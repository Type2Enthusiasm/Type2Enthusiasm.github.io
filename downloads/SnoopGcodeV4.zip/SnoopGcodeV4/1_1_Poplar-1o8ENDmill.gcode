; parseSafeZProperty: safeZMode = 'Retract'
; parseSafeZProperty: safeZHeightDefault = 15
; param: product-id = fusion360
;Fusion CAM 2602.1.25
; Posts processor: MPCNC v3.0 Beta 1.cps
; Gcode generated: Sun Aug 10 02:50:57 2025 GMT
; param: hostname = Harrisons-MacBook-Air.local
; param: username = harrisonesterly
; Document: snoop2 v15
; param: document-id = cdd3c627-a981-4b59-b2d6-a8cf2a6a6479
; param: model-version = 1b7ac768-0c1f-4280-92ec-74a9411570f3
; param: leads-supported = 1
; Setup: Setup1
; param: machine-id = 1
; param: machine-v2 = {
   "controller" : {
      "default" : {
         "head_info_part_id" : "head",
         "max_block_processing_speed" : 118,
         "max_normal_speed" : 4000.0000000000005,
         "non_tcp_rapid_interpolation_mode" : "Unsynchronized",
         "parts" : {
            "X" : {
               "coordinate" : 0,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Y" : {
               "coordinate" : 1,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Z" : {
               "coordinate" : 2,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            }
         },
         "table_part_id" : "table",
         "tcp_rapid_interpolation_mode" : "ToolTip"
      }
   },
   "general" : {
      "capabilities" : [ "milling" ],
      "description" : "Generic 3-axis",
      "minimumRevision" : 45805,
      "vendor" : "MP_CNC"
   },
   "interactions" : {
      "default" : {
         "pairs" : [
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            }
         ]
      }
   },
   "kinematics" : {
      "default" : {
         "conventions" : {
            "rotation" : "right-handed"
         },
         "parts" : [
            {
               "control" : "driven",
               "direction" : [ -1, 0, 0 ],
               "id" : "X",
               "max" : 289.99999999999994,
               "min" : 289.99999999999994,
               "name" : "X",
               "parts" : [
                  {
                     "control" : "driven",
                     "direction" : [ 0, -1, 0 ],
                     "id" : "Y",
                     "name" : "Y",
                     "parts" : [
                        {
                           "control" : "driven",
                           "direction" : [ 0, 0, -1 ],
                           "id" : "Z",
                           "max" : 0,
                           "min" : 0,
                           "name" : "Z",
                           "parts" : [
                              {
                                 "attach_frame" : {
                                    "point" : [ 0, 0, 0 ],
                                    "x_direction" : [ 1, 0, 0 ],
                                    "z_direction" : [ 0, 0, 1 ]
                                 },
                                 "display_name" : "table",
                                 "id" : "table",
                                 "type" : "table"
                              }
                           ],
                           "type" : "linear"
                        }
                     ],
                     "type" : "linear"
                  }
               ],
               "type" : "linear"
            },
            {
               "attach_frame" : {
                  "point" : [ 0, 0, 0 ],
                  "x_direction" : [ 1, 0, 0 ],
                  "z_direction" : [ 0, 0, 1 ]
               },
               "display_name" : "head",
               "id" : "head",
               "spindle" : {
                  "max_speed" : 0,
                  "min_speed" : 0
               },
               "tool_station" : {
                  "coolants" : null,
                  "max_tool_diameter" : 0,
                  "max_tool_length" : 0
               },
               "type" : "head"
            }
         ],
         "units" : {
            "angle" : "degrees",
            "length" : "mm"
         }
      }
   },
   "machining" : {
      "default" : {
         "feedrate_ratio" : 1,
         "tool_change_time" : 15
      }
   },
   "post" : {
      "default" : {
         "output_folder" : "/Users/harrisonesterly/Desktop/LIFE/Projects/MPCNC/fusion_GCode",
         "path" : "user://MPCNC.cps"
      }
   },
   "tooling" : {
      "default" : {
         "has_tool_changer" : false,
         "number_of_tools" : 100,
         "supports_tool_preload" : true
      }
   }
}


; param: stock-type = box
; param: stock = 0, 0, -26.416, 198.882, 300.482, 0
; param: stock-lower-x = 0
; param: stock-lower-y = 0
; param: stock-lower-z = -26.415999999999997
; param: stock-upper-x = 198.882
; param: stock-upper-y = 300.48199999999997
; param: stock-upper-z = 0
; param: part-lower-x = 1.0160000000000018
; param: part-lower-y = 1.0160000000000053
; param: part-lower-z = -26.415999999999997
; param: part-upper-x = 197.866
; param: part-upper-y = 299.466
; param: part-upper-z = -1.016
; param: areBothSpindlesGrabbed = 0
; param: notes = 
; param: operation-strategy = adaptive2d
; param: autodeskcam:operation-id = 6
; param: leads-supported = 1
; param: autodeskcam:path = Setups\Setup1\2D Adaptive1
; param: operation:is2DStrategy = 1
; param: operation:is3DStrategy = 0
; param: operation:isRoughingStrategy = 1
; param: operation:isFinishingStrategy = 0
; param: operation:isMillingStrategy = 1
; param: operation:isTurningStrategy = 0
; param: operation:isJetStrategy = 0
; param: operation:isAdditiveStrategy = 0
; param: operation:isProbingStrategy = 0
; param: operation:isInspectionStrategy = 0
; param: operation:isDrillingStrategy = 0
; param: operation:isHoleMillingStrategy = 0
; param: operation:isThreadStrategy = 0
; param: operation:isSamplingStrategy = 0
; param: operation:isRotaryStrategy = 1
; param: operation:isSubspindleStrategy = 0
; param: operation:isSurfaceStrategy = 0
; param: operation:isCheckSurfaceStrategy = 0
; param: operation:isMultiAxisStrategy = 0
; param: operation:advancedMode = 0
; param: operation:betaMode = 0
; param: operation:alphaMode = 0
; param: operation:isXpress = 0
; param: operation:licenseMultiaxis = 1
; param: operation:license3D = 1
; param: operation:metric = 0
; param: operation:isAssemblyDocument = 1
; param: operation:context = operation
; param: operation:strategy = adaptive2d
; param: operation:operation_description = 2D Adaptive
; param: operation:tool_type = flat end mill
; param: operation:undercut = 0
; param: operation:tool_isTurning = 0
; param: operation:tool_isMill = 1
; param: operation:tool_isDrill = 0
; param: operation:tool_isJet = 0
; param: operation:tool_isDepositing = 0
; param: operation:tool_taperedType = tapered_bull_nose
; param: operation:tool_unit = inches
; param: operation:tool_number = 2
; param: operation:tool_diameterOffset = 2
; param: operation:tool_lengthOffset = 2
; param: operation:tool_compensationOffset = 2
; param: operation:tool_turret = 0
; param: operation:tool_manualToolChange = 0
; param: operation:tool_breakControl = 0
; param: operation:tool_live = 1
; param: operation:tool_material = carbide
; param: operation:tool_description = HELICAL - 82253 - SQUARE END MILL FOR STEEL - 0.1250 1/8 DIA X 0.1250 1/8 SHANK DIA X 0.8750 7/8 LOC X 2.5000 2-1/2 OAL , 4 FLUTES, APLUS COATED
; param: operation:tool_comment = 
; param: operation:tool_vendor = HELICAL SOLUTIONS
; param: operation:tool_productId = 82253
; param: operation:tool_productLink = https://www.helicaltool.com/products/tool-details-82253
; param: operation:tool_diameter = 3.175
; param: operation:tool_maximumCuttingDiameter = 0
; param: operation:tool_tipDiameter = 3.175
; param: operation:tool_tipOffset = 0
; param: operation:tool_cornerRadius = 0
; param: operation:tool_inclusiveAngle = 0
; param: operation:tool_taperAngle = 0
; param: operation:tool_tipAngle = 0
; param: operation:tool_threadTipType = point
; param: operation:tool_threadTipWidth = 0
; param: operation:tool_threadTipRadius = 0
; param: operation:tool_threadProfileAngle = 0
; param: operation:tool_tipLength = 0
; param: operation:tool_fluteLength = 22.225
; param: operation:tool_shoulderLength = 22.225
; param: operation:tool_bodyLength = 23.8125
; param: operation:tool_overallLength = 63.5
; param: operation:tool_shaftDiameter = 3.175
; param: operation:tool_segmentHeight = 1.5875
; param: operation:tool_segmentDiameterLower = 6.35
; param: operation:tool_segmentDiameterUpper = 6.35
; param: operation:tool_shaftSegmentHeight = 1
; param: operation:tool_shaftSegmentDiameterLower = 3.175
; param: operation:tool_shaftSegmentDiameterUpper = 3.175
; param: operation:tool_threadPitch = 0
; param: operation:tool_maximumThreadPitch = 0
; param: operation:tool_minimumThreadPitch = 0
; param: operation:tool_numberOfTeeth = 0
; param: operation:tool_numberOfFlutes = 4
; param: operation:tool_shoulderDiameter = 3.175
; param: operation:tool_upperRadius = 1.016
; param: operation:tool_profileRadius = 101.6
; param: operation:tool_lowerRadius = 1.016
; param: operation:tool_axialDistance = 1.016
; param: operation:tool_chamferWidth = 1.016
; param: operation:tool_chamferAngle = 45
; param: operation:holder_attached = 0
; param: operation:holder_description = 
; param: operation:holder_comment = 
; param: operation:holder_vendor = 
; param: operation:holder_productId = 
; param: operation:holder_productLink = 
; param: operation:holder_libraryName = 
; param: operation:tool_holderGaugeLength = 0
; param: operation:tool_assemblyGaugeLength = 23.8125
; param: operation:tool_spindleSpeed = 25
; param: operation:tool_stockDiameter = 3.175
; param: operation:tool_surfaceSpeed = 249.36391687868982
; param: operation:tool_rampSpindleSpeed = 25
; param: operation:tool_feedCutting = 254
; param: operation:tool_feedPerTooth = 2.54
; param: operation:tool_feedEntry = 254
; param: operation:tool_feedExit = 254
; param: operation:tool_feedTransition = 254
; param: operation:tool_feedRamp = 25.4
; param: operation:tool_feedPlunge = 25.4
; param: operation:tool_feedPerRevolution = 1.016
; param: operation:tool_feedRetract = 25.4
; param: operation:tool_clockwise = 1
; param: operation:tool_coolant = disabled
; param: operation:featureOperationId = none
; param: operation:surfaceZHigh = -1.016
; param: operation:surfaceZLow = -26.416
; param: operation:surfaceXLow = 1.016
; param: operation:surfaceXHigh = 197.866
; param: operation:surfaceYLow = 1.01600000000001
; param: operation:surfaceYHigh = 299.46599999999995
; param: operation:stockZHigh = 0
; param: operation:stockZLow = -26.416
; param: operation:stockXLow = 0
; param: operation:stockXHigh = 198.88200000000003
; param: operation:stockYLow = 0
; param: operation:stockYHigh = 300.48199999999986
; param: operation:multiAxisMachiningType = three_axis
; param: operation:view_orientation_mode = useWCS
; param: operation:view_orientation_flipZ = 0
; param: operation:view_orientation_axesZX_unselected_default = wcs
; param: operation:view_orientation_axesZY_unselected_default = wcs
; param: operation:view_orientation_axesXY_unselected_default = wcs
; param: operation:view_select_angles = turn_and_tilt
; param: operation:view_turn_from_recipe = 0
; param: operation:view_tilt_from_recipe = 0
; param: operation:view_orientation_flipX = 0
; param: operation:view_orientation_flipY = 0
; param: operation:view_origin_mode = jobOrigin
; param: operation:view_origin_boxPoint = top center
; param: operation:show_machine = 0
; param: operation:unwrap = 1
; param: operation:wrap_cylinder_radius = 0
; param: operation:wrap_nominalRadius_offset = 0
; param: operation:wrap_nominalRadius_value = 0
; param: operation:usePolarWhenNecessary = 0
; param: operation:polarMode = automatic
; param: operation:polarLineAngle = 0
; param: operation:pockets_detectOpenPockets = 1
; param: operation:pockets_connectOpenPockets = 1
; param: operation:pockets_errorCheck = 1
; param: operation:pockets_detectOverlaps = 0
; param: operation:restMaterialCutterDiameter = 6.35
; param: operation:restMaterialCornerRadius = 0
; param: operation:restMaterialTaperAngle = 0
; param: operation:restMaterialShoulderLength = 0
; param: operation:restMaterialTool = 
; param: operation:isClearanceAreaEnabled = 0
; param: operation:clearanceHeight_mode = from retract height
; param: operation:clearanceHeightFromHighest_checkStock = top
; param: operation:clearanceHeightFromLowest_checkStock = bottom
; param: operation:clearanceHeightFromHighest_checkModel = top
; param: operation:clearanceHeightFromLowest_checkModel = bottom
; param: operation:clearanceHeightFromHighest_checkFixture = top
; param: operation:clearanceHeightFromLowest_checkFixture = bottom
; param: operation:clearanceHeight_offset = 10.16
; param: operation:clearanceHeight_value = 15.239999999999998
; param: operation:clearanceHeight_absolute = 1
; param: operation:retractHeight_mode = from stock top
; param: operation:retractHeightFromHighest_checkStock = top
; param: operation:retractHeightFromLowest_checkStock = bottom
; param: operation:retractHeightFromHighest_checkModel = top
; param: operation:retractHeightFromLowest_checkModel = bottom
; param: operation:retractHeightFromHighest_checkFixture = top
; param: operation:retractHeightFromLowest_checkFixture = bottom
; param: operation:retractHeight_offset = 5.08
; param: operation:retractHeight_value = 5.08
; param: operation:retractHeight_absolute = 1
; param: operation:topHeight_mode = from stock top
; param: operation:topHeightFromHighest_checkStock = top
; param: operation:topHeightFromLowest_checkStock = bottom
; param: operation:topHeightFromHighest_checkModel = ignore
; param: operation:topHeightFromLowest_checkModel = ignore
; param: operation:topHeightFromHighest_checkFixture = ignore
; param: operation:topHeightFromLowest_checkFixture = ignore
; param: operation:topHeight_offset = 0
; param: operation:topHeight_value = 0
; param: operation:topHeight_absolute = 1
; param: operation:bottomHeight_mode = from contour
; param: operation:bottomHeightFromHighest_checkStock = bottom
; param: operation:bottomHeightFromLowest_checkStock = ignore
; param: operation:bottomHeightFromHighest_checkModel = bottom
; param: operation:bottomHeightFromLowest_checkModel = bottom
; param: operation:bottomHeightFromHighest_checkFixture = ignore
; param: operation:bottomHeightFromLowest_checkFixture = ignore
; param: operation:bottomHeight_offset = 0
; param: operation:bottomHeight_value = 0
; param: operation:bottomHeight_absolute = 0
; param: operation:tolerance = 0.1016
; param: operation:contourTolerance = 0.0508
; param: operation:totalSurfaceTolerance = 0.0508
; param: operation:surfaceTriangulationTolerance = 0.0508
; param: operation:calculationTolerance = 0.0508
; param: operation:thinningTolerance = 0.000508
; param: operation:chainingTolerance = 0.01016
; param: operation:gougingTolerance = 0.0508
; param: operation:optimalLoad = 1.27
; param: operation:optimalLoadWeight = 0
; param: operation:speedWeight = 0
; param: operation:feedWeight = 0
; param: operation:loadDeviation = 0.127
; param: operation:maximumLoad = 1.397
; param: operation:bothWays = 0
; param: operation:optimalLoadOtherWay = 1.27
; param: operation:loadDeviationOtherWay = 0.127
; param: operation:maximumLoadOtherWay = 1.397
; param: operation:otherWayFeedrate = 228.6
; param: operation:maximumCuspHeight = 0
; param: operation:minimumCuttingRadius = 0.3175
; param: operation:minimumCuttingRadiusJl = 0.3175
; param: operation:machineCavities = 1
; param: operation:useSlotClearing = 0
; param: operation:slotClearingWidth = 3.96875
; param: operation:direction = climb
; param: operation:maximumStepdown = 5.08
; param: operation:maximumStepdownJl = 5.08
; param: operation:slopeAngle = 0
; param: operation:useEvenStepdowns = 0
; param: operation:curveInRadius = 0.7408333333333332
; param: operation:fineStepdown = 5.08
; param: operation:fineStepdownJl = 5.08
; param: operation:minimumStepdownJobline = 0
; param: operation:useSilhouetteAsStockBoundary = 0
; param: operation:orderByDepth = 0
; param: operation:orderByArea = 0
; param: operation:orderByAreaBufferSize = 400
; param: operation:stockToLeave = 0.254
; param: operation:verticalStockToLeave = 0.254
; param: operation:simpleStockToLeave = 0
; param: operation:useCombinedFilter = 1
; param: operation:useDMKSmoothing = 0
; param: operation:smoothingFilterMode = redistribute
; param: operation:smoothingFilterMaxSpacing = 0.508
; param: operation:smoothingFilterMaxAngle = 3
; param: operation:smoothingFilterToleranceForEvenlySpacedPoints = 0.0508
; param: operation:smoothingFilterToleranceFactor = 0.5
; param: operation:smoothingFilterTolerance = 0
; param: operation:reducedFeedChange = 25
; param: operation:reducedFeedRadius = 0
; param: operation:reducedFeedDistance = 0
; param: operation:reducedFeedrate = 228.6
; param: operation:reduceOnlyInnerCorners = 1
; param: operation:surfaceSpeedOnArcs = 0
; param: operation:maximumReducedFeedrateInternalArcFinishing = 100
; param: operation:maximumIncreasedFeedrateExternalArcFinishing = 100
; param: operation:maximumReducedFeedrateInternalArc = 100
; param: operation:maximumIncreasedFeedrateExternalArc = 100
; param: operation:retractionPolicy = full
; param: operation:highFeedrateMode = disabled
; param: operation:highFeedrate = 254
; param: operation:allowRapidRetract = 1
; param: operation:stayDownDistance = 15.875
; param: operation:minimumStayDownClearance = 2
; param: operation:stayDownLevel = level0
; param: operation:astarSpeedRatioJl = 0
; param: operation:liftHeight = 0.2032
; param: operation:noEngagementFeedrate = 254
; param: operation:leadRadius = 0.3175
; param: operation:verticalLeadRadius = 0.3175
; param: operation:leadInRadius = 0.3175
; param: operation:leadInVerticalRadius = 0.3175
; param: operation:leadOutRadius = 0.3175
; param: operation:leadOutVerticalRadius = 0.3175
; param: operation:rampType = helix
; param: operation:allowPlungingOutsideStockJl = 0
; param: operation:rampAngle = 2
; param: operation:rampTaperAngle = 1
; param: operation:rampClearanceHeight = 2.54
; param: operation:helicalRampDiameter = 3.01625
; param: operation:minimumRampDiameter = 1.5875
; param: operation:allowPlunging = 0
; param: operation:allowHelicalRamps = 1
; param: operation:isOperationTemplate = 0
; param: operation:use_tool_stepdown = 0
; param: operation:tool_stepdown = 20.0025
; param: operation:tool_finishingStepdown = 0.2032
; param: operation:use_tool_stepover = 0
; param: operation:tool_stepover = 0.9524999999999999
; param: operation:tool_finishingStepover = 0.3175
; param: operation:tool_rampType = helix
; param: operation:tool_rampAngle = 2
;When using Fusion for Personal Use, the feedrate of rapid
;moves is reduced to match the feedrate of cutting moves,
;which can increase machining time. Unrestricted rapid moves
;are available with a Fusion Subscription.
; param: movement:lead_in = 254
; param: movement:cutting = 254
; param: movement:lead_out = 254
; param: movement:transition = 254
; param: movement:direct = 254
; param: movement:helix_ramp = 25.399999999999995
; param: movement:profile_ramp = 25.399999999999995
; param: movement:zigzag_ramp = 25.399999999999995
; param: movement:ramp = 25.399999999999995
; param: movement:plunge = 25.4
; param: movement:predrill = 254
; param: movement:extended = 254
; param: movement:reduced = 254
; param: movement:finish_cutting = 254
; param: movement:high_feed = 254
; param: movement:depositing = 0
; param: movement:connection = 0
; param: movement:drill_breakthrough = 0
; param: movement:gun_drill_positioning = 0
; 
; Ranges Table:
;   X: Min=71.904 Max=126.57 Size=54.667
;   Y: Min=151.833 Max=236.806 Size=84.973
;   Z: Min=-5.762 Max=15.24 Size=21.002
; 
; Tools Table:
;  T2 D=3.175 CR=0 - ZMIN=-5.762 - flat end mill 
; 
; Feedrate and Scaling Properties:
;   Feed: Travel speed X/Y = 4470
;   Feed: Travel Speed Z = 2235
;   Feed: Enforce Feedrate = true
;   Feed: Scale Feedrate = false
;   Feed: Max XY Cut Speed = 1000
;   Feed: Max Z Cut Speed = 400
;   Feed: Max Toolpath Speed = 1000
; 
; G1->G0 Mapping Properties:
;   Map: First G1 -> G0 Rapid = false
;   Map: G1s -> G0 Rapids = false
;   Map: SafeZ Mode = Retract : default = 15
;   Map: Allow Rapid Z = false
; 
; *** START begin ***
;   Set Absolute Positioning
;   Units = mm
G90
G21
;   Disable stepper timeout
M84 S0
;   Set current position to 0,0,0
G92 X0 Y0 Z0
; *** START end ***
; 
; *** SECTION begin ***
;   X Min: 71.904 - X Max: 126.57
;   Y Min: 151.833 - Y Max: 236.806
;   Z Min: -5.762 - Z Max: 15.24
; 2D Adaptive1 - Milling - Tool: 2 -  flat end mill
; COMMAND_START_SPINDLE
; COMMAND_SPINDLE_CLOCKWISE
; >>> Spindle Speed: Manual
M0 Turn ON 25RPM
; COMMAND_COOLANT_ON
;   tool.coolant = 0 strCoolant = Off
; ---- Coolant: Off cur: Off A: Off B: Off
M117  2D Adaptive1
; MOVEMENT_CUTTING
G1 X73.959 Y152.599 Z15.24 F254
G1 Z5.08 F254
G1 Z2.54 F254
; MOVEMENT_RAMP_HELIX
G1 X74.05 Y152.544 Z2.536 F25
G1 X74.145 Y152.496 Z2.533 F25
G1 X74.243 Y152.456 Z2.529 F25
G1 X74.344 Y152.422 Z2.525 F25
G1 X74.447 Y152.396 Z2.521 F25
G1 X74.552 Y152.379 Z2.518 F25
G1 X74.658 Y152.368 Z2.514 F25
G1 X74.764 Y152.366 Z2.51 F25
G1 X74.87 Y152.372 Z2.507 F25
G1 X74.975 Y152.386 Z2.503 F25
G1 X75.08 Y152.407 Z2.499 F25
G1 X75.182 Y152.436 Z2.495 F25
G1 X75.282 Y152.473 Z2.492 F25
G1 X75.378 Y152.517 Z2.488 F25
G1 X75.472 Y152.568 Z2.484 F25
G1 X75.561 Y152.626 Z2.481 F25
G1 X75.645 Y152.69 Z2.477 F25
G1 X75.725 Y152.761 Z2.473 F25
G1 X75.799 Y152.837 Z2.469 F25
G1 X75.867 Y152.918 Z2.466 F25
G1 X75.929 Y153.005 Z2.462 F25
G1 X75.985 Y153.095 Z2.458 F25
G1 X76.033 Y153.19 Z2.455 F25
G1 X76.075 Y153.288 Z2.451 F25
G1 X76.108 Y153.389 Z2.447 F25
G1 X76.135 Y153.492 Z2.443 F25
G1 X76.153 Y153.596 Z2.44 F25
G1 X76.164 Y153.702 Z2.436 F25
G1 X76.167 Y153.808 Z2.432 F25
G1 X76.162 Y153.914 Z2.429 F25
G1 X76.149 Y154.02 Z2.425 F25
G1 X76.128 Y154.124 Z2.421 F25
G1 X76.099 Y154.226 Z2.417 F25
G1 X76.063 Y154.326 Z2.414 F25
G1 X76.02 Y154.423 Z2.41 F25
G1 X75.969 Y154.516 Z2.406 F25
G1 X75.912 Y154.606 Z2.403 F25
G1 X75.848 Y154.691 Z2.399 F25
G1 X75.778 Y154.77 Z2.395 F25
G1 X75.703 Y154.845 Z2.391 F25
G1 X75.622 Y154.914 Z2.388 F25
G1 X75.536 Y154.976 Z2.384 F25
G1 X75.445 Y155.032 Z2.38 F25
G1 X75.351 Y155.081 Z2.377 F25
G1 X75.253 Y155.122 Z2.373 F25
G1 X75.153 Y155.157 Z2.369 F25
G1 X75.05 Y155.184 Z2.365 F25
G1 X74.946 Y155.203 Z2.362 F25
G1 X74.84 Y155.214 Z2.358 F25
G1 X74.734 Y155.217 Z2.354 F25
G1 X74.628 Y155.213 Z2.351 F25
G1 X74.523 Y155.2 Z2.347 F25
G1 X74.418 Y155.18 Z2.343 F25
G1 X74.316 Y155.152 Z2.339 F25
G1 X74.216 Y155.117 Z2.336 F25
G1 X74.119 Y155.074 Z2.332 F25
G1 X74.025 Y155.024 Z2.328 F25
G1 X73.936 Y154.967 Z2.325 F25
G1 X73.851 Y154.904 Z2.321 F25
G1 X73.77 Y154.835 Z2.317 F25
G1 X73.696 Y154.759 Z2.313 F25
G1 X73.627 Y154.679 Z2.31 F25
G1 X73.564 Y154.593 Z2.306 F25
G1 X73.508 Y154.504 Z2.302 F25
G1 X73.458 Y154.41 Z2.299 F25
G1 X73.416 Y154.312 Z2.295 F25
G1 X73.381 Y154.212 Z2.291 F25
G1 X73.354 Y154.11 Z2.287 F25
G1 X73.334 Y154.006 Z2.284 F25
G1 X73.322 Y153.9 Z2.28 F25
G1 X73.318 Y153.794 Z2.276 F25
G1 X73.322 Y153.688 Z2.273 F25
G1 X73.334 Y153.583 Z2.269 F25
G1 X73.354 Y153.479 Z2.265 F25
G1 X73.381 Y153.376 Z2.261 F25
G1 X73.416 Y153.276 Z2.258 F25
G1 X73.458 Y153.179 Z2.254 F25
G1 X73.507 Y153.085 Z2.25 F25
G1 X73.564 Y152.995 Z2.247 F25
G1 X73.627 Y152.909 Z2.243 F25
G1 X73.695 Y152.829 Z2.239 F25
G1 X73.77 Y152.754 Z2.235 F25
G1 X73.85 Y152.684 Z2.232 F25
G1 X73.935 Y152.621 Z2.228 F25
G1 X74.025 Y152.565 Z2.224 F25
G1 X74.118 Y152.515 Z2.221 F25
G1 X74.215 Y152.472 Z2.217 F25
G1 X74.315 Y152.437 Z2.213 F25
G1 X74.417 Y152.409 Z2.21 F25
G1 X74.521 Y152.388 Z2.206 F25
G1 X74.626 Y152.376 Z2.202 F25
G1 X74.732 Y152.372 Z2.198 F25
G1 X74.838 Y152.375 Z2.195 F25
G1 X74.943 Y152.386 Z2.191 F25
G1 X75.048 Y152.405 Z2.187 F25
G1 X75.15 Y152.432 Z2.184 F25
G1 X75.25 Y152.466 Z2.18 F25
G1 X75.348 Y152.508 Z2.176 F25
G1 X75.442 Y152.557 Z2.172 F25
G1 X75.532 Y152.612 Z2.169 F25
G1 X75.617 Y152.675 Z2.165 F25
G1 X75.698 Y152.743 Z2.161 F25
G1 X75.774 Y152.817 Z2.158 F25
G1 X75.844 Y152.897 Z2.154 F25
G1 X75.907 Y152.982 Z2.15 F25
G1 X75.964 Y153.071 Z2.146 F25
G1 X76.015 Y153.164 Z2.143 F25
G1 X76.058 Y153.261 Z2.139 F25
G1 X76.094 Y153.36 Z2.135 F25
G1 X76.122 Y153.462 Z2.132 F25
G1 X76.143 Y153.566 Z2.128 F25
G1 X76.156 Y153.671 Z2.124 F25
G1 X76.161 Y153.776 Z2.12 F25
G1 X76.159 Y153.882 Z2.117 F25
G1 X76.148 Y153.987 Z2.113 F25
G1 X76.129 Y154.092 Z2.109 F25
G1 X76.103 Y154.194 Z2.106 F25
G1 X76.07 Y154.294 Z2.102 F25
G1 X76.029 Y154.392 Z2.098 F25
G1 X75.98 Y154.486 Z2.094 F25
G1 X75.925 Y154.576 Z2.091 F25
G1 X75.864 Y154.662 Z2.087 F25
G1 X75.796 Y154.743 Z2.083 F25
G1 X75.722 Y154.819 Z2.08 F25
G1 X75.643 Y154.889 Z2.076 F25
G1 X75.558 Y154.954 Z2.072 F25
G1 X75.47 Y155.011 Z2.068 F25
G1 X75.377 Y155.062 Z2.065 F25
G1 X75.281 Y155.106 Z2.061 F25
G1 X75.181 Y155.142 Z2.057 F25
G1 X75.08 Y155.171 Z2.054 F25
G1 X74.976 Y155.193 Z2.05 F25
G1 X74.871 Y155.206 Z2.046 F25
G1 X74.765 Y155.212 Z2.042 F25
G1 X74.66 Y155.21 Z2.039 F25
G1 X74.554 Y155.2 Z2.035 F25
G1 X74.45 Y155.182 Z2.031 F25
G1 X74.348 Y155.156 Z2.028 F25
G1 X74.247 Y155.123 Z2.024 F25
G1 X74.15 Y155.083 Z2.02 F25
G1 X74.056 Y155.035 Z2.016 F25
G1 X73.965 Y154.98 Z2.013 F25
G1 X73.879 Y154.919 Z2.009 F25
G1 X73.797 Y154.852 Z2.005 F25
G1 X73.721 Y154.779 Z2.002 F25
G1 X73.651 Y154.7 Z1.998 F25
G1 X73.586 Y154.616 Z1.994 F25
G1 X73.528 Y154.528 Z1.99 F25
G1 X73.477 Y154.436 Z1.987 F25
G1 X73.433 Y154.34 Z1.983 F25
G1 X73.396 Y154.241 Z1.979 F25
G1 X73.366 Y154.139 Z1.976 F25
G1 X73.344 Y154.036 Z1.972 F25
G1 X73.33 Y153.931 Z1.968 F25
G1 X73.324 Y153.826 Z1.964 F25
G1 X73.326 Y153.72 Z1.961 F25
G1 X73.335 Y153.615 Z1.957 F25
G1 X73.352 Y153.51 Z1.953 F25
G1 X73.377 Y153.408 Z1.95 F25
G1 X73.41 Y153.307 Z1.946 F25
G1 X73.45 Y153.209 Z1.942 F25
G1 X73.497 Y153.115 Z1.938 F25
G1 X73.551 Y153.024 Z1.935 F25
G1 X73.611 Y152.938 Z1.931 F25
G1 X73.678 Y152.856 Z1.927 F25
G1 X73.751 Y152.78 Z1.924 F25
G1 X73.829 Y152.709 Z1.92 F25
G1 X73.913 Y152.644 Z1.916 F25
G1 X74 Y152.586 Z1.912 F25
G1 X74.092 Y152.534 Z1.909 F25
G1 X74.188 Y152.489 Z1.905 F25
G1 X74.287 Y152.452 Z1.901 F25
G1 X74.388 Y152.422 Z1.898 F25
G1 X74.491 Y152.399 Z1.894 F25
G1 X74.595 Y152.384 Z1.89 F25
G1 X74.701 Y152.378 Z1.886 F25
G1 X74.806 Y152.379 Z1.883 F25
G1 X74.911 Y152.387 Z1.879 F25
G1 X75.016 Y152.404 Z1.875 F25
G1 X75.118 Y152.428 Z1.872 F25
G1 X75.219 Y152.46 Z1.868 F25
G1 X75.317 Y152.5 Z1.864 F25
G1 X75.411 Y152.546 Z1.86 F25
G1 X75.502 Y152.6 Z1.857 F25
G1 X75.589 Y152.66 Z1.853 F25
G1 X75.671 Y152.726 Z1.849 F25
G1 X75.748 Y152.799 Z1.846 F25
G1 X75.819 Y152.876 Z1.842 F25
G1 X75.885 Y152.959 Z1.838 F25
G1 X75.944 Y153.047 Z1.834 F25
G1 X75.996 Y153.138 Z1.831 F25
G1 X76.041 Y153.234 Z1.827 F25
G1 X76.079 Y153.332 Z1.823 F25
G1 X76.109 Y153.433 Z1.82 F25
G1 X76.132 Y153.536 Z1.816 F25
G1 X76.148 Y153.64 Z1.812 F25
G1 X76.155 Y153.745 Z1.808 F25
G1 Y153.85 Z1.805 F25
G1 X76.146 Y153.955 Z1.801 F25
G1 X76.13 Y154.06 Z1.797 F25
G1 X76.107 Y154.162 Z1.794 F25
G1 X76.075 Y154.263 Z1.79 F25
G1 X76.037 Y154.361 Z1.786 F25
G1 X75.991 Y154.456 Z1.782 F25
G1 X75.938 Y154.547 Z1.779 F25
G1 X75.878 Y154.634 Z1.775 F25
G1 X75.812 Y154.716 Z1.771 F25
G1 X75.741 Y154.793 Z1.768 F25
G1 X75.663 Y154.865 Z1.764 F25
G1 X75.581 Y154.931 Z1.76 F25
G1 X75.494 Y154.99 Z1.756 F25
G1 X75.402 Y155.043 Z1.753 F25
G1 X75.307 Y155.089 Z1.749 F25
G1 X75.209 Y155.127 Z1.745 F25
G1 X75.109 Y155.158 Z1.742 F25
G1 X75.006 Y155.182 Z1.738 F25
G1 X74.902 Y155.198 Z1.734 F25
G1 X74.797 Y155.206 Z1.73 F25
G1 X74.691 Z1.727 F25
G1 X74.586 Y155.198 Z1.723 F25
G1 X74.482 Y155.183 Z1.719 F25
G1 X74.38 Y155.159 Z1.716 F25
G1 X74.279 Y155.129 Z1.712 F25
G1 X74.181 Y155.09 Z1.708 F25
G1 X74.086 Y155.045 Z1.704 F25
G1 X73.995 Y154.993 Z1.701 F25
G1 X73.907 Y154.934 Z1.697 F25
G1 X73.825 Y154.868 Z1.693 F25
G1 X73.747 Y154.797 Z1.69 F25
G1 X73.675 Y154.72 Z1.686 F25
G1 X73.609 Y154.638 Z1.682 F25
G1 X73.55 Y154.552 Z1.678 F25
G1 X73.496 Y154.461 Z1.675 F25
G1 X73.45 Y154.366 Z1.671 F25
G1 X73.411 Y154.268 Z1.667 F25
G1 X73.38 Y154.168 Z1.664 F25
G1 X73.355 Y154.066 Z1.66 F25
G1 X73.339 Y153.962 Z1.656 F25
G1 X73.331 Y153.857 Z1.652 F25
G1 X73.33 Y153.751 Z1.649 F25
G1 X73.337 Y153.646 Z1.645 F25
G1 X73.352 Y153.542 Z1.641 F25
G1 X73.374 Y153.439 Z1.638 F25
G1 X73.404 Y153.339 Z1.634 F25
G1 X73.442 Y153.24 Z1.63 F25
G1 X73.487 Y153.145 Z1.626 F25
G1 X73.539 Y153.054 Z1.623 F25
G1 X73.597 Y152.966 Z1.619 F25
G1 X73.662 Y152.884 Z1.615 F25
G1 X73.733 Y152.806 Z1.612 F25
G1 X73.809 Y152.733 Z1.608 F25
G1 X73.89 Y152.667 Z1.604 F25
G1 X73.977 Y152.607 Z1.6 F25
G1 X74.067 Y152.553 Z1.597 F25
G1 X74.161 Y152.507 Z1.593 F25
G1 X74.259 Y152.467 Z1.589 F25
G1 X74.359 Y152.435 Z1.586 F25
G1 X74.461 Y152.41 Z1.582 F25
G1 X74.565 Y152.393 Z1.578 F25
G1 X74.67 Y152.384 Z1.575 F25
G1 X74.775 Y152.383 Z1.571 F25
G1 X74.88 Y152.389 Z1.567 F25
G1 X74.984 Y152.404 Z1.563 F25
G1 X75.087 Y152.426 Z1.56 F25
G1 X75.188 Y152.455 Z1.556 F25
G1 X75.286 Y152.492 Z1.552 F25
G1 X75.381 Y152.537 Z1.549 F25
G1 X75.473 Y152.588 Z1.545 F25
G1 X75.561 Y152.646 Z1.541 F25
G1 X75.644 Y152.71 Z1.537 F25
G1 X75.722 Y152.78 Z1.534 F25
G1 X75.795 Y152.856 Z1.53 F25
G1 X75.862 Y152.937 Z1.526 F25
G1 X75.922 Y153.023 Z1.523 F25
G1 X75.976 Y153.113 Z1.519 F25
G1 X76.023 Y153.207 Z1.515 F25
G1 X76.063 Y153.304 Z1.511 F25
G1 X76.096 Y153.404 Z1.508 F25
G1 X76.121 Y153.506 Z1.504 F25
G1 X76.139 Y153.609 Z1.5 F25
G1 X76.148 Y153.714 Z1.497 F25
G1 X76.15 Y153.819 Z1.493 F25
G1 X76.144 Y153.924 Z1.489 F25
G1 X76.131 Y154.028 Z1.485 F25
G1 X76.109 Y154.131 Z1.482 F25
G1 X76.08 Y154.232 Z1.478 F25
G1 X76.044 Y154.33 Z1.474 F25
G1 X76 Y154.426 Z1.471 F25
G1 X75.949 Y154.518 Z1.467 F25
G1 X75.892 Y154.605 Z1.463 F25
G1 X75.828 Y154.689 Z1.459 F25
G1 X75.758 Y154.767 Z1.456 F25
G1 X75.683 Y154.84 Z1.452 F25
G1 X75.602 Y154.908 Z1.448 F25
G1 X75.517 Y154.969 Z1.445 F25
G1 X75.427 Y155.023 Z1.441 F25
G1 X75.334 Y155.071 Z1.437 F25
G1 X75.237 Y155.111 Z1.433 F25
G1 X75.137 Y155.144 Z1.43 F25
G1 X75.036 Y155.17 Z1.426 F25
G1 X74.932 Y155.188 Z1.422 F25
G1 X74.828 Y155.199 Z1.419 F25
G1 X74.723 Y155.201 Z1.415 F25
G1 X74.618 Y155.196 Z1.411 F25
G1 X74.514 Y155.183 Z1.407 F25
G1 X74.411 Y155.162 Z1.404 F25
G1 X74.311 Y155.133 Z1.4 F25
G1 X74.212 Y155.098 Z1.396 F25
G1 X74.116 Y155.054 Z1.393 F25
G1 X74.024 Y155.004 Z1.389 F25
G1 X73.936 Y154.948 Z1.385 F25
G1 X73.852 Y154.884 Z1.381 F25
G1 X73.774 Y154.815 Z1.378 F25
G1 X73.7 Y154.74 Z1.374 F25
G1 X73.633 Y154.66 Z1.37 F25
G1 X73.571 Y154.575 Z1.367 F25
G1 X73.516 Y154.486 Z1.363 F25
G1 X73.468 Y154.392 Z1.359 F25
G1 X73.427 Y154.296 Z1.355 F25
G1 X73.393 Y154.197 Z1.352 F25
G1 X73.367 Y154.095 Z1.348 F25
G1 X73.349 Y153.992 Z1.344 F25
G1 X73.338 Y153.887 Z1.341 F25
G1 X73.335 Y153.783 Z1.337 F25
G1 X73.339 Y153.678 Z1.333 F25
G1 X73.352 Y153.574 Z1.329 F25
G1 X73.372 Y153.471 Z1.326 F25
G1 X73.4 Y153.37 Z1.322 F25
G1 X73.435 Y153.272 Z1.318 F25
G1 X73.478 Y153.176 Z1.315 F25
G1 X73.527 Y153.084 Z1.311 F25
G1 X73.583 Y152.995 Z1.307 F25
G1 X73.646 Y152.911 Z1.303 F25
G1 X73.715 Y152.832 Z1.3 F25
G1 X73.789 Y152.758 Z1.296 F25
G1 X73.869 Y152.691 Z1.292 F25
G1 X73.954 Y152.629 Z1.289 F25
G1 X74.042 Y152.573 Z1.285 F25
G1 X74.135 Y152.525 Z1.281 F25
G1 X74.231 Y152.483 Z1.277 F25
G1 X74.33 Y152.449 Z1.274 F25
G1 X74.432 Y152.422 Z1.27 F25
G1 X74.535 Y152.403 Z1.266 F25
G1 X74.639 Y152.392 Z1.263 F25
G1 X74.744 Y152.388 Z1.259 F25
G1 X74.848 Y152.392 Z1.255 F25
G1 X74.952 Y152.404 Z1.251 F25
G1 X75.055 Y152.424 Z1.248 F25
G1 X75.156 Y152.451 Z1.244 F25
G1 X75.255 Y152.486 Z1.24 F25
G1 X75.351 Y152.528 Z1.237 F25
G1 X75.444 Y152.577 Z1.233 F25
G1 X75.532 Y152.632 Z1.229 F25
G1 X75.616 Y152.694 Z1.225 F25
G1 X75.696 Y152.763 Z1.222 F25
G1 X75.77 Y152.837 Z1.218 F25
G1 X75.838 Y152.916 Z1.214 F25
G1 X75.9 Y153 Z1.211 F25
G1 X75.956 Y153.088 Z1.207 F25
G1 X76.005 Y153.181 Z1.203 F25
G1 X76.047 Y153.277 Z1.199 F25
G1 X76.082 Y153.375 Z1.196 F25
G1 X76.109 Y153.476 Z1.192 F25
G1 X76.129 Y153.579 Z1.188 F25
G1 X76.141 Y153.683 Z1.185 F25
G1 X76.145 Y153.788 Z1.181 F25
G1 X76.141 Y153.892 Z1.177 F25
G1 X76.13 Y153.996 Z1.173 F25
G1 X76.111 Y154.099 Z1.17 F25
G1 X76.084 Y154.2 Z1.166 F25
G1 X76.05 Y154.299 Z1.162 F25
G1 X76.009 Y154.395 Z1.159 F25
G1 X75.96 Y154.488 Z1.155 F25
G1 X75.905 Y154.577 Z1.151 F25
G1 X75.844 Y154.661 Z1.147 F25
G1 X75.776 Y154.741 Z1.144 F25
G1 X75.702 Y154.815 Z1.14 F25
G1 X75.623 Y154.884 Z1.136 F25
G1 X75.54 Y154.947 Z1.133 F25
G1 X75.452 Y155.003 Z1.129 F25
G1 X75.36 Y155.052 Z1.125 F25
G1 X75.264 Y155.095 Z1.121 F25
G1 X75.166 Y155.13 Z1.118 F25
G1 X75.065 Y155.158 Z1.114 F25
G1 X74.962 Y155.178 Z1.11 F25
G1 X74.859 Y155.191 Z1.107 F25
G1 X74.754 Y155.196 Z1.103 F25
G1 X74.65 Y155.193 Z1.099 F25
G1 X74.546 Y155.182 Z1.095 F25
G1 X74.443 Y155.163 Z1.092 F25
G1 X74.342 Y155.137 Z1.088 F25
G1 X74.243 Y155.104 Z1.084 F25
G1 X74.147 Y155.063 Z1.081 F25
G1 X74.054 Y155.015 Z1.077 F25
G1 X73.965 Y154.961 Z1.073 F25
G1 X73.88 Y154.899 Z1.069 F25
G1 X73.8 Y154.832 Z1.066 F25
G1 X73.725 Y154.759 Z1.062 F25
G1 X73.656 Y154.681 Z1.058 F25
G1 X73.593 Y154.597 Z1.055 F25
G1 X73.537 Y154.51 Z1.051 F25
G1 X73.487 Y154.418 Z1.047 F25
G1 X73.444 Y154.323 Z1.043 F25
G1 X73.408 Y154.225 Z1.04 F25
G1 X73.379 Y154.124 Z1.036 F25
G1 X73.359 Y154.022 Z1.032 F25
G1 X73.345 Y153.918 Z1.029 F25
G1 X73.34 Y153.814 Z1.025 F25
G1 X73.342 Y153.71 Z1.021 F25
G1 X73.353 Y153.606 Z1.017 F25
G1 X73.37 Y153.503 Z1.014 F25
G1 X73.396 Y153.402 Z1.01 F25
G1 X73.429 Y153.303 Z1.006 F25
G1 X73.469 Y153.206 Z1.003 F25
G1 X73.516 Y153.113 Z0.999 F25
G1 X73.57 Y153.024 Z0.995 F25
G1 X73.631 Y152.939 Z0.991 F25
G1 X73.698 Y152.859 Z0.988 F25
G1 X73.77 Y152.784 Z0.984 F25
G1 X73.848 Y152.714 Z0.98 F25
G1 X73.931 Y152.651 Z0.977 F25
G1 X74.018 Y152.594 Z0.973 F25
G1 X74.11 Y152.543 Z0.969 F25
G1 X74.205 Y152.5 Z0.965 F25
G1 X74.303 Y152.464 Z0.962 F25
G1 X74.403 Y152.435 Z0.958 F25
G1 X74.505 Y152.413 Z0.954 F25
G1 X74.608 Y152.4 Z0.951 F25
G1 X74.713 Y152.394 Z0.947 F25
G1 X74.817 Y152.396 Z0.943 F25
G1 X74.921 Y152.405 Z0.94 F25
G1 X75.024 Y152.422 Z0.936 F25
G1 X75.125 Y152.447 Z0.932 F25
G1 X75.224 Y152.48 Z0.928 F25
G1 X75.32 Y152.519 Z0.925 F25
G1 X75.414 Y152.566 Z0.921 F25
G1 X75.503 Y152.619 Z0.917 F25
G1 X75.588 Y152.68 Z0.914 F25
G1 X75.669 Y152.746 Z0.91 F25
G1 X75.744 Y152.818 Z0.906 F25
G1 X75.814 Y152.895 Z0.902 F25
G1 X75.878 Y152.978 Z0.899 F25
G1 X75.935 Y153.064 Z0.895 F25
G1 X75.986 Y153.155 Z0.891 F25
G1 X76.03 Y153.25 Z0.888 F25
G1 X76.067 Y153.347 Z0.884 F25
G1 X76.096 Y153.447 Z0.88 F25
G1 X76.118 Y153.549 Z0.876 F25
G1 X76.132 Y153.653 Z0.873 F25
G1 X76.139 Y153.757 Z0.869 F25
G1 X76.138 Y153.861 Z0.865 F25
G1 X76.129 Y153.965 Z0.862 F25
G1 X76.112 Y154.068 Z0.858 F25
G1 X76.088 Y154.169 Z0.854 F25
G1 X76.056 Y154.268 Z0.85 F25
G1 X76.017 Y154.365 Z0.847 F25
G1 X75.971 Y154.458 Z0.843 F25
G1 X75.918 Y154.548 Z0.839 F25
G1 X75.858 Y154.634 Z0.836 F25
G1 X75.792 Y154.714 Z0.832 F25
G1 X75.721 Y154.79 Z0.828 F25
G1 X75.644 Y154.86 Z0.824 F25
G1 X75.562 Y154.924 Z0.821 F25
G1 X75.476 Y154.982 Z0.817 F25
G1 X75.385 Y155.033 Z0.813 F25
G1 X75.291 Y155.078 Z0.81 F25
G1 X75.194 Y155.115 Z0.806 F25
G1 X75.094 Y155.145 Z0.802 F25
G1 X74.992 Y155.168 Z0.798 F25
G1 X74.889 Y155.182 Z0.795 F25
G1 X74.785 Y155.19 Z0.791 F25
G1 X74.681 Y155.189 Z0.787 F25
G1 X74.578 Y155.18 Z0.784 F25
G1 X74.475 Y155.164 Z0.78 F25
G1 X74.373 Y155.141 Z0.776 F25
G1 X74.274 Y155.109 Z0.772 F25
G1 X74.177 Y155.071 Z0.769 F25
G1 X74.084 Y155.025 Z0.765 F25
G1 X73.994 Y154.973 Z0.761 F25
G1 X73.908 Y154.914 Z0.758 F25
G1 X73.827 Y154.849 Z0.754 F25
G1 X73.751 Y154.778 Z0.75 F25
G1 X73.68 Y154.701 Z0.746 F25
G1 X73.616 Y154.619 Z0.743 F25
G1 X73.557 Y154.533 Z0.739 F25
G1 X73.505 Y154.443 Z0.735 F25
G1 X73.461 Y154.349 Z0.732 F25
G1 X73.423 Y154.252 Z0.728 F25
G1 X73.392 Y154.153 Z0.724 F25
G1 X73.369 Y154.051 Z0.72 F25
G1 X73.354 Y153.949 Z0.717 F25
G1 X73.346 Y153.845 Z0.713 F25
G1 Y153.741 Z0.709 F25
G1 X73.354 Y153.637 Z0.706 F25
G1 X73.37 Y153.535 Z0.702 F25
G1 X73.393 Y153.433 Z0.698 F25
G1 X73.423 Y153.334 Z0.694 F25
G1 X73.461 Y153.237 Z0.691 F25
G1 X73.506 Y153.143 Z0.687 F25
G1 X73.558 Y153.053 Z0.683 F25
G1 X73.617 Y152.967 Z0.68 F25
G1 X73.681 Y152.886 Z0.676 F25
G1 X73.752 Y152.809 Z0.672 F25
G1 X73.828 Y152.739 Z0.668 F25
G1 X73.909 Y152.674 Z0.665 F25
G1 X73.995 Y152.615 Z0.661 F25
G1 X74.085 Y152.563 Z0.657 F25
G1 X74.178 Y152.517 Z0.654 F25
G1 X74.275 Y152.479 Z0.65 F25
G1 X74.374 Y152.448 Z0.646 F25
G1 X74.476 Y152.424 Z0.642 F25
G1 X74.578 Y152.408 Z0.639 F25
G1 X74.682 Y152.4 Z0.635 F25
G1 X74.786 Z0.631 F25
G1 X74.889 Y152.407 Z0.628 F25
G1 X74.992 Y152.422 Z0.624 F25
G1 X75.093 Y152.444 Z0.62 F25
G1 X75.193 Y152.474 Z0.616 F25
G1 X75.29 Y152.512 Z0.613 F25
G1 X75.384 Y152.556 Z0.609 F25
G1 X75.474 Y152.607 Z0.605 F25
G1 X75.56 Y152.665 Z0.602 F25
G1 X75.642 Y152.729 Z0.598 F25
G1 X75.718 Y152.8 Z0.594 F25
G1 X75.79 Y152.875 Z0.59 F25
G1 X75.855 Y152.956 Z0.587 F25
G1 X75.914 Y153.041 Z0.583 F25
G1 X75.967 Y153.131 Z0.579 F25
G1 X76.013 Y153.224 Z0.576 F25
G1 X76.051 Y153.32 Z0.572 F25
G1 X76.083 Y153.419 Z0.568 F25
G1 X76.107 Y153.52 Z0.564 F25
G1 X76.124 Y153.623 Z0.561 F25
G1 X76.132 Y153.726 Z0.557 F25
G1 X76.133 Y153.83 Z0.553 F25
G1 X76.127 Y153.933 Z0.55 F25
G1 X76.112 Y154.036 Z0.546 F25
G1 X76.09 Y154.138 Z0.542 F25
G1 X76.061 Y154.237 Z0.538 F25
G1 X76.024 Y154.334 Z0.535 F25
G1 X75.98 Y154.428 Z0.531 F25
G1 X75.93 Y154.519 Z0.527 F25
G1 X75.872 Y154.605 Z0.524 F25
G1 X75.809 Y154.687 Z0.52 F25
G1 X75.739 Y154.764 Z0.516 F25
G1 X75.664 Y154.836 Z0.512 F25
G1 X75.584 Y154.901 Z0.509 F25
G1 X75.499 Y154.961 Z0.505 F25
G1 X75.41 Y155.014 Z0.501 F25
G1 X75.317 Y155.06 Z0.498 F25
G1 X75.221 Y155.1 Z0.494 F25
G1 X75.122 Y155.132 Z0.49 F25
G1 X75.022 Y155.156 Z0.486 F25
G1 X74.919 Y155.173 Z0.483 F25
G1 X74.816 Y155.183 Z0.479 F25
G1 X74.712 Y155.184 Z0.475 F25
G1 X74.609 Y155.178 Z0.472 F25
G1 X74.506 Y155.164 Z0.468 F25
G1 X74.405 Y155.143 Z0.464 F25
G1 X74.305 Y155.114 Z0.46 F25
G1 X74.208 Y155.078 Z0.457 F25
G1 X74.114 Y155.035 Z0.453 F25
G1 X74.023 Y154.984 Z0.449 F25
G1 X73.936 Y154.928 Z0.446 F25
G1 X73.854 Y154.864 Z0.442 F25
G1 X73.777 Y154.795 Z0.438 F25
G1 X73.705 Y154.721 Z0.434 F25
G1 X73.639 Y154.641 Z0.431 F25
G1 X73.579 Y154.556 Z0.427 F25
G1 X73.525 Y154.468 Z0.423 F25
G1 X73.478 Y154.375 Z0.42 F25
G1 X73.438 Y154.28 Z0.416 F25
G1 X73.406 Y154.181 Z0.412 F25
G1 X73.381 Y154.081 Z0.408 F25
G1 X73.363 Y153.979 Z0.405 F25
G1 X73.353 Y153.876 Z0.401 F25
G1 X73.351 Y153.772 Z0.397 F25
G1 X73.357 Y153.669 Z0.394 F25
G1 X73.37 Y153.566 Z0.39 F25
G1 X73.391 Y153.465 Z0.386 F25
G1 X73.419 Y153.365 Z0.382 F25
G1 X73.454 Y153.268 Z0.379 F25
G1 X73.497 Y153.173 Z0.375 F25
G1 X73.547 Y153.082 Z0.371 F25
G1 X73.603 Y152.995 Z0.368 F25
G1 X73.666 Y152.913 Z0.364 F25
G1 X73.734 Y152.835 Z0.36 F25
G1 X73.809 Y152.763 Z0.356 F25
G1 X73.888 Y152.697 Z0.353 F25
G1 X73.972 Y152.636 Z0.349 F25
G1 X74.06 Y152.582 Z0.345 F25
G1 X74.153 Y152.535 Z0.342 F25
G1 X74.248 Y152.494 Z0.338 F25
G1 X74.346 Y152.461 Z0.334 F25
G1 X74.446 Y152.436 Z0.33 F25
G1 X74.548 Y152.418 Z0.327 F25
G1 X74.651 Y152.407 Z0.323 F25
G1 X74.755 Y152.404 Z0.319 F25
G1 X74.858 Y152.409 Z0.316 F25
G1 X74.961 Y152.422 Z0.312 F25
G1 X75.062 Y152.442 Z0.308 F25
G1 X75.162 Y152.47 Z0.305 F25
G1 X75.259 Y152.505 Z0.301 F25
G1 X75.353 Y152.547 Z0.297 F25
G1 X75.445 Y152.596 Z0.293 F25
G1 X75.532 Y152.652 Z0.29 F25
G1 X75.614 Y152.714 Z0.286 F25
G1 X75.692 Y152.782 Z0.282 F25
G1 X75.765 Y152.856 Z0.279 F25
G1 X75.832 Y152.935 Z0.275 F25
G1 X75.893 Y153.018 Z0.271 F25
G1 X75.947 Y153.106 Z0.267 F25
G1 X75.995 Y153.198 Z0.264 F25
G1 X76.036 Y153.293 Z0.26 F25
G1 X76.069 Y153.391 Z0.256 F25
G1 X76.095 Y153.491 Z0.253 F25
G1 X76.114 Y153.593 Z0.249 F25
G1 X76.125 Y153.696 Z0.245 F25
G1 X76.129 Y153.799 Z0.241 F25
G1 X76.124 Y153.902 Z0.238 F25
G1 X76.112 Y154.005 Z0.234 F25
G1 X76.093 Y154.107 Z0.23 F25
G1 X76.065 Y154.206 Z0.227 F25
G1 X76.031 Y154.304 Z0.223 F25
G1 X75.989 Y154.398 Z0.219 F25
G1 X75.941 Y154.489 Z0.215 F25
G1 X75.886 Y154.577 Z0.212 F25
G1 X75.824 Y154.66 Z0.208 F25
G1 X75.756 Y154.738 Z0.204 F25
G1 X75.683 Y154.811 Z0.201 F25
G1 X75.605 Y154.878 Z0.197 F25
G1 X75.522 Y154.939 Z0.193 F25
G1 X75.434 Y154.994 Z0.189 F25
G1 X75.343 Y155.042 Z0.186 F25
G1 X75.248 Y155.084 Z0.182 F25
G1 X75.15 Y155.118 Z0.178 F25
G1 X75.051 Y155.144 Z0.175 F25
G1 X74.949 Y155.164 Z0.171 F25
G1 X74.846 Y155.175 Z0.167 F25
G1 X74.743 Y155.179 Z0.163 F25
G1 X74.64 Y155.175 Z0.16 F25
G1 X74.537 Y155.164 Z0.156 F25
G1 X74.436 Y155.145 Z0.152 F25
G1 X74.336 Y155.118 Z0.149 F25
G1 X74.238 Y155.084 Z0.145 F25
G1 X74.144 Y155.043 Z0.141 F25
G1 X74.052 Y154.995 Z0.137 F25
G1 X73.964 Y154.941 Z0.134 F25
G1 X73.881 Y154.88 Z0.13 F25
G1 X73.803 Y154.813 Z0.126 F25
G1 X73.73 Y154.74 Z0.123 F25
G1 X73.662 Y154.662 Z0.119 F25
G1 X73.6 Y154.579 Z0.115 F25
G1 X73.545 Y154.492 Z0.111 F25
G1 X73.496 Y154.401 Z0.108 F25
G1 X73.455 Y154.307 Z0.104 F25
G1 X73.42 Y154.209 Z0.1 F25
G1 X73.393 Y154.11 Z0.097 F25
G1 X73.373 Y154.009 Z0.093 F25
G1 X73.361 Y153.906 Z0.089 F25
G1 X73.356 Y153.803 Z0.085 F25
G1 X73.36 Y153.7 Z0.082 F25
G1 X73.37 Y153.597 Z0.078 F25
G1 X73.389 Y153.496 Z0.074 F25
G1 X73.415 Y153.396 Z0.071 F25
G1 X73.448 Y153.298 Z0.067 F25
G1 X73.489 Y153.203 Z0.063 F25
G1 X73.536 Y153.112 Z0.059 F25
G1 X73.59 Y153.024 Z0.056 F25
G1 X73.651 Y152.94 Z0.052 F25
G1 X73.718 Y152.862 Z0.048 F25
G1 X73.79 Y152.788 Z0.045 F25
G1 X73.867 Y152.72 Z0.041 F25
G1 X73.95 Y152.658 Z0.037 F25
G1 X74.037 Y152.602 Z0.033 F25
G1 X74.127 Y152.553 Z0.03 F25
G1 X74.221 Y152.511 Z0.026 F25
G1 X74.318 Y152.476 Z0.022 F25
G1 X74.417 Y152.448 Z0.019 F25
G1 X74.518 Y152.428 Z0.015 F25
G1 X74.621 Y152.415 Z0.011 F25
G1 X74.724 Y152.41 Z0.007 F25
G1 X74.827 Y152.412 Z0.004 F25
G1 X74.929 Y152.423 Z0 F25
G1 X75.031 Y152.441 Z-0.004 F25
G1 X75.131 Y152.466 Z-0.007 F25
G1 X75.228 Y152.499 Z-0.011 F25
G1 X75.323 Y152.539 Z-0.015 F25
G1 X75.415 Y152.586 Z-0.019 F25
G1 X75.503 Y152.639 Z-0.022 F25
G1 X75.587 Y152.699 Z-0.026 F25
G1 X75.666 Y152.765 Z-0.03 F25
G1 X75.74 Y152.837 Z-0.033 F25
G1 X75.808 Y152.914 Z-0.037 F25
G1 X75.871 Y152.996 Z-0.041 F25
G1 X75.927 Y153.083 Z-0.045 F25
G1 X75.976 Y153.173 Z-0.048 F25
G1 X76.019 Y153.267 Z-0.052 F25
G1 X76.055 Y153.363 Z-0.056 F25
G1 X76.083 Y153.462 Z-0.059 F25
G1 X76.104 Y153.563 Z-0.063 F25
G1 X76.117 Y153.666 Z-0.067 F25
G1 X76.123 Y153.768 Z-0.071 F25
G1 X76.121 Y153.871 Z-0.074 F25
G1 X76.111 Y153.974 Z-0.078 F25
G1 X76.094 Y154.075 Z-0.082 F25
G1 X76.069 Y154.175 Z-0.085 F25
G1 X76.037 Y154.273 Z-0.089 F25
G1 X75.998 Y154.368 Z-0.093 F25
G1 X75.951 Y154.46 Z-0.097 F25
G1 X75.898 Y154.548 Z-0.1 F25
G1 X75.839 Y154.632 Z-0.104 F25
G1 X75.773 Y154.711 Z-0.108 F25
G1 X75.702 Y154.786 Z-0.111 F25
G1 X75.625 Y154.854 Z-0.115 F25
G1 X75.544 Y154.917 Z-0.119 F25
G1 X75.458 Y154.974 Z-0.123 F25
G1 X75.368 Y155.024 Z-0.126 F25
G1 X75.274 Y155.067 Z-0.13 F25
G1 X75.178 Y155.103 Z-0.134 F25
G1 X75.079 Y155.132 Z-0.137 F25
G1 X74.978 Y155.153 Z-0.141 F25
G1 X74.876 Y155.167 Z-0.145 F25
G1 X74.774 Y155.173 Z-0.149 F25
G1 X74.671 Y155.172 Z-0.152 F25
G1 X74.568 Y155.163 Z-0.156 F25
G1 X74.467 Y155.146 Z-0.16 F25
G1 X74.367 Y155.122 Z-0.163 F25
G1 X74.269 Y155.09 Z-0.167 F25
G1 X74.174 Y155.051 Z-0.171 F25
G1 X74.082 Y155.006 Z-0.175 F25
G1 X73.993 Y154.953 Z-0.178 F25
G1 X73.909 Y154.894 Z-0.182 F25
G1 X73.829 Y154.829 Z-0.186 F25
G1 X73.755 Y154.758 Z-0.189 F25
G1 X73.686 Y154.682 Z-0.193 F25
G1 X73.623 Y154.601 Z-0.197 F25
G1 X73.566 Y154.516 Z-0.201 F25
G1 X73.515 Y154.426 Z-0.204 F25
G1 X73.471 Y154.333 Z-0.208 F25
G1 X73.435 Y154.237 Z-0.212 F25
G1 X73.406 Y154.138 Z-0.215 F25
G1 X73.384 Y154.038 Z-0.219 F25
G1 X73.369 Y153.936 Z-0.223 F25
G1 X73.362 Y153.834 Z-0.227 F25
G1 X73.363 Y153.731 Z-0.23 F25
G1 X73.372 Y153.628 Z-0.234 F25
G1 X73.388 Y153.527 Z-0.238 F25
G1 X73.412 Y153.427 Z-0.241 F25
G1 X73.443 Y153.329 Z-0.245 F25
G1 X73.481 Y153.233 Z-0.249 F25
G1 X73.526 Y153.141 Z-0.253 F25
G1 X73.578 Y153.052 Z-0.256 F25
G1 X73.637 Y152.968 Z-0.26 F25
G1 X73.701 Y152.888 Z-0.264 F25
G1 X73.772 Y152.813 Z-0.267 F25
G1 X73.847 Y152.744 Z-0.271 F25
G1 X73.928 Y152.68 Z-0.275 F25
G1 X74.013 Y152.623 Z-0.279 F25
G1 X74.102 Y152.572 Z-0.282 F25
G1 X74.195 Y152.528 Z-0.286 F25
G1 X74.291 Y152.491 Z-0.29 F25
G1 X74.389 Y152.461 Z-0.293 F25
G1 X74.489 Y152.438 Z-0.297 F25
G1 X74.591 Y152.423 Z-0.301 F25
G1 X74.693 Y152.416 Z-0.305 F25
G1 X74.796 Z-0.308 F25
G1 X74.898 Y152.424 Z-0.312 F25
G1 X75 Y152.44 Z-0.316 F25
G1 X75.1 Y152.463 Z-0.319 F25
G1 X75.198 Y152.493 Z-0.323 F25
G1 X75.293 Y152.531 Z-0.327 F25
G1 X75.386 Y152.576 Z-0.33 F25
G1 X75.474 Y152.627 Z-0.334 F25
G1 X75.559 Y152.685 Z-0.338 F25
G1 X75.639 Y152.749 Z-0.342 F25
G1 X75.715 Y152.819 Z-0.345 F25
G1 X75.784 Y152.894 Z-0.349 F25
G1 X75.848 Y152.975 Z-0.353 F25
G1 X75.906 Y153.059 Z-0.356 F25
G1 X75.958 Y153.148 Z-0.36 F25
G1 X76.002 Y153.241 Z-0.364 F25
G1 X76.04 Y153.336 Z-0.368 F25
G1 X76.07 Y153.434 Z-0.371 F25
G1 X76.093 Y153.534 Z-0.375 F25
G1 X76.109 Y153.636 Z-0.379 F25
G1 X76.117 Y153.738 Z-0.382 F25
G1 Y153.84 Z-0.386 F25
G1 X76.109 Y153.943 Z-0.39 F25
G1 X76.094 Y154.044 Z-0.394 F25
G1 X76.072 Y154.144 Z-0.397 F25
G1 X76.042 Y154.242 Z-0.401 F25
G1 X76.005 Y154.338 Z-0.405 F25
G1 X75.961 Y154.43 Z-0.408 F25
G1 X75.91 Y154.519 Z-0.412 F25
G1 X75.853 Y154.604 Z-0.416 F25
G1 X75.789 Y154.685 Z-0.42 F25
G1 X75.72 Y154.76 Z-0.423 F25
G1 X75.645 Y154.83 Z-0.427 F25
G1 X75.565 Y154.895 Z-0.431 F25
G1 X75.481 Y154.953 Z-0.434 F25
G1 X75.392 Y155.005 Z-0.438 F25
G1 X75.3 Y155.05 Z-0.442 F25
G1 X75.205 Y155.088 Z-0.446 F25
G1 X75.107 Y155.119 Z-0.449 F25
G1 X75.007 Y155.142 Z-0.453 F25
G1 X74.906 Y155.158 Z-0.457 F25
G1 X74.804 Y155.167 Z-0.46 F25
G1 X74.701 Y155.168 Z-0.464 F25
G1 X74.599 Y155.161 Z-0.468 F25
G1 X74.498 Y155.146 Z-0.472 F25
G1 X74.398 Y155.125 Z-0.475 F25
G1 X74.3 Y155.095 Z-0.479 F25
G1 X74.204 Y155.059 Z-0.483 F25
G1 X74.111 Y155.015 Z-0.486 F25
G1 X74.022 Y154.965 Z-0.49 F25
G1 X73.937 Y154.908 Z-0.494 F25
G1 X73.856 Y154.845 Z-0.498 F25
G1 X73.78 Y154.776 Z-0.501 F25
G1 X73.71 Y154.702 Z-0.505 F25
G1 X73.645 Y154.622 Z-0.509 F25
G1 X73.586 Y154.539 Z-0.512 F25
G1 X73.534 Y154.45 Z-0.516 F25
G1 X73.489 Y154.359 Z-0.52 F25
G1 X73.45 Y154.264 Z-0.524 F25
G1 X73.419 Y154.166 Z-0.527 F25
G1 X73.395 Y154.067 Z-0.531 F25
G1 X73.378 Y153.966 Z-0.535 F25
G1 X73.369 Y153.864 Z-0.538 F25
G1 X73.368 Y153.761 Z-0.542 F25
G1 X73.374 Y153.659 Z-0.546 F25
G1 X73.388 Y153.558 Z-0.55 F25
G1 X73.409 Y153.458 Z-0.553 F25
G1 X73.438 Y153.359 Z-0.557 F25
G1 X73.474 Y153.263 Z-0.561 F25
G1 X73.517 Y153.171 Z-0.564 F25
G1 X73.567 Y153.081 Z-0.568 F25
G1 X73.623 Y152.996 Z-0.572 F25
G1 X73.686 Y152.915 Z-0.576 F25
G1 X73.754 Y152.839 Z-0.579 F25
G1 X73.828 Y152.768 Z-0.583 F25
G1 X73.907 Y152.703 Z-0.587 F25
G1 X73.99 Y152.644 Z-0.59 F25
G1 X74.078 Y152.591 Z-0.594 F25
G1 X74.169 Y152.545 Z-0.598 F25
G1 X74.264 Y152.506 Z-0.602 F25
G1 X74.361 Y152.474 Z-0.605 F25
G1 X74.46 Y152.45 Z-0.609 F25
G1 X74.561 Y152.432 Z-0.613 F25
G1 X74.663 Y152.423 Z-0.616 F25
G1 X74.765 Y152.421 Z-0.62 F25
G1 X74.867 Y152.427 Z-0.624 F25
G1 X74.969 Y152.44 Z-0.628 F25
G1 X75.069 Y152.461 Z-0.631 F25
G1 X75.167 Y152.489 Z-0.635 F25
G1 X75.263 Y152.524 Z-0.639 F25
G1 X75.356 Y152.567 Z-0.642 F25
G1 X75.446 Y152.616 Z-0.646 F25
G1 X75.531 Y152.672 Z-0.65 F25
G1 X75.613 Y152.734 Z-0.654 F25
G1 X75.689 Y152.802 Z-0.657 F25
G1 X75.76 Y152.875 Z-0.661 F25
G1 X75.826 Y152.954 Z-0.665 F25
G1 X75.885 Y153.037 Z-0.668 F25
G1 X75.938 Y153.124 Z-0.672 F25
G1 X75.985 Y153.215 Z-0.676 F25
G1 X76.024 Y153.309 Z-0.68 F25
G1 X76.057 Y153.406 Z-0.683 F25
G1 X76.082 Y153.505 Z-0.687 F25
G1 X76.099 Y153.606 Z-0.691 F25
G1 X76.11 Y153.707 Z-0.694 F25
G1 X76.112 Y153.81 Z-0.698 F25
G1 X76.107 Y153.912 Z-0.702 F25
G1 X76.094 Y154.013 Z-0.706 F25
G1 X76.074 Y154.113 Z-0.709 F25
G1 X76.047 Y154.211 Z-0.713 F25
G1 X76.012 Y154.307 Z-0.717 F25
G1 X75.97 Y154.401 Z-0.72 F25
G1 X75.921 Y154.49 Z-0.724 F25
G1 X75.866 Y154.576 Z-0.728 F25
G1 X75.804 Y154.658 Z-0.732 F25
G1 X75.737 Y154.735 Z-0.735 F25
G1 X75.664 Y154.806 Z-0.739 F25
G1 X75.586 Y154.872 Z-0.743 F25
G1 X75.503 Y154.932 Z-0.746 F25
G1 X75.416 Y154.985 Z-0.75 F25
G1 X75.325 Y155.032 Z-0.754 F25
G1 X75.232 Y155.072 Z-0.758 F25
G1 X75.135 Y155.105 Z-0.761 F25
G1 X75.036 Y155.131 Z-0.765 F25
G1 X74.935 Y155.149 Z-0.769 F25
G1 X74.834 Y155.16 Z-0.772 F25
G1 X74.732 Y155.163 Z-0.776 F25
G1 X74.63 Y155.158 Z-0.78 F25
G1 X74.529 Y155.146 Z-0.784 F25
G1 X74.429 Y155.127 Z-0.787 F25
G1 X74.33 Y155.1 Z-0.791 F25
G1 X74.234 Y155.065 Z-0.795 F25
G1 X74.141 Y155.024 Z-0.798 F25
G1 X74.051 Y154.976 Z-0.802 F25
G1 X73.965 Y154.921 Z-0.806 F25
G1 X73.883 Y154.86 Z-0.81 F25
G1 X73.806 Y154.793 Z-0.813 F25
G1 X73.734 Y154.721 Z-0.817 F25
G1 X73.668 Y154.643 Z-0.821 F25
G1 X73.608 Y154.561 Z-0.824 F25
G1 X73.554 Y154.474 Z-0.828 F25
G1 X73.507 Y154.384 Z-0.832 F25
G1 X73.466 Y154.29 Z-0.836 F25
G1 X73.433 Y154.194 Z-0.839 F25
G1 X73.406 Y154.095 Z-0.843 F25
G1 X73.388 Y153.995 Z-0.847 F25
G1 X73.376 Y153.894 Z-0.85 F25
G1 X73.373 Y153.792 Z-0.854 F25
G1 X73.377 Y153.69 Z-0.858 F25
G1 X73.388 Y153.589 Z-0.862 F25
G1 X73.407 Y153.488 Z-0.865 F25
G1 X73.434 Y153.39 Z-0.869 F25
G1 X73.468 Y153.294 Z-0.873 F25
G1 X73.508 Y153.2 Z-0.876 F25
G1 X73.556 Y153.11 Z-0.88 F25
G1 X73.61 Y153.024 Z-0.884 F25
G1 X73.67 Y152.942 Z-0.888 F25
G1 X73.737 Y152.865 Z-0.891 F25
G1 X73.809 Y152.792 Z-0.895 F25
G1 X73.886 Y152.726 Z-0.899 F25
G1 X73.968 Y152.665 Z-0.902 F25
G1 X74.054 Y152.611 Z-0.906 F25
G1 X74.144 Y152.563 Z-0.91 F25
G1 X74.237 Y152.522 Z-0.914 F25
G1 X74.333 Y152.488 Z-0.917 F25
G1 X74.432 Y152.461 Z-0.921 F25
G1 X74.532 Y152.442 Z-0.925 F25
G1 X74.633 Y152.43 Z-0.928 F25
G1 X74.735 Y152.426 Z-0.932 F25
G1 X74.836 Y152.43 Z-0.936 F25
G1 X74.938 Y152.441 Z-0.94 F25
G1 X75.038 Y152.459 Z-0.943 F25
G1 X75.136 Y152.485 Z-0.947 F25
G1 X75.233 Y152.518 Z-0.951 F25
G1 X75.326 Y152.558 Z-0.954 F25
G1 X75.417 Y152.605 Z-0.958 F25
G1 X75.503 Y152.659 Z-0.962 F25
G1 X75.586 Y152.719 Z-0.965 F25
G1 X75.663 Y152.785 Z-0.969 F25
G1 X75.736 Y152.856 Z-0.973 F25
G1 X75.803 Y152.933 Z-0.977 F25
G1 X75.864 Y153.015 Z-0.98 F25
G1 X75.919 Y153.1 Z-0.984 F25
G1 X75.967 Y153.19 Z-0.988 F25
G1 X76.008 Y153.283 Z-0.991 F25
G1 X76.043 Y153.379 Z-0.995 F25
G1 X76.07 Y153.477 Z-0.999 F25
G1 X76.09 Y153.576 Z-1.003 F25
G1 X76.102 Y153.677 Z-1.006 F25
G1 X76.107 Y153.779 Z-1.01 F25
G1 X76.104 Y153.881 Z-1.014 F25
G1 X76.093 Y153.982 Z-1.017 F25
G1 X76.076 Y154.082 Z-1.021 F25
G1 X76.05 Y154.181 Z-1.025 F25
G1 X76.018 Y154.277 Z-1.029 F25
G1 X75.978 Y154.371 Z-1.032 F25
G1 X75.932 Y154.461 Z-1.036 F25
G1 X75.878 Y154.548 Z-1.04 F25
G1 X75.819 Y154.631 Z-1.043 F25
G1 X75.753 Y154.709 Z-1.047 F25
G1 X75.682 Y154.781 Z-1.051 F25
G1 X75.606 Y154.849 Z-1.055 F25
G1 X75.525 Y154.91 Z-1.058 F25
G1 X75.44 Y154.965 Z-1.062 F25
G1 X75.35 Y155.014 Z-1.066 F25
G1 X75.258 Y155.056 Z-1.069 F25
G1 X75.162 Y155.091 Z-1.073 F25
G1 X75.064 Y155.119 Z-1.077 F25
G1 X74.965 Y155.139 Z-1.081 F25
G1 X74.864 Y155.152 Z-1.084 F25
G1 X74.763 Y155.157 Z-1.088 F25
G1 X74.661 Y155.155 Z-1.092 F25
G1 X74.56 Y155.145 Z-1.095 F25
G1 X74.46 Y155.128 Z-1.099 F25
G1 X74.361 Y155.103 Z-1.103 F25
G1 X74.265 Y155.071 Z-1.107 F25
G1 X74.171 Y155.032 Z-1.11 F25
G1 X74.08 Y154.986 Z-1.114 F25
G1 X73.993 Y154.934 Z-1.118 F25
G1 X73.91 Y154.875 Z-1.121 F25
G1 X73.832 Y154.81 Z-1.125 F25
G1 X73.759 Y154.739 Z-1.129 F25
G1 X73.691 Y154.663 Z-1.133 F25
G1 X73.63 Y154.583 Z-1.136 F25
G1 X73.574 Y154.498 Z-1.14 F25
G1 X73.525 Y154.409 Z-1.144 F25
G1 X73.482 Y154.316 Z-1.147 F25
G1 X73.447 Y154.221 Z-1.151 F25
G1 X73.419 Y154.124 Z-1.155 F25
G1 X73.398 Y154.024 Z-1.159 F25
G1 X73.384 Y153.923 Z-1.162 F25
G1 X73.379 Y153.822 Z-1.166 F25
G1 X73.38 Y153.72 Z-1.17 F25
G1 X73.389 Y153.619 Z-1.173 F25
G1 X73.406 Y153.519 Z-1.177 F25
G1 X73.43 Y153.421 Z-1.181 F25
G1 X73.462 Y153.324 Z-1.185 F25
G1 X73.5 Y153.23 Z-1.188 F25
G1 X73.546 Y153.139 Z-1.192 F25
G1 X73.598 Y153.052 Z-1.196 F25
G1 X73.656 Y152.969 Z-1.199 F25
G1 X73.721 Y152.891 Z-1.203 F25
G1 X73.791 Y152.817 Z-1.207 F25
G1 X73.866 Y152.749 Z-1.211 F25
G1 X73.946 Y152.687 Z-1.214 F25
G1 X74.031 Y152.631 Z-1.218 F25
G1 X74.119 Y152.581 Z-1.222 F25
G1 X74.211 Y152.539 Z-1.225 F25
G1 X74.306 Y152.503 Z-1.229 F25
G1 X74.404 Y152.474 Z-1.233 F25
G1 X74.503 Y152.453 Z-1.237 F25
G1 X74.603 Y152.439 Z-1.24 F25
G1 X74.705 Y152.432 Z-1.244 F25
G1 X74.806 Y152.433 Z-1.248 F25
G1 X74.907 Y152.442 Z-1.251 F25
G1 X75.007 Y152.458 Z-1.255 F25
G1 X75.106 Y152.482 Z-1.259 F25
G1 X75.203 Y152.513 Z-1.263 F25
G1 X75.297 Y152.551 Z-1.266 F25
G1 X75.388 Y152.596 Z-1.27 F25
G1 X75.475 Y152.647 Z-1.274 F25
G1 X75.558 Y152.705 Z-1.277 F25
G1 X75.637 Y152.769 Z-1.281 F25
G1 X75.711 Y152.838 Z-1.285 F25
G1 X75.779 Y152.913 Z-1.289 F25
G1 X75.842 Y152.993 Z-1.292 F25
G1 X75.898 Y153.077 Z-1.296 F25
G1 X75.948 Y153.165 Z-1.3 F25
G1 X75.992 Y153.257 Z-1.303 F25
G1 X76.028 Y153.351 Z-1.307 F25
G1 X76.057 Y153.449 Z-1.311 F25
G1 X76.079 Y153.548 Z-1.315 F25
G1 X76.094 Y153.648 Z-1.318 F25
G1 X76.101 Y153.749 Z-1.322 F25
G1 X76.1 Y153.85 Z-1.326 F25
G1 X76.092 Y153.951 Z-1.329 F25
G1 X76.076 Y154.051 Z-1.333 F25
G1 X76.053 Y154.15 Z-1.337 F25
G1 X76.023 Y154.247 Z-1.341 F25
G1 X75.986 Y154.341 Z-1.344 F25
G1 X75.941 Y154.432 Z-1.348 F25
G1 X75.89 Y154.52 Z-1.352 F25
G1 X75.833 Y154.603 Z-1.355 F25
G1 X75.769 Y154.682 Z-1.359 F25
G1 X75.7 Y154.757 Z-1.363 F25
G1 X75.626 Y154.825 Z-1.367 F25
G1 X75.546 Y154.888 Z-1.37 F25
G1 X75.463 Y154.945 Z-1.374 F25
G1 X75.375 Y154.996 Z-1.378 F25
G1 X75.284 Y155.039 Z-1.381 F25
G1 X75.189 Y155.076 Z-1.385 F25
G1 X75.092 Y155.106 Z-1.389 F25
G1 X74.994 Y155.128 Z-1.393 F25
G1 X74.894 Y155.143 Z-1.396 F25
G1 X74.793 Y155.151 Z-1.4 F25
G1 X74.691 Z-1.404 F25
G1 X74.591 Y155.143 Z-1.407 F25
G1 X74.49 Y155.128 Z-1.411 F25
G1 X74.392 Y155.106 Z-1.415 F25
G1 X74.295 Y155.076 Z-1.419 F25
G1 X74.201 Y155.039 Z-1.422 F25
G1 X74.109 Y154.996 Z-1.426 F25
G1 X74.022 Y154.945 Z-1.43 F25
G1 X73.938 Y154.888 Z-1.433 F25
G1 X73.859 Y154.825 Z-1.437 F25
G1 X73.784 Y154.757 Z-1.441 F25
G1 X73.715 Y154.683 Z-1.445 F25
G1 X73.652 Y154.604 Z-1.448 F25
G1 X73.594 Y154.52 Z-1.452 F25
G1 X73.543 Y154.433 Z-1.456 F25
G1 X73.499 Y154.342 Z-1.459 F25
G1 X73.462 Y154.248 Z-1.463 F25
G1 X73.432 Y154.151 Z-1.467 F25
G1 X73.409 Y154.053 Z-1.471 F25
G1 X73.393 Y153.953 Z-1.474 F25
G1 X73.385 Y153.852 Z-1.478 F25
G1 X73.384 Y153.751 Z-1.482 F25
G1 X73.391 Y153.65 Z-1.485 F25
G1 X73.406 Y153.55 Z-1.489 F25
G1 X73.428 Y153.451 Z-1.493 F25
G1 X73.457 Y153.354 Z-1.497 F25
G1 X73.493 Y153.26 Z-1.5 F25
G1 X73.536 Y153.169 Z-1.504 F25
G1 X73.586 Y153.081 Z-1.508 F25
G1 X73.642 Y152.997 Z-1.511 F25
G1 X73.705 Y152.917 Z-1.515 F25
G1 X73.773 Y152.843 Z-1.519 F25
G1 X73.847 Y152.773 Z-1.523 F25
G1 X73.925 Y152.709 Z-1.526 F25
G1 X74.008 Y152.652 Z-1.53 F25
G1 X74.095 Y152.6 Z-1.534 F25
G1 X74.186 Y152.556 Z-1.537 F25
G1 X74.28 Y152.518 Z-1.541 F25
G1 X74.376 Y152.487 Z-1.545 F25
G1 X74.474 Y152.464 Z-1.549 F25
G1 X74.574 Y152.447 Z-1.552 F25
G1 X74.675 Y152.439 Z-1.556 F25
G1 X74.776 Y152.438 Z-1.56 F25
G1 X74.877 Y152.444 Z-1.563 F25
G1 X74.977 Y152.458 Z-1.567 F25
G1 X75.076 Y152.479 Z-1.571 F25
G1 X75.173 Y152.508 Z-1.575 F25
G1 X75.267 Y152.544 Z-1.578 F25
G1 X75.358 Y152.586 Z-1.582 F25
G1 X75.447 Y152.636 Z-1.586 F25
G1 X75.531 Y152.691 Z-1.589 F25
G1 X75.611 Y152.753 Z-1.593 F25
G1 X75.685 Y152.821 Z-1.597 F25
G1 X75.755 Y152.894 Z-1.6 F25
G1 X75.819 Y152.972 Z-1.604 F25
G1 X75.877 Y153.055 Z-1.608 F25
G1 X75.929 Y153.141 Z-1.612 F25
G1 X75.974 Y153.231 Z-1.615 F25
G1 X76.013 Y153.325 Z-1.619 F25
G1 X76.044 Y153.421 Z-1.623 F25
G1 X76.068 Y153.519 Z-1.626 F25
G1 X76.085 Y153.619 Z-1.63 F25
G1 X76.094 Y153.719 Z-1.634 F25
G1 X76.095 Y153.82 Z-1.638 F25
G1 X76.09 Y153.921 Z-1.641 F25
G1 X76.076 Y154.021 Z-1.645 F25
G1 X76.056 Y154.12 Z-1.649 F25
G1 X76.027 Y154.217 Z-1.652 F25
G1 X75.992 Y154.311 Z-1.656 F25
G1 X75.95 Y154.403 Z-1.66 F25
G1 X75.901 Y154.492 Z-1.664 F25
G1 X75.846 Y154.576 Z-1.667 F25
G1 X75.785 Y154.656 Z-1.671 F25
G1 X75.717 Y154.731 Z-1.675 F25
G1 X75.645 Y154.801 Z-1.678 F25
G1 X75.567 Y154.866 Z-1.682 F25
G1 X75.485 Y154.924 Z-1.686 F25
G1 X75.399 Y154.976 Z-1.69 F25
G1 X75.309 Y155.022 Z-1.693 F25
G1 X75.216 Y155.061 Z-1.697 F25
G1 X75.12 Y155.093 Z-1.701 F25
G1 X75.022 Y155.117 Z-1.704 F25
G1 X74.923 Y155.134 Z-1.708 F25
G1 X74.823 Y155.144 Z-1.712 F25
G1 X74.722 Y155.146 Z-1.716 F25
G1 X74.621 Y155.141 Z-1.719 F25
G1 X74.521 Y155.128 Z-1.723 F25
G1 X74.422 Y155.108 Z-1.727 F25
G1 X74.325 Y155.081 Z-1.73 F25
G1 X74.231 Y155.046 Z-1.734 F25
G1 X74.139 Y155.004 Z-1.738 F25
G1 X74.05 Y154.956 Z-1.742 F25
G1 X73.965 Y154.901 Z-1.745 F25
G1 X73.885 Y154.84 Z-1.749 F25
G1 X73.809 Y154.774 Z-1.753 F25
G1 X73.739 Y154.702 Z-1.756 F25
G1 X73.674 Y154.624 Z-1.76 F25
G1 X73.615 Y154.543 Z-1.764 F25
G1 X73.563 Y154.457 Z-1.768 F25
G1 X73.517 Y154.367 Z-1.771 F25
G1 X73.477 Y154.274 Z-1.775 F25
G1 X73.445 Y154.179 Z-1.779 F25
G1 X73.42 Y154.081 Z-1.782 F25
G1 X73.402 Y153.982 Z-1.786 F25
G1 X73.392 Y153.882 Z-1.79 F25
G1 X73.389 Y153.781 Z-1.794 F25
G1 X73.394 Y153.681 Z-1.797 F25
G1 X73.406 Y153.581 Z-1.801 F25
G1 X73.426 Y153.482 Z-1.805 F25
G1 X73.453 Y153.385 Z-1.808 F25
G1 X73.487 Y153.29 Z-1.812 F25
G1 X73.528 Y153.198 Z-1.816 F25
G1 X73.575 Y153.109 Z-1.82 F25
G1 X73.63 Y153.025 Z-1.823 F25
G1 X73.69 Y152.944 Z-1.827 F25
G1 X73.756 Y152.868 Z-1.831 F25
G1 X73.828 Y152.797 Z-1.834 F25
G1 X73.905 Y152.732 Z-1.838 F25
G1 X73.986 Y152.673 Z-1.842 F25
G1 X74.072 Y152.62 Z-1.846 F25
G1 X74.161 Y152.573 Z-1.849 F25
G1 X74.253 Y152.533 Z-1.853 F25
G1 X74.349 Y152.501 Z-1.857 F25
G1 X74.446 Y152.475 Z-1.86 F25
G1 X74.545 Y152.457 Z-1.864 F25
G1 X74.645 Y152.446 Z-1.868 F25
G1 X74.746 Y152.443 Z-1.872 F25
G1 X74.846 Y152.447 Z-1.875 F25
G1 X74.946 Y152.458 Z-1.879 F25
G1 X75.045 Y152.477 Z-1.883 F25
G1 X75.142 Y152.504 Z-1.886 F25
G1 X75.237 Y152.537 Z-1.89 F25
G1 X75.329 Y152.578 Z-1.894 F25
G1 X75.418 Y152.625 Z-1.898 F25
G1 X75.503 Y152.678 Z-1.901 F25
G1 X75.584 Y152.738 Z-1.905 F25
G1 X75.66 Y152.804 Z-1.909 F25
G1 X75.731 Y152.875 Z-1.912 F25
G1 X75.796 Y152.952 Z-1.916 F25
G1 X75.856 Y153.033 Z-1.92 F25
G1 X75.91 Y153.118 Z-1.924 F25
G1 X75.957 Y153.207 Z-1.927 F25
G1 X75.997 Y153.299 Z-1.931 F25
G1 X76.03 Y153.394 Z-1.935 F25
G1 X76.056 Y153.491 Z-1.938 F25
G1 X76.075 Y153.59 Z-1.942 F25
G1 X76.086 Y153.69 Z-1.946 F25
G1 X76.09 Y153.79 Z-1.95 F25
G1 X76.087 Y153.891 Z-1.953 F25
G1 X76.076 Y153.991 Z-1.957 F25
G1 X76.057 Y154.089 Z-1.961 F25
G1 X76.031 Y154.187 Z-1.964 F25
G1 X75.998 Y154.282 Z-1.968 F25
G1 X75.958 Y154.374 Z-1.972 F25
G1 X75.912 Y154.463 Z-1.976 F25
G1 X75.859 Y154.548 Z-1.979 F25
G1 X75.799 Y154.629 Z-1.983 F25
G1 X75.734 Y154.706 Z-1.987 F25
G1 X75.663 Y154.777 Z-1.99 F25
G1 X75.588 Y154.843 Z-1.994 F25
G1 X75.507 Y154.903 Z-1.998 F25
G1 X75.422 Y154.957 Z-2.002 F25
G1 X75.334 Y155.004 Z-2.005 F25
G1 X75.242 Y155.045 Z-2.009 F25
G1 X75.147 Y155.079 Z-2.013 F25
G1 X75.05 Y155.105 Z-2.016 F25
G1 X74.952 Y155.125 Z-2.02 F25
G1 X74.852 Y155.136 Z-2.024 F25
G1 X74.752 Y155.141 Z-2.028 F25
G1 X74.651 Y155.138 Z-2.031 F25
G1 X74.551 Y155.127 Z-2.035 F25
G1 X74.453 Y155.11 Z-2.039 F25
G1 X74.355 Y155.084 Z-2.042 F25
G1 X74.26 Y155.052 Z-2.046 F25
G1 X74.168 Y155.013 Z-2.05 F25
G1 X74.079 Y154.966 Z-2.054 F25
G1 X73.993 Y154.914 Z-2.057 F25
G1 X73.912 Y154.855 Z-2.061 F25
G1 X73.835 Y154.79 Z-2.065 F25
G1 X73.763 Y154.72 Z-2.068 F25
G1 X73.697 Y154.644 Z-2.072 F25
G1 X73.637 Y154.564 Z-2.076 F25
G1 X73.582 Y154.48 Z-2.08 F25
G1 X73.534 Y154.392 Z-2.083 F25
G1 X73.493 Y154.3 Z-2.087 F25
G1 X73.459 Y154.206 Z-2.091 F25
G1 X73.432 Y154.109 Z-2.094 F25
G1 X73.412 Y154.011 Z-2.098 F25
G1 X73.4 Y153.911 Z-2.102 F25
G1 X73.395 Y153.811 Z-2.106 F25
G1 X73.397 Y153.711 Z-2.109 F25
G1 X73.407 Y153.611 Z-2.113 F25
G1 X73.424 Y153.512 Z-2.117 F25
G1 X73.449 Y153.415 Z-2.12 F25
G1 X73.481 Y153.32 Z-2.124 F25
G1 X73.52 Y153.227 Z-2.128 F25
G1 X73.565 Y153.138 Z-2.132 F25
G1 X73.617 Y153.052 Z-2.135 F25
G1 X73.676 Y152.971 Z-2.139 F25
G1 X73.74 Y152.894 Z-2.143 F25
G1 X73.81 Y152.822 Z-2.146 F25
G1 X73.885 Y152.755 Z-2.15 F25
G1 X73.965 Y152.694 Z-2.154 F25
G1 X74.049 Y152.639 Z-2.158 F25
G1 X74.137 Y152.591 Z-2.161 F25
G1 X74.228 Y152.549 Z-2.165 F25
G1 X74.322 Y152.515 Z-2.169 F25
G1 X74.418 Y152.487 Z-2.172 F25
G1 X74.516 Y152.467 Z-2.176 F25
G1 X74.616 Y152.454 Z-2.18 F25
G1 X74.716 Y152.448 Z-2.184 F25
G1 X74.816 Y152.45 Z-2.187 F25
G1 X74.916 Y152.459 Z-2.191 F25
G1 X75.015 Y152.476 Z-2.195 F25
G1 X75.112 Y152.5 Z-2.198 F25
G1 X75.207 Y152.532 Z-2.202 F25
G1 X75.3 Y152.57 Z-2.206 F25
G1 X75.389 Y152.615 Z-2.21 F25
G1 X75.475 Y152.666 Z-2.213 F25
G1 X75.557 Y152.724 Z-2.217 F25
G1 X75.634 Y152.788 Z-2.221 F25
G1 X75.706 Y152.857 Z-2.224 F25
G1 X75.773 Y152.932 Z-2.228 F25
G1 X75.835 Y153.011 Z-2.232 F25
G1 X75.89 Y153.095 Z-2.235 F25
G1 X75.938 Y153.182 Z-2.239 F25
G1 X75.981 Y153.273 Z-2.243 F25
G1 X76.016 Y153.367 Z-2.247 F25
G1 X76.044 Y153.463 Z-2.25 F25
G1 X76.065 Y153.561 Z-2.254 F25
G1 X76.078 Y153.66 Z-2.258 F25
G1 X76.084 Y153.76 Z-2.261 F25
G1 X76.083 Y153.861 Z-2.265 F25
G1 X76.074 Y153.96 Z-2.269 F25
G1 X76.058 Y154.059 Z-2.273 F25
G1 X76.035 Y154.157 Z-2.276 F25
G1 X76.004 Y154.252 Z-2.28 F25
G1 X75.966 Y154.344 Z-2.284 F25
G1 X75.922 Y154.434 Z-2.287 F25
G1 X75.871 Y154.52 Z-2.291 F25
G1 X75.813 Y154.602 Z-2.295 F25
G1 X75.75 Y154.68 Z-2.299 F25
G1 X75.681 Y154.752 Z-2.302 F25
G1 X75.607 Y154.82 Z-2.306 F25
G1 X75.528 Y154.881 Z-2.31 F25
G1 X75.445 Y154.937 Z-2.313 F25
G1 X75.358 Y154.986 Z-2.317 F25
G1 X75.267 Y155.028 Z-2.321 F25
G1 X75.174 Y155.064 Z-2.325 F25
G1 X75.078 Y155.093 Z-2.328 F25
G1 X74.98 Y155.114 Z-2.332 F25
G1 X74.881 Y155.128 Z-2.336 F25
G1 X74.781 Y155.135 Z-2.339 F25
G1 X74.681 Y155.134 Z-2.343 F25
G1 X74.582 Y155.126 Z-2.347 F25
G1 X74.483 Y155.11 Z-2.351 F25
G1 X74.386 Y155.087 Z-2.354 F25
G1 X74.29 Y155.057 Z-2.358 F25
G1 X74.197 Y155.02 Z-2.362 F25
G1 X74.107 Y154.976 Z-2.365 F25
G1 X74.021 Y154.925 Z-2.369 F25
G1 X73.939 Y154.869 Z-2.373 F25
G1 X73.861 Y154.806 Z-2.377 F25
G1 X73.788 Y154.737 Z-2.38 F25
G1 X73.72 Y154.664 Z-2.384 F25
G1 X73.658 Y154.585 Z-2.388 F25
G1 X73.603 Y154.503 Z-2.391 F25
G1 X73.553 Y154.416 Z-2.395 F25
G1 X73.51 Y154.326 Z-2.399 F25
G1 X73.474 Y154.233 Z-2.403 F25
G1 X73.445 Y154.137 Z-2.406 F25
G1 X73.423 Y154.039 Z-2.41 F25
G1 X73.408 Y153.941 Z-2.414 F25
G1 X73.401 Y153.841 Z-2.417 F25
G1 Y153.741 Z-2.421 F25
G1 X73.409 Y153.641 Z-2.425 F25
G1 X73.424 Y153.543 Z-2.429 F25
G1 X73.446 Y153.445 Z-2.432 F25
G1 X73.476 Y153.35 Z-2.436 F25
G1 X73.512 Y153.257 Z-2.44 F25
G1 X73.556 Y153.167 Z-2.443 F25
G1 X73.606 Y153.08 Z-2.447 F25
G1 X73.662 Y152.998 Z-2.451 F25
G1 X73.724 Y152.92 Z-2.455 F25
G1 X73.792 Y152.846 Z-2.458 F25
G1 X73.866 Y152.778 Z-2.462 F25
G1 X73.944 Y152.716 Z-2.466 F25
G1 X74.026 Y152.66 Z-2.469 F25
G1 X74.113 Y152.61 Z-2.473 F25
G1 X74.203 Y152.566 Z-2.477 F25
G1 X74.295 Y152.529 Z-2.481 F25
G1 X74.391 Y152.5 Z-2.484 F25
G1 X74.488 Y152.477 Z-2.488 F25
G1 X74.587 Y152.462 Z-2.492 F25
G1 X74.686 Y152.455 Z-2.495 F25
G1 X74.786 Y152.454 Z-2.499 F25
G1 X74.885 Y152.461 Z-2.503 F25
G1 X74.984 Y152.476 Z-2.507 F25
G1 X75.081 Y152.498 Z-2.51 F25
G1 X75.177 Y152.527 Z-2.514 F25
G1 X75.27 Y152.563 Z-2.518 F25
G1 X75.36 Y152.606 Z-2.521 F25
G1 X75.447 Y152.655 Z-2.525 F25
G1 X75.53 Y152.711 Z-2.529 F25
G1 X75.608 Y152.773 Z-2.533 F25
G1 X75.681 Y152.84 Z-2.536 F25
G1 X75.75 Y152.913 Z-2.54 F25
G1 X75.813 Y152.99 Z-2.544 F25
G1 X75.869 Y153.072 Z-2.547 F25
G1 X75.92 Y153.159 Z-2.551 F25
G1 X75.964 Y153.248 Z-2.555 F25
G1 X76.001 Y153.341 Z-2.559 F25
G1 X76.031 Y153.436 Z-2.562 F25
G1 X76.054 Y153.533 Z-2.566 F25
G1 X76.07 Y153.632 Z-2.57 F25
G1 X76.078 Y153.731 Z-2.573 F25
G1 X76.079 Y153.831 Z-2.577 F25
G1 X76.072 Y153.93 Z-2.581 F25
G1 X76.058 Y154.029 Z-2.585 F25
G1 X76.037 Y154.126 Z-2.588 F25
G1 X76.009 Y154.222 Z-2.592 F25
G1 X75.973 Y154.315 Z-2.596 F25
G1 X75.931 Y154.405 Z-2.599 F25
G1 X75.882 Y154.492 Z-2.603 F25
G1 X75.827 Y154.575 Z-2.607 F25
G1 X75.765 Y154.653 Z-2.611 F25
G1 X75.699 Y154.727 Z-2.614 F25
G1 X75.626 Y154.796 Z-2.618 F25
G1 X75.549 Y154.859 Z-2.622 F25
G1 X75.467 Y154.916 Z-2.625 F25
G1 X75.382 Y154.967 Z-2.629 F25
G1 X75.292 Y155.011 Z-2.633 F25
G1 X75.2 Y155.049 Z-2.637 F25
G1 X75.105 Y155.08 Z-2.64 F25
G1 X75.008 Y155.103 Z-2.644 F25
G1 X74.91 Y155.119 Z-2.648 F25
G1 X74.811 Y155.128 Z-2.651 F25
G1 X74.711 Y155.13 Z-2.655 F25
G1 X74.612 Y155.124 Z-2.659 F25
G1 X74.513 Y155.11 Z-2.663 F25
G1 X74.415 Y155.09 Z-2.666 F25
G1 X74.32 Y155.062 Z-2.67 F25
G1 X74.226 Y155.027 Z-2.674 F25
G1 X74.136 Y154.985 Z-2.677 F25
G1 X74.049 Y154.937 Z-2.681 F25
G1 X73.966 Y154.882 Z-2.685 F25
G1 X73.887 Y154.821 Z-2.689 F25
G1 X73.813 Y154.755 Z-2.692 F25
G1 X73.744 Y154.683 Z-2.696 F25
G1 X73.681 Y154.606 Z-2.7 F25
G1 X73.623 Y154.525 Z-2.703 F25
G1 X73.572 Y154.44 Z-2.707 F25
G1 X73.527 Y154.351 Z-2.711 F25
G1 X73.489 Y154.259 Z-2.715 F25
G1 X73.458 Y154.164 Z-2.718 F25
G1 X73.434 Y154.068 Z-2.722 F25
G1 X73.417 Y153.969 Z-2.726 F25
G1 X73.408 Y153.87 Z-2.729 F25
G1 X73.406 Y153.771 Z-2.733 F25
G1 X73.411 Y153.672 Z-2.737 F25
G1 X73.424 Y153.573 Z-2.741 F25
G1 X73.444 Y153.475 Z-2.744 F25
G1 X73.472 Y153.38 Z-2.748 F25
G1 X73.506 Y153.286 Z-2.752 F25
G1 X73.547 Y153.196 Z-2.755 F25
G1 X73.595 Y153.108 Z-2.759 F25
G1 X73.649 Y153.025 Z-2.763 F25
G1 X73.71 Y152.946 Z-2.767 F25
G1 X73.776 Y152.871 Z-2.77 F25
G1 X73.847 Y152.802 Z-2.774 F25
G1 X73.926 Y152.736 Z-2.778 F25
G1 X74.011 Y152.676 Z-2.782 F25
G1 X74.099 Y152.623 Z-2.786 F25
G1 X74.191 Y152.577 Z-2.789 F25
G1 X74.287 Y152.538 Z-2.793 F25
G1 X74.385 Y152.507 Z-2.797 F25
G1 X74.486 Y152.483 Z-2.801 F25
G1 X74.588 Y152.468 Z-2.805 F25
G1 X74.691 Y152.46 Z-2.809 F25
G1 X74.794 Z-2.813 F25
G1 X74.897 Y152.468 Z-2.816 F25
G1 X74.999 Y152.484 Z-2.82 F25
G1 X75.099 Y152.508 Z-2.824 F25
G1 X75.198 Y152.54 Z-2.828 F25
G1 X75.293 Y152.579 Z-2.832 F25
G1 X75.385 Y152.625 Z-2.836 F25
G1 X75.474 Y152.679 Z-2.84 F25
G1 X75.558 Y152.739 Z-2.843 F25
G1 X75.637 Y152.805 Z-2.847 F25
G1 X75.71 Y152.878 Z-2.851 F25
G1 X75.778 Y152.955 Z-2.855 F25
G1 X75.84 Y153.038 Z-2.859 F25
G1 X75.895 Y153.125 Z-2.863 F25
G1 X75.943 Y153.217 Z-2.866 F25
G1 X75.984 Y153.311 Z-2.87 F25
G1 X76.018 Y153.409 Z-2.874 F25
G1 X76.043 Y153.509 Z-2.878 F25
G1 X76.062 Y153.61 Z-2.882 F25
G1 X76.072 Y153.713 Z-2.886 F25
G1 X76.074 Y153.816 Z-2.89 F25
G1 X76.068 Y153.919 Z-2.893 F25
G1 X76.054 Y154.021 Z-2.897 F25
G1 X76.033 Y154.122 Z-2.901 F25
G1 X76.003 Y154.221 Z-2.905 F25
G1 X75.966 Y154.317 Z-2.909 F25
G1 X75.922 Y154.41 Z-2.913 F25
G1 X75.871 Y154.5 Z-2.917 F25
G1 X75.813 Y154.585 Z-2.92 F25
G1 X75.748 Y154.665 Z-2.924 F25
G1 X75.678 Y154.74 Z-2.928 F25
G1 X75.602 Y154.81 Z-2.932 F25
G1 X75.52 Y154.873 Z-2.936 F25
G1 X75.434 Y154.93 Z-2.94 F25
G1 X75.344 Y154.98 Z-2.944 F25
G1 X75.251 Y155.024 Z-2.947 F25
G1 X75.154 Y155.059 Z-2.951 F25
G1 X75.055 Y155.087 Z-2.955 F25
G1 X74.954 Y155.108 Z-2.959 F25
G1 X74.851 Y155.12 Z-2.963 F25
G1 X74.748 Y155.125 Z-2.967 F25
G1 X74.645 Y155.121 Z-2.971 F25
G1 X74.543 Y155.11 Z-2.974 F25
G1 X74.442 Y155.09 Z-2.978 F25
G1 X74.342 Y155.063 Z-2.982 F25
G1 X74.245 Y155.029 Z-2.986 F25
G1 X74.152 Y154.987 Z-2.99 F25
G1 X74.061 Y154.937 Z-2.994 F25
G1 X73.975 Y154.881 Z-2.998 F25
G1 X73.893 Y154.819 Z-3.001 F25
G1 X73.816 Y154.75 Z-3.005 F25
G1 X73.745 Y154.676 Z-3.009 F25
G1 X73.68 Y154.596 Z-3.013 F25
G1 X73.621 Y154.512 Z-3.017 F25
G1 X73.569 Y154.423 Z-3.021 F25
G1 X73.524 Y154.33 Z-3.025 F25
G1 X73.486 Y154.234 Z-3.028 F25
G1 X73.456 Y154.136 Z-3.032 F25
G1 X73.433 Y154.036 Z-3.036 F25
G1 X73.418 Y153.934 Z-3.04 F25
G1 X73.412 Y153.831 Z-3.044 F25
G1 X73.413 Y153.728 Z-3.048 F25
G1 X73.422 Y153.625 Z-3.052 F25
G1 X73.439 Y153.524 Z-3.055 F25
G1 X73.464 Y153.424 Z-3.059 F25
G1 X73.496 Y153.326 Z-3.063 F25
G1 X73.536 Y153.231 Z-3.067 F25
G1 X73.583 Y153.14 Z-3.071 F25
G1 X73.637 Y153.052 Z-3.075 F25
G1 X73.698 Y152.969 Z-3.079 F25
G1 X73.765 Y152.891 Z-3.082 F25
G1 X73.837 Y152.818 Z-3.086 F25
G1 X73.915 Y152.751 Z-3.09 F25
G1 X73.998 Y152.691 Z-3.094 F25
G1 X74.086 Y152.637 Z-3.098 F25
G1 X74.177 Y152.59 Z-3.102 F25
G1 X74.272 Y152.55 Z-3.106 F25
G1 X74.369 Y152.517 Z-3.109 F25
G1 X74.469 Y152.492 Z-3.113 F25
G1 X74.571 Y152.475 Z-3.117 F25
G1 X74.673 Y152.466 Z-3.121 F25
G1 X74.776 Y152.465 Z-3.125 F25
G1 X74.878 Y152.472 Z-3.129 F25
G1 X74.98 Y152.486 Z-3.133 F25
G1 X75.081 Y152.509 Z-3.136 F25
G1 X75.179 Y152.539 Z-3.14 F25
G1 X75.275 Y152.577 Z-3.144 F25
G1 X75.367 Y152.622 Z-3.148 F25
G1 X75.456 Y152.674 Z-3.152 F25
G1 X75.54 Y152.732 Z-3.156 F25
G1 X75.62 Y152.797 Z-3.16 F25
G1 X75.694 Y152.868 Z-3.163 F25
G1 X75.763 Y152.945 Z-3.167 F25
G1 X75.825 Y153.026 Z-3.171 F25
G1 X75.881 Y153.113 Z-3.175 F25
G1 X75.93 Y153.203 Z-3.179 F25
G1 X75.972 Y153.297 Z-3.183 F25
G1 X76.007 Y153.393 Z-3.187 F25
G1 X76.034 Y153.492 Z-3.19 F25
G1 X76.054 Y153.593 Z-3.194 F25
G1 X76.065 Y153.695 Z-3.198 F25
G1 X76.069 Y153.798 Z-3.202 F25
G1 X76.064 Y153.9 Z-3.206 F25
G1 X76.052 Y154.002 Z-3.21 F25
G1 X76.032 Y154.103 Z-3.214 F25
G1 X76.004 Y154.202 Z-3.217 F25
G1 X75.968 Y154.298 Z-3.221 F25
G1 X75.925 Y154.392 Z-3.225 F25
G1 X75.876 Y154.481 Z-3.229 F25
G1 X75.819 Y154.567 Z-3.233 F25
G1 X75.756 Y154.648 Z-3.237 F25
G1 X75.687 Y154.724 Z-3.241 F25
G1 X75.612 Y154.794 Z-3.244 F25
G1 X75.532 Y154.858 Z-3.248 F25
G1 X75.447 Y154.916 Z-3.252 F25
G1 X75.358 Y154.967 Z-3.256 F25
G1 X75.265 Y155.012 Z-3.26 F25
G1 X75.169 Y155.048 Z-3.264 F25
G1 X75.071 Y155.078 Z-3.268 F25
G1 X74.97 Y155.099 Z-3.271 F25
G1 X74.869 Y155.113 Z-3.275 F25
G1 X74.766 Y155.119 Z-3.279 F25
G1 X74.664 Y155.117 Z-3.283 F25
G1 X74.562 Y155.107 Z-3.287 F25
G1 X74.461 Y155.089 Z-3.291 F25
G1 X74.361 Y155.063 Z-3.295 F25
G1 X74.264 Y155.03 Z-3.298 F25
G1 X74.17 Y154.99 Z-3.302 F25
G1 X74.08 Y154.942 Z-3.306 F25
G1 X73.993 Y154.887 Z-3.31 F25
G1 X73.91 Y154.826 Z-3.314 F25
G1 X73.833 Y154.759 Z-3.318 F25
G1 X73.761 Y154.685 Z-3.322 F25
G1 X73.695 Y154.607 Z-3.325 F25
G1 X73.636 Y154.524 Z-3.329 F25
G1 X73.582 Y154.436 Z-3.333 F25
G1 X73.536 Y154.344 Z-3.337 F25
G1 X73.497 Y154.25 Z-3.341 F25
G1 X73.466 Y154.152 Z-3.345 F25
G1 X73.442 Y154.052 Z-3.349 F25
G1 X73.426 Y153.951 Z-3.352 F25
G1 X73.418 Y153.849 Z-3.356 F25
G1 X73.417 Y153.746 Z-3.36 F25
G1 X73.425 Y153.644 Z-3.364 F25
G1 X73.441 Y153.543 Z-3.368 F25
G1 X73.464 Y153.443 Z-3.372 F25
G1 X73.495 Y153.345 Z-3.376 F25
G1 X73.533 Y153.25 Z-3.379 F25
G1 X73.579 Y153.158 Z-3.383 F25
G1 X73.632 Y153.07 Z-3.387 F25
G1 X73.691 Y152.987 Z-3.391 F25
G1 X73.756 Y152.908 Z-3.395 F25
G1 X73.828 Y152.835 Z-3.399 F25
G1 X73.905 Y152.767 Z-3.403 F25
G1 X73.986 Y152.705 Z-3.406 F25
G1 X74.073 Y152.65 Z-3.41 F25
G1 X74.163 Y152.602 Z-3.414 F25
G1 X74.257 Y152.561 Z-3.418 F25
G1 X74.354 Y152.528 Z-3.422 F25
G1 X74.453 Y152.501 Z-3.426 F25
G1 X74.554 Y152.483 Z-3.43 F25
G1 X74.655 Y152.473 Z-3.433 F25
G1 X74.758 Y152.47 Z-3.437 F25
G1 X74.86 Y152.475 Z-3.441 F25
G1 X74.962 Y152.489 Z-3.445 F25
G1 X75.062 Y152.51 Z-3.449 F25
G1 X75.16 Y152.538 Z-3.453 F25
G1 X75.256 Y152.575 Z-3.457 F25
G1 X75.349 Y152.618 Z-3.46 F25
G1 X75.438 Y152.669 Z-3.464 F25
G1 X75.523 Y152.726 Z-3.468 F25
G1 X75.603 Y152.79 Z-3.472 F25
G1 X75.678 Y152.859 Z-3.476 F25
G1 X75.747 Y152.935 Z-3.48 F25
G1 X75.81 Y153.015 Z-3.484 F25
G1 X75.867 Y153.1 Z-3.487 F25
G1 X75.917 Y153.189 Z-3.491 F25
G1 X75.961 Y153.282 Z-3.495 F25
G1 X75.996 Y153.378 Z-3.499 F25
G1 X76.025 Y153.476 Z-3.503 F25
G1 X76.045 Y153.576 Z-3.507 F25
G1 X76.058 Y153.678 Z-3.51 F25
G1 X76.063 Y153.78 Z-3.514 F25
G1 X76.06 Y153.882 Z-3.518 F25
G1 X76.049 Y153.984 Z-3.522 F25
G1 X76.03 Y154.084 Z-3.526 F25
G1 X76.004 Y154.183 Z-3.53 F25
G1 X75.97 Y154.279 Z-3.534 F25
G1 X75.929 Y154.373 Z-3.537 F25
G1 X75.88 Y154.463 Z-3.541 F25
G1 X75.825 Y154.549 Z-3.545 F25
G1 X75.763 Y154.631 Z-3.549 F25
G1 X75.695 Y154.707 Z-3.553 F25
G1 X75.622 Y154.778 Z-3.557 F25
G1 X75.543 Y154.843 Z-3.561 F25
G1 X75.459 Y154.902 Z-3.564 F25
G1 X75.371 Y154.954 Z-3.568 F25
G1 X75.279 Y154.999 Z-3.572 F25
G1 X75.184 Y155.037 Z-3.576 F25
G1 X75.087 Y155.068 Z-3.58 F25
G1 X74.987 Y155.091 Z-3.584 F25
G1 X74.886 Y155.106 Z-3.588 F25
G1 X74.784 Y155.113 Z-3.591 F25
G1 X74.682 Y155.112 Z-3.595 F25
G1 X74.58 Y155.104 Z-3.599 F25
G1 X74.48 Y155.087 Z-3.603 F25
G1 X74.38 Y155.063 Z-3.607 F25
G1 X74.283 Y155.031 Z-3.611 F25
G1 X74.189 Y154.992 Z-3.615 F25
G1 X74.098 Y154.946 Z-3.618 F25
G1 X74.011 Y154.893 Z-3.622 F25
G1 X73.928 Y154.833 Z-3.626 F25
G1 X73.85 Y154.767 Z-3.63 F25
G1 X73.777 Y154.695 Z-3.634 F25
G1 X73.711 Y154.618 Z-3.638 F25
G1 X73.65 Y154.536 Z-3.642 F25
G1 X73.596 Y154.449 Z-3.645 F25
G1 X73.549 Y154.358 Z-3.649 F25
G1 X73.509 Y154.264 Z-3.653 F25
G1 X73.476 Y154.168 Z-3.657 F25
G1 X73.451 Y154.069 Z-3.661 F25
G1 X73.433 Y153.968 Z-3.665 F25
G1 X73.424 Y153.866 Z-3.669 F25
G1 X73.422 Y153.764 Z-3.672 F25
G1 X73.429 Y153.662 Z-3.676 F25
G1 X73.443 Y153.561 Z-3.68 F25
G1 X73.464 Y153.461 Z-3.684 F25
G1 X73.494 Y153.364 Z-3.688 F25
G1 X73.531 Y153.269 Z-3.692 F25
G1 X73.575 Y153.177 Z-3.696 F25
G1 X73.626 Y153.089 Z-3.699 F25
G1 X73.684 Y153.005 Z-3.703 F25
G1 X73.748 Y152.925 Z-3.707 F25
G1 X73.818 Y152.851 Z-3.711 F25
G1 X73.894 Y152.783 Z-3.715 F25
G1 X73.975 Y152.72 Z-3.719 F25
G1 X74.06 Y152.664 Z-3.723 F25
G1 X74.149 Y152.615 Z-3.726 F25
G1 X74.242 Y152.573 Z-3.73 F25
G1 X74.338 Y152.538 Z-3.734 F25
G1 X74.436 Y152.511 Z-3.738 F25
G1 X74.537 Y152.491 Z-3.742 F25
G1 X74.638 Y152.479 Z-3.746 F25
G1 X74.74 Y152.475 Z-3.75 F25
G1 X74.842 Y152.479 Z-3.753 F25
G1 X74.943 Y152.491 Z-3.757 F25
G1 X75.043 Y152.511 Z-3.761 F25
G1 X75.141 Y152.538 Z-3.765 F25
G1 X75.237 Y152.573 Z-3.769 F25
G1 X75.33 Y152.615 Z-3.773 F25
G1 X75.42 Y152.664 Z-3.777 F25
G1 X75.505 Y152.72 Z-3.78 F25
G1 X75.585 Y152.782 Z-3.784 F25
G1 X75.661 Y152.85 Z-3.788 F25
G1 X75.731 Y152.924 Z-3.792 F25
G1 X75.795 Y153.004 Z-3.796 F25
G1 X75.853 Y153.087 Z-3.8 F25
G1 X75.904 Y153.176 Z-3.804 F25
G1 X75.948 Y153.267 Z-3.807 F25
G1 X75.985 Y153.362 Z-3.811 F25
G1 X76.015 Y153.46 Z-3.815 F25
G1 X76.037 Y153.559 Z-3.819 F25
G1 X76.051 Y153.66 Z-3.823 F25
G1 X76.057 Y153.762 Z-3.827 F25
G1 X76.056 Y153.864 Z-3.831 F25
G1 X76.046 Y153.965 Z-3.834 F25
G1 X76.029 Y154.066 Z-3.838 F25
G1 X76.004 Y154.164 Z-3.842 F25
G1 X75.971 Y154.261 Z-3.846 F25
G1 X75.931 Y154.355 Z-3.85 F25
G1 X75.884 Y154.445 Z-3.854 F25
G1 X75.83 Y154.531 Z-3.858 F25
G1 X75.77 Y154.613 Z-3.861 F25
G1 X75.703 Y154.69 Z-3.865 F25
G1 X75.631 Y154.762 Z-3.869 F25
G1 X75.553 Y154.828 Z-3.873 F25
G1 X75.471 Y154.888 Z-3.877 F25
G1 X75.384 Y154.941 Z-3.881 F25
G1 X75.293 Y154.987 Z-3.885 F25
G1 X75.199 Y155.026 Z-3.888 F25
G1 X75.103 Y155.058 Z-3.892 F25
G1 X75.004 Y155.082 Z-3.896 F25
G1 X74.904 Y155.098 Z-3.9 F25
G1 X74.802 Y155.107 Z-3.904 F25
G1 X74.7 Y155.108 Z-3.908 F25
G1 X74.599 Y155.1 Z-3.912 F25
G1 X74.498 Y155.085 Z-3.915 F25
G1 X74.399 Y155.063 Z-3.919 F25
G1 X74.302 Y155.032 Z-3.923 F25
G1 X74.208 Y154.995 Z-3.927 F25
G1 X74.116 Y154.95 Z-3.931 F25
G1 X74.029 Y154.898 Z-3.935 F25
G1 X73.945 Y154.839 Z-3.939 F25
G1 X73.867 Y154.775 Z-3.942 F25
G1 X73.794 Y154.704 Z-3.946 F25
G1 X73.726 Y154.628 Z-3.95 F25
G1 X73.665 Y154.547 Z-3.954 F25
G1 X73.61 Y154.462 Z-3.958 F25
G1 X73.561 Y154.372 Z-3.962 F25
G1 X73.52 Y154.279 Z-3.966 F25
G1 X73.486 Y154.183 Z-3.969 F25
G1 X73.46 Y154.085 Z-3.973 F25
G1 X73.441 Y153.985 Z-3.977 F25
G1 X73.43 Y153.884 Z-3.981 F25
G1 X73.427 Y153.782 Z-3.985 F25
G1 X73.432 Y153.681 Z-3.989 F25
G1 X73.445 Y153.58 Z-3.993 F25
G1 X73.465 Y153.48 Z-3.996 F25
G1 X73.493 Y153.383 Z-4 F25
G1 X73.529 Y153.287 Z-4.004 F25
G1 X73.572 Y153.195 Z-4.008 F25
G1 X73.621 Y153.107 Z-4.012 F25
G1 X73.678 Y153.022 Z-4.016 F25
G1 X73.741 Y152.942 Z-4.02 F25
G1 X73.81 Y152.868 Z-4.023 F25
G1 X73.884 Y152.799 Z-4.027 F25
G1 X73.964 Y152.735 Z-4.031 F25
G1 X74.048 Y152.678 Z-4.035 F25
G1 X74.136 Y152.628 Z-4.039 F25
G1 X74.228 Y152.585 Z-4.043 F25
G1 X74.323 Y152.549 Z-4.047 F25
G1 X74.421 Y152.52 Z-4.05 F25
G1 X74.52 Y152.499 Z-4.054 F25
G1 X74.621 Y152.486 Z-4.058 F25
G1 X74.722 Y152.481 Z-4.062 F25
G1 X74.824 Y152.484 Z-4.066 F25
G1 X74.925 Y152.494 Z-4.07 F25
G1 X75.025 Y152.512 Z-4.074 F25
G1 X75.123 Y152.538 Z-4.077 F25
G1 X75.219 Y152.571 Z-4.081 F25
G1 X75.312 Y152.612 Z-4.085 F25
G1 X75.401 Y152.659 Z-4.089 F25
G1 X75.487 Y152.714 Z-4.093 F25
G1 X75.568 Y152.775 Z-4.097 F25
G1 X75.644 Y152.842 Z-4.101 F25
G1 X75.715 Y152.915 Z-4.104 F25
G1 X75.78 Y152.993 Z-4.108 F25
G1 X75.839 Y153.075 Z-4.112 F25
G1 X75.891 Y153.162 Z-4.116 F25
G1 X75.936 Y153.253 Z-4.12 F25
G1 X75.974 Y153.347 Z-4.124 F25
G1 X76.005 Y153.444 Z-4.127 F25
G1 X76.028 Y153.543 Z-4.131 F25
G1 X76.044 Y153.643 Z-4.135 F25
G1 X76.051 Y153.744 Z-4.139 F25
G1 Y153.846 Z-4.143 F25
G1 X76.043 Y153.947 Z-4.147 F25
G1 X76.027 Y154.047 Z-4.151 F25
G1 X76.003 Y154.146 Z-4.154 F25
G1 X75.972 Y154.242 Z-4.158 F25
G1 X75.934 Y154.336 Z-4.162 F25
G1 X75.888 Y154.427 Z-4.166 F25
G1 X75.836 Y154.514 Z-4.17 F25
G1 X75.777 Y154.596 Z-4.174 F25
G1 X75.711 Y154.674 Z-4.178 F25
G1 X75.64 Y154.746 Z-4.181 F25
G1 X75.564 Y154.813 Z-4.185 F25
G1 X75.483 Y154.873 Z-4.189 F25
G1 X75.397 Y154.927 Z-4.193 F25
G1 X75.307 Y154.974 Z-4.197 F25
G1 X75.214 Y155.015 Z-4.201 F25
G1 X75.119 Y155.048 Z-4.205 F25
G1 X75.02 Y155.073 Z-4.208 F25
G1 X74.921 Y155.091 Z-4.212 F25
G1 X74.82 Y155.1 Z-4.216 F25
G1 X74.718 Y155.103 Z-4.22 F25
G1 X74.617 Y155.097 Z-4.224 F25
G1 X74.517 Y155.083 Z-4.228 F25
G1 X74.418 Y155.062 Z-4.232 F25
G1 X74.321 Y155.033 Z-4.235 F25
G1 X74.226 Y154.997 Z-4.239 F25
G1 X74.135 Y154.953 Z-4.243 F25
G1 X74.047 Y154.903 Z-4.247 F25
G1 X73.963 Y154.846 Z-4.251 F25
G1 X73.884 Y154.782 Z-4.255 F25
G1 X73.81 Y154.713 Z-4.259 F25
G1 X73.742 Y154.638 Z-4.262 F25
G1 X73.679 Y154.558 Z-4.266 F25
G1 X73.623 Y154.474 Z-4.27 F25
G1 X73.574 Y154.385 Z-4.274 F25
G1 X73.532 Y154.293 Z-4.278 F25
G1 X73.497 Y154.198 Z-4.282 F25
G1 X73.469 Y154.101 Z-4.286 F25
G1 X73.449 Y154.002 Z-4.289 F25
G1 X73.437 Y153.901 Z-4.293 F25
G1 X73.433 Y153.8 Z-4.297 F25
G1 X73.436 Y153.699 Z-4.301 F25
G1 X73.447 Y153.598 Z-4.305 F25
G1 X73.466 Y153.499 Z-4.309 F25
G1 X73.493 Y153.401 Z-4.313 F25
G1 X73.527 Y153.306 Z-4.316 F25
G1 X73.569 Y153.214 Z-4.32 F25
G1 X73.617 Y153.125 Z-4.324 F25
G1 X73.672 Y153.04 Z-4.328 F25
G1 X73.734 Y152.96 Z-4.332 F25
G1 X73.801 Y152.884 Z-4.336 F25
G1 X73.874 Y152.814 Z-4.34 F25
G1 X73.953 Y152.75 Z-4.343 F25
G1 X74.036 Y152.693 Z-4.347 F25
G1 X74.123 Y152.641 Z-4.351 F25
G1 X74.214 Y152.597 Z-4.355 F25
G1 X74.308 Y152.56 Z-4.359 F25
G1 X74.405 Y152.53 Z-4.363 F25
G1 X74.503 Y152.508 Z-4.367 F25
G1 X74.604 Y152.493 Z-4.37 F25
G1 X74.705 Y152.487 Z-4.374 F25
G1 X74.806 Y152.488 Z-4.378 F25
G1 X74.906 Y152.497 Z-4.382 F25
G1 X75.006 Y152.514 Z-4.386 F25
G1 X75.104 Y152.538 Z-4.39 F25
G1 X75.2 Y152.57 Z-4.394 F25
G1 X75.293 Y152.609 Z-4.397 F25
G1 X75.383 Y152.655 Z-4.401 F25
G1 X75.469 Y152.708 Z-4.405 F25
G1 X75.551 Y152.768 Z-4.409 F25
G1 X75.628 Y152.834 Z-4.413 F25
G1 X75.699 Y152.905 Z-4.417 F25
G1 X75.765 Y152.982 Z-4.421 F25
G1 X75.824 Y153.063 Z-4.424 F25
G1 X75.877 Y153.149 Z-4.428 F25
G1 X75.924 Y153.239 Z-4.432 F25
G1 X75.963 Y153.332 Z-4.436 F25
G1 X75.995 Y153.428 Z-4.44 F25
G1 X76.019 Y153.526 Z-4.444 F25
G1 X76.036 Y153.626 Z-4.448 F25
G1 X76.045 Y153.727 Z-4.451 F25
G1 X76.046 Y153.828 Z-4.455 F25
G1 X76.039 Y153.929 Z-4.459 F25
G1 X76.025 Y154.029 Z-4.463 F25
G1 X76.003 Y154.127 Z-4.467 F25
G1 X75.973 Y154.224 Z-4.471 F25
G1 X75.936 Y154.318 Z-4.475 F25
G1 X75.892 Y154.409 Z-4.478 F25
G1 X75.841 Y154.496 Z-4.482 F25
G1 X75.783 Y154.579 Z-4.486 F25
G1 X75.719 Y154.657 Z-4.49 F25
G1 X75.65 Y154.73 Z-4.494 F25
G1 X75.574 Y154.797 Z-4.498 F25
G1 X75.494 Y154.858 Z-4.502 F25
G1 X75.41 Y154.913 Z-4.505 F25
G1 X75.321 Y154.962 Z-4.509 F25
G1 X75.229 Y155.003 Z-4.513 F25
G1 X75.134 Y155.037 Z-4.517 F25
G1 X75.037 Y155.064 Z-4.521 F25
G1 X74.937 Y155.083 Z-4.525 F25
G1 X74.837 Y155.094 Z-4.529 F25
G1 X74.736 Y155.097 Z-4.532 F25
G1 X74.636 Y155.093 Z-4.536 F25
G1 X74.535 Y155.081 Z-4.54 F25
G1 X74.436 Y155.061 Z-4.544 F25
G1 X74.339 Y155.033 Z-4.548 F25
G1 X74.245 Y154.999 Z-4.552 F25
G1 X74.153 Y154.957 Z-4.556 F25
G1 X74.065 Y154.907 Z-4.559 F25
G1 X73.98 Y154.852 Z-4.563 F25
G1 X73.901 Y154.79 Z-4.567 F25
G1 X73.826 Y154.722 Z-4.571 F25
G1 X73.757 Y154.648 Z-4.575 F25
G1 X73.694 Y154.569 Z-4.579 F25
G1 X73.637 Y154.486 Z-4.583 F25
G1 X73.587 Y154.399 Z-4.586 F25
G1 X73.544 Y154.308 Z-4.59 F25
G1 X73.508 Y154.214 Z-4.594 F25
G1 X73.479 Y154.117 Z-4.598 F25
G1 X73.458 Y154.018 Z-4.602 F25
G1 X73.444 Y153.919 Z-4.606 F25
G1 X73.438 Y153.818 Z-4.61 F25
G1 X73.441 Y153.717 Z-4.613 F25
G1 X73.45 Y153.617 Z-4.617 F25
G1 X73.468 Y153.518 Z-4.621 F25
G1 X73.493 Y153.42 Z-4.625 F25
G1 X73.526 Y153.325 Z-4.629 F25
G1 X73.566 Y153.232 Z-4.633 F25
G1 X73.613 Y153.143 Z-4.637 F25
G1 X73.666 Y153.058 Z-4.64 F25
G1 X73.727 Y152.977 Z-4.644 F25
G1 X73.793 Y152.901 Z-4.648 F25
G1 X73.865 Y152.83 Z-4.652 F25
G1 X73.942 Y152.765 Z-4.656 F25
G1 X74.024 Y152.707 Z-4.66 F25
G1 X74.11 Y152.655 Z-4.664 F25
G1 X74.2 Y152.609 Z-4.667 F25
G1 X74.293 Y152.571 Z-4.671 F25
G1 X74.389 Y152.54 Z-4.675 F25
G1 X74.487 Y152.517 Z-4.679 F25
G1 X74.587 Y152.501 Z-4.683 F25
G1 X74.687 Y152.493 Z-4.687 F25
G1 X74.788 Z-4.691 F25
G1 X74.888 Y152.5 Z-4.694 F25
G1 X74.988 Y152.515 Z-4.698 F25
G1 X75.086 Y152.538 Z-4.702 F25
G1 X75.181 Y152.569 Z-4.706 F25
G1 X75.275 Y152.607 Z-4.71 F25
G1 X75.365 Y152.651 Z-4.714 F25
G1 X75.451 Y152.703 Z-4.718 F25
G1 X75.533 Y152.761 Z-4.721 F25
G1 X75.611 Y152.826 Z-4.725 F25
G1 X75.683 Y152.896 Z-4.729 F25
G1 X75.749 Y152.971 Z-4.733 F25
G1 X75.81 Y153.052 Z-4.737 F25
G1 X75.864 Y153.137 Z-4.741 F25
G1 X75.911 Y153.226 Z-4.745 F25
G1 X75.951 Y153.318 Z-4.748 F25
G1 X75.985 Y153.413 Z-4.752 F25
G1 X76.01 Y153.51 Z-4.756 F25
G1 X76.028 Y153.609 Z-4.76 F25
G1 X76.038 Y153.709 Z-4.764 F25
G1 X76.041 Y153.81 Z-4.768 F25
G1 X76.036 Y153.911 Z-4.771 F25
G1 X76.023 Y154.01 Z-4.775 F25
G1 X76.002 Y154.109 Z-4.779 F25
G1 X75.974 Y154.205 Z-4.783 F25
G1 X75.938 Y154.299 Z-4.787 F25
G1 X75.895 Y154.39 Z-4.791 F25
G1 X75.846 Y154.478 Z-4.795 F25
G1 X75.79 Y154.561 Z-4.798 F25
G1 X75.727 Y154.64 Z-4.802 F25
G1 X75.659 Y154.713 Z-4.806 F25
G1 X75.585 Y154.781 Z-4.81 F25
G1 X75.506 Y154.844 Z-4.814 F25
G1 X75.422 Y154.9 Z-4.818 F25
G1 X75.334 Y154.949 Z-4.822 F25
G1 X75.243 Y154.991 Z-4.825 F25
G1 X75.149 Y155.026 Z-4.829 F25
G1 X75.053 Y155.054 Z-4.833 F25
G1 X74.954 Y155.074 Z-4.837 F25
G1 X74.854 Y155.087 Z-4.841 F25
G1 X74.754 Y155.092 Z-4.845 F25
G1 X74.653 Y155.089 Z-4.849 F25
G1 X74.554 Y155.078 Z-4.852 F25
G1 X74.455 Y155.06 Z-4.856 F25
G1 X74.358 Y155.034 Z-4.86 F25
G1 X74.263 Y155 Z-4.864 F25
G1 X74.171 Y154.959 Z-4.868 F25
G1 X74.082 Y154.912 Z-4.872 F25
G1 X73.998 Y154.857 Z-4.876 F25
G1 X73.918 Y154.797 Z-4.879 F25
G1 X73.843 Y154.73 Z-4.883 F25
G1 X73.773 Y154.658 Z-4.887 F25
G1 X73.709 Y154.58 Z-4.891 F25
G1 X73.651 Y154.498 Z-4.895 F25
G1 X73.6 Y154.412 Z-4.899 F25
G1 X73.556 Y154.322 Z-4.903 F25
G1 X73.519 Y154.229 Z-4.906 F25
G1 X73.489 Y154.133 Z-4.91 F25
G1 X73.466 Y154.035 Z-4.914 F25
G1 X73.452 Y153.936 Z-4.918 F25
G1 X73.444 Y153.836 Z-4.922 F25
G1 X73.445 Y153.735 Z-4.926 F25
G1 X73.454 Y153.635 Z-4.93 F25
G1 X73.47 Y153.536 Z-4.933 F25
G1 X73.493 Y153.439 Z-4.937 F25
G1 X73.525 Y153.343 Z-4.941 F25
G1 X73.563 Y153.25 Z-4.945 F25
G1 X73.609 Y153.161 Z-4.949 F25
G1 X73.661 Y153.075 Z-4.953 F25
G1 X73.72 Y152.994 Z-4.957 F25
G1 X73.785 Y152.917 Z-4.96 F25
G1 X73.856 Y152.846 Z-4.964 F25
G1 X73.931 Y152.781 Z-4.968 F25
G1 X74.012 Y152.721 Z-4.972 F25
G1 X74.097 Y152.668 Z-4.976 F25
G1 X74.186 Y152.621 Z-4.98 F25
G1 X74.279 Y152.582 Z-4.984 F25
G1 X74.374 Y152.55 Z-4.987 F25
G1 X74.471 Y152.525 Z-4.991 F25
G1 X74.57 Y152.508 Z-4.995 F25
G1 X74.669 Y152.499 Z-4.999 F25
G1 X74.77 Y152.497 Z-5.003 F25
G1 X74.87 Y152.504 Z-5.007 F25
G1 X74.969 Y152.517 Z-5.011 F25
G1 X75.067 Y152.539 Z-5.014 F25
G1 X75.163 Y152.568 Z-5.018 F25
G1 X75.256 Y152.604 Z-5.022 F25
G1 X75.347 Y152.648 Z-5.026 F25
G1 X75.433 Y152.698 Z-5.03 F25
G1 X75.516 Y152.755 Z-5.034 F25
G1 X75.594 Y152.818 Z-5.038 F25
G1 X75.667 Y152.887 Z-5.041 F25
G1 X75.734 Y152.961 Z-5.045 F25
G1 X75.795 Y153.041 Z-5.049 F25
G1 X75.85 Y153.125 Z-5.053 F25
G1 X75.898 Y153.212 Z-5.057 F25
G1 X75.94 Y153.304 Z-5.061 F25
G1 X75.974 Y153.398 Z-5.065 F25
G1 X76.001 Y153.494 Z-5.068 F25
G1 X76.02 Y153.593 Z-5.072 F25
G1 X76.032 Y153.692 Z-5.076 F25
G1 X76.036 Y153.793 Z-5.08 F25
G3 X73.445 I-1.295 F25
G3 X76.036 I1.295 F25
; MOVEMENT_CUTTING
G1 X76.064 Y154.49 F254
G1 X76.072 Y154.625 F254
G1 X76.052 Y154.759 F254
G1 X76.006 Y154.886 F254
G1 X75.978 Y154.945 F254
G1 X75.956 Y154.999 F254
G1 X75.891 Y155.137 F254
G1 X75.809 Y155.265 F254
G1 X75.778 Y155.301 F254
G1 X75.633 Y155.433 F254
G1 X75.458 Y155.522 F254
G1 X75.266 Y155.563 F254
; MOVEMENT_LEAD_OUT
G1 X75.216 Y155.561 Z-5.06 F254
G1 X75.167 Y155.551 Z-5.039 F254
G1 X75.12 Y155.533 Z-5.019 F254
G1 X75.077 Y155.509 Z-4.999 F254
G1 X75.038 Y155.478 Z-4.978 F254
G1 X75.004 Y155.442 Z-4.958 F254
G1 X74.977 Y155.4 Z-4.938 F254
G1 X74.956 Y155.355 Z-4.917 F254
G1 X74.942 Y155.307 Z-4.897 F254
G1 X74.937 Y155.257 Z-4.877 F254
G3 X75.044 Y155.007 I0.317 J-0.012 F254
; MOVEMENT_LINK_DIRECT
G1 X75.448 Y154.651 F254
G3 X75.768 Y154.592 I0.21 J0.238 F254
; MOVEMENT_LEAD_IN
G1 X75.813 Y154.612 Z-4.897 F254
G1 X75.854 Y154.64 Z-4.917 F254
G1 X75.891 Y154.674 Z-4.938 F254
G1 X75.922 Y154.713 Z-4.958 F254
G1 X75.946 Y154.756 Z-4.978 F254
G1 X75.963 Y154.803 Z-4.999 F254
G1 X75.973 Y154.852 Z-5.019 F254
G1 X75.975 Y154.902 Z-5.039 F254
G1 X75.969 Y154.951 Z-5.06 F254
G1 X75.956 Y154.999 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X75.819 Y155.335 F254
G1 X75.804 Y155.37 F254
G1 X75.782 Y155.405 F254
G1 X75.755 Y155.44 F254
G1 X75.722 Y155.475 F254
G1 X75.691 Y155.499 F254
G1 X75.661 Y155.518 F254
G1 X75.621 Y155.536 F254
G1 X75.582 Y155.548 F254
G1 X75.542 Y155.554 F254
G1 X75.502 Y155.556 F254
G1 X75.344 Y155.557 F254
G1 X75.185 Y155.568 F254
G1 X75.027 Y155.596 F254
G1 X74.884 Y155.633 F254
G1 X74.868 Y155.638 F254
G1 X74.722 Y155.681 F254
G1 X74.572 Y155.707 F254
G1 X74.419 Y155.716 F254
G1 X74.267 Y155.71 F254
G1 X74.116 Y155.689 F254
G1 X73.968 Y155.654 F254
G1 X73.823 Y155.606 F254
G1 X73.683 Y155.546 F254
G1 X73.549 Y155.473 F254
G1 X73.422 Y155.39 F254
G1 X73.301 Y155.296 F254
G1 X73.234 Y155.234 F254
G1 X73.11 Y155.087 F254
G1 X73.028 Y154.913 F254
G1 X72.994 Y154.724 F254
G1 X73.01 Y154.533 F254
; MOVEMENT_LEAD_OUT
G1 X73.026 Y154.486 Z-5.06 F254
G1 X73.049 Y154.441 Z-5.039 F254
G1 X73.079 Y154.401 Z-5.019 F254
G1 X73.114 Y154.367 Z-4.999 F254
G1 X73.155 Y154.338 Z-4.978 F254
G1 X73.199 Y154.316 Z-4.958 F254
G1 X73.247 Y154.301 Z-4.938 F254
G1 X73.296 Y154.293 Z-4.917 F254
G1 X73.346 Y154.294 Z-4.897 F254
G1 X73.395 Y154.302 Z-4.877 F254
G3 X73.462 Y154.327 I-0.077 J0.308 F254
G1 X73.618 Y154.407 F254
; MOVEMENT_LINK_DIRECT
G1 X74.885 Y155.053 F254
; MOVEMENT_LEAD_IN
G1 X74.898 Y155.059 F254
G3 X75.05 Y155.228 I-0.144 J0.283 F254
G1 X75.064 Y155.276 Z-4.897 F254
G1 X75.071 Y155.325 Z-4.917 F254
G1 X75.069 Y155.375 Z-4.938 F254
G1 X75.06 Y155.424 Z-4.958 F254
G1 X75.044 Y155.471 Z-4.978 F254
G1 X75.02 Y155.515 Z-4.999 F254
G1 X74.99 Y155.554 Z-5.019 F254
G1 X74.954 Y155.589 Z-5.039 F254
G1 X74.913 Y155.617 Z-5.06 F254
G1 X74.868 Y155.638 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X74.71 Y155.693 F254
G1 X74.491 Y155.792 F254
G1 X74.392 Y155.842 F254
G1 X74.234 Y155.933 F254
G1 X74.208 Y155.951 F254
G1 X74.08 Y156.032 F254
G1 X73.935 Y156.079 F254
G1 X73.784 Y156.104 F254
G1 X73.632 Y156.109 F254
G1 X73.48 Y156.097 F254
G1 X73.419 Y156.085 F254
G1 X73.223 Y156.016 F254
G1 X73.054 Y155.896 F254
G1 X72.925 Y155.734 F254
G1 X72.846 Y155.542 F254
G1 X72.823 Y155.336 F254
G1 X72.858 Y155.132 F254
; MOVEMENT_LEAD_OUT
G1 X72.879 Y155.086 Z-5.06 F254
G1 X72.906 Y155.045 Z-5.039 F254
G1 X72.939 Y155.008 Z-5.019 F254
G1 X72.978 Y154.977 Z-4.999 F254
G1 X73.021 Y154.952 Z-4.978 F254
G1 X73.068 Y154.934 Z-4.958 F254
G1 X73.117 Y154.924 Z-4.938 F254
G1 X73.167 Y154.922 Z-4.917 F254
G1 X73.216 Y154.927 Z-4.897 F254
G1 X73.264 Y154.94 Z-4.877 F254
G3 X73.306 Y154.959 I-0.107 J0.299 F254
G1 X73.484 Y155.054 F254
; MOVEMENT_LINK_DIRECT
G1 X74.07 Y155.366 F254
; MOVEMENT_LEAD_IN
G1 X74.166 Y155.417 F254
G3 X74.27 Y155.506 I-0.149 J0.28 F254
G1 X74.297 Y155.548 Z-4.897 F254
G1 X74.317 Y155.594 Z-4.917 F254
G1 X74.33 Y155.642 Z-4.938 F254
G1 X74.334 Y155.692 Z-4.958 F254
G1 X74.331 Y155.741 Z-4.978 F254
G1 X74.321 Y155.79 Z-4.999 F254
G1 X74.303 Y155.836 Z-5.019 F254
G1 X74.277 Y155.879 Z-5.039 F254
G1 X74.246 Y155.918 Z-5.06 F254
G1 X74.208 Y155.951 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X74.075 Y156.044 F254
G1 X73.995 Y156.109 F254
G1 X73.813 Y156.268 F254
G1 X73.783 Y156.297 F254
G1 X73.669 Y156.399 F254
G1 X73.533 Y156.468 F254
G1 X73.327 Y156.49 F254
G1 X73.123 Y156.449 F254
G1 X72.94 Y156.348 F254
G1 X72.797 Y156.197 F254
G1 X72.706 Y156.01 F254
G1 X72.675 Y155.804 F254
G1 X72.708 Y155.599 F254
; MOVEMENT_LEAD_OUT
G1 X72.728 Y155.553 Z-5.06 F254
G1 X72.756 Y155.512 Z-5.039 F254
G1 X72.789 Y155.475 Z-5.019 F254
G1 X72.828 Y155.444 Z-4.999 F254
G1 X72.871 Y155.419 Z-4.978 F254
G1 X72.918 Y155.402 Z-4.958 F254
G1 X72.967 Y155.391 Z-4.938 F254
G1 X73.017 Y155.389 Z-4.917 F254
G1 X73.066 Y155.394 Z-4.897 F254
G1 X73.114 Y155.408 Z-4.877 F254
G3 X73.186 Y155.444 I-0.107 J0.299 F254
G1 X73.323 Y155.538 F254
; MOVEMENT_LINK_DIRECT
G1 X73.57 Y155.706 F254
; MOVEMENT_LEAD_IN
G1 X73.732 Y155.816 F254
G3 X73.772 Y155.849 I-0.179 J0.262 F254
G1 X73.805 Y155.886 Z-4.897 F254
G1 X73.832 Y155.928 Z-4.917 F254
G1 X73.852 Y155.973 Z-4.938 F254
G1 X73.865 Y156.021 Z-4.958 F254
G1 X73.87 Y156.071 Z-4.978 F254
G1 X73.868 Y156.121 Z-4.999 F254
G1 X73.857 Y156.169 Z-5.019 F254
G1 X73.839 Y156.216 Z-5.039 F254
G1 X73.814 Y156.259 Z-5.06 F254
G1 X73.783 Y156.297 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X73.758 Y156.322 F254
G1 X73.6 Y156.484 F254
G1 X73.508 Y156.585 F254
G1 X73.488 Y156.609 F254
G1 X73.383 Y156.719 F254
G1 X73.248 Y156.791 F254
G1 X73.067 Y156.805 F254
G1 X72.891 Y156.763 F254
G1 X72.735 Y156.669 F254
G1 X72.617 Y156.531 F254
G1 X72.546 Y156.364 F254
G1 X72.531 Y156.183 F254
G1 X72.572 Y156.006 F254
; MOVEMENT_LEAD_OUT
G1 X72.593 Y155.964 Z-5.061 F254
G1 X72.619 Y155.925 Z-5.042 F254
G1 X72.649 Y155.888 Z-5.022 F254
G1 X72.692 Y155.847 Z-4.998 F254
G1 X72.739 Y155.81 Z-4.974 F254
G1 X72.79 Y155.779 Z-4.95 F254
G1 X72.843 Y155.753 Z-4.925 F254
G1 X72.899 Y155.733 Z-4.901 F254
G1 X72.957 Y155.72 Z-4.877 F254
G3 X73.594 Y156.139 I0.098 J0.544 F254
; MOVEMENT_LEAD_IN
G1 X73.604 Y156.2 Z-4.902 F254
G1 X73.608 Y156.262 Z-4.928 F254
G1 X73.605 Y156.324 Z-4.953 F254
G1 X73.595 Y156.386 Z-4.978 F254
G1 X73.577 Y156.446 Z-5.004 F254
G1 X73.554 Y156.503 Z-5.029 F254
G1 X73.524 Y156.558 Z-5.055 F254
G1 X73.488 Y156.609 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X73.237 Y156.902 F254
G1 X73.133 Y157.014 F254
G1 X72.999 Y157.085 F254
G1 X72.815 Y157.09 F254
G1 X72.641 Y157.03 F254
G1 X72.499 Y156.912 F254
G1 X72.408 Y156.752 F254
G1 X72.38 Y156.57 F254
G1 X72.417 Y156.39 F254
; MOVEMENT_LEAD_OUT
G1 X72.435 Y156.354 Z-5.064 F254
G1 X72.456 Y156.32 Z-5.047 F254
G1 X72.48 Y156.288 Z-5.031 F254
G1 X72.517 Y156.249 Z-5.009 F254
G1 X72.558 Y156.214 Z-4.987 F254
G1 X72.603 Y156.183 Z-4.965 F254
G1 X72.651 Y156.158 Z-4.943 F254
G1 X72.701 Y156.139 Z-4.921 F254
G1 X72.754 Y156.125 Z-4.899 F254
G1 X72.807 Y156.116 Z-4.877 F254
G3 X73.31 Y156.431 I0.047 J0.485 F254
; MOVEMENT_LEAD_IN
G1 X73.328 Y156.49 Z-4.902 F254
G1 X73.338 Y156.552 Z-4.928 F254
G1 X73.341 Y156.614 Z-4.953 F254
G1 X73.335 Y156.676 Z-4.978 F254
G1 X73.322 Y156.737 Z-5.004 F254
G1 X73.301 Y156.795 Z-5.029 F254
G1 X73.272 Y156.851 Z-5.055 F254
G1 X73.237 Y156.902 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X72.998 Y157.187 F254
G1 X72.894 Y157.299 F254
G1 X72.716 Y157.342 F254
G1 X72.536 Y157.311 F254
G1 X72.382 Y157.212 F254
G1 X72.279 Y157.061 F254
G1 X72.244 Y156.882 F254
G1 X72.282 Y156.703 F254
; MOVEMENT_LEAD_OUT
G3 X72.336 Y156.624 I0.288 J0.137 F254
G3 X72.998 Y157.187 I0.32 J0.295 F254
; MOVEMENT_CUTTING
G1 X72.807 Y157.417 F254
G1 X72.778 Y157.454 F254
G1 X72.676 Y157.567 F254
G1 X72.516 Y157.591 F254
G1 X72.359 Y157.553 F254
G1 X72.228 Y157.459 F254
G1 X72.143 Y157.322 F254
G1 X72.116 Y157.162 F254
G1 X72.151 Y157.005 F254
; MOVEMENT_LEAD_OUT
G3 X72.196 Y156.942 I0.201 J0.097 F254
G3 X72.778 Y157.454 I0.272 J0.277 F254
; MOVEMENT_CUTTING
G1 X72.582 Y157.695 F254
G1 X72.531 Y157.752 F254
G1 X72.395 Y157.82 F254
G1 X72.242 Y157.804 F254
G1 X72.11 Y157.728 F254
G1 X72.02 Y157.605 F254
G1 X71.988 Y157.455 F254
G1 X72.019 Y157.305 F254
; MOVEMENT_LEAD_OUT
G3 X72.058 Y157.249 I0.196 J0.094 F254
G3 X72.582 Y157.695 I0.249 J0.238 F254
; MOVEMENT_CUTTING
G1 X72.49 Y157.808 F254
G1 X72.452 Y157.854 F254
G1 X72.422 Y157.882 F254
G1 X72.392 Y157.903 F254
G1 X72.362 Y157.92 F254
G1 X72.332 Y157.933 F254
G1 X72.292 Y157.945 F254
G1 X72.252 Y157.951 F254
G1 X72.213 Y157.953 F254
G1 X72.173 Y157.949 F254
G1 X72.133 Y157.94 F254
G1 X72.094 Y157.926 F254
G1 X72.054 Y157.906 F254
G1 X72.014 Y157.877 F254
G1 X71.991 Y157.854 F254
G1 X71.958 Y157.814 F254
G1 X71.935 Y157.775 F254
G1 X71.919 Y157.735 F254
G1 X71.909 Y157.695 F254
G1 X71.904 Y157.656 F254
G1 Y157.616 F254
G1 X71.909 Y157.576 F254
G1 X71.919 Y157.537 F254
G1 X72.014 Y157.315 F254
G1 X72.265 Y156.744 F254
G1 X72.402 Y156.426 F254
G1 X72.594 Y155.951 F254
G1 X72.807 Y155.29 F254
G1 X72.901 Y154.999 F254
G1 X72.944 Y154.84 F254
G1 X73.012 Y154.523 F254
G1 X73.042 Y154.365 F254
G1 X73.082 Y154.047 F254
G1 X73.099 Y153.889 F254
G1 X73.104 Y153.433 F254
G1 X73.101 Y153.413 F254
G1 X73.083 Y153.262 F254
G1 X73.081 Y153.109 F254
G1 X73.1 Y152.958 F254
G1 X73.137 Y152.81 F254
G1 X73.191 Y152.668 F254
G1 X73.26 Y152.532 F254
G1 X73.343 Y152.404 F254
G1 X73.438 Y152.285 F254
G1 X73.484 Y152.238 F254
G1 X73.625 Y152.124 F254
G1 X73.789 Y152.047 F254
G1 X73.967 Y152.013 F254
G1 X74.147 Y152.023 F254
; MOVEMENT_LEAD_OUT
G1 X74.195 Y152.037 Z-5.06 F254
G1 X74.24 Y152.058 Z-5.039 F254
G1 X74.281 Y152.087 Z-5.019 F254
G1 X74.317 Y152.121 Z-4.999 F254
G1 X74.347 Y152.161 Z-4.978 F254
G1 X74.371 Y152.204 Z-4.958 F254
G1 X74.388 Y152.251 Z-4.938 F254
G1 X74.397 Y152.3 Z-4.917 F254
G1 X74.398 Y152.35 Z-4.897 F254
G1 X74.391 Y152.399 Z-4.877 F254
G3 X74.346 Y152.508 I-0.31 J-0.066 F254
G1 X74.275 Y152.615 F254
; MOVEMENT_LINK_DIRECT
G1 X73.677 Y153.523 F254
; MOVEMENT_LEAD_IN
G3 X73.476 Y153.659 I-0.265 J-0.175 F254
G1 X73.427 Y153.666 Z-4.897 F254
G1 X73.377 Y153.664 Z-4.917 F254
G1 X73.328 Y153.655 Z-4.938 F254
G1 X73.281 Y153.638 Z-4.958 F254
G1 X73.237 Y153.614 Z-4.978 F254
G1 X73.198 Y153.583 Z-4.999 F254
G1 X73.164 Y153.547 Z-5.019 F254
G1 X73.136 Y153.506 Z-5.039 F254
G1 X73.115 Y153.461 Z-5.06 F254
G1 X73.101 Y153.413 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X73.046 Y153.096 F254
G1 X73.018 Y152.937 F254
G1 X72.966 Y152.734 F254
G1 X72.953 Y152.7 F254
G1 X72.907 Y152.555 F254
G1 X72.918 Y152.376 F254
G1 X72.982 Y152.209 F254
G1 X73.094 Y152.069 F254
G1 X73.243 Y151.969 F254
G1 X73.415 Y151.919 F254
G1 X73.594 Y151.924 F254
; MOVEMENT_LEAD_OUT
G1 X73.641 Y151.938 Z-5.06 F254
G1 X73.686 Y151.959 Z-5.039 F254
G1 X73.727 Y151.988 Z-5.019 F254
G1 X73.763 Y152.022 Z-4.999 F254
G1 X73.793 Y152.062 Z-4.978 F254
G1 X73.817 Y152.105 Z-4.958 F254
G1 X73.834 Y152.152 Z-4.938 F254
G1 X73.843 Y152.201 Z-4.917 F254
G1 X73.844 Y152.251 Z-4.897 F254
G1 X73.837 Y152.301 Z-4.877 F254
G3 X73.773 Y152.435 I-0.31 J-0.066 F254
G1 X73.712 Y152.51 F254
; MOVEMENT_LINK_DIRECT
G1 X73.549 Y152.709 F254
; MOVEMENT_LEAD_IN
G1 X73.492 Y152.779 F254
G3 X73.367 Y152.872 I-0.246 J-0.201 F254
G1 X73.32 Y152.887 Z-4.897 F254
G1 X73.271 Y152.895 Z-4.917 F254
G1 X73.221 Z-4.938 F254
G1 X73.172 Y152.887 Z-4.958 F254
G1 X73.124 Y152.872 Z-4.978 F254
G1 X73.08 Y152.849 Z-4.999 F254
G1 X73.04 Y152.82 Z-5.019 F254
G1 X73.005 Y152.784 Z-5.039 F254
G1 X72.975 Y152.744 Z-5.06 F254
G1 X72.953 Y152.7 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X72.923 Y152.62 F254
G1 X72.857 Y152.461 F254
G1 X72.807 Y152.369 F254
G1 X72.788 Y152.333 F254
G1 X72.772 Y152.303 F254
G1 X72.766 Y152.287 F254
G1 X72.749 Y152.227 F254
G1 X72.741 Y152.166 F254
G1 X72.742 Y152.105 F254
; MOVEMENT_LEAD_OUT
G3 X72.964 Y151.902 I0.262 J0.065 F254
G3 X73.044 Y152.434 I0.04 J0.266 F254
G3 X72.772 Y152.303 I-0.04 J-0.266 F254
; MOVEMENT_CUTTING
G1 X72.755 Y152.263 F254
G1 X72.745 Y152.224 F254
G1 X72.74 Y152.184 F254
G1 X72.739 Y152.144 F254
G1 X72.742 Y152.105 F254
G1 X72.75 Y152.065 F254
G1 X72.764 Y152.025 F254
G1 X72.785 Y151.986 F254
G1 X72.807 Y151.953 F254
G1 X72.825 Y151.933 F254
G1 X72.847 Y151.912 F254
G1 X72.886 Y151.882 F254
G1 X72.926 Y151.861 F254
G1 X72.966 Y151.846 F254
G1 X73.005 Y151.837 F254
G1 X73.045 Y151.833 F254
G1 X73.085 Y151.834 F254
G1 X73.124 Y151.84 F254
G1 X74.71 Y152.123 F254
G1 X75.185 Y152.204 F254
G1 X75.344 Y152.22 F254
G1 X75.502 Y152.234 F254
G1 X75.653 Y152.255 F254
G1 X75.8 Y152.295 F254
G1 X75.941 Y152.352 F254
G1 X76.075 Y152.426 F254
G1 X76.199 Y152.514 F254
G1 X76.314 Y152.614 F254
G1 X76.419 Y152.725 F254
G1 X76.514 Y152.848 F254
G1 X76.619 Y153.007 F254
G1 X76.733 Y153.216 F254
G1 X76.764 Y153.288 F254
G1 X76.824 Y153.505 F254
G1 X76.815 Y153.729 F254
G1 X76.739 Y153.941 F254
G1 X76.604 Y154.12 F254
G1 X76.515 Y154.206 F254
G1 X76.453 Y154.274 F254
G1 X76.136 Y154.653 F254
G1 X76.119 Y154.682 F254
G1 X76.028 Y154.84 F254
G1 X76.006 Y154.886 F254
; MOVEMENT_LEAD_OUT
G1 X75.98 Y154.928 Z-5.06 F254
G1 X75.947 Y154.966 Z-5.039 F254
G1 X75.909 Y154.998 Z-5.019 F254
G1 X75.866 Y155.023 Z-4.999 F254
G1 X75.82 Y155.042 Z-4.978 F254
G1 X75.771 Y155.053 Z-4.958 F254
G1 X75.721 Y155.056 Z-4.938 F254
G1 X75.672 Y155.051 Z-4.917 F254
G1 X75.623 Y155.039 Z-4.897 F254
G1 X75.578 Y155.02 Z-4.877 F254
G3 X75.41 Y154.773 I0.148 J-0.281 F254
; MOVEMENT_LINK_DIRECT
G1 X75.191 Y152.78 F254
; MOVEMENT_LEAD_IN
G1 X75.17 Y152.586 F254
G3 X75.168 Y152.534 I0.316 J-0.035 F254
G1 X75.175 Y152.485 Z-4.897 F254
G1 X75.189 Y152.437 Z-4.917 F254
G1 X75.211 Y152.392 Z-4.938 F254
G1 X75.239 Y152.351 Z-4.958 F254
G1 X75.273 Y152.315 Z-4.978 F254
G1 X75.313 Y152.285 Z-4.999 F254
G1 X75.357 Y152.261 Z-5.019 F254
G1 X75.403 Y152.244 Z-5.039 F254
G1 X75.452 Y152.235 Z-5.06 F254
G1 X75.502 Y152.234 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X76.136 Y152.289 F254
G1 X76.295 Y152.301 F254
G1 X76.333 Y152.303 F254
G1 X76.485 Y152.318 F254
G1 X76.633 Y152.352 F254
G1 X76.776 Y152.406 F254
G1 X76.91 Y152.479 F254
G1 X77.034 Y152.567 F254
G1 X77.148 Y152.668 F254
G1 X77.181 Y152.706 F254
G1 X77.299 Y152.892 F254
G1 X77.357 Y153.104 F254
G1 X77.35 Y153.325 F254
G1 X77.279 Y153.533 F254
G1 X77.15 Y153.711 F254
G1 X76.974 Y153.844 F254
; MOVEMENT_LEAD_OUT
G1 X76.928 Y153.862 Z-5.06 F254
G1 X76.881 Y153.873 Z-5.04 F254
G1 X76.832 Y153.877 Z-5.02 F254
G1 X76.783 Y153.873 Z-5 F254
G1 X76.736 Y153.862 Z-4.98 F254
G1 X76.691 Y153.843 Z-4.96 F254
G1 X76.649 Y153.818 Z-4.941 F254
G1 X76.611 Y153.787 Z-4.921 F254
G1 X76.579 Y153.75 Z-4.901 F254
G1 X76.553 Y153.709 Z-4.881 F254
G1 X76.548 Y153.701 Z-4.877 F254
G1 X76.431 Y153.483 F254
; MOVEMENT_LINK_DIRECT
G1 X76.089 Y152.846 F254
; MOVEMENT_LEAD_IN
G1 X76.049 Y152.77 F254
G3 X76.011 Y152.616 I0.28 J-0.15 F254
G1 X76.016 Y152.566 Z-4.897 F254
G1 X76.028 Y152.518 Z-4.917 F254
G1 X76.048 Y152.472 Z-4.938 F254
G1 X76.074 Y152.43 Z-4.958 F254
G1 X76.107 Y152.393 Z-4.978 F254
G1 X76.146 Y152.361 Z-4.999 F254
G1 X76.188 Y152.335 Z-5.019 F254
G1 X76.235 Y152.317 Z-5.039 F254
G1 X76.283 Y152.306 Z-5.06 F254
G1 X76.333 Y152.303 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X76.771 Y152.323 F254
G1 X77.088 Y152.321 F254
G1 X77.24 Y152.328 F254
G1 X77.386 Y152.369 F254
G1 X77.56 Y152.494 F254
G1 X77.69 Y152.663 F254
G1 X77.764 Y152.863 F254
G1 X77.778 Y153.077 F254
G1 X77.729 Y153.284 F254
G1 X77.621 Y153.469 F254
G1 X77.465 Y153.614 F254
G1 X77.273 Y153.708 F254
; MOVEMENT_LEAD_OUT
G1 X77.224 Y153.717 Z-5.06 F254
G1 X77.174 Y153.719 Z-5.039 F254
G1 X77.125 Y153.713 Z-5.019 F254
G1 X77.077 Y153.699 Z-4.999 F254
G1 X77.032 Y153.678 Z-4.978 F254
G1 X76.991 Y153.651 Z-4.958 F254
G1 X76.954 Y153.617 Z-4.938 F254
G1 X76.923 Y153.578 Z-4.917 F254
G1 X76.899 Y153.534 Z-4.897 F254
G1 X76.882 Y153.487 Z-4.877 F254
G3 X76.872 Y153.438 I0.306 J-0.085 F254
G1 X76.85 Y153.242 F254
; MOVEMENT_LINK_DIRECT
G1 X76.811 Y152.897 F254
; MOVEMENT_LEAD_IN
G1 X76.786 Y152.674 F254
G3 X76.784 Y152.652 I0.315 J-0.036 F254
G1 X76.786 Y152.602 Z-4.897 F254
G1 X76.795 Y152.553 Z-4.917 F254
G1 X76.812 Y152.506 Z-4.938 F254
G1 X76.837 Y152.463 Z-4.958 F254
G1 X76.867 Y152.423 Z-4.978 F254
G1 X76.904 Y152.39 Z-4.999 F254
G1 X76.945 Y152.362 Z-5.019 F254
G1 X76.99 Y152.341 Z-5.039 F254
G1 X77.038 Y152.327 Z-5.06 F254
G1 X77.088 Y152.321 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X77.611 Y152.317 F254
G1 X77.763 Y152.324 F254
G1 X77.905 Y152.379 F254
G1 X78.064 Y152.533 F254
G1 X78.164 Y152.729 F254
G1 X78.197 Y152.948 F254
G1 X78.157 Y153.165 F254
G1 X78.05 Y153.358 F254
G1 X77.887 Y153.506 F254
G1 X77.685 Y153.595 F254
; MOVEMENT_LEAD_OUT
G1 X77.636 Y153.602 Z-5.06 F254
G1 X77.586 Y153.601 Z-5.039 F254
G1 X77.537 Y153.592 Z-5.019 F254
G1 X77.49 Y153.575 Z-4.999 F254
G1 X77.446 Y153.552 Z-4.978 F254
G1 X77.406 Y153.522 Z-4.958 F254
G1 X77.372 Y153.486 Z-4.938 F254
G1 X77.343 Y153.445 Z-4.917 F254
G1 X77.322 Y153.4 Z-4.897 F254
G1 X77.307 Y153.352 Z-4.877 F254
G3 X77.3 Y153.281 I0.31 J-0.068 F254
G1 X77.302 Y153.106 F254
; MOVEMENT_LINK_DIRECT
G1 X77.304 Y152.895 F254
; MOVEMENT_LEAD_IN
G1 X77.307 Y152.648 F254
G1 Y152.631 Z-4.884 F254
G1 X77.311 Y152.583 Z-4.903 F254
G1 X77.323 Y152.536 Z-4.923 F254
G1 X77.341 Y152.492 Z-4.942 F254
G1 X77.366 Y152.451 Z-4.962 F254
G1 X77.397 Y152.414 Z-4.982 F254
G1 X77.433 Y152.382 Z-5.001 F254
G1 X77.473 Y152.356 Z-5.021 F254
G1 X77.517 Y152.336 Z-5.041 F254
G1 X77.563 Y152.323 Z-5.06 F254
G1 X77.611 Y152.317 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X77.722 Y152.316 F254
G1 X77.88 Y152.309 F254
G1 X78.008 Y152.3 F254
G1 X78.16 Y152.296 F254
G1 X78.304 Y152.345 F254
G1 X78.432 Y152.428 F254
G1 X78.552 Y152.6 F254
G1 X78.612 Y152.802 F254
G1 X78.604 Y153.012 F254
G1 X78.53 Y153.209 F254
G1 X78.398 Y153.372 F254
G1 X78.221 Y153.485 F254
G1 X78.018 Y153.537 F254
; MOVEMENT_LEAD_OUT
G1 X77.973 Y153.536 Z-5.062 F254
G1 X77.93 Y153.529 Z-5.044 F254
G1 X77.864 Y153.509 Z-5.016 F254
G1 X77.801 Y153.483 Z-4.988 F254
G1 X77.742 Y153.449 Z-4.96 F254
G1 X77.686 Y153.41 Z-4.933 F254
G1 X77.635 Y153.364 Z-4.905 F254
G1 X77.589 Y153.314 Z-4.877 F254
G3 X77.583 Y152.536 I0.486 J-0.393 F254
; MOVEMENT_LEAD_IN
G1 X77.624 Y152.489 Z-4.902 F254
G1 X77.669 Y152.446 Z-4.928 F254
G1 X77.719 Y152.408 Z-4.953 F254
G1 X77.772 Y152.375 Z-4.978 F254
G1 X77.827 Y152.348 Z-5.004 F254
G1 X77.886 Y152.326 Z-5.029 F254
G1 X77.946 Y152.31 Z-5.055 F254
G1 X78.008 Y152.3 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X78.197 Y152.286 F254
G1 X78.356 Y152.273 F254
G1 X78.437 Y152.264 F254
G1 X78.589 Y152.256 F254
G1 X78.733 Y152.306 F254
G1 X78.859 Y152.392 F254
G1 X78.965 Y152.502 F254
G1 X79.049 Y152.7 F254
G1 X79.067 Y152.914 F254
G1 X79.019 Y153.123 F254
G1 X78.907 Y153.307 F254
G1 X78.745 Y153.447 F254
G1 X78.546 Y153.529 F254
G1 X78.332 Y153.547 F254
; MOVEMENT_LEAD_OUT
G3 X78.055 Y153.177 I0.036 J-0.315 F254
G1 X78.101 Y152.913 F254
; MOVEMENT_LINK_DIRECT
G1 X78.102 Y152.904 F254
; MOVEMENT_LEAD_IN
G1 X78.168 Y152.525 F254
G3 X78.437 Y152.264 I0.313 J0.054 F254
; MOVEMENT_CUTTING
G1 X78.879 Y152.218 F254
G1 X79.032 Y152.209 F254
G1 X79.176 Y152.257 F254
G1 X79.304 Y152.34 F254
G1 X79.411 Y152.448 F254
G1 X79.497 Y152.575 F254
G1 X79.559 Y152.714 F254
G1 X79.597 Y152.861 F254
G1 X79.614 Y153.013 F254
G1 X79.607 Y153.165 F254
G1 X79.58 Y153.315 F254
G1 X79.554 Y153.384 F254
G1 X79.521 Y153.45 F254
G1 X79.482 Y153.513 F254
; MOVEMENT_LEAD_OUT
G1 X79.448 Y153.55 Z-5.06 F254
G1 X79.41 Y153.581 Z-5.039 F254
G1 X79.367 Y153.607 Z-5.019 F254
G1 X79.321 Y153.625 Z-4.999 F254
G1 X79.272 Y153.635 Z-4.978 F254
G1 X79.222 Y153.638 Z-4.958 F254
G1 X79.173 Y153.633 Z-4.938 F254
G1 X79.125 Y153.621 Z-4.917 F254
G1 X79.079 Y153.601 Z-4.897 F254
G1 X79.037 Y153.574 Z-4.877 F254
G3 X78.932 Y153.435 I0.192 J-0.253 F254
G1 X78.907 Y153.369 F254
; MOVEMENT_LINK_DIRECT
G1 X78.693 Y152.811 F254
; MOVEMENT_LEAD_IN
G1 X78.629 Y152.646 F254
G3 X78.611 Y152.578 I0.296 J-0.114 F254
G1 X78.608 Y152.528 Z-4.897 F254
G1 X78.613 Y152.479 Z-4.917 F254
G1 X78.625 Y152.43 Z-4.938 F254
G1 X78.644 Y152.385 Z-4.958 F254
G1 X78.671 Y152.343 Z-4.978 F254
G1 X78.704 Y152.305 Z-4.999 F254
G1 X78.742 Y152.273 Z-5.019 F254
G1 X78.785 Y152.248 Z-5.039 F254
G1 X78.831 Y152.229 Z-5.06 F254
G1 X78.879 Y152.218 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X79.307 Y152.17 F254
G1 X79.459 Y152.154 F254
G1 X79.608 Y152.185 F254
G1 X79.761 Y152.287 F254
G1 X79.875 Y152.432 F254
G1 X79.937 Y152.606 F254
G1 X79.943 Y152.79 F254
G1 X79.89 Y152.967 F254
G1 X79.785 Y153.119 F254
; MOVEMENT_LEAD_OUT
G1 X79.745 Y153.154 Z-5.058 F254
G1 X79.7 Y153.186 Z-5.036 F254
G1 X79.653 Y153.212 Z-5.014 F254
G1 X79.603 Y153.234 Z-4.992 F254
G1 X79.551 Y153.25 Z-4.969 F254
G1 X79.498 Y153.261 Z-4.947 F254
G1 X79.441 Y153.267 Z-4.924 F254
G1 X79.383 Y153.266 Z-4.9 F254
G1 X79.326 Y153.26 Z-4.877 F254
G3 X78.923 Y152.461 I0.09 J-0.546 F254
; MOVEMENT_LEAD_IN
G1 X78.954 Y152.408 Z-4.902 F254
G1 X78.992 Y152.358 Z-4.928 F254
G1 X79.034 Y152.312 Z-4.953 F254
G1 X79.082 Y152.272 Z-4.978 F254
G1 X79.133 Y152.237 Z-5.004 F254
G1 X79.189 Y152.208 Z-5.029 F254
G1 X79.247 Y152.186 Z-5.055 F254
G1 X79.307 Y152.17 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X79.466 Y152.144 F254
G1 X79.711 Y152.1 F254
G1 X79.862 Y152.081 F254
G1 X80.015 Y152.147 F254
G1 X80.134 Y152.263 F254
G1 X80.203 Y152.415 F254
G1 X80.214 Y152.581 F254
G1 X80.165 Y152.74 F254
G1 X80.062 Y152.871 F254
; MOVEMENT_LEAD_OUT
G3 X79.872 Y152.956 I-0.253 J-0.307 F254
G3 X79.711 Y152.1 I-0.069 J-0.43 F254
; MOVEMENT_CUTTING
G1 X80.028 Y152.043 F254
G1 X80.18 Y152.023 F254
G1 X80.323 Y152.099 F254
G1 X80.42 Y152.229 F254
G1 X80.452 Y152.388 F254
G1 X80.413 Y152.545 F254
G1 X80.31 Y152.671 F254
; MOVEMENT_LEAD_OUT
G3 X80.247 Y152.708 I-0.209 J-0.287 F254
G3 X79.769 Y152.497 I-0.144 J-0.321 F254
G3 X80.028 Y152.043 I0.334 J-0.11 F254
; MOVEMENT_CUTTING
G1 X80.1 Y152.03 F254
G1 X80.179 Y152.019 F254
G1 X80.219 Y152.021 F254
G1 X80.258 Y152.027 F254
G1 X80.298 Y152.039 F254
G1 X80.338 Y152.057 F254
G1 X80.377 Y152.082 F254
G1 X80.417 Y152.117 F254
G1 X80.44 Y152.144 F254
G1 X80.469 Y152.184 F254
G1 X80.491 Y152.224 F254
G1 X80.505 Y152.263 F254
G1 X80.514 Y152.303 F254
G1 X80.518 Y152.342 F254
G1 X80.517 Y152.382 F254
G1 X80.511 Y152.422 F254
G1 X80.5 Y152.461 F254
G1 X80.486 Y152.493 F254
G1 X80.469 Y152.524 F254
G1 X80.446 Y152.555 F254
G1 X80.417 Y152.586 F254
G1 X80.376 Y152.62 F254
G1 X80.173 Y152.779 F254
G1 X80.1 Y152.838 F254
G1 X79.807 Y153.096 F254
G1 X79.783 Y153.121 F254
G1 X79.669 Y153.254 F254
G1 X79.624 Y153.31 F254
G1 X79.44 Y153.572 F254
G1 X79.389 Y153.639 F254
G1 X79.348 Y153.676 F254
G1 X79.307 Y153.706 F254
G1 X79.282 Y153.719 F254
G1 X79.257 Y153.73 F254
G1 X79.23 Y153.739 F254
G1 X79.203 Y153.746 F254
G1 X79.149 Y153.751 F254
G1 X79.119 F254
G1 X79.089 Y153.747 F254
G1 X79.059 Y153.74 F254
G1 X78.99 Y153.716 F254
G1 X78.831 Y153.665 F254
G1 X78.673 Y153.617 F254
; MOVEMENT_LEAD_OUT
G3 X78.466 Y153.245 I0.102 J-0.301 F254
G1 X78.484 Y153.208 Z-5.077 F254
G1 X78.503 Y153.173 Z-5.069 F254
G1 X78.521 Y153.138 Z-5.056 F254
G1 X78.538 Y153.106 Z-5.038 F254
G1 X78.567 Y153.086 Z-5.013 F254
G1 X78.594 Y153.067 Z-4.984 F254
G1 X78.617 Y153.052 Z-4.951 F254
G1 X78.636 Y153.039 Z-4.915 F254
G1 X78.651 Y153.029 Z-4.875 F254
G1 X78.662 Y153.022 Z-4.834 F254
G1 X78.667 Y153.018 Z-4.791 F254
G1 X78.669 Z-4.763 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X88.054 Y212.698 F254
G1 Z2.54 F254
; MOVEMENT_RAMP_HELIX
G1 X88.104 Y212.784 Z2.537 F25
G1 X88.148 Y212.874 Z2.533 F25
G1 X88.185 Y212.967 Z2.53 F25
G1 X88.214 Y213.062 Z2.526 F25
G1 X88.236 Y213.159 Z2.523 F25
G1 X88.25 Y213.258 Z2.519 F25
G1 X88.257 Y213.358 Z2.516 F25
G1 X88.255 Y213.458 Z2.512 F25
G1 X88.246 Y213.557 Z2.509 F25
G1 X88.229 Y213.656 Z2.505 F25
G1 X88.205 Y213.753 Z2.502 F25
G1 X88.173 Y213.847 Z2.498 F25
G1 X88.134 Y213.939 Z2.495 F25
G1 X88.087 Y214.028 Z2.491 F25
G1 X88.034 Y214.112 Z2.488 F25
G1 X87.975 Y214.193 Z2.484 F25
G1 X87.909 Y214.268 Z2.481 F25
G1 X87.838 Y214.338 Z2.477 F25
G1 X87.762 Y214.403 Z2.474 F25
G1 X87.681 Y214.461 Z2.47 F25
G1 X87.595 Y214.512 Z2.467 F25
G1 X87.506 Y214.557 Z2.463 F25
G1 X87.413 Y214.595 Z2.46 F25
G1 X87.318 Y214.626 Z2.456 F25
G1 X87.221 Y214.649 Z2.453 F25
G1 X87.122 Y214.664 Z2.449 F25
G1 X87.023 Y214.671 Z2.446 F25
G1 X86.923 Z2.442 F25
G1 X86.824 Y214.663 Z2.439 F25
G1 X86.725 Y214.648 Z2.435 F25
G1 X86.628 Y214.624 Z2.432 F25
G1 X86.533 Y214.594 Z2.428 F25
G1 X86.441 Y214.556 Z2.425 F25
G1 X86.352 Y214.511 Z2.421 F25
G1 X86.267 Y214.459 Z2.418 F25
G1 X86.186 Y214.4 Z2.414 F25
G1 X86.11 Y214.336 Z2.411 F25
G1 X86.039 Y214.266 Z2.407 F25
G1 X85.974 Y214.19 Z2.404 F25
G1 X85.915 Y214.11 Z2.4 F25
G1 X85.862 Y214.025 Z2.397 F25
G1 X85.816 Y213.936 Z2.393 F25
G1 X85.777 Y213.844 Z2.39 F25
G1 X85.746 Y213.75 Z2.386 F25
G1 X85.722 Y213.653 Z2.383 F25
G1 X85.705 Y213.555 Z2.38 F25
G1 X85.696 Y213.455 Z2.376 F25
G1 X85.695 Y213.355 Z2.373 F25
G1 X85.702 Y213.256 Z2.369 F25
G1 X85.717 Y213.157 Z2.366 F25
G1 X85.739 Y213.06 Z2.362 F25
G1 X85.768 Y212.965 Z2.359 F25
G1 X85.805 Y212.872 Z2.355 F25
G1 X85.849 Y212.783 Z2.352 F25
G1 X85.9 Y212.697 Z2.348 F25
G1 X85.957 Y212.615 Z2.345 F25
G1 X86.021 Y212.539 Z2.341 F25
G1 X86.09 Y212.467 Z2.338 F25
G1 X86.165 Y212.401 Z2.334 F25
G1 X86.244 Y212.341 Z2.331 F25
G1 X86.328 Y212.288 Z2.327 F25
G1 X86.416 Y212.241 Z2.324 F25
G1 X86.508 Y212.201 Z2.32 F25
G1 X86.602 Y212.168 Z2.317 F25
G1 X86.698 Y212.143 Z2.313 F25
G1 X86.796 Y212.125 Z2.31 F25
G1 X86.895 Y212.115 Z2.306 F25
G1 X86.995 Y212.113 Z2.303 F25
G1 X87.094 Y212.118 Z2.299 F25
G1 X87.193 Y212.132 Z2.296 F25
G1 X87.291 Y212.153 Z2.292 F25
G1 X87.386 Y212.181 Z2.289 F25
G1 X87.479 Y212.217 Z2.285 F25
G1 X87.569 Y212.26 Z2.282 F25
G1 X87.655 Y212.309 Z2.278 F25
G1 X87.737 Y212.366 Z2.275 F25
G1 X87.815 Y212.428 Z2.271 F25
G1 X87.887 Y212.497 Z2.268 F25
G1 X87.954 Y212.571 Z2.264 F25
G1 X88.015 Y212.649 Z2.261 F25
G1 X88.07 Y212.733 Z2.257 F25
G1 X88.118 Y212.82 Z2.254 F25
G1 X88.158 Y212.911 Z2.25 F25
G1 X88.192 Y213.004 Z2.247 F25
G1 X88.219 Y213.1 Z2.243 F25
G1 X88.237 Y213.198 Z2.24 F25
G1 X88.249 Y213.297 Z2.236 F25
G1 X88.252 Y213.396 Z2.233 F25
G1 X88.248 Y213.496 Z2.229 F25
G1 X88.236 Y213.594 Z2.226 F25
G1 X88.216 Y213.692 Z2.222 F25
G1 X88.189 Y213.788 Z2.219 F25
G1 X88.154 Y213.881 Z2.216 F25
G1 X88.112 Y213.971 Z2.212 F25
G1 X88.064 Y214.058 Z2.209 F25
G1 X88.008 Y214.141 Z2.205 F25
G1 X87.947 Y214.219 Z2.202 F25
G1 X87.879 Y214.292 Z2.198 F25
G1 X87.806 Y214.36 Z2.195 F25
G1 X87.728 Y214.422 Z2.191 F25
G1 X87.646 Y214.477 Z2.188 F25
G1 X87.559 Y214.526 Z2.184 F25
G1 X87.469 Y214.568 Z2.181 F25
G1 X87.376 Y214.603 Z2.177 F25
G1 X87.28 Y214.631 Z2.174 F25
G1 X87.183 Y214.651 Z2.17 F25
G1 X87.084 Y214.663 Z2.167 F25
G1 X86.985 Y214.667 Z2.163 F25
G1 X86.886 Y214.664 Z2.16 F25
G1 X86.787 Y214.653 Z2.156 F25
G1 X86.689 Y214.635 Z2.153 F25
G1 X86.593 Y214.609 Z2.149 F25
G1 X86.5 Y214.575 Z2.146 F25
G1 X86.409 Y214.535 Z2.142 F25
G1 X86.322 Y214.487 Z2.139 F25
G1 X86.238 Y214.433 Z2.135 F25
G1 X86.16 Y214.373 Z2.132 F25
G1 X86.086 Y214.306 Z2.128 F25
G1 X86.017 Y214.234 Z2.125 F25
G1 X85.955 Y214.157 Z2.121 F25
G1 X85.898 Y214.075 Z2.118 F25
G1 X85.848 Y213.989 Z2.114 F25
G1 X85.805 Y213.899 Z2.111 F25
G1 X85.769 Y213.807 Z2.107 F25
G1 X85.74 Y213.712 Z2.104 F25
G1 X85.719 Y213.615 Z2.1 F25
G1 X85.706 Y213.516 Z2.097 F25
G1 X85.7 Y213.417 Z2.093 F25
G1 X85.702 Y213.317 Z2.09 F25
G1 X85.712 Y213.219 Z2.086 F25
G1 X85.729 Y213.121 Z2.083 F25
G1 X85.754 Y213.025 Z2.079 F25
G1 X85.786 Y212.931 Z2.076 F25
G1 X85.826 Y212.84 Z2.072 F25
G1 X85.872 Y212.752 Z2.069 F25
G1 X85.925 Y212.668 Z2.065 F25
G1 X85.985 Y212.589 Z2.062 F25
G1 X86.05 Y212.514 Z2.059 F25
G1 X86.121 Y212.445 Z2.055 F25
G1 X86.198 Y212.381 Z2.052 F25
G1 X86.279 Y212.324 Z2.048 F25
G1 X86.364 Y212.273 Z2.045 F25
G1 X86.453 Y212.229 Z2.041 F25
G1 X86.545 Y212.192 Z2.038 F25
G1 X86.64 Y212.162 Z2.034 F25
G1 X86.736 Y212.14 Z2.031 F25
G1 X86.835 Y212.125 Z2.027 F25
G1 X86.934 Y212.118 Z2.024 F25
G1 X87.033 Y212.119 Z2.02 F25
G1 X87.132 Y212.127 Z2.017 F25
G1 X87.23 Y212.144 Z2.013 F25
G1 X87.326 Y212.167 Z2.01 F25
G1 X87.42 Y212.198 Z2.006 F25
G1 X87.512 Y212.237 Z2.003 F25
G1 X87.6 Y212.282 Z1.999 F25
G1 X87.685 Y212.334 Z1.996 F25
G1 X87.765 Y212.393 Z1.992 F25
G1 X87.84 Y212.457 Z1.989 F25
G1 X87.91 Y212.528 Z1.985 F25
G1 X87.974 Y212.603 Z1.982 F25
G1 X88.033 Y212.683 Z1.978 F25
G1 X88.084 Y212.768 Z1.975 F25
G1 X88.13 Y212.856 Z1.971 F25
G1 X88.168 Y212.948 Z1.968 F25
G1 X88.198 Y213.042 Z1.964 F25
G1 X88.222 Y213.138 Z1.961 F25
G1 X88.238 Y213.236 Z1.957 F25
G1 X88.246 Y213.335 Z1.954 F25
G1 Y213.434 Z1.95 F25
G1 X88.239 Y213.533 Z1.947 F25
G1 X88.224 Y213.631 Z1.943 F25
G1 X88.202 Y213.727 Z1.94 F25
G1 X88.172 Y213.822 Z1.936 F25
G1 X88.134 Y213.914 Z1.933 F25
G1 X88.09 Y214.003 Z1.929 F25
G1 X88.039 Y214.088 Z1.926 F25
G1 X87.982 Y214.168 Z1.922 F25
G1 X87.918 Y214.244 Z1.919 F25
G1 X87.849 Y214.315 Z1.915 F25
G1 X87.774 Y214.38 Z1.912 F25
G1 X87.694 Y214.44 Z1.908 F25
G1 X87.611 Y214.493 Z1.905 F25
G1 X87.523 Y214.539 Z1.902 F25
G1 X87.432 Y214.578 Z1.898 F25
G1 X87.338 Y214.61 Z1.895 F25
G1 X87.242 Y214.634 Z1.891 F25
G1 X87.145 Y214.651 Z1.888 F25
G1 X87.046 Y214.661 Z1.884 F25
G1 X86.947 Y214.662 Z1.881 F25
G1 X86.848 Y214.656 Z1.877 F25
G1 X86.75 Y214.642 Z1.874 F25
G1 X86.654 Y214.621 Z1.87 F25
G1 X86.559 Y214.592 Z1.867 F25
G1 X86.467 Y214.556 Z1.863 F25
G1 X86.377 Y214.513 Z1.86 F25
G1 X86.292 Y214.463 Z1.856 F25
G1 X86.211 Y214.407 Z1.853 F25
G1 X86.134 Y214.344 Z1.849 F25
G1 X86.062 Y214.276 Z1.846 F25
G1 X85.996 Y214.202 Z1.842 F25
G1 X85.936 Y214.123 Z1.839 F25
G1 X85.882 Y214.04 Z1.835 F25
G1 X85.835 Y213.953 Z1.832 F25
G1 X85.795 Y213.862 Z1.828 F25
G1 X85.762 Y213.769 Z1.825 F25
G1 X85.736 Y213.673 Z1.821 F25
G1 X85.718 Y213.576 Z1.818 F25
G1 X85.708 Y213.478 Z1.814 F25
G1 X85.705 Y213.379 Z1.811 F25
G1 X85.71 Y213.28 Z1.807 F25
G1 X85.722 Y213.182 Z1.804 F25
G1 X85.742 Y213.085 Z1.8 F25
G1 X85.77 Y212.99 Z1.797 F25
G1 X85.805 Y212.898 Z1.793 F25
G1 X85.847 Y212.808 Z1.79 F25
G1 X85.896 Y212.722 Z1.786 F25
G1 X85.951 Y212.64 Z1.783 F25
G1 X86.013 Y212.563 Z1.779 F25
G1 X86.08 Y212.491 Z1.776 F25
G1 X86.153 Y212.424 Z1.772 F25
G1 X86.231 Y212.363 Z1.769 F25
G1 X86.313 Y212.308 Z1.765 F25
G1 X86.4 Y212.26 Z1.762 F25
G1 X86.49 Y212.219 Z1.758 F25
G1 X86.582 Y212.184 Z1.755 F25
G1 X86.678 Y212.158 Z1.751 F25
G1 X86.775 Y212.138 Z1.748 F25
G1 X86.873 Y212.127 Z1.745 F25
G1 X86.972 Y212.123 Z1.741 F25
G1 X87.07 Y212.126 Z1.738 F25
G1 X87.169 Y212.138 Z1.734 F25
G1 X87.266 Y212.157 Z1.731 F25
G1 X87.361 Y212.183 Z1.727 F25
G1 X87.454 Y212.217 Z1.724 F25
G1 X87.544 Y212.258 Z1.72 F25
G1 X87.63 Y212.306 Z1.717 F25
G1 X87.713 Y212.36 Z1.713 F25
G1 X87.791 Y212.421 Z1.71 F25
G1 X87.864 Y212.487 Z1.706 F25
G1 X87.931 Y212.559 Z1.703 F25
G1 X87.993 Y212.636 Z1.699 F25
G1 X88.049 Y212.718 Z1.696 F25
G1 X88.098 Y212.803 Z1.692 F25
G1 X88.14 Y212.893 Z1.689 F25
G1 X88.176 Y212.985 Z1.685 F25
G1 X88.203 Y213.08 Z1.682 F25
G1 X88.224 Y213.176 Z1.678 F25
G1 X88.237 Y213.274 Z1.675 F25
G1 X88.242 Y213.373 Z1.671 F25
G1 X88.24 Y213.472 Z1.668 F25
G1 X88.229 Y213.57 Z1.664 F25
G1 X88.212 Y213.667 Z1.661 F25
G1 X88.186 Y213.763 Z1.657 F25
G1 X88.154 Y213.856 Z1.654 F25
G1 X88.114 Y213.946 Z1.65 F25
G1 X88.067 Y214.033 Z1.647 F25
G1 X88.014 Y214.116 Z1.643 F25
G1 X87.954 Y214.195 Z1.64 F25
G1 X87.888 Y214.269 Z1.636 F25
G1 X87.817 Y214.337 Z1.633 F25
G1 X87.741 Y214.4 Z1.629 F25
G1 X87.66 Y214.457 Z1.626 F25
G1 X87.575 Y214.507 Z1.622 F25
G1 X87.487 Y214.55 Z1.619 F25
G1 X87.395 Y214.586 Z1.615 F25
G1 X87.301 Y214.615 Z1.612 F25
G1 X87.204 Y214.637 Z1.608 F25
G1 X87.107 Y214.651 Z1.605 F25
G1 X87.008 Y214.657 Z1.601 F25
G1 X86.91 Y214.656 Z1.598 F25
G1 X86.811 Y214.647 Z1.594 F25
G1 X86.714 Y214.63 Z1.591 F25
G1 X86.618 Y214.606 Z1.587 F25
G1 X86.525 Y214.575 Z1.584 F25
G1 X86.434 Y214.536 Z1.581 F25
G1 X86.347 Y214.49 Z1.577 F25
G1 X86.263 Y214.438 Z1.574 F25
G1 X86.184 Y214.38 Z1.57 F25
G1 X86.109 Y214.315 Z1.567 F25
G1 X86.04 Y214.245 Z1.563 F25
G1 X85.976 Y214.169 Z1.56 F25
G1 X85.919 Y214.089 Z1.556 F25
G1 X85.868 Y214.005 Z1.553 F25
G1 X85.823 Y213.917 Z1.549 F25
G1 X85.786 Y213.825 Z1.546 F25
G1 X85.756 Y213.731 Z1.542 F25
G1 X85.733 Y213.635 Z1.539 F25
G1 X85.718 Y213.538 Z1.535 F25
G1 X85.71 Y213.44 Z1.532 F25
G1 Y213.341 Z1.528 F25
G1 X85.718 Y213.243 Z1.525 F25
G1 X85.734 Y213.146 Z1.521 F25
G1 X85.757 Y213.05 Z1.518 F25
G1 X85.787 Y212.956 Z1.514 F25
G1 X85.824 Y212.865 Z1.511 F25
G1 X85.869 Y212.777 Z1.507 F25
G1 X85.92 Y212.693 Z1.504 F25
G1 X85.978 Y212.613 Z1.5 F25
G1 X86.041 Y212.538 Z1.497 F25
G1 X86.111 Y212.468 Z1.493 F25
G1 X86.185 Y212.404 Z1.49 F25
G1 X86.265 Y212.345 Z1.486 F25
G1 X86.348 Y212.293 Z1.483 F25
G1 X86.436 Y212.248 Z1.479 F25
G1 X86.527 Y212.209 Z1.476 F25
G1 X86.62 Y212.178 Z1.472 F25
G1 X86.716 Y212.154 Z1.469 F25
G1 X86.813 Y212.138 Z1.465 F25
G1 X86.911 Y212.129 Z1.462 F25
G1 X87.009 Y212.128 Z1.458 F25
G1 X87.108 Y212.135 Z1.455 F25
G1 X87.205 Y212.149 Z1.451 F25
G1 X87.301 Y212.171 Z1.448 F25
G1 X87.395 Y212.2 Z1.444 F25
G1 X87.487 Y212.236 Z1.441 F25
G1 X87.575 Y212.279 Z1.437 F25
G1 X87.66 Y212.33 Z1.434 F25
G1 X87.74 Y212.386 Z1.43 F25
G1 X87.816 Y212.449 Z1.427 F25
G1 X87.887 Y212.517 Z1.424 F25
G1 X87.952 Y212.591 Z1.42 F25
G1 X88.011 Y212.669 Z1.417 F25
G1 X88.064 Y212.752 Z1.413 F25
G1 X88.111 Y212.839 Z1.41 F25
G1 X88.15 Y212.929 Z1.406 F25
G1 X88.182 Y213.022 Z1.403 F25
G1 X88.207 Y213.117 Z1.399 F25
G1 X88.225 Y213.214 Z1.396 F25
G1 X88.235 Y213.312 Z1.392 F25
G1 X88.237 Y213.411 Z1.389 F25
G1 X88.232 Y213.509 Z1.385 F25
G1 X88.219 Y213.606 Z1.382 F25
G1 X88.198 Y213.703 Z1.378 F25
G1 X88.17 Y213.797 Z1.375 F25
G1 X88.135 Y213.889 Z1.371 F25
G1 X88.092 Y213.978 Z1.368 F25
G1 X88.043 Y214.063 Z1.364 F25
G1 X87.988 Y214.144 Z1.361 F25
G1 X87.926 Y214.221 Z1.357 F25
G1 X87.859 Y214.292 Z1.354 F25
G1 X87.786 Y214.358 Z1.35 F25
G1 X87.708 Y214.418 Z1.347 F25
G1 X87.626 Y214.472 Z1.343 F25
G1 X87.54 Y214.52 Z1.34 F25
G1 X87.45 Y214.56 Z1.336 F25
G1 X87.358 Y214.593 Z1.333 F25
G1 X87.263 Y214.62 Z1.329 F25
G1 X87.166 Y214.638 Z1.326 F25
G1 X87.069 Y214.649 Z1.322 F25
G1 X86.971 Y214.653 Z1.319 F25
G1 X86.872 Y214.649 Z1.315 F25
G1 X86.775 Y214.637 Z1.312 F25
G1 X86.678 Y214.617 Z1.308 F25
G1 X86.584 Y214.59 Z1.305 F25
G1 X86.492 Y214.556 Z1.301 F25
G1 X86.403 Y214.515 Z1.298 F25
G1 X86.317 Y214.467 Z1.294 F25
G1 X86.235 Y214.412 Z1.291 F25
G1 X86.158 Y214.352 Z1.287 F25
G1 X86.085 Y214.285 Z1.284 F25
G1 X86.019 Y214.213 Z1.28 F25
G1 X85.958 Y214.136 Z1.277 F25
G1 X85.903 Y214.055 Z1.273 F25
G1 X85.854 Y213.969 Z1.27 F25
G1 X85.813 Y213.88 Z1.267 F25
G1 X85.778 Y213.788 Z1.263 F25
G1 X85.751 Y213.694 Z1.26 F25
G1 X85.731 Y213.598 Z1.256 F25
G1 X85.719 Y213.5 Z1.253 F25
G1 X85.714 Y213.402 Z1.249 F25
G1 X85.717 Y213.304 Z1.246 F25
G1 X85.728 Y213.207 Z1.242 F25
G1 X85.746 Y213.11 Z1.239 F25
G1 X85.772 Y213.015 Z1.235 F25
G1 X85.805 Y212.923 Z1.232 F25
G1 X85.845 Y212.833 Z1.228 F25
G1 X85.892 Y212.747 Z1.225 F25
G1 X85.946 Y212.665 Z1.221 F25
G1 X86.005 Y212.587 Z1.218 F25
G1 X86.071 Y212.514 Z1.214 F25
G1 X86.142 Y212.446 Z1.211 F25
G1 X86.218 Y212.384 Z1.207 F25
G1 X86.299 Y212.329 Z1.204 F25
G1 X86.384 Y212.279 Z1.2 F25
G1 X86.472 Y212.237 Z1.197 F25
G1 X86.564 Y212.201 Z1.193 F25
G1 X86.658 Y212.173 Z1.19 F25
G1 X86.754 Y212.152 Z1.186 F25
G1 X86.851 Y212.138 Z1.183 F25
G1 X86.949 Y212.133 Z1.179 F25
G1 X87.047 Y212.134 Z1.176 F25
G1 X87.144 Y212.144 Z1.172 F25
G1 X87.241 Y212.161 Z1.169 F25
G1 X87.336 Y212.185 Z1.165 F25
G1 X87.429 Y212.217 Z1.162 F25
G1 X87.519 Y212.256 Z1.158 F25
G1 X87.605 Y212.302 Z1.155 F25
G1 X87.688 Y212.354 Z1.151 F25
G1 X87.767 Y212.413 Z1.148 F25
G1 X87.84 Y212.478 Z1.144 F25
G1 X87.909 Y212.548 Z1.141 F25
G1 X87.971 Y212.623 Z1.137 F25
G1 X88.028 Y212.703 Z1.134 F25
G1 X88.078 Y212.788 Z1.13 F25
G1 X88.122 Y212.875 Z1.127 F25
G1 X88.159 Y212.966 Z1.123 F25
G1 X88.188 Y213.06 Z1.12 F25
G1 X88.21 Y213.155 Z1.116 F25
G1 X88.225 Y213.252 Z1.113 F25
G1 X88.232 Y213.35 Z1.11 F25
G1 X88.231 Y213.448 Z1.106 F25
G1 X88.223 Y213.546 Z1.103 F25
G1 X88.207 Y213.643 Z1.099 F25
G1 X88.183 Y213.738 Z1.096 F25
G1 X88.153 Y213.831 Z1.092 F25
G1 X88.115 Y213.921 Z1.089 F25
G1 X88.07 Y214.008 Z1.085 F25
G1 X88.019 Y214.092 Z1.082 F25
G1 X87.961 Y214.171 Z1.078 F25
G1 X87.897 Y214.245 Z1.075 F25
G1 X87.828 Y214.314 Z1.071 F25
G1 X87.754 Y214.378 Z1.068 F25
G1 X87.674 Y214.436 Z1.064 F25
G1 X87.591 Y214.487 Z1.061 F25
G1 X87.504 Y214.531 Z1.057 F25
G1 X87.413 Y214.569 Z1.054 F25
G1 X87.32 Y214.6 Z1.05 F25
G1 X87.225 Y214.623 Z1.047 F25
G1 X87.129 Y214.638 Z1.043 F25
G1 X87.031 Y214.647 Z1.04 F25
G1 X86.933 Z1.036 F25
G1 X86.835 Y214.64 Z1.033 F25
G1 X86.739 Y214.625 Z1.029 F25
G1 X86.643 Y214.603 Z1.026 F25
G1 X86.55 Y214.574 Z1.022 F25
G1 X86.459 Y214.537 Z1.019 F25
G1 X86.372 Y214.493 Z1.015 F25
G1 X86.288 Y214.443 Z1.012 F25
G1 X86.208 Y214.386 Z1.008 F25
G1 X86.133 Y214.323 Z1.005 F25
G1 X86.063 Y214.255 Z1.001 F25
G1 X85.998 Y214.181 Z0.998 F25
G1 X85.94 Y214.103 Z0.994 F25
G1 X85.888 Y214.02 Z0.991 F25
G1 X85.842 Y213.933 Z0.987 F25
G1 X85.803 Y213.844 Z0.984 F25
G1 X85.772 Y213.751 Z0.98 F25
G1 X85.747 Y213.656 Z0.977 F25
G1 X85.731 Y213.56 Z0.973 F25
G1 X85.721 Y213.463 Z0.97 F25
G1 X85.72 Y213.365 Z0.966 F25
G1 X85.726 Y213.267 Z0.963 F25
G1 X85.739 Y213.17 Z0.959 F25
G1 X85.76 Y213.075 Z0.956 F25
G1 X85.788 Y212.981 Z0.953 F25
G1 X85.824 Y212.89 Z0.949 F25
G1 X85.867 Y212.802 Z0.946 F25
G1 X85.916 Y212.718 Z0.942 F25
G1 X85.972 Y212.637 Z0.939 F25
G1 X86.033 Y212.562 Z0.935 F25
G1 X86.101 Y212.491 Z0.932 F25
G1 X86.174 Y212.426 Z0.928 F25
G1 X86.251 Y212.366 Z0.925 F25
G1 X86.334 Y212.313 Z0.921 F25
G1 X86.419 Y212.266 Z0.918 F25
G1 X86.509 Y212.227 Z0.914 F25
G1 X86.601 Y212.194 Z0.911 F25
G1 X86.695 Y212.169 Z0.907 F25
G1 X86.791 Y212.151 Z0.904 F25
G1 X86.888 Y212.14 Z0.9 F25
G1 X86.986 Y212.137 Z0.897 F25
G1 X87.084 Y212.142 Z0.893 F25
G1 X87.181 Y212.154 Z0.89 F25
G1 X87.276 Y212.174 Z0.886 F25
G1 X87.37 Y212.201 Z0.883 F25
G1 X87.461 Y212.236 Z0.879 F25
G1 X87.55 Y212.277 Z0.876 F25
G1 X87.635 Y212.325 Z0.872 F25
G1 X87.716 Y212.38 Z0.869 F25
G1 X87.792 Y212.441 Z0.865 F25
G1 X87.864 Y212.508 Z0.862 F25
G1 X87.93 Y212.58 Z0.858 F25
G1 X87.99 Y212.656 Z0.855 F25
G1 X88.044 Y212.738 Z0.851 F25
G1 X88.092 Y212.823 Z0.848 F25
G1 X88.132 Y212.912 Z0.844 F25
G1 X88.166 Y213.003 Z0.841 F25
G1 X88.193 Y213.097 Z0.837 F25
G1 X88.212 Y213.193 Z0.834 F25
G1 X88.223 Y213.29 Z0.83 F25
G1 X88.227 Y213.388 Z0.827 F25
G1 X88.224 Y213.485 Z0.823 F25
G1 X88.213 Y213.582 Z0.82 F25
G1 X88.194 Y213.678 Z0.816 F25
G1 X88.168 Y213.772 Z0.813 F25
G1 X88.135 Y213.864 Z0.809 F25
G1 X88.094 Y213.953 Z0.806 F25
G1 X88.047 Y214.038 Z0.802 F25
G1 X87.994 Y214.12 Z0.799 F25
G1 X87.934 Y214.197 Z0.795 F25
G1 X87.868 Y214.269 Z0.792 F25
G1 X87.797 Y214.336 Z0.789 F25
G1 X87.721 Y214.397 Z0.785 F25
G1 X87.64 Y214.452 Z0.782 F25
G1 X87.556 Y214.5 Z0.778 F25
G1 X87.468 Y214.542 Z0.775 F25
G1 X87.377 Y214.577 Z0.771 F25
G1 X87.283 Y214.604 Z0.768 F25
G1 X87.188 Y214.625 Z0.764 F25
G1 X87.091 Y214.638 Z0.761 F25
G1 X86.994 Y214.643 Z0.757 F25
G1 X86.896 Y214.64 Z0.754 F25
G1 X86.799 Y214.63 Z0.75 F25
G1 X86.703 Y214.613 Z0.747 F25
G1 X86.609 Y214.588 Z0.743 F25
G1 X86.517 Y214.556 Z0.74 F25
G1 X86.427 Y214.516 Z0.736 F25
G1 X86.341 Y214.47 Z0.733 F25
G1 X86.259 Y214.418 Z0.729 F25
G1 X86.181 Y214.359 Z0.726 F25
G1 X86.109 Y214.294 Z0.722 F25
G1 X86.041 Y214.224 Z0.719 F25
G1 X85.979 Y214.149 Z0.715 F25
G1 X85.923 Y214.069 Z0.712 F25
G1 X85.874 Y213.985 Z0.708 F25
G1 X85.831 Y213.898 Z0.705 F25
G1 X85.795 Y213.807 Z0.701 F25
G1 X85.766 Y213.714 Z0.698 F25
G1 X85.745 Y213.619 Z0.694 F25
G1 X85.731 Y213.522 Z0.691 F25
G1 X85.725 Y213.425 Z0.687 F25
G1 X85.726 Y213.328 Z0.684 F25
G1 X85.735 Y213.231 Z0.68 F25
G1 X85.751 Y213.135 Z0.677 F25
G1 X85.775 Y213.04 Z0.673 F25
G1 X85.806 Y212.948 Z0.67 F25
G1 X85.844 Y212.858 Z0.666 F25
G1 X85.889 Y212.772 Z0.663 F25
G1 X85.941 Y212.689 Z0.659 F25
G1 X85.998 Y212.611 Z0.656 F25
G1 X86.062 Y212.537 Z0.652 F25
G1 X86.132 Y212.469 Z0.649 F25
G1 X86.206 Y212.406 Z0.645 F25
G1 X86.285 Y212.349 Z0.642 F25
G1 X86.368 Y212.299 Z0.638 F25
G1 X86.455 Y212.255 Z0.635 F25
G1 X86.545 Y212.218 Z0.632 F25
G1 X86.638 Y212.188 Z0.628 F25
G1 X86.733 Y212.166 Z0.625 F25
G1 X86.829 Y212.151 Z0.621 F25
G1 X86.926 Y212.143 Z0.618 F25
G1 X87.023 Z0.614 F25
G1 X87.12 Y212.151 Z0.611 F25
G1 X87.216 Y212.166 Z0.607 F25
G1 X87.311 Y212.188 Z0.604 F25
G1 X87.403 Y212.218 Z0.6 F25
G1 X87.493 Y212.255 Z0.597 F25
G1 X87.58 Y212.299 Z0.593 F25
G1 X87.663 Y212.35 Z0.59 F25
G1 X87.742 Y212.407 Z0.586 F25
G1 X87.817 Y212.469 Z0.583 F25
G1 X87.886 Y212.538 Z0.579 F25
G1 X87.95 Y212.611 Z0.576 F25
G1 X88.007 Y212.69 Z0.572 F25
G1 X88.059 Y212.772 Z0.569 F25
G1 X88.104 Y212.859 Z0.565 F25
G1 X88.142 Y212.948 Z0.562 F25
G1 X88.172 Y213.041 Z0.558 F25
G1 X88.196 Y213.135 Z0.555 F25
G1 X88.212 Y213.231 Z0.551 F25
G1 X88.221 Y213.328 Z0.548 F25
G1 X88.222 Y213.425 Z0.544 F25
G1 X88.216 Y213.522 Z0.541 F25
G1 X88.202 Y213.618 Z0.537 F25
G1 X88.18 Y213.713 Z0.534 F25
G1 X88.151 Y213.806 Z0.53 F25
G1 X88.116 Y213.896 Z0.527 F25
G1 X88.073 Y213.983 Z0.523 F25
G1 X88.023 Y214.067 Z0.52 F25
G1 X87.968 Y214.147 Z0.516 F25
G1 X87.906 Y214.221 Z0.513 F25
G1 X87.838 Y214.291 Z0.509 F25
G1 X87.765 Y214.356 Z0.506 F25
G1 X87.688 Y214.414 Z0.502 F25
G1 X87.606 Y214.467 Z0.499 F25
G1 X87.52 Y214.513 Z0.495 F25
G1 X87.431 Y214.552 Z0.492 F25
G1 X87.34 Y214.584 Z0.488 F25
G1 X87.246 Y214.608 Z0.485 F25
G1 X87.15 Y214.626 Z0.481 F25
G1 X87.053 Y214.635 Z0.478 F25
G1 X86.956 Y214.638 Z0.475 F25
G1 X86.859 Y214.633 Z0.471 F25
G1 X86.763 Y214.62 Z0.468 F25
G1 X86.668 Y214.599 Z0.464 F25
G1 X86.575 Y214.572 Z0.461 F25
G1 X86.484 Y214.537 Z0.457 F25
G1 X86.396 Y214.495 Z0.454 F25
G1 X86.312 Y214.447 Z0.45 F25
G1 X86.232 Y214.392 Z0.447 F25
G1 X86.156 Y214.331 Z0.443 F25
G1 X86.086 Y214.265 Z0.44 F25
G1 X86.021 Y214.193 Z0.436 F25
G1 X85.961 Y214.116 Z0.433 F25
G1 X85.908 Y214.035 Z0.429 F25
G1 X85.861 Y213.95 Z0.426 F25
G1 X85.821 Y213.861 Z0.422 F25
G1 X85.788 Y213.77 Z0.419 F25
G1 X85.762 Y213.677 Z0.415 F25
G1 X85.744 Y213.581 Z0.412 F25
G1 X85.733 Y213.485 Z0.408 F25
G1 X85.729 Y213.388 Z0.405 F25
G1 X85.733 Y213.291 Z0.401 F25
G1 X85.745 Y213.195 Z0.398 F25
G1 X85.764 Y213.1 Z0.394 F25
G1 X85.791 Y213.006 Z0.391 F25
G1 X85.824 Y212.915 Z0.387 F25
G1 X85.865 Y212.827 Z0.384 F25
G1 X85.912 Y212.742 Z0.38 F25
G1 X85.966 Y212.662 Z0.377 F25
G1 X86.026 Y212.585 Z0.373 F25
G1 X86.092 Y212.514 Z0.37 F25
G1 X86.163 Y212.448 Z0.366 F25
G1 X86.239 Y212.387 Z0.363 F25
G1 X86.319 Y212.333 Z0.359 F25
G1 X86.403 Y212.285 Z0.356 F25
G1 X86.491 Y212.244 Z0.352 F25
G1 X86.582 Y212.21 Z0.349 F25
G1 X86.675 Y212.183 Z0.345 F25
G1 X86.77 Y212.164 Z0.342 F25
G1 X86.866 Y212.152 Z0.338 F25
G1 X86.963 Y212.147 Z0.335 F25
G1 X87.06 Y212.15 Z0.331 F25
G1 X87.156 Y212.16 Z0.328 F25
G1 X87.251 Y212.178 Z0.324 F25
G1 X87.345 Y212.204 Z0.321 F25
G1 X87.436 Y212.236 Z0.317 F25
G1 X87.525 Y212.276 Z0.314 F25
G1 X87.61 Y212.322 Z0.311 F25
G1 X87.691 Y212.375 Z0.307 F25
G1 X87.768 Y212.434 Z0.304 F25
G1 X87.84 Y212.499 Z0.3 F25
G1 X87.907 Y212.569 Z0.297 F25
G1 X87.968 Y212.644 Z0.293 F25
G1 X88.024 Y212.724 Z0.29 F25
G1 X88.072 Y212.807 Z0.286 F25
G1 X88.114 Y212.895 Z0.283 F25
G1 X88.15 Y212.985 Z0.279 F25
G1 X88.178 Y213.078 Z0.276 F25
G1 X88.198 Y213.172 Z0.272 F25
G1 X88.212 Y213.268 Z0.269 F25
G1 X88.217 Y213.365 Z0.265 F25
G1 X88.216 Y213.462 Z0.262 F25
G1 X88.206 Y213.558 Z0.258 F25
G1 X88.19 Y213.653 Z0.255 F25
G1 X88.165 Y213.747 Z0.251 F25
G1 X88.134 Y213.839 Z0.248 F25
G1 X88.096 Y213.928 Z0.244 F25
G1 X88.05 Y214.013 Z0.241 F25
G1 X87.999 Y214.095 Z0.237 F25
G1 X87.941 Y214.173 Z0.234 F25
G1 X87.877 Y214.245 Z0.23 F25
G1 X87.808 Y214.313 Z0.227 F25
G1 X87.733 Y214.375 Z0.223 F25
G1 X87.654 Y214.431 Z0.22 F25
G1 X87.571 Y214.481 Z0.216 F25
G1 X87.485 Y214.524 Z0.213 F25
G1 X87.395 Y214.56 Z0.209 F25
G1 X87.303 Y214.589 Z0.206 F25
G1 X87.208 Y214.611 Z0.202 F25
G1 X87.113 Y214.625 Z0.199 F25
G1 X87.016 Y214.632 Z0.195 F25
G1 X86.919 Z0.192 F25
G1 X86.823 Y214.624 Z0.188 F25
G1 X86.727 Y214.608 Z0.185 F25
G1 X86.633 Y214.585 Z0.181 F25
G1 X86.541 Y214.555 Z0.178 F25
G1 X86.452 Y214.517 Z0.174 F25
G1 X86.366 Y214.473 Z0.171 F25
G1 X86.284 Y214.423 Z0.167 F25
G1 X86.206 Y214.366 Z0.164 F25
G1 X86.132 Y214.303 Z0.16 F25
G1 X86.064 Y214.234 Z0.157 F25
G1 X86.001 Y214.161 Z0.154 F25
G1 X85.944 Y214.083 Z0.15 F25
G1 X85.893 Y214 Z0.147 F25
G1 X85.849 Y213.914 Z0.143 F25
G1 X85.812 Y213.825 Z0.14 F25
G1 X85.782 Y213.733 Z0.136 F25
G1 X85.759 Y213.639 Z0.133 F25
G1 X85.743 Y213.544 Z0.129 F25
G1 X85.735 Y213.448 Z0.126 F25
G1 Y213.351 Z0.122 F25
G1 X85.742 Y213.255 Z0.119 F25
G1 X85.756 Y213.159 Z0.115 F25
G1 X85.778 Y213.065 Z0.112 F25
G1 X85.807 Y212.973 Z0.108 F25
G1 X85.843 Y212.883 Z0.105 F25
G1 X85.886 Y212.796 Z0.101 F25
G1 X85.936 Y212.713 Z0.098 F25
G1 X85.992 Y212.635 Z0.094 F25
G1 X86.054 Y212.56 Z0.091 F25
G1 X86.122 Y212.491 Z0.087 F25
G1 X86.194 Y212.428 Z0.084 F25
G1 X86.272 Y212.37 Z0.08 F25
G1 X86.353 Y212.318 Z0.077 F25
G1 X86.439 Y212.273 Z0.073 F25
G1 X86.527 Y212.235 Z0.07 F25
G1 X86.619 Y212.204 Z0.066 F25
G1 X86.712 Y212.18 Z0.063 F25
G1 X86.807 Y212.163 Z0.059 F25
G1 X86.903 Y212.154 Z0.056 F25
G1 X87 Y212.152 Z0.052 F25
G1 X87.096 Y212.158 Z0.049 F25
G1 X87.192 Y212.171 Z0.045 F25
G1 X87.286 Y212.192 Z0.042 F25
G1 X87.379 Y212.22 Z0.038 F25
G1 X87.469 Y212.255 Z0.035 F25
G1 X87.556 Y212.297 Z0.031 F25
G1 X87.639 Y212.346 Z0.028 F25
G1 X87.718 Y212.401 Z0.024 F25
G1 X87.793 Y212.462 Z0.021 F25
G1 X87.863 Y212.528 Z0.017 F25
G1 X87.928 Y212.6 Z0.014 F25
G1 X87.986 Y212.677 Z0.01 F25
G1 X88.039 Y212.758 Z0.007 F25
G1 X88.085 Y212.843 Z0.003 F25
G1 X88.124 Y212.931 Z0 F25
G1 X88.157 Y213.022 Z-0.003 F25
G1 X88.182 Y213.115 Z-0.007 F25
G1 X88.199 Y213.21 Z-0.01 F25
G1 X88.21 Y213.305 Z-0.014 F25
G1 X88.213 Y213.402 Z-0.017 F25
G1 X88.208 Y213.498 Z-0.021 F25
G1 X88.196 Y213.594 Z-0.024 F25
G1 X88.176 Y213.688 Z-0.028 F25
G1 X88.15 Y213.781 Z-0.031 F25
G1 X88.116 Y213.871 Z-0.035 F25
G1 X88.075 Y213.958 Z-0.038 F25
G1 X88.027 Y214.042 Z-0.042 F25
G1 X87.973 Y214.122 Z-0.045 F25
G1 X87.913 Y214.198 Z-0.049 F25
G1 X87.848 Y214.268 Z-0.052 F25
G1 X87.777 Y214.334 Z-0.056 F25
G1 X87.701 Y214.393 Z-0.059 F25
G1 X87.62 Y214.447 Z-0.063 F25
G1 X87.536 Y214.494 Z-0.066 F25
G1 X87.449 Y214.534 Z-0.07 F25
G1 X87.358 Y214.567 Z-0.073 F25
G1 X87.265 Y214.594 Z-0.077 F25
G1 X87.171 Y214.613 Z-0.08 F25
G1 X87.075 Y214.624 Z-0.084 F25
G1 X86.979 Y214.628 Z-0.087 F25
G1 X86.882 Y214.625 Z-0.091 F25
G1 X86.787 Y214.614 Z-0.094 F25
G1 X86.692 Y214.595 Z-0.098 F25
G1 X86.599 Y214.57 Z-0.101 F25
G1 X86.509 Y214.537 Z-0.105 F25
G1 X86.421 Y214.497 Z-0.108 F25
G1 X86.337 Y214.451 Z-0.112 F25
G1 X86.256 Y214.398 Z-0.115 F25
G1 X86.18 Y214.339 Z-0.119 F25
G1 X86.109 Y214.274 Z-0.122 F25
G1 X86.043 Y214.204 Z-0.126 F25
G1 X85.983 Y214.129 Z-0.129 F25
G1 X85.928 Y214.049 Z-0.133 F25
G1 X85.88 Y213.966 Z-0.136 F25
G1 X85.839 Y213.879 Z-0.14 F25
G1 X85.804 Y213.789 Z-0.143 F25
G1 X85.777 Y213.696 Z-0.147 F25
G1 X85.757 Y213.602 Z-0.15 F25
G1 X85.744 Y213.507 Z-0.154 F25
G1 X85.739 Y213.411 Z-0.157 F25
G1 X85.741 Y213.314 Z-0.16 F25
G1 X85.751 Y213.218 Z-0.164 F25
G1 X85.769 Y213.124 Z-0.167 F25
G1 X85.793 Y213.031 Z-0.171 F25
G1 X85.825 Y212.94 Z-0.174 F25
G1 X85.864 Y212.852 Z-0.178 F25
G1 X85.909 Y212.767 Z-0.181 F25
G1 X85.961 Y212.686 Z-0.185 F25
G1 X86.019 Y212.609 Z-0.188 F25
G1 X86.083 Y212.537 Z-0.192 F25
G1 X86.152 Y212.47 Z-0.195 F25
G1 X86.226 Y212.409 Z-0.199 F25
G1 X86.305 Y212.354 Z-0.202 F25
G1 X86.388 Y212.305 Z-0.206 F25
G1 X86.474 Y212.262 Z-0.209 F25
G1 X86.564 Y212.227 Z-0.213 F25
G1 X86.655 Y212.199 Z-0.216 F25
G1 X86.749 Y212.177 Z-0.22 F25
G1 X86.844 Y212.164 Z-0.223 F25
G1 X86.94 Y212.157 Z-0.227 F25
G1 X87.037 Y212.158 Z-0.23 F25
G1 X87.132 Y212.167 Z-0.234 F25
G1 X87.227 Y212.183 Z-0.237 F25
G1 X87.321 Y212.207 Z-0.241 F25
G1 X87.412 Y212.237 Z-0.244 F25
G1 X87.5 Y212.275 Z-0.248 F25
G1 X87.586 Y212.319 Z-0.251 F25
G1 X87.667 Y212.37 Z-0.255 F25
G1 X87.745 Y212.427 Z-0.258 F25
G1 X87.817 Y212.49 Z-0.262 F25
G1 X87.885 Y212.559 Z-0.265 F25
G1 X87.947 Y212.632 Z-0.269 F25
G1 X88.003 Y212.71 Z-0.272 F25
G1 X88.053 Y212.792 Z-0.276 F25
G1 X88.096 Y212.878 Z-0.279 F25
G1 X88.133 Y212.967 Z-0.283 F25
G1 X88.162 Y213.058 Z-0.286 F25
G1 X88.185 Y213.152 Z-0.29 F25
G1 X88.199 Y213.247 Z-0.293 F25
G1 X88.207 Y213.342 Z-0.297 F25
G1 Y213.438 Z-0.3 F25
G1 X88.199 Y213.534 Z-0.304 F25
G1 X88.185 Y213.629 Z-0.307 F25
G1 X88.162 Y213.723 Z-0.311 F25
G1 X88.133 Y213.814 Z-0.314 F25
G1 X88.096 Y213.903 Z-0.317 F25
G1 X88.053 Y213.989 Z-0.321 F25
G1 X88.003 Y214.071 Z-0.324 F25
G1 X87.947 Y214.149 Z-0.328 F25
G1 X87.885 Y214.222 Z-0.331 F25
G1 X87.818 Y214.29 Z-0.335 F25
G1 X87.745 Y214.353 Z-0.338 F25
G1 X87.668 Y214.41 Z-0.342 F25
G1 X87.586 Y214.461 Z-0.345 F25
G1 X87.501 Y214.505 Z-0.349 F25
G1 X87.413 Y214.543 Z-0.352 F25
G1 X87.321 Y214.574 Z-0.356 F25
G1 X87.228 Y214.597 Z-0.359 F25
G1 X87.134 Y214.613 Z-0.363 F25
G1 X87.038 Y214.622 Z-0.366 F25
G1 X86.942 Y214.623 Z-0.37 F25
G1 X86.846 Y214.617 Z-0.373 F25
G1 X86.751 Y214.603 Z-0.377 F25
G1 X86.658 Y214.582 Z-0.38 F25
G1 X86.566 Y214.553 Z-0.384 F25
G1 X86.477 Y214.518 Z-0.387 F25
G1 X86.391 Y214.476 Z-0.391 F25
G1 X86.308 Y214.427 Z-0.394 F25
G1 X86.23 Y214.372 Z-0.398 F25
G1 X86.156 Y214.311 Z-0.401 F25
G1 X86.087 Y214.244 Z-0.405 F25
G1 X86.023 Y214.173 Z-0.408 F25
G1 X85.965 Y214.096 Z-0.412 F25
G1 X85.913 Y214.015 Z-0.415 F25
G1 X85.868 Y213.931 Z-0.419 F25
G1 X85.829 Y213.843 Z-0.422 F25
G1 X85.798 Y213.752 Z-0.426 F25
G1 X85.773 Y213.659 Z-0.429 F25
G1 X85.756 Y213.565 Z-0.433 F25
G1 X85.746 Y213.47 Z-0.436 F25
G1 X85.744 Y213.374 Z-0.44 F25
G1 X85.749 Y213.278 Z-0.443 F25
G1 X85.762 Y213.183 Z-0.447 F25
G1 X85.782 Y213.089 Z-0.45 F25
G1 X85.809 Y212.997 Z-0.454 F25
G1 X85.843 Y212.907 Z-0.457 F25
G1 X85.884 Y212.821 Z-0.461 F25
G1 X85.932 Y212.738 Z-0.464 F25
G1 X85.986 Y212.659 Z-0.468 F25
G1 X86.046 Y212.584 Z-0.471 F25
G1 X86.112 Y212.514 Z-0.475 F25
G1 X86.183 Y212.45 Z-0.478 F25
G1 X86.259 Y212.391 Z-0.481 F25
G1 X86.339 Y212.339 Z-0.485 F25
G1 X86.423 Y212.292 Z-0.488 F25
G1 X86.51 Y212.253 Z-0.492 F25
G1 X86.6 Y212.22 Z-0.495 F25
G1 X86.692 Y212.194 Z-0.499 F25
G1 X86.786 Y212.176 Z-0.502 F25
G1 X86.881 Y212.165 Z-0.506 F25
G1 X86.977 Y212.162 Z-0.509 F25
G1 X87.073 Y212.166 Z-0.513 F25
G1 X87.168 Y212.177 Z-0.516 F25
G1 X87.262 Y212.196 Z-0.52 F25
G1 X87.354 Y212.222 Z-0.523 F25
G1 X87.444 Y212.255 Z-0.527 F25
G1 X87.531 Y212.295 Z-0.53 F25
G1 X87.615 Y212.342 Z-0.534 F25
G1 X87.695 Y212.395 Z-0.537 F25
G1 X87.77 Y212.454 Z-0.541 F25
G1 X87.84 Y212.519 Z-0.544 F25
G1 X87.906 Y212.589 Z-0.548 F25
G1 X87.965 Y212.664 Z-0.551 F25
G1 X88.019 Y212.743 Z-0.555 F25
G1 X88.066 Y212.827 Z-0.558 F25
G1 X88.107 Y212.913 Z-0.562 F25
G1 X88.14 Y213.003 Z-0.565 F25
G1 X88.167 Y213.095 Z-0.569 F25
G1 X88.186 Y213.189 Z-0.572 F25
G1 X88.198 Y213.283 Z-0.576 F25
G1 X88.203 Y213.379 Z-0.579 F25
G1 X88.2 Y213.475 Z-0.583 F25
G1 X88.19 Y213.57 Z-0.586 F25
G1 X88.172 Y213.664 Z-0.59 F25
G1 X88.147 Y213.756 Z-0.593 F25
G1 X88.115 Y213.846 Z-0.597 F25
G1 X88.076 Y213.934 Z-0.6 F25
G1 X88.03 Y214.018 Z-0.604 F25
G1 X87.978 Y214.098 Z-0.607 F25
G1 X87.92 Y214.174 Z-0.611 F25
G1 X87.856 Y214.245 Z-0.614 F25
G1 X87.787 Y214.312 Z-0.618 F25
G1 X87.713 Y214.372 Z-0.621 F25
G1 X87.634 Y214.426 Z-0.625 F25
G1 X87.552 Y214.475 Z-0.628 F25
G1 X87.465 Y214.516 Z-0.632 F25
G1 X87.376 Y214.551 Z-0.635 F25
G1 X87.285 Y214.579 Z-0.638 F25
G1 X87.191 Y214.599 Z-0.642 F25
G1 X87.097 Y214.612 Z-0.645 F25
G1 X87.001 Y214.618 Z-0.649 F25
G1 X86.906 Y214.616 Z-0.652 F25
G1 X86.811 Y214.607 Z-0.656 F25
G1 X86.717 Y214.591 Z-0.659 F25
G1 X86.624 Y214.567 Z-0.663 F25
G1 X86.534 Y214.536 Z-0.666 F25
G1 X86.446 Y214.498 Z-0.67 F25
G1 X86.361 Y214.454 Z-0.673 F25
G1 X86.281 Y214.403 Z-0.677 F25
G1 X86.204 Y214.345 Z-0.68 F25
G1 X86.132 Y214.282 Z-0.684 F25
G1 X86.065 Y214.214 Z-0.687 F25
G1 X86.004 Y214.141 Z-0.691 F25
G1 X85.949 Y214.063 Z-0.694 F25
G1 X85.9 Y213.981 Z-0.698 F25
G1 X85.857 Y213.895 Z-0.701 F25
G1 X85.821 Y213.807 Z-0.705 F25
G1 X85.792 Y213.716 Z-0.708 F25
G1 X85.771 Y213.623 Z-0.712 F25
G1 X85.756 Y213.528 Z-0.715 F25
G1 X85.749 Y213.433 Z-0.719 F25
G1 X85.75 Y213.337 Z-0.722 F25
G1 X85.758 Y213.242 Z-0.726 F25
G1 X85.773 Y213.148 Z-0.729 F25
G1 X85.796 Y213.055 Z-0.733 F25
G1 X85.826 Y212.964 Z-0.736 F25
G1 X85.863 Y212.876 Z-0.74 F25
G1 X85.906 Y212.791 Z-0.743 F25
G1 X85.956 Y212.71 Z-0.747 F25
G1 X86.012 Y212.633 Z-0.75 F25
G1 X86.074 Y212.56 Z-0.754 F25
G1 X86.142 Y212.493 Z-0.757 F25
G1 X86.214 Y212.431 Z-0.761 F25
G1 X86.291 Y212.374 Z-0.764 F25
G1 X86.373 Y212.324 Z-0.768 F25
G1 X86.458 Y212.281 Z-0.771 F25
G1 X86.546 Y212.244 Z-0.775 F25
G1 X86.636 Y212.214 Z-0.778 F25
G1 X86.729 Y212.191 Z-0.782 F25
G1 X86.823 Y212.176 Z-0.785 F25
G1 X86.918 Y212.168 Z-0.789 F25
G1 X87.014 Y212.167 Z-0.792 F25
G1 X87.109 Y212.174 Z-0.795 F25
G1 X87.203 Y212.188 Z-0.799 F25
G1 X87.296 Y212.21 Z-0.802 F25
G1 X87.387 Y212.239 Z-0.806 F25
G1 X87.476 Y212.274 Z-0.809 F25
G1 X87.561 Y212.317 Z-0.813 F25
G1 X87.643 Y212.366 Z-0.816 F25
G1 X87.721 Y212.421 Z-0.82 F25
G1 X87.794 Y212.482 Z-0.823 F25
G1 X87.862 Y212.549 Z-0.827 F25
G1 X87.925 Y212.62 Z-0.83 F25
G1 X87.982 Y212.697 Z-0.834 F25
G1 X88.033 Y212.777 Z-0.837 F25
G1 X88.078 Y212.862 Z-0.841 F25
G1 X88.116 Y212.949 Z-0.844 F25
G1 X88.147 Y213.039 Z-0.848 F25
G1 X88.17 Y213.131 Z-0.851 F25
G1 X88.187 Y213.225 Z-0.855 F25
G1 X88.196 Y213.32 Z-0.858 F25
G1 X88.198 Y213.416 Z-0.862 F25
G1 X88.192 Y213.511 Z-0.865 F25
G1 X88.179 Y213.605 Z-0.869 F25
G1 X88.159 Y213.698 Z-0.872 F25
G1 X88.131 Y213.789 Z-0.876 F25
G1 X88.096 Y213.878 Z-0.879 F25
G1 X88.055 Y213.964 Z-0.883 F25
G1 X88.007 Y214.047 Z-0.886 F25
G1 X87.953 Y214.125 Z-0.89 F25
G1 X87.893 Y214.199 Z-0.893 F25
G1 X87.827 Y214.268 Z-0.897 F25
G1 X87.756 Y214.332 Z-0.9 F25
G1 X87.68 Y214.39 Z-0.904 F25
G1 X87.6 Y214.442 Z-0.907 F25
G1 X87.517 Y214.487 Z-0.911 F25
G1 X87.43 Y214.526 Z-0.914 F25
G1 X87.34 Y214.558 Z-0.918 F25
G1 X87.248 Y214.583 Z-0.921 F25
G1 X87.155 Y214.6 Z-0.925 F25
G1 X87.06 Y214.611 Z-0.928 F25
G1 X86.965 Y214.613 Z-0.932 F25
G1 X86.87 Y214.609 Z-0.935 F25
G1 X86.775 Y214.597 Z-0.939 F25
G1 X86.682 Y214.578 Z-0.942 F25
G1 X86.591 Y214.551 Z-0.946 F25
G1 X86.502 Y214.518 Z-0.949 F25
G1 X86.415 Y214.478 Z-0.953 F25
G1 X86.333 Y214.431 Z-0.956 F25
G1 X86.254 Y214.377 Z-0.959 F25
G1 X86.179 Y214.318 Z-0.963 F25
G1 X86.109 Y214.253 Z-0.966 F25
G1 X86.045 Y214.183 Z-0.97 F25
G1 X85.986 Y214.109 Z-0.973 F25
G1 X85.933 Y214.029 Z-0.977 F25
G1 X85.887 Y213.946 Z-0.98 F25
G1 X85.847 Y213.86 Z-0.984 F25
G1 X85.814 Y213.771 Z-0.987 F25
G1 X85.788 Y213.679 Z-0.991 F25
G1 X85.769 Y213.586 Z-0.994 F25
G1 X85.758 Y213.491 Z-0.998 F25
G1 X85.754 Y213.396 Z-1.001 F25
G1 X85.757 Y213.301 Z-1.005 F25
G1 X85.768 Y213.207 Z-1.008 F25
G1 X85.786 Y213.113 Z-1.012 F25
G1 X85.811 Y213.022 Z-1.015 F25
G1 X85.844 Y212.932 Z-1.019 F25
G1 X85.883 Y212.846 Z-1.022 F25
G1 X85.929 Y212.762 Z-1.026 F25
G1 X85.981 Y212.683 Z-1.029 F25
G1 X86.039 Y212.608 Z-1.033 F25
G1 X86.103 Y212.537 Z-1.036 F25
G1 X86.172 Y212.472 Z-1.04 F25
G1 X86.246 Y212.412 Z-1.043 F25
G1 X86.325 Y212.359 Z-1.047 F25
G1 X86.407 Y212.311 Z-1.05 F25
G1 X86.493 Y212.27 Z-1.054 F25
G1 X86.582 Y212.236 Z-1.057 F25
G1 X86.673 Y212.209 Z-1.061 F25
G1 X86.766 Y212.19 Z-1.064 F25
G1 X86.86 Y212.177 Z-1.068 F25
G1 X86.955 Y212.172 Z-1.071 F25
G1 X87.05 Y212.174 Z-1.075 F25
G1 X87.145 Y212.184 Z-1.078 F25
G1 X87.238 Y212.201 Z-1.082 F25
G1 X87.33 Y212.225 Z-1.085 F25
G1 X87.42 Y212.256 Z-1.089 F25
G1 X87.507 Y212.294 Z-1.092 F25
G1 X87.591 Y212.339 Z-1.096 F25
G1 X87.671 Y212.39 Z-1.099 F25
G1 X87.746 Y212.447 Z-1.103 F25
G1 X87.817 Y212.51 Z-1.106 F25
G1 X87.883 Y212.579 Z-1.11 F25
G1 X87.944 Y212.652 Z-1.113 F25
G1 X87.998 Y212.73 Z-1.116 F25
G1 X88.047 Y212.811 Z-1.12 F25
G1 X88.089 Y212.897 Z-1.123 F25
G1 X88.124 Y212.985 Z-1.127 F25
G1 X88.152 Y213.075 Z-1.13 F25
G1 X88.173 Y213.168 Z-1.134 F25
G1 X88.186 Y213.262 Z-1.137 F25
G1 X88.193 Y213.357 Z-1.141 F25
G1 X88.192 Y213.452 Z-1.144 F25
G1 X88.183 Y213.546 Z-1.148 F25
G1 X88.167 Y213.64 Z-1.151 F25
G1 X88.144 Y213.732 Z-1.155 F25
G1 X88.114 Y213.822 Z-1.158 F25
G1 X88.077 Y213.91 Z-1.162 F25
G1 X88.033 Y213.994 Z-1.165 F25
G1 X87.983 Y214.074 Z-1.169 F25
G1 X87.927 Y214.151 Z-1.172 F25
G1 X87.865 Y214.223 Z-1.176 F25
G1 X87.797 Y214.289 Z-1.179 F25
G1 X87.722 Y214.353 Z-1.183 F25
G1 X87.641 Y214.41 Z-1.187 F25
G1 X87.557 Y214.461 Z-1.19 F25
G1 X87.468 Y214.504 Z-1.194 F25
G1 X87.377 Y214.541 Z-1.197 F25
G1 X87.282 Y214.569 Z-1.201 F25
G1 X87.186 Y214.59 Z-1.205 F25
G1 X87.088 Y214.603 Z-1.208 F25
G1 X86.99 Y214.608 Z-1.212 F25
G1 X86.891 Y214.606 Z-1.216 F25
G1 X86.793 Y214.595 Z-1.219 F25
G1 X86.696 Y214.576 Z-1.223 F25
G1 X86.601 Y214.55 Z-1.226 F25
G1 X86.509 Y214.515 Z-1.23 F25
G1 X86.419 Y214.474 Z-1.234 F25
G1 X86.333 Y214.425 Z-1.237 F25
G1 X86.252 Y214.37 Z-1.241 F25
G1 X86.175 Y214.308 Z-1.245 F25
G1 X86.103 Y214.24 Z-1.248 F25
G1 X86.037 Y214.167 Z-1.252 F25
G1 X85.978 Y214.088 Z-1.255 F25
G1 X85.925 Y214.005 Z-1.259 F25
G1 X85.878 Y213.918 Z-1.263 F25
G1 X85.839 Y213.828 Z-1.266 F25
G1 X85.808 Y213.734 Z-1.27 F25
G1 X85.784 Y213.639 Z-1.274 F25
G1 X85.768 Y213.541 Z-1.277 F25
G1 X85.76 Y213.443 Z-1.281 F25
G1 X85.759 Y213.345 Z-1.285 F25
G1 X85.767 Y213.247 Z-1.288 F25
G1 X85.783 Y213.149 Z-1.292 F25
G1 X85.807 Y213.054 Z-1.295 F25
G1 X85.838 Y212.96 Z-1.299 F25
G1 X85.876 Y212.87 Z-1.303 F25
G1 X85.922 Y212.783 Z-1.306 F25
G1 X85.975 Y212.7 Z-1.31 F25
G1 X86.034 Y212.621 Z-1.314 F25
G1 X86.1 Y212.547 Z-1.317 F25
G1 X86.171 Y212.479 Z-1.321 F25
G1 X86.248 Y212.417 Z-1.324 F25
G1 X86.329 Y212.362 Z-1.328 F25
G1 X86.415 Y212.313 Z-1.332 F25
G1 X86.504 Y212.271 Z-1.335 F25
G1 X86.596 Y212.237 Z-1.339 F25
G1 X86.691 Y212.21 Z-1.343 F25
G1 X86.788 Y212.191 Z-1.346 F25
G1 X86.885 Y212.18 Z-1.35 F25
G1 X86.984 Y212.177 Z-1.353 F25
G1 X87.082 Y212.181 Z-1.357 F25
G1 X87.18 Y212.194 Z-1.361 F25
G1 X87.276 Y212.215 Z-1.364 F25
G1 X87.37 Y212.243 Z-1.368 F25
G1 X87.462 Y212.279 Z-1.372 F25
G1 X87.55 Y212.322 Z-1.375 F25
G1 X87.635 Y212.372 Z-1.379 F25
G1 X87.715 Y212.429 Z-1.382 F25
G1 X87.791 Y212.492 Z-1.386 F25
G1 X87.861 Y212.561 Z-1.39 F25
G1 X87.925 Y212.636 Z-1.393 F25
G1 X87.983 Y212.715 Z-1.397 F25
G1 X88.034 Y212.799 Z-1.401 F25
G1 X88.079 Y212.887 Z-1.404 F25
G1 X88.116 Y212.978 Z-1.408 F25
G1 X88.146 Y213.072 Z-1.412 F25
G1 X88.167 Y213.167 Z-1.415 F25
G1 X88.182 Y213.265 Z-1.419 F25
G1 X88.188 Y213.363 Z-1.422 F25
G1 X88.186 Y213.461 Z-1.426 F25
G1 X88.176 Y213.559 Z-1.43 F25
G1 X88.159 Y213.656 Z-1.433 F25
G1 X88.133 Y213.751 Z-1.437 F25
G1 X88.1 Y213.844 Z-1.441 F25
G1 X88.06 Y213.933 Z-1.444 F25
G1 X88.012 Y214.019 Z-1.448 F25
G1 X87.958 Y214.101 Z-1.451 F25
G1 X87.897 Y214.179 Z-1.455 F25
G1 X87.831 Y214.251 Z-1.459 F25
G1 X87.758 Y214.317 Z-1.462 F25
G1 X87.681 Y214.377 Z-1.466 F25
G1 X87.599 Y214.431 Z-1.47 F25
G1 X87.512 Y214.478 Z-1.473 F25
G1 X87.423 Y214.518 Z-1.477 F25
G1 X87.33 Y214.551 Z-1.48 F25
G1 X87.235 Y214.576 Z-1.484 F25
G1 X87.138 Y214.593 Z-1.488 F25
G1 X87.04 Y214.602 Z-1.491 F25
G1 X86.942 Y214.603 Z-1.495 F25
G1 X86.844 Y214.596 Z-1.499 F25
G1 X86.747 Y214.582 Z-1.502 F25
G1 X86.651 Y214.559 Z-1.506 F25
G1 X86.558 Y214.529 Z-1.509 F25
G1 X86.467 Y214.492 Z-1.513 F25
G1 X86.38 Y214.447 Z-1.517 F25
G1 X86.296 Y214.395 Z-1.52 F25
G1 X86.217 Y214.337 Z-1.524 F25
G1 X86.143 Y214.272 Z-1.528 F25
G1 X86.074 Y214.202 Z-1.531 F25
G1 X86.012 Y214.127 Z-1.535 F25
G1 X85.955 Y214.046 Z-1.539 F25
G1 X85.906 Y213.961 Z-1.542 F25
G1 X85.863 Y213.873 Z-1.546 F25
G1 X85.828 Y213.781 Z-1.549 F25
G1 X85.8 Y213.687 Z-1.553 F25
G1 X85.78 Y213.591 Z-1.557 F25
G1 X85.768 Y213.494 Z-1.56 F25
G1 X85.763 Y213.396 Z-1.564 F25
G1 X85.767 Y213.298 Z-1.568 F25
G1 X85.779 Y213.2 Z-1.571 F25
G1 X85.798 Y213.104 Z-1.575 F25
G1 X85.825 Y213.01 Z-1.578 F25
G1 X85.86 Y212.918 Z-1.582 F25
G1 X85.902 Y212.83 Z-1.586 F25
G1 X85.951 Y212.745 Z-1.589 F25
G1 X86.007 Y212.664 Z-1.593 F25
G1 X86.069 Y212.588 Z-1.597 F25
G1 X86.137 Y212.517 Z-1.6 F25
G1 X86.211 Y212.452 Z-1.604 F25
G1 X86.289 Y212.394 Z-1.607 F25
G1 X86.372 Y212.342 Z-1.611 F25
G1 X86.459 Y212.296 Z-1.615 F25
G1 X86.55 Y212.258 Z-1.618 F25
G1 X86.643 Y212.228 Z-1.622 F25
G1 X86.738 Y212.205 Z-1.626 F25
G1 X86.835 Y212.189 Z-1.629 F25
G1 X86.933 Y212.182 Z-1.633 F25
G1 X87.031 Y212.183 Z-1.636 F25
G1 X87.129 Y212.191 Z-1.64 F25
G1 X87.225 Y212.208 Z-1.644 F25
G1 X87.32 Y212.232 Z-1.647 F25
G1 X87.413 Y212.264 Z-1.651 F25
G1 X87.503 Y212.303 Z-1.655 F25
G1 X87.589 Y212.349 Z-1.658 F25
G1 X87.671 Y212.403 Z-1.662 F25
G1 X87.749 Y212.462 Z-1.666 F25
G1 X87.822 Y212.528 Z-1.669 F25
G1 X87.889 Y212.6 Z-1.673 F25
G1 X87.95 Y212.676 Z-1.676 F25
G1 X88.004 Y212.758 Z-1.68 F25
G1 X88.052 Y212.843 Z-1.684 F25
G1 X88.093 Y212.932 Z-1.687 F25
G1 X88.126 Y213.024 Z-1.691 F25
G1 X88.152 Y213.119 Z-1.695 F25
G1 X88.17 Y213.215 Z-1.698 F25
G1 X88.181 Y213.312 Z-1.702 F25
G1 X88.183 Y213.41 Z-1.705 F25
G1 X88.177 Y213.508 Z-1.709 F25
G1 X88.164 Y213.605 Z-1.713 F25
G1 X88.143 Y213.701 Z-1.716 F25
G1 X88.114 Y213.795 Z-1.72 F25
G1 X88.077 Y213.885 Z-1.724 F25
G1 X88.034 Y213.973 Z-1.727 F25
G1 X87.983 Y214.057 Z-1.731 F25
G1 X87.926 Y214.136 Z-1.734 F25
G1 X87.862 Y214.211 Z-1.738 F25
G1 X87.793 Y214.28 Z-1.742 F25
G1 X87.719 Y214.343 Z-1.745 F25
G1 X87.639 Y214.4 Z-1.749 F25
G1 X87.555 Y214.451 Z-1.753 F25
G1 X87.467 Y214.494 Z-1.756 F25
G1 X87.377 Y214.53 Z-1.76 F25
G1 X87.283 Y214.559 Z-1.763 F25
G1 X87.187 Y214.58 Z-1.767 F25
G1 X87.09 Y214.593 Z-1.771 F25
G1 X86.993 Y214.599 Z-1.774 F25
G1 X86.895 Y214.596 Z-1.778 F25
G1 X86.798 Y214.586 Z-1.782 F25
G1 X86.702 Y214.567 Z-1.785 F25
G1 X86.607 Y214.541 Z-1.789 F25
G1 X86.515 Y214.508 Z-1.793 F25
G1 X86.426 Y214.467 Z-1.796 F25
G1 X86.341 Y214.419 Z-1.8 F25
G1 X86.26 Y214.364 Z-1.803 F25
G1 X86.184 Y214.303 Z-1.807 F25
G1 X86.112 Y214.236 Z-1.811 F25
G1 X86.047 Y214.163 Z-1.814 F25
G1 X85.988 Y214.085 Z-1.818 F25
G1 X85.935 Y214.003 Z-1.822 F25
G1 X85.889 Y213.917 Z-1.825 F25
G1 X85.85 Y213.827 Z-1.829 F25
G1 X85.818 Y213.735 Z-1.832 F25
G1 X85.794 Y213.64 Z-1.836 F25
G1 X85.778 Y213.544 Z-1.84 F25
G1 X85.77 Y213.446 Z-1.843 F25
G1 X85.769 Y213.349 Z-1.847 F25
G1 X85.777 Y213.251 Z-1.851 F25
G1 X85.792 Y213.155 Z-1.854 F25
G1 X85.815 Y213.06 Z-1.858 F25
G1 X85.846 Y212.967 Z-1.861 F25
G1 X85.884 Y212.877 Z-1.865 F25
G1 X85.929 Y212.79 Z-1.869 F25
G1 X85.981 Y212.708 Z-1.872 F25
G1 X86.04 Y212.63 Z-1.876 F25
G1 X86.105 Y212.557 Z-1.88 F25
G1 X86.175 Y212.489 Z-1.883 F25
G1 X86.251 Y212.427 Z-1.887 F25
G1 X86.332 Y212.372 Z-1.89 F25
G1 X86.416 Y212.323 Z-1.894 F25
G1 X86.505 Y212.281 Z-1.898 F25
G1 X86.596 Y212.247 Z-1.901 F25
G1 X86.69 Y212.22 Z-1.905 F25
G1 X86.786 Y212.201 Z-1.909 F25
G1 X86.883 Y212.19 Z-1.912 F25
G1 X86.98 Y212.186 Z-1.916 F25
G1 X87.078 Y212.191 Z-1.92 F25
G1 X87.175 Y212.203 Z-1.923 F25
G1 X87.27 Y212.223 Z-1.927 F25
G1 X87.364 Y212.251 Z-1.93 F25
G1 X87.455 Y212.286 Z-1.934 F25
G1 X87.543 Y212.329 Z-1.938 F25
G1 X87.627 Y212.378 Z-1.941 F25
G1 X87.706 Y212.435 Z-1.945 F25
G1 X87.781 Y212.497 Z-1.949 F25
G1 X87.851 Y212.565 Z-1.952 F25
G1 X87.915 Y212.639 Z-1.956 F25
G1 X87.973 Y212.718 Z-1.959 F25
G1 X88.024 Y212.801 Z-1.963 F25
G1 X88.068 Y212.888 Z-1.967 F25
G1 X88.105 Y212.978 Z-1.97 F25
G1 X88.135 Y213.071 Z-1.974 F25
G1 X88.157 Y213.166 Z-1.978 F25
G1 X88.172 Y213.263 Z-1.981 F25
G1 X88.178 Y213.36 Z-1.985 F25
G1 X88.176 Y213.458 Z-1.988 F25
G1 X88.167 Y213.555 Z-1.992 F25
G1 X88.15 Y213.651 Z-1.996 F25
G1 X88.125 Y213.745 Z-1.999 F25
G1 X88.093 Y213.837 Z-2.003 F25
G1 X88.053 Y213.926 Z-2.007 F25
G1 X88.006 Y214.011 Z-2.01 F25
G1 X87.952 Y214.093 Z-2.014 F25
G1 X87.892 Y214.17 Z-2.017 F25
G1 X87.826 Y214.241 Z-2.021 F25
G1 X87.755 Y214.307 Z-2.025 F25
G1 X87.678 Y214.367 Z-2.028 F25
G1 X87.596 Y214.421 Z-2.032 F25
G1 X87.511 Y214.468 Z-2.036 F25
G1 X87.422 Y214.508 Z-2.039 F25
G1 X87.33 Y214.54 Z-2.043 F25
G1 X87.236 Y214.565 Z-2.047 F25
G1 X87.14 Y214.582 Z-2.05 F25
G1 X87.043 Y214.592 Z-2.054 F25
G1 X86.946 Y214.593 Z-2.057 F25
G1 X86.848 Y214.587 Z-2.061 F25
G1 X86.752 Y214.573 Z-2.065 F25
G1 X86.657 Y214.551 Z-2.068 F25
G1 X86.564 Y214.521 Z-2.072 F25
G1 X86.474 Y214.484 Z-2.076 F25
G1 X86.387 Y214.44 Z-2.079 F25
G1 X86.304 Y214.389 Z-2.083 F25
G1 X86.225 Y214.331 Z-2.086 F25
G1 X86.152 Y214.268 Z-2.09 F25
G1 X86.084 Y214.198 Z-2.094 F25
G1 X86.021 Y214.123 Z-2.097 F25
G1 X85.965 Y214.044 Z-2.101 F25
G1 X85.916 Y213.96 Z-2.105 F25
G1 X85.873 Y213.872 Z-2.108 F25
G1 X85.838 Y213.782 Z-2.112 F25
G1 X85.81 Y213.688 Z-2.115 F25
G1 X85.79 Y213.593 Z-2.119 F25
G1 X85.778 Y213.496 Z-2.123 F25
G1 X85.773 Y213.399 Z-2.126 F25
G1 X85.777 Y213.302 Z-2.13 F25
G1 X85.788 Y213.205 Z-2.134 F25
G1 X85.807 Y213.11 Z-2.137 F25
G1 X85.834 Y213.016 Z-2.141 F25
G1 X85.868 Y212.925 Z-2.144 F25
G1 X85.909 Y212.837 Z-2.148 F25
G1 X85.958 Y212.753 Z-2.152 F25
G1 X86.013 Y212.672 Z-2.155 F25
G1 X86.074 Y212.597 Z-2.159 F25
G1 X86.142 Y212.527 Z-2.163 F25
G1 X86.215 Y212.462 Z-2.166 F25
G1 X86.292 Y212.404 Z-2.17 F25
G1 X86.375 Y212.352 Z-2.174 F25
G1 X86.461 Y212.306 Z-2.177 F25
G1 X86.55 Y212.268 Z-2.181 F25
G1 X86.643 Y212.238 Z-2.184 F25
G1 X86.737 Y212.215 Z-2.188 F25
G1 X86.833 Y212.199 Z-2.192 F25
G1 X86.93 Y212.192 Z-2.195 F25
G1 X87.027 Z-2.199 F25
G1 X87.124 Y212.201 Z-2.203 F25
G1 X87.22 Y212.217 Z-2.206 F25
G1 X87.314 Y212.24 Z-2.21 F25
G1 X87.406 Y212.272 Z-2.213 F25
G1 X87.495 Y212.31 Z-2.217 F25
G1 X87.581 Y212.356 Z-2.221 F25
G1 X87.663 Y212.409 Z-2.224 F25
G1 X87.74 Y212.468 Z-2.228 F25
G1 X87.812 Y212.533 Z-2.232 F25
G1 X87.879 Y212.604 Z-2.235 F25
G1 X87.94 Y212.679 Z-2.239 F25
G1 X87.994 Y212.76 Z-2.242 F25
G1 X88.042 Y212.845 Z-2.246 F25
G1 X88.083 Y212.933 Z-2.25 F25
G1 X88.116 Y213.024 Z-2.253 F25
G1 X88.142 Y213.118 Z-2.257 F25
G1 X88.16 Y213.213 Z-2.261 F25
G1 X88.171 Y213.31 Z-2.264 F25
G1 X88.173 Y213.407 Z-2.268 F25
G1 X88.168 Y213.504 Z-2.271 F25
G1 X88.155 Y213.6 Z-2.275 F25
G1 X88.134 Y213.695 Z-2.279 F25
G1 X88.106 Y213.788 Z-2.282 F25
G1 X88.07 Y213.878 Z-2.286 F25
G1 X88.027 Y213.965 Z-2.29 F25
G1 X87.977 Y214.048 Z-2.293 F25
G1 X87.92 Y214.127 Z-2.297 F25
G1 X87.858 Y214.201 Z-2.301 F25
G1 X87.789 Y214.27 Z-2.304 F25
G1 X87.715 Y214.333 Z-2.308 F25
G1 X87.636 Y214.39 Z-2.311 F25
G1 X87.553 Y214.44 Z-2.315 F25
G1 X87.466 Y214.484 Z-2.319 F25
G1 X87.376 Y214.52 Z-2.322 F25
G1 X87.284 Y214.549 Z-2.326 F25
G1 X87.189 Y214.57 Z-2.33 F25
G1 X87.093 Y214.583 Z-2.333 F25
G1 X86.996 Y214.589 Z-2.337 F25
G1 X86.899 Y214.586 Z-2.34 F25
G1 X86.802 Y214.576 Z-2.344 F25
G1 X86.707 Y214.558 Z-2.348 F25
G1 X86.613 Y214.533 Z-2.351 F25
G1 X86.522 Y214.5 Z-2.355 F25
G1 X86.434 Y214.459 Z-2.359 F25
G1 X86.349 Y214.412 Z-2.362 F25
G1 X86.268 Y214.358 Z-2.366 F25
G1 X86.193 Y214.298 Z-2.369 F25
G1 X86.122 Y214.231 Z-2.373 F25
G1 X86.057 Y214.16 Z-2.377 F25
G1 X85.998 Y214.083 Z-2.38 F25
G1 X85.945 Y214.001 Z-2.384 F25
G1 X85.899 Y213.916 Z-2.388 F25
G1 X85.86 Y213.827 Z-2.391 F25
G1 X85.829 Y213.735 Z-2.395 F25
G1 X85.805 Y213.641 Z-2.398 F25
G1 X85.788 Y213.546 Z-2.402 F25
G1 X85.78 Y213.449 Z-2.406 F25
G1 X85.779 Y213.352 Z-2.409 F25
G1 X85.786 Y213.256 Z-2.413 F25
G1 X85.801 Y213.16 Z-2.417 F25
G1 X85.824 Y213.066 Z-2.42 F25
G1 X85.854 Y212.974 Z-2.424 F25
G1 X85.891 Y212.884 Z-2.428 F25
G1 X85.936 Y212.798 Z-2.431 F25
G1 X85.988 Y212.716 Z-2.435 F25
G1 X86.046 Y212.638 Z-2.438 F25
G1 X86.11 Y212.566 Z-2.442 F25
G1 X86.18 Y212.498 Z-2.446 F25
G1 X86.255 Y212.437 Z-2.449 F25
G1 X86.334 Y212.382 Z-2.453 F25
G1 X86.418 Y212.333 Z-2.457 F25
G1 X86.505 Y212.292 Z-2.46 F25
G1 X86.596 Y212.257 Z-2.464 F25
G1 X86.689 Y212.231 Z-2.467 F25
G1 X86.784 Y212.211 Z-2.471 F25
G1 X86.88 Y212.2 Z-2.475 F25
G1 X86.977 Y212.196 Z-2.478 F25
G1 X87.074 Y212.2 Z-2.482 F25
G1 X87.17 Y212.212 Z-2.486 F25
G1 X87.264 Y212.232 Z-2.489 F25
G1 X87.357 Y212.259 Z-2.493 F25
G1 X87.448 Y212.294 Z-2.496 F25
G1 X87.535 Y212.336 Z-2.5 F25
G1 X87.619 Y212.385 Z-2.504 F25
G1 X87.698 Y212.44 Z-2.507 F25
G1 X87.772 Y212.502 Z-2.511 F25
G1 X87.842 Y212.57 Z-2.515 F25
G1 X87.905 Y212.643 Z-2.518 F25
G1 X87.963 Y212.721 Z-2.522 F25
G1 X88.014 Y212.803 Z-2.525 F25
G1 X88.058 Y212.889 Z-2.529 F25
G1 X88.095 Y212.979 Z-2.533 F25
G1 X88.125 Y213.071 Z-2.536 F25
G1 X88.147 Y213.165 Z-2.54 F25
G1 X88.161 Y213.261 Z-2.544 F25
G1 X88.168 Y213.357 Z-2.547 F25
G1 X88.167 Y213.454 Z-2.551 F25
G1 X88.158 Y213.55 Z-2.555 F25
G1 X88.141 Y213.645 Z-2.558 F25
G1 X88.117 Y213.739 Z-2.562 F25
G1 X88.085 Y213.83 Z-2.565 F25
G1 X88.046 Y213.918 Z-2.569 F25
G1 X87.999 Y214.003 Z-2.573 F25
G1 X87.946 Y214.084 Z-2.576 F25
G1 X87.887 Y214.161 Z-2.58 F25
G1 X87.822 Y214.232 Z-2.584 F25
G1 X87.751 Y214.298 Z-2.587 F25
G1 X87.675 Y214.357 Z-2.591 F25
G1 X87.594 Y214.411 Z-2.594 F25
G1 X87.51 Y214.458 Z-2.598 F25
G1 X87.421 Y214.497 Z-2.602 F25
G1 X87.33 Y214.53 Z-2.605 F25
G1 X87.237 Y214.555 Z-2.609 F25
G1 X87.142 Y214.572 Z-2.613 F25
G1 X87.046 Y214.582 Z-2.616 F25
G1 X86.949 Y214.584 Z-2.62 F25
G1 X86.852 Y214.578 Z-2.623 F25
G1 X86.757 Y214.564 Z-2.627 F25
G1 X86.662 Y214.542 Z-2.631 F25
G1 X86.57 Y214.513 Z-2.634 F25
G1 X86.481 Y214.477 Z-2.638 F25
G1 X86.395 Y214.433 Z-2.642 F25
G1 X86.312 Y214.383 Z-2.645 F25
G1 X86.234 Y214.326 Z-2.649 F25
G1 X86.161 Y214.263 Z-2.652 F25
G1 X86.093 Y214.194 Z-2.656 F25
G1 X86.031 Y214.12 Z-2.66 F25
G1 X85.975 Y214.041 Z-2.663 F25
G1 X85.926 Y213.958 Z-2.667 F25
G1 X85.884 Y213.871 Z-2.671 F25
G1 X85.849 Y213.782 Z-2.674 F25
G1 X85.821 Y213.689 Z-2.678 F25
G1 X85.801 Y213.595 Z-2.682 F25
G1 X85.788 Y213.499 Z-2.685 F25
G1 X85.783 Y213.402 Z-2.689 F25
G1 X85.786 Y213.306 Z-2.692 F25
G1 X85.797 Y213.21 Z-2.696 F25
G1 X85.816 Y213.115 Z-2.7 F25
G1 X85.842 Y213.022 Z-2.703 F25
G1 X85.876 Y212.932 Z-2.707 F25
G1 X85.917 Y212.844 Z-2.711 F25
G1 X85.964 Y212.76 Z-2.714 F25
G1 X86.019 Y212.681 Z-2.718 F25
G1 X86.08 Y212.606 Z-2.721 F25
G1 X86.146 Y212.536 Z-2.725 F25
G1 X86.218 Y212.472 Z-2.729 F25
G1 X86.295 Y212.413 Z-2.732 F25
G1 X86.377 Y212.362 Z-2.736 F25
G1 X86.462 Y212.317 Z-2.74 F25
G1 X86.55 Y212.279 Z-2.743 F25
G1 X86.642 Y212.248 Z-2.747 F25
G1 X86.736 Y212.225 Z-2.75 F25
G1 X86.831 Y212.21 Z-2.754 F25
G1 X86.927 Y212.202 Z-2.758 F25
G1 X87.023 Z-2.761 F25
G1 X87.119 Y212.21 Z-2.765 F25
G1 X87.215 Y212.226 Z-2.769 F25
G1 X87.308 Y212.249 Z-2.772 F25
G1 X87.4 Y212.28 Z-2.776 F25
G1 X87.488 Y212.318 Z-2.779 F25
G1 X87.573 Y212.363 Z-2.783 F25
G1 X87.655 Y212.415 Z-2.787 F25
G1 X87.731 Y212.473 Z-2.79 F25
G1 X87.803 Y212.538 Z-2.794 F25
G1 X87.87 Y212.608 Z-2.798 F25
G1 X87.93 Y212.683 Z-2.801 F25
G1 X87.984 Y212.763 Z-2.805 F25
G1 X88.032 Y212.846 Z-2.809 F25
G1 X88.073 Y212.934 Z-2.812 F25
G1 X88.106 Y213.024 Z-2.816 F25
G1 X88.132 Y213.117 Z-2.819 F25
G1 X88.15 Y213.212 Z-2.823 F25
G1 X88.161 Y213.307 Z-2.827 F25
G1 X88.164 Y213.404 Z-2.83 F25
G1 X88.159 Y213.5 Z-2.834 F25
G1 X88.146 Y213.595 Z-2.838 F25
G1 X88.126 Y213.689 Z-2.841 F25
G1 X88.098 Y213.782 Z-2.845 F25
G1 X88.062 Y213.871 Z-2.848 F25
G1 X88.02 Y213.958 Z-2.852 F25
G1 X87.97 Y214.04 Z-2.856 F25
G1 X87.915 Y214.119 Z-2.859 F25
G1 X87.852 Y214.192 Z-2.863 F25
G1 X87.785 Y214.261 Z-2.867 F25
G1 X87.712 Y214.323 Z-2.87 F25
G1 X87.634 Y214.38 Z-2.874 F25
G1 X87.551 Y214.43 Z-2.877 F25
G1 X87.465 Y214.473 Z-2.881 F25
G1 X87.376 Y214.509 Z-2.885 F25
G1 X87.284 Y214.538 Z-2.888 F25
G1 X87.19 Y214.559 Z-2.892 F25
G1 X87.095 Y214.573 Z-2.896 F25
G1 X86.999 Y214.579 Z-2.899 F25
G1 X86.902 Y214.577 Z-2.903 F25
G1 X86.807 Y214.567 Z-2.906 F25
G1 X86.712 Y214.55 Z-2.91 F25
G1 X86.619 Y214.524 Z-2.914 F25
G1 X86.529 Y214.492 Z-2.917 F25
G1 X86.441 Y214.452 Z-2.921 F25
G1 X86.357 Y214.405 Z-2.925 F25
G1 X86.277 Y214.352 Z-2.928 F25
G1 X86.202 Y214.292 Z-2.932 F25
G1 X86.131 Y214.227 Z-2.936 F25
G1 X86.066 Y214.156 Z-2.939 F25
G1 X86.008 Y214.08 Z-2.943 F25
G1 X85.955 Y213.999 Z-2.946 F25
G1 X85.909 Y213.915 Z-2.95 F25
G1 X85.87 Y213.827 Z-2.954 F25
G1 X85.839 Y213.736 Z-2.957 F25
G1 X85.815 Y213.643 Z-2.961 F25
G1 X85.798 Y213.548 Z-2.965 F25
G1 X85.79 Y213.452 Z-2.968 F25
G1 X85.789 Y213.356 Z-2.972 F25
G1 X85.796 Y213.26 Z-2.975 F25
G1 X85.81 Y213.165 Z-2.979 F25
G1 X85.832 Y213.071 Z-2.983 F25
G1 X85.862 Y212.98 Z-2.986 F25
G1 X85.899 Y212.891 Z-2.99 F25
G1 X85.943 Y212.806 Z-2.994 F25
G1 X85.994 Y212.724 Z-2.997 F25
G1 X86.051 Y212.647 Z-3.001 F25
G1 X86.115 Y212.575 Z-3.004 F25
G1 X86.183 Y212.508 Z-3.008 F25
G1 X86.258 Y212.447 Z-3.012 F25
G1 X86.336 Y212.392 Z-3.015 F25
G1 X86.419 Y212.343 Z-3.019 F25
G1 X86.506 Y212.302 Z-3.023 F25
G1 X86.596 Y212.268 Z-3.026 F25
G1 X86.688 Y212.241 Z-3.03 F25
G1 X86.782 Y212.222 Z-3.033 F25
G1 X86.878 Y212.21 Z-3.037 F25
G1 X86.973 Y212.206 Z-3.041 F25
G1 X87.069 Y212.21 Z-3.044 F25
G1 X87.165 Y212.221 Z-3.048 F25
G1 X87.259 Y212.241 Z-3.052 F25
G1 X87.351 Y212.268 Z-3.055 F25
G1 X87.441 Y212.302 Z-3.059 F25
G1 X87.528 Y212.343 Z-3.063 F25
G1 X87.611 Y212.392 Z-3.066 F25
G1 X87.689 Y212.446 Z-3.07 F25
G1 X87.764 Y212.507 Z-3.073 F25
G1 X87.833 Y212.574 Z-3.077 F25
G1 X87.896 Y212.647 Z-3.081 F25
G1 X87.953 Y212.724 Z-3.084 F25
G1 X88.004 Y212.805 Z-3.088 F25
G1 X88.048 Y212.89 Z-3.092 F25
G1 X88.085 Y212.979 Z-3.095 F25
G1 X88.115 Y213.07 Z-3.099 F25
G1 X88.137 Y213.163 Z-3.102 F25
G1 X88.151 Y213.258 Z-3.106 F25
G1 X88.158 Y213.354 Z-3.11 F25
G1 X88.157 Y213.45 Z-3.113 F25
G1 X88.149 Y213.545 Z-3.117 F25
G1 X88.132 Y213.64 Z-3.121 F25
G1 X88.108 Y213.733 Z-3.124 F25
G1 X88.077 Y213.823 Z-3.128 F25
G1 X88.038 Y213.911 Z-3.131 F25
G1 X87.992 Y213.995 Z-3.135 F25
G1 X87.94 Y214.076 Z-3.139 F25
G1 X87.881 Y214.152 Z-3.142 F25
G1 X87.817 Y214.223 Z-3.146 F25
G1 X87.747 Y214.288 Z-3.15 F25
G1 X87.672 Y214.348 Z-3.153 F25
G1 X87.592 Y214.401 Z-3.157 F25
G1 X87.508 Y214.448 Z-3.16 F25
G1 X87.421 Y214.487 Z-3.164 F25
G1 X87.33 Y214.52 Z-3.168 F25
G1 X87.238 Y214.545 Z-3.171 F25
G1 X87.143 Y214.562 Z-3.175 F25
G1 X87.048 Y214.572 Z-3.179 F25
G1 X86.952 Y214.574 Z-3.182 F25
G1 X86.857 Y214.568 Z-3.186 F25
G1 X86.762 Y214.555 Z-3.19 F25
G1 X86.668 Y214.534 Z-3.193 F25
G1 X86.577 Y214.505 Z-3.197 F25
G1 X86.488 Y214.469 Z-3.2 F25
G1 X86.403 Y214.426 Z-3.204 F25
G1 X86.321 Y214.376 Z-3.208 F25
G1 X86.243 Y214.32 Z-3.211 F25
G1 X86.17 Y214.258 Z-3.215 F25
G1 X86.103 Y214.19 Z-3.219 F25
G1 X86.041 Y214.117 Z-3.222 F25
G1 X85.986 Y214.039 Z-3.226 F25
G1 X85.936 Y213.956 Z-3.229 F25
G1 X85.894 Y213.87 Z-3.233 F25
G1 X85.859 Y213.781 Z-3.237 F25
G1 X85.831 Y213.69 Z-3.24 F25
G1 X85.811 Y213.596 Z-3.244 F25
G1 X85.798 Y213.501 Z-3.248 F25
G1 X85.793 Y213.405 Z-3.251 F25
G1 X85.796 Y213.31 Z-3.255 F25
G1 X85.806 Y213.214 Z-3.258 F25
G1 X85.825 Y213.12 Z-3.262 F25
G1 X85.85 Y213.028 Z-3.266 F25
G1 X85.884 Y212.938 Z-3.269 F25
G1 X85.924 Y212.852 Z-3.273 F25
G1 X85.971 Y212.768 Z-3.277 F25
G1 X86.025 Y212.689 Z-3.28 F25
G1 X86.085 Y212.615 Z-3.284 F25
G1 X86.151 Y212.545 Z-3.287 F25
G1 X86.222 Y212.481 Z-3.291 F25
G1 X86.298 Y212.423 Z-3.295 F25
G1 X86.378 Y212.372 Z-3.298 F25
G1 X86.463 Y212.327 Z-3.302 F25
G1 X86.551 Y212.289 Z-3.306 F25
G1 X86.642 Y212.259 Z-3.309 F25
G1 X86.734 Y212.235 Z-3.313 F25
G1 X86.829 Y212.22 Z-3.317 F25
G1 X86.924 Y212.212 Z-3.32 F25
G1 X87.02 Z-3.324 F25
G1 X87.115 Y212.219 Z-3.327 F25
G1 X87.21 Y212.235 Z-3.331 F25
G1 X87.302 Y212.258 Z-3.335 F25
G1 X87.393 Y212.288 Z-3.338 F25
G1 X87.481 Y212.326 Z-3.342 F25
G1 X87.566 Y212.37 Z-3.346 F25
G1 X87.647 Y212.421 Z-3.349 F25
G1 X87.723 Y212.479 Z-3.353 F25
G1 X87.794 Y212.543 Z-3.356 F25
G1 X87.86 Y212.612 Z-3.36 F25
G1 X87.92 Y212.686 Z-3.364 F25
G1 X87.974 Y212.765 Z-3.367 F25
G1 X88.022 Y212.848 Z-3.371 F25
G1 X88.062 Y212.934 Z-3.375 F25
G1 X88.095 Y213.024 Z-3.378 F25
G1 X88.121 Y213.116 Z-3.382 F25
G1 X88.14 Y213.21 Z-3.385 F25
G1 X88.151 Y213.305 Z-3.389 F25
G1 X88.154 Y213.4 Z-3.393 F25
G1 X88.149 Y213.496 Z-3.396 F25
G1 X88.137 Y213.59 Z-3.4 F25
G1 X88.117 Y213.684 Z-3.404 F25
G1 X88.089 Y213.775 Z-3.407 F25
G1 X88.054 Y213.864 Z-3.411 F25
G1 X88.013 Y213.95 Z-3.414 F25
G1 X87.964 Y214.032 Z-3.418 F25
G1 X87.909 Y214.11 Z-3.422 F25
G1 X87.847 Y214.183 Z-3.425 F25
G1 X87.78 Y214.251 Z-3.429 F25
G1 X87.708 Y214.314 Z-3.433 F25
G1 X87.631 Y214.37 Z-3.436 F25
G1 X87.549 Y214.42 Z-3.44 F25
G1 X87.464 Y214.463 Z-3.444 F25
G1 X87.375 Y214.499 Z-3.447 F25
G1 X87.285 Y214.528 Z-3.451 F25
G1 X87.192 Y214.549 Z-3.454 F25
G1 X87.097 Y214.563 Z-3.458 F25
G1 X87.002 Y214.569 Z-3.462 F25
G1 X86.906 Y214.567 Z-3.465 F25
G1 X86.812 Y214.558 Z-3.469 F25
G1 X86.718 Y214.541 Z-3.473 F25
G1 X86.625 Y214.516 Z-3.476 F25
G1 X86.536 Y214.484 Z-3.48 F25
G1 X86.449 Y214.445 Z-3.483 F25
G1 X86.365 Y214.399 Z-3.487 F25
G1 X86.286 Y214.346 Z-3.491 F25
G1 X86.211 Y214.287 Z-3.494 F25
G1 X86.141 Y214.222 Z-3.498 F25
G1 X86.076 Y214.152 Z-3.502 F25
G1 X86.017 Y214.077 Z-3.505 F25
G1 X85.965 Y213.997 Z-3.509 F25
G1 X85.92 Y213.913 Z-3.512 F25
G1 X85.881 Y213.826 Z-3.516 F25
G1 X85.849 Y213.736 Z-3.52 F25
G1 X85.825 Y213.643 Z-3.523 F25
G1 X85.809 Y213.55 Z-3.527 F25
G1 X85.8 Y213.455 Z-3.531 F25
G1 X85.798 Y213.359 Z-3.534 F25
G1 X85.805 Y213.264 Z-3.538 F25
G1 X85.819 Y213.17 Z-3.541 F25
G1 X85.841 Y213.077 Z-3.545 F25
G1 X85.87 Y212.986 Z-3.549 F25
G1 X85.906 Y212.898 Z-3.552 F25
G1 X85.95 Y212.813 Z-3.556 F25
G1 X86 Y212.732 Z-3.56 F25
G1 X86.057 Y212.656 Z-3.563 F25
G1 X86.119 Y212.584 Z-3.567 F25
G1 X86.188 Y212.517 Z-3.571 F25
G1 X86.261 Y212.457 Z-3.574 F25
G1 X86.339 Y212.402 Z-3.578 F25
G1 X86.421 Y212.354 Z-3.581 F25
G1 X86.507 Y212.312 Z-3.585 F25
G1 X86.596 Y212.278 Z-3.589 F25
G1 X86.687 Y212.251 Z-3.592 F25
G1 X86.781 Y212.232 Z-3.596 F25
G1 X86.875 Y212.22 Z-3.6 F25
G1 X86.97 Y212.216 Z-3.603 F25
G1 X87.066 Y212.219 Z-3.607 F25
G1 X87.16 Y212.231 Z-3.61 F25
G1 X87.254 Y212.25 Z-3.614 F25
G1 X87.345 Y212.276 Z-3.618 F25
G1 X87.434 Y212.31 Z-3.621 F25
G1 X87.52 Y212.351 Z-3.625 F25
G1 X87.603 Y212.398 Z-3.629 F25
G1 X87.681 Y212.452 Z-3.632 F25
G1 X87.755 Y212.513 Z-3.636 F25
G1 X87.823 Y212.579 Z-3.639 F25
G1 X87.886 Y212.65 Z-3.643 F25
G1 X87.943 Y212.726 Z-3.647 F25
G1 X87.994 Y212.807 Z-3.65 F25
G1 X88.038 Y212.891 Z-3.654 F25
G1 X88.075 Y212.979 Z-3.658 F25
G1 X88.104 Y213.069 Z-3.661 F25
G1 X88.126 Y213.162 Z-3.665 F25
G1 X88.141 Y213.256 Z-3.668 F25
G1 X88.148 Y213.351 Z-3.672 F25
G1 Y213.446 Z-3.676 F25
G1 X88.139 Y213.541 Z-3.679 F25
G1 X88.123 Y213.635 Z-3.683 F25
G1 X88.1 Y213.727 Z-3.687 F25
G1 X88.069 Y213.817 Z-3.69 F25
G1 X88.031 Y213.904 Z-3.694 F25
G1 X87.986 Y213.988 Z-3.698 F25
G1 X87.934 Y214.068 Z-3.701 F25
G1 X87.876 Y214.143 Z-3.705 F25
G1 X87.812 Y214.214 Z-3.708 F25
G1 X87.743 Y214.279 Z-3.712 F25
G1 X87.668 Y214.338 Z-3.716 F25
G1 X87.589 Y214.391 Z-3.719 F25
G1 X87.506 Y214.437 Z-3.723 F25
G1 X87.42 Y214.477 Z-3.727 F25
G1 X87.33 Y214.509 Z-3.73 F25
G1 X87.239 Y214.534 Z-3.734 F25
G1 X87.145 Y214.552 Z-3.737 F25
G1 X87.051 Y214.562 Z-3.741 F25
G1 X86.956 Y214.564 Z-3.745 F25
G1 X86.861 Y214.559 Z-3.748 F25
G1 X86.767 Y214.546 Z-3.752 F25
G1 X86.674 Y214.525 Z-3.756 F25
G1 X86.583 Y214.497 Z-3.759 F25
G1 X86.495 Y214.462 Z-3.763 F25
G1 X86.41 Y214.419 Z-3.766 F25
G1 X86.329 Y214.37 Z-3.77 F25
G1 X86.252 Y214.314 Z-3.774 F25
G1 X86.179 Y214.253 Z-3.777 F25
G1 X86.112 Y214.186 Z-3.781 F25
G1 X86.051 Y214.113 Z-3.785 F25
G1 X85.995 Y214.036 Z-3.788 F25
G1 X85.947 Y213.954 Z-3.792 F25
G1 X85.904 Y213.869 Z-3.795 F25
G1 X85.869 Y213.781 Z-3.799 F25
G1 X85.841 Y213.69 Z-3.803 F25
G1 X85.821 Y213.597 Z-3.806 F25
G1 X85.808 Y213.503 Z-3.81 F25
G1 X85.803 Y213.408 Z-3.814 F25
G1 X85.805 Y213.313 Z-3.817 F25
G1 X85.816 Y213.219 Z-3.821 F25
G1 X85.833 Y213.126 Z-3.825 F25
G1 X85.859 Y213.034 Z-3.828 F25
G1 X85.891 Y212.945 Z-3.832 F25
G1 X85.931 Y212.859 Z-3.835 F25
G1 X85.978 Y212.776 Z-3.839 F25
G1 X86.031 Y212.698 Z-3.843 F25
G1 X86.09 Y212.624 Z-3.846 F25
G1 X86.155 Y212.555 Z-3.85 F25
G1 X86.225 Y212.491 Z-3.854 F25
G1 X86.301 Y212.433 Z-3.857 F25
G1 X86.381 Y212.382 Z-3.861 F25
G1 X86.464 Y212.337 Z-3.864 F25
G1 X86.551 Y212.3 Z-3.868 F25
G1 X86.641 Y212.269 Z-3.872 F25
G1 X86.733 Y212.246 Z-3.875 F25
G1 X86.827 Y212.23 Z-3.879 F25
G1 X86.921 Y212.222 Z-3.883 F25
G1 X87.016 Z-3.886 F25
G1 X87.111 Y212.229 Z-3.89 F25
G1 X87.205 Y212.244 Z-3.893 F25
G1 X87.297 Y212.266 Z-3.897 F25
G1 X87.387 Y212.296 Z-3.901 F25
G1 X87.474 Y212.333 Z-3.904 F25
G1 X87.558 Y212.377 Z-3.908 F25
G1 X87.638 Y212.428 Z-3.912 F25
G1 X87.714 Y212.484 Z-3.915 F25
G1 X87.785 Y212.547 Z-3.919 F25
G1 X87.851 Y212.616 Z-3.922 F25
G1 X87.91 Y212.689 Z-3.926 F25
G1 X87.964 Y212.767 Z-3.93 F25
G1 X88.011 Y212.849 Z-3.933 F25
G1 X88.052 Y212.935 Z-3.937 F25
G1 X88.085 Y213.024 Z-3.941 F25
G1 X88.111 Y213.115 Z-3.944 F25
G1 X88.13 Y213.208 Z-3.948 F25
G1 X88.141 Y213.302 Z-3.952 F25
G1 X88.144 Y213.397 Z-3.955 F25
G1 X88.14 Y213.491 Z-3.959 F25
G1 X88.128 Y213.585 Z-3.962 F25
G1 X88.108 Y213.678 Z-3.966 F25
G1 X88.081 Y213.769 Z-3.97 F25
G1 X88.047 Y213.857 Z-3.973 F25
G1 X88.005 Y213.943 Z-3.977 F25
G1 X87.957 Y214.024 Z-3.981 F25
G1 X87.903 Y214.102 Z-3.984 F25
G1 X87.842 Y214.175 Z-3.988 F25
G1 X87.776 Y214.242 Z-3.991 F25
G1 X87.704 Y214.304 Z-3.995 F25
G1 X87.628 Y214.36 Z-3.999 F25
G1 X87.547 Y214.41 Z-4.002 F25
G1 X87.463 Y214.453 Z-4.006 F25
G1 X87.375 Y214.489 Z-4.01 F25
G1 X87.285 Y214.518 Z-4.013 F25
G1 X87.193 Y214.539 Z-4.017 F25
G1 X87.099 Y214.553 Z-4.02 F25
G1 X87.005 Y214.559 Z-4.024 F25
G1 X86.91 Y214.558 Z-4.028 F25
G1 X86.816 Y214.549 Z-4.031 F25
G1 X86.723 Y214.532 Z-4.035 F25
G1 X86.632 Y214.508 Z-4.039 F25
G1 X86.542 Y214.476 Z-4.042 F25
G1 X86.456 Y214.438 Z-4.046 F25
G1 X86.373 Y214.392 Z-4.049 F25
G1 X86.294 Y214.34 Z-4.053 F25
G1 X86.219 Y214.282 Z-4.057 F25
G1 X86.15 Y214.217 Z-4.06 F25
G1 X86.086 Y214.148 Z-4.064 F25
G1 X86.027 Y214.073 Z-4.068 F25
G1 X85.975 Y213.994 Z-4.071 F25
G1 X85.93 Y213.911 Z-4.075 F25
G1 X85.891 Y213.825 Z-4.079 F25
G1 X85.859 Y213.736 Z-4.082 F25
G1 X85.835 Y213.644 Z-4.086 F25
G1 X85.819 Y213.551 Z-4.089 F25
G1 X85.809 Y213.457 Z-4.093 F25
G1 X85.808 Y213.363 Z-4.097 F25
G1 X85.814 Y213.268 Z-4.1 F25
G1 X85.828 Y213.175 Z-4.104 F25
G1 X85.849 Y213.083 Z-4.108 F25
G1 X85.878 Y212.993 Z-4.111 F25
G1 X85.914 Y212.905 Z-4.115 F25
G1 X85.957 Y212.821 Z-4.118 F25
G1 X86.006 Y212.741 Z-4.122 F25
G1 X86.062 Y212.664 Z-4.126 F25
G1 X86.124 Y212.593 Z-4.129 F25
G1 X86.192 Y212.527 Z-4.133 F25
G1 X86.264 Y212.466 Z-4.137 F25
G1 X86.342 Y212.412 Z-4.14 F25
G1 X86.423 Y212.364 Z-4.144 F25
G1 X86.508 Y212.323 Z-4.147 F25
G1 X86.596 Y212.289 Z-4.151 F25
G1 X86.687 Y212.262 Z-4.155 F25
G1 X86.779 Y212.242 Z-4.158 F25
G1 X86.873 Y212.23 Z-4.162 F25
G1 X86.967 Y212.226 Z-4.166 F25
G1 X87.062 Y212.229 Z-4.169 F25
G1 X87.156 Y212.24 Z-4.173 F25
G1 X87.248 Y212.258 Z-4.176 F25
G1 X87.339 Y212.284 Z-4.18 F25
G1 X87.427 Y212.317 Z-4.184 F25
G1 X87.513 Y212.358 Z-4.187 F25
G1 X87.595 Y212.405 Z-4.191 F25
G1 X87.672 Y212.458 Z-4.195 F25
G1 X87.746 Y212.518 Z-4.198 F25
G1 X87.814 Y212.583 Z-4.202 F25
G1 X87.876 Y212.654 Z-4.206 F25
G1 X87.933 Y212.729 Z-4.209 F25
G1 X87.984 Y212.809 Z-4.213 F25
G1 X88.027 Y212.893 Z-4.216 F25
G1 X88.064 Y212.979 Z-4.22 F25
G1 X88.094 Y213.069 Z-4.224 F25
G1 X88.116 Y213.161 Z-4.227 F25
G1 X88.131 Y213.254 Z-4.231 F25
G1 X88.138 Y213.348 Z-4.235 F25
G1 Y213.442 Z-4.238 F25
G1 X88.13 Y213.536 Z-4.242 F25
G1 X88.114 Y213.63 Z-4.245 F25
G1 X88.091 Y213.721 Z-4.249 F25
G1 X88.061 Y213.81 Z-4.253 F25
G1 X88.023 Y213.897 Z-4.256 F25
G1 X87.979 Y213.98 Z-4.26 F25
G1 X87.928 Y214.06 Z-4.264 F25
G1 X87.87 Y214.135 Z-4.267 F25
G1 X87.807 Y214.205 Z-4.271 F25
G1 X87.739 Y214.269 Z-4.274 F25
G1 X87.665 Y214.328 Z-4.278 F25
G1 X87.587 Y214.381 Z-4.282 F25
G1 X87.505 Y214.427 Z-4.285 F25
G1 X87.419 Y214.467 Z-4.289 F25
G1 X87.331 Y214.499 Z-4.293 F25
G1 X87.24 Y214.524 Z-4.296 F25
G1 X87.147 Y214.542 Z-4.3 F25
G1 X87.054 Y214.552 Z-4.303 F25
G1 X86.959 Y214.554 Z-4.307 F25
G1 X86.865 Y214.549 Z-4.311 F25
G1 X86.772 Y214.537 Z-4.314 F25
G1 X86.68 Y214.516 Z-4.318 F25
G1 X86.59 Y214.489 Z-4.322 F25
G1 X86.502 Y214.454 Z-4.325 F25
G1 X86.418 Y214.412 Z-4.329 F25
G1 X86.337 Y214.364 Z-4.333 F25
G1 X86.26 Y214.309 Z-4.336 F25
G1 X86.188 Y214.248 Z-4.34 F25
G1 X86.122 Y214.181 Z-4.343 F25
G1 X86.06 Y214.109 Z-4.347 F25
G1 X86.005 Y214.033 Z-4.351 F25
G1 X85.957 Y213.952 Z-4.354 F25
G1 X85.915 Y213.868 Z-4.358 F25
G1 X85.879 Y213.781 Z-4.362 F25
G1 X85.852 Y213.691 Z-4.365 F25
G1 X85.831 Y213.599 Z-4.369 F25
G1 X85.818 Y213.506 Z-4.372 F25
G1 X85.813 Y213.412 Z-4.376 F25
G1 X85.815 Y213.318 Z-4.38 F25
G1 X85.825 Y213.224 Z-4.383 F25
G1 X85.842 Y213.131 Z-4.387 F25
G1 X85.867 Y213.041 Z-4.391 F25
G1 X85.899 Y212.952 Z-4.394 F25
G1 X85.938 Y212.867 Z-4.398 F25
G1 X85.984 Y212.784 Z-4.401 F25
G1 X86.037 Y212.706 Z-4.405 F25
G1 X86.095 Y212.633 Z-4.409 F25
G1 X86.16 Y212.564 Z-4.412 F25
G1 X86.229 Y212.501 Z-4.416 F25
G1 X86.304 Y212.443 Z-4.42 F25
G1 X86.383 Y212.392 Z-4.423 F25
G1 X86.466 Y212.348 Z-4.427 F25
G1 X86.552 Y212.31 Z-4.43 F25
G1 X86.641 Y212.279 Z-4.434 F25
G1 X86.732 Y212.256 Z-4.438 F25
G1 X86.825 Y212.24 Z-4.441 F25
G1 X86.919 Y212.232 Z-4.445 F25
G1 X87.013 Y212.231 Z-4.449 F25
G1 X87.107 Y212.238 Z-4.452 F25
G1 X87.2 Y212.253 Z-4.456 F25
G1 X87.291 Y212.275 Z-4.46 F25
G1 X87.38 Y212.304 Z-4.463 F25
G1 X87.467 Y212.34 Z-4.467 F25
G1 X87.55 Y212.384 Z-4.47 F25
G1 X87.63 Y212.434 Z-4.474 F25
G1 X87.705 Y212.49 Z-4.478 F25
G1 X87.776 Y212.552 Z-4.481 F25
G1 X87.841 Y212.62 Z-4.485 F25
G1 X87.901 Y212.692 Z-4.489 F25
G1 X87.954 Y212.77 Z-4.492 F25
G1 X88.001 Y212.851 Z-4.496 F25
G1 X88.041 Y212.936 Z-4.499 F25
G1 X88.075 Y213.024 Z-4.503 F25
G1 X88.101 Y213.114 Z-4.507 F25
G1 X88.119 Y213.206 Z-4.51 F25
G1 X88.131 Y213.3 Z-4.514 F25
G1 X88.134 Y213.394 Z-4.518 F25
G1 X88.13 Y213.488 Z-4.521 F25
G1 X88.118 Y213.581 Z-4.525 F25
G1 X88.099 Y213.673 Z-4.528 F25
G1 X88.073 Y213.763 Z-4.532 F25
G1 X88.039 Y213.851 Z-4.536 F25
G1 X87.998 Y213.935 Z-4.539 F25
G1 X87.951 Y214.016 Z-4.543 F25
G1 X87.897 Y214.093 Z-4.547 F25
G1 X87.837 Y214.166 Z-4.55 F25
G1 X87.772 Y214.233 Z-4.554 F25
G1 X87.701 Y214.295 Z-4.557 F25
G1 X87.625 Y214.35 Z-4.561 F25
G1 X87.545 Y214.4 Z-4.565 F25
G1 X87.462 Y214.443 Z-4.568 F25
G1 X87.375 Y214.478 Z-4.572 F25
G1 X87.286 Y214.507 Z-4.576 F25
G1 X87.194 Y214.529 Z-4.579 F25
G1 X87.102 Y214.543 Z-4.583 F25
G1 X87.008 Y214.549 Z-4.587 F25
G1 X86.914 Y214.548 Z-4.59 F25
G1 X86.821 Y214.539 Z-4.594 F25
G1 X86.728 Y214.523 Z-4.597 F25
G1 X86.637 Y214.499 Z-4.601 F25
G1 X86.549 Y214.468 Z-4.605 F25
G1 X86.463 Y214.43 Z-4.608 F25
G1 X86.381 Y214.385 Z-4.612 F25
G1 X86.302 Y214.334 Z-4.616 F25
G1 X86.228 Y214.276 Z-4.619 F25
G1 X86.159 Y214.213 Z-4.623 F25
G1 X86.095 Y214.144 Z-4.626 F25
G1 X86.037 Y214.07 Z-4.63 F25
G1 X85.985 Y213.992 Z-4.634 F25
G1 X85.94 Y213.91 Z-4.637 F25
G1 X85.901 Y213.824 Z-4.641 F25
G1 X85.87 Y213.736 Z-4.645 F25
G1 X85.846 Y213.646 Z-4.648 F25
G1 X85.829 Y213.553 Z-4.652 F25
G1 X85.819 Y213.46 Z-4.655 F25
G1 X85.818 Y213.366 Z-4.659 F25
G1 X85.824 Y213.273 Z-4.663 F25
G1 X85.837 Y213.18 Z-4.666 F25
G1 X85.858 Y213.089 Z-4.67 F25
G1 X85.886 Y212.999 Z-4.674 F25
G1 X85.922 Y212.912 Z-4.677 F25
G1 X85.964 Y212.829 Z-4.681 F25
G1 X86.013 Y212.749 Z-4.684 F25
G1 X86.068 Y212.673 Z-4.688 F25
G1 X86.129 Y212.602 Z-4.692 F25
G1 X86.196 Y212.536 Z-4.695 F25
G1 X86.268 Y212.476 Z-4.699 F25
G1 X86.344 Y212.422 Z-4.703 F25
G1 X86.425 Y212.374 Z-4.706 F25
G1 X86.509 Y212.333 Z-4.71 F25
G1 X86.597 Y212.299 Z-4.714 F25
G1 X86.686 Y212.272 Z-4.717 F25
G1 X86.778 Y212.252 Z-4.721 F25
G1 X86.871 Y212.24 Z-4.724 F25
G1 X86.964 Y212.235 Z-4.728 F25
G1 X87.058 Y212.238 Z-4.732 F25
G1 X87.151 Y212.249 Z-4.735 F25
G1 X87.243 Y212.267 Z-4.739 F25
G1 X87.333 Y212.292 Z-4.743 F25
G1 X87.421 Y212.325 Z-4.746 F25
G1 X87.505 Y212.365 Z-4.75 F25
G1 X87.587 Y212.411 Z-4.753 F25
G1 X87.664 Y212.464 Z-4.757 F25
G1 X87.737 Y212.523 Z-4.761 F25
G1 X87.804 Y212.588 Z-4.764 F25
G1 X87.867 Y212.657 Z-4.768 F25
G1 X87.923 Y212.732 Z-4.772 F25
G1 X87.973 Y212.811 Z-4.775 F25
G1 X88.017 Y212.894 Z-4.779 F25
G1 X88.054 Y212.98 Z-4.782 F25
G1 X88.084 Y213.069 Z-4.786 F25
G1 X88.106 Y213.16 Z-4.79 F25
G1 X88.121 Y213.252 Z-4.793 F25
G1 X88.128 Y213.345 Z-4.797 F25
G1 Y213.439 Z-4.801 F25
G1 X88.121 Y213.532 Z-4.804 F25
G1 X88.105 Y213.625 Z-4.808 F25
G1 X88.083 Y213.715 Z-4.811 F25
G1 X88.053 Y213.804 Z-4.815 F25
G1 X88.016 Y213.89 Z-4.819 F25
G1 X87.972 Y213.972 Z-4.822 F25
G1 X87.922 Y214.051 Z-4.826 F25
G1 X87.865 Y214.126 Z-4.83 F25
G1 X87.803 Y214.195 Z-4.833 F25
G1 X87.735 Y214.26 Z-4.837 F25
G1 X87.662 Y214.318 Z-4.841 F25
G1 X87.585 Y214.371 Z-4.844 F25
G1 X87.503 Y214.417 Z-4.848 F25
G1 X87.419 Y214.456 Z-4.851 F25
G1 X87.331 Y214.489 Z-4.855 F25
G1 X87.241 Y214.514 Z-4.859 F25
G1 X87.149 Y214.532 Z-4.862 F25
G1 X87.056 Y214.542 Z-4.866 F25
G1 X86.963 Y214.545 Z-4.87 F25
G1 X86.869 Y214.54 Z-4.873 F25
G1 X86.777 Y214.527 Z-4.877 F25
G1 X86.685 Y214.508 Z-4.88 F25
G1 X86.596 Y214.48 Z-4.884 F25
G1 X86.509 Y214.446 Z-4.888 F25
G1 X86.425 Y214.405 Z-4.891 F25
G1 X86.345 Y214.357 Z-4.895 F25
G1 X86.269 Y214.303 Z-4.899 F25
G1 X86.197 Y214.243 Z-4.902 F25
G1 X86.131 Y214.177 Z-4.906 F25
G1 X86.07 Y214.106 Z-4.909 F25
G1 X86.015 Y214.03 Z-4.913 F25
G1 X85.967 Y213.951 Z-4.917 F25
G1 X85.925 Y213.867 Z-4.92 F25
G1 X85.89 Y213.781 Z-4.924 F25
G1 X85.862 Y213.691 Z-4.928 F25
G1 X85.841 Y213.6 Z-4.931 F25
G1 X85.828 Y213.508 Z-4.935 F25
G1 X85.823 Y213.415 Z-4.938 F25
G1 X85.825 Y213.321 Z-4.942 F25
G1 X85.834 Y213.229 Z-4.946 F25
G1 X85.851 Y213.137 Z-4.949 F25
G1 X85.875 Y213.047 Z-4.953 F25
G1 X85.907 Y212.959 Z-4.957 F25
G1 X85.946 Y212.874 Z-4.96 F25
G1 X85.991 Y212.792 Z-4.964 F25
G1 X86.043 Y212.715 Z-4.968 F25
G1 X86.101 Y212.641 Z-4.971 F25
G1 X86.164 Y212.573 Z-4.975 F25
G1 X86.233 Y212.51 Z-4.978 F25
G1 X86.307 Y212.453 Z-4.982 F25
G1 X86.386 Y212.402 Z-4.986 F25
G1 X86.468 Y212.358 Z-4.989 F25
G1 X86.553 Y212.32 Z-4.993 F25
G1 X86.641 Y212.289 Z-4.997 F25
G1 X86.731 Y212.266 Z-5 F25
G1 X86.823 Y212.25 Z-5.004 F25
G1 X86.916 Y212.242 Z-5.007 F25
G1 X87.009 Y212.241 Z-5.011 F25
G1 X87.102 Y212.247 Z-5.015 F25
G1 X87.194 Y212.262 Z-5.018 F25
G1 X87.285 Y212.283 Z-5.022 F25
G1 X87.374 Y212.312 Z-5.026 F25
G1 X87.46 Y212.348 Z-5.029 F25
G1 X87.543 Y212.391 Z-5.033 F25
G1 X87.622 Y212.44 Z-5.036 F25
G1 X87.697 Y212.496 Z-5.04 F25
G1 X87.767 Y212.557 Z-5.044 F25
G1 X87.832 Y212.624 Z-5.047 F25
G1 X87.891 Y212.696 Z-5.051 F25
G1 X87.944 Y212.772 Z-5.055 F25
G1 X87.991 Y212.853 Z-5.058 F25
G1 X88.031 Y212.937 Z-5.062 F25
G1 X88.064 Y213.024 Z-5.065 F25
G1 X88.091 Y213.114 Z-5.069 F25
G1 X88.109 Y213.205 Z-5.073 F25
G1 X88.121 Y213.298 Z-5.076 F25
G1 X88.124 Y213.391 Z-5.08 F25
G3 X85.823 I-1.151 F25
G3 X88.124 I1.151 F25
; MOVEMENT_CUTTING
G1 X88.169 Y214.087 F254
G1 X88.173 Y214.174 F254
G1 X88.161 Y214.326 F254
G1 X88.12 Y214.473 F254
G1 X88.115 Y214.483 F254
G1 X88.005 Y214.653 F254
G1 X87.852 Y214.787 F254
G1 X87.669 Y214.875 F254
G1 X87.469 Y214.91 F254
G1 X87.392 Y214.912 F254
G1 X87.234 Y214.914 F254
G1 X87.075 Y214.912 F254
G1 X86.996 Y214.91 F254
G1 X86.917 Y214.895 F254
G1 X86.124 Y214.697 F254
G1 X86.087 Y214.685 F254
G1 X86.05 Y214.669 F254
G1 X85.966 Y214.628 F254
G1 X85.807 Y214.548 F254
G1 X85.709 Y214.475 F254
G1 X85.679 Y214.451 F254
G1 X85.648 Y214.422 F254
G1 X85.627 Y214.396 F254
G1 X85.61 Y214.369 F254
G1 X85.596 Y214.343 F254
G1 X85.586 Y214.316 F254
G1 X85.552 Y214.158 F254
G1 X85.49 Y213.825 F254
G1 X85.477 Y213.753 F254
G1 X85.474 Y213.682 F254
G1 X85.478 Y213.365 F254
G1 X85.486 Y213.206 F254
G1 X85.49 Y213.188 F254
G1 X85.534 Y213.048 F254
G1 X85.589 Y212.889 F254
G1 X85.774 Y212.371 F254
G1 X85.831 Y212.23 F254
G1 X85.908 Y212.099 F254
G1 X86.001 Y211.978 F254
G1 X86.109 Y211.871 F254
G1 X86.229 Y211.776 F254
G1 X86.358 Y211.695 F254
G1 X86.495 Y211.629 F254
G1 X86.638 Y211.576 F254
G1 X86.663 Y211.57 F254
G1 X86.854 Y211.546 F254
G1 X87.045 Y211.573 F254
G1 X87.222 Y211.647 F254
G1 X87.374 Y211.765 F254
; MOVEMENT_LEAD_OUT
G1 X87.405 Y211.804 Z-5.06 F254
G1 X87.43 Y211.847 Z-5.039 F254
G1 X87.447 Y211.894 Z-5.019 F254
G1 X87.457 Y211.943 Z-4.999 F254
G1 X87.459 Y211.992 Z-4.978 F254
G1 X87.453 Y212.042 Z-4.958 F254
G1 X87.44 Y212.09 Z-4.938 F254
G1 X87.419 Y212.135 Z-4.917 F254
G1 X87.391 Y212.177 Z-4.897 F254
G1 X87.358 Y212.213 Z-4.877 F254
G3 X87.273 Y212.27 I-0.216 J-0.233 F254
G1 X87.141 Y212.33 F254
; MOVEMENT_LINK_DIRECT
G1 X86.223 Y212.748 F254
; MOVEMENT_LEAD_IN
G1 X86.208 Y212.754 F254
G3 X85.983 Y212.769 I-0.132 J-0.289 F254
G1 X85.937 Y212.75 Z-4.897 F254
G1 X85.894 Y212.725 Z-4.917 F254
G1 X85.855 Y212.693 Z-4.938 F254
G1 X85.823 Y212.655 Z-4.958 F254
G1 X85.796 Y212.613 Z-4.978 F254
G1 X85.776 Y212.568 Z-4.999 F254
G1 X85.764 Y212.519 Z-5.019 F254
G1 X85.759 Y212.47 Z-5.039 F254
G1 X85.763 Y212.42 Z-5.06 F254
G1 X85.774 Y212.371 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X85.869 Y212.096 F254
G1 X85.922 Y211.937 F254
G1 X85.95 Y211.779 F254
G1 X85.959 Y211.725 F254
G1 X85.99 Y211.576 F254
G1 X86.098 Y211.407 F254
G1 X86.254 Y211.282 F254
G1 X86.442 Y211.213 F254
G1 X86.642 Y211.208 F254
G1 X86.834 Y211.267 F254
G1 X86.996 Y211.384 F254
; MOVEMENT_LEAD_OUT
G1 X87.027 Y211.423 Z-5.06 F254
G1 X87.052 Y211.467 Z-5.039 F254
G1 X87.069 Y211.513 Z-5.019 F254
G1 X87.079 Y211.562 Z-4.999 F254
G1 X87.081 Y211.612 Z-4.978 F254
G1 X87.075 Y211.661 Z-4.958 F254
G1 X87.061 Y211.709 Z-4.938 F254
G1 X87.041 Y211.755 Z-4.917 F254
G1 X87.013 Y211.796 Z-4.897 F254
G1 X86.979 Y211.833 Z-4.877 F254
G3 X86.864 Y211.901 I-0.216 J-0.233 F254
G1 X86.758 Y211.937 F254
; MOVEMENT_LINK_DIRECT
G1 X86.475 Y212.031 F254
; MOVEMENT_LEAD_IN
G1 X86.374 Y212.065 F254
G3 X86.235 Y212.079 I-0.1 J-0.301 F254
G1 X86.186 Y212.069 Z-4.897 F254
G1 X86.14 Y212.051 Z-4.917 F254
G1 X86.096 Y212.027 Z-4.938 F254
G1 X86.057 Y211.996 Z-4.958 F254
G1 X86.024 Y211.959 Z-4.978 F254
G1 X85.996 Y211.917 Z-4.999 F254
G1 X85.975 Y211.872 Z-5.019 F254
G1 X85.962 Y211.824 Z-5.039 F254
G1 X85.956 Y211.775 Z-5.06 F254
G1 X85.959 Y211.725 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X86 Y211.462 F254
G1 X86.023 Y211.303 F254
G1 X86.027 Y211.255 F254
G1 X86.03 Y211.221 F254
G1 X86.033 Y211.179 F254
G1 X86.041 Y211.122 F254
G1 X86.048 Y211.093 F254
G1 X86.056 Y211.065 F254
; MOVEMENT_LEAD_OUT
G1 X86.083 Y211.056 Z-5.068 F254
G1 X86.127 Y211.046 Z-5.05 F254
G1 X86.173 Y211.042 Z-5.031 F254
G1 X86.218 Y211.044 Z-5.013 F254
G1 X86.262 Y211.053 Z-4.994 F254
G1 X86.305 Y211.068 Z-4.976 F254
G1 X86.345 Y211.089 Z-4.958 F254
G1 X86.382 Y211.116 Z-4.939 F254
G1 X86.414 Y211.147 Z-4.921 F254
G1 X86.442 Y211.183 Z-4.902 F254
G1 X86.477 Y211.234 Z-4.877 F254
G1 X86.614 Y211.44 F254
; MOVEMENT_LINK_DIRECT
G1 X86.742 Y211.631 F254
G3 X86.637 Y212.083 I-0.264 J0.177 F254
G3 X86.194 Y211.948 I-0.159 J-0.275 F254
G3 X86.089 Y211.672 I1.42 J-0.698 F254
; MOVEMENT_LEAD_IN
G1 X86.065 Y211.575 Z-4.917 F254
G1 X86.048 Y211.477 Z-4.958 F254
G1 X86.037 Y211.378 Z-4.999 F254
G1 X86.032 Y211.279 Z-5.039 F254
G1 X86.033 Y211.179 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X86.036 Y211.144 F254
G1 X86.043 Y211.105 F254
G1 X86.056 Y211.065 F254
G1 X86.075 Y211.025 F254
G1 X86.102 Y210.986 F254
G1 X86.124 Y210.96 F254
G1 X86.164 Y210.926 F254
G1 X86.203 Y210.898 F254
G1 X86.243 Y210.879 F254
G1 X86.283 Y210.865 F254
G1 X86.322 Y210.857 F254
G1 X86.362 Y210.855 F254
G1 X86.402 Y210.857 F254
G1 X86.441 Y210.864 F254
G1 X86.481 Y210.877 F254
G1 X86.52 Y210.896 F254
G1 X86.56 Y210.923 F254
G1 X86.6 Y210.96 F254
G1 X86.621 Y210.986 F254
G1 X86.759 Y211.144 F254
G1 X86.917 Y211.304 F254
G1 X87.392 Y211.783 F254
G1 X87.551 Y211.938 F254
G1 X87.914 Y212.255 F254
G1 X88.026 Y212.349 F254
G1 X88.311 Y212.572 F254
G1 X88.426 Y212.672 F254
G1 X88.531 Y212.782 F254
G1 X88.631 Y212.909 F254
G1 X88.727 Y213.054 F254
G1 X88.809 Y213.202 F254
G1 X88.877 Y213.351 F254
G1 X88.93 Y213.5 F254
G1 X88.971 Y213.651 F254
G1 X88.999 Y213.801 F254
G1 X89.014 Y213.953 F254
G1 X89.015 Y214.105 F254
G1 X89.012 Y214.147 F254
G1 X88.973 Y214.334 F254
G1 X88.888 Y214.505 F254
G1 X88.761 Y214.649 F254
G1 X88.603 Y214.755 F254
G1 X88.422 Y214.817 F254
; MOVEMENT_LEAD_OUT
G1 X88.372 Y214.822 Z-5.06 F254
G1 X88.323 Y214.818 Z-5.039 F254
G1 X88.274 Y214.807 Z-5.019 F254
G1 X88.228 Y214.789 Z-4.999 F254
G1 X88.185 Y214.763 Z-4.978 F254
G1 X88.147 Y214.731 Z-4.958 F254
G1 X88.114 Y214.694 Z-4.938 F254
G1 X88.088 Y214.652 Z-4.917 F254
G1 X88.068 Y214.606 Z-4.897 F254
G1 X88.056 Y214.557 Z-4.877 F254
G1 X88.055 Y214.55 F254
G1 X88.02 Y214.313 F254
; MOVEMENT_LINK_DIRECT
G1 X87.81 Y212.875 F254
; MOVEMENT_LEAD_IN
G1 Y212.874 F254
G3 X87.868 Y212.641 I0.314 J-0.046 F254
G1 X87.9 Y212.604 Z-4.897 F254
G1 X87.938 Y212.571 Z-4.917 F254
G1 X87.98 Y212.545 Z-4.938 F254
G1 X88.026 Y212.526 Z-4.958 F254
G1 X88.075 Y212.515 Z-4.978 F254
G1 X88.124 Y212.511 Z-4.999 F254
G1 X88.174 Y212.515 Z-5.019 F254
G1 X88.222 Y212.527 Z-5.039 F254
G1 X88.268 Y212.546 Z-5.06 F254
G1 X88.311 Y212.572 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X88.514 Y212.73 F254
G1 X88.661 Y212.843 F254
G1 X88.978 Y213.051 F254
G1 X89.136 Y213.148 F254
G1 X89.264 Y213.232 F254
G1 X89.373 Y213.338 F254
G1 X89.467 Y213.458 F254
G1 X89.545 Y213.589 F254
G1 X89.561 Y213.624 F254
G1 X89.617 Y213.825 F254
G1 X89.615 Y214.034 F254
G1 X89.555 Y214.234 F254
G1 X89.441 Y214.409 F254
G1 X89.283 Y214.546 F254
G1 X89.093 Y214.633 F254
; MOVEMENT_LEAD_OUT
G1 X89.044 Y214.642 Z-5.06 F254
G1 X88.994 Z-5.039 F254
G1 X88.945 Y214.636 Z-5.019 F254
G1 X88.897 Y214.621 Z-4.999 F254
G1 X88.852 Y214.599 Z-4.978 F254
G1 X88.812 Y214.571 Z-4.958 F254
G1 X88.776 Y214.536 Z-4.938 F254
G1 X88.746 Y214.496 Z-4.917 F254
G1 X88.722 Y214.452 Z-4.897 F254
G1 X88.706 Y214.405 Z-4.877 F254
G3 X88.696 Y214.335 I0.307 J-0.08 F254
G1 X88.691 Y214.159 F254
; MOVEMENT_LINK_DIRECT
G1 X88.671 Y213.518 F254
; MOVEMENT_LEAD_IN
G1 X88.668 Y213.438 F254
G3 X88.706 Y213.277 I0.317 J-0.01 F254
G1 X88.733 Y213.235 Z-4.897 F254
G1 X88.766 Y213.198 Z-4.917 F254
G1 X88.805 Y213.167 Z-4.938 F254
G1 X88.848 Y213.142 Z-4.958 F254
G1 X88.895 Y213.124 Z-4.978 F254
G1 X88.943 Y213.113 Z-4.999 F254
G1 X88.993 Y213.111 Z-5.019 F254
G1 X89.043 Y213.116 Z-5.039 F254
G1 X89.091 Y213.128 Z-5.06 F254
G1 X89.136 Y213.148 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X89.506 Y213.365 F254
G1 X89.612 Y213.425 F254
G1 X89.699 Y213.473 F254
G1 X89.829 Y213.554 F254
G1 X89.935 Y213.71 F254
G1 X89.979 Y213.894 F254
G1 X89.953 Y214.081 F254
G1 X89.862 Y214.247 F254
G1 X89.717 Y214.369 F254
; MOVEMENT_LEAD_OUT
G1 X89.661 Y214.394 Z-5.055 F254
G1 X89.602 Y214.413 Z-5.03 F254
G1 X89.542 Y214.425 Z-5.005 F254
G1 X89.48 Y214.429 Z-4.98 F254
G1 X89.418 Y214.427 Z-4.954 F254
G1 X89.356 Y214.416 Z-4.928 F254
G1 X89.295 Y214.398 Z-4.902 F254
G1 X89.238 Y214.373 Z-4.877 F254
G3 X89.221 Y213.485 I0.233 J-0.449 F254
; MOVEMENT_LEAD_IN
G1 X89.277 Y213.457 Z-4.902 F254
G1 X89.335 Y213.437 Z-4.928 F254
G1 X89.396 Y213.424 Z-4.953 F254
G1 X89.458 Y213.419 Z-4.978 F254
G1 X89.521 Y213.421 Z-5.004 F254
G1 X89.582 Y213.431 Z-5.029 F254
G1 X89.642 Y213.449 Z-5.055 F254
G1 X89.699 Y213.473 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X89.994 Y213.637 F254
G1 X90.027 Y213.658 F254
G1 X90.06 Y213.682 F254
G1 X90.087 Y213.708 F254
G1 X90.115 Y213.741 F254
G1 X90.135 Y213.774 F254
G1 X90.151 Y213.807 F254
G1 X90.162 Y213.841 F254
G1 X90.17 Y213.88 F254
G1 X90.174 Y213.92 F254
G1 X90.172 Y213.96 F254
G1 X90.165 Y213.999 F254
G1 X90.154 Y214.035 F254
G1 X90.138 Y214.071 F254
G1 X90.117 Y214.107 F254
G1 X90.087 Y214.143 F254
G1 X90.073 Y214.158 F254
G1 X90.037 Y214.187 F254
G1 X90.001 Y214.209 F254
G1 X89.453 Y214.518 F254
G1 X89.414 Y214.537 F254
G1 X89.374 Y214.55 F254
G1 X88.978 Y214.667 F254
G1 X88.502 Y214.801 F254
G1 X88.344 Y214.833 F254
G1 X87.868 Y214.895 F254
G1 X87.709 Y214.901 F254
G1 X87.469 Y214.91 F254
; MOVEMENT_LEAD_OUT
G3 X87.153 Y214.623 J-0.318 F254
G1 X87.152 Y214.592 Z-5.079 F254
G1 X87.162 Y214.552 Z-5.071 F254
G1 X87.172 Y214.512 Z-5.059 F254
G1 X87.181 Y214.475 Z-5.041 F254
G1 X87.19 Y214.44 Z-5.018 F254
G1 X87.214 Y214.412 Z-4.985 F254
G1 X87.235 Y214.388 Z-4.948 F254
G1 X87.251 Y214.368 Z-4.906 F254
G1 X87.263 Y214.354 Z-4.86 F254
G1 X87.27 Y214.346 Z-4.812 F254
G1 X87.273 Y214.343 Z-4.763 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X93.593 Y229.651 F254
G1 Z2.54 F254
; MOVEMENT_RAMP_HELIX
G1 X93.696 Y229.699 Z2.536 F25
G1 X93.795 Y229.755 Z2.532 F25
G1 X93.891 Y229.817 Z2.528 F25
G1 X93.982 Y229.886 Z2.524 F25
G1 X94.068 Y229.961 Z2.52 F25
G1 X94.148 Y230.041 Z2.516 F25
G1 X94.223 Y230.127 Z2.512 F25
G1 X94.292 Y230.218 Z2.508 F25
G1 X94.354 Y230.314 Z2.504 F25
G1 X94.409 Y230.414 Z2.5 F25
G1 X94.457 Y230.517 Z2.496 F25
G1 X94.498 Y230.623 Z2.492 F25
G1 X94.531 Y230.732 Z2.488 F25
G1 X94.557 Y230.843 Z2.484 F25
G1 X94.575 Y230.956 Z2.48 F25
G1 X94.585 Y231.07 Z2.476 F25
G1 X94.588 Y231.184 Z2.472 F25
G1 X94.582 Y231.297 Z2.468 F25
G1 X94.568 Y231.411 Z2.464 F25
G1 X94.547 Y231.522 Z2.46 F25
G1 X94.518 Y231.633 Z2.456 F25
G1 X94.481 Y231.741 Z2.452 F25
G1 X94.437 Y231.846 Z2.448 F25
G1 X94.385 Y231.947 Z2.444 F25
G1 X94.327 Y232.045 Z2.44 F25
G1 X94.262 Y232.139 Z2.436 F25
G1 X94.191 Y232.228 Z2.433 F25
G1 X94.113 Y232.312 Z2.429 F25
G1 X94.03 Y232.39 Z2.425 F25
G1 X93.942 Y232.462 Z2.421 F25
G1 X93.849 Y232.528 Z2.417 F25
G1 X93.752 Y232.587 Z2.413 F25
G1 X93.651 Y232.639 Z2.409 F25
G1 X93.547 Y232.684 Z2.405 F25
G1 X93.439 Y232.722 Z2.401 F25
G1 X93.329 Y232.752 Z2.397 F25
G1 X93.218 Y232.775 Z2.393 F25
G1 X93.105 Y232.79 Z2.389 F25
G1 X92.991 Y232.797 Z2.385 F25
G1 X92.878 Y232.795 Z2.381 F25
G1 X92.764 Y232.786 Z2.377 F25
G1 X92.651 Y232.77 Z2.373 F25
G1 X92.54 Y232.745 Z2.369 F25
G1 X92.431 Y232.713 Z2.365 F25
G1 X92.324 Y232.673 Z2.361 F25
G1 X92.221 Y232.626 Z2.357 F25
G1 X92.121 Y232.572 Z2.353 F25
G1 X92.025 Y232.511 Z2.349 F25
G1 X91.933 Y232.443 Z2.345 F25
G1 X91.846 Y232.369 Z2.341 F25
G1 X91.765 Y232.29 Z2.337 F25
G1 X91.689 Y232.205 Z2.333 F25
G1 X91.62 Y232.114 Z2.329 F25
G1 X91.557 Y232.02 Z2.325 F25
G1 X91.5 Y231.921 Z2.321 F25
G1 X91.451 Y231.818 Z2.317 F25
G1 X91.409 Y231.712 Z2.313 F25
G1 X91.374 Y231.604 Z2.309 F25
G1 X91.347 Y231.494 Z2.305 F25
G1 X91.328 Y231.382 Z2.301 F25
G1 X91.316 Y231.268 Z2.297 F25
G1 X91.313 Y231.155 Z2.293 F25
G1 X91.317 Y231.041 Z2.289 F25
G1 X91.329 Y230.928 Z2.285 F25
G1 X91.349 Y230.816 Z2.281 F25
G1 X91.377 Y230.706 Z2.277 F25
G1 X91.412 Y230.598 Z2.273 F25
G1 X91.455 Y230.493 Z2.269 F25
G1 X91.505 Y230.39 Z2.265 F25
G1 X91.562 Y230.292 Z2.261 F25
G1 X91.626 Y230.198 Z2.257 F25
G1 X91.696 Y230.108 Z2.253 F25
G1 X91.772 Y230.024 Z2.249 F25
G1 X91.854 Y229.945 Z2.245 F25
G1 X91.941 Y229.872 Z2.241 F25
G1 X92.033 Y229.805 Z2.237 F25
G1 X92.129 Y229.745 Z2.233 F25
G1 X92.23 Y229.691 Z2.229 F25
G1 X92.334 Y229.645 Z2.225 F25
G1 X92.44 Y229.606 Z2.222 F25
G1 X92.55 Y229.574 Z2.218 F25
G1 X92.661 Y229.551 Z2.214 F25
G1 X92.773 Y229.534 Z2.21 F25
G1 X92.887 Y229.526 Z2.206 F25
G1 X93.001 Z2.202 F25
G1 X93.114 Y229.534 Z2.198 F25
G1 X93.227 Y229.549 Z2.194 F25
G1 X93.338 Y229.572 Z2.19 F25
G1 X93.447 Y229.603 Z2.186 F25
G1 X93.554 Y229.642 Z2.182 F25
G1 X93.658 Y229.687 Z2.178 F25
G1 X93.758 Y229.74 Z2.174 F25
G1 X93.855 Y229.8 Z2.17 F25
G1 X93.947 Y229.866 Z2.166 F25
G1 X94.035 Y229.939 Z2.162 F25
G1 X94.117 Y230.017 Z2.158 F25
G1 X94.193 Y230.101 Z2.154 F25
G1 X94.264 Y230.19 Z2.15 F25
G1 X94.328 Y230.284 Z2.146 F25
G1 X94.385 Y230.382 Z2.142 F25
G1 X94.436 Y230.484 Z2.138 F25
G1 X94.479 Y230.589 Z2.134 F25
G1 X94.515 Y230.696 Z2.13 F25
G1 X94.543 Y230.806 Z2.126 F25
G1 X94.564 Y230.918 Z2.122 F25
G1 X94.576 Y231.031 Z2.118 F25
G1 X94.581 Y231.144 Z2.114 F25
G1 X94.578 Y231.258 Z2.11 F25
G1 X94.568 Y231.371 Z2.106 F25
G1 X94.549 Y231.483 Z2.102 F25
G1 X94.522 Y231.593 Z2.098 F25
G1 X94.488 Y231.702 Z2.094 F25
G1 X94.447 Y231.808 Z2.09 F25
G1 X94.398 Y231.91 Z2.086 F25
G1 X94.342 Y232.009 Z2.082 F25
G1 X94.28 Y232.104 Z2.078 F25
G1 X94.211 Y232.194 Z2.074 F25
G1 X94.136 Y232.279 Z2.07 F25
G1 X94.055 Y232.359 Z2.066 F25
G1 X93.969 Y232.433 Z2.062 F25
G1 X93.879 Y232.501 Z2.058 F25
G1 X93.783 Y232.562 Z2.054 F25
G1 X93.684 Y232.616 Z2.05 F25
G1 X93.581 Y232.664 Z2.046 F25
G1 X93.475 Y232.704 Z2.042 F25
G1 X93.366 Y232.737 Z2.038 F25
G1 X93.255 Y232.762 Z2.034 F25
G1 X93.143 Y232.779 Z2.03 F25
G1 X93.03 Y232.789 Z2.026 F25
G1 X92.917 Y232.79 Z2.022 F25
G1 X92.804 Y232.784 Z2.018 F25
G1 X92.691 Y232.77 Z2.014 F25
G1 X92.58 Y232.748 Z2.011 F25
G1 X92.47 Y232.719 Z2.007 F25
G1 X92.363 Y232.682 Z2.003 F25
G1 X92.259 Y232.637 Z1.999 F25
G1 X92.158 Y232.585 Z1.995 F25
G1 X92.061 Y232.527 Z1.991 F25
G1 X91.968 Y232.462 Z1.987 F25
G1 X91.88 Y232.39 Z1.983 F25
G1 X91.797 Y232.313 Z1.979 F25
G1 X91.719 Y232.23 Z1.975 F25
G1 X91.648 Y232.142 Z1.971 F25
G1 X91.583 Y232.049 Z1.967 F25
G1 X91.524 Y231.952 Z1.963 F25
G1 X91.473 Y231.851 Z1.959 F25
G1 X91.428 Y231.747 Z1.955 F25
G1 X91.391 Y231.64 Z1.951 F25
G1 X91.361 Y231.531 Z1.947 F25
G1 X91.34 Y231.419 Z1.943 F25
G1 X91.326 Y231.307 Z1.939 F25
G1 X91.319 Y231.194 Z1.935 F25
G1 X91.321 Y231.081 Z1.931 F25
G1 X91.33 Y230.968 Z1.927 F25
G1 X91.348 Y230.856 Z1.923 F25
G1 X91.373 Y230.745 Z1.919 F25
G1 X91.405 Y230.637 Z1.915 F25
G1 X91.445 Y230.531 Z1.911 F25
G1 X91.493 Y230.428 Z1.907 F25
G1 X91.547 Y230.329 Z1.903 F25
G1 X91.609 Y230.233 Z1.899 F25
G1 X91.676 Y230.142 Z1.895 F25
G1 X91.75 Y230.057 Z1.891 F25
G1 X91.83 Y229.976 Z1.887 F25
G1 X91.915 Y229.901 Z1.883 F25
G1 X92.005 Y229.832 Z1.879 F25
G1 X92.099 Y229.77 Z1.875 F25
G1 X92.198 Y229.714 Z1.871 F25
G1 X92.3 Y229.666 Z1.867 F25
G1 X92.406 Y229.624 Z1.863 F25
G1 X92.514 Y229.59 Z1.859 F25
G1 X92.624 Y229.564 Z1.855 F25
G1 X92.736 Y229.545 Z1.851 F25
G1 X92.848 Y229.534 Z1.847 F25
G1 X92.961 Y229.531 Z1.843 F25
G1 X93.075 Y229.536 Z1.839 F25
G1 X93.187 Y229.549 Z1.835 F25
G1 X93.298 Y229.569 Z1.831 F25
G1 X93.408 Y229.598 Z1.827 F25
G1 X93.515 Y229.633 Z1.823 F25
G1 X93.62 Y229.676 Z1.819 F25
G1 X93.721 Y229.727 Z1.815 F25
G1 X93.819 Y229.784 Z1.811 F25
G1 X93.912 Y229.848 Z1.807 F25
G1 X94.001 Y229.918 Z1.803 F25
G1 X94.085 Y229.994 Z1.799 F25
G1 X94.163 Y230.076 Z1.796 F25
G1 X94.235 Y230.163 Z1.792 F25
G1 X94.301 Y230.255 Z1.788 F25
G1 X94.361 Y230.351 Z1.784 F25
G1 X94.413 Y230.451 Z1.78 F25
G1 X94.459 Y230.555 Z1.776 F25
G1 X94.497 Y230.661 Z1.772 F25
G1 X94.528 Y230.77 Z1.768 F25
G1 X94.551 Y230.881 Z1.764 F25
G1 X94.567 Y230.993 Z1.76 F25
G1 X94.574 Y231.106 Z1.756 F25
G1 Y231.219 Z1.752 F25
G1 X94.566 Y231.332 Z1.748 F25
G1 X94.55 Y231.444 Z1.744 F25
G1 X94.526 Y231.554 Z1.74 F25
G1 X94.495 Y231.663 Z1.736 F25
G1 X94.456 Y231.769 Z1.732 F25
G1 X94.41 Y231.873 Z1.728 F25
G1 X94.357 Y231.972 Z1.724 F25
G1 X94.297 Y232.068 Z1.72 F25
G1 X94.231 Y232.16 Z1.716 F25
G1 X94.158 Y232.246 Z1.712 F25
G1 X94.08 Y232.327 Z1.708 F25
G1 X93.996 Y232.403 Z1.704 F25
G1 X93.907 Y232.473 Z1.7 F25
G1 X93.813 Y232.536 Z1.696 F25
G1 X93.715 Y232.593 Z1.692 F25
G1 X93.614 Y232.643 Z1.688 F25
G1 X93.509 Y232.685 Z1.684 F25
G1 X93.402 Y232.72 Z1.68 F25
G1 X93.292 Y232.748 Z1.676 F25
G1 X93.181 Y232.768 Z1.672 F25
G1 X93.069 Y232.78 Z1.668 F25
G1 X92.956 Y232.784 Z1.664 F25
G1 X92.843 Y232.781 Z1.66 F25
G1 X92.73 Y232.77 Z1.656 F25
G1 X92.619 Y232.75 Z1.652 F25
G1 X92.509 Y232.724 Z1.648 F25
G1 X92.402 Y232.689 Z1.644 F25
G1 X92.297 Y232.647 Z1.64 F25
G1 X92.195 Y232.598 Z1.636 F25
G1 X92.097 Y232.542 Z1.632 F25
G1 X92.003 Y232.48 Z1.628 F25
G1 X91.913 Y232.411 Z1.624 F25
G1 X91.829 Y232.336 Z1.62 F25
G1 X91.75 Y232.255 Z1.616 F25
G1 X91.676 Y232.169 Z1.612 F25
G1 X91.609 Y232.078 Z1.608 F25
G1 X91.549 Y231.983 Z1.604 F25
G1 X91.495 Y231.884 Z1.6 F25
G1 X91.448 Y231.781 Z1.596 F25
G1 X91.409 Y231.675 Z1.592 F25
G1 X91.377 Y231.567 Z1.588 F25
G1 X91.352 Y231.457 Z1.585 F25
G1 X91.336 Y231.345 Z1.581 F25
G1 X91.327 Y231.233 Z1.577 F25
G1 X91.326 Y231.12 Z1.573 F25
G1 X91.332 Y231.007 Z1.569 F25
G1 X91.347 Y230.895 Z1.565 F25
G1 X91.369 Y230.785 Z1.561 F25
G1 X91.399 Y230.676 Z1.557 F25
G1 X91.437 Y230.569 Z1.553 F25
G1 X91.482 Y230.466 Z1.549 F25
G1 X91.533 Y230.365 Z1.545 F25
G1 X91.592 Y230.269 Z1.541 F25
G1 X91.657 Y230.177 Z1.537 F25
G1 X91.729 Y230.09 Z1.533 F25
G1 X91.806 Y230.007 Z1.529 F25
G1 X91.889 Y229.931 Z1.525 F25
G1 X91.977 Y229.86 Z1.521 F25
G1 X92.07 Y229.796 Z1.517 F25
G1 X92.167 Y229.738 Z1.513 F25
G1 X92.267 Y229.687 Z1.509 F25
G1 X92.371 Y229.643 Z1.505 F25
G1 X92.478 Y229.607 Z1.501 F25
G1 X92.587 Y229.578 Z1.497 F25
G1 X92.698 Y229.557 Z1.493 F25
G1 X92.81 Y229.543 Z1.489 F25
G1 X92.922 Y229.538 Z1.485 F25
G1 X93.035 Y229.54 Z1.481 F25
G1 X93.147 Y229.55 Z1.477 F25
G1 X93.259 Y229.568 Z1.473 F25
G1 X93.369 Y229.593 Z1.469 F25
G1 X93.476 Y229.626 Z1.465 F25
G1 X93.582 Y229.667 Z1.461 F25
G1 X93.684 Y229.714 Z1.457 F25
G1 X93.782 Y229.769 Z1.453 F25
G1 X93.877 Y229.83 Z1.449 F25
G1 X93.967 Y229.898 Z1.445 F25
G1 X94.052 Y229.972 Z1.441 F25
G1 X94.132 Y230.052 Z1.437 F25
G1 X94.206 Y230.136 Z1.433 F25
G1 X94.274 Y230.226 Z1.429 F25
G1 X94.336 Y230.321 Z1.425 F25
G1 X94.39 Y230.419 Z1.421 F25
G1 X94.438 Y230.521 Z1.417 F25
G1 X94.479 Y230.626 Z1.413 F25
G1 X94.512 Y230.734 Z1.409 F25
G1 X94.538 Y230.844 Z1.405 F25
G1 X94.556 Y230.955 Z1.401 F25
G1 X94.566 Y231.067 Z1.397 F25
G1 X94.569 Y231.18 Z1.393 F25
G1 X94.563 Y231.293 Z1.389 F25
G1 X94.55 Y231.405 Z1.385 F25
G1 X94.529 Y231.515 Z1.381 F25
G1 X94.501 Y231.624 Z1.377 F25
G1 X94.465 Y231.731 Z1.374 F25
G1 X94.421 Y231.835 Z1.37 F25
G1 X94.371 Y231.935 Z1.366 F25
G1 X94.313 Y232.032 Z1.362 F25
G1 X94.249 Y232.125 Z1.358 F25
G1 X94.179 Y232.213 Z1.354 F25
G1 X94.103 Y232.296 Z1.35 F25
G1 X94.021 Y232.373 Z1.346 F25
G1 X93.934 Y232.445 Z1.342 F25
G1 X93.842 Y232.51 Z1.338 F25
G1 X93.746 Y232.569 Z1.334 F25
G1 X93.647 Y232.621 Z1.33 F25
G1 X93.543 Y232.665 Z1.326 F25
G1 X93.437 Y232.703 Z1.322 F25
G1 X93.329 Y232.733 Z1.318 F25
G1 X93.218 Y232.756 Z1.314 F25
G1 X93.107 Y232.77 Z1.31 F25
G1 X92.994 Y232.777 Z1.306 F25
G1 X92.882 Z1.302 F25
G1 X92.77 Y232.768 Z1.298 F25
G1 X92.658 Y232.752 Z1.294 F25
G1 X92.548 Y232.728 Z1.29 F25
G1 X92.44 Y232.696 Z1.286 F25
G1 X92.335 Y232.657 Z1.282 F25
G1 X92.232 Y232.61 Z1.278 F25
G1 X92.133 Y232.557 Z1.274 F25
G1 X92.038 Y232.497 Z1.27 F25
G1 X91.947 Y232.43 Z1.266 F25
G1 X91.861 Y232.358 Z1.262 F25
G1 X91.781 Y232.279 Z1.258 F25
G1 X91.706 Y232.195 Z1.254 F25
G1 X91.637 Y232.106 Z1.25 F25
G1 X91.574 Y232.013 Z1.246 F25
G1 X91.518 Y231.915 Z1.242 F25
G1 X91.469 Y231.814 Z1.238 F25
G1 X91.428 Y231.71 Z1.234 F25
G1 X91.393 Y231.603 Z1.23 F25
G1 X91.366 Y231.494 Z1.226 F25
G1 X91.347 Y231.383 Z1.222 F25
G1 X91.335 Y231.271 Z1.218 F25
G1 X91.332 Y231.159 Z1.214 F25
G1 X91.336 Y231.046 Z1.21 F25
G1 X91.347 Y230.934 Z1.206 F25
G1 X91.367 Y230.824 Z1.202 F25
G1 X91.394 Y230.715 Z1.198 F25
G1 X91.429 Y230.608 Z1.194 F25
G1 X91.471 Y230.503 Z1.19 F25
G1 X91.52 Y230.402 Z1.186 F25
G1 X91.576 Y230.305 Z1.182 F25
G1 X91.639 Y230.212 Z1.178 F25
G1 X91.708 Y230.123 Z1.174 F25
G1 X91.783 Y230.039 Z1.17 F25
G1 X91.864 Y229.961 Z1.166 F25
G1 X91.95 Y229.889 Z1.163 F25
G1 X92.041 Y229.822 Z1.159 F25
G1 X92.136 Y229.762 Z1.155 F25
G1 X92.235 Y229.709 Z1.151 F25
G1 X92.338 Y229.663 Z1.147 F25
G1 X92.443 Y229.625 Z1.143 F25
G1 X92.551 Y229.593 Z1.139 F25
G1 X92.661 Y229.57 Z1.135 F25
G1 X92.772 Y229.553 Z1.131 F25
G1 X92.884 Y229.545 Z1.127 F25
G1 X92.996 Z1.123 F25
G1 X93.108 Y229.552 Z1.119 F25
G1 X93.219 Y229.567 Z1.115 F25
G1 X93.329 Y229.59 Z1.111 F25
G1 X93.438 Y229.62 Z1.107 F25
G1 X93.543 Y229.658 Z1.103 F25
G1 X93.646 Y229.703 Z1.099 F25
G1 X93.746 Y229.755 Z1.095 F25
G1 X93.841 Y229.814 Z1.091 F25
G1 X93.933 Y229.879 Z1.087 F25
G1 X94.019 Y229.951 Z1.083 F25
G1 X94.101 Y230.028 Z1.079 F25
G1 X94.176 Y230.111 Z1.075 F25
G1 X94.246 Y230.199 Z1.071 F25
G1 X94.31 Y230.291 Z1.067 F25
G1 X94.367 Y230.388 Z1.063 F25
G1 X94.417 Y230.489 Z1.059 F25
G1 X94.46 Y230.592 Z1.055 F25
G1 X94.496 Y230.699 Z1.051 F25
G1 X94.524 Y230.807 Z1.047 F25
G1 X94.545 Y230.918 Z1.043 F25
G1 X94.558 Y231.029 Z1.039 F25
G1 X94.563 Y231.141 Z1.035 F25
G1 X94.56 Y231.254 Z1.031 F25
G1 X94.549 Y231.365 Z1.027 F25
G1 X94.531 Y231.476 Z1.023 F25
G1 X94.505 Y231.585 Z1.019 F25
G1 X94.472 Y231.692 Z1.015 F25
G1 X94.431 Y231.797 Z1.011 F25
G1 X94.383 Y231.898 Z1.007 F25
G1 X94.328 Y231.996 Z1.003 F25
G1 X94.267 Y232.09 Z0.999 F25
G1 X94.199 Y232.179 Z0.995 F25
G1 X94.125 Y232.263 Z0.991 F25
G1 X94.046 Y232.342 Z0.987 F25
G1 X93.961 Y232.416 Z0.983 F25
G1 X93.871 Y232.483 Z0.979 F25
G1 X93.777 Y232.544 Z0.975 F25
G1 X93.678 Y232.598 Z0.971 F25
G1 X93.577 Y232.645 Z0.967 F25
G1 X93.472 Y232.685 Z0.963 F25
G1 X93.365 Y232.718 Z0.959 F25
G1 X93.255 Y232.743 Z0.955 F25
G1 X93.144 Y232.76 Z0.952 F25
G1 X93.033 Y232.77 Z0.948 F25
G1 X92.92 Y232.772 Z0.944 F25
G1 X92.808 Y232.766 Z0.94 F25
G1 X92.697 Y232.752 Z0.936 F25
G1 X92.587 Y232.731 Z0.932 F25
G1 X92.479 Y232.702 Z0.928 F25
G1 X92.373 Y232.665 Z0.924 F25
G1 X92.269 Y232.621 Z0.92 F25
G1 X92.17 Y232.571 Z0.916 F25
G1 X92.074 Y232.513 Z0.912 F25
G1 X91.982 Y232.449 Z0.908 F25
G1 X91.894 Y232.379 Z0.904 F25
G1 X91.812 Y232.302 Z0.9 F25
G1 X91.736 Y232.221 Z0.896 F25
G1 X91.665 Y232.134 Z0.892 F25
G1 X91.6 Y232.042 Z0.888 F25
G1 X91.542 Y231.946 Z0.884 F25
G1 X91.491 Y231.847 Z0.88 F25
G1 X91.447 Y231.744 Z0.876 F25
G1 X91.41 Y231.638 Z0.872 F25
G1 X91.381 Y231.53 Z0.868 F25
G1 X91.359 Y231.42 Z0.864 F25
G1 X91.345 Y231.309 Z0.86 F25
G1 X91.338 Y231.197 Z0.856 F25
G1 X91.34 Y231.085 Z0.852 F25
G1 X91.349 Y230.974 Z0.848 F25
G1 X91.366 Y230.863 Z0.844 F25
G1 X91.39 Y230.753 Z0.84 F25
G1 X91.422 Y230.646 Z0.836 F25
G1 X91.462 Y230.541 Z0.832 F25
G1 X91.508 Y230.439 Z0.828 F25
G1 X91.562 Y230.341 Z0.824 F25
G1 X91.622 Y230.247 Z0.82 F25
G1 X91.689 Y230.157 Z0.816 F25
G1 X91.762 Y230.072 Z0.812 F25
G1 X91.84 Y229.992 Z0.808 F25
G1 X91.924 Y229.918 Z0.804 F25
G1 X92.013 Y229.849 Z0.8 F25
G1 X92.106 Y229.788 Z0.796 F25
G1 X92.203 Y229.733 Z0.792 F25
G1 X92.304 Y229.684 Z0.788 F25
G1 X92.408 Y229.643 Z0.784 F25
G1 X92.515 Y229.609 Z0.78 F25
G1 X92.624 Y229.583 Z0.776 F25
G1 X92.734 Y229.564 Z0.772 F25
G1 X92.846 Y229.553 Z0.768 F25
G1 X92.957 Y229.55 Z0.764 F25
G1 X93.069 Y229.555 Z0.76 F25
G1 X93.18 Y229.567 Z0.756 F25
G1 X93.29 Y229.587 Z0.752 F25
G1 X93.399 Y229.615 Z0.748 F25
G1 X93.505 Y229.65 Z0.744 F25
G1 X93.609 Y229.692 Z0.741 F25
G1 X93.709 Y229.742 Z0.737 F25
G1 X93.806 Y229.798 Z0.733 F25
G1 X93.898 Y229.861 Z0.729 F25
G1 X93.986 Y229.93 Z0.725 F25
G1 X94.069 Y230.005 Z0.721 F25
G1 X94.146 Y230.086 Z0.717 F25
G1 X94.218 Y230.172 Z0.713 F25
G1 X94.284 Y230.263 Z0.709 F25
G1 X94.343 Y230.358 Z0.705 F25
G1 X94.395 Y230.457 Z0.701 F25
G1 X94.44 Y230.559 Z0.697 F25
G1 X94.478 Y230.664 Z0.693 F25
G1 X94.509 Y230.771 Z0.689 F25
G1 X94.532 Y230.881 Z0.685 F25
G1 X94.548 Y230.991 Z0.681 F25
G1 X94.555 Y231.103 Z0.677 F25
G1 Y231.215 Z0.673 F25
G1 X94.548 Y231.326 Z0.669 F25
G1 X94.532 Y231.437 Z0.665 F25
G1 X94.509 Y231.546 Z0.661 F25
G1 X94.478 Y231.654 Z0.657 F25
G1 X94.44 Y231.759 Z0.653 F25
G1 X94.395 Y231.861 Z0.649 F25
G1 X94.343 Y231.959 Z0.645 F25
G1 X94.284 Y232.054 Z0.641 F25
G1 X94.218 Y232.145 Z0.637 F25
G1 X94.147 Y232.231 Z0.633 F25
G1 X94.069 Y232.311 Z0.629 F25
G1 X93.986 Y232.386 Z0.625 F25
G1 X93.899 Y232.455 Z0.621 F25
G1 X93.806 Y232.518 Z0.617 F25
G1 X93.71 Y232.574 Z0.613 F25
G1 X93.609 Y232.624 Z0.609 F25
G1 X93.506 Y232.666 Z0.605 F25
G1 X93.4 Y232.701 Z0.601 F25
G1 X93.291 Y232.729 Z0.597 F25
G1 X93.182 Y232.749 Z0.593 F25
G1 X93.07 Y232.761 Z0.589 F25
G1 X92.959 Y232.766 Z0.585 F25
G1 X92.847 Y232.762 Z0.581 F25
G1 X92.736 Y232.751 Z0.577 F25
G1 X92.626 Y232.733 Z0.573 F25
G1 X92.517 Y232.706 Z0.569 F25
G1 X92.411 Y232.673 Z0.565 F25
G1 X92.307 Y232.632 Z0.561 F25
G1 X92.207 Y232.583 Z0.557 F25
G1 X92.11 Y232.528 Z0.553 F25
G1 X92.016 Y232.467 Z0.549 F25
G1 X91.928 Y232.399 Z0.545 F25
G1 X91.844 Y232.325 Z0.541 F25
G1 X91.766 Y232.245 Z0.537 F25
G1 X91.694 Y232.16 Z0.533 F25
G1 X91.627 Y232.071 Z0.529 F25
G1 X91.567 Y231.977 Z0.526 F25
G1 X91.514 Y231.879 Z0.522 F25
G1 X91.467 Y231.777 Z0.518 F25
G1 X91.428 Y231.673 Z0.514 F25
G1 X91.396 Y231.566 Z0.51 F25
G1 X91.372 Y231.457 Z0.506 F25
G1 X91.355 Y231.347 Z0.502 F25
G1 X91.346 Y231.235 Z0.498 F25
G1 X91.345 Y231.124 Z0.494 F25
G1 X91.351 Y231.012 Z0.49 F25
G1 X91.365 Y230.902 Z0.486 F25
G1 X91.387 Y230.792 Z0.482 F25
G1 X91.416 Y230.685 Z0.478 F25
G1 X91.453 Y230.579 Z0.474 F25
G1 X91.497 Y230.477 Z0.47 F25
G1 X91.548 Y230.377 Z0.466 F25
G1 X91.606 Y230.282 Z0.462 F25
G1 X91.67 Y230.191 Z0.458 F25
G1 X91.741 Y230.104 Z0.454 F25
G1 X91.817 Y230.023 Z0.45 F25
G1 X91.899 Y229.947 Z0.446 F25
G1 X91.985 Y229.877 Z0.442 F25
G1 X92.077 Y229.814 Z0.438 F25
G1 X92.172 Y229.756 Z0.434 F25
G1 X92.272 Y229.706 Z0.43 F25
G1 X92.374 Y229.662 Z0.426 F25
G1 X92.48 Y229.626 Z0.422 F25
G1 X92.588 Y229.597 Z0.418 F25
G1 X92.697 Y229.576 Z0.414 F25
G1 X92.808 Y229.563 Z0.41 F25
G1 X92.919 Y229.557 Z0.406 F25
G1 X93.03 Y229.559 Z0.402 F25
G1 X93.141 Y229.568 Z0.398 F25
G1 X93.252 Y229.586 Z0.394 F25
G1 X93.36 Y229.611 Z0.39 F25
G1 X93.467 Y229.643 Z0.386 F25
G1 X93.571 Y229.683 Z0.382 F25
G1 X93.672 Y229.73 Z0.378 F25
G1 X93.77 Y229.783 Z0.374 F25
G1 X93.863 Y229.844 Z0.37 F25
G1 X93.953 Y229.911 Z0.366 F25
G1 X94.037 Y229.984 Z0.362 F25
G1 X94.116 Y230.062 Z0.358 F25
G1 X94.189 Y230.146 Z0.354 F25
G1 X94.257 Y230.235 Z0.35 F25
G1 X94.318 Y230.328 Z0.346 F25
G1 X94.372 Y230.425 Z0.342 F25
G1 X94.42 Y230.526 Z0.338 F25
G1 X94.46 Y230.629 Z0.334 F25
G1 X94.493 Y230.736 Z0.33 F25
G1 X94.519 Y230.844 Z0.326 F25
G1 X94.537 Y230.954 Z0.322 F25
G1 X94.547 Y231.065 Z0.318 F25
G1 X94.55 Y231.176 Z0.315 F25
G1 X94.545 Y231.287 Z0.311 F25
G1 X94.532 Y231.398 Z0.307 F25
G1 X94.512 Y231.507 Z0.303 F25
G1 X94.484 Y231.615 Z0.299 F25
G1 X94.448 Y231.72 Z0.295 F25
G1 X94.406 Y231.823 Z0.291 F25
G1 X94.356 Y231.923 Z0.287 F25
G1 X94.299 Y232.019 Z0.283 F25
G1 X94.236 Y232.111 Z0.279 F25
G1 X94.167 Y232.198 Z0.275 F25
G1 X94.092 Y232.28 Z0.271 F25
G1 X94.011 Y232.356 Z0.267 F25
G1 X93.925 Y232.427 Z0.263 F25
G1 X93.835 Y232.492 Z0.259 F25
G1 X93.74 Y232.55 Z0.255 F25
G1 X93.641 Y232.602 Z0.251 F25
G1 X93.539 Y232.647 Z0.247 F25
G1 X93.434 Y232.684 Z0.243 F25
G1 X93.327 Y232.714 Z0.239 F25
G1 X93.218 Y232.737 Z0.235 F25
G1 X93.108 Y232.751 Z0.231 F25
G1 X92.997 Y232.759 Z0.227 F25
G1 X92.886 Y232.758 Z0.223 F25
G1 X92.775 Y232.75 Z0.219 F25
G1 X92.665 Y232.734 Z0.215 F25
G1 X92.556 Y232.71 Z0.211 F25
G1 X92.45 Y232.679 Z0.207 F25
G1 X92.345 Y232.641 Z0.203 F25
G1 X92.244 Y232.595 Z0.199 F25
G1 X92.146 Y232.543 Z0.195 F25
G1 X92.052 Y232.484 Z0.191 F25
G1 X91.962 Y232.418 Z0.187 F25
G1 X91.877 Y232.346 Z0.183 F25
G1 X91.797 Y232.269 Z0.179 F25
G1 X91.723 Y232.186 Z0.175 F25
G1 X91.654 Y232.098 Z0.171 F25
G1 X91.592 Y232.006 Z0.167 F25
G1 X91.537 Y231.91 Z0.163 F25
G1 X91.488 Y231.81 Z0.159 F25
G1 X91.447 Y231.707 Z0.155 F25
G1 X91.412 Y231.601 Z0.151 F25
G1 X91.385 Y231.493 Z0.147 F25
G1 X91.366 Y231.384 Z0.143 F25
G1 X91.354 Y231.273 Z0.139 F25
G1 X91.35 Y231.162 Z0.135 F25
G1 X91.354 Y231.051 Z0.131 F25
G1 X91.366 Y230.94 Z0.127 F25
G1 X91.385 Y230.831 Z0.123 F25
G1 X91.411 Y230.723 Z0.119 F25
G1 X91.446 Y230.617 Z0.115 F25
G1 X91.487 Y230.514 Z0.111 F25
G1 X91.535 Y230.414 Z0.107 F25
G1 X91.591 Y230.318 Z0.104 F25
G1 X91.652 Y230.225 Z0.1 F25
G1 X91.72 Y230.138 Z0.096 F25
G1 X91.794 Y230.055 Z0.092 F25
G1 X91.874 Y229.977 Z0.088 F25
G1 X91.959 Y229.906 Z0.084 F25
G1 X92.048 Y229.84 Z0.08 F25
G1 X92.142 Y229.781 Z0.076 F25
G1 X92.24 Y229.728 Z0.072 F25
G1 X92.341 Y229.682 Z0.068 F25
G1 X92.445 Y229.644 Z0.064 F25
G1 X92.552 Y229.613 Z0.06 F25
G1 X92.66 Y229.589 Z0.056 F25
G1 X92.77 Y229.573 Z0.052 F25
G1 X92.881 Y229.564 Z0.048 F25
G1 X92.992 Y229.563 Z0.044 F25
G1 X93.103 Y229.57 Z0.04 F25
G1 X93.213 Y229.585 Z0.036 F25
G1 X93.322 Y229.607 Z0.032 F25
G1 X93.429 Y229.637 Z0.028 F25
G1 X93.533 Y229.674 Z0.024 F25
G1 X93.635 Y229.718 Z0.02 F25
G1 X93.734 Y229.77 Z0.016 F25
G1 X93.828 Y229.828 Z0.012 F25
G1 X93.919 Y229.892 Z0.008 F25
G1 X94.004 Y229.963 Z0.004 F25
G1 X94.085 Y230.039 Z0 F25
G1 X94.16 Y230.121 Z-0.004 F25
G1 X94.229 Y230.207 Z-0.008 F25
G1 X94.292 Y230.299 Z-0.012 F25
G1 X94.349 Y230.394 Z-0.016 F25
G1 X94.399 Y230.493 Z-0.02 F25
G1 X94.441 Y230.595 Z-0.024 F25
G1 X94.477 Y230.701 Z-0.028 F25
G1 X94.505 Y230.808 Z-0.032 F25
G1 X94.525 Y230.917 Z-0.036 F25
G1 X94.538 Y231.027 Z-0.04 F25
G1 X94.544 Y231.138 Z-0.044 F25
G1 X94.541 Y231.249 Z-0.048 F25
G1 X94.531 Y231.359 Z-0.052 F25
G1 X94.513 Y231.468 Z-0.056 F25
G1 X94.488 Y231.576 Z-0.06 F25
G1 X94.455 Y231.682 Z-0.064 F25
G1 X94.415 Y231.786 Z-0.068 F25
G1 X94.368 Y231.886 Z-0.072 F25
G1 X94.314 Y231.983 Z-0.076 F25
G1 X94.253 Y232.076 Z-0.08 F25
G1 X94.187 Y232.164 Z-0.084 F25
G1 X94.114 Y232.248 Z-0.088 F25
G1 X94.035 Y232.326 Z-0.092 F25
G1 X93.951 Y232.399 Z-0.096 F25
G1 X93.863 Y232.466 Z-0.1 F25
G1 X93.77 Y232.526 Z-0.104 F25
G1 X93.673 Y232.58 Z-0.107 F25
G1 X93.572 Y232.626 Z-0.111 F25
G1 X93.469 Y232.666 Z-0.115 F25
G1 X93.363 Y232.699 Z-0.119 F25
G1 X93.255 Y232.724 Z-0.123 F25
G1 X93.145 Y232.741 Z-0.127 F25
G1 X93.035 Y232.751 Z-0.131 F25
G1 X92.924 Y232.753 Z-0.135 F25
G1 X92.814 Y232.747 Z-0.139 F25
G1 X92.704 Y232.734 Z-0.143 F25
G1 X92.595 Y232.713 Z-0.147 F25
G1 X92.488 Y232.685 Z-0.151 F25
G1 X92.383 Y232.649 Z-0.155 F25
G1 X92.281 Y232.606 Z-0.159 F25
G1 X92.182 Y232.556 Z-0.163 F25
G1 X92.087 Y232.499 Z-0.167 F25
G1 X91.996 Y232.436 Z-0.171 F25
G1 X91.91 Y232.367 Z-0.175 F25
G1 X91.828 Y232.292 Z-0.179 F25
G1 X91.752 Y232.211 Z-0.183 F25
G1 X91.682 Y232.125 Z-0.187 F25
G1 X91.618 Y232.035 Z-0.191 F25
G1 X91.561 Y231.94 Z-0.195 F25
G1 X91.51 Y231.842 Z-0.199 F25
G1 X91.466 Y231.74 Z-0.203 F25
G1 X91.429 Y231.636 Z-0.207 F25
G1 X91.4 Y231.529 Z-0.211 F25
G1 X91.378 Y231.42 Z-0.215 F25
G1 X91.364 Y231.31 Z-0.219 F25
G1 X91.357 Y231.2 Z-0.223 F25
G1 X91.358 Y231.089 Z-0.227 F25
G1 X91.367 Y230.979 Z-0.231 F25
G1 X91.383 Y230.869 Z-0.235 F25
G1 X91.407 Y230.761 Z-0.239 F25
G1 X91.439 Y230.655 Z-0.243 F25
G1 X91.478 Y230.552 Z-0.247 F25
G1 X91.523 Y230.451 Z-0.251 F25
G1 X91.576 Y230.354 Z-0.255 F25
G1 X91.636 Y230.26 Z-0.259 F25
G1 X91.701 Y230.171 Z-0.263 F25
G1 X91.773 Y230.087 Z-0.267 F25
G1 X91.85 Y230.008 Z-0.271 F25
G1 X91.933 Y229.935 Z-0.275 F25
G1 X92.021 Y229.867 Z-0.279 F25
G1 X92.113 Y229.806 Z-0.283 F25
G1 X92.209 Y229.751 Z-0.287 F25
G1 X92.309 Y229.703 Z-0.291 F25
G1 X92.411 Y229.662 Z-0.295 F25
G1 X92.517 Y229.629 Z-0.299 F25
G1 X92.624 Y229.602 Z-0.303 F25
G1 X92.733 Y229.584 Z-0.307 F25
G1 X92.843 Y229.573 Z-0.311 F25
G1 X92.954 Y229.569 Z-0.315 F25
G1 X93.064 Y229.573 Z-0.318 F25
G1 X93.174 Y229.585 Z-0.322 F25
G1 X93.283 Y229.605 Z-0.326 F25
G1 X93.39 Y229.632 Z-0.33 F25
G1 X93.496 Y229.666 Z-0.334 F25
G1 X93.598 Y229.708 Z-0.338 F25
G1 X93.697 Y229.757 Z-0.342 F25
G1 X93.793 Y229.812 Z-0.346 F25
G1 X93.885 Y229.874 Z-0.35 F25
G1 X93.972 Y229.942 Z-0.354 F25
G1 X94.054 Y230.016 Z-0.358 F25
G1 X94.13 Y230.096 Z-0.362 F25
G1 X94.201 Y230.181 Z-0.366 F25
G1 X94.266 Y230.27 Z-0.37 F25
G1 X94.325 Y230.364 Z-0.374 F25
G1 X94.377 Y230.461 Z-0.378 F25
G1 X94.422 Y230.562 Z-0.382 F25
G1 X94.459 Y230.666 Z-0.386 F25
G1 X94.49 Y230.772 Z-0.39 F25
G1 X94.513 Y230.88 Z-0.394 F25
G1 X94.529 Y230.99 Z-0.398 F25
G1 X94.536 Y231.1 Z-0.402 F25
G1 X94.537 Y231.21 Z-0.406 F25
G1 X94.529 Y231.32 Z-0.41 F25
G1 X94.514 Y231.43 Z-0.414 F25
G1 X94.492 Y231.538 Z-0.418 F25
G1 X94.461 Y231.644 Z-0.422 F25
G1 X94.424 Y231.748 Z-0.426 F25
G1 X94.379 Y231.849 Z-0.43 F25
G1 X94.328 Y231.947 Z-0.434 F25
G1 X94.27 Y232.041 Z-0.438 F25
G1 X94.205 Y232.131 Z-0.442 F25
G1 X94.135 Y232.216 Z-0.446 F25
G1 X94.058 Y232.296 Z-0.45 F25
G1 X93.977 Y232.37 Z-0.454 F25
G1 X93.89 Y232.438 Z-0.458 F25
G1 X93.799 Y232.501 Z-0.462 F25
G1 X93.703 Y232.556 Z-0.466 F25
G1 X93.605 Y232.605 Z-0.47 F25
G1 X93.502 Y232.647 Z-0.474 F25
G1 X93.398 Y232.682 Z-0.478 F25
G1 X93.291 Y232.71 Z-0.482 F25
G1 X93.182 Y232.73 Z-0.486 F25
G1 X93.073 Y232.742 Z-0.49 F25
G1 X92.963 Y232.747 Z-0.494 F25
G1 X92.852 Y232.744 Z-0.498 F25
G1 X92.742 Y232.733 Z-0.502 F25
G1 X92.634 Y232.715 Z-0.506 F25
G1 X92.526 Y232.689 Z-0.51 F25
G1 X92.421 Y232.656 Z-0.514 F25
G1 X92.318 Y232.616 Z-0.518 F25
G1 X92.219 Y232.568 Z-0.522 F25
G1 X92.123 Y232.514 Z-0.526 F25
G1 X92.03 Y232.453 Z-0.529 F25
G1 X91.943 Y232.386 Z-0.533 F25
G1 X91.86 Y232.314 Z-0.537 F25
G1 X91.782 Y232.235 Z-0.541 F25
G1 X91.711 Y232.151 Z-0.545 F25
G1 X91.645 Y232.063 Z-0.549 F25
G1 X91.585 Y231.97 Z-0.553 F25
G1 X91.532 Y231.873 Z-0.557 F25
G1 X91.486 Y231.773 Z-0.561 F25
G1 X91.447 Y231.67 Z-0.565 F25
G1 X91.415 Y231.564 Z-0.569 F25
G1 X91.391 Y231.456 Z-0.573 F25
G1 X91.374 Y231.347 Z-0.577 F25
G1 X91.365 Y231.238 Z-0.581 F25
G1 X91.363 Y231.127 Z-0.585 F25
G1 X91.369 Y231.017 Z-0.589 F25
G1 X91.383 Y230.908 Z-0.593 F25
G1 X91.404 Y230.8 Z-0.597 F25
G1 X91.433 Y230.693 Z-0.601 F25
G1 X91.469 Y230.589 Z-0.605 F25
G1 X91.513 Y230.488 Z-0.609 F25
G1 X91.563 Y230.39 Z-0.613 F25
G1 X91.62 Y230.295 Z-0.617 F25
G1 X91.683 Y230.205 Z-0.621 F25
G1 X91.752 Y230.12 Z-0.625 F25
G1 X91.828 Y230.039 Z-0.629 F25
G1 X91.908 Y229.964 Z-0.633 F25
G1 X91.994 Y229.895 Z-0.637 F25
G1 X92.084 Y229.831 Z-0.641 F25
G1 X92.178 Y229.775 Z-0.645 F25
G1 X92.277 Y229.725 Z-0.649 F25
G1 X92.378 Y229.681 Z-0.653 F25
G1 X92.482 Y229.645 Z-0.657 F25
G1 X92.589 Y229.617 Z-0.661 F25
G1 X92.697 Y229.595 Z-0.665 F25
G1 X92.806 Y229.582 Z-0.669 F25
G1 X92.916 Y229.576 Z-0.673 F25
G1 X93.026 Y229.577 Z-0.677 F25
G1 X93.136 Y229.587 Z-0.681 F25
G1 X93.245 Y229.603 Z-0.685 F25
G1 X93.352 Y229.628 Z-0.689 F25
G1 X93.458 Y229.66 Z-0.693 F25
G1 X93.561 Y229.699 Z-0.697 F25
G1 X93.661 Y229.745 Z-0.701 F25
G1 X93.757 Y229.798 Z-0.705 F25
G1 X93.85 Y229.857 Z-0.709 F25
G1 X93.938 Y229.923 Z-0.713 F25
G1 X94.022 Y229.995 Z-0.717 F25
G1 X94.1 Y230.072 Z-0.721 F25
G1 X94.172 Y230.155 Z-0.725 F25
G1 X94.239 Y230.242 Z-0.729 F25
G1 X94.3 Y230.334 Z-0.733 F25
G1 X94.354 Y230.43 Z-0.737 F25
G1 X94.401 Y230.53 Z-0.741 F25
G1 X94.441 Y230.632 Z-0.744 F25
G1 X94.474 Y230.737 Z-0.748 F25
G1 X94.5 Y230.844 Z-0.752 F25
G1 X94.518 Y230.953 Z-0.756 F25
G1 X94.528 Y231.062 Z-0.76 F25
G1 X94.531 Y231.172 Z-0.764 F25
G1 X94.526 Y231.282 Z-0.768 F25
G1 X94.514 Y231.392 Z-0.772 F25
G1 X94.494 Y231.5 Z-0.776 F25
G1 X94.467 Y231.606 Z-0.78 F25
G1 X94.432 Y231.711 Z-0.784 F25
G1 X94.39 Y231.813 Z-0.788 F25
G1 X94.341 Y231.911 Z-0.792 F25
G1 X94.285 Y232.006 Z-0.796 F25
G1 X94.223 Y232.097 Z-0.8 F25
G1 X94.155 Y232.183 Z-0.804 F25
G1 X94.081 Y232.265 Z-0.808 F25
G1 X94.001 Y232.34 Z-0.812 F25
G1 X93.916 Y232.411 Z-0.816 F25
G1 X93.827 Y232.475 Z-0.82 F25
G1 X93.734 Y232.533 Z-0.824 F25
G1 X93.636 Y232.584 Z-0.828 F25
G1 X93.536 Y232.628 Z-0.832 F25
G1 X93.432 Y232.665 Z-0.836 F25
G1 X93.327 Y232.695 Z-0.84 F25
G1 X93.219 Y232.717 Z-0.844 F25
G1 X93.11 Y232.732 Z-0.848 F25
G1 X93 Y232.74 Z-0.852 F25
G1 X92.89 Y232.739 Z-0.856 F25
G1 X92.781 Y232.731 Z-0.86 F25
G1 X92.672 Y232.716 Z-0.864 F25
G1 X92.565 Y232.693 Z-0.868 F25
G1 X92.459 Y232.662 Z-0.872 F25
G1 X92.356 Y232.625 Z-0.876 F25
G1 X92.255 Y232.58 Z-0.88 F25
G1 X92.158 Y232.528 Z-0.884 F25
G1 X92.065 Y232.47 Z-0.888 F25
G1 X91.976 Y232.405 Z-0.892 F25
G1 X91.892 Y232.334 Z-0.896 F25
G1 X91.813 Y232.258 Z-0.9 F25
G1 X91.739 Y232.176 Z-0.904 F25
G1 X91.672 Y232.09 Z-0.908 F25
G1 X91.61 Y231.999 Z-0.912 F25
G1 X91.555 Y231.904 Z-0.916 F25
G1 X91.507 Y231.805 Z-0.92 F25
G1 X91.465 Y231.703 Z-0.924 F25
G1 X91.431 Y231.599 Z-0.928 F25
G1 X91.404 Y231.492 Z-0.932 F25
G1 X91.385 Y231.384 Z-0.936 F25
G1 X91.373 Y231.275 Z-0.94 F25
G1 X91.369 Y231.165 Z-0.944 F25
G1 X91.373 Y231.056 Z-0.948 F25
G1 X91.384 Y230.946 Z-0.952 F25
G1 X91.402 Y230.838 Z-0.955 F25
G1 X91.428 Y230.732 Z-0.959 F25
G1 X91.462 Y230.627 Z-0.963 F25
G1 X91.503 Y230.525 Z-0.967 F25
G1 X91.55 Y230.426 Z-0.971 F25
G1 X91.605 Y230.331 Z-0.975 F25
G1 X91.666 Y230.24 Z-0.979 F25
G1 X91.733 Y230.153 Z-0.983 F25
G1 X91.806 Y230.071 Z-0.987 F25
G1 X91.884 Y229.994 Z-0.991 F25
G1 X91.968 Y229.923 Z-0.995 F25
G1 X92.056 Y229.858 Z-0.999 F25
G1 X92.149 Y229.799 Z-1.003 F25
G1 X92.245 Y229.747 Z-1.007 F25
G1 X92.345 Y229.701 Z-1.011 F25
G1 X92.448 Y229.663 Z-1.015 F25
G1 X92.553 Y229.632 Z-1.019 F25
G1 X92.661 Y229.608 Z-1.023 F25
G1 X92.769 Y229.592 Z-1.027 F25
G1 X92.879 Y229.583 Z-1.031 F25
G1 X92.988 Y229.582 Z-1.035 F25
G1 X93.098 Y229.589 Z-1.039 F25
G1 X93.207 Y229.603 Z-1.043 F25
G1 X93.314 Y229.625 Z-1.047 F25
G1 X93.42 Y229.654 Z-1.051 F25
G1 X93.523 Y229.69 Z-1.055 F25
G1 X93.624 Y229.734 Z-1.059 F25
G1 X93.721 Y229.784 Z-1.063 F25
G1 X93.815 Y229.841 Z-1.067 F25
G1 X93.904 Y229.905 Z-1.071 F25
G1 X93.989 Y229.974 Z-1.075 F25
G1 X94.069 Y230.049 Z-1.079 F25
G1 X94.143 Y230.13 Z-1.083 F25
G1 X94.212 Y230.215 Z-1.087 F25
G1 X94.274 Y230.306 Z-1.091 F25
G1 X94.33 Y230.4 Z-1.095 F25
G1 X94.38 Y230.498 Z-1.099 F25
G1 X94.422 Y230.599 Z-1.103 F25
G1 X94.458 Y230.703 Z-1.107 F25
G1 X94.486 Y230.809 Z-1.111 F25
G1 X94.506 Y230.916 Z-1.115 F25
G1 X94.519 Y231.025 Z-1.119 F25
G1 X94.525 Y231.135 Z-1.123 F25
G1 X94.523 Y231.244 Z-1.127 F25
G1 X94.513 Y231.353 Z-1.131 F25
G1 X94.496 Y231.462 Z-1.135 F25
G1 X94.471 Y231.568 Z-1.139 F25
G1 X94.439 Y231.673 Z-1.143 F25
G1 X94.399 Y231.776 Z-1.147 F25
G1 X94.353 Y231.875 Z-1.151 F25
G1 X94.3 Y231.971 Z-1.155 F25
G1 X94.24 Y232.063 Z-1.159 F25
G1 X94.174 Y232.15 Z-1.163 F25
G1 X94.102 Y232.233 Z-1.166 F25
G1 X94.025 Y232.31 Z-1.17 F25
G1 X93.942 Y232.382 Z-1.174 F25
G1 X93.855 Y232.448 Z-1.178 F25
G1 X93.763 Y232.508 Z-1.182 F25
G1 X93.667 Y232.561 Z-1.186 F25
G1 X93.568 Y232.608 Z-1.19 F25
G1 X93.466 Y232.647 Z-1.194 F25
G1 X93.362 Y232.679 Z-1.198 F25
G1 X93.255 Y232.704 Z-1.202 F25
G1 X93.147 Y232.722 Z-1.206 F25
G1 X93.038 Y232.732 Z-1.21 F25
G1 X92.928 Y232.734 Z-1.214 F25
G1 X92.819 Y232.729 Z-1.218 F25
G1 X92.71 Y232.716 Z-1.222 F25
G1 X92.603 Y232.695 Z-1.226 F25
G1 X92.497 Y232.668 Z-1.23 F25
G1 X92.393 Y232.633 Z-1.234 F25
G1 X92.292 Y232.59 Z-1.238 F25
G1 X92.194 Y232.541 Z-1.242 F25
G1 X92.1 Y232.485 Z-1.246 F25
G1 X92.01 Y232.423 Z-1.25 F25
G1 X91.924 Y232.355 Z-1.254 F25
G1 X91.844 Y232.28 Z-1.258 F25
G1 X91.769 Y232.201 Z-1.262 F25
G1 X91.699 Y232.116 Z-1.266 F25
G1 X91.636 Y232.027 Z-1.27 F25
G1 X91.579 Y231.934 Z-1.274 F25
G1 X91.528 Y231.837 Z-1.278 F25
G1 X91.485 Y231.736 Z-1.282 F25
G1 X91.448 Y231.633 Z-1.286 F25
G1 X91.419 Y231.528 Z-1.29 F25
G1 X91.397 Y231.421 Z-1.294 F25
G1 X91.383 Y231.312 Z-1.298 F25
G1 X91.376 Y231.203 Z-1.302 F25
G1 X91.377 Y231.094 Z-1.306 F25
G1 X91.385 Y230.985 Z-1.31 F25
G1 X91.401 Y230.877 Z-1.314 F25
G1 X91.425 Y230.77 Z-1.318 F25
G1 X91.456 Y230.665 Z-1.322 F25
G1 X91.494 Y230.562 Z-1.326 F25
G1 X91.539 Y230.463 Z-1.33 F25
G1 X91.591 Y230.366 Z-1.334 F25
G1 X91.649 Y230.274 Z-1.338 F25
G1 X91.714 Y230.186 Z-1.342 F25
G1 X91.785 Y230.102 Z-1.346 F25
G1 X91.861 Y230.024 Z-1.35 F25
G1 X91.943 Y229.951 Z-1.354 F25
G1 X92.029 Y229.884 Z-1.358 F25
G1 X92.12 Y229.824 Z-1.362 F25
G1 X92.215 Y229.769 Z-1.366 F25
G1 X92.313 Y229.722 Z-1.37 F25
G1 X92.415 Y229.681 Z-1.374 F25
G1 X92.519 Y229.648 Z-1.377 F25
G1 X92.625 Y229.621 Z-1.381 F25
G1 X92.733 Y229.603 Z-1.385 F25
G1 X92.841 Y229.591 Z-1.389 F25
G1 X92.951 Y229.588 Z-1.393 F25
G1 X93.06 Y229.592 Z-1.397 F25
G1 X93.168 Y229.603 Z-1.401 F25
G1 X93.276 Y229.622 Z-1.405 F25
G1 X93.382 Y229.649 Z-1.409 F25
G1 X93.486 Y229.683 Z-1.413 F25
G1 X93.587 Y229.724 Z-1.417 F25
G1 X93.685 Y229.772 Z-1.421 F25
G1 X93.78 Y229.826 Z-1.425 F25
G1 X93.87 Y229.887 Z-1.429 F25
G1 X93.956 Y229.954 Z-1.433 F25
G1 X94.038 Y230.027 Z-1.437 F25
G1 X94.114 Y230.106 Z-1.441 F25
G1 X94.184 Y230.189 Z-1.445 F25
G1 X94.248 Y230.278 Z-1.449 F25
G1 X94.306 Y230.37 Z-1.453 F25
G1 X94.358 Y230.466 Z-1.457 F25
G1 X94.403 Y230.566 Z-1.461 F25
G1 X94.44 Y230.669 Z-1.465 F25
G1 X94.471 Y230.773 Z-1.469 F25
G1 X94.494 Y230.88 Z-1.473 F25
G1 X94.509 Y230.988 Z-1.477 F25
G1 X94.517 Y231.097 Z-1.481 F25
G1 X94.518 Y231.206 Z-1.485 F25
G1 X94.511 Y231.315 Z-1.489 F25
G1 X94.496 Y231.424 Z-1.493 F25
G1 X94.474 Y231.531 Z-1.497 F25
G1 X94.444 Y231.636 Z-1.501 F25
G1 X94.408 Y231.738 Z-1.505 F25
G1 X94.364 Y231.838 Z-1.509 F25
G1 X94.313 Y231.935 Z-1.513 F25
G1 X94.256 Y232.028 Z-1.517 F25
G1 X94.193 Y232.117 Z-1.521 F25
G1 X94.123 Y232.201 Z-1.525 F25
G1 X94.048 Y232.28 Z-1.529 F25
G1 X93.967 Y232.353 Z-1.533 F25
G1 X93.882 Y232.421 Z-1.537 F25
G1 X93.792 Y232.483 Z-1.541 F25
G1 X93.698 Y232.538 Z-1.545 F25
G1 X93.6 Y232.587 Z-1.549 F25
G1 X93.499 Y232.628 Z-1.553 F25
G1 X93.396 Y232.663 Z-1.557 F25
G1 X93.29 Y232.69 Z-1.561 F25
G1 X93.183 Y232.71 Z-1.565 F25
G1 X93.075 Y232.723 Z-1.569 F25
G1 X92.966 Y232.728 Z-1.573 F25
G1 X92.857 Y232.725 Z-1.577 F25
G1 X92.748 Y232.715 Z-1.581 F25
G1 X92.641 Y232.697 Z-1.585 F25
G1 X92.534 Y232.672 Z-1.588 F25
G1 X92.43 Y232.639 Z-1.592 F25
G1 X92.329 Y232.6 Z-1.596 F25
G1 X92.23 Y232.553 Z-1.6 F25
G1 X92.135 Y232.5 Z-1.604 F25
G1 X92.044 Y232.44 Z-1.608 F25
G1 X91.957 Y232.374 Z-1.612 F25
G1 X91.875 Y232.302 Z-1.616 F25
G1 X91.798 Y232.225 Z-1.62 F25
G1 X91.727 Y232.142 Z-1.624 F25
G1 X91.662 Y232.055 Z-1.628 F25
G1 X91.603 Y231.963 Z-1.632 F25
G1 X91.55 Y231.868 Z-1.636 F25
G1 X91.505 Y231.769 Z-1.64 F25
G1 X91.466 Y231.667 Z-1.644 F25
G1 X91.434 Y231.563 Z-1.648 F25
G1 X91.41 Y231.457 Z-1.652 F25
G1 X91.393 Y231.349 Z-1.656 F25
G1 X91.384 Y231.241 Z-1.66 F25
G1 X91.382 Y231.132 Z-1.664 F25
G1 X91.388 Y231.023 Z-1.668 F25
G1 X91.401 Y230.915 Z-1.672 F25
G1 X91.422 Y230.808 Z-1.676 F25
G1 X91.45 Y230.703 Z-1.68 F25
G1 X91.486 Y230.6 Z-1.684 F25
G1 X91.528 Y230.499 Z-1.688 F25
G1 X91.578 Y230.402 Z-1.692 F25
G1 X91.634 Y230.309 Z-1.696 F25
G1 X91.696 Y230.219 Z-1.7 F25
G1 X91.764 Y230.135 Z-1.704 F25
G1 X91.839 Y230.055 Z-1.708 F25
G1 X91.918 Y229.98 Z-1.712 F25
G1 X92.003 Y229.912 Z-1.716 F25
G1 X92.092 Y229.849 Z-1.72 F25
G1 X92.185 Y229.793 Z-1.724 F25
G1 X92.282 Y229.743 Z-1.728 F25
G1 X92.382 Y229.7 Z-1.732 F25
G1 X92.485 Y229.664 Z-1.736 F25
G1 X92.59 Y229.636 Z-1.74 F25
G1 X92.696 Y229.614 Z-1.744 F25
G1 X92.804 Y229.601 Z-1.748 F25
G1 X92.913 Y229.594 Z-1.752 F25
G1 X93.022 Y229.596 Z-1.756 F25
G1 X93.13 Y229.605 Z-1.76 F25
G1 X93.238 Y229.621 Z-1.764 F25
G1 X93.344 Y229.645 Z-1.768 F25
G1 X93.448 Y229.676 Z-1.772 F25
G1 X93.55 Y229.715 Z-1.776 F25
G1 X93.649 Y229.76 Z-1.78 F25
G1 X93.744 Y229.812 Z-1.784 F25
G1 X93.836 Y229.871 Z-1.788 F25
G1 X93.923 Y229.935 Z-1.792 F25
G1 X94.006 Y230.006 Z-1.796 F25
G1 X94.084 Y230.083 Z-1.799 F25
G1 X94.156 Y230.164 Z-1.803 F25
G1 X94.222 Y230.25 Z-1.807 F25
G1 X94.282 Y230.341 Z-1.811 F25
G1 X94.335 Y230.436 Z-1.815 F25
G1 X94.382 Y230.534 Z-1.819 F25
G1 X94.422 Y230.635 Z-1.823 F25
G1 X94.455 Y230.739 Z-1.827 F25
G1 X94.481 Y230.845 Z-1.831 F25
G1 X94.499 Y230.952 Z-1.835 F25
G1 X94.509 Y231.06 Z-1.839 F25
G1 X94.512 Y231.169 Z-1.843 F25
G1 X94.508 Y231.278 Z-1.847 F25
G1 X94.496 Y231.386 Z-1.851 F25
G1 X94.476 Y231.493 Z-1.855 F25
G1 X94.449 Y231.598 Z-1.859 F25
G1 X94.415 Y231.701 Z-1.863 F25
G1 X94.374 Y231.802 Z-1.867 F25
G1 X94.326 Y231.899 Z-1.871 F25
G1 X94.271 Y231.993 Z-1.875 F25
G1 X94.21 Y232.083 Z-1.879 F25
G1 X94.143 Y232.168 Z-1.883 F25
G1 X94.07 Y232.249 Z-1.887 F25
G1 X93.991 Y232.324 Z-1.891 F25
G1 X93.908 Y232.393 Z-1.895 F25
G1 X93.82 Y232.457 Z-1.899 F25
G1 X93.728 Y232.514 Z-1.903 F25
G1 X93.631 Y232.565 Z-1.907 F25
G1 X93.532 Y232.609 Z-1.911 F25
G1 X93.43 Y232.646 Z-1.915 F25
G1 X93.325 Y232.676 Z-1.919 F25
G1 X93.219 Y232.698 Z-1.923 F25
G1 X93.112 Y232.713 Z-1.927 F25
G1 X93.003 Y232.721 Z-1.931 F25
G1 X92.894 Z-1.935 F25
G1 X92.786 Y232.713 Z-1.939 F25
G1 X92.678 Y232.698 Z-1.943 F25
G1 X92.572 Y232.675 Z-1.947 F25
G1 X92.468 Y232.645 Z-1.951 F25
G1 X92.366 Y232.608 Z-1.955 F25
G1 X92.266 Y232.564 Z-1.959 F25
G1 X92.17 Y232.513 Z-1.963 F25
G1 X92.078 Y232.456 Z-1.967 F25
G1 X91.99 Y232.392 Z-1.971 F25
G1 X91.907 Y232.323 Z-1.975 F25
G1 X91.829 Y232.248 Z-1.979 F25
G1 X91.756 Y232.167 Z-1.983 F25
G1 X91.689 Y232.082 Z-1.987 F25
G1 X91.628 Y231.992 Z-1.991 F25
G1 X91.573 Y231.898 Z-1.995 F25
G1 X91.525 Y231.801 Z-1.999 F25
G1 X91.484 Y231.7 Z-2.003 F25
G1 X91.45 Y231.597 Z-2.007 F25
G1 X91.424 Y231.492 Z-2.011 F25
G1 X91.404 Y231.385 Z-2.014 F25
G1 X91.392 Y231.277 Z-2.018 F25
G1 X91.388 Y231.169 Z-2.022 F25
G1 X91.391 Y231.061 Z-2.026 F25
G1 X91.402 Y230.953 Z-2.03 F25
G1 X91.42 Y230.846 Z-2.034 F25
G1 X91.446 Y230.74 Z-2.038 F25
G1 X91.479 Y230.637 Z-2.042 F25
G1 X91.519 Y230.536 Z-2.046 F25
G1 X91.565 Y230.438 Z-2.05 F25
G1 X91.619 Y230.344 Z-2.054 F25
G1 X91.679 Y230.253 Z-2.058 F25
G1 X91.745 Y230.167 Z-2.062 F25
G1 X91.817 Y230.086 Z-2.066 F25
G1 X91.895 Y230.01 Z-2.07 F25
G1 X91.977 Y229.939 Z-2.074 F25
G1 X92.064 Y229.875 Z-2.078 F25
G1 X92.156 Y229.817 Z-2.082 F25
G1 X92.251 Y229.765 Z-2.086 F25
G1 X92.349 Y229.72 Z-2.09 F25
G1 X92.451 Y229.682 Z-2.094 F25
G1 X92.555 Y229.651 Z-2.098 F25
G1 X92.661 Y229.627 Z-2.102 F25
G1 X92.768 Y229.611 Z-2.106 F25
G1 X92.876 Y229.602 Z-2.11 F25
G1 X92.984 Y229.601 Z-2.114 F25
G1 X93.092 Y229.607 Z-2.118 F25
G1 X93.2 Y229.621 Z-2.122 F25
G1 X93.306 Y229.642 Z-2.126 F25
G1 X93.411 Y229.671 Z-2.13 F25
G1 X93.513 Y229.706 Z-2.134 F25
G1 X93.612 Y229.749 Z-2.138 F25
G1 X93.709 Y229.799 Z-2.142 F25
G1 X93.802 Y229.855 Z-2.146 F25
G1 X93.89 Y229.918 Z-2.15 F25
G1 X93.974 Y229.986 Z-2.154 F25
G1 X94.053 Y230.06 Z-2.158 F25
G1 X94.127 Y230.14 Z-2.162 F25
G1 X94.195 Y230.224 Z-2.166 F25
G1 X94.257 Y230.313 Z-2.17 F25
G1 X94.312 Y230.406 Z-2.174 F25
G1 X94.361 Y230.503 Z-2.178 F25
G1 X94.404 Y230.603 Z-2.182 F25
G1 X94.439 Y230.705 Z-2.186 F25
G1 X94.467 Y230.81 Z-2.19 F25
G1 X94.487 Y230.916 Z-2.194 F25
G1 X94.5 Y231.024 Z-2.198 F25
G1 X94.506 Y231.132 Z-2.202 F25
G1 X94.504 Y231.24 Z-2.206 F25
G1 X94.495 Y231.348 Z-2.21 F25
G1 X94.478 Y231.455 Z-2.214 F25
G1 X94.454 Y231.56 Z-2.218 F25
G1 X94.422 Y231.664 Z-2.222 F25
G1 X94.383 Y231.765 Z-2.225 F25
G1 X94.338 Y231.863 Z-2.229 F25
G1 X94.285 Y231.958 Z-2.233 F25
G1 X94.227 Y232.049 Z-2.237 F25
G1 X94.162 Y232.135 Z-2.241 F25
G1 X94.091 Y232.217 Z-2.245 F25
G1 X94.015 Y232.294 Z-2.249 F25
G1 X93.933 Y232.365 Z-2.253 F25
G1 X93.847 Y232.431 Z-2.257 F25
G1 X93.756 Y232.49 Z-2.261 F25
G1 X93.662 Y232.543 Z-2.265 F25
G1 X93.564 Y232.589 Z-2.269 F25
G1 X93.463 Y232.628 Z-2.273 F25
G1 X93.36 Y232.66 Z-2.277 F25
G1 X93.255 Y232.685 Z-2.281 F25
G1 X93.148 Y232.703 Z-2.285 F25
G1 X93.04 Y232.713 Z-2.289 F25
G1 X92.932 Y232.715 Z-2.293 F25
G1 X92.824 Y232.71 Z-2.297 F25
G1 X92.716 Y232.698 Z-2.301 F25
G1 X92.61 Y232.678 Z-2.305 F25
G1 X92.505 Y232.65 Z-2.309 F25
G1 X92.402 Y232.616 Z-2.313 F25
G1 X92.303 Y232.575 Z-2.317 F25
G1 X92.206 Y232.526 Z-2.321 F25
G1 X92.113 Y232.471 Z-2.325 F25
G1 X92.024 Y232.41 Z-2.329 F25
G1 X91.939 Y232.343 Z-2.333 F25
G1 X91.86 Y232.27 Z-2.337 F25
G1 X91.785 Y232.191 Z-2.341 F25
G1 X91.716 Y232.108 Z-2.345 F25
G1 X91.653 Y232.02 Z-2.349 F25
G1 X91.597 Y231.928 Z-2.353 F25
G1 X91.547 Y231.832 Z-2.357 F25
G1 X91.504 Y231.733 Z-2.361 F25
G1 X91.467 Y231.631 Z-2.365 F25
G1 X91.438 Y231.527 Z-2.369 F25
G1 X91.416 Y231.421 Z-2.373 F25
G1 X91.402 Y231.314 Z-2.377 F25
G1 X91.395 Y231.206 Z-2.381 F25
G1 X91.396 Y231.098 Z-2.385 F25
G1 X91.404 Y230.99 Z-2.389 F25
G1 X91.419 Y230.883 Z-2.393 F25
G1 X91.442 Y230.778 Z-2.397 F25
G1 X91.473 Y230.674 Z-2.401 F25
G1 X91.51 Y230.572 Z-2.405 F25
G1 X91.554 Y230.474 Z-2.409 F25
G1 X91.605 Y230.379 Z-2.413 F25
G1 X91.663 Y230.287 Z-2.417 F25
G1 X91.727 Y230.2 Z-2.421 F25
G1 X91.796 Y230.117 Z-2.425 F25
G1 X91.872 Y230.04 Z-2.429 F25
G1 X91.952 Y229.968 Z-2.433 F25
G1 X92.037 Y229.901 Z-2.436 F25
G1 X92.127 Y229.841 Z-2.44 F25
G1 X92.22 Y229.787 Z-2.444 F25
G1 X92.318 Y229.74 Z-2.448 F25
G1 X92.418 Y229.7 Z-2.452 F25
G1 X92.52 Y229.667 Z-2.456 F25
G1 X92.625 Y229.64 Z-2.46 F25
G1 X92.731 Y229.622 Z-2.464 F25
G1 X92.839 Y229.61 Z-2.468 F25
G1 X92.947 Y229.607 Z-2.472 F25
G1 X93.055 Y229.61 Z-2.476 F25
G1 X93.162 Y229.622 Z-2.48 F25
G1 X93.268 Y229.64 Z-2.484 F25
G1 X93.373 Y229.666 Z-2.488 F25
G1 X93.476 Y229.699 Z-2.492 F25
G1 X93.576 Y229.74 Z-2.496 F25
G1 X93.673 Y229.787 Z-2.5 F25
G1 X93.767 Y229.84 Z-2.504 F25
G1 X93.856 Y229.901 Z-2.508 F25
G1 X93.942 Y229.967 Z-2.512 F25
G1 X94.022 Y230.039 Z-2.516 F25
G1 X94.098 Y230.116 Z-2.52 F25
G1 X94.167 Y230.199 Z-2.524 F25
G1 X94.231 Y230.286 Z-2.528 F25
G1 X94.289 Y230.377 Z-2.532 F25
G1 X94.34 Y230.472 Z-2.536 F25
G1 X94.384 Y230.57 Z-2.54 F25
G1 X94.422 Y230.672 Z-2.544 F25
G1 X94.452 Y230.775 Z-2.548 F25
G1 X94.475 Y230.88 Z-2.552 F25
G1 X94.49 Y230.987 Z-2.556 F25
G1 X94.499 Y231.095 Z-2.56 F25
G1 Y231.202 Z-2.564 F25
G1 X94.493 Y231.31 Z-2.568 F25
G1 X94.478 Y231.417 Z-2.572 F25
G1 X94.457 Y231.523 Z-2.576 F25
G1 X94.428 Y231.626 Z-2.58 F25
G1 X94.392 Y231.728 Z-2.584 F25
G1 X94.349 Y231.827 Z-2.588 F25
G1 X94.299 Y231.922 Z-2.592 F25
G1 X94.242 Y232.014 Z-2.596 F25
G1 X94.18 Y232.102 Z-2.6 F25
G1 X94.111 Y232.185 Z-2.604 F25
G1 X94.037 Y232.264 Z-2.608 F25
G1 X93.958 Y232.337 Z-2.612 F25
G1 X93.873 Y232.404 Z-2.616 F25
G1 X93.785 Y232.465 Z-2.62 F25
G1 X93.692 Y232.52 Z-2.624 F25
G1 X93.595 Y232.568 Z-2.628 F25
G1 X93.496 Y232.61 Z-2.632 F25
G1 X93.394 Y232.644 Z-2.636 F25
G1 X93.289 Y232.671 Z-2.64 F25
G1 X93.183 Y232.691 Z-2.644 F25
G1 X93.076 Y232.704 Z-2.647 F25
G1 X92.969 Y232.709 Z-2.651 F25
G1 X92.861 Y232.707 Z-2.655 F25
G1 X92.754 Y232.697 Z-2.659 F25
G1 X92.647 Y232.679 Z-2.663 F25
G1 X92.543 Y232.655 Z-2.667 F25
G1 X92.44 Y232.623 Z-2.671 F25
G1 X92.339 Y232.584 Z-2.675 F25
G1 X92.242 Y232.538 Z-2.679 F25
G1 X92.148 Y232.486 Z-2.683 F25
G1 X92.058 Y232.427 Z-2.687 F25
G1 X91.972 Y232.362 Z-2.691 F25
G1 X91.891 Y232.291 Z-2.695 F25
G1 X91.815 Y232.215 Z-2.699 F25
G1 X91.744 Y232.133 Z-2.703 F25
G1 X91.68 Y232.047 Z-2.707 F25
G1 X91.621 Y231.957 Z-2.711 F25
G1 X91.569 Y231.863 Z-2.715 F25
G1 X91.523 Y231.765 Z-2.719 F25
G1 X91.485 Y231.664 Z-2.723 F25
G1 X91.453 Y231.561 Z-2.727 F25
G1 X91.429 Y231.456 Z-2.731 F25
G1 X91.412 Y231.35 Z-2.735 F25
G1 X91.403 Y231.243 Z-2.739 F25
G1 X91.401 Y231.135 Z-2.743 F25
G1 X91.406 Y231.028 Z-2.747 F25
G1 X91.419 Y230.921 Z-2.751 F25
G1 X91.44 Y230.815 Z-2.755 F25
G1 X91.467 Y230.711 Z-2.759 F25
G1 X91.502 Y230.609 Z-2.763 F25
G1 X91.544 Y230.51 Z-2.767 F25
G1 X91.593 Y230.414 Z-2.771 F25
G1 X91.648 Y230.321 Z-2.775 F25
G1 X91.709 Y230.233 Z-2.779 F25
G1 X91.776 Y230.149 Z-2.783 F25
G1 X91.85 Y230.07 Z-2.787 F25
G1 X91.928 Y229.997 Z-2.791 F25
G1 X92.011 Y229.929 Z-2.795 F25
G1 X92.099 Y229.867 Z-2.799 F25
G1 X92.191 Y229.811 Z-2.803 F25
G1 X92.286 Y229.761 Z-2.807 F25
G1 X92.385 Y229.719 Z-2.811 F25
G1 X92.487 Y229.683 Z-2.815 F25
G1 X92.59 Y229.655 Z-2.819 F25
G1 X92.696 Y229.634 Z-2.823 F25
G1 X92.802 Y229.62 Z-2.827 F25
G1 X92.91 Y229.613 Z-2.831 F25
G1 X93.017 Y229.615 Z-2.835 F25
G1 X93.124 Y229.623 Z-2.839 F25
G1 X93.231 Y229.639 Z-2.843 F25
G1 X93.336 Y229.663 Z-2.847 F25
G1 X93.439 Y229.693 Z-2.851 F25
G1 X93.54 Y229.731 Z-2.855 F25
G1 X93.637 Y229.775 Z-2.858 F25
G1 X93.732 Y229.827 Z-2.862 F25
G1 X93.823 Y229.884 Z-2.866 F25
G1 X93.909 Y229.948 Z-2.87 F25
G1 X93.991 Y230.018 Z-2.874 F25
G1 X94.068 Y230.093 Z-2.878 F25
G1 X94.139 Y230.174 Z-2.882 F25
G1 X94.205 Y230.259 Z-2.886 F25
G1 X94.264 Y230.348 Z-2.89 F25
G1 X94.317 Y230.442 Z-2.894 F25
G1 X94.364 Y230.539 Z-2.898 F25
G1 X94.404 Y230.638 Z-2.902 F25
G1 X94.436 Y230.741 Z-2.906 F25
G1 X94.462 Y230.845 Z-2.91 F25
G1 X94.48 Y230.951 Z-2.914 F25
G1 X94.49 Y231.058 Z-2.918 F25
G1 X94.494 Y231.165 Z-2.922 F25
G1 X94.489 Y231.272 Z-2.926 F25
G1 X94.478 Y231.379 Z-2.93 F25
G1 X94.459 Y231.485 Z-2.934 F25
G1 X94.432 Y231.589 Z-2.938 F25
G1 X94.399 Y231.691 Z-2.942 F25
G1 X94.358 Y231.791 Z-2.946 F25
G1 X94.311 Y231.887 Z-2.95 F25
G1 X94.257 Y231.98 Z-2.954 F25
G1 X94.197 Y232.069 Z-2.958 F25
G1 X94.131 Y232.153 Z-2.962 F25
G1 X94.059 Y232.233 Z-2.966 F25
G1 X93.981 Y232.307 Z-2.97 F25
G1 X93.899 Y232.376 Z-2.974 F25
G1 X93.812 Y232.439 Z-2.978 F25
G1 X93.721 Y232.496 Z-2.982 F25
G1 X93.626 Y232.547 Z-2.986 F25
G1 X93.528 Y232.59 Z-2.99 F25
G1 X93.427 Y232.627 Z-2.994 F25
G1 X93.324 Y232.657 Z-2.998 F25
G1 X93.219 Y232.679 Z-3.002 F25
G1 X93.113 Y232.694 Z-3.006 F25
G1 X93.006 Y232.702 Z-3.01 F25
G1 X92.898 Z-3.014 F25
G1 X92.791 Y232.695 Z-3.018 F25
G1 X92.685 Y232.68 Z-3.022 F25
G1 X92.58 Y232.658 Z-3.026 F25
G1 X92.477 Y232.629 Z-3.03 F25
G1 X92.376 Y232.592 Z-3.034 F25
G1 X92.278 Y232.549 Z-3.038 F25
G1 X92.183 Y232.499 Z-3.042 F25
G1 X92.092 Y232.442 Z-3.046 F25
G1 X92.005 Y232.38 Z-3.05 F25
G1 X91.922 Y232.311 Z-3.054 F25
G1 X91.845 Y232.237 Z-3.058 F25
G1 X91.773 Y232.158 Z-3.062 F25
G1 X91.706 Y232.073 Z-3.066 F25
G1 X91.646 Y231.985 Z-3.069 F25
G1 X91.592 Y231.892 Z-3.073 F25
G1 X91.544 Y231.796 Z-3.077 F25
G1 X91.503 Y231.697 Z-3.081 F25
G1 X91.469 Y231.595 Z-3.085 F25
G1 X91.443 Y231.491 Z-3.089 F25
G1 X91.423 Y231.386 Z-3.093 F25
G1 X91.412 Y231.279 Z-3.097 F25
G1 X91.407 Y231.172 Z-3.101 F25
G1 X91.41 Y231.065 Z-3.105 F25
G1 X91.42 Y230.958 Z-3.109 F25
G1 X91.438 Y230.852 Z-3.113 F25
G1 X91.463 Y230.748 Z-3.117 F25
G1 X91.497 Y230.642 Z-3.121 F25
G1 X91.538 Y230.539 Z-3.126 F25
G1 X91.586 Y230.439 Z-3.13 F25
G1 X91.641 Y230.343 Z-3.134 F25
G1 X91.703 Y230.251 Z-3.138 F25
G1 X91.772 Y230.164 Z-3.142 F25
G1 X91.847 Y230.082 Z-3.146 F25
G1 X91.927 Y230.006 Z-3.15 F25
G1 X92.013 Y229.935 Z-3.154 F25
G1 X92.103 Y229.871 Z-3.159 F25
G1 X92.198 Y229.814 Z-3.163 F25
G1 X92.297 Y229.763 Z-3.167 F25
G1 X92.399 Y229.72 Z-3.171 F25
G1 X92.504 Y229.684 Z-3.175 F25
G1 X92.612 Y229.656 Z-3.179 F25
G1 X92.721 Y229.636 Z-3.183 F25
G1 X92.831 Y229.624 Z-3.187 F25
G1 X92.942 Y229.619 Z-3.191 F25
G1 X93.053 Y229.623 Z-3.196 F25
G1 X93.163 Y229.634 Z-3.2 F25
G1 X93.272 Y229.654 Z-3.204 F25
G1 X93.38 Y229.681 Z-3.208 F25
G1 X93.485 Y229.716 Z-3.212 F25
G1 X93.588 Y229.759 Z-3.216 F25
G1 X93.687 Y229.808 Z-3.22 F25
G1 X93.782 Y229.865 Z-3.224 F25
G1 X93.873 Y229.928 Z-3.229 F25
G1 X93.96 Y229.998 Z-3.233 F25
G1 X94.04 Y230.074 Z-3.237 F25
G1 X94.116 Y230.155 Z-3.241 F25
G1 X94.185 Y230.242 Z-3.245 F25
G1 X94.247 Y230.333 Z-3.249 F25
G1 X94.303 Y230.429 Z-3.253 F25
G1 X94.352 Y230.528 Z-3.257 F25
G1 X94.394 Y230.631 Z-3.262 F25
G1 X94.428 Y230.736 Z-3.266 F25
G1 X94.455 Y230.844 Z-3.27 F25
G1 X94.474 Y230.953 Z-3.274 F25
G1 X94.484 Y231.063 Z-3.278 F25
G1 X94.487 Y231.174 Z-3.282 F25
G1 X94.482 Y231.285 Z-3.286 F25
G1 X94.469 Y231.395 Z-3.29 F25
G1 X94.448 Y231.504 Z-3.295 F25
G1 X94.419 Y231.611 Z-3.299 F25
G1 X94.383 Y231.715 Z-3.303 F25
G1 X94.339 Y231.817 Z-3.307 F25
G1 X94.288 Y231.915 Z-3.311 F25
G1 X94.23 Y232.01 Z-3.315 F25
G1 X94.166 Y232.1 Z-3.319 F25
G1 X94.095 Y232.185 Z-3.323 F25
G1 X94.018 Y232.265 Z-3.328 F25
G1 X93.935 Y232.339 Z-3.332 F25
G1 X93.848 Y232.407 Z-3.336 F25
G1 X93.756 Y232.468 Z-3.34 F25
G1 X93.659 Y232.523 Z-3.344 F25
G1 X93.559 Y232.571 Z-3.348 F25
G1 X93.456 Y232.611 Z-3.352 F25
G1 X93.351 Y232.643 Z-3.356 F25
G1 X93.243 Y232.668 Z-3.361 F25
G1 X93.133 Y232.686 Z-3.365 F25
G1 X93.023 Y232.695 Z-3.369 F25
G1 X92.913 Y232.696 Z-3.373 F25
G1 X92.802 Y232.69 Z-3.377 F25
G1 X92.692 Y232.675 Z-3.381 F25
G1 X92.584 Y232.653 Z-3.385 F25
G1 X92.478 Y232.622 Z-3.389 F25
G1 X92.374 Y232.585 Z-3.394 F25
G1 X92.273 Y232.539 Z-3.398 F25
G1 X92.175 Y232.487 Z-3.402 F25
G1 X92.082 Y232.428 Z-3.406 F25
G1 X91.993 Y232.362 Z-3.41 F25
G1 X91.909 Y232.29 Z-3.414 F25
G1 X91.83 Y232.212 Z-3.418 F25
G1 X91.757 Y232.129 Z-3.422 F25
G1 X91.69 Y232.041 Z-3.427 F25
G1 X91.63 Y231.948 Z-3.431 F25
G1 X91.577 Y231.851 Z-3.435 F25
G1 X91.531 Y231.75 Z-3.439 F25
G1 X91.492 Y231.647 Z-3.443 F25
G1 X91.461 Y231.54 Z-3.447 F25
G1 X91.437 Y231.432 Z-3.451 F25
G1 X91.422 Y231.323 Z-3.455 F25
G1 X91.414 Y231.212 Z-3.46 F25
G1 Y231.102 Z-3.464 F25
G1 X91.422 Y230.991 Z-3.468 F25
G1 X91.439 Y230.882 Z-3.472 F25
G1 X91.462 Y230.774 Z-3.476 F25
G1 X91.494 Y230.668 Z-3.48 F25
G1 X91.533 Y230.565 Z-3.484 F25
G1 X91.58 Y230.465 Z-3.488 F25
G1 X91.633 Y230.368 Z-3.493 F25
G1 X91.694 Y230.276 Z-3.497 F25
G1 X91.761 Y230.188 Z-3.501 F25
G1 X91.834 Y230.105 Z-3.505 F25
G1 X91.913 Y230.027 Z-3.509 F25
G1 X91.997 Y229.956 Z-3.513 F25
G1 X92.086 Y229.89 Z-3.517 F25
G1 X92.179 Y229.832 Z-3.521 F25
G1 X92.277 Y229.78 Z-3.525 F25
G1 X92.378 Y229.735 Z-3.53 F25
G1 X92.482 Y229.698 Z-3.534 F25
G1 X92.589 Y229.668 Z-3.538 F25
G1 X92.697 Y229.646 Z-3.542 F25
G1 X92.807 Y229.632 Z-3.546 F25
G1 X92.917 Y229.626 Z-3.55 F25
G1 X93.027 Y229.628 Z-3.554 F25
G1 X93.137 Y229.637 Z-3.558 F25
G1 X93.247 Y229.655 Z-3.563 F25
G1 X93.354 Y229.68 Z-3.567 F25
G1 X93.46 Y229.713 Z-3.571 F25
G1 X93.562 Y229.754 Z-3.575 F25
G1 X93.662 Y229.802 Z-3.579 F25
G1 X93.758 Y229.857 Z-3.583 F25
G1 X93.849 Y229.918 Z-3.587 F25
G1 X93.936 Y229.986 Z-3.591 F25
G1 X94.018 Y230.061 Z-3.596 F25
G1 X94.094 Y230.14 Z-3.6 F25
G1 X94.164 Y230.225 Z-3.604 F25
G1 X94.228 Y230.315 Z-3.608 F25
G1 X94.286 Y230.41 Z-3.612 F25
G1 X94.336 Y230.508 Z-3.616 F25
G1 X94.379 Y230.609 Z-3.62 F25
G1 X94.415 Y230.714 Z-3.624 F25
G1 X94.443 Y230.82 Z-3.629 F25
G1 X94.464 Y230.929 Z-3.633 F25
G1 X94.476 Y231.039 Z-3.637 F25
G1 X94.481 Y231.149 Z-3.641 F25
G1 X94.478 Y231.259 Z-3.645 F25
G1 X94.467 Y231.369 Z-3.649 F25
G1 X94.447 Y231.478 Z-3.653 F25
G1 X94.421 Y231.585 Z-3.657 F25
G1 X94.386 Y231.689 Z-3.662 F25
G1 X94.344 Y231.792 Z-3.666 F25
G1 X94.295 Y231.89 Z-3.67 F25
G1 X94.239 Y231.985 Z-3.674 F25
G1 X94.176 Y232.076 Z-3.678 F25
G1 X94.107 Y232.162 Z-3.682 F25
G1 X94.031 Y232.243 Z-3.686 F25
G1 X93.951 Y232.318 Z-3.69 F25
G1 X93.864 Y232.387 Z-3.695 F25
G1 X93.774 Y232.45 Z-3.699 F25
G1 X93.679 Y232.506 Z-3.703 F25
G1 X93.58 Y232.555 Z-3.707 F25
G1 X93.478 Y232.596 Z-3.711 F25
G1 X93.373 Y232.631 Z-3.715 F25
G1 X93.266 Y232.657 Z-3.719 F25
G1 X93.158 Y232.676 Z-3.723 F25
G1 X93.048 Y232.687 Z-3.728 F25
G1 X92.938 Y232.69 Z-3.732 F25
G1 X92.828 Y232.686 Z-3.736 F25
G1 X92.718 Y232.673 Z-3.74 F25
G1 X92.61 Y232.652 Z-3.744 F25
G1 X92.504 Y232.624 Z-3.748 F25
G1 X92.399 Y232.588 Z-3.752 F25
G1 X92.298 Y232.545 Z-3.756 F25
G1 X92.2 Y232.494 Z-3.761 F25
G1 X92.106 Y232.437 Z-3.765 F25
G1 X92.016 Y232.373 Z-3.769 F25
G1 X91.931 Y232.302 Z-3.773 F25
G1 X91.852 Y232.226 Z-3.777 F25
G1 X91.778 Y232.144 Z-3.781 F25
G1 X91.71 Y232.057 Z-3.785 F25
G1 X91.649 Y231.966 Z-3.789 F25
G1 X91.594 Y231.87 Z-3.794 F25
G1 X91.547 Y231.771 Z-3.798 F25
G1 X91.506 Y231.668 Z-3.802 F25
G1 X91.473 Y231.563 Z-3.806 F25
G1 X91.448 Y231.456 Z-3.81 F25
G1 X91.431 Y231.347 Z-3.814 F25
G1 X91.421 Y231.237 Z-3.818 F25
G1 X91.42 Y231.127 Z-3.822 F25
G1 X91.426 Y231.017 Z-3.826 F25
G1 X91.44 Y230.908 Z-3.831 F25
G1 X91.462 Y230.8 Z-3.835 F25
G1 X91.492 Y230.694 Z-3.839 F25
G1 X91.529 Y230.591 Z-3.843 F25
G1 X91.574 Y230.49 Z-3.847 F25
G1 X91.626 Y230.393 Z-3.851 F25
G1 X91.684 Y230.3 Z-3.855 F25
G1 X91.75 Y230.211 Z-3.859 F25
G1 X91.821 Y230.128 Z-3.864 F25
G1 X91.898 Y230.049 Z-3.868 F25
G1 X91.981 Y229.976 Z-3.872 F25
G1 X92.069 Y229.91 Z-3.876 F25
G1 X92.161 Y229.85 Z-3.88 F25
G1 X92.257 Y229.797 Z-3.884 F25
G1 X92.357 Y229.751 Z-3.888 F25
G1 X92.46 Y229.712 Z-3.892 F25
G1 X92.566 Y229.68 Z-3.897 F25
G1 X92.673 Y229.657 Z-3.901 F25
G1 X92.782 Y229.641 Z-3.905 F25
G1 X92.892 Y229.633 Z-3.909 F25
G1 X93.002 Z-3.913 F25
G1 X93.112 Y229.641 Z-3.917 F25
G1 X93.221 Y229.656 Z-3.921 F25
G1 X93.328 Y229.68 Z-3.925 F25
G1 X93.434 Y229.711 Z-3.93 F25
G1 X93.537 Y229.75 Z-3.934 F25
G1 X93.636 Y229.796 Z-3.938 F25
G1 X93.733 Y229.849 Z-3.942 F25
G1 X93.825 Y229.909 Z-3.946 F25
G1 X93.913 Y229.975 Z-3.95 F25
G1 X93.995 Y230.048 Z-3.954 F25
G1 X94.072 Y230.126 Z-3.958 F25
G1 X94.144 Y230.209 Z-3.963 F25
G1 X94.209 Y230.298 Z-3.967 F25
G1 X94.268 Y230.391 Z-3.971 F25
G1 X94.32 Y230.488 Z-3.975 F25
G1 X94.364 Y230.588 Z-3.979 F25
G1 X94.402 Y230.692 Z-3.983 F25
G1 X94.431 Y230.797 Z-3.987 F25
G1 X94.454 Y230.905 Z-3.991 F25
G1 X94.468 Y231.014 Z-3.996 F25
G1 X94.474 Y231.124 Z-4 F25
G1 X94.473 Y231.234 Z-4.004 F25
G1 X94.463 Y231.343 Z-4.008 F25
G1 X94.446 Y231.452 Z-4.012 F25
G1 X94.421 Y231.559 Z-4.016 F25
G1 X94.389 Y231.664 Z-4.02 F25
G1 X94.349 Y231.766 Z-4.024 F25
G1 X94.301 Y231.865 Z-4.029 F25
G1 X94.247 Y231.961 Z-4.033 F25
G1 X94.186 Y232.052 Z-4.037 F25
G1 X94.118 Y232.139 Z-4.041 F25
G1 X94.045 Y232.221 Z-4.045 F25
G1 X93.965 Y232.297 Z-4.049 F25
G1 X93.881 Y232.367 Z-4.053 F25
G1 X93.792 Y232.431 Z-4.057 F25
G1 X93.698 Y232.488 Z-4.062 F25
G1 X93.6 Y232.538 Z-4.066 F25
G1 X93.5 Y232.581 Z-4.07 F25
G1 X93.396 Y232.617 Z-4.074 F25
G1 X93.29 Y232.646 Z-4.078 F25
G1 X93.182 Y232.666 Z-4.082 F25
G1 X93.073 Y232.679 Z-4.086 F25
G1 X92.963 Y232.684 Z-4.09 F25
G1 X92.853 Y232.681 Z-4.095 F25
G1 X92.744 Y232.67 Z-4.099 F25
G1 X92.636 Y232.651 Z-4.103 F25
G1 X92.529 Y232.625 Z-4.107 F25
G1 X92.425 Y232.591 Z-4.111 F25
G1 X92.323 Y232.549 Z-4.115 F25
G1 X92.225 Y232.501 Z-4.119 F25
G1 X92.13 Y232.445 Z-4.123 F25
G1 X92.04 Y232.383 Z-4.127 F25
G1 X91.954 Y232.314 Z-4.132 F25
G1 X91.874 Y232.24 Z-4.136 F25
G1 X91.799 Y232.159 Z-4.14 F25
G1 X91.73 Y232.074 Z-4.144 F25
G1 X91.667 Y231.984 Z-4.148 F25
G1 X91.611 Y231.889 Z-4.152 F25
G1 X91.562 Y231.791 Z-4.156 F25
G1 X91.521 Y231.69 Z-4.16 F25
G1 X91.486 Y231.586 Z-4.165 F25
G1 X91.459 Y231.479 Z-4.169 F25
G1 X91.44 Y231.371 Z-4.173 F25
G1 X91.429 Y231.262 Z-4.177 F25
G1 X91.426 Y231.153 Z-4.181 F25
G1 X91.43 Y231.043 Z-4.185 F25
G1 X91.443 Y230.934 Z-4.189 F25
G1 X91.463 Y230.826 Z-4.193 F25
G1 X91.491 Y230.72 Z-4.198 F25
G1 X91.526 Y230.617 Z-4.202 F25
G1 X91.569 Y230.516 Z-4.206 F25
G1 X91.619 Y230.418 Z-4.21 F25
G1 X91.676 Y230.324 Z-4.214 F25
G1 X91.739 Y230.235 Z-4.218 F25
G1 X91.809 Y230.15 Z-4.222 F25
G1 X91.885 Y230.071 Z-4.226 F25
G1 X91.966 Y229.997 Z-4.231 F25
G1 X92.052 Y229.93 Z-4.235 F25
G1 X92.143 Y229.868 Z-4.239 F25
G1 X92.238 Y229.814 Z-4.243 F25
G1 X92.337 Y229.766 Z-4.247 F25
G1 X92.439 Y229.726 Z-4.251 F25
G1 X92.543 Y229.693 Z-4.255 F25
G1 X92.65 Y229.668 Z-4.259 F25
G1 X92.758 Y229.65 Z-4.264 F25
G1 X92.867 Y229.64 Z-4.268 F25
G1 X92.977 Y229.638 Z-4.272 F25
G1 X93.086 Y229.644 Z-4.276 F25
G1 X93.195 Y229.658 Z-4.28 F25
G1 X93.302 Y229.68 Z-4.284 F25
G1 X93.408 Y229.709 Z-4.288 F25
G1 X93.511 Y229.746 Z-4.292 F25
G1 X93.611 Y229.79 Z-4.297 F25
G1 X93.708 Y229.842 Z-4.301 F25
G1 X93.801 Y229.9 Z-4.305 F25
G1 X93.889 Y229.964 Z-4.309 F25
G1 X93.973 Y230.035 Z-4.313 F25
G1 X94.051 Y230.112 Z-4.317 F25
G1 X94.123 Y230.194 Z-4.321 F25
G1 X94.19 Y230.281 Z-4.325 F25
G1 X94.25 Y230.372 Z-4.33 F25
G1 X94.303 Y230.468 Z-4.334 F25
G1 X94.349 Y230.567 Z-4.338 F25
G1 X94.388 Y230.67 Z-4.342 F25
G1 X94.419 Y230.775 Z-4.346 F25
G1 X94.443 Y230.882 Z-4.35 F25
G1 X94.459 Y230.99 Z-4.354 F25
G1 X94.467 Y231.099 Z-4.358 F25
G1 X94.468 Y231.209 Z-4.363 F25
G1 X94.46 Y231.318 Z-4.367 F25
G1 X94.445 Y231.426 Z-4.371 F25
G1 X94.422 Y231.533 Z-4.375 F25
G1 X94.391 Y231.638 Z-4.379 F25
G1 X94.352 Y231.741 Z-4.383 F25
G1 X94.307 Y231.84 Z-4.387 F25
G1 X94.254 Y231.936 Z-4.391 F25
G1 X94.195 Y232.028 Z-4.396 F25
G1 X94.129 Y232.116 Z-4.4 F25
G1 X94.057 Y232.198 Z-4.404 F25
G1 X93.98 Y232.275 Z-4.408 F25
G1 X93.897 Y232.346 Z-4.412 F25
G1 X93.809 Y232.411 Z-4.416 F25
G1 X93.717 Y232.47 Z-4.42 F25
G1 X93.62 Y232.522 Z-4.424 F25
G1 X93.521 Y232.566 Z-4.429 F25
G1 X93.418 Y232.604 Z-4.433 F25
G1 X93.313 Y232.634 Z-4.437 F25
G1 X93.206 Y232.656 Z-4.441 F25
G1 X93.097 Y232.671 Z-4.445 F25
G1 X92.988 Y232.677 Z-4.449 F25
G1 X92.879 Y232.676 Z-4.453 F25
G1 X92.77 Y232.667 Z-4.457 F25
G1 X92.662 Y232.65 Z-4.461 F25
G1 X92.555 Y232.626 Z-4.466 F25
G1 X92.451 Y232.593 Z-4.47 F25
G1 X92.349 Y232.554 Z-4.474 F25
G1 X92.25 Y232.507 Z-4.478 F25
G1 X92.155 Y232.453 Z-4.482 F25
G1 X92.064 Y232.392 Z-4.486 F25
G1 X91.977 Y232.325 Z-4.49 F25
G1 X91.896 Y232.252 Z-4.494 F25
G1 X91.82 Y232.174 Z-4.499 F25
G1 X91.75 Y232.09 Z-4.503 F25
G1 X91.686 Y232.001 Z-4.507 F25
G1 X91.629 Y231.908 Z-4.511 F25
G1 X91.579 Y231.811 Z-4.515 F25
G1 X91.535 Y231.711 Z-4.519 F25
G1 X91.499 Y231.608 Z-4.523 F25
G1 X91.471 Y231.502 Z-4.527 F25
G1 X91.45 Y231.395 Z-4.532 F25
G1 X91.437 Y231.287 Z-4.536 F25
G1 X91.432 Y231.178 Z-4.54 F25
G1 X91.435 Y231.069 Z-4.544 F25
G1 X91.445 Y230.96 Z-4.548 F25
G1 X91.464 Y230.852 Z-4.552 F25
G1 X91.49 Y230.746 Z-4.556 F25
G1 X91.523 Y230.642 Z-4.56 F25
G1 X91.564 Y230.541 Z-4.565 F25
G1 X91.612 Y230.443 Z-4.569 F25
G1 X91.668 Y230.349 Z-4.573 F25
G1 X91.729 Y230.259 Z-4.577 F25
G1 X91.797 Y230.173 Z-4.581 F25
G1 X91.871 Y230.093 Z-4.585 F25
G1 X91.951 Y230.018 Z-4.589 F25
G1 X92.036 Y229.95 Z-4.593 F25
G1 X92.125 Y229.887 Z-4.598 F25
G1 X92.219 Y229.831 Z-4.602 F25
G1 X92.317 Y229.782 Z-4.606 F25
G1 X92.418 Y229.74 Z-4.61 F25
G1 X92.521 Y229.706 Z-4.614 F25
G1 X92.627 Y229.679 Z-4.618 F25
G1 X92.734 Y229.659 Z-4.622 F25
G1 X92.843 Y229.648 Z-4.626 F25
G1 X92.952 Y229.644 Z-4.631 F25
G1 X93.061 Y229.649 Z-4.635 F25
G1 X93.169 Y229.661 Z-4.639 F25
G1 X93.276 Y229.68 Z-4.643 F25
G1 X93.382 Y229.708 Z-4.647 F25
G1 X93.485 Y229.743 Z-4.651 F25
G1 X93.586 Y229.785 Z-4.655 F25
G1 X93.683 Y229.835 Z-4.659 F25
G1 X93.776 Y229.891 Z-4.664 F25
G1 X93.865 Y229.954 Z-4.668 F25
G1 X93.95 Y230.023 Z-4.672 F25
G1 X94.029 Y230.098 Z-4.676 F25
G1 X94.102 Y230.179 Z-4.68 F25
G1 X94.17 Y230.264 Z-4.684 F25
G1 X94.231 Y230.355 Z-4.688 F25
G1 X94.286 Y230.449 Z-4.692 F25
G1 X94.333 Y230.547 Z-4.697 F25
G1 X94.374 Y230.648 Z-4.701 F25
G1 X94.407 Y230.752 Z-4.705 F25
G1 X94.432 Y230.858 Z-4.709 F25
G1 X94.45 Y230.966 Z-4.713 F25
G1 X94.46 Y231.075 Z-4.717 F25
G1 X94.462 Y231.184 Z-4.721 F25
G1 X94.456 Y231.292 Z-4.725 F25
G1 X94.443 Y231.401 Z-4.73 F25
G1 X94.421 Y231.508 Z-4.734 F25
G1 X94.393 Y231.613 Z-4.738 F25
G1 X94.356 Y231.715 Z-4.742 F25
G1 X94.312 Y231.815 Z-4.746 F25
G1 X94.262 Y231.911 Z-4.75 F25
G1 X94.204 Y232.004 Z-4.754 F25
G1 X94.14 Y232.092 Z-4.758 F25
G1 X94.07 Y232.175 Z-4.763 F25
G1 X93.994 Y232.253 Z-4.767 F25
G1 X93.912 Y232.326 Z-4.771 F25
G1 X93.826 Y232.392 Z-4.775 F25
G1 X93.735 Y232.452 Z-4.779 F25
G1 X93.64 Y232.505 Z-4.783 F25
G1 X93.541 Y232.551 Z-4.787 F25
G1 X93.44 Y232.59 Z-4.791 F25
G1 X93.335 Y232.621 Z-4.795 F25
G1 X93.229 Y232.645 Z-4.8 F25
G1 X93.121 Y232.662 Z-4.804 F25
G1 X93.013 Y232.67 Z-4.808 F25
G1 X92.904 Y232.671 Z-4.812 F25
G1 X92.795 Y232.663 Z-4.816 F25
G1 X92.687 Y232.648 Z-4.82 F25
G1 X92.581 Y232.626 Z-4.824 F25
G1 X92.476 Y232.595 Z-4.828 F25
G1 X92.374 Y232.558 Z-4.833 F25
G1 X92.275 Y232.513 Z-4.837 F25
G1 X92.179 Y232.46 Z-4.841 F25
G1 X92.088 Y232.402 Z-4.845 F25
G1 X92 Y232.336 Z-4.849 F25
G1 X91.918 Y232.265 Z-4.853 F25
G1 X91.842 Y232.188 Z-4.857 F25
G1 X91.77 Y232.106 Z-4.861 F25
G1 X91.705 Y232.018 Z-4.866 F25
G1 X91.647 Y231.927 Z-4.87 F25
G1 X91.595 Y231.831 Z-4.874 F25
G1 X91.55 Y231.732 Z-4.878 F25
G1 X91.513 Y231.63 Z-4.882 F25
G1 X91.483 Y231.525 Z-4.886 F25
G1 X91.46 Y231.419 Z-4.89 F25
G1 X91.446 Y231.311 Z-4.894 F25
G1 X91.439 Y231.203 Z-4.899 F25
G1 X91.44 Y231.094 Z-4.903 F25
G1 X91.448 Y230.985 Z-4.907 F25
G1 X91.465 Y230.878 Z-4.911 F25
G1 X91.489 Y230.772 Z-4.915 F25
G1 X91.521 Y230.668 Z-4.919 F25
G1 X91.56 Y230.566 Z-4.923 F25
G1 X91.606 Y230.468 Z-4.927 F25
G1 X91.66 Y230.373 Z-4.932 F25
G1 X91.72 Y230.283 Z-4.936 F25
G1 X91.786 Y230.196 Z-4.94 F25
G1 X91.859 Y230.115 Z-4.944 F25
G1 X91.937 Y230.039 Z-4.948 F25
G1 X92.02 Y229.97 Z-4.952 F25
G1 X92.108 Y229.906 Z-4.956 F25
G1 X92.201 Y229.849 Z-4.96 F25
G1 X92.297 Y229.798 Z-4.965 F25
G1 X92.397 Y229.755 Z-4.969 F25
G1 X92.499 Y229.719 Z-4.973 F25
G1 X92.604 Y229.69 Z-4.977 F25
G1 X92.71 Y229.669 Z-4.981 F25
G1 X92.818 Y229.656 Z-4.985 F25
G1 X92.927 Y229.651 Z-4.989 F25
G1 X93.035 Y229.653 Z-4.993 F25
G1 X93.143 Y229.663 Z-4.998 F25
G1 X93.251 Y229.681 Z-5.002 F25
G1 X93.356 Y229.707 Z-5.006 F25
G1 X93.46 Y229.74 Z-5.01 F25
G1 X93.56 Y229.781 Z-5.014 F25
G1 X93.658 Y229.828 Z-5.018 F25
G1 X93.752 Y229.883 Z-5.022 F25
G1 X93.842 Y229.944 Z-5.026 F25
G1 X93.927 Y230.011 Z-5.031 F25
G1 X94.007 Y230.085 Z-5.035 F25
G1 X94.081 Y230.164 Z-5.039 F25
G1 X94.15 Y230.248 Z-5.043 F25
G1 X94.212 Y230.337 Z-5.047 F25
G1 X94.268 Y230.43 Z-5.051 F25
G1 X94.317 Y230.527 Z-5.055 F25
G1 X94.359 Y230.627 Z-5.059 F25
G1 X94.394 Y230.73 Z-5.064 F25
G1 X94.421 Y230.835 Z-5.068 F25
G1 X94.44 Y230.942 Z-5.072 F25
G1 X94.452 Y231.05 Z-5.076 F25
G1 X94.456 Y231.159 Z-5.08 F25
G3 X91.439 I-1.508 F25
G3 X94.456 I1.508 F25
; MOVEMENT_CUTTING
G1 X94.474 Y231.856 F254
G1 X94.499 Y231.94 F254
G1 X94.523 Y232.091 F254
G1 X94.517 Y232.243 F254
G1 X94.486 Y232.392 F254
G1 X94.434 Y232.535 F254
G1 X94.365 Y232.671 F254
G1 X94.281 Y232.798 F254
G1 X94.184 Y232.916 F254
G1 X94.075 Y233.023 F254
G1 X93.957 Y233.119 F254
G1 X93.831 Y233.204 F254
G1 X93.698 Y233.279 F254
G1 X93.559 Y233.341 F254
G1 X93.413 Y233.393 F254
G1 X93.259 Y233.435 F254
G1 X93.099 Y233.464 F254
G1 X92.934 Y233.481 F254
G1 X92.765 Y233.485 F254
G1 X92.594 Y233.475 F254
G1 X92.422 Y233.45 F254
G1 X92.25 Y233.412 F254
G1 X92.08 Y233.359 F254
G1 X91.913 Y233.293 F254
G1 X91.75 Y233.212 F254
G1 X91.593 Y233.118 F254
G1 X91.443 Y233.01 F254
G1 X91.301 Y232.89 F254
G1 X91.169 Y232.759 F254
G1 X91.047 Y232.617 F254
G1 X90.936 Y232.464 F254
G1 X90.838 Y232.303 F254
G1 X90.752 Y232.134 F254
G1 X90.681 Y231.958 F254
G1 X90.623 Y231.776 F254
G1 X90.58 Y231.59 F254
G1 X90.552 Y231.4 F254
G1 X90.54 Y231.209 F254
G1 X90.543 Y231.017 F254
G1 X90.561 Y230.826 F254
G1 X90.594 Y230.636 F254
G1 X90.643 Y230.45 F254
G1 X90.707 Y230.268 F254
G1 X90.785 Y230.091 F254
G1 X90.877 Y229.921 F254
G1 X90.982 Y229.759 F254
G1 X91.1 Y229.606 F254
G1 X91.23 Y229.463 F254
G1 X91.371 Y229.331 F254
G1 X91.523 Y229.21 F254
G1 X91.684 Y229.102 F254
G1 X91.852 Y229.007 F254
G1 X92.028 Y228.926 F254
G1 X92.21 Y228.86 F254
G1 X92.397 Y228.808 F254
G1 X92.587 Y228.771 F254
G1 X92.78 Y228.75 F254
G1 X92.974 Y228.744 F254
G1 X93.167 Y228.754 F254
G1 X93.359 Y228.779 F254
G1 X93.549 Y228.82 F254
G1 X93.735 Y228.876 F254
G1 X93.915 Y228.946 F254
G1 X94.09 Y229.031 F254
G1 X94.257 Y229.13 F254
G1 X94.416 Y229.241 F254
G1 X94.565 Y229.365 F254
G1 X94.703 Y229.501 F254
G1 X94.831 Y229.647 F254
G1 X94.946 Y229.803 F254
G1 X95.051 Y229.971 F254
G1 X95.161 Y230.185 F254
G1 X95.32 Y230.567 F254
G1 X95.43 Y230.905 F254
G1 X95.497 Y231.181 F254
G1 X95.536 Y231.435 F254
G1 X95.554 Y231.673 F254
G1 X95.552 Y231.898 F254
G1 X95.534 Y232.113 F254
G1 X95.499 Y232.319 F254
G1 X95.448 Y232.521 F254
G1 X95.381 Y232.719 F254
G1 X95.298 Y232.91 F254
G1 X95.2 Y233.095 F254
G1 X95.087 Y233.271 F254
G1 X94.959 Y233.439 F254
G1 X94.817 Y233.598 F254
G1 X94.661 Y233.747 F254
G1 X94.491 Y233.885 F254
G1 X94.309 Y234.01 F254
G1 X94.113 Y234.122 F254
G1 X93.907 Y234.219 F254
G1 X93.69 Y234.3 F254
G1 X93.464 Y234.365 F254
G1 X93.23 Y234.412 F254
G1 X92.991 Y234.44 F254
G1 X92.747 Y234.45 F254
G1 X92.5 Y234.439 F254
G1 X92.253 Y234.409 F254
G1 X92.007 Y234.358 F254
G1 X91.763 Y234.287 F254
G1 X91.524 Y234.196 F254
G1 X91.292 Y234.085 F254
G1 X91.067 Y233.956 F254
G1 X90.853 Y233.807 F254
G1 X90.65 Y233.641 F254
G1 X90.46 Y233.459 F254
G1 X90.284 Y233.261 F254
G1 X90.124 Y233.048 F254
G1 X89.981 Y232.822 F254
G1 X89.857 Y232.585 F254
G1 X89.751 Y232.338 F254
G1 X89.665 Y232.082 F254
G1 X89.6 Y231.82 F254
G1 X89.557 Y231.553 F254
G1 X89.534 Y231.282 F254
G1 Y231.01 F254
G1 X89.555 Y230.739 F254
G1 X89.598 Y230.47 F254
G1 X89.663 Y230.204 F254
G1 X89.749 Y229.945 F254
G1 X89.855 Y229.693 F254
G1 X89.982 Y229.45 F254
G1 X90.127 Y229.218 F254
G1 X90.291 Y228.998 F254
G1 X90.472 Y228.792 F254
G1 X90.669 Y228.602 F254
G1 X90.881 Y228.427 F254
G1 X91.107 Y228.27 F254
G1 X91.344 Y228.132 F254
G1 X91.592 Y228.013 F254
G1 X91.848 Y227.914 F254
G1 X92.112 Y227.836 F254
G1 X92.381 Y227.779 F254
G1 X92.654 Y227.745 F254
G1 X92.928 Y227.732 F254
G1 X93.203 Y227.741 F254
G1 X93.477 Y227.773 F254
G1 X93.747 Y227.826 F254
G1 X94.011 Y227.901 F254
G1 X94.269 Y227.997 F254
G1 X94.519 Y228.113 F254
G1 X94.758 Y228.249 F254
G1 X94.986 Y228.403 F254
G1 X95.201 Y228.576 F254
G1 X95.408 Y228.772 F254
G1 X95.627 Y229.015 F254
G1 X95.832 Y229.283 F254
G1 X96.023 Y229.579 F254
G1 X96.191 Y229.893 F254
G1 X96.332 Y230.216 F254
G1 X96.444 Y230.541 F254
G1 X96.527 Y230.864 F254
G1 X96.582 Y231.184 F254
G1 X96.611 Y231.5 F254
G1 X96.614 Y231.812 F254
G1 X96.592 Y232.12 F254
G1 X96.546 Y232.422 F254
G1 X96.477 Y232.717 F254
G1 X96.385 Y233.004 F254
G1 X96.27 Y233.281 F254
G1 X96.134 Y233.548 F254
G1 X95.976 Y233.804 F254
G1 X95.798 Y234.047 F254
G1 X95.601 Y234.276 F254
G1 X95.384 Y234.489 F254
G1 X95.149 Y234.686 F254
G1 X95.085 Y234.731 F254
G1 X94.909 Y234.823 F254
G1 X94.714 Y234.865 F254
G1 X94.515 Y234.854 F254
G1 X94.114 Y234.776 F254
G1 X93.892 Y234.757 F254
G1 X93.734 Y234.762 F254
G1 X93.596 Y234.776 F254
G1 X93.417 Y234.808 F254
G1 X93.258 Y234.853 F254
G1 X93.1 Y234.903 F254
G1 X92.783 Y235.011 F254
G1 X92.756 Y235.022 F254
G1 X92.614 Y235.076 F254
G1 X92.459 Y235.115 F254
G1 X92.291 Y235.143 F254
G1 X92.101 Y235.16 F254
G1 X91.905 Y235.161 F254
G1 X91.691 Y235.145 F254
G1 X91.46 Y235.11 F254
G1 X91.227 Y235.054 F254
G1 X90.987 Y234.976 F254
G1 X90.738 Y234.872 F254
G1 X90.487 Y234.742 F254
G1 X90.236 Y234.587 F254
G1 X89.994 Y234.408 F254
G1 X89.761 Y234.205 F254
G1 X89.54 Y233.979 F254
G1 X89.333 Y233.73 F254
G1 X89.143 Y233.46 F254
G1 X88.972 Y233.171 F254
G1 X88.823 Y232.864 F254
G1 X88.698 Y232.544 F254
G1 X88.598 Y232.211 F254
G1 X88.594 Y232.193 F254
G1 X88.578 Y232.052 F254
G1 X88.589 Y231.91 F254
G1 X88.627 Y231.773 F254
; MOVEMENT_LEAD_OUT
G1 X88.65 Y231.729 Z-5.06 F254
G1 X88.679 Y231.689 Z-5.039 F254
G1 X88.715 Y231.654 Z-5.019 F254
G1 X88.755 Y231.625 Z-4.999 F254
G1 X88.8 Y231.602 Z-4.978 F254
G1 X88.847 Y231.587 Z-4.958 F254
G1 X88.896 Y231.58 Z-4.938 F254
G1 X88.946 Z-4.917 F254
G1 X88.995 Y231.588 Z-4.897 F254
G1 X89.043 Y231.604 Z-4.877 F254
G3 X89.112 Y231.645 I-0.123 J0.293 F254
G1 X89.244 Y231.746 F254
; MOVEMENT_LINK_DIRECT
G1 X92.736 Y234.425 F254
; MOVEMENT_LEAD_IN
G1 X92.813 Y234.484 F254
G3 X92.906 Y234.599 I-0.193 J0.252 F254
G1 X92.924 Y234.646 Z-4.897 F254
G1 X92.934 Y234.694 Z-4.917 F254
G1 X92.937 Y234.744 Z-4.938 F254
G1 X92.932 Y234.794 Z-4.958 F254
G1 X92.919 Y234.842 Z-4.978 F254
G1 X92.898 Y234.887 Z-4.999 F254
G1 X92.871 Y234.929 Z-5.019 F254
G1 X92.838 Y234.966 Z-5.039 F254
G1 X92.799 Y234.997 Z-5.06 F254
G1 X92.756 Y235.022 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X92.624 Y235.08 F254
G1 X92.465 Y235.167 F254
G1 X92.307 Y235.282 F254
G1 X92.148 Y235.413 F254
G1 X92.03 Y235.508 F254
G1 X91.9 Y235.589 F254
G1 X91.762 Y235.653 F254
G1 X91.617 Y235.701 F254
G1 X91.469 Y235.735 F254
G1 X91.312 Y235.756 F254
G1 X91.142 Y235.766 F254
G1 X90.95 Y235.762 F254
G1 X90.753 Y235.741 F254
G1 X90.531 Y235.7 F254
G1 X90.301 Y235.638 F254
G1 X90.063 Y235.553 F254
G1 X89.809 Y235.438 F254
G1 X89.548 Y235.294 F254
G1 X89.293 Y235.125 F254
G1 X89.036 Y234.923 F254
G1 X88.781 Y234.687 F254
G1 X88.533 Y234.419 F254
G1 X88.299 Y234.12 F254
G1 X88.27 Y234.075 F254
G1 X88.189 Y233.912 F254
G1 X88.15 Y233.734 F254
G1 X88.156 Y233.552 F254
; MOVEMENT_LEAD_OUT
G1 X88.169 Y233.504 Z-5.06 F254
G1 X88.19 Y233.458 Z-5.039 F254
G1 X88.217 Y233.417 Z-5.019 F254
G1 X88.251 Y233.38 Z-4.999 F254
G1 X88.29 Y233.349 Z-4.978 F254
G1 X88.333 Y233.324 Z-4.958 F254
G1 X88.38 Y233.307 Z-4.938 F254
G1 X88.429 Y233.297 Z-4.917 F254
G1 X88.478 Y233.295 Z-4.897 F254
G1 X88.528 Y233.3 Z-4.877 F254
G3 X88.599 Y233.323 I-0.06 J0.312 F254
G1 X88.756 Y233.394 F254
; MOVEMENT_LINK_DIRECT
G1 X91.947 Y234.842 F254
; MOVEMENT_LEAD_IN
G1 X92.061 Y234.894 F254
G3 X92.159 Y234.964 I-0.131 J0.289 F254
G1 X92.191 Y235.003 Z-4.897 F254
G1 X92.216 Y235.046 Z-4.917 F254
G1 X92.234 Y235.092 Z-4.938 F254
G1 X92.244 Y235.141 Z-4.958 F254
G1 X92.247 Y235.191 Z-4.978 F254
G1 X92.242 Y235.24 Z-4.999 F254
G1 X92.229 Y235.288 Z-5.019 F254
G1 X92.209 Y235.334 Z-5.039 F254
G1 X92.182 Y235.376 Z-5.06 F254
G1 X92.148 Y235.413 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X91.973 Y235.569 F254
G1 X91.801 Y235.728 F254
G1 X91.673 Y235.849 F254
G1 X91.514 Y236.004 F254
G1 X91.471 Y236.045 F254
G1 X91.353 Y236.141 F254
G1 X91.225 Y236.224 F254
G1 X91.088 Y236.291 F254
G1 X90.945 Y236.343 F254
G1 X90.797 Y236.382 F254
G1 X90.635 Y236.41 F254
G1 X90.467 Y236.425 F254
G1 X90.27 Y236.427 F254
G1 X90.068 Y236.412 F254
G1 X89.845 Y236.378 F254
G1 X89.602 Y236.321 F254
G1 X89.358 Y236.242 F254
G1 X89.091 Y236.132 F254
G1 X88.81 Y235.989 F254
G1 X88.782 Y235.971 F254
G1 X88.697 Y235.91 F254
G1 X88.621 Y235.838 F254
G1 X88.557 Y235.755 F254
; MOVEMENT_LEAD_OUT
G1 X88.534 Y235.711 Z-5.06 F254
G1 X88.518 Y235.664 Z-5.039 F254
G1 X88.51 Y235.615 Z-5.019 F254
G1 X88.509 Y235.565 Z-4.999 F254
G1 X88.516 Y235.516 Z-4.978 F254
G1 X88.531 Y235.468 Z-4.958 F254
G1 X88.553 Y235.424 Z-4.938 F254
G1 X88.582 Y235.383 Z-4.917 F254
G1 X88.617 Y235.347 Z-4.897 F254
G1 X88.657 Y235.318 Z-4.877 F254
G3 X88.857 Y235.271 I0.169 J0.269 F254
G1 X88.895 Y235.274 F254
; MOVEMENT_LINK_DIRECT
G1 X91.244 Y235.504 F254
; MOVEMENT_LEAD_IN
G1 X91.275 Y235.507 F254
G3 X91.467 Y235.596 I-0.031 J0.316 F254
G1 X91.499 Y235.634 Z-4.897 F254
G1 X91.526 Y235.676 Z-4.917 F254
G1 X91.545 Y235.722 Z-4.938 F254
G1 X91.557 Y235.77 Z-4.958 F254
G1 X91.562 Y235.82 Z-4.978 F254
G1 X91.558 Y235.869 Z-4.999 F254
G1 X91.547 Y235.918 Z-5.019 F254
G1 X91.529 Y235.964 Z-5.039 F254
G1 X91.503 Y236.007 Z-5.06 F254
G1 X91.471 Y236.045 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X91.197 Y236.289 F254
G1 X90.868 Y236.521 F254
G1 X90.831 Y236.543 F254
G1 X90.795 Y236.562 F254
G1 X90.405 Y236.719 F254
G1 X90.246 Y236.78 F254
G1 X90.167 Y236.794 F254
G1 X90.087 Y236.804 F254
G1 X90.048 Y236.806 F254
G1 X90.008 Y236.804 F254
G1 X89.85 Y236.788 F254
G1 X89.81 Y236.783 F254
G1 X89.77 Y236.772 F254
G1 X89.518 Y236.679 F254
G1 X89.486 Y236.664 F254
G1 X89.453 Y236.645 F254
G1 X89.266 Y236.521 F254
G1 X89.136 Y236.434 F254
G1 X89.061 Y236.362 F254
G1 X88.819 Y236.119 F254
G1 X88.752 Y236.045 F254
G1 X88.502 Y235.674 F254
G1 X88.469 Y235.622 F254
G1 X88.444 Y235.569 F254
G1 X88.271 Y235.173 F254
G1 X88.257 Y235.133 F254
G1 X88.246 Y235.093 F254
G1 X88.185 Y234.831 F254
G1 X88.175 Y234.776 F254
G1 X88.12 Y234.3 F254
G1 X88.116 Y234.142 F254
G1 X88.138 Y233.666 F254
G1 X88.163 Y233.507 F254
G1 X88.216 Y233.19 F254
G1 X88.247 Y233.031 F254
G1 X88.367 Y232.556 F254
G1 X88.515 Y232.08 F254
G1 X88.57 Y231.921 F254
G1 X88.752 Y231.445 F254
G1 X88.978 Y230.909 F254
G1 X89.164 Y230.494 F254
G1 X89.238 Y230.335 F254
G1 X89.48 Y229.859 F254
G1 X90.314 Y228.273 F254
G1 X90.496 Y227.956 F254
G1 X90.579 Y227.828 F254
G1 X90.684 Y227.698 F254
G1 X90.816 Y227.56 F254
G1 X90.964 Y227.428 F254
G1 X91.136 Y227.297 F254
G1 X91.336 Y227.17 F254
G1 X91.553 Y227.055 F254
G1 X91.789 Y226.952 F254
G1 X92.05 Y226.864 F254
G1 X92.332 Y226.793 F254
G1 X92.631 Y226.742 F254
G1 X92.94 Y226.715 F254
G1 X93.258 Y226.714 F254
G1 X93.388 Y226.723 F254
G1 X93.537 Y226.75 F254
G1 X93.679 Y226.807 F254
G1 X93.805 Y226.891 F254
; MOVEMENT_LEAD_OUT
G1 X93.84 Y226.927 Z-5.06 F254
G1 X93.868 Y226.968 Z-5.039 F254
G1 X93.89 Y227.013 Z-5.019 F254
G1 X93.904 Y227.061 Z-4.999 F254
G1 X93.911 Y227.11 Z-4.978 F254
G1 X93.91 Y227.16 Z-4.958 F254
G1 X93.901 Y227.209 Z-4.938 F254
G1 X93.885 Y227.256 Z-4.917 F254
G1 X93.862 Y227.3 Z-4.897 F254
G1 X93.832 Y227.339 Z-4.877 F254
G3 X93.698 Y227.429 I-0.238 J-0.211 F254
G1 X93.618 Y227.456 F254
; MOVEMENT_LINK_DIRECT
G1 X90.881 Y228.405 F254
G3 X90.627 Y228.385 I-0.104 J-0.3 F254
; MOVEMENT_LEAD_IN
G1 X90.585 Y228.359 Z-4.897 F254
G1 X90.548 Y228.326 Z-4.917 F254
G1 X90.516 Y228.287 Z-4.938 F254
G1 X90.491 Y228.244 Z-4.958 F254
G1 X90.473 Y228.198 Z-4.978 F254
G1 X90.462 Y228.149 Z-4.999 F254
G1 X90.459 Y228.1 Z-5.019 F254
G1 X90.464 Y228.05 Z-5.039 F254
G1 X90.476 Y228.002 Z-5.06 F254
G1 X90.496 Y227.956 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X90.588 Y227.798 F254
G1 X90.722 Y227.571 F254
G1 X90.88 Y227.307 F254
G1 X90.968 Y227.163 F254
G1 X91.278 Y226.687 F254
G1 X91.37 Y226.566 F254
G1 X91.474 Y226.454 F254
G1 X91.586 Y226.351 F254
G1 X91.724 Y226.245 F254
G1 X91.874 Y226.147 F254
G1 X92.057 Y226.048 F254
G1 X92.073 Y226.041 F254
G1 X92.262 Y225.986 F254
G1 X92.459 Y225.983 F254
G1 X92.65 Y226.032 F254
G1 X92.821 Y226.129 F254
; MOVEMENT_LEAD_OUT
G1 X92.857 Y226.163 Z-5.06 F254
G1 X92.887 Y226.203 Z-5.039 F254
G1 X92.911 Y226.247 Z-5.019 F254
G1 X92.927 Y226.294 Z-4.999 F254
G1 X92.936 Y226.343 Z-4.978 F254
G1 X92.937 Y226.393 Z-4.958 F254
G1 X92.93 Y226.442 Z-4.938 F254
G1 X92.916 Y226.49 Z-4.917 F254
G1 X92.894 Y226.535 Z-4.897 F254
G1 X92.866 Y226.575 Z-4.877 F254
G3 X92.749 Y226.665 I-0.246 J-0.201 F254
G1 X92.659 Y226.705 F254
; MOVEMENT_LINK_DIRECT
G1 X91.679 Y227.142 F254
G3 X91.385 Y227.123 I-0.129 J-0.29 F254
; MOVEMENT_LEAD_IN
G1 X91.344 Y227.094 Z-4.897 F254
G1 X91.309 Y227.059 Z-4.917 F254
G1 X91.28 Y227.019 Z-4.938 F254
G1 X91.257 Y226.975 Z-4.958 F254
G1 X91.241 Y226.927 Z-4.978 F254
G1 X91.233 Y226.878 Z-4.999 F254
G1 Y226.828 Z-5.019 F254
G1 X91.241 Y226.779 Z-5.039 F254
G1 X91.256 Y226.732 Z-5.06 F254
G1 X91.278 Y226.687 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X91.673 Y226.113 F254
G1 X91.847 Y225.894 F254
G1 X91.919 Y225.809 F254
G1 X91.954 Y225.779 F254
G1 X91.99 Y225.757 F254
G1 X92.039 Y225.736 F254
G1 X92.094 Y225.722 F254
G1 X92.148 Y225.717 F254
G1 X92.177 F254
G1 X92.206 Y225.721 F254
G1 X92.234 Y225.727 F254
G1 X92.263 Y225.736 F254
G1 X92.307 Y225.756 F254
G1 X92.465 Y225.859 F254
G1 X93.417 Y226.583 F254
G1 X93.75 Y226.846 F254
G1 X93.892 Y226.964 F254
G1 X94.843 Y227.815 F254
G1 X94.989 Y227.956 F254
G1 X95.161 Y228.135 F254
G1 X95.319 Y228.306 F254
G1 X95.953 Y228.998 F254
G1 X96.013 Y229.066 F254
G1 X96.143 Y229.225 F254
G1 X96.395 Y229.542 F254
G1 X97.021 Y230.335 F254
G1 X97.142 Y230.509 F254
G1 X97.237 Y230.671 F254
G1 X97.324 Y230.852 F254
G1 X97.402 Y231.055 F254
G1 X97.471 Y231.288 F254
G1 X97.522 Y231.532 F254
G1 X97.556 Y231.8 F254
G1 X97.569 Y232.09 F254
G1 X97.559 Y232.397 F254
G1 X97.523 Y232.711 F254
G1 X97.46 Y233.03 F254
G1 X97.368 Y233.355 F254
G1 X97.246 Y233.682 F254
G1 X97.095 Y234.006 F254
G1 X96.915 Y234.324 F254
G1 X96.706 Y234.631 F254
G1 X96.522 Y234.861 F254
G1 X96.335 Y235.059 F254
G1 X96.319 Y235.073 F254
G1 X96.143 Y235.191 F254
G1 X95.941 Y235.254 F254
G1 X95.729 Y235.257 F254
G1 X95.525 Y235.201 F254
G1 X95.161 Y235.04 F254
G1 X95.002 Y234.979 F254
G1 X94.88 Y234.935 F254
G1 X94.843 Y234.925 F254
G1 X94.685 Y234.889 F254
G1 X94.515 Y234.854 F254
; MOVEMENT_LEAD_OUT
G1 X94.468 Y234.839 Z-5.06 F254
G1 X94.423 Y234.816 Z-5.039 F254
G1 X94.383 Y234.787 Z-5.019 F254
G1 X94.347 Y234.753 Z-4.999 F254
G1 X94.317 Y234.713 Z-4.978 F254
G1 X94.294 Y234.668 Z-4.958 F254
G1 X94.279 Y234.621 Z-4.938 F254
G1 X94.27 Y234.572 Z-4.917 F254
G1 Y234.522 Z-4.897 F254
G1 X94.277 Y234.473 Z-4.877 F254
G3 X94.308 Y234.392 I0.309 J0.071 F254
G1 X94.385 Y234.251 F254
; MOVEMENT_LINK_DIRECT
G1 X96.438 Y230.502 F254
; MOVEMENT_LEAD_IN
G1 X96.5 Y230.388 F254
G3 X96.574 Y230.298 I0.278 J0.152 F254
G1 X96.614 Y230.269 Z-4.897 F254
G1 X96.659 Y230.246 Z-4.917 F254
G1 X96.706 Y230.231 Z-4.938 F254
G1 X96.756 Y230.224 Z-4.958 F254
G1 X96.805 Z-4.978 F254
G1 X96.855 Y230.232 Z-4.999 F254
G1 X96.902 Y230.248 Z-5.019 F254
G1 X96.946 Y230.27 Z-5.039 F254
G1 X96.986 Y230.3 Z-5.06 F254
G1 X97.021 Y230.335 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X97.758 Y231.287 F254
G1 X97.856 Y231.415 F254
G1 X97.995 Y231.604 F254
G1 X98.079 Y231.731 F254
G1 X98.151 Y231.866 F254
G1 X98.214 Y232.016 F254
G1 X98.267 Y232.176 F254
G1 X98.315 Y232.369 F254
G1 X98.347 Y232.57 F254
G1 X98.366 Y232.806 F254
G1 X98.365 Y233.056 F254
G1 X98.343 Y233.328 F254
G1 X98.294 Y233.629 F254
G1 X98.217 Y233.939 F254
G1 X98.11 Y234.259 F254
G1 X97.974 Y234.578 F254
G1 X97.822 Y234.867 F254
G1 X97.68 Y235.093 F254
G1 X97.535 Y235.286 F254
G1 X97.403 Y235.434 F254
G1 X97.348 Y235.488 F254
G1 X97.173 Y235.613 F254
G1 X96.969 Y235.682 F254
G1 X96.754 Y235.69 F254
G1 X96.546 Y235.636 F254
; MOVEMENT_LEAD_OUT
G1 X96.502 Y235.611 Z-5.059 F254
G1 X96.463 Y235.58 Z-5.039 F254
G1 X96.429 Y235.543 Z-5.018 F254
G1 X96.401 Y235.501 Z-4.998 F254
G1 X96.381 Y235.455 Z-4.977 F254
G1 X96.368 Y235.406 Z-4.957 F254
G1 X96.362 Y235.356 Z-4.936 F254
G1 X96.365 Y235.306 Z-4.916 F254
G1 X96.376 Y235.257 Z-4.895 F254
G1 X96.389 Y235.214 Z-4.877 F254
G1 X96.46 Y234.977 F254
; MOVEMENT_LINK_DIRECT
G1 X97.426 Y231.761 F254
; MOVEMENT_LEAD_IN
G1 X97.442 Y231.71 F254
G3 X97.549 Y231.552 I0.304 J0.091 F254
G1 X97.59 Y231.524 Z-4.897 F254
G1 X97.636 Y231.503 Z-4.917 F254
G1 X97.683 Y231.49 Z-4.938 F254
G1 X97.733 Y231.484 Z-4.958 F254
G1 X97.783 Y231.486 Z-4.978 F254
G1 X97.832 Y231.495 Z-4.999 F254
G1 X97.878 Y231.513 Z-5.019 F254
G1 X97.922 Y231.537 Z-5.039 F254
G1 X97.961 Y231.568 Z-5.06 F254
G1 X97.995 Y231.604 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X98.228 Y231.921 F254
G1 X98.559 Y232.397 F254
G1 X98.648 Y232.54 F254
G1 X98.657 Y232.556 F254
G1 X98.732 Y232.714 F254
G1 X98.877 Y233.031 F254
G1 X98.909 Y233.111 F254
G1 X98.935 Y233.19 F254
G1 X98.969 Y233.349 F254
G1 X99.014 Y233.629 F254
G1 X99.03 Y233.824 F254
G1 Y234.044 F254
G1 X99.011 Y234.271 F254
G1 X98.971 Y234.516 F254
G1 X98.909 Y234.769 F254
G1 X98.826 Y235.019 F254
G1 X98.731 Y235.24 F254
G1 X98.625 Y235.442 F254
G1 X98.512 Y235.622 F254
G1 X98.485 Y235.657 F254
G1 X98.344 Y235.8 F254
G1 X98.17 Y235.9 F254
G1 X97.975 Y235.949 F254
G1 X97.775 Y235.944 F254
; MOVEMENT_LEAD_OUT
G1 X97.727 Y235.931 Z-5.06 F254
G1 X97.681 Y235.91 Z-5.039 F254
G1 X97.64 Y235.883 Z-5.019 F254
G1 X97.603 Y235.849 Z-4.999 F254
G1 X97.572 Y235.81 Z-4.978 F254
G1 X97.548 Y235.766 Z-4.958 F254
G1 X97.531 Y235.72 Z-4.938 F254
G1 X97.521 Y235.671 Z-4.917 F254
G1 X97.519 Y235.621 Z-4.897 F254
G1 X97.525 Y235.572 Z-4.877 F254
G3 X97.539 Y235.522 I0.312 J0.061 F254
G1 X97.607 Y235.339 F254
; MOVEMENT_LINK_DIRECT
G1 X98.364 Y233.314 F254
G3 X98.584 Y233.118 I0.297 J0.111 F254
; MOVEMENT_LEAD_IN
G1 X98.633 Y233.109 Z-4.897 F254
G1 X98.683 Z-4.917 F254
G1 X98.732 Y233.116 Z-4.938 F254
G1 X98.78 Y233.131 Z-4.958 F254
G1 X98.825 Y233.153 Z-4.978 F254
G1 X98.865 Y233.182 Z-4.999 F254
G1 X98.901 Y233.217 Z-5.019 F254
G1 X98.93 Y233.257 Z-5.039 F254
G1 X98.953 Y233.301 Z-5.06 F254
G1 X98.969 Y233.349 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X99.172 Y234.3 F254
G1 X99.185 Y234.38 F254
G1 X99.192 Y234.617 F254
G1 X99.19 Y234.776 F254
G1 X99.165 Y234.935 F254
G1 X99.15 Y235.004 F254
G1 X99.116 Y235.093 F254
G1 X99.08 Y235.173 F254
G1 X99.028 Y235.252 F254
G1 X98.965 Y235.344 F254
G1 X98.903 Y235.41 F254
G1 X98.425 Y235.886 F254
G1 X98.378 Y235.924 F254
G1 X98.331 Y235.953 F254
G1 X98.292 Y235.97 F254
G1 X98.252 Y235.981 F254
G1 X98.212 Y235.987 F254
G1 X98.173 F254
G1 X97.856 Y235.957 F254
G1 X97.697 Y235.932 F254
G1 X97.38 Y235.873 F254
G1 X97.222 Y235.843 F254
G1 X96.904 Y235.778 F254
G1 X96.869 Y235.769 F254
G1 X96.834 Y235.758 F254
G1 X95.953 Y235.385 F254
G1 X95.636 Y235.25 F254
G1 X95.525 Y235.201 F254
; MOVEMENT_LEAD_OUT
G3 X95.365 Y234.805 I0.138 J-0.286 F254
G1 X95.388 Y234.772 Z-5.077 F254
G1 X95.41 Y234.739 Z-5.069 F254
G1 X95.432 Y234.707 Z-5.056 F254
G1 X95.453 Y234.676 Z-5.038 F254
G1 X95.485 Y234.66 Z-5.013 F254
G1 X95.514 Y234.645 Z-4.984 F254
G1 X95.539 Y234.633 Z-4.951 F254
G1 X95.559 Y234.622 Z-4.915 F254
G1 X95.575 Y234.614 Z-4.875 F254
G1 X95.587 Y234.608 Z-4.834 F254
G1 X95.593 Y234.605 Z-4.791 F254
G1 X95.594 Z-4.762 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X115.328 Y183.822 F254
G1 Z2.54 F254
; MOVEMENT_RAMP_HELIX
G1 X115.432 Y183.871 Z2.536 F25
G1 X115.531 Y183.926 Z2.532 F25
G1 X115.627 Y183.989 Z2.528 F25
G1 X115.717 Y184.057 Z2.524 F25
G1 X115.803 Y184.132 Z2.52 F25
G1 X115.884 Y184.213 Z2.516 F25
G1 X115.959 Y184.299 Z2.512 F25
G1 X116.027 Y184.39 Z2.508 F25
G1 X116.089 Y184.486 Z2.504 F25
G1 X116.145 Y184.585 Z2.5 F25
G1 X116.193 Y184.689 Z2.496 F25
G1 X116.234 Y184.795 Z2.492 F25
G1 X116.267 Y184.904 Z2.488 F25
G1 X116.293 Y185.015 Z2.484 F25
G1 X116.311 Y185.128 Z2.48 F25
G1 X116.321 Y185.241 Z2.476 F25
G1 X116.323 Y185.355 Z2.472 F25
G1 X116.317 Y185.469 Z2.468 F25
G1 X116.304 Y185.582 Z2.464 F25
G1 X116.282 Y185.694 Z2.46 F25
G1 X116.253 Y185.804 Z2.456 F25
G1 X116.216 Y185.912 Z2.452 F25
G1 X116.172 Y186.017 Z2.448 F25
G1 X116.121 Y186.119 Z2.444 F25
G1 X116.063 Y186.217 Z2.44 F25
G1 X115.998 Y186.311 Z2.436 F25
G1 X115.926 Y186.399 Z2.433 F25
G1 X115.849 Y186.483 Z2.429 F25
G1 X115.766 Y186.561 Z2.425 F25
G1 X115.678 Y186.633 Z2.421 F25
G1 X115.585 Y186.699 Z2.417 F25
G1 X115.488 Y186.758 Z2.413 F25
G1 X115.387 Y186.811 Z2.409 F25
G1 X115.282 Y186.856 Z2.405 F25
G1 X115.175 Y186.894 Z2.401 F25
G1 X115.065 Y186.924 Z2.397 F25
G1 X114.953 Y186.946 Z2.393 F25
G1 X114.841 Y186.961 Z2.389 F25
G1 X114.727 Y186.968 Z2.385 F25
G1 X114.613 Y186.967 Z2.381 F25
G1 X114.5 Y186.958 Z2.377 F25
G1 X114.387 Y186.941 Z2.373 F25
G1 X114.276 Y186.917 Z2.369 F25
G1 X114.167 Y186.884 Z2.365 F25
G1 X114.06 Y186.844 Z2.361 F25
G1 X113.956 Y186.797 Z2.357 F25
G1 X113.856 Y186.743 Z2.353 F25
G1 X113.76 Y186.682 Z2.349 F25
G1 X113.669 Y186.615 Z2.345 F25
G1 X113.582 Y186.541 Z2.341 F25
G1 X113.5 Y186.461 Z2.337 F25
G1 X113.425 Y186.376 Z2.333 F25
G1 X113.355 Y186.286 Z2.329 F25
G1 X113.292 Y186.191 Z2.325 F25
G1 X113.236 Y186.092 Z2.321 F25
G1 X113.186 Y185.99 Z2.317 F25
G1 X113.144 Y185.884 Z2.313 F25
G1 X113.11 Y185.776 Z2.309 F25
G1 X113.083 Y185.665 Z2.305 F25
G1 X113.063 Y185.553 Z2.301 F25
G1 X113.052 Y185.44 Z2.297 F25
G1 X113.048 Y185.326 Z2.293 F25
G1 X113.053 Y185.213 Z2.289 F25
G1 X113.065 Y185.1 Z2.285 F25
G1 X113.085 Y184.988 Z2.281 F25
G1 X113.113 Y184.877 Z2.277 F25
G1 X113.148 Y184.769 Z2.273 F25
G1 X113.191 Y184.664 Z2.269 F25
G1 X113.241 Y184.562 Z2.265 F25
G1 X113.298 Y184.464 Z2.261 F25
G1 X113.362 Y184.369 Z2.257 F25
G1 X113.432 Y184.28 Z2.253 F25
G1 X113.508 Y184.195 Z2.249 F25
G1 X113.59 Y184.116 Z2.245 F25
G1 X113.677 Y184.043 Z2.241 F25
G1 X113.769 Y183.976 Z2.237 F25
G1 X113.865 Y183.916 Z2.233 F25
G1 X113.965 Y183.863 Z2.229 F25
G1 X114.069 Y183.816 Z2.225 F25
G1 X114.176 Y183.777 Z2.222 F25
G1 X114.285 Y183.746 Z2.218 F25
G1 X114.396 Y183.722 Z2.214 F25
G1 X114.509 Y183.706 Z2.21 F25
G1 X114.622 Y183.698 Z2.206 F25
G1 X114.736 Z2.202 F25
G1 X114.85 Y183.705 Z2.198 F25
G1 X114.962 Y183.721 Z2.194 F25
G1 X115.073 Y183.744 Z2.19 F25
G1 X115.183 Y183.775 Z2.186 F25
G1 X115.29 Y183.813 Z2.182 F25
G1 X115.393 Y183.859 Z2.178 F25
G1 X115.494 Y183.912 Z2.174 F25
G1 X115.591 Y183.972 Z2.17 F25
G1 X115.683 Y184.038 Z2.166 F25
G1 X115.77 Y184.11 Z2.162 F25
G1 X115.852 Y184.189 Z2.158 F25
G1 X115.929 Y184.273 Z2.154 F25
G1 X115.999 Y184.362 Z2.15 F25
G1 X116.063 Y184.456 Z2.146 F25
G1 X116.121 Y184.554 Z2.142 F25
G1 X116.171 Y184.655 Z2.138 F25
G1 X116.214 Y184.76 Z2.134 F25
G1 X116.25 Y184.868 Z2.13 F25
G1 X116.279 Y184.978 Z2.126 F25
G1 X116.299 Y185.09 Z2.122 F25
G1 X116.312 Y185.203 Z2.118 F25
G1 X116.317 Y185.316 Z2.114 F25
G1 X116.314 Y185.429 Z2.11 F25
G1 X116.303 Y185.543 Z2.106 F25
G1 X116.284 Y185.655 Z2.102 F25
G1 X116.258 Y185.765 Z2.098 F25
G1 X116.224 Y185.873 Z2.094 F25
G1 X116.183 Y185.979 Z2.09 F25
G1 X116.134 Y186.082 Z2.086 F25
G1 X116.078 Y186.181 Z2.082 F25
G1 X116.016 Y186.275 Z2.078 F25
G1 X115.947 Y186.366 Z2.074 F25
G1 X115.872 Y186.451 Z2.07 F25
G1 X115.791 Y186.53 Z2.066 F25
G1 X115.705 Y186.604 Z2.062 F25
G1 X115.614 Y186.672 Z2.058 F25
G1 X115.519 Y186.733 Z2.054 F25
G1 X115.419 Y186.788 Z2.05 F25
G1 X115.316 Y186.835 Z2.046 F25
G1 X115.21 Y186.876 Z2.042 F25
G1 X115.102 Y186.908 Z2.038 F25
G1 X114.991 Y186.933 Z2.034 F25
G1 X114.879 Y186.951 Z2.03 F25
G1 X114.766 Y186.96 Z2.026 F25
G1 X114.652 Y186.962 Z2.022 F25
G1 X114.539 Y186.956 Z2.018 F25
G1 X114.427 Y186.942 Z2.014 F25
G1 X114.315 Y186.92 Z2.011 F25
G1 X114.206 Y186.89 Z2.007 F25
G1 X114.099 Y186.853 Z2.003 F25
G1 X113.994 Y186.809 Z1.999 F25
G1 X113.893 Y186.757 Z1.995 F25
G1 X113.796 Y186.699 Z1.991 F25
G1 X113.703 Y186.633 Z1.987 F25
G1 X113.615 Y186.562 Z1.983 F25
G1 X113.532 Y186.485 Z1.979 F25
G1 X113.455 Y186.402 Z1.975 F25
G1 X113.383 Y186.314 Z1.971 F25
G1 X113.318 Y186.221 Z1.967 F25
G1 X113.26 Y186.124 Z1.963 F25
G1 X113.208 Y186.023 Z1.959 F25
G1 X113.164 Y185.918 Z1.955 F25
G1 X113.127 Y185.811 Z1.951 F25
G1 X113.097 Y185.702 Z1.947 F25
G1 X113.075 Y185.591 Z1.943 F25
G1 X113.061 Y185.479 Z1.939 F25
G1 X113.055 Y185.365 Z1.935 F25
G1 X113.056 Y185.252 Z1.931 F25
G1 X113.066 Y185.139 Z1.927 F25
G1 X113.083 Y185.027 Z1.923 F25
G1 X113.108 Y184.917 Z1.919 F25
G1 X113.141 Y184.808 Z1.915 F25
G1 X113.181 Y184.702 Z1.911 F25
G1 X113.228 Y184.6 Z1.907 F25
G1 X113.283 Y184.5 Z1.903 F25
G1 X113.344 Y184.405 Z1.899 F25
G1 X113.412 Y184.314 Z1.895 F25
G1 X113.486 Y184.228 Z1.891 F25
G1 X113.565 Y184.147 Z1.887 F25
G1 X113.65 Y184.073 Z1.883 F25
G1 X113.74 Y184.004 Z1.879 F25
G1 X113.835 Y183.941 Z1.875 F25
G1 X113.934 Y183.886 Z1.871 F25
G1 X114.036 Y183.837 Z1.867 F25
G1 X114.141 Y183.796 Z1.863 F25
G1 X114.249 Y183.762 Z1.859 F25
G1 X114.36 Y183.735 Z1.855 F25
G1 X114.471 Y183.717 Z1.851 F25
G1 X114.584 Y183.706 Z1.847 F25
G1 X114.697 Y183.703 Z1.843 F25
G1 X114.81 Y183.708 Z1.839 F25
G1 X114.923 Y183.721 Z1.835 F25
G1 X115.034 Y183.741 Z1.831 F25
G1 X115.143 Y183.769 Z1.827 F25
G1 X115.251 Y183.805 Z1.823 F25
G1 X115.355 Y183.848 Z1.819 F25
G1 X115.457 Y183.898 Z1.815 F25
G1 X115.554 Y183.955 Z1.811 F25
G1 X115.648 Y184.019 Z1.807 F25
G1 X115.737 Y184.089 Z1.803 F25
G1 X115.82 Y184.166 Z1.799 F25
G1 X115.898 Y184.247 Z1.796 F25
G1 X115.971 Y184.334 Z1.792 F25
G1 X116.037 Y184.426 Z1.788 F25
G1 X116.096 Y184.523 Z1.784 F25
G1 X116.149 Y184.623 Z1.78 F25
G1 X116.195 Y184.726 Z1.776 F25
G1 X116.233 Y184.833 Z1.772 F25
G1 X116.264 Y184.942 Z1.768 F25
G1 X116.287 Y185.052 Z1.764 F25
G1 X116.302 Y185.164 Z1.76 F25
G1 X116.31 Y185.277 Z1.756 F25
G1 Y185.39 Z1.752 F25
G1 X116.302 Y185.503 Z1.748 F25
G1 X116.286 Y185.615 Z1.744 F25
G1 X116.262 Y185.726 Z1.74 F25
G1 X116.231 Y185.835 Z1.736 F25
G1 X116.192 Y185.941 Z1.732 F25
G1 X116.146 Y186.044 Z1.728 F25
G1 X116.093 Y186.144 Z1.724 F25
G1 X116.033 Y186.24 Z1.72 F25
G1 X115.966 Y186.331 Z1.716 F25
G1 X115.894 Y186.418 Z1.712 F25
G1 X115.815 Y186.499 Z1.708 F25
G1 X115.731 Y186.575 Z1.704 F25
G1 X115.642 Y186.644 Z1.7 F25
G1 X115.549 Y186.708 Z1.696 F25
G1 X115.451 Y186.764 Z1.692 F25
G1 X115.35 Y186.814 Z1.688 F25
G1 X115.245 Y186.857 Z1.684 F25
G1 X115.137 Y186.892 Z1.68 F25
G1 X115.028 Y186.919 Z1.676 F25
G1 X114.917 Y186.939 Z1.672 F25
G1 X114.804 Y186.952 Z1.668 F25
G1 X114.691 Y186.956 Z1.664 F25
G1 X114.578 Y186.952 Z1.66 F25
G1 X114.466 Y186.941 Z1.656 F25
G1 X114.355 Y186.922 Z1.652 F25
G1 X114.245 Y186.895 Z1.648 F25
G1 X114.137 Y186.861 Z1.644 F25
G1 X114.032 Y186.819 Z1.64 F25
G1 X113.93 Y186.77 Z1.636 F25
G1 X113.832 Y186.714 Z1.632 F25
G1 X113.738 Y186.651 Z1.628 F25
G1 X113.649 Y186.582 Z1.624 F25
G1 X113.564 Y186.507 Z1.62 F25
G1 X113.485 Y186.426 Z1.616 F25
G1 X113.412 Y186.341 Z1.612 F25
G1 X113.345 Y186.25 Z1.608 F25
G1 X113.285 Y186.154 Z1.604 F25
G1 X113.231 Y186.055 Z1.6 F25
G1 X113.184 Y185.952 Z1.596 F25
G1 X113.145 Y185.847 Z1.592 F25
G1 X113.113 Y185.739 Z1.588 F25
G1 X113.088 Y185.628 Z1.585 F25
G1 X113.071 Y185.517 Z1.581 F25
G1 X113.062 Y185.404 Z1.577 F25
G1 X113.061 Y185.291 Z1.573 F25
G1 X113.068 Y185.179 Z1.569 F25
G1 X113.083 Y185.067 Z1.565 F25
G1 X113.105 Y184.956 Z1.561 F25
G1 X113.135 Y184.847 Z1.557 F25
G1 X113.172 Y184.741 Z1.553 F25
G1 X113.217 Y184.637 Z1.549 F25
G1 X113.269 Y184.537 Z1.545 F25
G1 X113.328 Y184.441 Z1.541 F25
G1 X113.393 Y184.348 Z1.537 F25
G1 X113.464 Y184.261 Z1.533 F25
G1 X113.542 Y184.179 Z1.529 F25
G1 X113.625 Y184.102 Z1.525 F25
G1 X113.713 Y184.032 Z1.521 F25
G1 X113.805 Y183.967 Z1.517 F25
G1 X113.902 Y183.91 Z1.513 F25
G1 X114.003 Y183.859 Z1.509 F25
G1 X114.107 Y183.815 Z1.505 F25
G1 X114.214 Y183.779 Z1.501 F25
G1 X114.323 Y183.75 Z1.497 F25
G1 X114.434 Y183.728 Z1.493 F25
G1 X114.546 Y183.715 Z1.489 F25
G1 X114.658 Y183.709 Z1.485 F25
G1 X114.771 Y183.711 Z1.481 F25
G1 X114.883 Y183.721 Z1.477 F25
G1 X114.994 Y183.739 Z1.473 F25
G1 X115.104 Y183.765 Z1.469 F25
G1 X115.212 Y183.798 Z1.465 F25
G1 X115.317 Y183.838 Z1.461 F25
G1 X115.419 Y183.886 Z1.457 F25
G1 X115.518 Y183.94 Z1.453 F25
G1 X115.613 Y184.002 Z1.449 F25
G1 X115.703 Y184.07 Z1.445 F25
G1 X115.788 Y184.143 Z1.441 F25
G1 X115.868 Y184.223 Z1.437 F25
G1 X115.942 Y184.308 Z1.433 F25
G1 X116.01 Y184.398 Z1.429 F25
G1 X116.071 Y184.492 Z1.425 F25
G1 X116.126 Y184.591 Z1.421 F25
G1 X116.174 Y184.693 Z1.417 F25
G1 X116.215 Y184.798 Z1.413 F25
G1 X116.248 Y184.906 Z1.409 F25
G1 X116.274 Y185.015 Z1.405 F25
G1 X116.292 Y185.127 Z1.401 F25
G1 X116.302 Y185.239 Z1.397 F25
G1 X116.304 Y185.352 Z1.393 F25
G1 X116.299 Y185.464 Z1.389 F25
G1 X116.286 Y185.576 Z1.385 F25
G1 X116.265 Y185.687 Z1.381 F25
G1 X116.236 Y185.796 Z1.377 F25
G1 X116.2 Y185.902 Z1.374 F25
G1 X116.157 Y186.006 Z1.37 F25
G1 X116.106 Y186.107 Z1.366 F25
G1 X116.049 Y186.204 Z1.362 F25
G1 X115.985 Y186.296 Z1.358 F25
G1 X115.915 Y186.384 Z1.354 F25
G1 X115.838 Y186.467 Z1.35 F25
G1 X115.757 Y186.545 Z1.346 F25
G1 X115.67 Y186.616 Z1.342 F25
G1 X115.578 Y186.681 Z1.338 F25
G1 X115.482 Y186.74 Z1.334 F25
G1 X115.382 Y186.792 Z1.33 F25
G1 X115.279 Y186.837 Z1.326 F25
G1 X115.173 Y186.875 Z1.322 F25
G1 X115.064 Y186.905 Z1.318 F25
G1 X114.954 Y186.927 Z1.314 F25
G1 X114.842 Y186.942 Z1.31 F25
G1 X114.73 Y186.949 Z1.306 F25
G1 X114.617 Y186.948 Z1.302 F25
G1 X114.505 Y186.94 Z1.298 F25
G1 X114.394 Y186.923 Z1.294 F25
G1 X114.284 Y186.899 Z1.29 F25
G1 X114.176 Y186.867 Z1.286 F25
G1 X114.07 Y186.828 Z1.282 F25
G1 X113.968 Y186.782 Z1.278 F25
G1 X113.869 Y186.728 Z1.274 F25
G1 X113.773 Y186.668 Z1.27 F25
G1 X113.683 Y186.602 Z1.266 F25
G1 X113.597 Y186.529 Z1.262 F25
G1 X113.516 Y186.451 Z1.258 F25
G1 X113.441 Y186.367 Z1.254 F25
G1 X113.373 Y186.278 Z1.25 F25
G1 X113.31 Y186.185 Z1.246 F25
G1 X113.254 Y186.087 Z1.242 F25
G1 X113.205 Y185.986 Z1.238 F25
G1 X113.163 Y185.881 Z1.234 F25
G1 X113.129 Y185.774 Z1.23 F25
G1 X113.102 Y185.665 Z1.226 F25
G1 X113.082 Y185.554 Z1.222 F25
G1 X113.071 Y185.443 Z1.218 F25
G1 X113.067 Y185.33 Z1.214 F25
G1 X113.071 Y185.218 Z1.21 F25
G1 X113.083 Y185.106 Z1.206 F25
G1 X113.103 Y184.995 Z1.202 F25
G1 X113.13 Y184.886 Z1.198 F25
G1 X113.165 Y184.779 Z1.194 F25
G1 X113.207 Y184.675 Z1.19 F25
G1 X113.256 Y184.574 Z1.186 F25
G1 X113.312 Y184.476 Z1.182 F25
G1 X113.375 Y184.383 Z1.178 F25
G1 X113.444 Y184.295 Z1.174 F25
G1 X113.519 Y184.211 Z1.17 F25
G1 X113.6 Y184.133 Z1.166 F25
G1 X113.686 Y184.06 Z1.163 F25
G1 X113.777 Y183.994 Z1.159 F25
G1 X113.872 Y183.934 Z1.155 F25
G1 X113.971 Y183.881 Z1.151 F25
G1 X114.073 Y183.835 Z1.147 F25
G1 X114.179 Y183.796 Z1.143 F25
G1 X114.287 Y183.765 Z1.139 F25
G1 X114.396 Y183.741 Z1.135 F25
G1 X114.507 Y183.725 Z1.131 F25
G1 X114.619 Y183.717 Z1.127 F25
G1 X114.732 Y183.716 Z1.123 F25
G1 X114.844 Y183.723 Z1.119 F25
G1 X114.955 Y183.738 Z1.115 F25
G1 X115.065 Y183.761 Z1.111 F25
G1 X115.173 Y183.791 Z1.107 F25
G1 X115.279 Y183.829 Z1.103 F25
G1 X115.382 Y183.874 Z1.099 F25
G1 X115.481 Y183.926 Z1.095 F25
G1 X115.577 Y183.985 Z1.091 F25
G1 X115.668 Y184.051 Z1.087 F25
G1 X115.755 Y184.122 Z1.083 F25
G1 X115.836 Y184.199 Z1.079 F25
G1 X115.912 Y184.282 Z1.075 F25
G1 X115.982 Y184.37 Z1.071 F25
G1 X116.045 Y184.463 Z1.067 F25
G1 X116.102 Y184.56 Z1.063 F25
G1 X116.153 Y184.66 Z1.059 F25
G1 X116.196 Y184.764 Z1.055 F25
G1 X116.231 Y184.87 Z1.051 F25
G1 X116.26 Y184.979 Z1.047 F25
G1 X116.28 Y185.089 Z1.043 F25
G1 X116.293 Y185.201 Z1.039 F25
G1 X116.298 Y185.313 Z1.035 F25
G1 X116.296 Y185.425 Z1.031 F25
G1 X116.285 Y185.537 Z1.027 F25
G1 X116.267 Y185.647 Z1.023 F25
G1 X116.241 Y185.757 Z1.019 F25
G1 X116.208 Y185.864 Z1.015 F25
G1 X116.167 Y185.968 Z1.011 F25
G1 X116.119 Y186.07 Z1.007 F25
G1 X116.064 Y186.167 Z1.003 F25
G1 X116.003 Y186.261 Z0.999 F25
G1 X115.935 Y186.351 Z0.995 F25
G1 X115.861 Y186.435 Z0.991 F25
G1 X115.781 Y186.514 Z0.987 F25
G1 X115.696 Y186.587 Z0.983 F25
G1 X115.606 Y186.654 Z0.979 F25
G1 X115.512 Y186.715 Z0.975 F25
G1 X115.414 Y186.769 Z0.971 F25
G1 X115.312 Y186.817 Z0.967 F25
G1 X115.207 Y186.856 Z0.963 F25
G1 X115.1 Y186.889 Z0.959 F25
G1 X114.991 Y186.914 Z0.955 F25
G1 X114.88 Y186.932 Z0.952 F25
G1 X114.768 Y186.941 Z0.948 F25
G1 X114.656 Y186.943 Z0.944 F25
G1 X114.544 Y186.937 Z0.94 F25
G1 X114.433 Y186.923 Z0.936 F25
G1 X114.323 Y186.902 Z0.932 F25
G1 X114.214 Y186.873 Z0.928 F25
G1 X114.108 Y186.837 Z0.924 F25
G1 X114.005 Y186.793 Z0.92 F25
G1 X113.905 Y186.742 Z0.916 F25
G1 X113.809 Y186.685 Z0.912 F25
G1 X113.717 Y186.621 Z0.908 F25
G1 X113.63 Y186.55 Z0.904 F25
G1 X113.548 Y186.474 Z0.9 F25
G1 X113.471 Y186.392 Z0.896 F25
G1 X113.401 Y186.305 Z0.892 F25
G1 X113.336 Y186.214 Z0.888 F25
G1 X113.278 Y186.118 Z0.884 F25
G1 X113.227 Y186.018 Z0.88 F25
G1 X113.183 Y185.915 Z0.876 F25
G1 X113.146 Y185.81 Z0.872 F25
G1 X113.116 Y185.702 Z0.868 F25
G1 X113.095 Y185.592 Z0.864 F25
G1 X113.08 Y185.481 Z0.86 F25
G1 X113.074 Y185.369 Z0.856 F25
G1 X113.075 Y185.257 Z0.852 F25
G1 X113.084 Y185.145 Z0.848 F25
G1 X113.101 Y185.034 Z0.844 F25
G1 X113.126 Y184.925 Z0.84 F25
G1 X113.158 Y184.818 Z0.836 F25
G1 X113.197 Y184.713 Z0.832 F25
G1 X113.244 Y184.611 Z0.828 F25
G1 X113.298 Y184.513 Z0.824 F25
G1 X113.358 Y184.418 Z0.82 F25
G1 X113.425 Y184.328 Z0.816 F25
G1 X113.497 Y184.243 Z0.812 F25
G1 X113.576 Y184.163 Z0.808 F25
G1 X113.66 Y184.089 Z0.804 F25
G1 X113.748 Y184.021 Z0.8 F25
G1 X113.842 Y183.959 Z0.796 F25
G1 X113.939 Y183.904 Z0.792 F25
G1 X114.04 Y183.856 Z0.788 F25
G1 X114.144 Y183.815 Z0.784 F25
G1 X114.251 Y183.781 Z0.78 F25
G1 X114.359 Y183.755 Z0.776 F25
G1 X114.47 Y183.736 Z0.772 F25
G1 X114.581 Y183.725 Z0.768 F25
G1 X114.693 Y183.722 Z0.764 F25
G1 X114.805 Y183.726 Z0.76 F25
G1 X114.916 Y183.739 Z0.756 F25
G1 X115.026 Y183.759 Z0.752 F25
G1 X115.134 Y183.786 Z0.748 F25
G1 X115.241 Y183.821 Z0.744 F25
G1 X115.344 Y183.864 Z0.741 F25
G1 X115.445 Y183.913 Z0.737 F25
G1 X115.541 Y183.97 Z0.733 F25
G1 X115.634 Y184.032 Z0.729 F25
G1 X115.722 Y184.102 Z0.725 F25
G1 X115.805 Y184.177 Z0.721 F25
G1 X115.882 Y184.258 Z0.717 F25
G1 X115.954 Y184.343 Z0.713 F25
G1 X116.019 Y184.434 Z0.709 F25
G1 X116.078 Y184.529 Z0.705 F25
G1 X116.131 Y184.628 Z0.701 F25
G1 X116.176 Y184.73 Z0.697 F25
G1 X116.214 Y184.836 Z0.693 F25
G1 X116.245 Y184.943 Z0.689 F25
G1 X116.268 Y185.052 Z0.685 F25
G1 X116.283 Y185.163 Z0.681 F25
G1 X116.291 Y185.274 Z0.677 F25
G1 Y185.386 Z0.673 F25
G1 X116.283 Y185.498 Z0.669 F25
G1 X116.268 Y185.608 Z0.665 F25
G1 X116.245 Y185.718 Z0.661 F25
G1 X116.214 Y185.825 Z0.657 F25
G1 X116.176 Y185.93 Z0.653 F25
G1 X116.131 Y186.032 Z0.649 F25
G1 X116.078 Y186.131 Z0.645 F25
G1 X116.019 Y186.226 Z0.641 F25
G1 X115.954 Y186.316 Z0.637 F25
G1 X115.882 Y186.402 Z0.633 F25
G1 X115.805 Y186.483 Z0.629 F25
G1 X115.722 Y186.558 Z0.625 F25
G1 X115.634 Y186.627 Z0.621 F25
G1 X115.542 Y186.69 Z0.617 F25
G1 X115.445 Y186.746 Z0.613 F25
G1 X115.345 Y186.795 Z0.609 F25
G1 X115.242 Y186.838 Z0.605 F25
G1 X115.135 Y186.873 Z0.601 F25
G1 X115.027 Y186.9 Z0.597 F25
G1 X114.917 Y186.92 Z0.593 F25
G1 X114.806 Y186.933 Z0.589 F25
G1 X114.694 Y186.937 Z0.585 F25
G1 X114.583 Y186.934 Z0.581 F25
G1 X114.472 Y186.923 Z0.577 F25
G1 X114.362 Y186.904 Z0.573 F25
G1 X114.253 Y186.878 Z0.569 F25
G1 X114.147 Y186.844 Z0.565 F25
G1 X114.043 Y186.803 Z0.561 F25
G1 X113.942 Y186.755 Z0.557 F25
G1 X113.845 Y186.7 Z0.553 F25
G1 X113.752 Y186.638 Z0.549 F25
G1 X113.664 Y186.57 Z0.545 F25
G1 X113.58 Y186.496 Z0.541 F25
G1 X113.502 Y186.417 Z0.537 F25
G1 X113.429 Y186.332 Z0.533 F25
G1 X113.363 Y186.242 Z0.529 F25
G1 X113.303 Y186.148 Z0.526 F25
G1 X113.249 Y186.05 Z0.522 F25
G1 X113.203 Y185.949 Z0.518 F25
G1 X113.164 Y185.844 Z0.514 F25
G1 X113.132 Y185.737 Z0.51 F25
G1 X113.107 Y185.628 Z0.506 F25
G1 X113.091 Y185.518 Z0.502 F25
G1 X113.082 Y185.407 Z0.498 F25
G1 X113.08 Y185.295 Z0.494 F25
G1 X113.087 Y185.184 Z0.49 F25
G1 X113.101 Y185.073 Z0.486 F25
G1 X113.123 Y184.964 Z0.482 F25
G1 X113.152 Y184.856 Z0.478 F25
G1 X113.189 Y184.751 Z0.474 F25
G1 X113.233 Y184.648 Z0.47 F25
G1 X113.284 Y184.549 Z0.466 F25
G1 X113.342 Y184.453 Z0.462 F25
G1 X113.406 Y184.362 Z0.458 F25
G1 X113.476 Y184.276 Z0.454 F25
G1 X113.553 Y184.195 Z0.45 F25
G1 X113.634 Y184.119 Z0.446 F25
G1 X113.721 Y184.049 Z0.442 F25
G1 X113.812 Y183.985 Z0.438 F25
G1 X113.908 Y183.928 Z0.434 F25
G1 X114.007 Y183.877 Z0.43 F25
G1 X114.11 Y183.834 Z0.426 F25
G1 X114.216 Y183.798 Z0.422 F25
G1 X114.323 Y183.769 Z0.418 F25
G1 X114.433 Y183.748 Z0.414 F25
G1 X114.543 Y183.734 Z0.41 F25
G1 X114.655 Y183.728 Z0.406 F25
G1 X114.766 Y183.73 Z0.402 F25
G1 X114.877 Y183.74 Z0.398 F25
G1 X114.987 Y183.757 Z0.394 F25
G1 X115.096 Y183.782 Z0.39 F25
G1 X115.202 Y183.814 Z0.386 F25
G1 X115.307 Y183.854 Z0.382 F25
G1 X115.408 Y183.901 Z0.378 F25
G1 X115.505 Y183.955 Z0.374 F25
G1 X115.599 Y184.015 Z0.37 F25
G1 X115.688 Y184.082 Z0.366 F25
G1 X115.772 Y184.155 Z0.362 F25
G1 X115.852 Y184.234 Z0.358 F25
G1 X115.925 Y184.317 Z0.354 F25
G1 X115.992 Y184.406 Z0.35 F25
G1 X116.054 Y184.499 Z0.346 F25
G1 X116.108 Y184.597 Z0.342 F25
G1 X116.155 Y184.697 Z0.338 F25
G1 X116.196 Y184.801 Z0.334 F25
G1 X116.229 Y184.907 Z0.33 F25
G1 X116.255 Y185.016 Z0.326 F25
G1 X116.273 Y185.125 Z0.322 F25
G1 X116.283 Y185.236 Z0.318 F25
G1 X116.286 Y185.348 Z0.315 F25
G1 X116.281 Y185.459 Z0.311 F25
G1 X116.268 Y185.569 Z0.307 F25
G1 X116.247 Y185.679 Z0.303 F25
G1 X116.219 Y185.786 Z0.299 F25
G1 X116.184 Y185.892 Z0.295 F25
G1 X116.141 Y185.995 Z0.291 F25
G1 X116.091 Y186.094 Z0.287 F25
G1 X116.035 Y186.19 Z0.283 F25
G1 X115.972 Y186.282 Z0.279 F25
G1 X115.903 Y186.369 Z0.275 F25
G1 X115.827 Y186.451 Z0.271 F25
G1 X115.747 Y186.528 Z0.267 F25
G1 X115.661 Y186.599 Z0.263 F25
G1 X115.57 Y186.664 Z0.259 F25
G1 X115.476 Y186.722 Z0.255 F25
G1 X115.377 Y186.774 Z0.251 F25
G1 X115.275 Y186.818 Z0.247 F25
G1 X115.17 Y186.856 Z0.243 F25
G1 X115.063 Y186.886 Z0.239 F25
G1 X114.954 Y186.908 Z0.235 F25
G1 X114.844 Y186.923 Z0.231 F25
G1 X114.733 Y186.93 Z0.227 F25
G1 X114.621 Z0.223 F25
G1 X114.511 Y186.921 Z0.219 F25
G1 X114.401 Y186.905 Z0.215 F25
G1 X114.292 Y186.882 Z0.211 F25
G1 X114.185 Y186.851 Z0.207 F25
G1 X114.081 Y186.812 Z0.203 F25
G1 X113.979 Y186.767 Z0.199 F25
G1 X113.881 Y186.714 Z0.195 F25
G1 X113.787 Y186.655 Z0.191 F25
G1 X113.697 Y186.589 Z0.187 F25
G1 X113.612 Y186.518 Z0.183 F25
G1 X113.533 Y186.44 Z0.179 F25
G1 X113.458 Y186.358 Z0.175 F25
G1 X113.39 Y186.27 Z0.171 F25
G1 X113.328 Y186.178 Z0.167 F25
G1 X113.273 Y186.081 Z0.163 F25
G1 X113.224 Y185.981 Z0.159 F25
G1 X113.182 Y185.878 Z0.155 F25
G1 X113.148 Y185.773 Z0.151 F25
G1 X113.121 Y185.665 Z0.147 F25
G1 X113.102 Y185.555 Z0.143 F25
G1 X113.09 Y185.445 Z0.139 F25
G1 X113.086 Y185.333 Z0.135 F25
G1 X113.09 Y185.222 Z0.131 F25
G1 X113.101 Y185.112 Z0.127 F25
G1 X113.12 Y185.002 Z0.123 F25
G1 X113.147 Y184.894 Z0.119 F25
G1 X113.181 Y184.789 Z0.115 F25
G1 X113.223 Y184.685 Z0.111 F25
G1 X113.271 Y184.586 Z0.107 F25
G1 X113.326 Y184.489 Z0.104 F25
G1 X113.388 Y184.397 Z0.1 F25
G1 X113.456 Y184.309 Z0.096 F25
G1 X113.53 Y184.226 Z0.092 F25
G1 X113.61 Y184.149 Z0.088 F25
G1 X113.694 Y184.077 Z0.084 F25
G1 X113.784 Y184.012 Z0.08 F25
G1 X113.878 Y183.952 Z0.076 F25
G1 X113.976 Y183.9 Z0.072 F25
G1 X114.077 Y183.854 Z0.068 F25
G1 X114.181 Y183.815 Z0.064 F25
G1 X114.287 Y183.784 Z0.06 F25
G1 X114.396 Y183.76 Z0.056 F25
G1 X114.506 Y183.744 Z0.052 F25
G1 X114.617 Y183.736 Z0.048 F25
G1 X114.728 Y183.735 Z0.044 F25
G1 X114.838 Y183.742 Z0.04 F25
G1 X114.948 Y183.757 Z0.036 F25
G1 X115.057 Y183.779 Z0.032 F25
G1 X115.164 Y183.809 Z0.028 F25
G1 X115.269 Y183.846 Z0.024 F25
G1 X115.371 Y183.89 Z0.02 F25
G1 X115.469 Y183.941 Z0.016 F25
G1 X115.564 Y183.999 Z0.012 F25
G1 X115.654 Y184.064 Z0.008 F25
G1 X115.74 Y184.134 Z0.004 F25
G1 X115.821 Y184.21 Z0 F25
G1 X115.896 Y184.292 Z-0.004 F25
G1 X115.965 Y184.379 Z-0.008 F25
G1 X116.028 Y184.47 Z-0.012 F25
G1 X116.084 Y184.566 Z-0.016 F25
G1 X116.134 Y184.665 Z-0.02 F25
G1 X116.177 Y184.767 Z-0.024 F25
G1 X116.212 Y184.872 Z-0.028 F25
G1 X116.241 Y184.979 Z-0.032 F25
G1 X116.261 Y185.088 Z-0.036 F25
G1 X116.274 Y185.198 Z-0.04 F25
G1 X116.279 Y185.309 Z-0.044 F25
G1 X116.277 Y185.42 Z-0.048 F25
G1 X116.267 Y185.531 Z-0.052 F25
G1 X116.249 Y185.64 Z-0.056 F25
G1 X116.224 Y185.748 Z-0.06 F25
G1 X116.191 Y185.854 Z-0.064 F25
G1 X116.151 Y185.957 Z-0.068 F25
G1 X116.104 Y186.058 Z-0.072 F25
G1 X116.05 Y186.155 Z-0.076 F25
G1 X115.989 Y186.247 Z-0.08 F25
G1 X115.922 Y186.336 Z-0.084 F25
G1 X115.849 Y186.419 Z-0.088 F25
G1 X115.771 Y186.498 Z-0.092 F25
G1 X115.687 Y186.57 Z-0.096 F25
G1 X115.598 Y186.637 Z-0.1 F25
G1 X115.505 Y186.697 Z-0.104 F25
G1 X115.408 Y186.751 Z-0.107 F25
G1 X115.308 Y186.798 Z-0.111 F25
G1 X115.204 Y186.838 Z-0.115 F25
G1 X115.098 Y186.87 Z-0.119 F25
G1 X114.99 Y186.895 Z-0.123 F25
G1 X114.881 Y186.913 Z-0.127 F25
G1 X114.771 Y186.922 Z-0.131 F25
G1 X114.66 Y186.924 Z-0.135 F25
G1 X114.549 Y186.919 Z-0.139 F25
G1 X114.439 Y186.906 Z-0.143 F25
G1 X114.331 Y186.885 Z-0.147 F25
G1 X114.224 Y186.856 Z-0.151 F25
G1 X114.119 Y186.821 Z-0.155 F25
G1 X114.017 Y186.778 Z-0.159 F25
G1 X113.918 Y186.728 Z-0.163 F25
G1 X113.823 Y186.671 Z-0.167 F25
G1 X113.732 Y186.608 Z-0.171 F25
G1 X113.645 Y186.538 Z-0.175 F25
G1 X113.564 Y186.463 Z-0.179 F25
G1 X113.488 Y186.383 Z-0.183 F25
G1 X113.418 Y186.297 Z-0.187 F25
G1 X113.354 Y186.206 Z-0.191 F25
G1 X113.296 Y186.112 Z-0.195 F25
G1 X113.245 Y186.013 Z-0.199 F25
G1 X113.202 Y185.912 Z-0.203 F25
G1 X113.165 Y185.807 Z-0.207 F25
G1 X113.136 Y185.7 Z-0.211 F25
G1 X113.114 Y185.592 Z-0.215 F25
G1 X113.099 Y185.482 Z-0.219 F25
G1 X113.093 Y185.371 Z-0.223 F25
G1 X113.094 Y185.261 Z-0.227 F25
G1 X113.103 Y185.15 Z-0.231 F25
G1 X113.119 Y185.041 Z-0.235 F25
G1 X113.143 Y184.933 Z-0.239 F25
G1 X113.175 Y184.827 Z-0.243 F25
G1 X113.213 Y184.723 Z-0.247 F25
G1 X113.259 Y184.622 Z-0.251 F25
G1 X113.312 Y184.525 Z-0.255 F25
G1 X113.371 Y184.432 Z-0.259 F25
G1 X113.437 Y184.343 Z-0.263 F25
G1 X113.509 Y184.259 Z-0.267 F25
G1 X113.586 Y184.18 Z-0.271 F25
G1 X113.669 Y184.106 Z-0.275 F25
G1 X113.756 Y184.039 Z-0.279 F25
G1 X113.848 Y183.977 Z-0.283 F25
G1 X113.944 Y183.923 Z-0.287 F25
G1 X114.044 Y183.875 Z-0.291 F25
G1 X114.147 Y183.834 Z-0.295 F25
G1 X114.252 Y183.8 Z-0.299 F25
G1 X114.36 Y183.774 Z-0.303 F25
G1 X114.469 Y183.755 Z-0.307 F25
G1 X114.579 Y183.744 Z-0.311 F25
G1 X114.689 Y183.741 Z-0.315 F25
G1 X114.8 Y183.745 Z-0.318 F25
G1 X114.91 Y183.757 Z-0.322 F25
G1 X115.019 Y183.776 Z-0.326 F25
G1 X115.126 Y183.804 Z-0.33 F25
G1 X115.231 Y183.838 Z-0.334 F25
G1 X115.334 Y183.88 Z-0.338 F25
G1 X115.433 Y183.928 Z-0.342 F25
G1 X115.529 Y183.984 Z-0.346 F25
G1 X115.62 Y184.046 Z-0.35 F25
G1 X115.707 Y184.114 Z-0.354 F25
G1 X115.789 Y184.188 Z-0.358 F25
G1 X115.866 Y184.267 Z-0.362 F25
G1 X115.937 Y184.352 Z-0.366 F25
G1 X116.002 Y184.442 Z-0.37 F25
G1 X116.06 Y184.535 Z-0.374 F25
G1 X116.112 Y184.633 Z-0.378 F25
G1 X116.157 Y184.734 Z-0.382 F25
G1 X116.195 Y184.838 Z-0.386 F25
G1 X116.226 Y184.944 Z-0.39 F25
G1 X116.249 Y185.052 Z-0.394 F25
G1 X116.264 Y185.161 Z-0.398 F25
G1 X116.272 Y185.271 Z-0.402 F25
G1 Y185.382 Z-0.406 F25
G1 X116.265 Y185.492 Z-0.41 F25
G1 X116.25 Y185.601 Z-0.414 F25
G1 X116.227 Y185.71 Z-0.418 F25
G1 X116.197 Y185.816 Z-0.422 F25
G1 X116.16 Y185.92 Z-0.426 F25
G1 X116.115 Y186.021 Z-0.43 F25
G1 X116.064 Y186.119 Z-0.434 F25
G1 X116.005 Y186.213 Z-0.438 F25
G1 X115.941 Y186.302 Z-0.442 F25
G1 X115.87 Y186.387 Z-0.446 F25
G1 X115.794 Y186.467 Z-0.45 F25
G1 X115.712 Y186.541 Z-0.454 F25
G1 X115.625 Y186.61 Z-0.458 F25
G1 X115.534 Y186.672 Z-0.462 F25
G1 X115.439 Y186.728 Z-0.466 F25
G1 X115.34 Y186.777 Z-0.47 F25
G1 X115.238 Y186.819 Z-0.474 F25
G1 X115.133 Y186.854 Z-0.478 F25
G1 X115.027 Y186.881 Z-0.482 F25
G1 X114.918 Y186.901 Z-0.486 F25
G1 X114.808 Y186.914 Z-0.49 F25
G1 X114.698 Y186.918 Z-0.494 F25
G1 X114.588 Y186.915 Z-0.498 F25
G1 X114.478 Y186.905 Z-0.502 F25
G1 X114.369 Y186.887 Z-0.506 F25
G1 X114.262 Y186.861 Z-0.51 F25
G1 X114.157 Y186.828 Z-0.514 F25
G1 X114.054 Y186.787 Z-0.518 F25
G1 X113.954 Y186.74 Z-0.522 F25
G1 X113.858 Y186.686 Z-0.526 F25
G1 X113.766 Y186.625 Z-0.529 F25
G1 X113.678 Y186.558 Z-0.533 F25
G1 X113.596 Y186.485 Z-0.537 F25
G1 X113.518 Y186.407 Z-0.541 F25
G1 X113.446 Y186.323 Z-0.545 F25
G1 X113.38 Y186.234 Z-0.549 F25
G1 X113.321 Y186.141 Z-0.553 F25
G1 X113.268 Y186.045 Z-0.557 F25
G1 X113.222 Y185.944 Z-0.561 F25
G1 X113.183 Y185.841 Z-0.565 F25
G1 X113.151 Y185.736 Z-0.569 F25
G1 X113.126 Y185.628 Z-0.573 F25
G1 X113.11 Y185.519 Z-0.577 F25
G1 X113.1 Y185.409 Z-0.581 F25
G1 X113.099 Y185.299 Z-0.585 F25
G1 X113.105 Y185.189 Z-0.589 F25
G1 X113.119 Y185.079 Z-0.593 F25
G1 X113.14 Y184.971 Z-0.597 F25
G1 X113.169 Y184.865 Z-0.601 F25
G1 X113.205 Y184.761 Z-0.605 F25
G1 X113.248 Y184.66 Z-0.609 F25
G1 X113.298 Y184.561 Z-0.613 F25
G1 X113.355 Y184.467 Z-0.617 F25
G1 X113.419 Y184.377 Z-0.621 F25
G1 X113.488 Y184.291 Z-0.625 F25
G1 X113.563 Y184.211 Z-0.629 F25
G1 X113.644 Y184.136 Z-0.633 F25
G1 X113.729 Y184.066 Z-0.637 F25
G1 X113.82 Y184.003 Z-0.641 F25
G1 X113.914 Y183.946 Z-0.645 F25
G1 X114.012 Y183.896 Z-0.649 F25
G1 X114.114 Y183.853 Z-0.653 F25
G1 X114.218 Y183.817 Z-0.657 F25
G1 X114.324 Y183.788 Z-0.661 F25
G1 X114.432 Y183.767 Z-0.665 F25
G1 X114.542 Y183.753 Z-0.669 F25
G1 X114.652 Y183.747 Z-0.673 F25
G1 X114.762 Y183.749 Z-0.677 F25
G1 X114.872 Y183.758 Z-0.681 F25
G1 X114.981 Y183.775 Z-0.685 F25
G1 X115.088 Y183.799 Z-0.689 F25
G1 X115.194 Y183.831 Z-0.693 F25
G1 X115.296 Y183.87 Z-0.697 F25
G1 X115.396 Y183.916 Z-0.701 F25
G1 X115.493 Y183.969 Z-0.705 F25
G1 X115.585 Y184.029 Z-0.709 F25
G1 X115.674 Y184.095 Z-0.713 F25
G1 X115.757 Y184.166 Z-0.717 F25
G1 X115.835 Y184.244 Z-0.721 F25
G1 X115.908 Y184.326 Z-0.725 F25
G1 X115.975 Y184.414 Z-0.729 F25
G1 X116.035 Y184.506 Z-0.733 F25
G1 X116.089 Y184.602 Z-0.737 F25
G1 X116.137 Y184.701 Z-0.741 F25
G1 X116.177 Y184.804 Z-0.744 F25
G1 X116.21 Y184.909 Z-0.748 F25
G1 X116.235 Y185.016 Z-0.752 F25
G1 X116.253 Y185.124 Z-0.756 F25
G1 X116.264 Y185.234 Z-0.76 F25
G1 X116.267 Y185.344 Z-0.764 F25
G1 X116.262 Y185.454 Z-0.768 F25
G1 X116.25 Y185.563 Z-0.772 F25
G1 X116.23 Y185.671 Z-0.776 F25
G1 X116.202 Y185.778 Z-0.78 F25
G1 X116.167 Y185.882 Z-0.784 F25
G1 X116.125 Y185.984 Z-0.788 F25
G1 X116.076 Y186.083 Z-0.792 F25
G1 X116.021 Y186.178 Z-0.796 F25
G1 X115.959 Y186.268 Z-0.8 F25
G1 X115.89 Y186.355 Z-0.804 F25
G1 X115.816 Y186.436 Z-0.808 F25
G1 X115.737 Y186.512 Z-0.812 F25
G1 X115.652 Y186.582 Z-0.816 F25
G1 X115.563 Y186.646 Z-0.82 F25
G1 X115.469 Y186.704 Z-0.824 F25
G1 X115.372 Y186.755 Z-0.828 F25
G1 X115.271 Y186.799 Z-0.832 F25
G1 X115.168 Y186.837 Z-0.836 F25
G1 X115.062 Y186.867 Z-0.84 F25
G1 X114.955 Y186.889 Z-0.844 F25
G1 X114.846 Y186.904 Z-0.848 F25
G1 X114.736 Y186.911 Z-0.852 F25
G1 X114.626 Z-0.856 F25
G1 X114.516 Y186.903 Z-0.86 F25
G1 X114.408 Y186.887 Z-0.864 F25
G1 X114.3 Y186.864 Z-0.868 F25
G1 X114.195 Y186.834 Z-0.872 F25
G1 X114.091 Y186.796 Z-0.876 F25
G1 X113.991 Y186.751 Z-0.88 F25
G1 X113.894 Y186.7 Z-0.884 F25
G1 X113.801 Y186.641 Z-0.888 F25
G1 X113.712 Y186.577 Z-0.892 F25
G1 X113.628 Y186.506 Z-0.896 F25
G1 X113.549 Y186.43 Z-0.9 F25
G1 X113.475 Y186.348 Z-0.904 F25
G1 X113.407 Y186.261 Z-0.908 F25
G1 X113.346 Y186.17 Z-0.912 F25
G1 X113.291 Y186.075 Z-0.916 F25
G1 X113.242 Y185.976 Z-0.92 F25
G1 X113.201 Y185.875 Z-0.924 F25
G1 X113.167 Y185.77 Z-0.928 F25
G1 X113.14 Y185.664 Z-0.932 F25
G1 X113.121 Y185.556 Z-0.936 F25
G1 X113.109 Y185.447 Z-0.94 F25
G1 X113.105 Y185.337 Z-0.944 F25
G1 X113.108 Y185.227 Z-0.948 F25
G1 X113.119 Y185.118 Z-0.952 F25
G1 X113.138 Y185.01 Z-0.955 F25
G1 X113.164 Y184.903 Z-0.959 F25
G1 X113.198 Y184.799 Z-0.963 F25
G1 X113.238 Y184.697 Z-0.967 F25
G1 X113.286 Y184.598 Z-0.971 F25
G1 X113.34 Y184.502 Z-0.975 F25
G1 X113.401 Y184.411 Z-0.979 F25
G1 X113.468 Y184.324 Z-0.983 F25
G1 X113.541 Y184.242 Z-0.987 F25
G1 X113.62 Y184.165 Z-0.991 F25
G1 X113.703 Y184.094 Z-0.995 F25
G1 X113.792 Y184.029 Z-0.999 F25
G1 X113.884 Y183.97 Z-1.003 F25
G1 X113.981 Y183.918 Z-1.007 F25
G1 X114.081 Y183.873 Z-1.011 F25
G1 X114.184 Y183.834 Z-1.015 F25
G1 X114.289 Y183.803 Z-1.019 F25
G1 X114.396 Y183.779 Z-1.023 F25
G1 X114.505 Y183.763 Z-1.027 F25
G1 X114.614 Y183.755 Z-1.031 F25
G1 X114.724 Y183.754 Z-1.035 F25
G1 X114.834 Y183.76 Z-1.039 F25
G1 X114.942 Y183.774 Z-1.043 F25
G1 X115.05 Y183.796 Z-1.047 F25
G1 X115.155 Y183.825 Z-1.051 F25
G1 X115.259 Y183.862 Z-1.055 F25
G1 X115.36 Y183.905 Z-1.059 F25
G1 X115.457 Y183.956 Z-1.063 F25
G1 X115.551 Y184.013 Z-1.067 F25
G1 X115.64 Y184.076 Z-1.071 F25
G1 X115.725 Y184.146 Z-1.075 F25
G1 X115.805 Y184.221 Z-1.079 F25
G1 X115.879 Y184.301 Z-1.083 F25
G1 X115.948 Y184.387 Z-1.087 F25
G1 X116.01 Y184.477 Z-1.091 F25
G1 X116.066 Y184.571 Z-1.095 F25
G1 X116.115 Y184.669 Z-1.099 F25
G1 X116.158 Y184.77 Z-1.103 F25
G1 X116.193 Y184.874 Z-1.107 F25
G1 X116.221 Y184.98 Z-1.111 F25
G1 X116.242 Y185.088 Z-1.115 F25
G1 X116.255 Y185.197 Z-1.119 F25
G1 X116.26 Y185.306 Z-1.123 F25
G1 X116.258 Y185.416 Z-1.127 F25
G1 X116.248 Y185.525 Z-1.131 F25
G1 X116.231 Y185.633 Z-1.135 F25
G1 X116.206 Y185.74 Z-1.139 F25
G1 X116.174 Y185.845 Z-1.143 F25
G1 X116.135 Y185.947 Z-1.147 F25
G1 X116.088 Y186.046 Z-1.151 F25
G1 X116.035 Y186.142 Z-1.155 F25
G1 X115.976 Y186.234 Z-1.159 F25
G1 X115.91 Y186.322 Z-1.163 F25
G1 X115.838 Y186.404 Z-1.166 F25
G1 X115.76 Y186.482 Z-1.17 F25
G1 X115.678 Y186.554 Z-1.174 F25
G1 X115.591 Y186.62 Z-1.178 F25
G1 X115.499 Y186.679 Z-1.182 F25
G1 X115.403 Y186.733 Z-1.186 F25
G1 X115.304 Y186.779 Z-1.19 F25
G1 X115.202 Y186.819 Z-1.194 F25
G1 X115.097 Y186.851 Z-1.198 F25
G1 X114.991 Y186.876 Z-1.202 F25
G1 X114.882 Y186.893 Z-1.206 F25
G1 X114.773 Y186.903 Z-1.21 F25
G1 X114.664 Y186.906 Z-1.214 F25
G1 X114.555 Y186.9 Z-1.218 F25
G1 X114.446 Y186.887 Z-1.222 F25
G1 X114.338 Y186.867 Z-1.226 F25
G1 X114.232 Y186.839 Z-1.23 F25
G1 X114.129 Y186.804 Z-1.234 F25
G1 X114.028 Y186.762 Z-1.238 F25
G1 X113.93 Y186.713 Z-1.242 F25
G1 X113.836 Y186.657 Z-1.246 F25
G1 X113.746 Y186.594 Z-1.25 F25
G1 X113.66 Y186.526 Z-1.254 F25
G1 X113.579 Y186.452 Z-1.258 F25
G1 X113.504 Y186.372 Z-1.262 F25
G1 X113.435 Y186.288 Z-1.266 F25
G1 X113.371 Y186.199 Z-1.27 F25
G1 X113.314 Y186.105 Z-1.274 F25
G1 X113.264 Y186.008 Z-1.278 F25
G1 X113.22 Y185.908 Z-1.282 F25
G1 X113.184 Y185.805 Z-1.286 F25
G1 X113.155 Y185.699 Z-1.29 F25
G1 X113.133 Y185.592 Z-1.294 F25
G1 X113.118 Y185.484 Z-1.298 F25
G1 X113.112 Y185.375 Z-1.302 F25
G1 Y185.265 Z-1.306 F25
G1 X113.121 Y185.156 Z-1.31 F25
G1 X113.137 Y185.048 Z-1.314 F25
G1 X113.16 Y184.941 Z-1.318 F25
G1 X113.191 Y184.836 Z-1.322 F25
G1 X113.229 Y184.734 Z-1.326 F25
G1 X113.274 Y184.634 Z-1.33 F25
G1 X113.326 Y184.538 Z-1.334 F25
G1 X113.385 Y184.446 Z-1.338 F25
G1 X113.449 Y184.357 Z-1.342 F25
G1 X113.52 Y184.274 Z-1.346 F25
G1 X113.597 Y184.196 Z-1.35 F25
G1 X113.678 Y184.123 Z-1.354 F25
G1 X113.765 Y184.056 Z-1.358 F25
G1 X113.855 Y183.995 Z-1.362 F25
G1 X113.95 Y183.941 Z-1.366 F25
G1 X114.049 Y183.893 Z-1.37 F25
G1 X114.15 Y183.853 Z-1.374 F25
G1 X114.254 Y183.819 Z-1.377 F25
G1 X114.361 Y183.793 Z-1.381 F25
G1 X114.468 Y183.774 Z-1.385 F25
G1 X114.577 Y183.763 Z-1.389 F25
G1 X114.686 Y183.759 Z-1.393 F25
G1 X114.795 Y183.763 Z-1.397 F25
G1 X114.904 Y183.775 Z-1.401 F25
G1 X115.012 Y183.794 Z-1.405 F25
G1 X115.117 Y183.82 Z-1.409 F25
G1 X115.221 Y183.854 Z-1.413 F25
G1 X115.323 Y183.895 Z-1.417 F25
G1 X115.421 Y183.943 Z-1.421 F25
G1 X115.515 Y183.998 Z-1.425 F25
G1 X115.606 Y184.059 Z-1.429 F25
G1 X115.692 Y184.126 Z-1.433 F25
G1 X115.773 Y184.199 Z-1.437 F25
G1 X115.849 Y184.277 Z-1.441 F25
G1 X115.92 Y184.361 Z-1.445 F25
G1 X115.984 Y184.449 Z-1.449 F25
G1 X116.042 Y184.542 Z-1.453 F25
G1 X116.094 Y184.638 Z-1.457 F25
G1 X116.138 Y184.738 Z-1.461 F25
G1 X116.176 Y184.84 Z-1.465 F25
G1 X116.206 Y184.945 Z-1.469 F25
G1 X116.229 Y185.052 Z-1.473 F25
G1 X116.245 Y185.16 Z-1.477 F25
G1 X116.253 Y185.269 Z-1.481 F25
G1 X116.254 Y185.378 Z-1.485 F25
G1 X116.246 Y185.487 Z-1.489 F25
G1 X116.232 Y185.595 Z-1.493 F25
G1 X116.21 Y185.702 Z-1.497 F25
G1 X116.18 Y185.807 Z-1.501 F25
G1 X116.143 Y185.91 Z-1.505 F25
G1 X116.1 Y186.01 Z-1.509 F25
G1 X116.049 Y186.107 Z-1.513 F25
G1 X115.992 Y186.199 Z-1.517 F25
G1 X115.928 Y186.288 Z-1.521 F25
G1 X115.859 Y186.372 Z-1.525 F25
G1 X115.783 Y186.451 Z-1.529 F25
G1 X115.703 Y186.525 Z-1.533 F25
G1 X115.617 Y186.593 Z-1.537 F25
G1 X115.528 Y186.654 Z-1.541 F25
G1 X115.434 Y186.71 Z-1.545 F25
G1 X115.336 Y186.758 Z-1.549 F25
G1 X115.235 Y186.8 Z-1.553 F25
G1 X115.132 Y186.835 Z-1.557 F25
G1 X115.026 Y186.862 Z-1.561 F25
G1 X114.919 Y186.882 Z-1.565 F25
G1 X114.81 Y186.894 Z-1.569 F25
G1 X114.702 Y186.899 Z-1.573 F25
G1 X114.592 Y186.897 Z-1.577 F25
G1 X114.484 Y186.886 Z-1.581 F25
G1 X114.376 Y186.869 Z-1.585 F25
G1 X114.27 Y186.843 Z-1.588 F25
G1 X114.166 Y186.811 Z-1.592 F25
G1 X114.064 Y186.771 Z-1.596 F25
G1 X113.966 Y186.725 Z-1.6 F25
G1 X113.871 Y186.671 Z-1.604 F25
G1 X113.779 Y186.611 Z-1.608 F25
G1 X113.693 Y186.545 Z-1.612 F25
G1 X113.611 Y186.473 Z-1.616 F25
G1 X113.534 Y186.396 Z-1.62 F25
G1 X113.463 Y186.314 Z-1.624 F25
G1 X113.398 Y186.226 Z-1.628 F25
G1 X113.339 Y186.135 Z-1.632 F25
G1 X113.286 Y186.039 Z-1.636 F25
G1 X113.24 Y185.94 Z-1.64 F25
G1 X113.201 Y185.839 Z-1.644 F25
G1 X113.17 Y185.734 Z-1.648 F25
G1 X113.146 Y185.628 Z-1.652 F25
G1 X113.129 Y185.521 Z-1.656 F25
G1 X113.119 Y185.412 Z-1.66 F25
G1 X113.118 Y185.303 Z-1.664 F25
G1 X113.123 Y185.194 Z-1.668 F25
G1 X113.137 Y185.086 Z-1.672 F25
G1 X113.158 Y184.979 Z-1.676 F25
G1 X113.186 Y184.874 Z-1.68 F25
G1 X113.221 Y184.771 Z-1.684 F25
G1 X113.264 Y184.671 Z-1.688 F25
G1 X113.313 Y184.574 Z-1.692 F25
G1 X113.369 Y184.48 Z-1.696 F25
G1 X113.432 Y184.391 Z-1.7 F25
G1 X113.5 Y184.306 Z-1.704 F25
G1 X113.574 Y184.226 Z-1.708 F25
G1 X113.654 Y184.152 Z-1.712 F25
G1 X113.738 Y184.083 Z-1.716 F25
G1 X113.827 Y184.02 Z-1.72 F25
G1 X113.921 Y183.964 Z-1.724 F25
G1 X114.017 Y183.914 Z-1.728 F25
G1 X114.118 Y183.871 Z-1.732 F25
G1 X114.22 Y183.836 Z-1.736 F25
G1 X114.325 Y183.807 Z-1.74 F25
G1 X114.432 Y183.786 Z-1.744 F25
G1 X114.54 Y183.772 Z-1.748 F25
G1 X114.649 Y183.766 Z-1.752 F25
G1 X114.757 Y183.767 Z-1.756 F25
G1 X114.866 Y183.776 Z-1.76 F25
G1 X114.973 Y183.793 Z-1.764 F25
G1 X115.08 Y183.817 Z-1.768 F25
G1 X115.184 Y183.848 Z-1.772 F25
G1 X115.286 Y183.886 Z-1.776 F25
G1 X115.384 Y183.931 Z-1.78 F25
G1 X115.48 Y183.984 Z-1.784 F25
G1 X115.572 Y184.042 Z-1.788 F25
G1 X115.659 Y184.107 Z-1.792 F25
G1 X115.742 Y184.178 Z-1.796 F25
G1 X115.819 Y184.254 Z-1.799 F25
G1 X115.891 Y184.336 Z-1.803 F25
G1 X115.957 Y184.422 Z-1.807 F25
G1 X116.017 Y184.513 Z-1.811 F25
G1 X116.071 Y184.607 Z-1.815 F25
G1 X116.118 Y184.706 Z-1.819 F25
G1 X116.158 Y184.807 Z-1.823 F25
G1 X116.191 Y184.911 Z-1.827 F25
G1 X116.216 Y185.016 Z-1.831 F25
G1 X116.234 Y185.124 Z-1.835 F25
G1 X116.245 Y185.232 Z-1.839 F25
G1 X116.248 Y185.341 Z-1.843 F25
G1 X116.244 Y185.449 Z-1.847 F25
G1 X116.231 Y185.557 Z-1.851 F25
G1 X116.212 Y185.664 Z-1.855 F25
G1 X116.185 Y185.769 Z-1.859 F25
G1 X116.151 Y185.873 Z-1.863 F25
G1 X116.11 Y185.973 Z-1.867 F25
G1 X116.062 Y186.071 Z-1.871 F25
G1 X116.007 Y186.164 Z-1.875 F25
G1 X115.946 Y186.254 Z-1.879 F25
G1 X115.878 Y186.34 Z-1.883 F25
G1 X115.805 Y186.42 Z-1.887 F25
G1 X115.727 Y186.495 Z-1.891 F25
G1 X115.644 Y186.565 Z-1.895 F25
G1 X115.555 Y186.628 Z-1.899 F25
G1 X115.463 Y186.686 Z-1.903 F25
G1 X115.367 Y186.737 Z-1.907 F25
G1 X115.268 Y186.781 Z-1.911 F25
G1 X115.166 Y186.818 Z-1.915 F25
G1 X115.061 Y186.847 Z-1.919 F25
G1 X114.955 Y186.87 Z-1.923 F25
G1 X114.847 Y186.885 Z-1.927 F25
G1 X114.739 Y186.892 Z-1.931 F25
G1 X114.63 Z-1.935 F25
G1 X114.522 Y186.885 Z-1.939 F25
G1 X114.414 Y186.869 Z-1.943 F25
G1 X114.308 Y186.847 Z-1.947 F25
G1 X114.203 Y186.817 Z-1.951 F25
G1 X114.101 Y186.78 Z-1.955 F25
G1 X114.002 Y186.736 Z-1.959 F25
G1 X113.906 Y186.685 Z-1.963 F25
G1 X113.814 Y186.627 Z-1.967 F25
G1 X113.726 Y186.564 Z-1.971 F25
G1 X113.643 Y186.494 Z-1.975 F25
G1 X113.564 Y186.419 Z-1.979 F25
G1 X113.492 Y186.339 Z-1.983 F25
G1 X113.424 Y186.253 Z-1.987 F25
G1 X113.363 Y186.164 Z-1.991 F25
G1 X113.309 Y186.07 Z-1.995 F25
G1 X113.261 Y185.972 Z-1.999 F25
G1 X113.22 Y185.872 Z-2.003 F25
G1 X113.186 Y185.769 Z-2.007 F25
G1 X113.159 Y185.664 Z-2.011 F25
G1 X113.14 Y185.557 Z-2.014 F25
G1 X113.128 Y185.449 Z-2.018 F25
G1 X113.124 Y185.341 Z-2.022 F25
G1 X113.127 Y185.232 Z-2.026 F25
G1 X113.138 Y185.124 Z-2.03 F25
G1 X113.156 Y185.017 Z-2.034 F25
G1 X113.181 Y184.912 Z-2.038 F25
G1 X113.214 Y184.808 Z-2.042 F25
G1 X113.254 Y184.707 Z-2.046 F25
G1 X113.301 Y184.609 Z-2.05 F25
G1 X113.355 Y184.515 Z-2.054 F25
G1 X113.415 Y184.425 Z-2.058 F25
G1 X113.481 Y184.339 Z-2.062 F25
G1 X113.553 Y184.257 Z-2.066 F25
G1 X113.63 Y184.181 Z-2.07 F25
G1 X113.713 Y184.111 Z-2.074 F25
G1 X113.8 Y184.046 Z-2.078 F25
G1 X113.891 Y183.988 Z-2.082 F25
G1 X113.986 Y183.936 Z-2.086 F25
G1 X114.085 Y183.891 Z-2.09 F25
G1 X114.187 Y183.853 Z-2.094 F25
G1 X114.29 Y183.822 Z-2.098 F25
G1 X114.396 Y183.799 Z-2.102 F25
G1 X114.503 Y183.782 Z-2.106 F25
G1 X114.611 Y183.774 Z-2.11 F25
G1 X114.72 Y183.772 Z-2.114 F25
G1 X114.828 Y183.779 Z-2.118 F25
G1 X114.935 Y183.792 Z-2.122 F25
G1 X115.042 Y183.814 Z-2.126 F25
G1 X115.146 Y183.842 Z-2.13 F25
G1 X115.249 Y183.878 Z-2.134 F25
G1 X115.348 Y183.921 Z-2.138 F25
G1 X115.444 Y183.97 Z-2.142 F25
G1 X115.537 Y184.027 Z-2.146 F25
G1 X115.626 Y184.089 Z-2.15 F25
G1 X115.71 Y184.158 Z-2.154 F25
G1 X115.789 Y184.232 Z-2.158 F25
G1 X115.862 Y184.311 Z-2.162 F25
G1 X115.93 Y184.396 Z-2.166 F25
G1 X115.992 Y184.485 Z-2.17 F25
G1 X116.048 Y184.578 Z-2.174 F25
G1 X116.097 Y184.674 Z-2.178 F25
G1 X116.139 Y184.774 Z-2.182 F25
G1 X116.174 Y184.877 Z-2.186 F25
G1 X116.202 Y184.981 Z-2.19 F25
G1 X116.223 Y185.088 Z-2.194 F25
G1 X116.236 Y185.195 Z-2.198 F25
G1 X116.242 Y185.303 Z-2.202 F25
G1 X116.24 Y185.411 Z-2.206 F25
G1 X116.23 Y185.519 Z-2.21 F25
G1 X116.213 Y185.626 Z-2.214 F25
G1 X116.189 Y185.732 Z-2.218 F25
G1 X116.158 Y185.835 Z-2.222 F25
G1 X116.119 Y185.936 Z-2.225 F25
G1 X116.073 Y186.035 Z-2.229 F25
G1 X116.021 Y186.129 Z-2.233 F25
G1 X115.962 Y186.22 Z-2.237 F25
G1 X115.897 Y186.307 Z-2.241 F25
G1 X115.827 Y186.389 Z-2.245 F25
G1 X115.75 Y186.465 Z-2.249 F25
G1 X115.669 Y186.537 Z-2.253 F25
G1 X115.583 Y186.602 Z-2.257 F25
G1 X115.492 Y186.661 Z-2.261 F25
G1 X115.398 Y186.714 Z-2.265 F25
G1 X115.3 Y186.76 Z-2.269 F25
G1 X115.199 Y186.8 Z-2.273 F25
G1 X115.095 Y186.832 Z-2.277 F25
G1 X114.99 Y186.857 Z-2.281 F25
G1 X114.883 Y186.874 Z-2.285 F25
G1 X114.776 Y186.884 Z-2.289 F25
G1 X114.667 Y186.887 Z-2.293 F25
G1 X114.559 Y186.882 Z-2.297 F25
G1 X114.452 Y186.869 Z-2.301 F25
G1 X114.345 Y186.849 Z-2.305 F25
G1 X114.241 Y186.822 Z-2.309 F25
G1 X114.138 Y186.788 Z-2.313 F25
G1 X114.038 Y186.746 Z-2.317 F25
G1 X113.942 Y186.698 Z-2.321 F25
G1 X113.848 Y186.643 Z-2.325 F25
G1 X113.759 Y186.582 Z-2.329 F25
G1 X113.675 Y186.514 Z-2.333 F25
G1 X113.595 Y186.441 Z-2.337 F25
G1 X113.521 Y186.363 Z-2.341 F25
G1 X113.452 Y186.279 Z-2.345 F25
G1 X113.389 Y186.191 Z-2.349 F25
G1 X113.332 Y186.099 Z-2.353 F25
G1 X113.282 Y186.004 Z-2.357 F25
G1 X113.239 Y185.904 Z-2.361 F25
G1 X113.203 Y185.803 Z-2.365 F25
G1 X113.174 Y185.699 Z-2.369 F25
G1 X113.152 Y185.593 Z-2.373 F25
G1 X113.138 Y185.486 Z-2.377 F25
G1 X113.131 Y185.378 Z-2.381 F25
G1 Y185.27 Z-2.385 F25
G1 X113.139 Y185.162 Z-2.389 F25
G1 X113.155 Y185.055 Z-2.393 F25
G1 X113.178 Y184.949 Z-2.397 F25
G1 X113.208 Y184.845 Z-2.401 F25
G1 X113.246 Y184.744 Z-2.405 F25
G1 X113.29 Y184.645 Z-2.409 F25
G1 X113.341 Y184.55 Z-2.413 F25
G1 X113.399 Y184.459 Z-2.417 F25
G1 X113.462 Y184.371 Z-2.421 F25
G1 X113.532 Y184.289 Z-2.425 F25
G1 X113.607 Y184.211 Z-2.429 F25
G1 X113.688 Y184.139 Z-2.433 F25
G1 X113.773 Y184.073 Z-2.436 F25
G1 X113.863 Y184.013 Z-2.44 F25
G1 X113.956 Y183.959 Z-2.444 F25
G1 X114.053 Y183.912 Z-2.448 F25
G1 X114.153 Y183.871 Z-2.452 F25
G1 X114.256 Y183.838 Z-2.456 F25
G1 X114.361 Y183.812 Z-2.46 F25
G1 X114.467 Y183.793 Z-2.464 F25
G1 X114.574 Y183.782 Z-2.468 F25
G1 X114.682 Y183.778 Z-2.472 F25
G1 X114.79 Y183.782 Z-2.476 F25
G1 X114.898 Y183.793 Z-2.48 F25
G1 X115.004 Y183.812 Z-2.484 F25
G1 X115.109 Y183.838 Z-2.488 F25
G1 X115.211 Y183.871 Z-2.492 F25
G1 X115.312 Y183.911 Z-2.496 F25
G1 X115.409 Y183.958 Z-2.5 F25
G1 X115.502 Y184.012 Z-2.504 F25
G1 X115.592 Y184.072 Z-2.508 F25
G1 X115.677 Y184.138 Z-2.512 F25
G1 X115.758 Y184.21 Z-2.516 F25
G1 X115.833 Y184.288 Z-2.52 F25
G1 X115.903 Y184.37 Z-2.524 F25
G1 X115.967 Y184.457 Z-2.528 F25
G1 X116.024 Y184.548 Z-2.532 F25
G1 X116.075 Y184.644 Z-2.536 F25
G1 X116.12 Y184.742 Z-2.54 F25
G1 X116.157 Y184.843 Z-2.544 F25
G1 X116.187 Y184.947 Z-2.548 F25
G1 X116.21 Y185.052 Z-2.552 F25
G1 X116.226 Y185.159 Z-2.556 F25
G1 X116.234 Y185.266 Z-2.56 F25
G1 X116.235 Y185.374 Z-2.564 F25
G1 X116.228 Y185.482 Z-2.568 F25
G1 X116.214 Y185.588 Z-2.572 F25
G1 X116.192 Y185.694 Z-2.576 F25
G1 X116.163 Y185.798 Z-2.58 F25
G1 X116.127 Y185.899 Z-2.584 F25
G1 X116.084 Y185.998 Z-2.588 F25
G1 X116.034 Y186.094 Z-2.592 F25
G1 X115.978 Y186.186 Z-2.596 F25
G1 X115.915 Y186.274 Z-2.6 F25
G1 X115.847 Y186.357 Z-2.604 F25
G1 X115.773 Y186.435 Z-2.608 F25
G1 X115.693 Y186.508 Z-2.612 F25
G1 X115.609 Y186.575 Z-2.616 F25
G1 X115.52 Y186.636 Z-2.62 F25
G1 X115.427 Y186.691 Z-2.624 F25
G1 X115.331 Y186.74 Z-2.628 F25
G1 X115.231 Y186.781 Z-2.632 F25
G1 X115.129 Y186.816 Z-2.636 F25
G1 X115.025 Y186.843 Z-2.64 F25
G1 X114.919 Y186.863 Z-2.644 F25
G1 X114.812 Y186.875 Z-2.647 F25
G1 X114.704 Y186.881 Z-2.651 F25
G1 X114.596 Y186.878 Z-2.655 F25
G1 X114.489 Y186.868 Z-2.659 F25
G1 X114.383 Y186.851 Z-2.663 F25
G1 X114.278 Y186.826 Z-2.667 F25
G1 X114.175 Y186.794 Z-2.671 F25
G1 X114.075 Y186.755 Z-2.675 F25
G1 X113.977 Y186.71 Z-2.679 F25
G1 X113.883 Y186.657 Z-2.683 F25
G1 X113.793 Y186.598 Z-2.687 F25
G1 X113.707 Y186.533 Z-2.691 F25
G1 X113.626 Y186.462 Z-2.695 F25
G1 X113.55 Y186.386 Z-2.699 F25
G1 X113.48 Y186.305 Z-2.703 F25
G1 X113.415 Y186.219 Z-2.707 F25
G1 X113.357 Y186.128 Z-2.711 F25
G1 X113.305 Y186.034 Z-2.715 F25
G1 X113.259 Y185.936 Z-2.719 F25
G1 X113.221 Y185.836 Z-2.723 F25
G1 X113.189 Y185.733 Z-2.727 F25
G1 X113.165 Y185.628 Z-2.731 F25
G1 X113.148 Y185.522 Z-2.735 F25
G1 X113.138 Y185.414 Z-2.739 F25
G1 X113.136 Y185.307 Z-2.743 F25
G1 X113.142 Y185.199 Z-2.747 F25
G1 X113.155 Y185.092 Z-2.751 F25
G1 X113.175 Y184.987 Z-2.755 F25
G1 X113.203 Y184.882 Z-2.759 F25
G1 X113.238 Y184.781 Z-2.763 F25
G1 X113.28 Y184.681 Z-2.767 F25
G1 X113.328 Y184.585 Z-2.771 F25
G1 X113.383 Y184.493 Z-2.775 F25
G1 X113.445 Y184.405 Z-2.779 F25
G1 X113.512 Y184.321 Z-2.783 F25
G1 X113.585 Y184.242 Z-2.787 F25
G1 X113.663 Y184.168 Z-2.791 F25
G1 X113.747 Y184.1 Z-2.795 F25
G1 X113.835 Y184.038 Z-2.799 F25
G1 X113.926 Y183.982 Z-2.803 F25
G1 X114.022 Y183.933 Z-2.807 F25
G1 X114.121 Y183.89 Z-2.811 F25
G1 X114.222 Y183.855 Z-2.815 F25
G1 X114.326 Y183.826 Z-2.819 F25
G1 X114.431 Y183.805 Z-2.823 F25
G1 X114.538 Y183.791 Z-2.827 F25
G1 X114.645 Y183.785 Z-2.831 F25
G1 X114.753 Y183.786 Z-2.835 F25
G1 X114.86 Y183.795 Z-2.839 F25
G1 X114.966 Y183.811 Z-2.843 F25
G1 X115.071 Y183.834 Z-2.847 F25
G1 X115.174 Y183.865 Z-2.851 F25
G1 X115.275 Y183.902 Z-2.855 F25
G1 X115.373 Y183.947 Z-2.858 F25
G1 X115.468 Y183.998 Z-2.862 F25
G1 X115.558 Y184.056 Z-2.866 F25
G1 X115.645 Y184.12 Z-2.87 F25
G1 X115.727 Y184.19 Z-2.874 F25
G1 X115.803 Y184.265 Z-2.878 F25
G1 X115.875 Y184.345 Z-2.882 F25
G1 X115.94 Y184.431 Z-2.886 F25
G1 X116 Y184.52 Z-2.89 F25
G1 X116.053 Y184.613 Z-2.894 F25
G1 X116.1 Y184.71 Z-2.898 F25
G1 X116.139 Y184.81 Z-2.902 F25
G1 X116.172 Y184.912 Z-2.906 F25
G1 X116.197 Y185.017 Z-2.91 F25
G1 X116.215 Y185.122 Z-2.914 F25
G1 X116.226 Y185.229 Z-2.918 F25
G1 X116.229 Y185.337 Z-2.922 F25
G1 X116.225 Y185.444 Z-2.926 F25
G1 X116.213 Y185.551 Z-2.93 F25
G1 X116.194 Y185.656 Z-2.934 F25
G1 X116.168 Y185.761 Z-2.938 F25
G1 X116.135 Y185.863 Z-2.942 F25
G1 X116.094 Y185.962 Z-2.946 F25
G1 X116.047 Y186.058 Z-2.95 F25
G1 X115.993 Y186.151 Z-2.954 F25
G1 X115.932 Y186.24 Z-2.958 F25
G1 X115.866 Y186.325 Z-2.962 F25
G1 X115.794 Y186.404 Z-2.966 F25
G1 X115.717 Y186.479 Z-2.97 F25
G1 X115.635 Y186.548 Z-2.974 F25
G1 X115.548 Y186.611 Z-2.978 F25
G1 X115.456 Y186.668 Z-2.982 F25
G1 X115.362 Y186.718 Z-2.986 F25
G1 X115.264 Y186.762 Z-2.99 F25
G1 X115.163 Y186.799 Z-2.994 F25
G1 X115.059 Y186.828 Z-2.998 F25
G1 X114.954 Y186.851 Z-3.002 F25
G1 X114.848 Y186.866 Z-3.006 F25
G1 X114.741 Y186.873 Z-3.01 F25
G1 X114.634 Y186.874 Z-3.014 F25
G1 X114.527 Y186.866 Z-3.018 F25
G1 X114.421 Y186.852 Z-3.022 F25
G1 X114.316 Y186.83 Z-3.026 F25
G1 X114.212 Y186.8 Z-3.03 F25
G1 X114.112 Y186.764 Z-3.034 F25
G1 X114.013 Y186.721 Z-3.038 F25
G1 X113.919 Y186.671 Z-3.042 F25
G1 X113.827 Y186.614 Z-3.046 F25
G1 X113.74 Y186.551 Z-3.05 F25
G1 X113.658 Y186.483 Z-3.054 F25
G1 X113.58 Y186.409 Z-3.058 F25
G1 X113.508 Y186.329 Z-3.062 F25
G1 X113.442 Y186.245 Z-3.066 F25
G1 X113.381 Y186.156 Z-3.069 F25
G1 X113.327 Y186.064 Z-3.073 F25
G1 X113.28 Y185.968 Z-3.077 F25
G1 X113.239 Y185.868 Z-3.081 F25
G1 X113.205 Y185.767 Z-3.085 F25
G1 X113.178 Y185.663 Z-3.089 F25
G1 X113.159 Y185.557 Z-3.093 F25
G1 X113.147 Y185.451 Z-3.097 F25
G1 X113.143 Y185.344 Z-3.101 F25
G1 X113.146 Y185.236 Z-3.105 F25
G1 X113.156 Y185.13 Z-3.109 F25
G1 X113.174 Y185.024 Z-3.113 F25
G1 X113.199 Y184.92 Z-3.117 F25
G1 X113.232 Y184.814 Z-3.121 F25
G1 X113.273 Y184.711 Z-3.126 F25
G1 X113.322 Y184.611 Z-3.13 F25
G1 X113.377 Y184.515 Z-3.134 F25
G1 X113.439 Y184.423 Z-3.138 F25
G1 X113.508 Y184.336 Z-3.142 F25
G1 X113.582 Y184.254 Z-3.146 F25
G1 X113.663 Y184.177 Z-3.15 F25
G1 X113.749 Y184.107 Z-3.154 F25
G1 X113.839 Y184.043 Z-3.159 F25
G1 X113.934 Y183.985 Z-3.163 F25
G1 X114.033 Y183.935 Z-3.167 F25
G1 X114.135 Y183.892 Z-3.171 F25
G1 X114.24 Y183.856 Z-3.175 F25
G1 X114.347 Y183.828 Z-3.179 F25
G1 X114.456 Y183.808 Z-3.183 F25
G1 X114.567 Y183.795 Z-3.187 F25
G1 X114.678 Y183.791 Z-3.191 F25
G1 X114.788 Y183.794 Z-3.196 F25
G1 X114.899 Y183.806 Z-3.2 F25
G1 X115.008 Y183.825 Z-3.204 F25
G1 X115.116 Y183.853 Z-3.208 F25
G1 X115.221 Y183.888 Z-3.212 F25
G1 X115.323 Y183.93 Z-3.216 F25
G1 X115.423 Y183.98 Z-3.22 F25
G1 X115.518 Y184.037 Z-3.224 F25
G1 X115.609 Y184.1 Z-3.229 F25
G1 X115.695 Y184.17 Z-3.233 F25
G1 X115.776 Y184.246 Z-3.237 F25
G1 X115.851 Y184.327 Z-3.241 F25
G1 X115.92 Y184.414 Z-3.245 F25
G1 X115.983 Y184.505 Z-3.249 F25
G1 X116.039 Y184.6 Z-3.253 F25
G1 X116.088 Y184.7 Z-3.257 F25
G1 X116.13 Y184.802 Z-3.262 F25
G1 X116.164 Y184.908 Z-3.266 F25
G1 X116.191 Y185.015 Z-3.27 F25
G1 X116.209 Y185.125 Z-3.274 F25
G1 X116.22 Y185.235 Z-3.278 F25
G1 X116.223 Y185.346 Z-3.282 F25
G1 X116.218 Y185.456 Z-3.286 F25
G1 X116.205 Y185.566 Z-3.29 F25
G1 X116.184 Y185.675 Z-3.295 F25
G1 X116.155 Y185.782 Z-3.299 F25
G1 X116.119 Y185.887 Z-3.303 F25
G1 X116.075 Y185.989 Z-3.307 F25
G1 X116.024 Y186.087 Z-3.311 F25
G1 X115.966 Y186.181 Z-3.315 F25
G1 X115.901 Y186.271 Z-3.319 F25
G1 X115.83 Y186.357 Z-3.323 F25
G1 X115.753 Y186.436 Z-3.328 F25
G1 X115.671 Y186.51 Z-3.332 F25
G1 X115.584 Y186.578 Z-3.336 F25
G1 X115.491 Y186.64 Z-3.34 F25
G1 X115.395 Y186.694 Z-3.344 F25
G1 X115.295 Y186.742 Z-3.348 F25
G1 X115.192 Y186.782 Z-3.352 F25
G1 X115.086 Y186.815 Z-3.356 F25
G1 X114.978 Y186.84 Z-3.361 F25
G1 X114.869 Y186.857 Z-3.365 F25
G1 X114.759 Y186.866 Z-3.369 F25
G1 X114.648 Y186.868 Z-3.373 F25
G1 X114.538 Y186.861 Z-3.377 F25
G1 X114.428 Y186.846 Z-3.381 F25
G1 X114.32 Y186.824 Z-3.385 F25
G1 X114.213 Y186.794 Z-3.389 F25
G1 X114.109 Y186.756 Z-3.394 F25
G1 X114.008 Y186.711 Z-3.398 F25
G1 X113.911 Y186.659 Z-3.402 F25
G1 X113.817 Y186.599 Z-3.406 F25
G1 X113.728 Y186.534 Z-3.41 F25
G1 X113.644 Y186.462 Z-3.414 F25
G1 X113.566 Y186.384 Z-3.418 F25
G1 X113.493 Y186.3 Z-3.422 F25
G1 X113.426 Y186.212 Z-3.427 F25
G1 X113.366 Y186.119 Z-3.431 F25
G1 X113.313 Y186.022 Z-3.435 F25
G1 X113.267 Y185.922 Z-3.439 F25
G1 X113.228 Y185.818 Z-3.443 F25
G1 X113.197 Y185.712 Z-3.447 F25
G1 X113.173 Y185.604 Z-3.451 F25
G1 X113.157 Y185.494 Z-3.455 F25
G1 X113.15 Y185.384 Z-3.46 F25
G1 Y185.273 Z-3.464 F25
G1 X113.158 Y185.163 Z-3.468 F25
G1 X113.174 Y185.054 Z-3.472 F25
G1 X113.198 Y184.946 Z-3.476 F25
G1 X113.23 Y184.84 Z-3.48 F25
G1 X113.269 Y184.737 Z-3.484 F25
G1 X113.315 Y184.636 Z-3.488 F25
G1 X113.369 Y184.54 Z-3.493 F25
G1 X113.429 Y184.447 Z-3.497 F25
G1 X113.496 Y184.359 Z-3.501 F25
G1 X113.569 Y184.276 Z-3.505 F25
G1 X113.648 Y184.199 Z-3.509 F25
G1 X113.732 Y184.127 Z-3.513 F25
G1 X113.821 Y184.062 Z-3.517 F25
G1 X113.915 Y184.003 Z-3.521 F25
G1 X114.013 Y183.951 Z-3.525 F25
G1 X114.114 Y183.907 Z-3.53 F25
G1 X114.218 Y183.869 Z-3.534 F25
G1 X114.324 Y183.84 Z-3.538 F25
G1 X114.433 Y183.818 Z-3.542 F25
G1 X114.542 Y183.804 Z-3.546 F25
G1 X114.652 Y183.797 Z-3.55 F25
G1 X114.763 Y183.799 Z-3.554 F25
G1 X114.873 Y183.809 Z-3.558 F25
G1 X114.982 Y183.826 Z-3.563 F25
G1 X115.09 Y183.852 Z-3.567 F25
G1 X115.195 Y183.885 Z-3.571 F25
G1 X115.298 Y183.926 Z-3.575 F25
G1 X115.397 Y183.973 Z-3.579 F25
G1 X115.493 Y184.028 Z-3.583 F25
G1 X115.585 Y184.09 Z-3.587 F25
G1 X115.672 Y184.158 Z-3.591 F25
G1 X115.754 Y184.232 Z-3.596 F25
G1 X115.83 Y184.312 Z-3.6 F25
G1 X115.9 Y184.397 Z-3.604 F25
G1 X115.964 Y184.487 Z-3.608 F25
G1 X116.021 Y184.581 Z-3.612 F25
G1 X116.072 Y184.679 Z-3.616 F25
G1 X116.115 Y184.781 Z-3.62 F25
G1 X116.151 Y184.885 Z-3.624 F25
G1 X116.179 Y184.992 Z-3.629 F25
G1 X116.199 Y185.1 Z-3.633 F25
G1 X116.212 Y185.21 Z-3.637 F25
G1 X116.217 Y185.32 Z-3.641 F25
G1 X116.213 Y185.431 Z-3.645 F25
G1 X116.202 Y185.54 Z-3.649 F25
G1 X116.183 Y185.649 Z-3.653 F25
G1 X116.156 Y185.756 Z-3.657 F25
G1 X116.122 Y185.861 Z-3.662 F25
G1 X116.08 Y185.963 Z-3.666 F25
G1 X116.031 Y186.062 Z-3.67 F25
G1 X115.974 Y186.157 Z-3.674 F25
G1 X115.911 Y186.248 Z-3.678 F25
G1 X115.842 Y186.334 Z-3.682 F25
G1 X115.767 Y186.414 Z-3.686 F25
G1 X115.686 Y186.489 Z-3.69 F25
G1 X115.6 Y186.558 Z-3.695 F25
G1 X115.509 Y186.621 Z-3.699 F25
G1 X115.414 Y186.677 Z-3.703 F25
G1 X115.316 Y186.726 Z-3.707 F25
G1 X115.214 Y186.768 Z-3.711 F25
G1 X115.109 Y186.802 Z-3.715 F25
G1 X115.002 Y186.829 Z-3.719 F25
G1 X114.893 Y186.848 Z-3.723 F25
G1 X114.784 Y186.859 Z-3.728 F25
G1 X114.674 Y186.862 Z-3.732 F25
G1 X114.563 Y186.857 Z-3.736 F25
G1 X114.454 Y186.844 Z-3.74 F25
G1 X114.346 Y186.824 Z-3.744 F25
G1 X114.239 Y186.795 Z-3.748 F25
G1 X114.135 Y186.759 Z-3.752 F25
G1 X114.034 Y186.716 Z-3.756 F25
G1 X113.936 Y186.666 Z-3.761 F25
G1 X113.842 Y186.608 Z-3.765 F25
G1 X113.752 Y186.544 Z-3.769 F25
G1 X113.667 Y186.474 Z-3.773 F25
G1 X113.587 Y186.398 Z-3.777 F25
G1 X113.514 Y186.316 Z-3.781 F25
G1 X113.446 Y186.229 Z-3.785 F25
G1 X113.384 Y186.137 Z-3.789 F25
G1 X113.33 Y186.042 Z-3.794 F25
G1 X113.282 Y185.942 Z-3.798 F25
G1 X113.242 Y185.84 Z-3.802 F25
G1 X113.209 Y185.735 Z-3.806 F25
G1 X113.184 Y185.627 Z-3.81 F25
G1 X113.166 Y185.519 Z-3.814 F25
G1 X113.157 Y185.409 Z-3.818 F25
G1 X113.155 Y185.299 Z-3.822 F25
G1 X113.162 Y185.189 Z-3.826 F25
G1 X113.176 Y185.08 Z-3.831 F25
G1 X113.198 Y184.972 Z-3.835 F25
G1 X113.228 Y184.866 Z-3.839 F25
G1 X113.265 Y184.762 Z-3.843 F25
G1 X113.31 Y184.662 Z-3.847 F25
G1 X113.361 Y184.565 Z-3.851 F25
G1 X113.42 Y184.471 Z-3.855 F25
G1 X113.485 Y184.383 Z-3.859 F25
G1 X113.557 Y184.299 Z-3.864 F25
G1 X113.634 Y184.221 Z-3.868 F25
G1 X113.717 Y184.148 Z-3.872 F25
G1 X113.804 Y184.081 Z-3.876 F25
G1 X113.897 Y184.021 Z-3.88 F25
G1 X113.993 Y183.968 Z-3.884 F25
G1 X114.093 Y183.922 Z-3.888 F25
G1 X114.196 Y183.883 Z-3.892 F25
G1 X114.301 Y183.852 Z-3.897 F25
G1 X114.409 Y183.828 Z-3.901 F25
G1 X114.518 Y183.812 Z-3.905 F25
G1 X114.628 Y183.804 Z-3.909 F25
G1 X114.738 Z-3.913 F25
G1 X114.847 Y183.812 Z-3.917 F25
G1 X114.956 Y183.828 Z-3.921 F25
G1 X115.064 Y183.852 Z-3.925 F25
G1 X115.169 Y183.883 Z-3.93 F25
G1 X115.272 Y183.921 Z-3.934 F25
G1 X115.372 Y183.967 Z-3.938 F25
G1 X115.468 Y184.02 Z-3.942 F25
G1 X115.561 Y184.08 Z-3.946 F25
G1 X115.648 Y184.147 Z-3.95 F25
G1 X115.731 Y184.219 Z-3.954 F25
G1 X115.808 Y184.297 Z-3.958 F25
G1 X115.879 Y184.381 Z-3.963 F25
G1 X115.945 Y184.469 Z-3.967 F25
G1 X116.003 Y184.562 Z-3.971 F25
G1 X116.055 Y184.659 Z-3.975 F25
G1 X116.1 Y184.76 Z-3.979 F25
G1 X116.137 Y184.863 Z-3.983 F25
G1 X116.167 Y184.969 Z-3.987 F25
G1 X116.189 Y185.077 Z-3.991 F25
G1 X116.204 Y185.186 Z-3.996 F25
G1 X116.21 Y185.295 Z-4 F25
G1 X116.208 Y185.405 Z-4.004 F25
G1 X116.199 Y185.515 Z-4.008 F25
G1 X116.182 Y185.623 Z-4.012 F25
G1 X116.157 Y185.73 Z-4.016 F25
G1 X116.124 Y185.835 Z-4.02 F25
G1 X116.084 Y185.938 Z-4.024 F25
G1 X116.037 Y186.037 Z-4.029 F25
G1 X115.982 Y186.132 Z-4.033 F25
G1 X115.921 Y186.224 Z-4.037 F25
G1 X115.854 Y186.311 Z-4.041 F25
G1 X115.78 Y186.392 Z-4.045 F25
G1 X115.701 Y186.468 Z-4.049 F25
G1 X115.617 Y186.538 Z-4.053 F25
G1 X115.527 Y186.602 Z-4.057 F25
G1 X115.434 Y186.659 Z-4.062 F25
G1 X115.336 Y186.71 Z-4.066 F25
G1 X115.235 Y186.753 Z-4.07 F25
G1 X115.131 Y186.789 Z-4.074 F25
G1 X115.025 Y186.817 Z-4.078 F25
G1 X114.918 Y186.838 Z-4.082 F25
G1 X114.808 Y186.851 Z-4.086 F25
G1 X114.699 Y186.856 Z-4.09 F25
G1 X114.589 Y186.853 Z-4.095 F25
G1 X114.48 Y186.842 Z-4.099 F25
G1 X114.372 Y186.823 Z-4.103 F25
G1 X114.265 Y186.796 Z-4.107 F25
G1 X114.161 Y186.762 Z-4.111 F25
G1 X114.059 Y186.721 Z-4.115 F25
G1 X113.961 Y186.672 Z-4.119 F25
G1 X113.866 Y186.617 Z-4.123 F25
G1 X113.776 Y186.554 Z-4.127 F25
G1 X113.69 Y186.486 Z-4.132 F25
G1 X113.609 Y186.411 Z-4.136 F25
G1 X113.535 Y186.331 Z-4.14 F25
G1 X113.466 Y186.245 Z-4.144 F25
G1 X113.403 Y186.155 Z-4.148 F25
G1 X113.347 Y186.061 Z-4.152 F25
G1 X113.298 Y185.963 Z-4.156 F25
G1 X113.256 Y185.861 Z-4.16 F25
G1 X113.222 Y185.757 Z-4.165 F25
G1 X113.195 Y185.651 Z-4.169 F25
G1 X113.176 Y185.543 Z-4.173 F25
G1 X113.165 Y185.434 Z-4.177 F25
G1 X113.161 Y185.324 Z-4.181 F25
G1 X113.166 Y185.215 Z-4.185 F25
G1 X113.178 Y185.106 Z-4.189 F25
G1 X113.198 Y184.998 Z-4.193 F25
G1 X113.226 Y184.892 Z-4.198 F25
G1 X113.262 Y184.788 Z-4.202 F25
G1 X113.305 Y184.687 Z-4.206 F25
G1 X113.354 Y184.59 Z-4.21 F25
G1 X113.411 Y184.496 Z-4.214 F25
G1 X113.475 Y184.407 Z-4.218 F25
G1 X113.545 Y184.322 Z-4.222 F25
G1 X113.62 Y184.243 Z-4.226 F25
G1 X113.701 Y184.169 Z-4.231 F25
G1 X113.788 Y184.101 Z-4.235 F25
G1 X113.879 Y184.04 Z-4.239 F25
G1 X113.974 Y183.985 Z-4.243 F25
G1 X114.072 Y183.938 Z-4.247 F25
G1 X114.174 Y183.897 Z-4.251 F25
G1 X114.279 Y183.864 Z-4.255 F25
G1 X114.386 Y183.839 Z-4.259 F25
G1 X114.494 Y183.821 Z-4.264 F25
G1 X114.603 Y183.812 Z-4.268 F25
G1 X114.713 Y183.81 Z-4.272 F25
G1 X114.822 Y183.816 Z-4.276 F25
G1 X114.931 Y183.83 Z-4.28 F25
G1 X115.038 Y183.851 Z-4.284 F25
G1 X115.143 Y183.881 Z-4.288 F25
G1 X115.246 Y183.918 Z-4.292 F25
G1 X115.347 Y183.962 Z-4.297 F25
G1 X115.443 Y184.013 Z-4.301 F25
G1 X115.536 Y184.071 Z-4.305 F25
G1 X115.625 Y184.136 Z-4.309 F25
G1 X115.708 Y184.207 Z-4.313 F25
G1 X115.786 Y184.283 Z-4.317 F25
G1 X115.859 Y184.365 Z-4.321 F25
G1 X115.925 Y184.452 Z-4.325 F25
G1 X115.985 Y184.544 Z-4.33 F25
G1 X116.038 Y184.64 Z-4.334 F25
G1 X116.084 Y184.739 Z-4.338 F25
G1 X116.123 Y184.841 Z-4.342 F25
G1 X116.155 Y184.946 Z-4.346 F25
G1 X116.179 Y185.053 Z-4.35 F25
G1 X116.195 Y185.161 Z-4.354 F25
G1 X116.203 Y185.271 Z-4.358 F25
G1 Y185.38 Z-4.363 F25
G1 X116.196 Y185.489 Z-4.367 F25
G1 X116.18 Y185.598 Z-4.371 F25
G1 X116.157 Y185.705 Z-4.375 F25
G1 X116.126 Y185.81 Z-4.379 F25
G1 X116.088 Y185.912 Z-4.383 F25
G1 X116.043 Y186.012 Z-4.387 F25
G1 X115.99 Y186.108 Z-4.391 F25
G1 X115.931 Y186.2 Z-4.396 F25
G1 X115.865 Y186.287 Z-4.4 F25
G1 X115.793 Y186.369 Z-4.404 F25
G1 X115.715 Y186.446 Z-4.408 F25
G1 X115.633 Y186.518 Z-4.412 F25
G1 X115.545 Y186.583 Z-4.416 F25
G1 X115.452 Y186.641 Z-4.42 F25
G1 X115.356 Y186.693 Z-4.424 F25
G1 X115.256 Y186.738 Z-4.429 F25
G1 X115.153 Y186.775 Z-4.433 F25
G1 X115.048 Y186.805 Z-4.437 F25
G1 X114.941 Y186.828 Z-4.441 F25
G1 X114.833 Y186.842 Z-4.445 F25
G1 X114.724 Y186.849 Z-4.449 F25
G1 X114.614 Y186.848 Z-4.453 F25
G1 X114.505 Y186.839 Z-4.457 F25
G1 X114.397 Y186.822 Z-4.461 F25
G1 X114.291 Y186.797 Z-4.466 F25
G1 X114.186 Y186.765 Z-4.47 F25
G1 X114.084 Y186.725 Z-4.474 F25
G1 X113.986 Y186.678 Z-4.478 F25
G1 X113.89 Y186.625 Z-4.482 F25
G1 X113.799 Y186.564 Z-4.486 F25
G1 X113.713 Y186.497 Z-4.49 F25
G1 X113.632 Y186.424 Z-4.494 F25
G1 X113.556 Y186.345 Z-4.499 F25
G1 X113.486 Y186.261 Z-4.503 F25
G1 X113.422 Y186.173 Z-4.507 F25
G1 X113.365 Y186.08 Z-4.511 F25
G1 X113.314 Y185.983 Z-4.515 F25
G1 X113.271 Y185.883 Z-4.519 F25
G1 X113.235 Y185.779 Z-4.523 F25
G1 X113.207 Y185.674 Z-4.527 F25
G1 X113.186 Y185.567 Z-4.532 F25
G1 X113.173 Y185.458 Z-4.536 F25
G1 X113.168 Y185.349 Z-4.54 F25
G1 X113.17 Y185.24 Z-4.544 F25
G1 X113.181 Y185.131 Z-4.548 F25
G1 X113.199 Y185.024 Z-4.552 F25
G1 X113.225 Y184.918 Z-4.556 F25
G1 X113.259 Y184.814 Z-4.56 F25
G1 X113.3 Y184.713 Z-4.565 F25
G1 X113.348 Y184.615 Z-4.569 F25
G1 X113.403 Y184.52 Z-4.573 F25
G1 X113.465 Y184.43 Z-4.577 F25
G1 X113.533 Y184.345 Z-4.581 F25
G1 X113.607 Y184.265 Z-4.585 F25
G1 X113.687 Y184.19 Z-4.589 F25
G1 X113.771 Y184.121 Z-4.593 F25
G1 X113.861 Y184.059 Z-4.598 F25
G1 X113.955 Y184.003 Z-4.602 F25
G1 X114.052 Y183.954 Z-4.606 F25
G1 X114.153 Y183.912 Z-4.61 F25
G1 X114.257 Y183.877 Z-4.614 F25
G1 X114.363 Y183.85 Z-4.618 F25
G1 X114.47 Y183.831 Z-4.622 F25
G1 X114.578 Y183.819 Z-4.626 F25
G1 X114.687 Y183.816 Z-4.631 F25
G1 X114.796 Y183.82 Z-4.635 F25
G1 X114.905 Y183.832 Z-4.639 F25
G1 X115.012 Y183.852 Z-4.643 F25
G1 X115.117 Y183.879 Z-4.647 F25
G1 X115.221 Y183.914 Z-4.651 F25
G1 X115.321 Y183.957 Z-4.655 F25
G1 X115.418 Y184.006 Z-4.659 F25
G1 X115.512 Y184.062 Z-4.664 F25
G1 X115.601 Y184.125 Z-4.668 F25
G1 X115.685 Y184.195 Z-4.672 F25
G1 X115.764 Y184.27 Z-4.676 F25
G1 X115.838 Y184.35 Z-4.68 F25
G1 X115.905 Y184.436 Z-4.684 F25
G1 X115.967 Y184.526 Z-4.688 F25
G1 X116.021 Y184.62 Z-4.692 F25
G1 X116.069 Y184.719 Z-4.697 F25
G1 X116.109 Y184.82 Z-4.701 F25
G1 X116.142 Y184.924 Z-4.705 F25
G1 X116.168 Y185.03 Z-4.709 F25
G1 X116.185 Y185.137 Z-4.713 F25
G1 X116.195 Y185.246 Z-4.717 F25
G1 X116.198 Y185.355 Z-4.721 F25
G1 X116.192 Y185.464 Z-4.725 F25
G1 X116.178 Y185.572 Z-4.73 F25
G1 X116.157 Y185.679 Z-4.734 F25
G1 X116.128 Y185.784 Z-4.738 F25
G1 X116.092 Y185.887 Z-4.742 F25
G1 X116.048 Y185.987 Z-4.746 F25
G1 X115.997 Y186.083 Z-4.75 F25
G1 X115.94 Y186.175 Z-4.754 F25
G1 X115.876 Y186.264 Z-4.758 F25
G1 X115.806 Y186.347 Z-4.763 F25
G1 X115.729 Y186.425 Z-4.767 F25
G1 X115.648 Y186.497 Z-4.771 F25
G1 X115.562 Y186.563 Z-4.775 F25
G1 X115.471 Y186.623 Z-4.779 F25
G1 X115.376 Y186.676 Z-4.783 F25
G1 X115.277 Y186.722 Z-4.787 F25
G1 X115.175 Y186.761 Z-4.791 F25
G1 X115.071 Y186.793 Z-4.795 F25
G1 X114.965 Y186.817 Z-4.8 F25
G1 X114.857 Y186.833 Z-4.804 F25
G1 X114.748 Y186.842 Z-4.808 F25
G1 X114.64 Z-4.812 F25
G1 X114.531 Y186.835 Z-4.816 F25
G1 X114.423 Y186.82 Z-4.82 F25
G1 X114.316 Y186.797 Z-4.824 F25
G1 X114.212 Y186.767 Z-4.828 F25
G1 X114.11 Y186.729 Z-4.833 F25
G1 X114.011 Y186.684 Z-4.837 F25
G1 X113.915 Y186.632 Z-4.841 F25
G1 X113.823 Y186.573 Z-4.845 F25
G1 X113.736 Y186.508 Z-4.849 F25
G1 X113.654 Y186.437 Z-4.853 F25
G1 X113.577 Y186.36 Z-4.857 F25
G1 X113.506 Y186.277 Z-4.861 F25
G1 X113.441 Y186.19 Z-4.866 F25
G1 X113.383 Y186.098 Z-4.87 F25
G1 X113.331 Y186.003 Z-4.874 F25
G1 X113.286 Y185.904 Z-4.878 F25
G1 X113.249 Y185.801 Z-4.882 F25
G1 X113.219 Y185.697 Z-4.886 F25
G1 X113.196 Y185.59 Z-4.89 F25
G1 X113.181 Y185.483 Z-4.894 F25
G1 X113.174 Y185.374 Z-4.899 F25
G1 X113.175 Y185.265 Z-4.903 F25
G1 X113.184 Y185.157 Z-4.907 F25
G1 X113.201 Y185.049 Z-4.911 F25
G1 X113.225 Y184.943 Z-4.915 F25
G1 X113.256 Y184.839 Z-4.919 F25
G1 X113.296 Y184.738 Z-4.923 F25
G1 X113.342 Y184.64 Z-4.927 F25
G1 X113.395 Y184.545 Z-4.932 F25
G1 X113.455 Y184.454 Z-4.936 F25
G1 X113.522 Y184.368 Z-4.94 F25
G1 X113.594 Y184.287 Z-4.944 F25
G1 X113.672 Y184.211 Z-4.948 F25
G1 X113.756 Y184.141 Z-4.952 F25
G1 X113.844 Y184.077 Z-4.956 F25
G1 X113.936 Y184.02 Z-4.96 F25
G1 X114.033 Y183.97 Z-4.965 F25
G1 X114.132 Y183.926 Z-4.969 F25
G1 X114.235 Y183.89 Z-4.973 F25
G1 X114.339 Y183.862 Z-4.977 F25
G1 X114.446 Y183.841 Z-4.981 F25
G1 X114.554 Y183.828 Z-4.985 F25
G1 X114.662 Y183.822 Z-4.989 F25
G1 X114.771 Y183.825 Z-4.993 F25
G1 X114.879 Y183.835 Z-4.998 F25
G1 X114.986 Y183.853 Z-5.002 F25
G1 X115.092 Y183.878 Z-5.006 F25
G1 X115.195 Y183.912 Z-5.01 F25
G1 X115.296 Y183.952 Z-5.014 F25
G1 X115.394 Y184 Z-5.018 F25
G1 X115.487 Y184.054 Z-5.022 F25
G1 X115.577 Y184.116 Z-5.026 F25
G1 X115.662 Y184.183 Z-5.031 F25
G1 X115.742 Y184.256 Z-5.035 F25
G1 X115.817 Y184.335 Z-5.039 F25
G1 X115.886 Y184.42 Z-5.043 F25
G1 X115.948 Y184.509 Z-5.047 F25
G1 X116.004 Y184.602 Z-5.051 F25
G1 X116.053 Y184.699 Z-5.055 F25
G1 X116.095 Y184.799 Z-5.059 F25
G1 X116.129 Y184.902 Z-5.064 F25
G1 X116.156 Y185.007 Z-5.068 F25
G1 X116.176 Y185.114 Z-5.072 F25
G1 X116.188 Y185.222 Z-5.076 F25
G1 X116.192 Y185.33 Z-5.08 F25
G3 X113.175 I-1.508 F25
G3 X116.192 I1.508 F25
; MOVEMENT_CUTTING
G1 X116.21 Y186.028 F254
G1 X116.235 Y186.112 F254
G1 X116.259 Y186.262 F254
G1 X116.252 Y186.414 F254
G1 X116.221 Y186.564 F254
G1 X116.17 Y186.707 F254
G1 X116.101 Y186.843 F254
G1 X116.017 Y186.97 F254
G1 X115.919 Y187.087 F254
G1 X115.811 Y187.194 F254
G1 X115.693 Y187.291 F254
G1 X115.566 Y187.376 F254
G1 X115.433 Y187.45 F254
G1 X115.294 Y187.513 F254
G1 X115.148 Y187.565 F254
G1 X114.995 Y187.606 F254
G1 X114.835 Y187.636 F254
G1 X114.67 Y187.653 F254
G1 X114.501 Y187.656 F254
G1 X114.33 Y187.646 F254
G1 X114.158 Y187.622 F254
G1 X113.986 Y187.584 F254
G1 X113.815 Y187.531 F254
G1 X113.644 Y187.462 F254
G1 X113.523 Y187.387 F254
G1 X113.419 Y187.29 F254
G1 X113.335 Y187.174 F254
G1 X112.758 Y186.193 F254
G1 X112.695 Y186.085 F254
G1 X112.638 Y185.927 F254
G1 X112.533 Y185.609 F254
G1 X112.492 Y185.462 F254
G1 X112.464 Y185.313 F254
G1 X112.449 Y185.161 F254
G1 X112.447 Y185.009 F254
G1 X112.457 Y184.855 F254
G1 X112.48 Y184.699 F254
G1 X112.517 Y184.542 F254
G1 X112.567 Y184.386 F254
G1 X112.63 Y184.231 F254
G1 X112.708 Y184.079 F254
G1 X112.798 Y183.931 F254
G1 X112.901 Y183.79 F254
G1 X113.017 Y183.655 F254
G1 X113.144 Y183.529 F254
G1 X113.283 Y183.412 F254
G1 X113.432 Y183.306 F254
G1 X113.589 Y183.212 F254
G1 X113.755 Y183.13 F254
G1 X113.928 Y183.061 F254
G1 X114.107 Y183.006 F254
G1 X114.291 Y182.966 F254
G1 X114.478 Y182.94 F254
G1 X114.667 Y182.929 F254
G1 X114.857 Y182.934 F254
G1 X115.046 Y182.953 F254
G1 X115.234 Y182.988 F254
G1 X115.418 Y183.038 F254
G1 X115.54 Y183.082 F254
G1 X115.654 Y183.134 F254
G1 X115.758 Y183.205 F254
G1 X115.848 Y183.292 F254
; MOVEMENT_LEAD_OUT
G1 X115.876 Y183.333 Z-5.06 F254
G1 X115.898 Y183.377 Z-5.039 F254
G1 X115.912 Y183.425 Z-5.019 F254
G1 X115.918 Y183.475 Z-4.999 F254
G1 X115.917 Y183.524 Z-4.978 F254
G1 X115.908 Y183.573 Z-4.958 F254
G1 X115.892 Y183.62 Z-4.938 F254
G1 X115.868 Y183.664 Z-4.917 F254
G1 X115.838 Y183.704 Z-4.897 F254
G1 X115.802 Y183.738 Z-4.877 F254
G3 X115.788 Y183.749 I-0.201 J-0.246 F254
G1 X115.602 Y183.884 F254
; MOVEMENT_LINK_DIRECT
G1 X113.147 Y185.662 F254
; MOVEMENT_LEAD_IN
G1 X113.017 Y185.756 F254
G3 X112.941 Y185.797 I-0.186 J-0.257 F254
G1 X112.893 Y185.81 Z-4.897 F254
G1 X112.843 Y185.816 Z-4.917 F254
G1 X112.794 Y185.814 Z-4.938 F254
G1 X112.745 Y185.805 Z-4.958 F254
G1 X112.698 Y185.787 Z-4.978 F254
G1 X112.655 Y185.763 Z-4.999 F254
G1 X112.616 Y185.732 Z-5.019 F254
G1 X112.582 Y185.696 Z-5.039 F254
G1 X112.554 Y185.655 Z-5.06 F254
G1 X112.533 Y185.609 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X112.244 Y184.737 F254
G1 X112.234 Y184.697 F254
G1 X112.228 Y184.658 F254
G1 X112.184 Y184.182 F254
G1 X112.177 Y184.03 F254
G1 X112.188 Y183.878 F254
G1 X112.215 Y183.728 F254
G1 X112.256 Y183.581 F254
G1 X112.31 Y183.438 F254
G1 X112.379 Y183.294 F254
G1 X112.463 Y183.149 F254
G1 X112.562 Y183.006 F254
G1 X112.679 Y182.863 F254
G1 X112.814 Y182.723 F254
G1 X112.967 Y182.588 F254
G1 X113.133 Y182.463 F254
G1 X113.315 Y182.349 F254
G1 X113.512 Y182.246 F254
G1 X113.723 Y182.156 F254
G1 X113.947 Y182.081 F254
G1 X114.038 Y182.059 F254
G1 X114.251 Y182.038 F254
G1 X114.462 Y182.08 F254
G1 X114.651 Y182.18 F254
; MOVEMENT_LEAD_OUT
G1 X114.688 Y182.213 Z-5.06 F254
G1 X114.719 Y182.252 Z-5.039 F254
G1 X114.743 Y182.296 Z-5.019 F254
G1 X114.761 Y182.342 Z-4.999 F254
G1 X114.771 Y182.391 Z-4.978 F254
G1 X114.773 Y182.441 Z-4.958 F254
G1 X114.767 Y182.49 Z-4.938 F254
G1 X114.754 Y182.538 Z-4.917 F254
G1 X114.733 Y182.584 Z-4.897 F254
G1 X114.706 Y182.625 Z-4.877 F254
G3 X114.665 Y182.668 I-0.25 J-0.196 F254
G1 X114.524 Y182.792 F254
; MOVEMENT_LINK_DIRECT
G1 X112.752 Y184.341 F254
; MOVEMENT_LEAD_IN
G1 X112.707 Y184.38 F254
G3 X112.539 Y184.456 I-0.209 J-0.239 F254
G1 X112.489 Y184.458 Z-4.897 F254
G1 X112.44 Y184.453 Z-4.917 F254
G1 X112.392 Y184.44 Z-4.938 F254
G1 X112.346 Y184.42 Z-4.958 F254
G1 X112.305 Y184.393 Z-4.978 F254
G1 X112.268 Y184.359 Z-4.999 F254
G1 X112.236 Y184.32 Z-5.019 F254
G1 X112.212 Y184.277 Z-5.039 F254
G1 X112.194 Y184.231 Z-5.06 F254
G1 X112.184 Y184.182 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X112.124 Y183.547 F254
G1 X112.122 Y183.504 F254
G1 X112.124 Y183.461 F254
G1 X112.238 Y182.755 F254
G1 X112.251 Y182.675 F254
G1 X112.259 Y182.636 F254
G1 X112.27 Y182.596 F254
G1 X112.282 Y182.567 F254
G1 X112.506 Y182.12 F254
G1 X112.544 Y182.065 F254
G1 X112.599 Y182.01 F254
G1 X112.758 Y181.861 F254
G1 X112.797 Y181.827 F254
G1 X112.836 Y181.803 F254
G1 X112.876 Y181.783 F254
G1 X112.916 Y181.769 F254
G1 X113.075 Y181.723 F254
G1 X113.154 Y181.701 F254
G1 X113.194 Y181.694 F254
G1 X113.234 Y181.692 F254
G1 X113.63 Y181.721 F254
G1 X113.67 Y181.725 F254
G1 X113.709 Y181.733 F254
G1 X113.868 Y181.792 F254
G1 X114.343 Y181.98 F254
G1 X114.423 Y182.016 F254
G1 X114.502 Y182.07 F254
G1 X115.223 Y182.596 F254
G1 X115.259 Y182.624 F254
G1 X115.294 Y182.659 F254
G1 X116.087 Y183.566 F254
G1 X116.117 Y183.601 F254
G1 X116.141 Y183.636 F254
G1 X116.8 Y184.816 F254
G1 X116.841 Y184.896 F254
G1 X116.867 Y184.975 F254
G1 X117.038 Y185.537 F254
G1 X117.094 Y185.76 F254
G1 X117.123 Y185.929 F254
G1 X117.138 Y186.104 F254
G1 X117.139 Y186.274 F254
G1 X117.126 Y186.446 F254
G1 X117.098 Y186.622 F254
G1 X117.056 Y186.796 F254
G1 X117 Y186.967 F254
G1 X116.93 Y187.135 F254
G1 X116.844 Y187.302 F254
G1 X116.742 Y187.465 F254
G1 X116.625 Y187.623 F254
G1 X116.493 Y187.773 F254
G1 X116.348 Y187.916 F254
G1 X116.188 Y188.048 F254
G1 X116.015 Y188.169 F254
G1 X115.829 Y188.279 F254
G1 X115.631 Y188.375 F254
G1 X115.421 Y188.456 F254
G1 X115.202 Y188.522 F254
G1 X115.099 Y188.544 F254
G1 X114.899 Y188.559 F254
G1 X114.702 Y188.519 F254
G1 X114.523 Y188.429 F254
; MOVEMENT_LEAD_OUT
G1 X114.486 Y188.396 Z-5.06 F254
G1 X114.454 Y188.358 Z-5.039 F254
G1 X114.428 Y188.315 Z-5.019 F254
G1 X114.41 Y188.269 Z-4.999 F254
G1 X114.398 Y188.22 Z-4.978 F254
G1 X114.395 Y188.171 Z-4.958 F254
G1 X114.399 Y188.121 Z-4.938 F254
G1 X114.412 Y188.073 Z-4.917 F254
G1 X114.431 Y188.027 Z-4.897 F254
G1 X114.458 Y187.985 Z-4.877 F254
G3 X114.465 Y187.976 I0.255 J0.189 F254
G1 X114.612 Y187.792 F254
; MOVEMENT_LINK_DIRECT
G1 X116.448 Y185.495 F254
; MOVEMENT_LEAD_IN
G1 X116.49 Y185.442 F254
G3 X116.635 Y185.34 I0.248 J0.198 F254
G1 X116.683 Y185.328 Z-4.897 F254
G1 X116.733 Y185.323 Z-4.917 F254
G1 X116.783 Y185.326 Z-4.938 F254
G1 X116.831 Y185.337 Z-4.958 F254
G1 X116.878 Y185.355 Z-4.978 F254
G1 X116.92 Y185.381 Z-4.999 F254
G1 X116.959 Y185.412 Z-5.019 F254
G1 X116.992 Y185.45 Z-5.039 F254
G1 X117.019 Y185.492 Z-5.06 F254
G1 X117.038 Y185.537 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X117.206 Y186.085 F254
G1 X117.252 Y186.244 F254
G1 X117.266 Y186.402 F254
G1 X117.326 Y187.283 F254
G1 X117.331 Y187.354 F254
G1 X117.333 Y187.433 F254
G1 X117.321 Y187.513 F254
G1 X117.29 Y187.671 F254
G1 X117.254 Y187.819 F254
G1 X117.203 Y187.963 F254
G1 X117.139 Y188.106 F254
G1 X117.058 Y188.256 F254
G1 X116.956 Y188.412 F254
G1 X116.839 Y188.563 F254
G1 X116.701 Y188.713 F254
G1 X116.54 Y188.863 F254
G1 X116.439 Y188.943 F254
G1 X116.291 Y189.035 F254
G1 X116.125 Y189.089 F254
G1 X115.952 Y189.103 F254
; MOVEMENT_LEAD_OUT
G1 X115.902 Y189.096 Z-5.06 F254
G1 X115.855 Y189.08 Z-5.039 F254
G1 X115.81 Y189.058 Z-5.019 F254
G1 X115.77 Y189.029 Z-4.999 F254
G1 X115.734 Y188.994 Z-4.978 F254
G1 X115.705 Y188.954 Z-4.958 F254
G1 X115.682 Y188.91 Z-4.938 F254
G1 X115.666 Y188.863 Z-4.917 F254
G1 X115.658 Y188.814 Z-4.897 F254
G1 Y188.764 Z-4.877 F254
G3 X115.734 Y188.579 I0.317 J0.023 F254
G1 X115.762 Y188.546 F254
; MOVEMENT_LINK_DIRECT
G1 X116.736 Y187.415 F254
G3 X117.026 Y187.308 I0.241 J0.207 F254
; MOVEMENT_LEAD_IN
G1 X117.075 Y187.32 Z-4.897 F254
G1 X117.121 Y187.339 Z-4.917 F254
G1 X117.163 Y187.365 Z-4.938 F254
G1 X117.201 Y187.397 Z-4.958 F254
G1 X117.234 Y187.435 Z-4.978 F254
G1 X117.26 Y187.477 Z-4.999 F254
G1 X117.279 Y187.523 Z-5.019 F254
G1 X117.29 Y187.572 Z-5.039 F254
G1 X117.294 Y187.622 Z-5.06 F254
G1 X117.29 Y187.671 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X117.182 Y188.229 F254
G1 X117.172 Y188.268 F254
G1 X117.157 Y188.306 F254
G1 X116.942 Y188.702 F254
G1 X116.92 Y188.742 F254
G1 X116.889 Y188.781 F254
G1 X116.88 Y188.79 F254
G1 X116.71 Y188.94 F254
G1 X116.636 Y188.998 F254
G1 X116.6 Y189.018 F254
G1 X116.563 Y189.032 F254
G1 X116.365 Y189.099 F254
G1 X116.335 Y189.107 F254
G1 X116.305 Y189.112 F254
G1 X116.246 Y189.114 F254
G1 X115.929 Y189.102 F254
G1 X115.857 Y189.099 F254
G1 X115.814 Y189.092 F254
G1 X115.77 Y189.078 F254
G1 X115.294 Y188.907 F254
G1 X115.136 Y188.847 F254
G1 X115.033 Y188.781 F254
G1 X114.343 Y188.305 F254
G1 X114.304 Y188.276 F254
G1 X114.264 Y188.24 F254
G1 X113.451 Y187.354 F254
G1 X113.418 Y187.312 F254
G1 X113.392 Y187.271 F254
G1 X113.335 Y187.174 F254
; MOVEMENT_LEAD_OUT
G3 X113.437 Y186.76 I0.279 J-0.151 F254
G1 X113.475 Y186.746 Z-5.077 F254
G1 X113.513 Y186.732 Z-5.069 F254
G1 X113.549 Y186.719 Z-5.056 F254
G1 X113.584 Y186.707 Z-5.038 F254
G1 X113.614 Y186.705 Z-5.018 F254
G1 X113.651 Y186.713 Z-4.985 F254
G1 X113.682 Y186.719 Z-4.948 F254
G1 X113.707 Y186.724 Z-4.906 F254
G1 X113.725 Y186.728 Z-4.86 F254
G1 X113.736 Y186.73 Z-4.812 F254
G1 X113.74 Y186.731 Z-4.763 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X124.69 Y153.541 F254
G1 Z2.54 F254
; MOVEMENT_RAMP_HELIX
G1 X124.644 Y153.606 Z2.537 F25
G1 X124.592 Y153.665 Z2.534 F25
G1 X124.535 Y153.72 Z2.532 F25
G1 X124.472 Y153.769 Z2.529 F25
G1 X124.405 Y153.811 Z2.526 F25
G1 X124.334 Y153.847 Z2.523 F25
G1 X124.26 Y153.875 Z2.521 F25
G1 X124.184 Y153.896 Z2.518 F25
G1 X124.106 Y153.91 Z2.515 F25
G1 X124.027 Y153.916 Z2.512 F25
G1 X123.947 Y153.914 Z2.51 F25
G1 X123.869 Y153.904 Z2.507 F25
G1 X123.791 Y153.887 Z2.504 F25
G1 X123.716 Y153.862 Z2.501 F25
G1 X123.644 Y153.83 Z2.498 F25
G1 X123.574 Y153.791 Z2.496 F25
G1 X123.51 Y153.745 Z2.493 F25
G1 X123.449 Y153.694 Z2.49 F25
G1 X123.395 Y153.636 Z2.487 F25
G1 X123.346 Y153.574 Z2.485 F25
G1 X123.303 Y153.507 Z2.482 F25
G1 X123.268 Y153.436 Z2.479 F25
G1 X123.239 Y153.363 Z2.476 F25
G1 X123.218 Y153.286 Z2.474 F25
G1 X123.204 Y153.208 Z2.471 F25
G1 X123.198 Y153.129 Z2.468 F25
G1 X123.2 Y153.05 Z2.465 F25
G1 X123.209 Y152.972 Z2.462 F25
G1 X123.226 Y152.894 Z2.46 F25
G1 X123.251 Y152.819 Z2.457 F25
G1 X123.282 Y152.746 Z2.454 F25
G1 X123.321 Y152.677 Z2.451 F25
G1 X123.367 Y152.612 Z2.449 F25
G1 X123.418 Y152.552 Z2.446 F25
G1 X123.475 Y152.497 Z2.443 F25
G1 X123.537 Y152.448 Z2.44 F25
G1 X123.604 Y152.406 Z2.438 F25
G1 X123.675 Y152.37 Z2.435 F25
G1 X123.748 Y152.341 Z2.432 F25
G1 X123.825 Y152.319 Z2.429 F25
G1 X123.903 Y152.305 Z2.426 F25
G1 X123.981 Y152.299 Z2.424 F25
G1 X124.061 Y152.301 Z2.421 F25
G1 X124.139 Y152.31 Z2.418 F25
G1 X124.216 Y152.327 Z2.415 F25
G1 X124.292 Y152.351 Z2.413 F25
G1 X124.364 Y152.383 Z2.41 F25
G1 X124.433 Y152.421 Z2.407 F25
G1 X124.498 Y152.466 Z2.404 F25
G1 X124.558 Y152.518 Z2.402 F25
G1 X124.613 Y152.575 Z2.399 F25
G1 X124.662 Y152.637 Z2.396 F25
G1 X124.705 Y152.703 Z2.393 F25
G1 X124.741 Y152.773 Z2.39 F25
G1 X124.77 Y152.847 Z2.388 F25
G1 X124.792 Y152.923 Z2.385 F25
G1 X124.806 Y153.001 Z2.382 F25
G1 X124.813 Y153.08 Z2.379 F25
G1 X124.811 Y153.159 Z2.377 F25
G1 X124.802 Y153.237 Z2.374 F25
G1 X124.786 Y153.315 Z2.371 F25
G1 X124.762 Y153.39 Z2.368 F25
G1 X124.73 Y153.463 Z2.365 F25
G1 X124.692 Y153.532 Z2.363 F25
G1 X124.647 Y153.597 Z2.36 F25
G1 X124.596 Y153.657 Z2.357 F25
G1 X124.539 Y153.712 Z2.354 F25
G1 X124.478 Y153.761 Z2.352 F25
G1 X124.411 Y153.804 Z2.349 F25
G1 X124.341 Y153.84 Z2.346 F25
G1 X124.268 Y153.87 Z2.343 F25
G1 X124.192 Y153.891 Z2.341 F25
G1 X124.114 Y153.906 Z2.338 F25
G1 X124.035 Y153.912 Z2.335 F25
G1 X123.956 Y153.911 Z2.332 F25
G1 X123.878 Y153.903 Z2.329 F25
G1 X123.801 Y153.886 Z2.327 F25
G1 X123.725 Y153.862 Z2.324 F25
G1 X123.653 Y153.831 Z2.321 F25
G1 X123.584 Y153.793 Z2.318 F25
G1 X123.518 Y153.748 Z2.316 F25
G1 X123.458 Y153.697 Z2.313 F25
G1 X123.403 Y153.641 Z2.31 F25
G1 X123.353 Y153.579 Z2.307 F25
G1 X123.31 Y153.513 Z2.305 F25
G1 X123.274 Y153.443 Z2.302 F25
G1 X123.245 Y153.37 Z2.299 F25
G1 X123.223 Y153.294 Z2.296 F25
G1 X123.208 Y153.217 Z2.293 F25
G1 X123.201 Y153.138 Z2.291 F25
G1 X123.202 Y153.059 Z2.288 F25
G1 X123.211 Y152.981 Z2.285 F25
G1 X123.227 Y152.903 Z2.282 F25
G1 X123.25 Y152.828 Z2.28 F25
G1 X123.281 Y152.756 Z2.277 F25
G1 X123.319 Y152.686 Z2.274 F25
G1 X123.364 Y152.621 Z2.271 F25
G1 X123.414 Y152.561 Z2.269 F25
G1 X123.471 Y152.506 Z2.266 F25
G1 X123.532 Y152.456 Z2.263 F25
G1 X123.598 Y152.413 Z2.26 F25
G1 X123.668 Y152.376 Z2.257 F25
G1 X123.741 Y152.347 Z2.255 F25
G1 X123.817 Y152.324 Z2.252 F25
G1 X123.894 Y152.31 Z2.249 F25
G1 X123.973 Y152.303 Z2.246 F25
G1 X124.052 Z2.244 F25
G1 X124.13 Y152.312 Z2.241 F25
G1 X124.207 Y152.328 Z2.238 F25
G1 X124.282 Y152.351 Z2.235 F25
G1 X124.355 Y152.382 Z2.233 F25
G1 X124.424 Y152.419 Z2.23 F25
G1 X124.489 Y152.464 Z2.227 F25
G1 X124.55 Y152.514 Z2.224 F25
G1 X124.605 Y152.57 Z2.221 F25
G1 X124.655 Y152.631 Z2.219 F25
G1 X124.698 Y152.697 Z2.216 F25
G1 X124.735 Y152.767 Z2.213 F25
G1 X124.765 Y152.84 Z2.21 F25
G1 X124.787 Y152.915 Z2.208 F25
G1 X124.802 Y152.993 Z2.205 F25
G1 X124.809 Y153.071 Z2.202 F25
G1 Y153.15 Z2.199 F25
G1 X124.801 Y153.228 Z2.197 F25
G1 X124.785 Y153.305 Z2.194 F25
G1 X124.762 Y153.381 Z2.191 F25
G1 X124.731 Y153.453 Z2.188 F25
G1 X124.694 Y153.523 Z2.185 F25
G1 X124.65 Y153.588 Z2.183 F25
G1 X124.6 Y153.648 Z2.18 F25
G1 X124.544 Y153.704 Z2.177 F25
G1 X124.483 Y153.753 Z2.174 F25
G1 X124.417 Y153.797 Z2.172 F25
G1 X124.348 Y153.834 Z2.169 F25
G1 X124.275 Y153.864 Z2.166 F25
G1 X124.2 Y153.886 Z2.163 F25
G1 X124.122 Y153.901 Z2.161 F25
G1 X124.044 Y153.909 Z2.158 F25
G1 X123.965 Z2.155 F25
G1 X123.887 Y153.901 Z2.152 F25
G1 X123.81 Y153.885 Z2.149 F25
G1 X123.735 Y153.862 Z2.147 F25
G1 X123.662 Y153.832 Z2.144 F25
G1 X123.593 Y153.795 Z2.141 F25
G1 X123.527 Y153.751 Z2.138 F25
G1 X123.466 Y153.701 Z2.136 F25
G1 X123.411 Y153.645 Z2.133 F25
G1 X123.361 Y153.585 Z2.13 F25
G1 X123.318 Y153.519 Z2.127 F25
G1 X123.281 Y153.45 Z2.125 F25
G1 X123.25 Y153.377 Z2.122 F25
G1 X123.228 Y153.302 Z2.119 F25
G1 X123.212 Y153.225 Z2.116 F25
G1 X123.205 Y153.147 Z2.113 F25
G1 Y153.068 Z2.111 F25
G1 X123.212 Y152.99 Z2.108 F25
G1 X123.228 Y152.913 Z2.105 F25
G1 X123.25 Y152.838 Z2.102 F25
G1 X123.28 Y152.765 Z2.1 F25
G1 X123.317 Y152.696 Z2.097 F25
G1 X123.361 Y152.63 Z2.094 F25
G1 X123.411 Y152.569 Z2.091 F25
G1 X123.466 Y152.514 Z2.089 F25
G1 X123.527 Y152.464 Z2.086 F25
G1 X123.592 Y152.42 Z2.083 F25
G1 X123.661 Y152.383 Z2.08 F25
G1 X123.734 Y152.353 Z2.077 F25
G1 X123.809 Y152.33 Z2.075 F25
G1 X123.886 Y152.314 Z2.072 F25
G1 X123.964 Y152.306 Z2.069 F25
G1 X124.043 Z2.066 F25
G1 X124.121 Y152.313 Z2.064 F25
G1 X124.198 Y152.328 Z2.061 F25
G1 X124.273 Y152.351 Z2.058 F25
G1 X124.346 Y152.381 Z2.055 F25
G1 X124.415 Y152.417 Z2.052 F25
G1 X124.48 Y152.461 Z2.05 F25
G1 X124.541 Y152.51 Z2.047 F25
G1 X124.597 Y152.566 Z2.044 F25
G1 X124.647 Y152.626 Z2.041 F25
G1 X124.691 Y152.691 Z2.039 F25
G1 X124.728 Y152.76 Z2.036 F25
G1 X124.759 Y152.833 Z2.033 F25
G1 X124.782 Y152.908 Z2.03 F25
G1 X124.798 Y152.984 Z2.028 F25
G1 X124.806 Y153.063 Z2.025 F25
G1 Y153.141 Z2.022 F25
G1 X124.799 Y153.219 Z2.019 F25
G1 X124.784 Y153.296 Z2.016 F25
G1 X124.762 Y153.371 Z2.014 F25
G1 X124.732 Y153.444 Z2.011 F25
G1 X124.696 Y153.513 Z2.008 F25
G1 X124.653 Y153.579 Z2.005 F25
G1 X124.603 Y153.64 Z2.003 F25
G1 X124.548 Y153.696 Z2 F25
G1 X124.488 Y153.746 Z1.997 F25
G1 X124.423 Y153.79 Z1.994 F25
G1 X124.354 Y153.827 Z1.992 F25
G1 X124.282 Y153.858 Z1.989 F25
G1 X124.207 Y153.881 Z1.986 F25
G1 X124.13 Y153.897 Z1.983 F25
G1 X124.053 Y153.905 Z1.98 F25
G1 X123.974 Y153.906 Z1.978 F25
G1 X123.896 Y153.899 Z1.975 F25
G1 X123.819 Y153.884 Z1.972 F25
G1 X123.744 Y153.862 Z1.969 F25
G1 X123.671 Y153.833 Z1.967 F25
G1 X123.602 Y153.797 Z1.964 F25
G1 X123.536 Y153.754 Z1.961 F25
G1 X123.475 Y153.705 Z1.958 F25
G1 X123.419 Y153.65 Z1.956 F25
G1 X123.369 Y153.59 Z1.953 F25
G1 X123.325 Y153.525 Z1.95 F25
G1 X123.287 Y153.456 Z1.947 F25
G1 X123.256 Y153.384 Z1.944 F25
G1 X123.233 Y153.31 Z1.942 F25
G1 X123.217 Y153.233 Z1.939 F25
G1 X123.208 Y153.155 Z1.936 F25
G1 X123.207 Y153.077 Z1.933 F25
G1 X123.214 Y152.999 Z1.931 F25
G1 X123.229 Y152.922 Z1.928 F25
G1 X123.25 Y152.847 Z1.925 F25
G1 X123.28 Y152.774 Z1.922 F25
G1 X123.316 Y152.705 Z1.92 F25
G1 X123.358 Y152.639 Z1.917 F25
G1 X123.407 Y152.578 Z1.914 F25
G1 X123.462 Y152.522 Z1.911 F25
G1 X123.522 Y152.471 Z1.908 F25
G1 X123.586 Y152.427 Z1.906 F25
G1 X123.655 Y152.389 Z1.903 F25
G1 X123.727 Y152.358 Z1.9 F25
G1 X123.801 Y152.335 Z1.897 F25
G1 X123.878 Y152.318 Z1.895 F25
G1 X123.956 Y152.31 Z1.892 F25
G1 X124.034 Y152.309 Z1.889 F25
G1 X124.112 Y152.315 Z1.886 F25
G1 X124.189 Y152.329 Z1.884 F25
G1 X124.264 Y152.351 Z1.881 F25
G1 X124.336 Y152.38 Z1.878 F25
G1 X124.406 Y152.416 Z1.875 F25
G1 X124.472 Y152.458 Z1.872 F25
G1 X124.533 Y152.507 Z1.87 F25
G1 X124.589 Y152.561 Z1.867 F25
G1 X124.639 Y152.621 Z1.864 F25
G1 X124.684 Y152.685 Z1.861 F25
G1 X124.722 Y152.754 Z1.859 F25
G1 X124.753 Y152.825 Z1.856 F25
G1 X124.777 Y152.9 Z1.853 F25
G1 X124.793 Y152.976 Z1.85 F25
G1 X124.802 Y153.054 Z1.848 F25
G1 X124.803 Y153.132 Z1.845 F25
G1 X124.797 Y153.21 Z1.842 F25
G1 X124.783 Y153.287 Z1.839 F25
G1 X124.762 Y153.362 Z1.836 F25
G1 X124.733 Y153.435 Z1.834 F25
G1 X124.697 Y153.504 Z1.831 F25
G1 X124.655 Y153.57 Z1.828 F25
G1 X124.607 Y153.631 Z1.825 F25
G1 X124.553 Y153.687 Z1.823 F25
G1 X124.493 Y153.738 Z1.82 F25
G1 X124.429 Y153.783 Z1.817 F25
G1 X124.361 Y153.821 Z1.814 F25
G1 X124.289 Y153.852 Z1.812 F25
G1 X124.215 Y153.876 Z1.809 F25
G1 X124.139 Y153.893 Z1.806 F25
G1 X124.061 Y153.902 Z1.803 F25
G1 X123.983 Y153.903 Z1.8 F25
G1 X123.905 Y153.897 Z1.798 F25
G1 X123.828 Y153.883 Z1.795 F25
G1 X123.753 Y153.862 Z1.792 F25
G1 X123.68 Y153.834 Z1.789 F25
G1 X123.611 Y153.798 Z1.787 F25
G1 X123.545 Y153.756 Z1.784 F25
G1 X123.484 Y153.708 Z1.781 F25
G1 X123.427 Y153.654 Z1.778 F25
G1 X123.377 Y153.595 Z1.776 F25
G1 X123.332 Y153.531 Z1.773 F25
G1 X123.294 Y153.463 Z1.77 F25
G1 X123.262 Y153.391 Z1.767 F25
G1 X123.238 Y153.317 Z1.764 F25
G1 X123.221 Y153.241 Z1.762 F25
G1 X123.212 Y153.164 Z1.759 F25
G1 X123.21 Y153.086 Z1.756 F25
G1 X123.216 Y153.008 Z1.753 F25
G1 X123.23 Y152.931 Z1.751 F25
G1 X123.251 Y152.856 Z1.748 F25
G1 X123.279 Y152.783 Z1.745 F25
G1 X123.314 Y152.714 Z1.742 F25
G1 X123.356 Y152.648 Z1.739 F25
G1 X123.404 Y152.586 Z1.737 F25
G1 X123.458 Y152.53 Z1.734 F25
G1 X123.517 Y152.479 Z1.731 F25
G1 X123.581 Y152.434 Z1.728 F25
G1 X123.649 Y152.396 Z1.726 F25
G1 X123.72 Y152.364 Z1.723 F25
G1 X123.794 Y152.34 Z1.72 F25
G1 X123.87 Y152.323 Z1.717 F25
G1 X123.947 Y152.313 Z1.715 F25
G1 X124.025 Y152.311 Z1.712 F25
G1 X124.103 Y152.317 Z1.709 F25
G1 X124.179 Y152.33 Z1.706 F25
G1 X124.255 Y152.351 Z1.703 F25
G1 X124.327 Y152.379 Z1.701 F25
G1 X124.397 Y152.414 Z1.698 F25
G1 X124.463 Y152.456 Z1.695 F25
G1 X124.524 Y152.504 Z1.692 F25
G1 X124.581 Y152.557 Z1.69 F25
G1 X124.632 Y152.616 Z1.687 F25
G1 X124.677 Y152.68 Z1.684 F25
G1 X124.715 Y152.747 Z1.681 F25
G1 X124.747 Y152.819 Z1.679 F25
G1 X124.771 Y152.892 Z1.676 F25
G1 X124.789 Y152.968 Z1.673 F25
G1 X124.798 Y153.046 Z1.67 F25
G1 X124.801 Y153.124 Z1.667 F25
G1 X124.795 Y153.201 Z1.665 F25
G1 X124.782 Y153.278 Z1.662 F25
G1 X124.762 Y153.353 Z1.659 F25
G1 X124.734 Y153.426 Z1.656 F25
G1 X124.699 Y153.495 Z1.654 F25
G1 X124.658 Y153.561 Z1.651 F25
G1 X124.61 Y153.623 Z1.648 F25
G1 X124.557 Y153.679 Z1.645 F25
G1 X124.498 Y153.73 Z1.643 F25
G1 X124.435 Y153.775 Z1.64 F25
G1 X124.367 Y153.814 Z1.637 F25
G1 X124.296 Y153.846 Z1.634 F25
G1 X124.222 Y153.871 Z1.631 F25
G1 X124.147 Y153.888 Z1.629 F25
G1 X124.069 Y153.898 Z1.626 F25
G1 X123.992 Y153.9 Z1.623 F25
G1 X123.914 Y153.895 Z1.62 F25
G1 X123.837 Y153.882 Z1.618 F25
G1 X123.762 Y153.862 Z1.615 F25
G1 X123.689 Y153.834 Z1.612 F25
G1 X123.62 Y153.8 Z1.609 F25
G1 X123.554 Y153.759 Z1.607 F25
G1 X123.492 Y153.711 Z1.604 F25
G1 X123.436 Y153.658 Z1.601 F25
G1 X123.384 Y153.6 Z1.598 F25
G1 X123.339 Y153.536 Z1.595 F25
G1 X123.3 Y153.469 Z1.593 F25
G1 X123.268 Y153.398 Z1.59 F25
G1 X123.243 Y153.325 Z1.587 F25
G1 X123.226 Y153.249 Z1.584 F25
G1 X123.216 Y153.172 Z1.582 F25
G1 X123.213 Y153.094 Z1.579 F25
G1 X123.218 Y153.017 Z1.576 F25
G1 X123.231 Y152.94 Z1.573 F25
G1 X123.251 Y152.865 Z1.571 F25
G1 X123.278 Y152.792 Z1.568 F25
G1 X123.313 Y152.723 Z1.565 F25
G1 X123.353 Y152.657 Z1.562 F25
G1 X123.401 Y152.595 Z1.559 F25
G1 X123.454 Y152.538 Z1.557 F25
G1 X123.512 Y152.487 Z1.554 F25
G1 X123.575 Y152.441 Z1.551 F25
G1 X123.642 Y152.403 Z1.548 F25
G1 X123.713 Y152.37 Z1.546 F25
G1 X123.786 Y152.345 Z1.543 F25
G1 X123.862 Y152.327 Z1.54 F25
G1 X123.939 Y152.317 Z1.537 F25
G1 X124.016 Y152.314 Z1.535 F25
G1 X124.094 Y152.319 Z1.532 F25
G1 X124.17 Y152.332 Z1.529 F25
G1 X124.245 Y152.351 Z1.526 F25
G1 X124.318 Y152.379 Z1.523 F25
G1 X124.388 Y152.413 Z1.521 F25
G1 X124.454 Y152.453 Z1.518 F25
G1 X124.516 Y152.5 Z1.515 F25
G1 X124.572 Y152.553 Z1.512 F25
G1 X124.624 Y152.611 Z1.51 F25
G1 X124.669 Y152.674 Z1.507 F25
G1 X124.708 Y152.741 Z1.504 F25
G1 X124.741 Y152.812 Z1.501 F25
G1 X124.766 Y152.885 Z1.499 F25
G1 X124.784 Y152.961 Z1.496 F25
G1 X124.795 Y153.037 Z1.493 F25
G1 X124.798 Y153.115 Z1.49 F25
G1 X124.793 Y153.192 Z1.487 F25
G1 X124.781 Y153.269 Z1.485 F25
G1 X124.761 Y153.344 Z1.482 F25
G1 X124.734 Y153.416 Z1.479 F25
G1 X124.701 Y153.486 Z1.476 F25
G1 X124.66 Y153.552 Z1.474 F25
G1 X124.613 Y153.614 Z1.471 F25
G1 X124.561 Y153.671 Z1.468 F25
G1 X124.503 Y153.722 Z1.465 F25
G1 X124.44 Y153.768 Z1.463 F25
G1 X124.373 Y153.807 Z1.46 F25
G1 X124.303 Y153.84 Z1.457 F25
G1 X124.23 Y153.865 Z1.454 F25
G1 X124.154 Y153.883 Z1.451 F25
G1 X124.078 Y153.894 Z1.449 F25
G1 X124 Y153.897 Z1.446 F25
G1 X123.923 Y153.893 Z1.443 F25
G1 X123.846 Y153.881 Z1.44 F25
G1 X123.771 Y153.862 Z1.438 F25
G1 X123.698 Y153.835 Z1.435 F25
G1 X123.629 Y153.801 Z1.432 F25
G1 X123.563 Y153.761 Z1.429 F25
G1 X123.501 Y153.715 Z1.426 F25
G1 X123.444 Y153.662 Z1.424 F25
G1 X123.392 Y153.604 Z1.421 F25
G1 X123.347 Y153.542 Z1.418 F25
G1 X123.307 Y153.475 Z1.415 F25
G1 X123.274 Y153.405 Z1.413 F25
G1 X123.249 Y153.332 Z1.41 F25
G1 X123.23 Y153.257 Z1.407 F25
G1 X123.22 Y153.18 Z1.404 F25
G1 X123.216 Y153.103 Z1.402 F25
G1 X123.22 Y153.026 Z1.399 F25
G1 X123.232 Y152.949 Z1.396 F25
G1 X123.251 Y152.874 Z1.393 F25
G1 X123.278 Y152.802 Z1.39 F25
G1 X123.311 Y152.732 Z1.388 F25
G1 X123.351 Y152.665 Z1.385 F25
G1 X123.398 Y152.604 Z1.382 F25
G1 X123.45 Y152.546 Z1.379 F25
G1 X123.507 Y152.495 Z1.377 F25
G1 X123.57 Y152.449 Z1.374 F25
G1 X123.636 Y152.409 Z1.371 F25
G1 X123.706 Y152.376 Z1.368 F25
G1 X123.779 Y152.351 Z1.366 F25
G1 X123.854 Y152.332 Z1.363 F25
G1 X123.93 Y152.321 Z1.36 F25
G1 X124.008 Y152.317 Z1.357 F25
G1 X124.085 Y152.321 Z1.354 F25
G1 X124.161 Y152.333 Z1.352 F25
G1 X124.236 Y152.352 Z1.349 F25
G1 X124.309 Y152.378 Z1.346 F25
G1 X124.379 Y152.411 Z1.343 F25
G1 X124.445 Y152.451 Z1.341 F25
G1 X124.507 Y152.497 Z1.338 F25
G1 X124.564 Y152.549 Z1.335 F25
G1 X124.616 Y152.607 Z1.332 F25
G1 X124.662 Y152.669 Z1.33 F25
G1 X124.702 Y152.735 Z1.327 F25
G1 X124.735 Y152.805 Z1.324 F25
G1 X124.761 Y152.878 Z1.321 F25
G1 X124.779 Y152.953 Z1.318 F25
G1 X124.791 Y153.029 Z1.316 F25
G1 X124.795 Y153.106 Z1.313 F25
G1 X124.791 Y153.183 Z1.31 F25
G1 X124.78 Y153.26 Z1.307 F25
G1 X124.761 Y153.335 Z1.305 F25
G1 X124.735 Y153.407 Z1.302 F25
G1 X124.702 Y153.477 Z1.299 F25
G1 X124.662 Y153.543 Z1.296 F25
G1 X124.616 Y153.605 Z1.294 F25
G1 X124.565 Y153.663 Z1.291 F25
G1 X124.507 Y153.715 Z1.288 F25
G1 X124.446 Y153.761 Z1.285 F25
G1 X124.379 Y153.801 Z1.282 F25
G1 X124.31 Y153.834 Z1.28 F25
G1 X124.237 Y153.86 Z1.277 F25
G1 X124.162 Y153.879 Z1.274 F25
G1 X124.086 Y153.89 Z1.271 F25
G1 X124.009 Y153.894 Z1.269 F25
G1 X123.932 Y153.891 Z1.266 F25
G1 X123.855 Y153.88 Z1.263 F25
G1 X123.78 Y153.861 Z1.26 F25
G1 X123.708 Y153.835 Z1.258 F25
G1 X123.638 Y153.803 Z1.255 F25
G1 X123.572 Y153.763 Z1.252 F25
G1 X123.509 Y153.718 Z1.249 F25
G1 X123.452 Y153.666 Z1.246 F25
G1 X123.4 Y153.609 Z1.244 F25
G1 X123.354 Y153.547 Z1.241 F25
G1 X123.314 Y153.482 Z1.238 F25
G1 X123.281 Y153.412 Z1.235 F25
G1 X123.254 Y153.34 Z1.233 F25
G1 X123.235 Y153.265 Z1.23 F25
G1 X123.223 Y153.189 Z1.227 F25
G1 X123.219 Y153.112 Z1.224 F25
G1 X123.223 Y153.035 Z1.222 F25
G1 X123.233 Y152.958 Z1.219 F25
G1 X123.252 Y152.883 Z1.216 F25
G1 X123.277 Y152.811 Z1.213 F25
G1 X123.31 Y152.741 Z1.21 F25
G1 X123.349 Y152.674 Z1.208 F25
G1 X123.395 Y152.612 Z1.205 F25
G1 X123.446 Y152.555 Z1.202 F25
G1 X123.503 Y152.503 Z1.199 F25
G1 X123.564 Y152.456 Z1.197 F25
G1 X123.63 Y152.416 Z1.194 F25
G1 X123.699 Y152.383 Z1.191 F25
G1 X123.772 Y152.356 Z1.188 F25
G1 X123.846 Y152.337 Z1.186 F25
G1 X123.922 Y152.325 Z1.183 F25
G1 X123.999 Y152.321 Z1.18 F25
G1 X124.076 Y152.324 Z1.177 F25
G1 X124.152 Y152.334 Z1.174 F25
G1 X124.227 Y152.352 Z1.172 F25
G1 X124.3 Y152.378 Z1.169 F25
G1 X124.37 Y152.41 Z1.166 F25
G1 X124.436 Y152.449 Z1.163 F25
G1 X124.498 Y152.494 Z1.161 F25
G1 X124.556 Y152.545 Z1.158 F25
G1 X124.608 Y152.602 Z1.155 F25
G1 X124.655 Y152.663 Z1.152 F25
G1 X124.695 Y152.729 Z1.15 F25
G1 X124.729 Y152.798 Z1.147 F25
G1 X124.755 Y152.87 Z1.144 F25
G1 X124.775 Y152.945 Z1.141 F25
G1 X124.787 Y153.021 Z1.138 F25
G1 X124.791 Y153.098 Z1.136 F25
G1 X124.789 Y153.174 Z1.133 F25
G1 X124.778 Y153.251 Z1.13 F25
G1 X124.76 Y153.325 Z1.127 F25
G1 X124.735 Y153.398 Z1.125 F25
G1 X124.703 Y153.468 Z1.122 F25
G1 X124.664 Y153.534 Z1.119 F25
G1 X124.619 Y153.597 Z1.116 F25
G1 X124.568 Y153.654 Z1.114 F25
G1 X124.512 Y153.707 Z1.111 F25
G1 X124.451 Y153.753 Z1.108 F25
G1 X124.385 Y153.794 Z1.105 F25
G1 X124.316 Y153.827 Z1.102 F25
G1 X124.244 Y153.854 Z1.1 F25
G1 X124.17 Y153.874 Z1.097 F25
G1 X124.094 Y153.886 Z1.094 F25
G1 X124.017 Y153.891 Z1.091 F25
G1 X123.94 Y153.888 Z1.089 F25
G1 X123.864 Y153.878 Z1.086 F25
G1 X123.789 Y153.861 Z1.083 F25
G1 X123.717 Y153.836 Z1.08 F25
G1 X123.647 Y153.804 Z1.077 F25
G1 X123.58 Y153.765 Z1.075 F25
G1 X123.518 Y153.721 Z1.072 F25
G1 X123.46 Y153.67 Z1.069 F25
G1 X123.408 Y153.614 Z1.066 F25
G1 X123.361 Y153.553 Z1.064 F25
G1 X123.321 Y153.488 Z1.061 F25
G1 X123.287 Y153.419 Z1.058 F25
G1 X123.26 Y153.347 Z1.055 F25
G1 X123.24 Y153.273 Z1.053 F25
G1 X123.227 Y153.197 Z1.05 F25
G1 X123.222 Y153.12 Z1.047 F25
G1 X123.225 Y153.043 Z1.044 F25
G1 X123.235 Y152.967 Z1.041 F25
G1 X123.252 Y152.892 Z1.039 F25
G1 X123.277 Y152.82 Z1.036 F25
G1 X123.309 Y152.75 Z1.033 F25
G1 X123.347 Y152.683 Z1.03 F25
G1 X123.392 Y152.621 Z1.028 F25
G1 X123.442 Y152.563 Z1.025 F25
G1 X123.498 Y152.51 Z1.022 F25
G1 X123.559 Y152.464 Z1.019 F25
G1 X123.624 Y152.423 Z1.017 F25
G1 X123.693 Y152.389 Z1.014 F25
G1 X123.764 Y152.362 Z1.011 F25
G1 X123.838 Y152.342 Z1.008 F25
G1 X123.914 Y152.329 Z1.005 F25
G1 X123.991 Y152.324 Z1.003 F25
G1 X124.067 Y152.326 Z1 F25
G1 X124.143 Y152.336 Z0.997 F25
G1 X124.218 Y152.353 Z0.994 F25
G1 X124.291 Y152.377 Z0.992 F25
G1 X124.361 Y152.409 Z0.989 F25
G1 X124.427 Y152.447 Z0.986 F25
G1 X124.49 Y152.491 Z0.983 F25
G1 X124.548 Y152.542 Z0.981 F25
G1 X124.6 Y152.597 Z0.978 F25
G1 X124.647 Y152.658 Z0.975 F25
G1 X124.688 Y152.723 Z0.972 F25
G1 X124.722 Y152.792 Z0.969 F25
G1 X124.75 Y152.863 Z0.967 F25
G1 X124.77 Y152.937 Z0.964 F25
G1 X124.783 Y153.013 Z0.961 F25
G1 X124.788 Y153.089 Z0.958 F25
G1 X124.786 Y153.166 Z0.956 F25
G1 X124.777 Y153.242 Z0.953 F25
G1 X124.76 Y153.316 Z0.95 F25
G1 X124.735 Y153.389 Z0.947 F25
G1 X124.704 Y153.459 Z0.945 F25
G1 X124.666 Y153.526 Z0.942 F25
G1 X124.622 Y153.588 Z0.939 F25
G1 X124.572 Y153.646 Z0.936 F25
G1 X124.517 Y153.699 Z0.933 F25
G1 X124.456 Y153.746 Z0.931 F25
G1 X124.391 Y153.787 Z0.928 F25
G1 X124.323 Y153.821 Z0.925 F25
G1 X124.251 Y153.849 Z0.922 F25
G1 X124.178 Y153.869 Z0.92 F25
G1 X124.102 Y153.882 Z0.917 F25
G1 X124.026 Y153.888 Z0.914 F25
G1 X123.949 Y153.886 Z0.911 F25
G1 X123.873 Y153.877 Z0.909 F25
G1 X123.799 Y153.86 Z0.906 F25
G1 X123.726 Y153.836 Z0.903 F25
G1 X123.656 Y153.805 Z0.9 F25
G1 X123.589 Y153.767 Z0.897 F25
G1 X123.527 Y153.723 Z0.895 F25
G1 X123.469 Y153.674 Z0.892 F25
G1 X123.416 Y153.618 Z0.889 F25
G1 X123.369 Y153.558 Z0.886 F25
G1 X123.328 Y153.493 Z0.884 F25
G1 X123.293 Y153.425 Z0.881 F25
G1 X123.265 Y153.354 Z0.878 F25
G1 X123.245 Y153.28 Z0.875 F25
G1 X123.232 Y153.205 Z0.873 F25
G1 X123.226 Y153.129 Z0.87 F25
G1 X123.227 Y153.052 Z0.867 F25
G1 X123.237 Y152.976 Z0.864 F25
G1 X123.253 Y152.901 Z0.861 F25
G1 X123.277 Y152.829 Z0.859 F25
G1 X123.308 Y152.759 Z0.856 F25
G1 X123.345 Y152.692 Z0.853 F25
G1 X123.389 Y152.629 Z0.85 F25
G1 X123.438 Y152.571 Z0.848 F25
G1 X123.494 Y152.518 Z0.845 F25
G1 X123.554 Y152.471 Z0.842 F25
G1 X123.618 Y152.43 Z0.839 F25
G1 X123.686 Y152.395 Z0.837 F25
G1 X123.757 Y152.367 Z0.834 F25
G1 X123.831 Y152.347 Z0.831 F25
G1 X123.906 Y152.333 Z0.828 F25
G1 X123.982 Y152.327 Z0.825 F25
G1 X124.058 Y152.329 Z0.823 F25
G1 X124.134 Y152.337 Z0.82 F25
G1 X124.209 Y152.354 Z0.817 F25
G1 X124.282 Y152.377 Z0.814 F25
G1 X124.352 Y152.408 Z0.812 F25
G1 X124.418 Y152.445 Z0.809 F25
G1 X124.481 Y152.489 Z0.806 F25
G1 X124.539 Y152.538 Z0.803 F25
G1 X124.592 Y152.593 Z0.801 F25
G1 X124.64 Y152.653 Z0.798 F25
G1 X124.681 Y152.717 Z0.795 F25
G1 X124.716 Y152.785 Z0.792 F25
G1 X124.744 Y152.856 Z0.789 F25
G1 X124.765 Y152.929 Z0.787 F25
G1 X124.779 Y153.005 Z0.784 F25
G1 X124.785 Y153.081 Z0.781 F25
G1 X124.784 Y153.157 Z0.778 F25
G1 X124.775 Y153.233 Z0.776 F25
G1 X124.759 Y153.307 Z0.773 F25
G1 X124.736 Y153.38 Z0.77 F25
G1 X124.705 Y153.45 Z0.767 F25
G1 X124.668 Y153.517 Z0.764 F25
G1 X124.625 Y153.58 Z0.762 F25
G1 X124.576 Y153.638 Z0.759 F25
G1 X124.521 Y153.691 Z0.756 F25
G1 X124.461 Y153.738 Z0.753 F25
G1 X124.397 Y153.78 Z0.751 F25
G1 X124.329 Y153.815 Z0.748 F25
G1 X124.258 Y153.843 Z0.745 F25
G1 X124.185 Y153.864 Z0.742 F25
G1 X124.11 Y153.878 Z0.74 F25
G1 X124.034 Y153.885 Z0.737 F25
G1 X123.958 Y153.884 Z0.734 F25
G1 X123.882 Y153.875 Z0.731 F25
G1 X123.808 Y153.859 Z0.728 F25
G1 X123.735 Y153.836 Z0.726 F25
G1 X123.665 Y153.806 Z0.723 F25
G1 X123.598 Y153.769 Z0.72 F25
G1 X123.535 Y153.726 Z0.717 F25
G1 X123.477 Y153.677 Z0.715 F25
G1 X123.424 Y153.623 Z0.712 F25
G1 X123.376 Y153.563 Z0.709 F25
G1 X123.335 Y153.499 Z0.706 F25
G1 X123.299 Y153.432 Z0.704 F25
G1 X123.271 Y153.361 Z0.701 F25
G1 X123.25 Y153.288 Z0.698 F25
G1 X123.236 Y153.213 Z0.695 F25
G1 X123.229 Y153.137 Z0.692 F25
G1 X123.23 Y153.061 Z0.69 F25
G1 X123.238 Y152.985 Z0.687 F25
G1 X123.254 Y152.91 Z0.684 F25
G1 X123.277 Y152.838 Z0.681 F25
G1 X123.307 Y152.768 Z0.679 F25
G1 X123.343 Y152.701 Z0.676 F25
G1 X123.386 Y152.638 Z0.673 F25
G1 X123.435 Y152.58 Z0.67 F25
G1 X123.489 Y152.526 Z0.668 F25
G1 X123.548 Y152.479 Z0.665 F25
G1 X123.612 Y152.437 Z0.662 F25
G1 X123.68 Y152.402 Z0.659 F25
G1 X123.75 Y152.373 Z0.656 F25
G1 X123.823 Y152.352 Z0.654 F25
G1 X123.898 Y152.337 Z0.651 F25
G1 X123.974 Y152.331 Z0.648 F25
G1 X124.05 Z0.645 F25
G1 X124.126 Y152.339 Z0.643 F25
G1 X124.2 Y152.355 Z0.64 F25
G1 X124.273 Y152.377 Z0.637 F25
G1 X124.343 Y152.407 Z0.634 F25
G1 X124.41 Y152.443 Z0.632 F25
G1 X124.473 Y152.486 Z0.629 F25
G1 X124.531 Y152.535 Z0.626 F25
G1 X124.585 Y152.589 Z0.623 F25
G1 X124.632 Y152.648 Z0.62 F25
G1 X124.674 Y152.711 Z0.618 F25
G1 X124.71 Y152.779 Z0.615 F25
G1 X124.738 Y152.849 Z0.612 F25
G1 X124.76 Y152.922 Z0.609 F25
G1 X124.774 Y152.997 Z0.607 F25
G1 X124.781 Y153.072 Z0.604 F25
G1 Y153.148 Z0.601 F25
G1 X124.773 Y153.224 Z0.598 F25
G1 X124.758 Y153.298 Z0.596 F25
G1 X124.736 Y153.371 Z0.593 F25
G1 X124.706 Y153.441 Z0.59 F25
G1 X124.67 Y153.508 Z0.587 F25
G1 X124.628 Y153.571 Z0.584 F25
G1 X124.579 Y153.629 Z0.582 F25
G1 X124.525 Y153.683 Z0.579 F25
G1 X124.466 Y153.731 Z0.576 F25
G1 X124.403 Y153.773 Z0.573 F25
G1 X124.336 Y153.809 Z0.571 F25
G1 X124.265 Y153.837 Z0.568 F25
G1 X124.193 Y153.859 Z0.565 F25
G1 X124.118 Y153.874 Z0.562 F25
G1 X124.042 Y153.881 Z0.56 F25
G1 X123.967 Z0.557 F25
G1 X123.891 Y153.873 Z0.554 F25
G1 X123.817 Y153.858 Z0.551 F25
G1 X123.744 Y153.836 Z0.548 F25
G1 X123.674 Y153.807 Z0.546 F25
G1 X123.607 Y153.771 Z0.543 F25
G1 X123.544 Y153.729 Z0.54 F25
G1 X123.485 Y153.681 Z0.537 F25
G1 X123.432 Y153.627 Z0.535 F25
G1 X123.384 Y153.568 Z0.532 F25
G1 X123.342 Y153.505 Z0.529 F25
G1 X123.306 Y153.438 Z0.526 F25
G1 X123.277 Y153.368 Z0.524 F25
G1 X123.255 Y153.295 Z0.521 F25
G1 X123.24 Y153.221 Z0.518 F25
G1 X123.233 Y153.145 Z0.515 F25
G1 Y153.069 Z0.512 F25
G1 X123.24 Y152.994 Z0.51 F25
G1 X123.255 Y152.919 Z0.507 F25
G1 X123.277 Y152.847 Z0.504 F25
G1 X123.306 Y152.777 Z0.501 F25
G1 X123.341 Y152.71 Z0.499 F25
G1 X123.383 Y152.647 Z0.496 F25
G1 X123.431 Y152.588 Z0.493 F25
G1 X123.485 Y152.534 Z0.49 F25
G1 X123.544 Y152.486 Z0.488 F25
G1 X123.606 Y152.444 Z0.485 F25
G1 X123.673 Y152.408 Z0.482 F25
G1 X123.743 Y152.379 Z0.479 F25
G1 X123.816 Y152.357 Z0.476 F25
G1 X123.89 Y152.342 Z0.474 F25
G1 X123.965 Y152.334 Z0.471 F25
G1 X124.041 Z0.468 F25
G1 X124.117 Y152.341 Z0.465 F25
G1 X124.191 Y152.356 Z0.463 F25
G1 X124.264 Y152.377 Z0.46 F25
G1 X124.334 Y152.406 Z0.457 F25
G1 X124.401 Y152.442 Z0.454 F25
G1 X124.464 Y152.483 Z0.451 F25
G1 X124.523 Y152.531 Z0.449 F25
G1 X124.577 Y152.585 Z0.446 F25
G1 X124.625 Y152.643 Z0.443 F25
G1 X124.667 Y152.706 Z0.44 F25
G1 X124.703 Y152.772 Z0.438 F25
G1 X124.733 Y152.842 Z0.435 F25
G1 X124.755 Y152.914 Z0.432 F25
G1 X124.77 Y152.989 Z0.429 F25
G1 X124.778 Y153.064 Z0.427 F25
G1 Y153.14 Z0.424 F25
G1 X124.771 Y153.215 Z0.421 F25
G1 X124.757 Y153.289 Z0.418 F25
G1 X124.735 Y153.362 Z0.415 F25
G1 X124.707 Y153.432 Z0.413 F25
G1 X124.672 Y153.499 Z0.41 F25
G1 X124.63 Y153.562 Z0.407 F25
G1 X124.582 Y153.621 Z0.404 F25
G1 X124.529 Y153.675 Z0.402 F25
G1 X124.471 Y153.723 Z0.399 F25
G1 X124.408 Y153.766 Z0.396 F25
G1 X124.342 Y153.802 Z0.393 F25
G1 X124.272 Y153.832 Z0.391 F25
G1 X124.2 Y153.854 Z0.388 F25
G1 X124.126 Y153.87 Z0.385 F25
G1 X124.051 Y153.878 Z0.382 F25
G1 X123.975 Z0.379 F25
G1 X123.9 Y153.871 Z0.377 F25
G1 X123.826 Y153.857 Z0.374 F25
G1 X123.753 Y153.836 Z0.371 F25
G1 X123.683 Y153.808 Z0.368 F25
G1 X123.616 Y153.773 Z0.366 F25
G1 X123.553 Y153.731 Z0.363 F25
G1 X123.494 Y153.684 Z0.36 F25
G1 X123.44 Y153.631 Z0.357 F25
G1 X123.391 Y153.573 Z0.355 F25
G1 X123.349 Y153.51 Z0.352 F25
G1 X123.312 Y153.444 Z0.349 F25
G1 X123.283 Y153.375 Z0.346 F25
G1 X123.26 Y153.303 Z0.343 F25
G1 X123.244 Y153.229 Z0.341 F25
G1 X123.236 Y153.153 Z0.338 F25
G1 X123.235 Y153.078 Z0.335 F25
G1 X123.242 Y153.002 Z0.332 F25
G1 X123.256 Y152.928 Z0.33 F25
G1 X123.277 Y152.856 Z0.327 F25
G1 X123.305 Y152.786 Z0.324 F25
G1 X123.34 Y152.719 Z0.321 F25
G1 X123.381 Y152.655 Z0.319 F25
G1 X123.428 Y152.596 Z0.316 F25
G1 X123.481 Y152.542 Z0.313 F25
G1 X123.539 Y152.494 Z0.31 F25
G1 X123.601 Y152.451 Z0.307 F25
G1 X123.667 Y152.414 Z0.305 F25
G1 X123.736 Y152.385 Z0.302 F25
G1 X123.808 Y152.362 Z0.299 F25
G1 X123.882 Y152.346 Z0.296 F25
G1 X123.957 Y152.338 Z0.294 F25
G1 X124.033 Y152.337 Z0.291 F25
G1 X124.108 Y152.343 Z0.288 F25
G1 X124.182 Y152.357 Z0.285 F25
G1 X124.255 Y152.377 Z0.283 F25
G1 X124.325 Y152.405 Z0.28 F25
G1 X124.392 Y152.44 Z0.277 F25
G1 X124.455 Y152.481 Z0.274 F25
G1 X124.515 Y152.528 Z0.271 F25
G1 X124.569 Y152.581 Z0.269 F25
G1 X124.617 Y152.638 Z0.266 F25
G1 X124.66 Y152.7 Z0.263 F25
G1 X124.697 Y152.766 Z0.26 F25
G1 X124.727 Y152.835 Z0.258 F25
G1 X124.75 Y152.907 Z0.255 F25
G1 X124.766 Y152.981 Z0.252 F25
G1 X124.774 Y153.056 Z0.249 F25
G1 X124.776 Y153.131 Z0.247 F25
G1 X124.769 Y153.206 Z0.244 F25
G1 X124.756 Y153.28 Z0.241 F25
G1 X124.735 Y153.353 Z0.238 F25
G1 X124.708 Y153.423 Z0.235 F25
G1 X124.673 Y153.49 Z0.233 F25
G1 X124.632 Y153.554 Z0.23 F25
G1 X124.586 Y153.613 Z0.227 F25
G1 X124.533 Y153.667 Z0.224 F25
G1 X124.476 Y153.716 Z0.222 F25
G1 X124.414 Y153.759 Z0.219 F25
G1 X124.348 Y153.796 Z0.216 F25
G1 X124.279 Y153.826 Z0.213 F25
G1 X124.207 Y153.849 Z0.211 F25
G1 X124.134 Y153.865 Z0.208 F25
G1 X124.059 Y153.874 Z0.205 F25
G1 X123.984 Y153.875 Z0.202 F25
G1 X123.909 Y153.869 Z0.199 F25
G1 X123.834 Y153.856 Z0.197 F25
G1 X123.762 Y153.836 Z0.194 F25
G1 X123.692 Y153.808 Z0.191 F25
G1 X123.625 Y153.774 Z0.188 F25
G1 X123.561 Y153.734 Z0.186 F25
G1 X123.502 Y153.687 Z0.183 F25
G1 X123.448 Y153.635 Z0.18 F25
G1 X123.399 Y153.578 Z0.177 F25
G1 X123.356 Y153.516 Z0.175 F25
G1 X123.319 Y153.45 Z0.172 F25
G1 X123.288 Y153.381 Z0.169 F25
G1 X123.265 Y153.31 Z0.166 F25
G1 X123.249 Y153.236 Z0.163 F25
G1 X123.24 Y153.161 Z0.161 F25
G1 X123.238 Y153.086 Z0.158 F25
G1 X123.244 Y153.011 Z0.155 F25
G1 X123.257 Y152.937 Z0.152 F25
G1 X123.277 Y152.865 Z0.15 F25
G1 X123.304 Y152.794 Z0.147 F25
G1 X123.338 Y152.727 Z0.144 F25
G1 X123.379 Y152.664 Z0.141 F25
G1 X123.425 Y152.605 Z0.138 F25
G1 X123.477 Y152.55 Z0.136 F25
G1 X123.534 Y152.501 Z0.133 F25
G1 X123.595 Y152.458 Z0.13 F25
G1 X123.661 Y152.421 Z0.127 F25
G1 X123.73 Y152.39 Z0.125 F25
G1 X123.801 Y152.367 Z0.122 F25
G1 X123.874 Y152.35 Z0.119 F25
G1 X123.949 Y152.341 Z0.116 F25
G1 X124.024 Y152.339 Z0.114 F25
G1 X124.099 Y152.345 Z0.111 F25
G1 X124.173 Y152.358 Z0.108 F25
G1 X124.246 Y152.378 Z0.105 F25
G1 X124.316 Y152.405 Z0.102 F25
G1 X124.383 Y152.439 Z0.1 F25
G1 X124.447 Y152.479 Z0.097 F25
G1 X124.506 Y152.525 Z0.094 F25
G1 X124.561 Y152.577 Z0.091 F25
G1 X124.61 Y152.633 Z0.089 F25
G1 X124.653 Y152.695 Z0.086 F25
G1 X124.69 Y152.76 Z0.083 F25
G1 X124.721 Y152.829 Z0.08 F25
G1 X124.745 Y152.9 Z0.078 F25
G1 X124.761 Y152.973 Z0.075 F25
G1 X124.771 Y153.048 Z0.072 F25
G1 X124.773 Y153.123 Z0.069 F25
G1 X124.767 Y153.198 Z0.066 F25
G1 X124.755 Y153.272 Z0.064 F25
G1 X124.735 Y153.344 Z0.061 F25
G1 X124.708 Y153.414 Z0.058 F25
G1 X124.675 Y153.481 Z0.055 F25
G1 X124.635 Y153.545 Z0.053 F25
G1 X124.589 Y153.605 Z0.05 F25
G1 X124.537 Y153.659 Z0.047 F25
G1 X124.481 Y153.708 Z0.044 F25
G1 X124.419 Y153.752 Z0.042 F25
G1 X124.354 Y153.789 Z0.039 F25
G1 X124.286 Y153.82 Z0.036 F25
G1 X124.215 Y153.844 Z0.033 F25
G1 X124.141 Y153.861 Z0.03 F25
G1 X124.067 Y153.87 Z0.028 F25
G1 X123.992 Y153.873 Z0.025 F25
G1 X123.917 Y153.867 Z0.022 F25
G1 X123.843 Y153.855 Z0.019 F25
G1 X123.771 Y153.835 Z0.017 F25
G1 X123.701 Y153.809 Z0.014 F25
G1 X123.634 Y153.776 Z0.011 F25
G1 X123.57 Y153.736 Z0.008 F25
G1 X123.51 Y153.69 Z0.006 F25
G1 X123.456 Y153.639 Z0.003 F25
G1 X123.406 Y153.582 Z0 F25
G1 X123.363 Y153.521 Z-0.003 F25
G1 X123.325 Y153.456 Z-0.006 F25
G1 X123.294 Y153.388 Z-0.008 F25
G1 X123.27 Y153.317 Z-0.011 F25
G1 X123.253 Y153.244 Z-0.014 F25
G1 X123.243 Y153.17 Z-0.017 F25
G1 X123.241 Y153.095 Z-0.019 F25
G1 X123.246 Y153.02 Z-0.022 F25
G1 X123.258 Y152.946 Z-0.025 F25
G1 X123.277 Y152.874 Z-0.028 F25
G1 X123.304 Y152.803 Z-0.03 F25
G1 X123.337 Y152.736 Z-0.033 F25
G1 X123.376 Y152.673 Z-0.036 F25
G1 X123.422 Y152.613 Z-0.039 F25
G1 X123.473 Y152.558 Z-0.042 F25
G1 X123.529 Y152.509 Z-0.044 F25
G1 X123.59 Y152.465 Z-0.047 F25
G1 X123.655 Y152.427 Z-0.05 F25
G1 X123.723 Y152.396 Z-0.053 F25
G1 X123.794 Y152.372 Z-0.055 F25
G1 X123.867 Y152.355 Z-0.058 F25
G1 X123.941 Y152.345 Z-0.061 F25
G1 X124.016 Y152.342 Z-0.064 F25
G1 X124.091 Y152.347 Z-0.066 F25
G1 X124.165 Y152.359 Z-0.069 F25
G1 X124.237 Y152.378 Z-0.072 F25
G1 X124.307 Y152.404 Z-0.075 F25
G1 X124.375 Y152.437 Z-0.078 F25
G1 X124.438 Y152.476 Z-0.08 F25
G1 X124.498 Y152.522 Z-0.083 F25
G1 X124.553 Y152.573 Z-0.086 F25
G1 X124.602 Y152.629 Z-0.089 F25
G1 X124.646 Y152.689 Z-0.091 F25
G1 X124.684 Y152.754 Z-0.094 F25
G1 X124.715 Y152.822 Z-0.097 F25
G1 X124.739 Y152.893 Z-0.1 F25
G1 X124.757 Y152.965 Z-0.102 F25
G1 X124.767 Y153.04 Z-0.105 F25
G1 X124.77 Y153.114 Z-0.108 F25
G1 X124.765 Y153.189 Z-0.111 F25
G1 X124.753 Y153.263 Z-0.114 F25
G1 X124.735 Y153.335 Z-0.116 F25
G1 X124.709 Y153.405 Z-0.119 F25
G1 X124.676 Y153.473 Z-0.122 F25
G1 X124.637 Y153.537 Z-0.125 F25
G1 X124.592 Y153.596 Z-0.127 F25
G1 X124.541 Y153.651 Z-0.13 F25
G1 X124.485 Y153.701 Z-0.133 F25
G1 X124.425 Y153.745 Z-0.136 F25
G1 X124.36 Y153.783 Z-0.138 F25
G1 X124.292 Y153.814 Z-0.141 F25
G1 X124.222 Y153.839 Z-0.144 F25
G1 X124.149 Y153.856 Z-0.147 F25
G1 X124.075 Y153.866 Z-0.15 F25
G1 X124.001 Y153.87 Z-0.152 F25
G1 X123.926 Y153.865 Z-0.155 F25
G1 X123.852 Y153.854 Z-0.158 F25
G1 X123.78 Y153.835 Z-0.161 F25
G1 X123.71 Y153.809 Z-0.163 F25
G1 X123.642 Y153.777 Z-0.166 F25
G1 X123.578 Y153.738 Z-0.169 F25
G1 X123.519 Y153.693 Z-0.172 F25
G1 X123.464 Y153.643 Z-0.175 F25
G1 X123.414 Y153.587 Z-0.177 F25
G1 X123.37 Y153.527 Z-0.18 F25
G1 X123.332 Y153.462 Z-0.183 F25
G1 X123.3 Y153.395 Z-0.186 F25
G1 X123.276 Y153.324 Z-0.188 F25
G1 X123.258 Y153.251 Z-0.191 F25
G1 X123.247 Y153.177 Z-0.194 F25
G1 X123.244 Y153.103 Z-0.197 F25
G1 X123.248 Y153.028 Z-0.199 F25
G1 X123.259 Y152.955 Z-0.202 F25
G1 X123.278 Y152.882 Z-0.205 F25
G1 X123.303 Y152.812 Z-0.208 F25
G1 X123.336 Y152.745 Z-0.211 F25
G1 X123.374 Y152.681 Z-0.213 F25
G1 X123.419 Y152.621 Z-0.216 F25
G1 X123.469 Y152.566 Z-0.219 F25
G1 X123.525 Y152.516 Z-0.222 F25
G1 X123.585 Y152.472 Z-0.224 F25
G1 X123.649 Y152.434 Z-0.227 F25
G1 X123.716 Y152.402 Z-0.23 F25
G1 X123.787 Y152.377 Z-0.233 F25
G1 X123.859 Y152.36 Z-0.235 F25
G1 X123.933 Y152.349 Z-0.238 F25
G1 X124.008 Y152.345 Z-0.241 F25
G1 X124.082 Y152.349 Z-0.244 F25
G1 X124.156 Y152.36 Z-0.247 F25
G1 X124.228 Y152.379 Z-0.249 F25
G1 X124.298 Y152.404 Z-0.252 F25
G1 X124.366 Y152.436 Z-0.255 F25
G1 X124.43 Y152.474 Z-0.258 F25
G1 X124.489 Y152.519 Z-0.26 F25
G1 X124.545 Y152.569 Z-0.263 F25
G1 X124.595 Y152.624 Z-0.266 F25
G1 X124.639 Y152.684 Z-0.269 F25
G1 X124.677 Y152.748 Z-0.271 F25
G1 X124.709 Y152.815 Z-0.274 F25
G1 X124.734 Y152.886 Z-0.277 F25
G1 X124.752 Y152.958 Z-0.28 F25
G1 X124.763 Y153.032 Z-0.283 F25
G1 X124.767 Y153.106 Z-0.285 F25
G1 X124.763 Y153.18 Z-0.288 F25
G1 X124.752 Y153.254 Z-0.291 F25
G1 X124.734 Y153.326 Z-0.294 F25
G1 X124.709 Y153.397 Z-0.296 F25
G1 X124.677 Y153.464 Z-0.299 F25
G1 X124.639 Y153.528 Z-0.302 F25
G1 X124.595 Y153.588 Z-0.305 F25
G1 X124.545 Y153.643 Z-0.307 F25
G1 X124.49 Y153.693 Z-0.31 F25
G1 X124.43 Y153.738 Z-0.313 F25
G1 X124.366 Y153.776 Z-0.316 F25
G1 X124.299 Y153.808 Z-0.319 F25
G1 X124.229 Y153.833 Z-0.321 F25
G1 X124.157 Y153.851 Z-0.324 F25
G1 X124.083 Y153.863 Z-0.327 F25
G1 X124.009 Y153.866 Z-0.33 F25
G1 X123.934 Y153.863 Z-0.332 F25
G1 X123.861 Y153.852 Z-0.335 F25
G1 X123.789 Y153.834 Z-0.338 F25
G1 X123.718 Y153.81 Z-0.341 F25
G1 X123.651 Y153.778 Z-0.343 F25
G1 X123.587 Y153.74 Z-0.346 F25
G1 X123.527 Y153.696 Z-0.349 F25
G1 X123.472 Y153.646 Z-0.352 F25
G1 X123.422 Y153.591 Z-0.355 F25
G1 X123.377 Y153.532 Z-0.357 F25
G1 X123.338 Y153.468 Z-0.36 F25
G1 X123.306 Y153.401 Z-0.363 F25
G1 X123.281 Y153.331 Z-0.366 F25
G1 X123.262 Y153.259 Z-0.368 F25
G1 X123.251 Y153.185 Z-0.371 F25
G1 X123.247 Y153.111 Z-0.374 F25
G1 X123.25 Y153.037 Z-0.377 F25
G1 X123.261 Y152.963 Z-0.379 F25
G1 X123.278 Y152.891 Z-0.382 F25
G1 X123.303 Y152.821 Z-0.385 F25
G1 X123.334 Y152.754 Z-0.388 F25
G1 X123.372 Y152.69 Z-0.391 F25
G1 X123.416 Y152.63 Z-0.393 F25
G1 X123.466 Y152.574 Z-0.396 F25
G1 X123.52 Y152.524 Z-0.399 F25
G1 X123.58 Y152.479 Z-0.402 F25
G1 X123.643 Y152.441 Z-0.404 F25
G1 X123.71 Y152.408 Z-0.407 F25
G1 X123.78 Y152.383 Z-0.41 F25
G1 X123.852 Y152.364 Z-0.413 F25
G1 X123.925 Y152.353 Z-0.415 F25
G1 X123.999 Y152.348 Z-0.418 F25
G1 X124.074 Y152.352 Z-0.421 F25
G1 X124.147 Y152.362 Z-0.424 F25
G1 X124.22 Y152.379 Z-0.427 F25
G1 X124.29 Y152.404 Z-0.429 F25
G1 X124.357 Y152.435 Z-0.432 F25
G1 X124.421 Y152.472 Z-0.435 F25
G1 X124.481 Y152.516 Z-0.438 F25
G1 X124.536 Y152.565 Z-0.44 F25
G1 X124.587 Y152.62 Z-0.443 F25
G1 X124.632 Y152.679 Z-0.446 F25
G1 X124.67 Y152.742 Z-0.449 F25
G1 X124.703 Y152.809 Z-0.451 F25
G1 X124.729 Y152.879 Z-0.454 F25
G1 X124.747 Y152.95 Z-0.457 F25
G1 X124.759 Y153.024 Z-0.46 F25
G1 X124.763 Y153.098 Z-0.463 F25
G1 X124.761 Y153.172 Z-0.465 F25
G1 X124.751 Y153.245 Z-0.468 F25
G1 X124.733 Y153.318 Z-0.471 F25
G1 X124.709 Y153.388 Z-0.474 F25
G1 X124.678 Y153.455 Z-0.476 F25
G1 X124.641 Y153.519 Z-0.479 F25
G1 X124.597 Y153.58 Z-0.482 F25
G1 X124.548 Y153.635 Z-0.485 F25
G1 X124.494 Y153.686 Z-0.488 F25
G1 X124.435 Y153.73 Z-0.49 F25
G1 X124.372 Y153.769 Z-0.493 F25
G1 X124.305 Y153.802 Z-0.496 F25
G1 X124.236 Y153.828 Z-0.499 F25
G1 X124.164 Y153.847 Z-0.501 F25
G1 X124.091 Y153.859 Z-0.504 F25
G1 X124.017 Y153.863 Z-0.507 F25
G1 X123.943 Y153.861 Z-0.51 F25
G1 X123.87 Y153.851 Z-0.512 F25
G1 X123.797 Y153.834 Z-0.515 F25
G1 X123.727 Y153.81 Z-0.518 F25
G1 X123.66 Y153.779 Z-0.521 F25
G1 X123.596 Y153.742 Z-0.524 F25
G1 X123.536 Y153.699 Z-0.526 F25
G1 X123.48 Y153.65 Z-0.529 F25
G1 X123.429 Y153.596 Z-0.532 F25
G1 X123.384 Y153.537 Z-0.535 F25
G1 X123.345 Y153.474 Z-0.537 F25
G1 X123.312 Y153.407 Z-0.54 F25
G1 X123.286 Y153.338 Z-0.543 F25
G1 X123.266 Y153.263 Z-0.546 F25
G1 X123.254 Y153.186 Z-0.549 F25
G1 X123.25 Y153.108 Z-0.552 F25
G1 X123.254 Y153.031 Z-0.555 F25
G1 X123.266 Y152.954 Z-0.557 F25
G1 X123.286 Y152.879 Z-0.56 F25
G1 X123.313 Y152.806 Z-0.563 F25
G1 X123.347 Y152.736 Z-0.566 F25
G1 X123.389 Y152.671 Z-0.569 F25
G1 X123.437 Y152.61 Z-0.572 F25
G1 X123.491 Y152.554 Z-0.575 F25
G1 X123.551 Y152.504 Z-0.578 F25
G1 X123.615 Y152.46 Z-0.581 F25
G1 X123.684 Y152.424 Z-0.584 F25
G1 X123.755 Y152.394 Z-0.587 F25
G1 X123.83 Y152.372 Z-0.589 F25
G1 X123.906 Y152.358 Z-0.592 F25
G1 X123.984 Y152.352 Z-0.595 F25
G1 X124.062 Y152.354 Z-0.598 F25
G1 X124.139 Y152.363 Z-0.601 F25
G1 X124.214 Y152.381 Z-0.604 F25
G1 X124.288 Y152.406 Z-0.607 F25
G1 X124.358 Y152.439 Z-0.61 F25
G1 X124.425 Y152.478 Z-0.613 F25
G1 X124.487 Y152.525 Z-0.616 F25
G1 X124.544 Y152.577 Z-0.619 F25
G1 X124.596 Y152.635 Z-0.621 F25
G1 X124.641 Y152.698 Z-0.624 F25
G1 X124.679 Y152.766 Z-0.627 F25
G1 X124.711 Y152.837 Z-0.63 F25
G1 X124.735 Y152.911 Z-0.633 F25
G1 X124.751 Y152.987 Z-0.636 F25
G1 X124.759 Y153.064 Z-0.639 F25
G1 X124.76 Y153.141 Z-0.642 F25
G1 X124.752 Y153.219 Z-0.645 F25
G1 X124.736 Y153.295 Z-0.648 F25
G1 X124.713 Y153.369 Z-0.651 F25
G1 X124.683 Y153.44 Z-0.653 F25
G1 X124.645 Y153.508 Z-0.656 F25
G1 X124.6 Y153.571 Z-0.659 F25
G1 X124.549 Y153.63 Z-0.662 F25
G1 X124.493 Y153.683 Z-0.665 F25
G1 X124.431 Y153.73 Z-0.668 F25
G1 X124.365 Y153.77 Z-0.671 F25
G1 X124.295 Y153.803 Z-0.674 F25
G1 X124.222 Y153.829 Z-0.677 F25
G1 X124.146 Y153.847 Z-0.68 F25
G1 X124.069 Y153.858 Z-0.683 F25
G1 X123.992 Y153.86 Z-0.685 F25
G1 X123.915 Y153.855 Z-0.688 F25
G1 X123.838 Y153.841 Z-0.691 F25
G1 X123.764 Y153.82 Z-0.694 F25
G1 X123.692 Y153.791 Z-0.697 F25
G1 X123.623 Y153.755 Z-0.7 F25
G1 X123.559 Y153.712 Z-0.703 F25
G1 X123.499 Y153.663 Z-0.706 F25
G1 X123.444 Y153.608 Z-0.709 F25
G1 X123.396 Y153.548 Z-0.712 F25
G1 X123.354 Y153.483 Z-0.714 F25
G1 X123.318 Y153.414 Z-0.717 F25
G1 X123.291 Y153.341 Z-0.72 F25
G1 X123.27 Y153.267 Z-0.723 F25
G1 X123.258 Y153.19 Z-0.726 F25
G1 X123.253 Y153.113 Z-0.729 F25
G1 X123.257 Y153.036 Z-0.732 F25
G1 X123.268 Y152.959 Z-0.735 F25
G1 X123.287 Y152.884 Z-0.738 F25
G1 X123.314 Y152.811 Z-0.741 F25
G1 X123.348 Y152.742 Z-0.744 F25
G1 X123.389 Y152.676 Z-0.746 F25
G1 X123.436 Y152.615 Z-0.749 F25
G1 X123.49 Y152.559 Z-0.752 F25
G1 X123.549 Y152.509 Z-0.755 F25
G1 X123.613 Y152.465 Z-0.758 F25
G1 X123.681 Y152.428 Z-0.761 F25
G1 X123.752 Y152.399 Z-0.764 F25
G1 X123.826 Y152.376 Z-0.767 F25
G1 X123.902 Y152.362 Z-0.77 F25
G1 X123.979 Y152.355 Z-0.773 F25
G1 X124.057 Y152.356 Z-0.776 F25
G1 X124.134 Y152.366 Z-0.778 F25
G1 X124.209 Y152.383 Z-0.781 F25
G1 X124.282 Y152.407 Z-0.784 F25
G1 X124.353 Y152.439 Z-0.787 F25
G1 X124.419 Y152.479 Z-0.79 F25
G1 X124.482 Y152.524 Z-0.793 F25
G1 X124.539 Y152.576 Z-0.796 F25
G1 X124.59 Y152.634 Z-0.799 F25
G1 X124.636 Y152.696 Z-0.802 F25
G1 X124.675 Y152.763 Z-0.805 F25
G1 X124.706 Y152.834 Z-0.808 F25
G1 X124.731 Y152.907 Z-0.81 F25
G1 X124.747 Y152.983 Z-0.813 F25
G1 X124.756 Y153.059 Z-0.816 F25
G1 X124.757 Y153.137 Z-0.819 F25
G1 X124.75 Y153.214 Z-0.822 F25
G1 X124.735 Y153.29 Z-0.825 F25
G1 X124.712 Y153.363 Z-0.828 F25
G1 X124.682 Y153.435 Z-0.831 F25
G1 X124.644 Y153.502 Z-0.834 F25
G1 X124.6 Y153.566 Z-0.837 F25
G1 X124.55 Y153.624 Z-0.84 F25
G1 X124.494 Y153.677 Z-0.842 F25
G1 X124.433 Y153.724 Z-0.845 F25
G1 X124.367 Y153.765 Z-0.848 F25
G1 X124.298 Y153.798 Z-0.851 F25
G1 X124.225 Y153.825 Z-0.854 F25
G1 X124.15 Y153.843 Z-0.857 F25
G1 X124.074 Y153.854 Z-0.86 F25
G1 X123.997 Y153.857 Z-0.863 F25
G1 X123.92 Y153.852 Z-0.866 F25
G1 X123.843 Y153.839 Z-0.869 F25
G1 X123.769 Y153.819 Z-0.872 F25
G1 X123.697 Y153.79 Z-0.874 F25
G1 X123.629 Y153.755 Z-0.877 F25
G1 X123.564 Y153.713 Z-0.88 F25
G1 X123.504 Y153.664 Z-0.883 F25
G1 X123.45 Y153.609 Z-0.886 F25
G1 X123.401 Y153.549 Z-0.889 F25
G1 X123.359 Y153.485 Z-0.892 F25
G1 X123.323 Y153.416 Z-0.895 F25
G1 X123.295 Y153.345 Z-0.898 F25
G1 X123.274 Y153.27 Z-0.901 F25
G1 X123.261 Y153.194 Z-0.904 F25
G1 X123.256 Y153.117 Z-0.906 F25
G1 X123.259 Y153.04 Z-0.909 F25
G1 X123.27 Y152.964 Z-0.912 F25
G1 X123.289 Y152.889 Z-0.915 F25
G1 X123.315 Y152.817 Z-0.918 F25
G1 X123.348 Y152.747 Z-0.921 F25
G1 X123.389 Y152.682 Z-0.924 F25
G1 X123.436 Y152.621 Z-0.927 F25
G1 X123.489 Y152.565 Z-0.93 F25
G1 X123.547 Y152.514 Z-0.933 F25
G1 X123.611 Y152.47 Z-0.936 F25
G1 X123.678 Y152.433 Z-0.938 F25
G1 X123.749 Y152.403 Z-0.941 F25
G1 X123.823 Y152.38 Z-0.944 F25
G1 X123.898 Y152.365 Z-0.947 F25
G1 X123.975 Y152.358 Z-0.95 F25
G1 X124.052 Y152.359 Z-0.953 F25
G1 X124.129 Y152.368 Z-0.956 F25
G1 X124.204 Y152.384 Z-0.959 F25
G1 X124.277 Y152.409 Z-0.962 F25
G1 X124.347 Y152.44 Z-0.965 F25
G1 X124.414 Y152.479 Z-0.968 F25
G1 X124.476 Y152.524 Z-0.97 F25
G1 X124.533 Y152.575 Z-0.973 F25
G1 X124.585 Y152.632 Z-0.976 F25
G1 X124.631 Y152.694 Z-0.979 F25
G1 X124.67 Y152.761 Z-0.982 F25
G1 X124.702 Y152.831 Z-0.985 F25
G1 X124.726 Y152.904 Z-0.988 F25
G1 X124.743 Y152.979 Z-0.991 F25
G1 X124.752 Y153.055 Z-0.994 F25
G1 X124.754 Y153.132 Z-0.997 F25
G1 X124.747 Y153.209 Z-1 F25
G1 X124.733 Y153.284 Z-1.002 F25
G1 X124.711 Y153.358 Z-1.005 F25
G1 X124.681 Y153.429 Z-1.008 F25
G1 X124.644 Y153.497 Z-1.011 F25
G1 X124.601 Y153.56 Z-1.014 F25
G1 X124.551 Y153.619 Z-1.017 F25
G1 X124.495 Y153.672 Z-1.02 F25
G1 X124.435 Y153.719 Z-1.023 F25
G1 X124.37 Y153.76 Z-1.026 F25
G1 X124.301 Y153.794 Z-1.029 F25
G1 X124.228 Y153.82 Z-1.032 F25
G1 X124.154 Y153.839 Z-1.034 F25
G1 X124.078 Y153.851 Z-1.037 F25
G1 X124.001 Y153.854 Z-1.04 F25
G1 X123.924 Y153.849 Z-1.043 F25
G1 X123.848 Y153.837 Z-1.046 F25
G1 X123.774 Y153.817 Z-1.049 F25
G1 X123.703 Y153.789 Z-1.052 F25
G1 X123.634 Y153.754 Z-1.055 F25
G1 X123.569 Y153.713 Z-1.058 F25
G1 X123.509 Y153.665 Z-1.061 F25
G1 X123.455 Y153.611 Z-1.064 F25
G1 X123.406 Y153.551 Z-1.066 F25
G1 X123.363 Y153.487 Z-1.069 F25
G1 X123.328 Y153.419 Z-1.072 F25
G1 X123.299 Y153.348 Z-1.075 F25
G1 X123.278 Y153.274 Z-1.078 F25
G1 X123.265 Y153.198 Z-1.081 F25
G1 X123.26 Y153.122 Z-1.084 F25
G1 X123.262 Y153.045 Z-1.087 F25
G1 X123.272 Y152.969 Z-1.09 F25
G1 X123.29 Y152.894 Z-1.093 F25
G1 X123.316 Y152.822 Z-1.095 F25
G1 X123.349 Y152.753 Z-1.098 F25
G1 X123.389 Y152.687 Z-1.101 F25
G1 X123.435 Y152.626 Z-1.104 F25
G1 X123.488 Y152.57 Z-1.107 F25
G1 X123.546 Y152.52 Z-1.11 F25
G1 X123.609 Y152.475 Z-1.113 F25
G1 X123.676 Y152.438 Z-1.116 F25
G1 X123.746 Y152.407 Z-1.119 F25
G1 X123.819 Y152.385 Z-1.122 F25
G1 X123.894 Y152.369 Z-1.125 F25
G1 X123.971 Y152.362 Z-1.127 F25
G1 X124.047 Z-1.13 F25
G1 X124.124 Y152.37 Z-1.133 F25
G1 X124.199 Y152.386 Z-1.136 F25
G1 X124.272 Y152.41 Z-1.139 F25
G1 X124.342 Y152.441 Z-1.142 F25
G1 X124.408 Y152.479 Z-1.145 F25
G1 X124.471 Y152.524 Z-1.148 F25
G1 X124.528 Y152.574 Z-1.151 F25
G1 X124.58 Y152.631 Z-1.154 F25
G1 X124.626 Y152.692 Z-1.157 F25
G1 X124.665 Y152.758 Z-1.159 F25
G1 X124.697 Y152.828 Z-1.162 F25
G1 X124.722 Y152.9 Z-1.165 F25
G1 X124.739 Y152.975 Z-1.168 F25
G1 X124.749 Y153.051 Z-1.171 F25
G1 X124.751 Y153.128 Z-1.174 F25
G1 X124.745 Y153.204 Z-1.177 F25
G1 X124.731 Y153.279 Z-1.18 F25
G1 X124.709 Y153.353 Z-1.183 F25
G1 X124.68 Y153.424 Z-1.186 F25
G1 X124.644 Y153.491 Z-1.189 F25
G1 X124.601 Y153.555 Z-1.191 F25
G1 X124.552 Y153.613 Z-1.194 F25
G1 X124.497 Y153.667 Z-1.197 F25
G1 X124.437 Y153.714 Z-1.2 F25
G1 X124.372 Y153.755 Z-1.203 F25
G1 X124.303 Y153.789 Z-1.206 F25
G1 X124.232 Y153.816 Z-1.209 F25
G1 X124.158 Y153.835 Z-1.212 F25
G1 X124.082 Y153.847 Z-1.215 F25
G1 X124.006 Y153.851 Z-1.218 F25
G1 X123.929 Y153.847 Z-1.221 F25
G1 X123.853 Y153.835 Z-1.223 F25
G1 X123.779 Y153.815 Z-1.226 F25
G1 X123.708 Y153.788 Z-1.229 F25
G1 X123.639 Y153.754 Z-1.232 F25
G1 X123.575 Y153.713 Z-1.235 F25
G1 X123.515 Y153.665 Z-1.238 F25
G1 X123.46 Y153.612 Z-1.241 F25
G1 X123.411 Y153.553 Z-1.244 F25
G1 X123.368 Y153.49 Z-1.247 F25
G1 X123.333 Y153.422 Z-1.25 F25
G1 X123.304 Y153.351 Z-1.253 F25
G1 X123.282 Y153.278 Z-1.255 F25
G1 X123.269 Y153.203 Z-1.258 F25
G1 X123.263 Y153.126 Z-1.261 F25
G1 X123.265 Y153.05 Z-1.264 F25
G1 X123.275 Y152.974 Z-1.267 F25
G1 X123.292 Y152.9 Z-1.27 F25
G1 X123.317 Y152.827 Z-1.273 F25
G1 X123.35 Y152.758 Z-1.276 F25
G1 X123.389 Y152.693 Z-1.279 F25
G1 X123.435 Y152.631 Z-1.282 F25
G1 X123.487 Y152.575 Z-1.285 F25
G1 X123.544 Y152.525 Z-1.287 F25
G1 X123.606 Y152.48 Z-1.29 F25
G1 X123.673 Y152.443 Z-1.293 F25
G1 X123.743 Y152.412 Z-1.296 F25
G1 X123.816 Y152.389 Z-1.299 F25
G1 X123.891 Y152.373 Z-1.302 F25
G1 X123.966 Y152.365 Z-1.305 F25
G1 X124.043 Z-1.308 F25
G1 X124.119 Y152.373 Z-1.311 F25
G1 X124.194 Y152.388 Z-1.314 F25
G1 X124.266 Y152.411 Z-1.317 F25
G1 X124.336 Y152.442 Z-1.319 F25
G1 X124.403 Y152.479 Z-1.322 F25
G1 X124.465 Y152.523 Z-1.325 F25
G1 X124.523 Y152.573 Z-1.328 F25
G1 X124.575 Y152.629 Z-1.331 F25
G1 X124.621 Y152.69 Z-1.334 F25
G1 X124.66 Y152.756 Z-1.337 F25
G1 X124.693 Y152.825 Z-1.34 F25
G1 X124.718 Y152.897 Z-1.343 F25
G1 X124.736 Y152.971 Z-1.346 F25
G1 X124.746 Y153.047 Z-1.349 F25
G1 X124.748 Y153.123 Z-1.351 F25
G1 X124.742 Y153.199 Z-1.354 F25
G1 X124.729 Y153.274 Z-1.357 F25
G1 X124.708 Y153.348 Z-1.36 F25
G1 X124.679 Y153.418 Z-1.363 F25
G1 X124.644 Y153.486 Z-1.366 F25
G1 X124.601 Y153.549 Z-1.369 F25
G1 X124.553 Y153.608 Z-1.372 F25
G1 X124.498 Y153.661 Z-1.375 F25
G1 X124.439 Y153.709 Z-1.378 F25
G1 X124.374 Y153.75 Z-1.381 F25
G1 X124.306 Y153.785 Z-1.383 F25
G1 X124.235 Y153.812 Z-1.386 F25
G1 X124.161 Y153.831 Z-1.389 F25
G1 X124.086 Y153.844 Z-1.392 F25
G1 X124.01 Y153.848 Z-1.395 F25
G1 X123.934 Y153.844 Z-1.398 F25
G1 X123.858 Y153.833 Z-1.401 F25
G1 X123.785 Y153.814 Z-1.404 F25
G1 X123.713 Y153.787 Z-1.407 F25
G1 X123.645 Y153.753 Z-1.41 F25
G1 X123.58 Y153.713 Z-1.413 F25
G1 X123.52 Y153.666 Z-1.415 F25
G1 X123.465 Y153.613 Z-1.418 F25
G1 X123.416 Y153.555 Z-1.421 F25
G1 X123.373 Y153.492 Z-1.424 F25
G1 X123.337 Y153.425 Z-1.427 F25
G1 X123.308 Y153.354 Z-1.43 F25
G1 X123.286 Y153.281 Z-1.433 F25
G1 X123.272 Y153.207 Z-1.436 F25
G1 X123.266 Y153.131 Z-1.439 F25
G1 X123.268 Y153.055 Z-1.442 F25
G1 X123.277 Y152.979 Z-1.445 F25
G1 X123.294 Y152.905 Z-1.447 F25
G1 X123.318 Y152.833 Z-1.45 F25
G1 X123.35 Y152.763 Z-1.453 F25
G1 X123.389 Y152.698 Z-1.456 F25
G1 X123.434 Y152.637 Z-1.459 F25
G1 X123.486 Y152.581 Z-1.462 F25
G1 X123.543 Y152.53 Z-1.465 F25
G1 X123.604 Y152.485 Z-1.468 F25
G1 X123.67 Y152.447 Z-1.471 F25
G1 X123.74 Y152.416 Z-1.474 F25
G1 X123.812 Y152.393 Z-1.476 F25
G1 X123.887 Y152.377 Z-1.479 F25
G1 X123.962 Y152.368 Z-1.482 F25
G1 X124.038 Z-1.485 F25
G1 X124.114 Y152.375 Z-1.488 F25
G1 X124.188 Y152.39 Z-1.491 F25
G1 X124.261 Y152.413 Z-1.494 F25
G1 X124.331 Y152.442 Z-1.497 F25
G1 X124.397 Y152.479 Z-1.5 F25
G1 X124.46 Y152.523 Z-1.503 F25
G1 X124.517 Y152.573 Z-1.506 F25
G1 X124.569 Y152.628 Z-1.508 F25
G1 X124.616 Y152.688 Z-1.511 F25
G1 X124.655 Y152.753 Z-1.514 F25
G1 X124.688 Y152.822 Z-1.517 F25
G1 X124.714 Y152.894 Z-1.52 F25
G1 X124.732 Y152.967 Z-1.523 F25
G1 X124.742 Y153.043 Z-1.526 F25
G1 X124.745 Y153.119 Z-1.529 F25
G1 X124.74 Y153.195 Z-1.532 F25
G1 X124.727 Y153.269 Z-1.535 F25
G1 X124.706 Y153.343 Z-1.538 F25
G1 X124.678 Y153.413 Z-1.54 F25
G1 X124.643 Y153.48 Z-1.543 F25
G1 X124.601 Y153.544 Z-1.546 F25
G1 X124.553 Y153.603 Z-1.549 F25
G1 X124.499 Y153.656 Z-1.552 F25
G1 X124.44 Y153.704 Z-1.555 F25
G1 X124.377 Y153.745 Z-1.558 F25
G1 X124.309 Y153.78 Z-1.561 F25
G1 X124.238 Y153.807 Z-1.564 F25
G1 X124.165 Y153.828 Z-1.567 F25
G1 X124.09 Y153.84 Z-1.57 F25
G1 X124.014 Y153.845 Z-1.572 F25
G1 X123.938 Y153.842 Z-1.575 F25
G1 X123.863 Y153.831 Z-1.578 F25
G1 X123.79 Y153.812 Z-1.581 F25
G1 X123.718 Y153.786 Z-1.584 F25
G1 X123.65 Y153.753 Z-1.587 F25
G1 X123.586 Y153.713 Z-1.59 F25
G1 X123.526 Y153.666 Z-1.593 F25
G1 X123.471 Y153.614 Z-1.596 F25
G1 X123.421 Y153.556 Z-1.599 F25
G1 X123.378 Y153.494 Z-1.602 F25
G1 X123.342 Y153.427 Z-1.604 F25
G1 X123.313 Y153.358 Z-1.607 F25
G1 X123.291 Y153.285 Z-1.61 F25
G1 X123.276 Y153.211 Z-1.613 F25
G1 X123.269 Y153.135 Z-1.616 F25
G1 X123.27 Y153.059 Z-1.619 F25
G1 X123.279 Y152.984 Z-1.622 F25
G1 X123.296 Y152.91 Z-1.625 F25
G1 X123.32 Y152.838 Z-1.628 F25
G1 X123.351 Y152.769 Z-1.631 F25
G1 X123.389 Y152.703 Z-1.634 F25
G1 X123.434 Y152.642 Z-1.636 F25
G1 X123.485 Y152.586 Z-1.639 F25
G1 X123.541 Y152.535 Z-1.642 F25
G1 X123.602 Y152.49 Z-1.645 F25
G1 X123.668 Y152.452 Z-1.648 F25
G1 X123.737 Y152.421 Z-1.651 F25
G1 X123.809 Y152.397 Z-1.654 F25
G1 X123.883 Y152.38 Z-1.657 F25
G1 X123.958 Y152.372 Z-1.66 F25
G1 X124.034 Y152.371 Z-1.663 F25
G1 X124.109 Y152.377 Z-1.666 F25
G1 X124.183 Y152.392 Z-1.668 F25
G1 X124.256 Y152.414 Z-1.671 F25
G1 X124.326 Y152.443 Z-1.674 F25
G1 X124.392 Y152.48 Z-1.677 F25
G1 X124.454 Y152.523 Z-1.68 F25
G1 X124.512 Y152.572 Z-1.683 F25
G1 X124.564 Y152.627 Z-1.686 F25
G1 X124.611 Y152.687 Z-1.689 F25
G1 X124.65 Y152.751 Z-1.692 F25
G1 X124.684 Y152.819 Z-1.695 F25
G1 X124.709 Y152.89 Z-1.698 F25
G1 X124.728 Y152.964 Z-1.7 F25
G1 X124.739 Y153.039 Z-1.703 F25
G1 X124.742 Y153.114 Z-1.706 F25
G1 X124.737 Y153.19 Z-1.709 F25
G1 X124.725 Y153.264 Z-1.712 F25
G1 X124.705 Y153.337 Z-1.715 F25
G1 X124.677 Y153.408 Z-1.718 F25
G1 X124.643 Y153.475 Z-1.721 F25
G1 X124.601 Y153.538 Z-1.724 F25
G1 X124.554 Y153.597 Z-1.727 F25
G1 X124.501 Y153.651 Z-1.73 F25
G1 X124.442 Y153.699 Z-1.732 F25
G1 X124.379 Y153.74 Z-1.735 F25
G1 X124.312 Y153.775 Z-1.738 F25
G1 X124.241 Y153.803 Z-1.741 F25
G1 X124.169 Y153.824 Z-1.744 F25
G1 X124.094 Y153.836 Z-1.747 F25
G1 X124.019 Y153.842 Z-1.75 F25
G1 X123.943 Y153.839 Z-1.753 F25
G1 X123.868 Y153.828 Z-1.756 F25
G1 X123.795 Y153.81 Z-1.759 F25
G1 X123.724 Y153.785 Z-1.762 F25
G1 X123.655 Y153.752 Z-1.764 F25
G1 X123.591 Y153.713 Z-1.767 F25
G1 X123.531 Y153.667 Z-1.77 F25
G1 X123.476 Y153.615 Z-1.773 F25
G1 X123.427 Y153.558 Z-1.776 F25
G1 X123.383 Y153.496 Z-1.779 F25
G1 X123.347 Y153.43 Z-1.782 F25
G1 X123.317 Y153.361 Z-1.785 F25
G1 X123.295 Y153.288 Z-1.788 F25
G1 X123.28 Y153.214 Z-1.791 F25
G1 X123.273 Y153.139 Z-1.794 F25
G1 Y153.064 Z-1.796 F25
G1 X123.282 Y152.989 Z-1.799 F25
G1 X123.298 Y152.915 Z-1.802 F25
G1 X123.321 Y152.843 Z-1.805 F25
G1 X123.352 Y152.774 Z-1.808 F25
G1 X123.39 Y152.709 Z-1.811 F25
G1 X123.434 Y152.647 Z-1.814 F25
G1 X123.484 Y152.591 Z-1.817 F25
G1 X123.54 Y152.54 Z-1.82 F25
G1 X123.6 Y152.495 Z-1.823 F25
G1 X123.665 Y152.457 Z-1.826 F25
G1 X123.734 Y152.425 Z-1.828 F25
G1 X123.805 Y152.401 Z-1.831 F25
G1 X123.879 Y152.384 Z-1.834 F25
G1 X123.954 Y152.375 Z-1.837 F25
G1 X124.029 Y152.374 Z-1.84 F25
G1 X124.104 Y152.38 Z-1.843 F25
G1 X124.178 Y152.394 Z-1.846 F25
G1 X124.251 Y152.415 Z-1.849 F25
G1 X124.32 Y152.444 Z-1.852 F25
G1 X124.387 Y152.48 Z-1.855 F25
G1 X124.449 Y152.522 Z-1.857 F25
G1 X124.507 Y152.571 Z-1.86 F25
G1 X124.559 Y152.625 Z-1.863 F25
G1 X124.605 Y152.685 Z-1.866 F25
G1 X124.646 Y152.749 Z-1.869 F25
G1 X124.679 Y152.816 Z-1.872 F25
G1 X124.705 Y152.887 Z-1.875 F25
G1 X124.724 Y152.96 Z-1.878 F25
G1 X124.735 Y153.035 Z-1.881 F25
G1 X124.739 Y153.11 Z-1.884 F25
G1 X124.735 Y153.185 Z-1.887 F25
G1 X124.723 Y153.259 Z-1.889 F25
G1 X124.703 Y153.332 Z-1.892 F25
G1 X124.676 Y153.402 Z-1.895 F25
G1 X124.642 Y153.47 Z-1.898 F25
G1 X124.602 Y153.533 Z-1.901 F25
G1 X124.555 Y153.592 Z-1.904 F25
G1 X124.502 Y153.646 Z-1.907 F25
G1 X124.444 Y153.694 Z-1.91 F25
G1 X124.381 Y153.735 Z-1.913 F25
G1 X124.314 Y153.771 Z-1.916 F25
G1 X124.245 Y153.799 Z-1.919 F25
G1 X124.172 Y153.82 Z-1.921 F25
G1 X124.098 Y153.833 Z-1.924 F25
G1 X124.023 Y153.838 Z-1.927 F25
G1 X123.948 Y153.836 Z-1.93 F25
G1 X123.873 Y153.826 Z-1.933 F25
G1 X123.8 Y153.809 Z-1.936 F25
G1 X123.729 Y153.784 Z-1.939 F25
G1 X123.661 Y153.752 Z-1.942 F25
G1 X123.596 Y153.713 Z-1.945 F25
G1 X123.536 Y153.667 Z-1.948 F25
G1 X123.481 Y153.616 Z-1.951 F25
G1 X123.432 Y153.56 Z-1.953 F25
G1 X123.388 Y153.498 Z-1.956 F25
G1 X123.351 Y153.433 Z-1.959 F25
G1 X123.321 Y153.364 Z-1.962 F25
G1 X123.299 Y153.292 Z-1.965 F25
G1 X123.284 Y153.218 Z-1.968 F25
G1 X123.276 Y153.144 Z-1.971 F25
G1 Y153.068 Z-1.974 F25
G1 X123.284 Y152.994 Z-1.977 F25
G1 X123.299 Y152.92 Z-1.98 F25
G1 X123.322 Y152.848 Z-1.983 F25
G1 X123.353 Y152.779 Z-1.985 F25
G1 X123.39 Y152.714 Z-1.988 F25
G1 X123.433 Y152.653 Z-1.991 F25
G1 X123.483 Y152.596 Z-1.994 F25
G1 X123.538 Y152.545 Z-1.997 F25
G1 X123.598 Y152.5 Z-2 F25
G1 X123.663 Y152.462 Z-2.003 F25
G1 X123.731 Y152.43 Z-2.006 F25
G1 X123.802 Y152.405 Z-2.009 F25
G1 X123.875 Y152.388 Z-2.012 F25
G1 X123.95 Y152.378 Z-2.015 F25
G1 X124.025 Y152.377 Z-2.017 F25
G1 X124.099 Y152.382 Z-2.02 F25
G1 X124.173 Y152.396 Z-2.023 F25
G1 X124.245 Y152.417 Z-2.026 F25
G1 X124.315 Y152.445 Z-2.029 F25
G1 X124.381 Y152.48 Z-2.032 F25
G1 X124.444 Y152.522 Z-2.035 F25
G1 X124.501 Y152.57 Z-2.038 F25
G1 X124.554 Y152.624 Z-2.041 F25
G1 X124.6 Y152.683 Z-2.044 F25
G1 X124.641 Y152.746 Z-2.047 F25
G1 X124.674 Y152.814 Z-2.049 F25
G1 X124.701 Y152.884 Z-2.052 F25
G1 X124.72 Y152.956 Z-2.055 F25
G1 X124.732 Y153.031 Z-2.058 F25
G1 X124.736 Y153.105 Z-2.061 F25
G1 X124.732 Y153.18 Z-2.064 F25
G1 X124.72 Y153.254 Z-2.067 F25
G1 X124.701 Y153.327 Z-2.07 F25
G1 X124.675 Y153.397 Z-2.073 F25
G1 X124.642 Y153.464 Z-2.076 F25
G1 X124.602 Y153.528 Z-2.079 F25
G1 X124.555 Y153.587 Z-2.081 F25
G1 X124.503 Y153.64 Z-2.084 F25
G1 X124.445 Y153.689 Z-2.087 F25
G1 X124.383 Y153.731 Z-2.09 F25
G1 X124.317 Y153.766 Z-2.093 F25
G1 X124.248 Y153.794 Z-2.096 F25
G1 X124.176 Y153.816 Z-2.099 F25
G1 X124.102 Y153.829 Z-2.102 F25
G1 X124.027 Y153.835 Z-2.105 F25
G1 X123.952 Y153.833 Z-2.108 F25
G1 X123.878 Y153.824 Z-2.111 F25
G1 X123.805 Y153.807 Z-2.113 F25
G1 X123.734 Y153.783 Z-2.116 F25
G1 X123.666 Y153.751 Z-2.119 F25
G1 X123.602 Y153.713 Z-2.122 F25
G1 X123.542 Y153.668 Z-2.125 F25
G1 X123.487 Y153.617 Z-2.128 F25
G1 X123.437 Y153.561 Z-2.131 F25
G1 X123.393 Y153.5 Z-2.134 F25
G1 X123.356 Y153.435 Z-2.137 F25
G1 X123.326 Y153.367 Z-2.14 F25
G1 X123.303 Y153.295 Z-2.143 F25
G1 X123.287 Y153.222 Z-2.145 F25
G1 X123.279 Y153.148 Z-2.148 F25
G1 Y153.073 Z-2.151 F25
G1 X123.286 Y152.998 Z-2.154 F25
G1 X123.301 Y152.925 Z-2.157 F25
G1 X123.324 Y152.853 Z-2.16 F25
G1 X123.353 Y152.785 Z-2.163 F25
G1 X123.39 Y152.719 Z-2.166 F25
G1 X123.433 Y152.658 Z-2.169 F25
G1 X123.482 Y152.602 Z-2.172 F25
G1 X123.537 Y152.551 Z-2.175 F25
G1 X123.597 Y152.505 Z-2.177 F25
G1 X123.66 Y152.466 Z-2.18 F25
G1 X123.728 Y152.434 Z-2.183 F25
G1 X123.799 Y152.409 Z-2.186 F25
G1 X123.871 Y152.392 Z-2.189 F25
G1 X123.945 Y152.382 Z-2.192 F25
G1 X124.02 Y152.38 Z-2.195 F25
G1 X124.095 Y152.385 Z-2.198 F25
G1 X124.168 Y152.398 Z-2.201 F25
G1 X124.24 Y152.418 Z-2.204 F25
G1 X124.31 Y152.446 Z-2.207 F25
G1 X124.376 Y152.481 Z-2.209 F25
G1 X124.438 Y152.522 Z-2.212 F25
G1 X124.496 Y152.57 Z-2.215 F25
G1 X124.549 Y152.623 Z-2.218 F25
G1 X124.595 Y152.681 Z-2.221 F25
G1 X124.636 Y152.744 Z-2.224 F25
G1 X124.67 Y152.811 Z-2.227 F25
G1 X124.697 Y152.881 Z-2.23 F25
G1 X124.716 Y152.953 Z-2.233 F25
G1 X124.728 Y153.026 Z-2.236 F25
G1 X124.733 Y153.101 Z-2.238 F25
G1 X124.729 Y153.176 Z-2.241 F25
G1 X124.718 Y153.25 Z-2.244 F25
G1 X124.7 Y153.322 Z-2.247 F25
G1 X124.674 Y153.392 Z-2.25 F25
G1 X124.641 Y153.459 Z-2.253 F25
G1 X124.602 Y153.522 Z-2.256 F25
G1 X124.556 Y153.581 Z-2.259 F25
G1 X124.504 Y153.635 Z-2.262 F25
G1 X124.447 Y153.683 Z-2.265 F25
G1 X124.385 Y153.726 Z-2.268 F25
G1 X124.32 Y153.761 Z-2.27 F25
G1 X124.251 Y153.79 Z-2.273 F25
G1 X124.179 Y153.811 Z-2.276 F25
G1 X124.106 Y153.825 Z-2.279 F25
G1 X124.031 Y153.832 Z-2.282 F25
G1 X123.957 Y153.831 Z-2.285 F25
G1 X123.883 Y153.822 Z-2.288 F25
G1 X123.81 Y153.805 Z-2.291 F25
G1 X123.739 Y153.781 Z-2.294 F25
G1 X123.671 Y153.75 Z-2.297 F25
G1 X123.607 Y153.712 Z-2.3 F25
G1 X123.547 Y153.668 Z-2.302 F25
G1 X123.492 Y153.618 Z-2.305 F25
G1 X123.442 Y153.563 Z-2.308 F25
G1 X123.398 Y153.502 Z-2.311 F25
G1 X123.361 Y153.438 Z-2.314 F25
G1 X123.33 Y153.37 Z-2.317 F25
G1 X123.307 Y153.299 Z-2.32 F25
G1 X123.291 Y153.226 Z-2.323 F25
G1 X123.283 Y153.152 Z-2.326 F25
G1 X123.282 Y153.077 Z-2.329 F25
G1 X123.289 Y153.003 Z-2.332 F25
G1 X123.303 Y152.93 Z-2.334 F25
G1 X123.325 Y152.859 Z-2.337 F25
G1 X123.354 Y152.79 Z-2.34 F25
G1 X123.39 Y152.725 Z-2.343 F25
G1 X123.433 Y152.663 Z-2.346 F25
G1 X123.482 Y152.607 Z-2.349 F25
G1 X123.536 Y152.556 Z-2.352 F25
G1 X123.595 Y152.51 Z-2.355 F25
G1 X123.658 Y152.471 Z-2.358 F25
G1 X123.725 Y152.439 Z-2.361 F25
G1 X123.795 Y152.414 Z-2.364 F25
G1 X123.868 Y152.396 Z-2.366 F25
G1 X123.941 Y152.385 Z-2.369 F25
G1 X124.016 Y152.383 Z-2.372 F25
G1 X124.09 Y152.387 Z-2.375 F25
G1 X124.163 Y152.4 Z-2.378 F25
G1 X124.235 Y152.42 Z-2.381 F25
G1 X124.305 Y152.447 Z-2.384 F25
G1 X124.371 Y152.481 Z-2.387 F25
G1 X124.433 Y152.522 Z-2.39 F25
G1 X124.491 Y152.569 Z-2.393 F25
G1 X124.543 Y152.622 Z-2.396 F25
G1 X124.59 Y152.68 Z-2.398 F25
G1 X124.631 Y152.742 Z-2.401 F25
G1 X124.665 Y152.808 Z-2.404 F25
G1 X124.692 Y152.877 Z-2.407 F25
G1 X124.712 Y152.949 Z-2.41 F25
G1 X124.725 Y153.022 Z-2.413 F25
G1 X124.729 Y153.097 Z-2.416 F25
G1 X124.727 Y153.171 Z-2.419 F25
G1 X124.716 Y153.245 Z-2.422 F25
G1 X124.698 Y153.317 Z-2.425 F25
G1 X124.673 Y153.387 Z-2.428 F25
G1 X124.641 Y153.454 Z-2.43 F25
G1 X124.601 Y153.517 Z-2.433 F25
G1 X124.556 Y153.576 Z-2.436 F25
G1 X124.505 Y153.63 Z-2.439 F25
G1 X124.448 Y153.678 Z-2.442 F25
G1 X124.387 Y153.721 Z-2.445 F25
G1 X124.322 Y153.757 Z-2.448 F25
G1 X124.254 Y153.786 Z-2.451 F25
G1 X124.183 Y153.807 Z-2.454 F25
G1 X124.11 Y153.822 Z-2.457 F25
G1 X124.036 Y153.829 Z-2.46 F25
G1 X123.961 Y153.828 Z-2.462 F25
G1 X123.887 Y153.819 Z-2.465 F25
G1 X123.815 Y153.803 Z-2.468 F25
G1 X123.744 Y153.78 Z-2.471 F25
G1 X123.677 Y153.75 Z-2.474 F25
G1 X123.612 Y153.712 Z-2.477 F25
G1 X123.552 Y153.669 Z-2.48 F25
G1 X123.497 Y153.619 Z-2.483 F25
G1 X123.447 Y153.564 Z-2.486 F25
G1 X123.403 Y153.504 Z-2.489 F25
G1 X123.366 Y153.44 Z-2.492 F25
G1 X123.335 Y153.373 Z-2.494 F25
G1 X123.311 Y153.302 Z-2.497 F25
G1 X123.295 Y153.23 Z-2.5 F25
G1 X123.286 Y153.156 Z-2.503 F25
G1 X123.285 Y153.082 Z-2.506 F25
G1 X123.291 Y153.008 Z-2.509 F25
G1 X123.305 Y152.935 Z-2.512 F25
G1 X123.327 Y152.864 Z-2.515 F25
G1 X123.355 Y152.795 Z-2.518 F25
G1 X123.391 Y152.73 Z-2.521 F25
G1 X123.433 Y152.669 Z-2.524 F25
G1 X123.481 Y152.612 Z-2.526 F25
G1 X123.534 Y152.561 Z-2.529 F25
G1 X123.593 Y152.515 Z-2.532 F25
G1 X123.656 Y152.476 Z-2.535 F25
G1 X123.722 Y152.444 Z-2.538 F25
G1 X123.792 Y152.418 Z-2.541 F25
G1 X123.864 Y152.4 Z-2.544 F25
G1 X123.937 Y152.389 Z-2.547 F25
G1 X124.011 Y152.386 Z-2.55 F25
G1 X124.085 Y152.39 Z-2.553 F25
G1 X124.159 Y152.402 Z-2.556 F25
G1 X124.23 Y152.422 Z-2.558 F25
G1 X124.299 Y152.448 Z-2.561 F25
G1 X124.365 Y152.482 Z-2.564 F25
G1 X124.428 Y152.522 Z-2.567 F25
G1 X124.486 Y152.569 Z-2.57 F25
G1 X124.538 Y152.621 Z-2.573 F25
G1 X124.585 Y152.678 Z-2.576 F25
G1 X124.626 Y152.74 Z-2.579 F25
G1 X124.661 Y152.806 Z-2.582 F25
G1 X124.688 Y152.874 Z-2.585 F25
G1 X124.708 Y152.946 Z-2.588 F25
G1 X124.721 Y153.019 Z-2.59 F25
G1 X124.726 Y153.092 Z-2.593 F25
G1 X124.724 Y153.166 Z-2.596 F25
G1 X124.714 Y153.24 Z-2.599 F25
G1 X124.696 Y153.312 Z-2.602 F25
G1 X124.672 Y153.382 Z-2.605 F25
G1 X124.64 Y153.448 Z-2.608 F25
G1 X124.601 Y153.512 Z-2.611 F25
G1 X124.557 Y153.571 Z-2.614 F25
G1 X124.506 Y153.625 Z-2.617 F25
G1 X124.45 Y153.673 Z-2.619 F25
G1 X124.389 Y153.716 Z-2.622 F25
G1 X124.325 Y153.752 Z-2.625 F25
G1 X124.257 Y153.781 Z-2.628 F25
G1 X124.186 Y153.803 Z-2.631 F25
G1 X124.113 Y153.818 Z-2.634 F25
G1 X124.04 Y153.825 Z-2.637 F25
G1 X123.966 Z-2.64 F25
G1 X123.892 Y153.817 Z-2.643 F25
G1 X123.82 Y153.802 Z-2.646 F25
G1 X123.75 Y153.779 Z-2.649 F25
G1 X123.682 Y153.749 Z-2.651 F25
G1 X123.618 Y153.712 Z-2.654 F25
G1 X123.558 Y153.669 Z-2.657 F25
G1 X123.502 Y153.62 Z-2.66 F25
G1 X123.452 Y153.565 Z-2.663 F25
G1 X123.408 Y153.506 Z-2.666 F25
G1 X123.37 Y153.442 Z-2.669 F25
G1 X123.339 Y153.375 Z-2.672 F25
G1 X123.315 Y153.305 Z-2.675 F25
G1 X123.299 Y153.233 Z-2.678 F25
G1 X123.289 Y153.16 Z-2.681 F25
G1 X123.288 Y153.086 Z-2.683 F25
G1 X123.294 Y153.012 Z-2.686 F25
G1 X123.307 Y152.94 Z-2.689 F25
G1 X123.328 Y152.869 Z-2.692 F25
G1 X123.356 Y152.8 Z-2.695 F25
G1 X123.391 Y152.735 Z-2.698 F25
G1 X123.433 Y152.674 Z-2.701 F25
G1 X123.48 Y152.617 Z-2.704 F25
G1 X123.533 Y152.566 Z-2.707 F25
G1 X123.591 Y152.52 Z-2.71 F25
G1 X123.654 Y152.481 Z-2.713 F25
G1 X123.72 Y152.448 Z-2.715 F25
G1 X123.789 Y152.422 Z-2.718 F25
G1 X123.86 Y152.404 Z-2.721 F25
G1 X123.933 Y152.392 Z-2.724 F25
G1 X124.007 Y152.389 Z-2.727 F25
G1 X124.081 Y152.393 Z-2.73 F25
G1 X124.154 Y152.404 Z-2.733 F25
G1 X124.225 Y152.423 Z-2.736 F25
G1 X124.294 Y152.449 Z-2.739 F25
G1 X124.36 Y152.482 Z-2.742 F25
G1 X124.422 Y152.522 Z-2.745 F25
G1 X124.48 Y152.568 Z-2.747 F25
G1 X124.533 Y152.62 Z-2.75 F25
G1 X124.58 Y152.676 Z-2.753 F25
G1 X124.621 Y152.738 Z-2.756 F25
G1 X124.656 Y152.803 Z-2.759 F25
G1 X124.684 Y152.871 Z-2.762 F25
G1 X124.704 Y152.942 Z-2.765 F25
G1 X124.717 Y153.015 Z-2.768 F25
G1 X124.723 Y153.088 Z-2.771 F25
G1 X124.721 Y153.162 Z-2.774 F25
G1 X124.712 Y153.235 Z-2.777 F25
G1 X124.695 Y153.307 Z-2.779 F25
G1 X124.67 Y153.376 Z-2.782 F25
G1 X124.639 Y153.443 Z-2.785 F25
G1 X124.601 Y153.506 Z-2.788 F25
G1 X124.557 Y153.565 Z-2.791 F25
G1 X124.507 Y153.62 Z-2.794 F25
G1 X124.451 Y153.668 Z-2.797 F25
G1 X124.391 Y153.711 Z-2.8 F25
G1 X124.327 Y153.747 Z-2.803 F25
G1 X124.26 Y153.777 Z-2.806 F25
G1 X124.189 Y153.799 Z-2.809 F25
G1 X124.117 Y153.814 Z-2.811 F25
G1 X124.044 Y153.822 Z-2.814 F25
G1 X123.97 Z-2.817 F25
G1 X123.897 Y153.815 Z-2.82 F25
G1 X123.825 Y153.8 Z-2.823 F25
G1 X123.755 Y153.777 Z-2.826 F25
G1 X123.687 Y153.748 Z-2.829 F25
G1 X123.623 Y153.712 Z-2.832 F25
G1 X123.563 Y153.669 Z-2.835 F25
G1 X123.508 Y153.621 Z-2.838 F25
G1 X123.458 Y153.567 Z-2.841 F25
G1 X123.413 Y153.508 Z-2.843 F25
G1 X123.375 Y153.445 Z-2.846 F25
G1 X123.344 Y153.378 Z-2.849 F25
G1 X123.319 Y153.309 Z-2.852 F25
G1 X123.302 Y153.237 Z-2.855 F25
G1 X123.293 Y153.164 Z-2.858 F25
G1 X123.291 Y153.09 Z-2.861 F25
G1 X123.296 Y153.017 Z-2.864 F25
G1 X123.309 Y152.944 Z-2.867 F25
G1 X123.33 Y152.874 Z-2.87 F25
G1 X123.357 Y152.806 Z-2.873 F25
G1 X123.392 Y152.74 Z-2.875 F25
G1 X123.432 Y152.679 Z-2.878 F25
G1 X123.479 Y152.623 Z-2.881 F25
G1 X123.532 Y152.571 Z-2.884 F25
G1 X123.589 Y152.525 Z-2.887 F25
G1 X123.651 Y152.486 Z-2.89 F25
G1 X123.717 Y152.453 Z-2.893 F25
G1 X123.786 Y152.426 Z-2.896 F25
G1 X123.857 Y152.407 Z-2.899 F25
G1 X123.929 Y152.396 Z-2.902 F25
G1 X124.003 Y152.392 Z-2.905 F25
G1 X124.076 Y152.395 Z-2.907 F25
G1 X124.149 Y152.406 Z-2.91 F25
G1 X124.22 Y152.425 Z-2.913 F25
G1 X124.289 Y152.45 Z-2.916 F25
G1 X124.355 Y152.483 Z-2.919 F25
G1 X124.417 Y152.522 Z-2.922 F25
G1 X124.475 Y152.568 Z-2.925 F25
G1 X124.528 Y152.619 Z-2.928 F25
G1 X124.575 Y152.675 Z-2.931 F25
G1 X124.617 Y152.736 Z-2.934 F25
G1 X124.651 Y152.8 Z-2.937 F25
G1 X124.679 Y152.868 Z-2.939 F25
G1 X124.7 Y152.939 Z-2.942 F25
G1 X124.714 Y153.011 Z-2.945 F25
G1 X124.72 Y153.084 Z-2.948 F25
G1 X124.718 Y153.157 Z-2.951 F25
G1 X124.709 Y153.23 Z-2.954 F25
G1 X124.693 Y153.302 Z-2.957 F25
G1 X124.669 Y153.371 Z-2.96 F25
G1 X124.638 Y153.438 Z-2.963 F25
G1 X124.601 Y153.501 Z-2.966 F25
G1 X124.557 Y153.56 Z-2.969 F25
G1 X124.508 Y153.614 Z-2.971 F25
G1 X124.453 Y153.663 Z-2.974 F25
G1 X124.393 Y153.706 Z-2.977 F25
G1 X124.33 Y153.743 Z-2.98 F25
G1 X124.262 Y153.772 Z-2.983 F25
G1 X124.193 Y153.795 Z-2.986 F25
G1 X124.121 Y153.811 Z-2.989 F25
G1 X124.048 Y153.819 Z-2.992 F25
G1 X123.975 Z-2.995 F25
G1 X123.902 Y153.812 Z-2.998 F25
G1 X123.83 Y153.798 Z-3 F25
G1 X123.76 Y153.776 Z-3.003 F25
G1 X123.692 Y153.747 Z-3.006 F25
G1 X123.628 Y153.711 Z-3.009 F25
G1 X123.568 Y153.669 Z-3.012 F25
G1 X123.513 Y153.621 Z-3.015 F25
G1 X123.463 Y153.568 Z-3.018 F25
G1 X123.418 Y153.51 Z-3.021 F25
G1 X123.38 Y153.447 Z-3.024 F25
G1 X123.348 Y153.381 Z-3.027 F25
G1 X123.324 Y153.312 Z-3.03 F25
G1 X123.306 Y153.241 Z-3.032 F25
G1 X123.296 Y153.168 Z-3.035 F25
G1 X123.294 Y153.095 Z-3.038 F25
G1 X123.299 Y153.022 Z-3.041 F25
G1 X123.311 Y152.949 Z-3.044 F25
G1 X123.331 Y152.879 Z-3.047 F25
G1 X123.358 Y152.811 Z-3.05 F25
G1 X123.392 Y152.746 Z-3.053 F25
G1 X123.432 Y152.685 Z-3.056 F25
G1 X123.479 Y152.628 Z-3.059 F25
G1 X123.531 Y152.576 Z-3.062 F25
G1 X123.588 Y152.53 Z-3.064 F25
G1 X123.649 Y152.491 Z-3.067 F25
G1 X123.714 Y152.457 Z-3.07 F25
G1 X123.783 Y152.431 Z-3.073 F25
G1 X123.853 Y152.411 Z-3.076 F25
G1 X123.925 Y152.399 Z-3.079 F25
G1 X123.999 Y152.395 Z-3.082 F25
G1 X124.072 Y152.398 Z-3.085 F25
G1 X124.144 Y152.409 Z-3.088 F25
G1 X124.215 Y152.427 Z-3.091 F25
G1 X124.284 Y152.452 Z-3.094 F25
G1 X124.35 Y152.484 Z-3.096 F25
G1 X124.412 Y152.522 Z-3.099 F25
G1 X124.47 Y152.567 Z-3.102 F25
G1 X124.523 Y152.618 Z-3.105 F25
G1 X124.57 Y152.673 Z-3.108 F25
G1 X124.612 Y152.734 Z-3.111 F25
G1 X124.647 Y152.798 Z-3.114 F25
G1 X124.675 Y152.865 Z-3.117 F25
G1 X124.696 Y152.935 Z-3.12 F25
G1 X124.71 Y153.007 Z-3.123 F25
G1 X124.717 Y153.08 Z-3.126 F25
G1 X124.716 Y153.153 Z-3.128 F25
G1 X124.707 Y153.225 Z-3.131 F25
G1 X124.691 Y153.297 Z-3.134 F25
G1 X124.668 Y153.366 Z-3.137 F25
G1 X124.638 Y153.433 Z-3.14 F25
G1 X124.601 Y153.496 Z-3.143 F25
G1 X124.558 Y153.555 Z-3.146 F25
G1 X124.508 Y153.609 Z-3.149 F25
G1 X124.454 Y153.658 Z-3.152 F25
G1 X124.395 Y153.701 Z-3.155 F25
G1 X124.332 Y153.738 Z-3.158 F25
G1 X124.265 Y153.768 Z-3.16 F25
G1 X124.196 Y153.791 Z-3.163 F25
G1 X124.125 Y153.807 Z-3.166 F25
G1 X124.052 Y153.815 Z-3.169 F25
G1 X123.979 Y153.816 Z-3.172 F25
G1 X123.906 Y153.81 Z-3.175 F25
G1 X123.835 Y153.796 Z-3.178 F25
G1 X123.765 Y153.775 Z-3.181 F25
G1 X123.698 Y153.746 Z-3.184 F25
G1 X123.634 Y153.711 Z-3.187 F25
G1 X123.574 Y153.67 Z-3.19 F25
G1 X123.518 Y153.622 Z-3.192 F25
G1 X123.468 Y153.569 Z-3.195 F25
G1 X123.423 Y153.511 Z-3.198 F25
G1 X123.385 Y153.449 Z-3.201 F25
G1 X123.353 Y153.384 Z-3.204 F25
G1 X123.328 Y153.315 Z-3.207 F25
G1 X123.31 Y153.244 Z-3.21 F25
G1 X123.3 Y153.172 Z-3.213 F25
G1 X123.297 Y153.099 Z-3.216 F25
G1 X123.301 Y153.026 Z-3.219 F25
G1 X123.313 Y152.954 Z-3.222 F25
G1 X123.333 Y152.884 Z-3.224 F25
G1 X123.359 Y152.816 Z-3.227 F25
G1 X123.393 Y152.751 Z-3.23 F25
G1 X123.432 Y152.69 Z-3.233 F25
G1 X123.478 Y152.633 Z-3.236 F25
G1 X123.53 Y152.582 Z-3.239 F25
G1 X123.586 Y152.535 Z-3.242 F25
G1 X123.647 Y152.495 Z-3.245 F25
G1 X123.712 Y152.462 Z-3.248 F25
G1 X123.78 Y152.435 Z-3.251 F25
G1 X123.85 Y152.415 Z-3.254 F25
G1 X123.922 Y152.403 Z-3.256 F25
G1 X123.994 Y152.398 Z-3.259 F25
G1 X124.067 Y152.401 Z-3.262 F25
G1 X124.139 Y152.411 Z-3.265 F25
G1 X124.21 Y152.428 Z-3.268 F25
G1 X124.279 Y152.453 Z-3.271 F25
G1 X124.345 Y152.484 Z-3.274 F25
G1 X124.407 Y152.523 Z-3.277 F25
G1 X124.465 Y152.567 Z-3.28 F25
G1 X124.518 Y152.617 Z-3.283 F25
G1 X124.565 Y152.672 Z-3.286 F25
G1 X124.607 Y152.732 Z-3.288 F25
G1 X124.642 Y152.795 Z-3.291 F25
G1 X124.671 Y152.862 Z-3.294 F25
G1 X124.692 Y152.932 Z-3.297 F25
G1 X124.706 Y153.003 Z-3.3 F25
G1 X124.713 Y153.076 Z-3.303 F25
G1 Y153.148 Z-3.306 F25
G1 X124.705 Y153.221 Z-3.309 F25
G1 X124.689 Y153.292 Z-3.312 F25
G1 X124.666 Y153.361 Z-3.315 F25
G1 X124.637 Y153.428 Z-3.318 F25
G1 X124.6 Y153.491 Z-3.32 F25
G1 X124.558 Y153.55 Z-3.323 F25
G1 X124.509 Y153.604 Z-3.326 F25
G1 X124.455 Y153.653 Z-3.329 F25
G1 X124.397 Y153.696 Z-3.332 F25
G1 X124.334 Y153.733 Z-3.335 F25
G1 X124.268 Y153.764 Z-3.338 F25
G1 X124.199 Y153.787 Z-3.341 F25
G1 X124.128 Y153.803 Z-3.344 F25
G1 X124.056 Y153.812 Z-3.347 F25
G1 X123.984 Y153.813 Z-3.35 F25
G1 X123.911 Y153.807 Z-3.352 F25
G1 X123.84 Y153.794 Z-3.355 F25
G1 X123.77 Y153.773 Z-3.358 F25
G1 X123.703 Y153.745 Z-3.361 F25
G1 X123.639 Y153.711 Z-3.364 F25
G1 X123.579 Y153.67 Z-3.367 F25
G1 X123.523 Y153.623 Z-3.37 F25
G1 X123.473 Y153.57 Z-3.373 F25
G1 X123.428 Y153.513 Z-3.376 F25
G1 X123.389 Y153.451 Z-3.379 F25
G1 X123.357 Y153.386 Z-3.381 F25
G1 X123.332 Y153.318 Z-3.384 F25
G1 X123.314 Y153.248 Z-3.387 F25
G1 X123.303 Y153.176 Z-3.39 F25
G1 X123.3 Y153.103 Z-3.393 F25
G1 X123.304 Y153.031 Z-3.396 F25
G1 X123.315 Y152.959 Z-3.399 F25
G1 X123.334 Y152.889 Z-3.402 F25
G1 X123.36 Y152.821 Z-3.405 F25
G1 X123.393 Y152.756 Z-3.408 F25
G1 X123.432 Y152.695 Z-3.411 F25
G1 X123.478 Y152.639 Z-3.413 F25
G1 X123.529 Y152.587 Z-3.416 F25
G1 X123.585 Y152.541 Z-3.419 F25
G1 X123.645 Y152.5 Z-3.422 F25
G1 X123.709 Y152.466 Z-3.425 F25
G1 X123.777 Y152.439 Z-3.428 F25
G1 X123.846 Y152.419 Z-3.431 F25
G1 X123.918 Y152.407 Z-3.434 F25
G1 X123.99 Y152.401 Z-3.437 F25
G1 X124.063 Y152.403 Z-3.44 F25
G1 X124.135 Y152.413 Z-3.443 F25
G1 X124.205 Y152.43 Z-3.445 F25
G1 X124.274 Y152.454 Z-3.448 F25
G1 X124.339 Y152.485 Z-3.451 F25
G1 X124.401 Y152.523 Z-3.454 F25
G1 X124.459 Y152.566 Z-3.457 F25
G1 X124.512 Y152.616 Z-3.46 F25
G1 X124.56 Y152.67 Z-3.463 F25
G1 X124.602 Y152.73 Z-3.466 F25
G1 X124.637 Y152.793 Z-3.469 F25
G1 X124.666 Y152.859 Z-3.472 F25
G1 X124.688 Y152.928 Z-3.475 F25
G1 X124.703 Y152.999 Z-3.477 F25
G1 X124.71 Y153.072 Z-3.48 F25
G1 Y153.144 Z-3.483 F25
G1 X124.702 Y153.216 Z-3.486 F25
G1 X124.687 Y153.287 Z-3.489 F25
G1 X124.665 Y153.356 Z-3.492 F25
G1 X124.636 Y153.422 Z-3.495 F25
G1 X124.6 Y153.485 Z-3.498 F25
G1 X124.558 Y153.544 Z-3.501 F25
G1 X124.51 Y153.599 Z-3.504 F25
G1 X124.457 Y153.648 Z-3.507 F25
G1 X124.399 Y153.691 Z-3.509 F25
G1 X124.337 Y153.729 Z-3.512 F25
G1 X124.271 Y153.759 Z-3.515 F25
G1 X124.203 Y153.783 Z-3.518 F25
G1 X124.132 Y153.799 Z-3.521 F25
G1 X124.06 Y153.809 Z-3.524 F25
G1 X123.988 Y153.81 Z-3.527 F25
G1 X123.916 Y153.805 Z-3.53 F25
G1 X123.845 Y153.792 Z-3.533 F25
G1 X123.775 Y153.771 Z-3.536 F25
G1 X123.708 Y153.744 Z-3.539 F25
G1 X123.644 Y153.71 Z-3.541 F25
G1 X123.584 Y153.67 Z-3.544 F25
G1 X123.528 Y153.623 Z-3.547 F25
G1 X123.478 Y153.571 Z-3.55 F25
G1 X123.433 Y153.515 Z-3.553 F25
G1 X123.394 Y153.454 Z-3.556 F25
G1 X123.362 Y153.389 Z-3.559 F25
G1 X123.336 Y153.321 Z-3.562 F25
G1 X123.318 Y153.251 Z-3.565 F25
G1 X123.307 Y153.18 Z-3.568 F25
G1 X123.303 Y153.107 Z-3.571 F25
G1 X123.307 Y153.035 Z-3.573 F25
G1 X123.318 Y152.964 Z-3.576 F25
G1 X123.336 Y152.894 Z-3.579 F25
G1 X123.361 Y152.826 Z-3.582 F25
G1 X123.394 Y152.762 Z-3.585 F25
G1 X123.432 Y152.7 Z-3.588 F25
G1 X123.477 Y152.644 Z-3.591 F25
G1 X123.528 Y152.592 Z-3.594 F25
G1 X123.583 Y152.546 Z-3.597 F25
G1 X123.643 Y152.505 Z-3.6 F25
G1 X123.707 Y152.471 Z-3.603 F25
G1 X123.774 Y152.444 Z-3.605 F25
G1 X123.843 Y152.423 Z-3.608 F25
G1 X123.914 Y152.41 Z-3.611 F25
G1 X123.986 Y152.405 Z-3.614 F25
G1 X124.058 Y152.406 Z-3.617 F25
G1 X124.13 Y152.415 Z-3.62 F25
G1 X124.2 Y152.432 Z-3.623 F25
G1 X124.269 Y152.455 Z-3.626 F25
G1 X124.334 Y152.486 Z-3.629 F25
G1 X124.396 Y152.523 Z-3.632 F25
G1 X124.454 Y152.566 Z-3.635 F25
G1 X124.507 Y152.615 Z-3.637 F25
G1 X124.555 Y152.669 Z-3.64 F25
G1 X124.597 Y152.728 Z-3.643 F25
G1 X124.633 Y152.79 Z-3.646 F25
G1 X124.662 Y152.856 Z-3.649 F25
G1 X124.684 Y152.925 Z-3.652 F25
G1 X124.699 Y152.996 Z-3.655 F25
G1 X124.707 Y153.067 Z-3.658 F25
G1 Y153.14 Z-3.661 F25
G1 X124.7 Y153.211 Z-3.664 F25
G1 X124.685 Y153.282 Z-3.667 F25
G1 X124.664 Y153.351 Z-3.669 F25
G1 X124.635 Y153.417 Z-3.672 F25
G1 X124.6 Y153.48 Z-3.675 F25
G1 X124.558 Y153.539 Z-3.678 F25
G1 X124.511 Y153.594 Z-3.681 F25
G1 X124.458 Y153.643 Z-3.684 F25
G1 X124.4 Y153.686 Z-3.687 F25
G1 X124.339 Y153.724 Z-3.69 F25
G1 X124.274 Y153.755 Z-3.693 F25
G1 X124.206 Y153.779 Z-3.696 F25
G1 X124.136 Y153.796 Z-3.699 F25
G1 X124.064 Y153.805 Z-3.701 F25
G1 X123.992 Y153.807 Z-3.704 F25
G1 X123.92 Y153.802 Z-3.707 F25
G1 X123.849 Y153.79 Z-3.71 F25
G1 X123.78 Y153.77 Z-3.713 F25
G1 X123.713 Y153.743 Z-3.716 F25
G1 X123.649 Y153.71 Z-3.719 F25
G1 X123.589 Y153.67 Z-3.722 F25
G1 X123.534 Y153.624 Z-3.725 F25
G1 X123.483 Y153.573 Z-3.728 F25
G1 X123.438 Y153.516 Z-3.731 F25
G1 X123.399 Y153.456 Z-3.733 F25
G1 X123.366 Y153.391 Z-3.736 F25
G1 X123.34 Y153.324 Z-3.739 F25
G1 X123.322 Y153.255 Z-3.742 F25
G1 X123.31 Y153.184 Z-3.745 F25
G1 X123.306 Y153.112 Z-3.748 F25
G1 X123.309 Y153.04 Z-3.751 F25
G1 X123.32 Y152.969 Z-3.754 F25
G1 X123.338 Y152.899 Z-3.757 F25
G1 X123.363 Y152.831 Z-3.76 F25
G1 X123.394 Y152.767 Z-3.762 F25
G1 X123.433 Y152.706 Z-3.765 F25
G1 X123.477 Y152.649 Z-3.768 F25
G1 X123.527 Y152.597 Z-3.771 F25
G1 X123.582 Y152.551 Z-3.774 F25
G1 X123.641 Y152.51 Z-3.777 F25
G1 X123.704 Y152.476 Z-3.78 F25
G1 X123.771 Y152.448 Z-3.783 F25
G1 X123.84 Y152.427 Z-3.786 F25
G1 X123.91 Y152.414 Z-3.789 F25
G1 X123.982 Y152.408 Z-3.792 F25
G1 X124.054 Y152.409 Z-3.794 F25
G1 X124.125 Y152.418 Z-3.797 F25
G1 X124.196 Y152.434 Z-3.8 F25
G1 X124.264 Y152.457 Z-3.803 F25
G1 X124.329 Y152.487 Z-3.806 F25
G1 X124.391 Y152.523 Z-3.809 F25
G1 X124.449 Y152.566 Z-3.812 F25
G1 X124.502 Y152.614 Z-3.815 F25
G1 X124.55 Y152.668 Z-3.818 F25
G1 X124.592 Y152.726 Z-3.821 F25
G1 X124.628 Y152.788 Z-3.824 F25
G1 X124.657 Y152.854 Z-3.826 F25
G1 X124.68 Y152.922 Z-3.829 F25
G1 X124.695 Y152.992 Z-3.832 F25
G1 X124.703 Y153.063 Z-3.835 F25
G1 X124.704 Y153.135 Z-3.838 F25
G1 X124.697 Y153.207 Z-3.841 F25
G1 X124.683 Y153.277 Z-3.844 F25
G1 X124.662 Y153.346 Z-3.847 F25
G1 X124.634 Y153.412 Z-3.85 F25
G1 X124.599 Y153.475 Z-3.853 F25
G1 X124.558 Y153.534 Z-3.856 F25
G1 X124.511 Y153.589 Z-3.858 F25
G1 X124.459 Y153.638 Z-3.861 F25
G1 X124.402 Y153.682 Z-3.864 F25
G1 X124.341 Y153.719 Z-3.867 F25
G1 X124.276 Y153.75 Z-3.87 F25
G1 X124.209 Y153.775 Z-3.873 F25
G1 X124.139 Y153.792 Z-3.876 F25
G1 X124.068 Y153.802 Z-3.879 F25
G1 X123.996 Y153.804 Z-3.882 F25
G1 X123.925 Y153.8 Z-3.885 F25
G1 X123.854 Y153.788 Z-3.888 F25
G1 X123.785 Y153.768 Z-3.89 F25
G1 X123.718 Y153.742 Z-3.893 F25
G1 X123.654 Y153.709 Z-3.896 F25
G1 X123.594 Y153.67 Z-3.899 F25
G1 X123.539 Y153.624 Z-3.902 F25
G1 X123.488 Y153.574 Z-3.905 F25
G1 X123.443 Y153.518 Z-3.908 F25
G1 X123.404 Y153.458 Z-3.911 F25
G1 X123.371 Y153.394 Z-3.914 F25
G1 X123.345 Y153.327 Z-3.917 F25
G1 X123.326 Y153.258 Z-3.92 F25
G1 X123.314 Y153.187 Z-3.922 F25
G1 X123.309 Y153.116 Z-3.925 F25
G1 X123.312 Y153.044 Z-3.928 F25
G1 X123.322 Y152.973 Z-3.931 F25
G1 X123.339 Y152.904 Z-3.934 F25
G1 X123.364 Y152.836 Z-3.937 F25
G1 X123.395 Y152.772 Z-3.94 F25
G1 X123.433 Y152.711 Z-3.943 F25
G1 X123.476 Y152.654 Z-3.946 F25
G1 X123.526 Y152.602 Z-3.949 F25
G1 X123.58 Y152.556 Z-3.952 F25
G1 X123.639 Y152.515 Z-3.954 F25
G1 X123.702 Y152.48 Z-3.957 F25
G1 X123.768 Y152.452 Z-3.96 F25
G1 X123.836 Y152.431 Z-3.963 F25
G1 X123.907 Y152.418 Z-3.966 F25
G1 X123.978 Y152.411 Z-3.969 F25
G1 X124.05 Y152.412 Z-3.972 F25
G1 X124.121 Y152.42 Z-3.975 F25
G1 X124.191 Y152.435 Z-3.978 F25
G1 X124.259 Y152.458 Z-3.981 F25
G1 X124.324 Y152.487 Z-3.984 F25
G1 X124.386 Y152.523 Z-3.986 F25
G1 X124.444 Y152.565 Z-3.989 F25
G1 X124.497 Y152.613 Z-3.992 F25
G1 X124.545 Y152.666 Z-3.995 F25
G1 X124.587 Y152.724 Z-3.998 F25
G1 X124.623 Y152.786 Z-4.001 F25
G1 X124.653 Y152.851 Z-4.004 F25
G1 X124.676 Y152.919 Z-4.007 F25
G1 X124.692 Y152.988 Z-4.01 F25
G1 X124.7 Y153.06 Z-4.013 F25
G1 X124.701 Y153.131 Z-4.016 F25
G1 X124.695 Y153.202 Z-4.018 F25
G1 X124.681 Y153.273 Z-4.021 F25
G1 X124.661 Y153.341 Z-4.024 F25
G1 X124.633 Y153.407 Z-4.027 F25
G1 X124.599 Y153.47 Z-4.03 F25
G1 X124.558 Y153.529 Z-4.033 F25
G1 X124.512 Y153.583 Z-4.036 F25
G1 X124.46 Y153.633 Z-4.039 F25
G1 X124.404 Y153.677 Z-4.042 F25
G1 X124.343 Y153.714 Z-4.045 F25
G1 X124.279 Y153.746 Z-4.048 F25
G1 X124.212 Y153.77 Z-4.05 F25
G1 X124.143 Y153.788 Z-4.053 F25
G1 X124.072 Y153.798 Z-4.056 F25
G1 X124.001 Y153.801 Z-4.059 F25
G1 X123.929 Y153.797 Z-4.062 F25
G1 X123.859 Y153.785 Z-4.065 F25
G1 X123.79 Y153.767 Z-4.068 F25
G1 X123.723 Y153.741 Z-4.071 F25
G1 X123.66 Y153.708 Z-4.074 F25
G1 X123.6 Y153.67 Z-4.077 F25
G1 X123.544 Y153.625 Z-4.08 F25
G1 X123.493 Y153.575 Z-4.082 F25
G1 X123.448 Y153.519 Z-4.085 F25
G1 X123.408 Y153.46 Z-4.088 F25
G1 X123.375 Y153.396 Z-4.091 F25
G1 X123.349 Y153.33 Z-4.094 F25
G1 X123.33 Y153.261 Z-4.097 F25
G1 X123.317 Y153.191 Z-4.1 F25
G1 X123.312 Y153.12 Z-4.103 F25
G1 X123.315 Y153.049 Z-4.106 F25
G1 X123.324 Y152.978 Z-4.109 F25
G1 X123.341 Y152.909 Z-4.112 F25
G1 X123.365 Y152.841 Z-4.114 F25
G1 X123.396 Y152.777 Z-4.117 F25
G1 X123.433 Y152.716 Z-4.12 F25
G1 X123.476 Y152.659 Z-4.123 F25
G1 X123.525 Y152.607 Z-4.126 F25
G1 X123.579 Y152.561 Z-4.129 F25
G1 X123.637 Y152.52 Z-4.132 F25
G1 X123.699 Y152.485 Z-4.135 F25
G1 X123.765 Y152.457 Z-4.138 F25
G1 X123.833 Y152.435 Z-4.141 F25
G1 X123.903 Y152.421 Z-4.143 F25
G1 X123.974 Y152.414 Z-4.146 F25
G1 X124.045 Y152.415 Z-4.149 F25
G1 X124.116 Y152.422 Z-4.152 F25
G1 X124.186 Y152.437 Z-4.155 F25
G1 X124.254 Y152.459 Z-4.158 F25
G1 X124.319 Y152.488 Z-4.161 F25
G1 X124.381 Y152.524 Z-4.164 F25
G1 X124.438 Y152.565 Z-4.167 F25
G1 X124.492 Y152.613 Z-4.17 F25
G1 X124.54 Y152.665 Z-4.173 F25
G1 X124.582 Y152.722 Z-4.175 F25
G1 X124.619 Y152.783 Z-4.178 F25
G1 X124.649 Y152.848 Z-4.181 F25
G1 X124.672 Y152.916 Z-4.184 F25
G1 X124.688 Y152.985 Z-4.187 F25
G1 X124.697 Y153.056 Z-4.19 F25
G1 X124.698 Y153.127 Z-4.193 F25
G1 X124.692 Y153.198 Z-4.196 F25
G1 X124.679 Y153.268 Z-4.199 F25
G1 X124.659 Y153.336 Z-4.202 F25
G1 X124.632 Y153.402 Z-4.205 F25
G1 X124.598 Y153.465 Z-4.207 F25
G1 X124.558 Y153.524 Z-4.21 F25
G1 X124.513 Y153.578 Z-4.213 F25
G1 X124.461 Y153.628 Z-4.216 F25
G1 X124.406 Y153.672 Z-4.219 F25
G1 X124.345 Y153.71 Z-4.222 F25
G1 X124.282 Y153.741 Z-4.225 F25
G1 X124.215 Y153.766 Z-4.228 F25
G1 X124.146 Y153.784 Z-4.231 F25
G1 X124.076 Y153.795 Z-4.234 F25
G1 X124.005 Y153.798 Z-4.237 F25
G1 X123.934 Y153.794 Z-4.239 F25
G1 X123.864 Y153.783 Z-4.242 F25
G1 X123.795 Y153.765 Z-4.245 F25
G1 X123.728 Y153.74 Z-4.248 F25
G1 X123.665 Y153.708 Z-4.251 F25
G1 X123.605 Y153.669 Z-4.254 F25
G1 X123.549 Y153.625 Z-4.257 F25
G1 X123.498 Y153.575 Z-4.26 F25
G1 X123.453 Y153.521 Z-4.263 F25
G1 X123.413 Y153.462 Z-4.266 F25
G1 X123.38 Y153.399 Z-4.269 F25
G1 X123.353 Y153.333 Z-4.271 F25
G1 X123.333 Y153.265 Z-4.274 F25
G1 X123.321 Y153.195 Z-4.277 F25
G1 X123.315 Y153.124 Z-4.28 F25
G1 X123.317 Y153.053 Z-4.283 F25
G1 X123.327 Y152.983 Z-4.286 F25
G1 X123.343 Y152.914 Z-4.289 F25
G1 X123.366 Y152.846 Z-4.292 F25
G1 X123.397 Y152.782 Z-4.295 F25
G1 X123.433 Y152.721 Z-4.298 F25
G1 X123.476 Y152.665 Z-4.301 F25
G1 X123.524 Y152.612 Z-4.303 F25
G1 X123.577 Y152.566 Z-4.306 F25
G1 X123.635 Y152.524 Z-4.309 F25
G1 X123.697 Y152.489 Z-4.312 F25
G1 X123.762 Y152.461 Z-4.315 F25
G1 X123.83 Y152.439 Z-4.318 F25
G1 X123.899 Y152.425 Z-4.321 F25
G1 X123.97 Y152.418 Z-4.324 F25
G1 X124.041 Z-4.327 F25
G1 X124.112 Y152.425 Z-4.33 F25
G1 X124.181 Y152.439 Z-4.333 F25
G1 X124.249 Y152.461 Z-4.335 F25
G1 X124.314 Y152.489 Z-4.338 F25
G1 X124.375 Y152.524 Z-4.341 F25
G1 X124.433 Y152.565 Z-4.344 F25
G1 X124.487 Y152.612 Z-4.347 F25
G1 X124.535 Y152.664 Z-4.35 F25
G1 X124.577 Y152.721 Z-4.353 F25
G1 X124.614 Y152.781 Z-4.356 F25
G1 X124.644 Y152.845 Z-4.359 F25
G1 X124.668 Y152.912 Z-4.362 F25
G1 X124.684 Y152.981 Z-4.365 F25
G1 X124.693 Y153.052 Z-4.367 F25
G1 X124.695 Y153.123 Z-4.37 F25
G1 X124.69 Y153.193 Z-4.373 F25
G1 X124.677 Y153.263 Z-4.376 F25
G1 X124.658 Y153.331 Z-4.379 F25
G1 X124.631 Y153.397 Z-4.382 F25
G1 X124.598 Y153.46 Z-4.385 F25
G1 X124.558 Y153.519 Z-4.388 F25
G1 X124.513 Y153.573 Z-4.391 F25
G1 X124.463 Y153.623 Z-4.394 F25
G1 X124.407 Y153.667 Z-4.397 F25
G1 X124.348 Y153.705 Z-4.399 F25
G1 X124.284 Y153.737 Z-4.402 F25
G1 X124.218 Y153.762 Z-4.405 F25
G1 X124.15 Y153.78 Z-4.408 F25
G1 X124.08 Y153.791 Z-4.411 F25
G1 X124.009 Y153.795 Z-4.414 F25
G1 X123.938 Y153.792 Z-4.417 F25
G1 X123.868 Y153.781 Z-4.42 F25
G1 X123.8 Y153.763 Z-4.423 F25
G1 X123.733 Y153.739 Z-4.426 F25
G1 X123.67 Y153.707 Z-4.429 F25
G1 X123.61 Y153.669 Z-4.431 F25
G1 X123.554 Y153.626 Z-4.434 F25
G1 X123.503 Y153.576 Z-4.437 F25
G1 X123.458 Y153.522 Z-4.44 F25
G1 X123.418 Y153.464 Z-4.443 F25
G1 X123.384 Y153.401 Z-4.446 F25
G1 X123.358 Y153.336 Z-4.449 F25
G1 X123.337 Y153.268 Z-4.452 F25
G1 X123.324 Y153.199 Z-4.455 F25
G1 X123.319 Y153.128 Z-4.458 F25
G1 X123.32 Y153.057 Z-4.461 F25
G1 X123.329 Y152.987 Z-4.463 F25
G1 X123.345 Y152.918 Z-4.466 F25
G1 X123.368 Y152.851 Z-4.469 F25
G1 X123.397 Y152.787 Z-4.472 F25
G1 X123.433 Y152.726 Z-4.475 F25
G1 X123.476 Y152.67 Z-4.478 F25
G1 X123.523 Y152.617 Z-4.481 F25
G1 X123.576 Y152.571 Z-4.484 F25
G1 X123.634 Y152.529 Z-4.487 F25
G1 X123.695 Y152.494 Z-4.49 F25
G1 X123.76 Y152.465 Z-4.493 F25
G1 X123.827 Y152.443 Z-4.495 F25
G1 X123.896 Y152.429 Z-4.498 F25
G1 X123.966 Y152.421 Z-4.501 F25
G1 X124.037 Y152.42 Z-4.504 F25
G1 X124.107 Y152.427 Z-4.507 F25
G1 X124.176 Y152.441 Z-4.51 F25
G1 X124.244 Y152.462 Z-4.513 F25
G1 X124.309 Y152.49 Z-4.516 F25
G1 X124.37 Y152.524 Z-4.519 F25
G1 X124.428 Y152.565 Z-4.522 F25
G1 X124.481 Y152.611 Z-4.524 F25
G1 X124.53 Y152.663 Z-4.527 F25
G1 X124.573 Y152.719 Z-4.53 F25
G1 X124.609 Y152.779 Z-4.533 F25
G1 X124.64 Y152.843 Z-4.536 F25
G1 X124.663 Y152.909 Z-4.539 F25
G1 X124.68 Y152.978 Z-4.542 F25
G1 X124.69 Y153.048 Z-4.545 F25
G1 X124.692 Y153.119 Z-4.548 F25
G1 X124.687 Y153.189 Z-4.551 F25
G1 X124.675 Y153.259 Z-4.554 F25
G1 X124.656 Y153.327 Z-4.556 F25
G1 X124.63 Y153.392 Z-4.559 F25
G1 X124.597 Y153.455 Z-4.562 F25
G1 X124.558 Y153.513 Z-4.565 F25
G1 X124.514 Y153.568 Z-4.568 F25
G1 X124.464 Y153.618 Z-4.571 F25
G1 X124.409 Y153.662 Z-4.574 F25
G1 X124.35 Y153.7 Z-4.577 F25
G1 X124.287 Y153.732 Z-4.58 F25
G1 X124.221 Y153.758 Z-4.583 F25
G1 X124.153 Y153.776 Z-4.586 F25
G1 X124.083 Y153.788 Z-4.588 F25
G1 X124.013 Y153.792 Z-4.591 F25
G1 X123.943 Y153.789 Z-4.594 F25
G1 X123.873 Y153.779 Z-4.597 F25
G1 X123.804 Y153.762 Z-4.6 F25
G1 X123.738 Y153.737 Z-4.603 F25
G1 X123.675 Y153.706 Z-4.606 F25
G1 X123.615 Y153.669 Z-4.609 F25
G1 X123.559 Y153.626 Z-4.612 F25
G1 X123.508 Y153.577 Z-4.615 F25
G1 X123.463 Y153.524 Z-4.618 F25
G1 X123.423 Y153.466 Z-4.62 F25
G1 X123.389 Y153.404 Z-4.623 F25
G1 X123.362 Y153.339 Z-4.626 F25
G1 X123.341 Y153.271 Z-4.629 F25
G1 X123.328 Y153.202 Z-4.632 F25
G1 X123.322 Y153.132 Z-4.635 F25
G1 X123.323 Y153.062 Z-4.638 F25
G1 X123.331 Y152.992 Z-4.641 F25
G1 X123.347 Y152.923 Z-4.644 F25
G1 X123.369 Y152.856 Z-4.647 F25
G1 X123.398 Y152.792 Z-4.65 F25
G1 X123.434 Y152.732 Z-4.652 F25
G1 X123.475 Y152.675 Z-4.655 F25
G1 X123.523 Y152.623 Z-4.658 F25
G1 X123.575 Y152.575 Z-4.661 F25
G1 X123.632 Y152.534 Z-4.664 F25
G1 X123.693 Y152.499 Z-4.667 F25
G1 X123.757 Y152.47 Z-4.67 F25
G1 X123.824 Y152.447 Z-4.673 F25
G1 X123.892 Y152.432 Z-4.676 F25
G1 X123.962 Y152.424 Z-4.679 F25
G1 X124.032 Y152.423 Z-4.682 F25
G1 X124.102 Y152.43 Z-4.684 F25
G1 X124.171 Y152.443 Z-4.687 F25
G1 X124.239 Y152.464 Z-4.69 F25
G1 X124.303 Y152.491 Z-4.693 F25
G1 X124.365 Y152.525 Z-4.696 F25
G1 X124.423 Y152.565 Z-4.699 F25
G1 X124.476 Y152.611 Z-4.702 F25
G1 X124.525 Y152.662 Z-4.705 F25
G1 X124.568 Y152.717 Z-4.708 F25
G1 X124.605 Y152.777 Z-4.711 F25
G1 X124.635 Y152.84 Z-4.714 F25
G1 X124.659 Y152.906 Z-4.716 F25
G1 X124.676 Y152.975 Z-4.719 F25
G1 X124.686 Y153.044 Z-4.722 F25
G1 X124.689 Y153.114 Z-4.725 F25
G1 X124.685 Y153.185 Z-4.728 F25
G1 X124.673 Y153.254 Z-4.731 F25
G1 X124.654 Y153.322 Z-4.734 F25
G1 X124.629 Y153.387 Z-4.737 F25
G1 X124.597 Y153.449 Z-4.74 F25
G1 X124.558 Y153.508 Z-4.743 F25
G1 X124.514 Y153.563 Z-4.746 F25
G1 X124.465 Y153.612 Z-4.748 F25
G1 X124.41 Y153.657 Z-4.751 F25
G1 X124.352 Y153.695 Z-4.754 F25
G1 X124.289 Y153.728 Z-4.757 F25
G1 X124.224 Y153.753 Z-4.76 F25
G1 X124.156 Y153.772 Z-4.763 F25
G1 X124.087 Y153.784 Z-4.766 F25
G1 X124.017 Y153.789 Z-4.769 F25
G1 X123.947 Y153.786 Z-4.772 F25
G1 X123.877 Y153.777 Z-4.775 F25
G1 X123.809 Y153.76 Z-4.778 F25
G1 X123.743 Y153.736 Z-4.78 F25
G1 X123.68 Y153.706 Z-4.783 F25
G1 X123.62 Y153.669 Z-4.786 F25
G1 X123.564 Y153.626 Z-4.789 F25
G1 X123.511 Y153.575 Z-4.792 F25
G1 X123.463 Y153.519 Z-4.795 F25
G1 X123.422 Y153.458 Z-4.798 F25
G1 X123.387 Y153.393 Z-4.801 F25
G1 X123.36 Y153.324 Z-4.804 F25
G1 X123.34 Y153.253 Z-4.808 F25
G1 X123.329 Y153.18 Z-4.811 F25
G1 X123.325 Y153.107 Z-4.814 F25
G1 X123.329 Y153.033 Z-4.817 F25
G1 X123.341 Y152.96 Z-4.82 F25
G1 X123.36 Y152.889 Z-4.823 F25
G1 X123.388 Y152.821 Z-4.826 F25
G1 X123.422 Y152.755 Z-4.829 F25
G1 X123.464 Y152.694 Z-4.832 F25
G1 X123.512 Y152.638 Z-4.835 F25
G1 X123.565 Y152.588 Z-4.838 F25
G1 X123.624 Y152.543 Z-4.841 F25
G1 X123.687 Y152.505 Z-4.844 F25
G1 X123.754 Y152.474 Z-4.847 F25
G1 X123.824 Y152.451 Z-4.85 F25
G1 X123.896 Y152.435 Z-4.853 F25
G1 X123.969 Y152.427 Z-4.857 F25
G1 X124.043 Z-4.86 F25
G1 X124.116 Y152.435 Z-4.863 F25
G1 X124.188 Y152.451 Z-4.866 F25
G1 X124.258 Y152.474 Z-4.869 F25
G1 X124.325 Y152.505 Z-4.872 F25
G1 X124.388 Y152.543 Z-4.875 F25
G1 X124.446 Y152.588 Z-4.878 F25
G1 X124.5 Y152.639 Z-4.881 F25
G1 X124.548 Y152.695 Z-4.884 F25
G1 X124.589 Y152.756 Z-4.887 F25
G1 X124.623 Y152.821 Z-4.89 F25
G1 X124.651 Y152.889 Z-4.893 F25
G1 X124.67 Y152.96 Z-4.896 F25
G1 X124.682 Y153.033 Z-4.899 F25
G1 X124.686 Y153.107 Z-4.902 F25
G1 X124.682 Y153.18 Z-4.905 F25
G1 X124.67 Y153.253 Z-4.909 F25
G1 X124.65 Y153.324 Z-4.912 F25
G1 X124.623 Y153.392 Z-4.915 F25
G1 X124.589 Y153.457 Z-4.918 F25
G1 X124.547 Y153.518 Z-4.921 F25
G1 X124.5 Y153.574 Z-4.924 F25
G1 X124.446 Y153.624 Z-4.927 F25
G1 X124.388 Y153.669 Z-4.93 F25
G1 X124.325 Y153.707 Z-4.933 F25
G1 X124.258 Y153.738 Z-4.936 F25
G1 X124.188 Y153.761 Z-4.939 F25
G1 X124.116 Y153.777 Z-4.942 F25
G1 X124.043 Y153.785 Z-4.945 F25
G1 X123.97 Z-4.948 F25
G1 X123.896 Y153.777 Z-4.951 F25
G1 X123.825 Y153.761 Z-4.954 F25
G1 X123.755 Y153.737 Z-4.958 F25
G1 X123.688 Y153.707 Z-4.961 F25
G1 X123.625 Y153.669 Z-4.964 F25
G1 X123.567 Y153.624 Z-4.967 F25
G1 X123.513 Y153.574 Z-4.97 F25
G1 X123.466 Y153.518 Z-4.973 F25
G1 X123.425 Y153.457 Z-4.976 F25
G1 X123.39 Y153.392 Z-4.979 F25
G1 X123.363 Y153.324 Z-4.982 F25
G1 X123.344 Y153.253 Z-4.985 F25
G1 X123.332 Y153.18 Z-4.988 F25
G1 X123.328 Y153.107 Z-4.991 F25
G1 X123.332 Y153.034 Z-4.994 F25
G1 X123.344 Y152.961 Z-4.997 F25
G1 X123.363 Y152.89 Z-5 F25
G1 X123.39 Y152.822 Z-5.003 F25
G1 X123.425 Y152.757 Z-5.007 F25
G1 X123.466 Y152.697 Z-5.01 F25
G1 X123.514 Y152.641 Z-5.013 F25
G1 X123.567 Y152.59 Z-5.016 F25
G1 X123.625 Y152.546 Z-5.019 F25
G1 X123.688 Y152.508 Z-5.022 F25
G1 X123.755 Y152.477 Z-5.025 F25
G1 X123.824 Y152.454 Z-5.028 F25
G1 X123.896 Y152.438 Z-5.031 F25
G1 X123.969 Y152.43 Z-5.034 F25
G1 X124.042 Z-5.037 F25
G1 X124.115 Y152.438 Z-5.04 F25
G1 X124.187 Y152.454 Z-5.043 F25
G1 X124.256 Y152.477 Z-5.046 F25
G1 X124.323 Y152.508 Z-5.049 F25
G1 X124.386 Y152.546 Z-5.052 F25
G1 X124.444 Y152.59 Z-5.056 F25
G1 X124.497 Y152.641 Z-5.059 F25
G1 X124.545 Y152.696 Z-5.062 F25
G1 X124.586 Y152.757 Z-5.065 F25
G1 X124.62 Y152.822 Z-5.068 F25
G1 X124.648 Y152.89 Z-5.071 F25
G1 X124.667 Y152.961 Z-5.074 F25
G1 X124.679 Y153.033 Z-5.077 F25
G1 X124.683 Y153.106 Z-5.08 F25
G3 X123.328 I-0.677 F25
G3 X124.683 I0.677 F25
; MOVEMENT_CUTTING
G1 X124.715 Y153.576 F254
G1 X124.701 Y153.668 F254
G1 X124.662 Y153.752 F254
G1 X124.602 Y153.822 F254
G1 X124.49 Y153.922 F254
G1 X124.354 Y154.047 F254
G1 X124.238 Y154.146 F254
G1 X124.068 Y154.202 F254
G1 X123.889 Y154.204 F254
G1 X123.717 Y154.153 F254
G1 X123.569 Y154.052 F254
; MOVEMENT_LEAD_OUT
G1 X123.536 Y154.014 Z-5.06 F254
G1 X123.51 Y153.972 Z-5.039 F254
G1 X123.491 Y153.926 Z-5.019 F254
G1 X123.479 Y153.878 Z-4.999 F254
G1 X123.475 Y153.828 Z-4.978 F254
G1 X123.479 Y153.778 Z-4.958 F254
G1 X123.491 Y153.73 Z-4.938 F254
G1 X123.51 Y153.684 Z-4.917 F254
G1 X123.536 Y153.641 Z-4.897 F254
G1 X123.568 Y153.603 Z-4.877 F254
G3 X123.79 Y153.51 I0.225 J0.224 F254
; MOVEMENT_LINK_DIRECT
G1 X124.126 Y153.507 F254
G3 X124.352 Y153.599 I0.003 J0.317 F254
; MOVEMENT_LEAD_IN
G1 X124.385 Y153.636 Z-4.897 F254
G1 X124.411 Y153.679 Z-4.917 F254
G1 X124.43 Y153.725 Z-4.938 F254
G1 X124.442 Y153.773 Z-4.958 F254
G1 X124.446 Y153.823 Z-4.978 F254
G1 X124.443 Y153.872 Z-4.999 F254
G1 X124.431 Y153.921 Z-5.019 F254
G1 X124.412 Y153.967 Z-5.039 F254
G1 X124.387 Y154.009 Z-5.06 F254
G1 X124.354 Y154.047 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X124.331 Y154.07 F254
G1 X124.172 Y154.225 F254
G1 X124.133 Y154.255 F254
G1 X124.093 Y154.277 F254
G1 X124.054 Y154.292 F254
G1 X124.014 Y154.302 F254
G1 X123.974 Y154.306 F254
G1 X123.935 Y154.305 F254
G1 X123.895 Y154.299 F254
G1 X123.855 Y154.288 F254
G1 X123.824 Y154.275 F254
G1 X123.792 Y154.258 F254
G1 X123.761 Y154.235 F254
G1 X123.729 Y154.206 F254
G1 X123.697 Y154.171 F254
G1 X123.538 Y154.024 F254
G1 X123.378 Y153.889 F254
G1 X123.221 Y153.763 F254
G1 X123.178 Y153.73 F254
G1 X123.156 Y153.712 F254
G1 X123.134 Y153.691 F254
G1 X123.102 Y153.651 F254
G1 X123.08 Y153.611 F254
G1 X123.063 Y153.567 F254
G1 X123.054 Y153.529 F254
G1 X123.049 Y153.49 F254
G1 X123.05 Y153.452 F254
G1 X123.063 Y153.336 F254
G1 X123.069 Y153.254 F254
G1 X123.076 Y153.096 F254
G1 X123.068 Y152.937 F254
G1 X123.063 Y152.883 F254
G1 X123.058 Y152.851 F254
G1 X123.052 Y152.811 F254
G1 X123.047 Y152.779 F254
G1 X123.03 Y152.627 F254
G1 X123.105 Y152.46 F254
G1 X123.238 Y152.334 F254
G1 X123.409 Y152.267 F254
; MOVEMENT_LEAD_OUT
G1 X123.44 Y152.264 Z-5.067 F254
G1 X123.471 Y152.262 Z-5.054 F254
G1 X123.472 F254
G1 X123.526 Y152.266 Z-5.032 F254
G1 X123.579 Y152.276 Z-5.01 F254
G1 X123.631 Y152.293 Z-4.988 F254
G1 X123.68 Y152.316 Z-4.966 F254
G1 X123.726 Y152.345 Z-4.943 F254
G1 X123.768 Y152.38 Z-4.921 F254
G1 X123.805 Y152.42 Z-4.899 F254
G1 X123.837 Y152.464 Z-4.877 F254
G3 X123.901 Y152.74 I-0.365 J0.23 F254
; MOVEMENT_LINK_DIRECT
G3 X123.377 Y153.116 I-0.43 J-0.046 F254
; MOVEMENT_LEAD_IN
G1 X123.324 Y153.1 Z-4.899 F254
G1 X123.273 Y153.078 Z-4.922 F254
G1 X123.225 Y153.049 Z-4.945 F254
G1 X123.182 Y153.015 Z-4.967 F254
G1 X123.143 Y152.976 Z-4.99 F254
G1 X123.11 Y152.931 Z-5.012 F254
G1 X123.083 Y152.883 Z-5.035 F254
G1 X123.062 Y152.832 Z-5.057 F254
G1 X123.047 Y152.779 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X123.021 Y152.62 F254
G1 X123.023 Y152.58 F254
G1 X123.031 Y152.541 F254
G1 X123.044 Y152.501 F254
G1 X123.063 Y152.461 F254
G1 X123.097 Y152.412 F254
G1 X123.117 Y152.387 F254
G1 X123.142 Y152.363 F254
G1 X123.182 Y152.333 F254
G1 X123.221 Y152.311 F254
G1 X123.241 Y152.303 F254
G1 X123.276 Y152.292 F254
G1 X123.38 Y152.272 F254
G1 X123.697 Y152.215 F254
G1 X124.172 Y152.137 F254
G1 X124.26 Y152.127 F254
G1 X124.412 Y152.117 F254
G1 X124.563 Y152.139 F254
G1 X124.707 Y152.188 F254
G1 X124.841 Y152.261 F254
G1 X124.961 Y152.354 F254
G1 X125.069 Y152.462 F254
G1 X125.077 Y152.473 F254
G1 X125.182 Y152.643 F254
G1 X125.237 Y152.835 F254
G1 X125.239 Y153.034 F254
G1 X125.187 Y153.227 F254
G1 X125.086 Y153.399 F254
G1 X124.943 Y153.538 F254
; MOVEMENT_LEAD_OUT
G1 X124.9 Y153.563 Z-5.06 F254
G1 X124.853 Y153.581 Z-5.039 F254
G1 X124.805 Y153.591 Z-5.019 F254
G1 X124.755 Y153.593 Z-4.999 F254
G1 X124.705 Y153.588 Z-4.978 F254
G1 X124.657 Y153.575 Z-4.958 F254
G1 X124.612 Y153.555 Z-4.938 F254
G1 X124.57 Y153.528 Z-4.917 F254
G1 X124.533 Y153.494 Z-4.897 F254
G1 X124.502 Y153.456 Z-4.877 F254
G3 X124.485 Y153.428 I0.262 J-0.18 F254
G1 X124.382 Y153.24 F254
; MOVEMENT_LINK_DIRECT
G1 X124.092 Y152.711 F254
; MOVEMENT_LEAD_IN
G1 X124.028 Y152.593 F254
G3 X123.992 Y152.487 I0.278 J-0.153 F254
G1 X123.989 Y152.438 Z-4.897 F254
G1 X123.993 Y152.388 Z-4.917 F254
G1 X124.005 Y152.34 Z-4.938 F254
G1 X124.025 Y152.294 Z-4.958 F254
G1 X124.051 Y152.252 Z-4.978 F254
G1 X124.084 Y152.214 Z-4.999 F254
G1 X124.122 Y152.182 Z-5.019 F254
G1 X124.165 Y152.156 Z-5.039 F254
G1 X124.211 Y152.138 Z-5.06 F254
G1 X124.26 Y152.127 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X124.331 Y152.119 F254
G1 X124.648 Y152.086 F254
G1 X124.807 Y152.077 F254
G1 X125.013 Y152.089 F254
G1 X125.165 Y152.106 F254
G1 X125.344 Y152.2 F254
G1 X125.489 Y152.342 F254
G1 X125.585 Y152.521 F254
G1 X125.625 Y152.72 F254
G1 X125.605 Y152.921 F254
G1 X125.527 Y153.109 F254
G1 X125.398 Y153.265 F254
G1 X125.228 Y153.376 F254
; MOVEMENT_LEAD_OUT
G1 X125.188 Y153.39 Z-5.063 F254
G1 X125.147 Y153.398 Z-5.046 F254
G1 X125.105 Y153.401 Z-5.029 F254
G1 X125.059 Y153.397 Z-5.01 F254
G1 X125.013 Y153.387 Z-4.991 F254
G1 X124.97 Y153.371 Z-4.972 F254
G1 X124.929 Y153.348 Z-4.953 F254
G1 X124.893 Y153.319 Z-4.934 F254
G1 X124.86 Y153.286 Z-4.915 F254
G1 X124.834 Y153.248 Z-4.896 F254
G1 X124.812 Y153.206 Z-4.877 F254
G3 X124.791 Y153.13 I0.293 J-0.123 F254
G1 X124.767 Y152.964 F254
; MOVEMENT_LINK_DIRECT
G1 X124.719 Y152.644 F254
; MOVEMENT_LEAD_IN
G1 X124.691 Y152.453 F254
G3 X124.688 Y152.399 I0.314 J-0.046 F254
G1 X124.693 Y152.349 Z-4.897 F254
G1 X124.706 Y152.301 Z-4.917 F254
G1 X124.726 Y152.256 Z-4.938 F254
G1 X124.753 Y152.214 Z-4.958 F254
G1 X124.786 Y152.177 Z-4.978 F254
G1 X124.825 Y152.145 Z-4.999 F254
G1 X124.868 Y152.12 Z-5.019 F254
G1 X124.915 Y152.102 Z-5.039 F254
G1 X124.963 Y152.092 Z-5.06 F254
G1 X125.013 Y152.089 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X125.282 Y152.105 F254
G1 X125.361 Y152.113 F254
G1 X125.599 Y152.173 F254
G1 X125.745 Y152.217 F254
G1 X125.893 Y152.365 F254
G1 X125.978 Y152.556 F254
G1 X125.989 Y152.765 F254
G1 X125.924 Y152.963 F254
G1 X125.791 Y153.125 F254
G1 X125.609 Y153.228 F254
; MOVEMENT_LEAD_OUT
G1 X125.554 Y153.241 Z-5.057 F254
G1 X125.498 Y153.248 Z-5.034 F254
G1 X125.441 Y153.249 Z-5.011 F254
G1 X125.385 Y153.242 Z-4.988 F254
G1 X125.33 Y153.229 Z-4.964 F254
G1 X125.279 Y153.212 Z-4.943 F254
G1 X125.23 Y153.189 Z-4.921 F254
G1 X125.184 Y153.162 Z-4.899 F254
G1 X125.141 Y153.13 Z-4.877 F254
G3 X125.132 Y152.289 I0.343 J-0.424 F254
; MOVEMENT_LEAD_IN
G1 X125.182 Y152.252 Z-4.902 F254
G1 X125.236 Y152.22 Z-4.928 F254
G1 X125.293 Y152.195 Z-4.953 F254
G1 X125.352 Y152.177 Z-4.978 F254
G1 X125.413 Y152.165 Z-5.004 F254
G1 X125.475 Y152.161 Z-5.029 F254
G1 X125.538 Y152.163 Z-5.055 F254
G1 X125.599 Y152.173 Z-5.08 F254
; MOVEMENT_CUTTING
G1 X125.916 Y152.253 F254
G1 X126.026 Y152.293 F254
G1 X126.166 Y152.352 F254
G1 X126.261 Y152.479 F254
G1 X126.306 Y152.631 F254
G1 X126.295 Y152.788 F254
G1 X126.229 Y152.932 F254
G1 X126.116 Y153.044 F254
G1 X125.972 Y153.11 F254
; MOVEMENT_LEAD_OUT
G3 X125.748 Y153.094 I-0.085 J-0.393 F254
G3 X126.026 Y152.293 I0.147 J-0.398 F254
; MOVEMENT_CUTTING
G1 X126.233 Y152.369 F254
G1 X126.36 Y152.421 F254
G1 X126.392 Y152.434 F254
G1 X126.417 Y152.449 F254
G1 X126.455 Y152.476 F254
G1 X126.474 Y152.491 F254
; MOVEMENT_LEAD_OUT
G3 X126.238 Y152.768 I-0.121 J0.135 F254
; MOVEMENT_LEAD_IN
G1 X126.216 Y152.75 F254
G3 X126.417 Y152.449 I0.114 J-0.141 F254
; MOVEMENT_CUTTING
G1 X126.438 Y152.461 F254
G1 X126.475 Y152.492 F254
G1 X126.495 Y152.513 F254
G1 X126.511 Y152.535 F254
G1 X126.534 Y152.571 F254
G1 X126.55 Y152.608 F254
G1 X126.555 Y152.62 F254
G1 X126.565 Y152.66 F254
G1 X126.57 Y152.699 F254
G1 Y152.739 F254
G1 X126.565 Y152.779 F254
G1 X126.55 Y152.832 F254
G1 X126.539 Y152.858 F254
G1 X126.525 Y152.884 F254
G1 X126.487 Y152.937 F254
G1 X126.466 Y152.961 F254
G1 X126.439 Y152.985 F254
G1 X126.416 Y153.003 F254
G1 X126.392 Y153.017 F254
G1 X126.352 Y153.035 F254
G1 X126.313 Y153.048 F254
G1 X126.233 Y153.059 F254
G1 X126.075 Y153.084 F254
G1 X125.916 Y153.124 F254
G1 X125.758 Y153.177 F254
G1 X125.441 Y153.286 F254
G1 X125.282 Y153.351 F254
G1 X125.148 Y153.413 F254
G1 X124.965 Y153.522 F254
G1 X124.897 Y153.572 F254
G1 X124.807 Y153.642 F254
G1 X124.648 Y153.781 F254
G1 X124.602 Y153.822 F254
; MOVEMENT_LEAD_OUT
G3 X124.176 Y153.803 I-0.202 J-0.245 F254
G1 X124.155 Y153.767 Z-5.077 F254
G1 X124.134 Y153.733 Z-5.069 F254
G1 X124.114 Y153.7 Z-5.056 F254
G1 X124.095 Y153.668 Z-5.038 F254
G1 X124.091 Y153.635 Z-5.015 F254
G1 X124.086 Y153.604 Z-4.989 F254
G1 X124.082 Y153.577 Z-4.958 F254
G1 X124.085 Y153.554 Z-4.923 F254
G1 X124.087 Y153.535 Z-4.886 F254
G1 X124.088 Y153.522 Z-4.846 F254
G1 X124.089 Y153.513 Z-4.805 F254
G1 Y153.511 Z-4.763 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X74.372 Y152.413 F254
G1 Z-2.54 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_RAMP_HELIX
G1 X74.473 Y152.39 Z-2.544 F25
G1 X74.575 Y152.375 Z-2.547 F25
G1 X74.679 Y152.366 Z-2.551 F25
G1 X74.782 Z-2.554 F25
G1 X74.885 Y152.373 Z-2.558 F25
G1 X74.988 Y152.387 Z-2.562 F25
G1 X75.089 Y152.408 Z-2.565 F25
G1 X75.189 Y152.437 Z-2.569 F25
G1 X75.286 Y152.473 Z-2.573 F25
G1 X75.38 Y152.516 Z-2.576 F25
G1 X75.471 Y152.566 Z-2.58 F25
G1 X75.558 Y152.622 Z-2.583 F25
G1 X75.64 Y152.685 Z-2.587 F25
G1 X75.718 Y152.753 Z-2.591 F25
G1 X75.791 Y152.827 Z-2.594 F25
G1 X75.858 Y152.905 Z-2.598 F25
G1 X75.92 Y152.989 Z-2.601 F25
G1 X75.975 Y153.076 Z-2.605 F25
G1 X76.023 Y153.168 Z-2.609 F25
G1 X76.065 Y153.262 Z-2.612 F25
G1 X76.1 Y153.36 Z-2.616 F25
G1 X76.128 Y153.46 Z-2.62 F25
G1 X76.148 Y153.561 Z-2.623 F25
G1 X76.161 Y153.664 Z-2.627 F25
G1 X76.167 Y153.767 Z-2.63 F25
G1 X76.165 Y153.871 Z-2.634 F25
G1 X76.156 Y153.974 Z-2.638 F25
G1 X76.139 Y154.076 Z-2.641 F25
G1 X76.114 Y154.176 Z-2.645 F25
G1 X76.083 Y154.275 Z-2.648 F25
G1 X76.045 Y154.371 Z-2.652 F25
G1 X75.999 Y154.464 Z-2.656 F25
G1 X75.947 Y154.553 Z-2.659 F25
G1 X75.889 Y154.638 Z-2.663 F25
G1 X75.824 Y154.719 Z-2.667 F25
G1 X75.754 Y154.795 Z-2.67 F25
G1 X75.679 Y154.866 Z-2.674 F25
G1 X75.599 Y154.931 Z-2.677 F25
G1 X75.514 Y154.99 Z-2.681 F25
G1 X75.425 Y155.043 Z-2.685 F25
G1 X75.332 Y155.089 Z-2.688 F25
G1 X75.237 Y155.129 Z-2.692 F25
G1 X75.139 Y155.161 Z-2.695 F25
G1 X75.038 Y155.186 Z-2.699 F25
G1 X74.936 Y155.204 Z-2.703 F25
G1 X74.833 Y155.214 Z-2.706 F25
G1 X74.73 Y155.217 Z-2.71 F25
G1 X74.627 Y155.213 Z-2.714 F25
G1 X74.524 Y155.201 Z-2.717 F25
G1 X74.423 Y155.181 Z-2.721 F25
G1 X74.323 Y155.154 Z-2.724 F25
G1 X74.225 Y155.12 Z-2.728 F25
G1 X74.13 Y155.079 Z-2.732 F25
G1 X74.038 Y155.032 Z-2.735 F25
G1 X73.95 Y154.977 Z-2.739 F25
G1 X73.867 Y154.917 Z-2.743 F25
G1 X73.788 Y154.85 Z-2.746 F25
G1 X73.713 Y154.779 Z-2.75 F25
G1 X73.645 Y154.701 Z-2.753 F25
G1 X73.582 Y154.62 Z-2.757 F25
G1 X73.525 Y154.533 Z-2.761 F25
G1 X73.475 Y154.443 Z-2.764 F25
G1 X73.431 Y154.35 Z-2.768 F25
G1 X73.394 Y154.253 Z-2.771 F25
G1 X73.364 Y154.154 Z-2.775 F25
G1 X73.342 Y154.053 Z-2.779 F25
G1 X73.327 Y153.951 Z-2.782 F25
G1 X73.319 Y153.848 Z-2.786 F25
G1 Y153.745 Z-2.79 F25
G1 X73.326 Y153.642 Z-2.793 F25
G1 X73.341 Y153.54 Z-2.797 F25
G1 X73.363 Y153.439 Z-2.8 F25
G1 X73.392 Y153.34 Z-2.804 F25
G1 X73.429 Y153.243 Z-2.808 F25
G1 X73.472 Y153.149 Z-2.811 F25
G1 X73.522 Y153.059 Z-2.815 F25
G1 X73.578 Y152.973 Z-2.818 F25
G1 X73.641 Y152.89 Z-2.822 F25
G1 X73.709 Y152.813 Z-2.826 F25
G1 X73.783 Y152.741 Z-2.829 F25
G1 X73.862 Y152.674 Z-2.833 F25
G1 X73.945 Y152.613 Z-2.837 F25
G1 X74.033 Y152.559 Z-2.84 F25
G1 X74.124 Y152.511 Z-2.844 F25
G1 X74.219 Y152.47 Z-2.847 F25
G1 X74.316 Y152.435 Z-2.851 F25
G1 X74.416 Y152.408 Z-2.855 F25
G1 X74.517 Y152.388 Z-2.858 F25
G1 X74.619 Y152.376 Z-2.862 F25
G1 X74.722 Y152.371 Z-2.865 F25
G1 X74.825 Y152.373 Z-2.869 F25
G1 X74.928 Y152.383 Z-2.873 F25
G1 X75.03 Y152.4 Z-2.876 F25
G1 X75.13 Y152.425 Z-2.88 F25
G1 X75.228 Y152.457 Z-2.884 F25
G1 X75.324 Y152.496 Z-2.887 F25
G1 X75.416 Y152.542 Z-2.891 F25
G1 X75.505 Y152.594 Z-2.894 F25
G1 X75.59 Y152.653 Z-2.898 F25
G1 X75.67 Y152.717 Z-2.902 F25
G1 X75.746 Y152.787 Z-2.905 F25
G1 X75.816 Y152.863 Z-2.909 F25
G1 X75.881 Y152.943 Z-2.912 F25
G1 X75.939 Y153.028 Z-2.916 F25
G1 X75.991 Y153.117 Z-2.92 F25
G1 X76.037 Y153.21 Z-2.923 F25
G1 X76.076 Y153.305 Z-2.927 F25
G1 X76.108 Y153.404 Z-2.931 F25
G1 X76.132 Y153.504 Z-2.934 F25
G1 X76.15 Y153.605 Z-2.938 F25
G1 X76.159 Y153.708 Z-2.941 F25
G1 X76.162 Y153.811 Z-2.945 F25
G1 X76.157 Y153.914 Z-2.949 F25
G1 X76.144 Y154.016 Z-2.952 F25
G1 X76.124 Y154.117 Z-2.956 F25
G1 X76.097 Y154.216 Z-2.959 F25
G1 X76.063 Y154.314 Z-2.963 F25
G1 X76.021 Y154.408 Z-2.967 F25
G1 X75.973 Y154.499 Z-2.97 F25
G1 X75.919 Y154.587 Z-2.974 F25
G1 X75.858 Y154.67 Z-2.978 F25
G1 X75.791 Y154.748 Z-2.981 F25
G1 X75.719 Y154.822 Z-2.985 F25
G1 X75.642 Y154.89 Z-2.988 F25
G1 X75.56 Y154.953 Z-2.992 F25
G1 X75.474 Y155.009 Z-2.996 F25
G1 X75.383 Y155.059 Z-2.999 F25
G1 X75.29 Y155.102 Z-3.003 F25
G1 X75.194 Y155.138 Z-3.006 F25
G1 X75.095 Y155.167 Z-3.01 F25
G1 X74.994 Y155.189 Z-3.014 F25
G1 X74.892 Y155.204 Z-3.017 F25
G1 X74.789 Y155.211 Z-3.021 F25
G1 X74.686 Z-3.025 F25
G1 X74.583 Y155.203 Z-3.028 F25
G1 X74.482 Y155.188 Z-3.032 F25
G1 X74.381 Y155.165 Z-3.035 F25
G1 X74.283 Y155.136 Z-3.039 F25
G1 X74.187 Y155.099 Z-3.043 F25
G1 X74.093 Y155.055 Z-3.046 F25
G1 X74.004 Y155.005 Z-3.05 F25
G1 X73.918 Y154.948 Z-3.053 F25
G1 X73.836 Y154.885 Z-3.057 F25
G1 X73.759 Y154.817 Z-3.061 F25
G1 X73.688 Y154.743 Z-3.064 F25
G1 X73.622 Y154.664 Z-3.068 F25
G1 X73.562 Y154.581 Z-3.072 F25
G1 X73.508 Y154.493 Z-3.075 F25
G1 X73.46 Y154.402 Z-3.079 F25
G1 X73.419 Y154.307 Z-3.082 F25
G1 X73.386 Y154.21 Z-3.086 F25
G1 X73.359 Y154.11 Z-3.09 F25
G1 X73.34 Y154.009 Z-3.093 F25
G1 X73.328 Y153.907 Z-3.097 F25
G1 X73.323 Y153.804 Z-3.101 F25
G1 X73.326 Y153.701 Z-3.104 F25
G1 X73.337 Y153.599 Z-3.108 F25
G1 X73.354 Y153.498 Z-3.111 F25
G1 X73.38 Y153.398 Z-3.115 F25
G1 X73.412 Y153.3 Z-3.119 F25
G1 X73.451 Y153.205 Z-3.122 F25
G1 X73.497 Y153.113 Z-3.126 F25
G1 X73.55 Y153.025 Z-3.129 F25
G1 X73.609 Y152.94 Z-3.133 F25
G1 X73.673 Y152.861 Z-3.137 F25
G1 X73.744 Y152.786 Z-3.14 F25
G1 X73.819 Y152.716 Z-3.144 F25
G1 X73.9 Y152.652 Z-3.148 F25
G1 X73.985 Y152.594 Z-3.151 F25
G1 X74.074 Y152.543 Z-3.155 F25
G1 X74.166 Y152.498 Z-3.158 F25
G1 X74.262 Y152.459 Z-3.162 F25
G1 X74.359 Y152.428 Z-3.166 F25
G1 X74.459 Y152.404 Z-3.169 F25
G1 X74.561 Y152.388 Z-3.173 F25
G1 X74.663 Y152.378 Z-3.176 F25
G1 X74.766 Y152.376 Z-3.18 F25
G1 X74.869 Y152.382 Z-3.184 F25
G1 X74.971 Y152.395 Z-3.187 F25
G1 X75.071 Y152.415 Z-3.191 F25
G1 X75.17 Y152.443 Z-3.195 F25
G1 X75.267 Y152.478 Z-3.198 F25
G1 X75.361 Y152.519 Z-3.202 F25
G1 X75.452 Y152.568 Z-3.205 F25
G1 X75.539 Y152.623 Z-3.209 F25
G1 X75.621 Y152.684 Z-3.213 F25
G1 X75.7 Y152.75 Z-3.216 F25
G1 X75.773 Y152.823 Z-3.22 F25
G1 X75.84 Y152.9 Z-3.223 F25
G1 X75.902 Y152.982 Z-3.227 F25
G1 X75.958 Y153.068 Z-3.231 F25
G1 X76.007 Y153.159 Z-3.234 F25
G1 X76.049 Y153.252 Z-3.238 F25
G1 X76.085 Y153.348 Z-3.242 F25
G1 X76.114 Y153.447 Z-3.245 F25
G1 X76.135 Y153.547 Z-3.249 F25
G1 X76.149 Y153.649 Z-3.252 F25
G1 X76.156 Y153.751 Z-3.256 F25
G1 X76.155 Y153.854 Z-3.26 F25
G1 X76.147 Y153.956 Z-3.263 F25
G1 X76.131 Y154.058 Z-3.267 F25
G1 X76.108 Y154.158 Z-3.27 F25
G1 X76.078 Y154.256 Z-3.274 F25
G1 X76.041 Y154.352 Z-3.278 F25
G1 X75.997 Y154.444 Z-3.281 F25
G1 X75.946 Y154.534 Z-3.285 F25
G1 X75.889 Y154.619 Z-3.289 F25
G1 X75.826 Y154.7 Z-3.292 F25
G1 X75.757 Y154.777 Z-3.296 F25
G1 X75.683 Y154.848 Z-3.299 F25
G1 X75.604 Y154.913 Z-3.303 F25
G1 X75.521 Y154.973 Z-3.307 F25
G1 X75.433 Y155.026 Z-3.31 F25
G1 X75.342 Y155.073 Z-3.314 F25
G1 X75.247 Y155.113 Z-3.317 F25
G1 X75.15 Y155.146 Z-3.321 F25
G1 X75.051 Y155.172 Z-3.325 F25
G1 X74.95 Y155.191 Z-3.328 F25
G1 X74.848 Y155.203 Z-3.332 F25
G1 X74.746 Y155.207 Z-3.336 F25
G1 X74.643 Y155.203 Z-3.339 F25
G1 X74.541 Y155.192 Z-3.343 F25
G1 X74.44 Y155.174 Z-3.346 F25
G1 X74.341 Y155.148 Z-3.35 F25
G1 X74.244 Y155.116 Z-3.354 F25
G1 X74.149 Y155.076 Z-3.357 F25
G1 X74.058 Y155.03 Z-3.361 F25
G1 X73.97 Y154.977 Z-3.364 F25
G1 X73.886 Y154.918 Z-3.368 F25
G1 X73.807 Y154.853 Z-3.372 F25
G1 X73.732 Y154.782 Z-3.375 F25
G1 X73.663 Y154.707 Z-3.379 F25
G1 X73.6 Y154.626 Z-3.383 F25
G1 X73.543 Y154.541 Z-3.386 F25
G1 X73.492 Y154.452 Z-3.39 F25
G1 X73.447 Y154.36 Z-3.393 F25
G1 X73.409 Y154.264 Z-3.397 F25
G1 X73.379 Y154.166 Z-3.401 F25
G1 X73.355 Y154.067 Z-3.404 F25
G1 X73.339 Y153.965 Z-3.408 F25
G1 X73.33 Y153.863 Z-3.411 F25
G1 X73.329 Y153.761 Z-3.415 F25
G1 X73.335 Y153.658 Z-3.419 F25
G1 X73.349 Y153.557 Z-3.422 F25
G1 X73.369 Y153.456 Z-3.426 F25
G1 X73.397 Y153.358 Z-3.43 F25
G1 X73.433 Y153.262 Z-3.433 F25
G1 X73.475 Y153.168 Z-3.437 F25
G1 X73.523 Y153.078 Z-3.44 F25
G1 X73.578 Y152.992 Z-3.444 F25
G1 X73.639 Y152.91 Z-3.448 F25
G1 X73.706 Y152.832 Z-3.451 F25
G1 X73.779 Y152.76 Z-3.455 F25
G1 X73.856 Y152.693 Z-3.459 F25
G1 X73.938 Y152.631 Z-3.462 F25
G1 X74.025 Y152.576 Z-3.466 F25
G1 X74.115 Y152.528 Z-3.469 F25
G1 X74.208 Y152.486 Z-3.473 F25
G1 X74.304 Y152.451 Z-3.477 F25
G1 X74.403 Y152.423 Z-3.48 F25
G1 X74.503 Y152.402 Z-3.484 F25
G1 X74.605 Y152.388 Z-3.487 F25
G1 X74.707 Y152.382 Z-3.491 F25
G1 X74.809 Y152.383 Z-3.495 F25
G1 X74.911 Y152.392 Z-3.498 F25
G1 X75.013 Y152.408 Z-3.502 F25
G1 X75.112 Y152.432 Z-3.506 F25
G1 X75.21 Y152.462 Z-3.509 F25
G1 X75.305 Y152.5 Z-3.513 F25
G1 X75.398 Y152.544 Z-3.516 F25
G1 X75.486 Y152.595 Z-3.52 F25
G1 X75.571 Y152.652 Z-3.524 F25
G1 X75.652 Y152.715 Z-3.527 F25
G1 X75.727 Y152.784 Z-3.531 F25
G1 X75.798 Y152.858 Z-3.534 F25
G1 X75.863 Y152.937 Z-3.538 F25
G1 X75.922 Y153.021 Z-3.542 F25
G1 X75.974 Y153.109 Z-3.545 F25
G1 X76.021 Y153.2 Z-3.549 F25
G1 X76.06 Y153.294 Z-3.553 F25
G1 X76.093 Y153.391 Z-3.556 F25
G1 X76.118 Y153.49 Z-3.56 F25
G1 X76.136 Y153.591 Z-3.563 F25
G1 X76.147 Y153.693 Z-3.567 F25
G1 X76.151 Y153.795 Z-3.571 F25
G1 X76.147 Y153.897 Z-3.574 F25
G1 X76.136 Y153.999 Z-3.578 F25
G1 X76.117 Y154.099 Z-3.581 F25
G1 X76.091 Y154.198 Z-3.585 F25
G1 X76.058 Y154.295 Z-3.589 F25
G1 X76.018 Y154.389 Z-3.592 F25
G1 X75.971 Y154.48 Z-3.596 F25
G1 X75.918 Y154.568 Z-3.6 F25
G1 X75.859 Y154.651 Z-3.603 F25
G1 X75.793 Y154.73 Z-3.607 F25
G1 X75.723 Y154.804 Z-3.61 F25
G1 X75.647 Y154.872 Z-3.614 F25
G1 X75.563 Y154.937 Z-3.618 F25
G1 X75.474 Y154.996 Z-3.622 F25
G1 X75.382 Y155.047 Z-3.625 F25
G1 X75.285 Y155.092 Z-3.629 F25
G1 X75.186 Y155.129 Z-3.633 F25
G1 X75.084 Y155.159 Z-3.637 F25
G1 X74.98 Y155.181 Z-3.64 F25
G1 X74.875 Y155.195 Z-3.644 F25
G1 X74.769 Y155.201 Z-3.648 F25
G1 X74.663 Y155.199 Z-3.652 F25
G1 X74.558 Y155.189 Z-3.655 F25
G1 X74.453 Y155.171 Z-3.659 F25
G1 X74.35 Y155.145 Z-3.663 F25
G1 X74.249 Y155.112 Z-3.667 F25
G1 X74.151 Y155.071 Z-3.67 F25
G1 X74.057 Y155.023 Z-3.674 F25
G1 X73.966 Y154.968 Z-3.678 F25
G1 X73.88 Y154.906 Z-3.682 F25
G1 X73.799 Y154.838 Z-3.685 F25
G1 X73.723 Y154.764 Z-3.689 F25
G1 X73.652 Y154.685 Z-3.693 F25
G1 X73.588 Y154.6 Z-3.697 F25
G1 X73.531 Y154.511 Z-3.7 F25
G1 X73.48 Y154.418 Z-3.704 F25
G1 X73.437 Y154.321 Z-3.708 F25
G1 X73.401 Y154.221 Z-3.712 F25
G1 X73.372 Y154.119 Z-3.715 F25
G1 X73.352 Y154.015 Z-3.719 F25
G1 X73.339 Y153.91 Z-3.723 F25
G1 X73.334 Y153.804 Z-3.727 F25
G1 X73.337 Y153.698 Z-3.73 F25
G1 X73.348 Y153.593 Z-3.734 F25
G1 X73.368 Y153.488 Z-3.738 F25
G1 X73.394 Y153.386 Z-3.742 F25
G1 X73.429 Y153.286 Z-3.745 F25
G1 X73.471 Y153.188 Z-3.749 F25
G1 X73.52 Y153.095 Z-3.753 F25
G1 X73.576 Y153.005 Z-3.757 F25
G1 X73.639 Y152.919 Z-3.76 F25
G1 X73.708 Y152.839 Z-3.764 F25
G1 X73.783 Y152.764 Z-3.768 F25
G1 X73.863 Y152.694 Z-3.772 F25
G1 X73.948 Y152.632 Z-3.775 F25
G1 X74.038 Y152.575 Z-3.779 F25
G1 X74.132 Y152.526 Z-3.783 F25
G1 X74.229 Y152.483 Z-3.787 F25
G1 X74.329 Y152.449 Z-3.79 F25
G1 X74.431 Y152.421 Z-3.794 F25
G1 X74.535 Y152.402 Z-3.798 F25
G1 X74.641 Y152.391 Z-3.802 F25
G1 X74.747 Y152.387 Z-3.806 F25
G1 X74.853 Y152.392 Z-3.809 F25
G1 X74.958 Y152.404 Z-3.813 F25
G1 X75.062 Y152.424 Z-3.817 F25
G1 X75.164 Y152.452 Z-3.821 F25
G1 X75.263 Y152.488 Z-3.824 F25
G1 X75.36 Y152.531 Z-3.828 F25
G1 X75.453 Y152.581 Z-3.832 F25
G1 X75.542 Y152.638 Z-3.836 F25
G1 X75.627 Y152.702 Z-3.839 F25
G1 X75.706 Y152.772 Z-3.843 F25
G1 X75.78 Y152.847 Z-3.847 F25
G1 X75.849 Y152.928 Z-3.851 F25
G1 X75.911 Y153.014 Z-3.854 F25
G1 X75.966 Y153.105 Z-3.858 F25
G1 X76.014 Y153.199 Z-3.862 F25
G1 X76.055 Y153.296 Z-3.866 F25
G1 X76.089 Y153.397 Z-3.869 F25
G1 X76.115 Y153.499 Z-3.873 F25
G1 X76.133 Y153.604 Z-3.877 F25
G1 X76.143 Y153.709 Z-3.881 F25
G1 X76.145 Y153.815 Z-3.884 F25
G1 X76.139 Y153.92 Z-3.888 F25
G1 X76.126 Y154.025 Z-3.892 F25
G1 X76.104 Y154.129 Z-3.896 F25
G1 X76.075 Y154.231 Z-3.899 F25
G1 X76.038 Y154.33 Z-3.903 F25
G1 X75.994 Y154.426 Z-3.907 F25
G1 X75.943 Y154.519 Z-3.911 F25
G1 X75.885 Y154.607 Z-3.914 F25
G1 X75.82 Y154.691 Z-3.918 F25
G1 X75.749 Y154.769 Z-3.922 F25
G1 X75.673 Y154.842 Z-3.926 F25
G1 X75.591 Y154.909 Z-3.929 F25
G1 X75.505 Y154.97 Z-3.933 F25
G1 X75.414 Y155.024 Z-3.937 F25
G1 X75.319 Y155.071 Z-3.941 F25
G1 X75.221 Y155.111 Z-3.944 F25
G1 X75.121 Y155.143 Z-3.948 F25
G1 X75.018 Y155.168 Z-3.952 F25
G1 X74.914 Y155.185 Z-3.956 F25
G1 X74.808 Y155.194 Z-3.959 F25
G1 X74.703 Y155.195 Z-3.963 F25
G1 X74.597 Y155.188 Z-3.967 F25
G1 X74.492 Y155.173 Z-3.971 F25
G1 X74.389 Y155.15 Z-3.975 F25
G1 X74.288 Y155.12 Z-3.978 F25
G1 X74.189 Y155.082 Z-3.982 F25
G1 X74.094 Y155.037 Z-3.986 F25
G1 X74.002 Y154.984 Z-3.99 F25
G1 X73.914 Y154.925 Z-3.993 F25
G1 X73.831 Y154.86 Z-3.997 F25
G1 X73.754 Y154.788 Z-4.001 F25
G1 X73.681 Y154.711 Z-4.005 F25
G1 X73.615 Y154.628 Z-4.008 F25
G1 X73.556 Y154.541 Z-4.012 F25
G1 X73.503 Y154.45 Z-4.016 F25
G1 X73.457 Y154.355 Z-4.02 F25
G1 X73.418 Y154.257 Z-4.023 F25
G1 X73.387 Y154.156 Z-4.027 F25
G1 X73.364 Y154.053 Z-4.031 F25
G1 X73.348 Y153.948 Z-4.035 F25
G1 X73.34 Y153.843 Z-4.038 F25
G1 X73.341 Y153.738 Z-4.042 F25
G1 X73.349 Y153.632 Z-4.046 F25
G1 X73.365 Y153.528 Z-4.05 F25
G1 X73.389 Y153.425 Z-4.053 F25
G1 X73.421 Y153.324 Z-4.057 F25
G1 X73.46 Y153.226 Z-4.061 F25
G1 X73.506 Y153.131 Z-4.065 F25
G1 X73.559 Y153.04 Z-4.068 F25
G1 X73.619 Y152.953 Z-4.072 F25
G1 X73.686 Y152.871 Z-4.076 F25
G1 X73.758 Y152.795 Z-4.08 F25
G1 X73.836 Y152.723 Z-4.083 F25
G1 X73.919 Y152.658 Z-4.087 F25
G1 X74.007 Y152.6 Z-4.091 F25
G1 X74.099 Y152.548 Z-4.095 F25
G1 X74.195 Y152.503 Z-4.098 F25
G1 X74.294 Y152.466 Z-4.102 F25
G1 X74.395 Y152.436 Z-4.106 F25
G1 X74.498 Y152.414 Z-4.11 F25
G1 X74.602 Y152.399 Z-4.113 F25
G1 X74.708 Y152.393 Z-4.117 F25
G1 X74.813 Y152.394 Z-4.121 F25
G1 X74.918 Y152.404 Z-4.125 F25
G1 X75.022 Y152.421 Z-4.128 F25
G1 X75.125 Y152.446 Z-4.132 F25
G1 X75.225 Y152.479 Z-4.136 F25
G1 X75.322 Y152.519 Z-4.14 F25
G1 X75.416 Y152.567 Z-4.143 F25
G1 X75.507 Y152.621 Z-4.147 F25
G1 X75.593 Y152.682 Z-4.151 F25
G1 X75.674 Y152.749 Z-4.155 F25
G1 X75.75 Y152.823 Z-4.159 F25
G1 X75.82 Y152.901 Z-4.162 F25
G1 X75.884 Y152.985 Z-4.166 F25
G1 X75.941 Y153.074 Z-4.17 F25
G1 X75.992 Y153.166 Z-4.174 F25
G1 X76.036 Y153.262 Z-4.177 F25
G1 X76.072 Y153.361 Z-4.181 F25
G1 X76.101 Y153.463 Z-4.185 F25
G1 X76.122 Y153.566 Z-4.189 F25
G1 X76.135 Y153.671 Z-4.192 F25
G1 X76.14 Y153.776 Z-4.196 F25
G1 X76.137 Y153.881 Z-4.2 F25
G1 X76.126 Y153.986 Z-4.204 F25
G1 X76.108 Y154.09 Z-4.207 F25
G1 X76.082 Y154.192 Z-4.211 F25
G1 X76.048 Y154.292 Z-4.215 F25
G1 X76.006 Y154.388 Z-4.219 F25
G1 X75.958 Y154.482 Z-4.222 F25
G1 X75.902 Y154.572 Z-4.226 F25
G1 X75.841 Y154.657 Z-4.23 F25
G1 X75.772 Y154.737 Z-4.234 F25
G1 X75.698 Y154.812 Z-4.237 F25
G1 X75.619 Y154.881 Z-4.241 F25
G1 X75.534 Y154.944 Z-4.245 F25
G1 X75.445 Y155 Z-4.249 F25
G1 X75.352 Y155.05 Z-4.252 F25
G1 X75.256 Y155.092 Z-4.256 F25
G1 X75.157 Y155.127 Z-4.26 F25
G1 X75.055 Y155.155 Z-4.264 F25
G1 X74.951 Y155.174 Z-4.267 F25
G1 X74.847 Y155.186 Z-4.271 F25
G1 X74.742 Y155.19 Z-4.275 F25
G1 X74.636 Y155.186 Z-4.279 F25
G1 X74.532 Y155.174 Z-4.282 F25
G1 X74.428 Y155.154 Z-4.286 F25
G1 X74.326 Y155.127 Z-4.29 F25
G1 X74.227 Y155.092 Z-4.294 F25
G1 X74.131 Y155.049 Z-4.297 F25
G1 X74.038 Y155 Z-4.301 F25
G1 X73.949 Y154.943 Z-4.305 F25
G1 X73.865 Y154.881 Z-4.309 F25
G1 X73.785 Y154.811 Z-4.312 F25
G1 X73.712 Y154.737 Z-4.316 F25
G1 X73.643 Y154.656 Z-4.32 F25
G1 X73.582 Y154.571 Z-4.324 F25
G1 X73.526 Y154.482 Z-4.327 F25
G1 X73.478 Y154.388 Z-4.331 F25
G1 X73.437 Y154.292 Z-4.335 F25
G1 X73.403 Y154.192 Z-4.339 F25
G1 X73.377 Y154.09 Z-4.343 F25
G1 X73.358 Y153.986 Z-4.346 F25
G1 X73.348 Y153.882 Z-4.35 F25
G1 X73.345 Y153.777 Z-4.354 F25
G1 X73.35 Y153.672 Z-4.358 F25
G1 X73.364 Y153.567 Z-4.361 F25
G1 X73.385 Y153.464 Z-4.365 F25
G1 X73.413 Y153.363 Z-4.369 F25
G1 X73.449 Y153.264 Z-4.373 F25
G1 X73.493 Y153.168 Z-4.376 F25
G1 X73.544 Y153.076 Z-4.38 F25
G1 X73.601 Y152.988 Z-4.384 F25
G1 X73.665 Y152.904 Z-4.388 F25
G1 X73.735 Y152.826 Z-4.391 F25
G1 X73.811 Y152.753 Z-4.395 F25
G1 X73.892 Y152.686 Z-4.399 F25
G1 X73.977 Y152.625 Z-4.403 F25
G1 X74.067 Y152.571 Z-4.406 F25
G1 X74.161 Y152.524 Z-4.41 F25
G1 X74.258 Y152.484 Z-4.414 F25
G1 X74.358 Y152.451 Z-4.418 F25
G1 X74.46 Y152.426 Z-4.421 F25
G1 X74.564 Y152.409 Z-4.425 F25
G1 X74.669 Y152.4 Z-4.429 F25
G1 X74.774 Y152.398 Z-4.433 F25
G1 X74.879 Y152.405 Z-4.436 F25
G1 X74.983 Y152.419 Z-4.44 F25
G1 X75.085 Y152.441 Z-4.444 F25
G1 X75.186 Y152.471 Z-4.448 F25
G1 X75.284 Y152.509 Z-4.451 F25
G1 X75.38 Y152.553 Z-4.455 F25
G1 X75.471 Y152.605 Z-4.459 F25
G1 X75.558 Y152.663 Z-4.463 F25
G1 X75.641 Y152.728 Z-4.466 F25
G1 X75.719 Y152.799 Z-4.47 F25
G1 X75.791 Y152.875 Z-4.474 F25
G1 X75.857 Y152.957 Z-4.478 F25
G1 X75.916 Y153.044 Z-4.481 F25
G1 X75.97 Y153.134 Z-4.485 F25
G1 X76.016 Y153.229 Z-4.489 F25
G1 X76.054 Y153.326 Z-4.493 F25
G1 X76.086 Y153.426 Z-4.496 F25
G1 X76.109 Y153.529 Z-4.5 F25
G1 X76.125 Y153.632 Z-4.504 F25
G1 X76.133 Y153.737 Z-4.508 F25
G1 X76.134 Y153.842 Z-4.512 F25
G1 X76.126 Y153.947 Z-4.515 F25
G1 X76.11 Y154.05 Z-4.519 F25
G1 X76.087 Y154.153 Z-4.523 F25
G1 X76.056 Y154.253 Z-4.527 F25
G1 X76.018 Y154.351 Z-4.53 F25
G1 X75.972 Y154.445 Z-4.534 F25
G1 X75.919 Y154.536 Z-4.538 F25
G1 X75.86 Y154.622 Z-4.542 F25
G1 X75.794 Y154.704 Z-4.545 F25
G1 X75.722 Y154.781 Z-4.549 F25
G1 X75.645 Y154.852 Z-4.553 F25
G1 X75.563 Y154.917 Z-4.557 F25
G1 X75.476 Y154.976 Z-4.56 F25
G1 X75.385 Y155.027 Z-4.564 F25
G1 X75.29 Y155.072 Z-4.568 F25
G1 X75.192 Y155.11 Z-4.572 F25
G1 X75.091 Y155.14 Z-4.575 F25
G1 X74.989 Y155.163 Z-4.579 F25
G1 X74.885 Y155.177 Z-4.583 F25
G1 X74.78 Y155.184 Z-4.587 F25
G1 X74.675 Y155.183 Z-4.59 F25
G1 X74.571 Y155.174 Z-4.594 F25
G1 X74.467 Y155.157 Z-4.598 F25
G1 X74.365 Y155.133 Z-4.602 F25
G1 X74.266 Y155.101 Z-4.605 F25
G1 X74.168 Y155.061 Z-4.609 F25
G1 X74.075 Y155.014 Z-4.613 F25
G1 X73.985 Y154.961 Z-4.617 F25
G1 X73.899 Y154.9 Z-4.62 F25
G1 X73.818 Y154.834 Z-4.624 F25
G1 X73.742 Y154.761 Z-4.628 F25
G1 X73.672 Y154.683 Z-4.632 F25
G1 X73.608 Y154.6 Z-4.635 F25
G1 X73.551 Y154.513 Z-4.639 F25
G1 X73.5 Y154.421 Z-4.643 F25
G1 X73.456 Y154.326 Z-4.647 F25
G1 X73.42 Y154.227 Z-4.65 F25
G1 X73.391 Y154.127 Z-4.654 F25
G1 X73.37 Y154.024 Z-4.658 F25
G1 X73.356 Y153.92 Z-4.662 F25
G1 X73.351 Y153.815 Z-4.665 F25
G1 X73.353 Y153.71 Z-4.669 F25
G1 X73.363 Y153.606 Z-4.673 F25
G1 X73.381 Y153.503 Z-4.677 F25
G1 X73.407 Y153.401 Z-4.68 F25
G1 X73.44 Y153.302 Z-4.684 F25
G1 X73.481 Y153.205 Z-4.688 F25
G1 X73.529 Y153.112 Z-4.692 F25
G1 X73.584 Y153.023 Z-4.696 F25
G1 X73.645 Y152.938 Z-4.699 F25
G1 X73.712 Y152.858 Z-4.703 F25
G1 X73.786 Y152.783 Z-4.707 F25
G1 X73.864 Y152.714 Z-4.711 F25
G1 X73.948 Y152.651 Z-4.714 F25
G1 X74.036 Y152.595 Z-4.718 F25
G1 X74.128 Y152.545 Z-4.722 F25
G1 X74.224 Y152.503 Z-4.726 F25
G1 X74.323 Y152.468 Z-4.729 F25
G1 X74.424 Y152.44 Z-4.733 F25
G1 X74.526 Y152.42 Z-4.737 F25
G1 X74.63 Y152.408 Z-4.741 F25
G1 X74.735 Y152.403 Z-4.744 F25
G1 X74.84 Y152.407 Z-4.748 F25
G1 X74.944 Y152.418 Z-4.752 F25
G1 X75.047 Y152.438 Z-4.756 F25
G1 X75.148 Y152.465 Z-4.759 F25
G1 X75.247 Y152.499 Z-4.763 F25
G1 X75.343 Y152.541 Z-4.767 F25
G1 X75.435 Y152.59 Z-4.771 F25
G1 X75.524 Y152.646 Z-4.774 F25
G1 X75.608 Y152.708 Z-4.778 F25
G1 X75.687 Y152.776 Z-4.782 F25
G1 X75.761 Y152.85 Z-4.786 F25
G1 X75.829 Y152.93 Z-4.789 F25
G1 X75.891 Y153.014 Z-4.793 F25
G1 X75.946 Y153.103 Z-4.797 F25
G1 X75.994 Y153.196 Z-4.801 F25
G1 X76.036 Y153.292 Z-4.804 F25
G1 X76.07 Y153.39 Z-4.808 F25
G1 X76.096 Y153.492 Z-4.812 F25
G1 X76.115 Y153.595 Z-4.816 F25
G1 X76.126 Y153.698 Z-4.819 F25
G1 X76.129 Y153.803 Z-4.823 F25
G1 X76.124 Y153.907 Z-4.827 F25
G1 X76.112 Y154.011 Z-4.831 F25
G1 X76.091 Y154.114 Z-4.834 F25
G1 X76.063 Y154.214 Z-4.838 F25
G1 X76.027 Y154.313 Z-4.842 F25
G1 X75.985 Y154.408 Z-4.846 F25
G1 X75.935 Y154.5 Z-4.849 F25
G1 X75.878 Y154.588 Z-4.853 F25
G1 X75.815 Y154.671 Z-4.857 F25
G1 X75.745 Y154.749 Z-4.861 F25
G1 X75.67 Y154.822 Z-4.864 F25
G1 X75.59 Y154.889 Z-4.868 F25
G1 X75.505 Y154.95 Z-4.872 F25
G1 X75.416 Y155.004 Z-4.876 F25
G1 X75.323 Y155.052 Z-4.88 F25
G1 X75.226 Y155.092 Z-4.883 F25
G1 X75.127 Y155.125 Z-4.887 F25
G1 X75.026 Y155.15 Z-4.891 F25
G1 X74.923 Y155.167 Z-4.895 F25
G1 X74.819 Y155.177 Z-4.898 F25
G1 X74.714 Y155.179 Z-4.902 F25
G1 X74.61 Y155.173 Z-4.906 F25
G1 X74.506 Y155.159 Z-4.91 F25
G1 X74.404 Y155.137 Z-4.913 F25
G1 X74.304 Y155.108 Z-4.917 F25
G1 X74.206 Y155.072 Z-4.921 F25
G1 X74.112 Y155.028 Z-4.925 F25
G1 X74.02 Y154.977 Z-4.928 F25
G1 X73.933 Y154.919 Z-4.932 F25
G1 X73.851 Y154.855 Z-4.936 F25
G1 X73.773 Y154.785 Z-4.94 F25
G1 X73.702 Y154.709 Z-4.943 F25
G1 X73.636 Y154.628 Z-4.947 F25
G1 X73.576 Y154.542 Z-4.951 F25
G1 X73.523 Y154.452 Z-4.955 F25
G1 X73.477 Y154.359 Z-4.958 F25
G1 X73.438 Y154.262 Z-4.962 F25
G1 X73.406 Y154.162 Z-4.966 F25
G1 X73.382 Y154.061 Z-4.97 F25
G1 X73.366 Y153.958 Z-4.973 F25
G1 X73.357 Y153.853 Z-4.977 F25
G1 Y153.749 Z-4.981 F25
G1 X73.364 Y153.645 Z-4.985 F25
G1 X73.379 Y153.542 Z-4.988 F25
G1 X73.402 Y153.44 Z-4.992 F25
G1 X73.432 Y153.34 Z-4.996 F25
G1 X73.47 Y153.243 Z-5 F25
G1 X73.515 Y153.149 Z-5.003 F25
G1 X73.567 Y153.059 Z-5.007 F25
G1 X73.626 Y152.972 Z-5.011 F25
G1 X73.691 Y152.891 Z-5.015 F25
G1 X73.762 Y152.814 Z-5.018 F25
G1 X73.838 Y152.743 Z-5.022 F25
G1 X73.92 Y152.678 Z-5.026 F25
G1 X74.006 Y152.62 Z-5.03 F25
G1 X74.096 Y152.568 Z-5.033 F25
G1 X74.191 Y152.523 Z-5.037 F25
G1 X74.288 Y152.485 Z-5.041 F25
G1 X74.388 Y152.455 Z-5.045 F25
G1 X74.489 Y152.432 Z-5.049 F25
G1 X74.593 Y152.417 Z-5.052 F25
G1 X74.697 Y152.41 Z-5.056 F25
G1 X74.801 Z-5.06 F25
G1 X74.905 Y152.419 Z-5.064 F25
G1 X75.008 Y152.435 Z-5.067 F25
G1 X75.109 Y152.459 Z-5.071 F25
G1 X75.209 Y152.491 Z-5.075 F25
G1 X75.306 Y152.53 Z-5.079 F25
G1 X75.399 Y152.576 Z-5.082 F25
G1 X75.489 Y152.629 Z-5.086 F25
G1 X75.574 Y152.688 Z-5.09 F25
G1 X75.655 Y152.754 Z-5.094 F25
G1 X75.73 Y152.826 Z-5.097 F25
G1 X75.8 Y152.903 Z-5.101 F25
G1 X75.864 Y152.985 Z-5.105 F25
G1 X75.922 Y153.072 Z-5.109 F25
G1 X75.972 Y153.163 Z-5.112 F25
G1 X76.016 Y153.258 Z-5.116 F25
G1 X76.053 Y153.355 Z-5.12 F25
G1 X76.082 Y153.455 Z-5.124 F25
G1 X76.103 Y153.557 Z-5.127 F25
G1 X76.117 Y153.66 Z-5.131 F25
G1 X76.123 Y153.764 Z-5.135 F25
G1 X76.121 Y153.869 Z-5.139 F25
G1 X76.112 Y153.972 Z-5.142 F25
G1 X76.094 Y154.075 Z-5.146 F25
G1 X76.069 Y154.176 Z-5.15 F25
G1 X76.036 Y154.275 Z-5.154 F25
G1 X75.996 Y154.371 Z-5.157 F25
G1 X75.949 Y154.464 Z-5.161 F25
G1 X75.895 Y154.553 Z-5.165 F25
G1 X75.834 Y154.638 Z-5.169 F25
G1 X75.768 Y154.718 Z-5.172 F25
G1 X75.695 Y154.792 Z-5.176 F25
G1 X75.617 Y154.861 Z-5.18 F25
G1 X75.534 Y154.924 Z-5.184 F25
G1 X75.447 Y154.981 Z-5.187 F25
G1 X75.355 Y155.03 Z-5.191 F25
G1 X75.26 Y155.073 Z-5.195 F25
G1 X75.162 Y155.108 Z-5.199 F25
G1 X75.062 Y155.136 Z-5.202 F25
G1 X74.96 Y155.156 Z-5.206 F25
G1 X74.857 Y155.169 Z-5.21 F25
G1 X74.753 Y155.174 Z-5.214 F25
G1 X74.649 Y155.171 Z-5.217 F25
G1 X74.545 Y155.16 Z-5.221 F25
G1 X74.443 Y155.141 Z-5.225 F25
G1 X74.342 Y155.115 Z-5.229 F25
G1 X74.244 Y155.081 Z-5.233 F25
G1 X74.148 Y155.04 Z-5.236 F25
G1 X74.056 Y154.991 Z-5.24 F25
G1 X73.968 Y154.936 Z-5.244 F25
G1 X73.884 Y154.875 Z-5.248 F25
G1 X73.805 Y154.807 Z-5.251 F25
G1 X73.731 Y154.734 Z-5.255 F25
G1 X73.663 Y154.655 Z-5.259 F25
G1 X73.602 Y154.571 Z-5.263 F25
G1 X73.546 Y154.483 Z-5.266 F25
G1 X73.498 Y154.391 Z-5.27 F25
G1 X73.456 Y154.296 Z-5.274 F25
G1 X73.422 Y154.198 Z-5.278 F25
G1 X73.395 Y154.097 Z-5.281 F25
G1 X73.376 Y153.995 Z-5.285 F25
G1 X73.365 Y153.892 Z-5.289 F25
G1 X73.361 Y153.788 Z-5.293 F25
G1 X73.366 Y153.684 Z-5.296 F25
G1 X73.378 Y153.581 Z-5.3 F25
G1 X73.398 Y153.479 Z-5.304 F25
G1 X73.425 Y153.379 Z-5.308 F25
G1 X73.46 Y153.281 Z-5.311 F25
G1 X73.502 Y153.186 Z-5.315 F25
G1 X73.552 Y153.094 Z-5.319 F25
G1 X73.608 Y153.007 Z-5.323 F25
G1 X73.67 Y152.924 Z-5.326 F25
G1 X73.739 Y152.846 Z-5.33 F25
G1 X73.813 Y152.773 Z-5.334 F25
G1 X73.892 Y152.706 Z-5.338 F25
G1 X73.977 Y152.645 Z-5.341 F25
G1 X74.065 Y152.591 Z-5.345 F25
G1 X74.158 Y152.544 Z-5.349 F25
G1 X74.254 Y152.503 Z-5.353 F25
G1 X74.352 Y152.47 Z-5.356 F25
G1 X74.453 Y152.445 Z-5.36 F25
G1 X74.555 Y152.427 Z-5.364 F25
G1 X74.659 Y152.417 Z-5.368 F25
G1 X74.763 Y152.415 Z-5.371 F25
G1 X74.866 Y152.42 Z-5.375 F25
G1 X74.969 Y152.433 Z-5.379 F25
G1 X75.071 Y152.455 Z-5.383 F25
G1 X75.171 Y152.483 Z-5.386 F25
G1 X75.268 Y152.519 Z-5.39 F25
G1 X75.362 Y152.563 Z-5.394 F25
G1 X75.453 Y152.613 Z-5.398 F25
G1 X75.54 Y152.67 Z-5.401 F25
G1 X75.622 Y152.733 Z-5.405 F25
G1 X75.699 Y152.803 Z-5.409 F25
G1 X75.771 Y152.878 Z-5.413 F25
G1 X75.837 Y152.958 Z-5.417 F25
G1 X75.896 Y153.043 Z-5.42 F25
G1 X75.95 Y153.132 Z-5.424 F25
G1 X75.996 Y153.225 Z-5.428 F25
G1 X76.035 Y153.321 Z-5.432 F25
G1 X76.067 Y153.42 Z-5.435 F25
G1 X76.091 Y153.521 Z-5.439 F25
G1 X76.108 Y153.623 Z-5.443 F25
G1 X76.116 Y153.726 Z-5.447 F25
G1 X76.117 Y153.83 Z-5.45 F25
G1 X76.111 Y153.934 Z-5.454 F25
G1 X76.096 Y154.036 Z-5.458 F25
G1 X76.074 Y154.138 Z-5.462 F25
G1 X76.044 Y154.237 Z-5.465 F25
G1 X76.007 Y154.334 Z-5.469 F25
G1 X75.962 Y154.428 Z-5.473 F25
G1 X75.911 Y154.518 Z-5.477 F25
G1 X75.853 Y154.604 Z-5.48 F25
G1 X75.789 Y154.685 Z-5.484 F25
G1 X75.719 Y154.761 Z-5.488 F25
G1 X75.643 Y154.832 Z-5.492 F25
G1 X75.562 Y154.897 Z-5.495 F25
G1 X75.477 Y154.956 Z-5.499 F25
G1 X75.387 Y155.008 Z-5.503 F25
G1 X75.294 Y155.053 Z-5.507 F25
G1 X75.197 Y155.091 Z-5.51 F25
G1 X75.098 Y155.121 Z-5.514 F25
G1 X74.997 Y155.144 Z-5.518 F25
G1 X74.895 Y155.16 Z-5.522 F25
G1 X74.791 Y155.167 Z-5.525 F25
G1 X74.688 Z-5.529 F25
G1 X74.584 Y155.159 Z-5.533 F25
G1 X74.482 Y155.143 Z-5.537 F25
G1 X74.381 Y155.12 Z-5.54 F25
G1 X74.282 Y155.089 Z-5.544 F25
G1 X74.186 Y155.051 Z-5.548 F25
G1 X74.092 Y155.005 Z-5.552 F25
G1 X74.003 Y154.953 Z-5.555 F25
G1 X73.918 Y154.894 Z-5.559 F25
G1 X73.837 Y154.829 Z-5.563 F25
G1 X73.762 Y154.757 Z-5.567 F25
G1 X73.692 Y154.681 Z-5.57 F25
G1 X73.628 Y154.599 Z-5.574 F25
G1 X73.57 Y154.513 Z-5.578 F25
G1 X73.52 Y154.423 Z-5.582 F25
G1 X73.476 Y154.329 Z-5.586 F25
G1 X73.439 Y154.233 Z-5.589 F25
G1 X73.41 Y154.133 Z-5.593 F25
G1 X73.388 Y154.032 Z-5.597 F25
G1 X73.374 Y153.93 Z-5.601 F25
G1 X73.367 Y153.826 Z-5.604 F25
G1 X73.369 Y153.723 Z-5.608 F25
G1 X73.378 Y153.62 Z-5.612 F25
G1 X73.395 Y153.518 Z-5.616 F25
G1 X73.42 Y153.417 Z-5.619 F25
G1 X73.452 Y153.319 Z-5.623 F25
G1 X73.491 Y153.223 Z-5.627 F25
G1 X73.538 Y153.13 Z-5.631 F25
G1 X73.591 Y153.042 Z-5.634 F25
G1 X73.651 Y152.957 Z-5.638 F25
G1 X73.717 Y152.877 Z-5.642 F25
G1 X73.789 Y152.803 Z-5.646 F25
G1 X73.866 Y152.734 Z-5.649 F25
G1 X73.948 Y152.671 Z-5.653 F25
G1 X74.035 Y152.615 Z-5.657 F25
G1 X74.126 Y152.565 Z-5.661 F25
G1 X74.22 Y152.522 Z-5.664 F25
G1 X74.317 Y152.487 Z-5.668 F25
G1 X74.417 Y152.458 Z-5.672 F25
G1 X74.518 Y152.438 Z-5.676 F25
G1 X74.621 Y152.425 Z-5.679 F25
G1 X74.724 Y152.42 Z-5.683 F25
G1 X74.827 Y152.423 Z-5.687 F25
G1 X74.93 Y152.433 Z-5.691 F25
G1 X75.032 Y152.451 Z-5.694 F25
G1 X75.132 Y152.477 Z-5.698 F25
G1 X75.23 Y152.51 Z-5.702 F25
G1 X75.325 Y152.551 Z-5.706 F25
G1 X75.417 Y152.598 Z-5.709 F25
G1 X75.505 Y152.653 Z-5.713 F25
G1 X75.589 Y152.713 Z-5.717 F25
G1 X75.667 Y152.78 Z-5.721 F25
G1 X75.741 Y152.853 Z-5.724 F25
G1 X75.809 Y152.931 Z-5.728 F25
G1 X75.871 Y153.014 Z-5.732 F25
G1 X75.926 Y153.101 Z-5.736 F25
G1 X75.975 Y153.192 Z-5.739 F25
G1 X76.016 Y153.287 Z-5.743 F25
G1 X76.051 Y153.385 Z-5.747 F25
G1 X76.078 Y153.484 Z-5.751 F25
G1 X76.097 Y153.586 Z-5.754 F25
G1 X76.109 Y153.689 Z-5.758 F25
G1 X76.113 Y153.792 Z-5.762 F25
G3 X73.368 I-1.372 F25
G3 X76.113 I1.372 F25
; MOVEMENT_CUTTING
G1 X76.144 Y154.489 F254
G1 X76.15 Y154.56 F254
G1 X76.139 Y154.629 F254
G1 X76.111 Y154.694 F254
G1 X76.028 Y154.84 F254
G1 X75.978 Y154.945 F254
G1 X75.92 Y155.086 F254
G1 X75.904 Y155.126 F254
G1 X75.891 Y155.158 F254
G1 X75.827 Y155.296 F254
G1 X75.802 Y155.328 F254
G1 X75.676 Y155.45 F254
G1 X75.518 Y155.529 F254
G1 X75.344 Y155.557 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X75.294 Y155.555 Z-5.742 F254
G1 X75.245 Y155.545 Z-5.721 F254
G1 X75.198 Y155.528 Z-5.701 F254
G1 X75.155 Y155.503 Z-5.681 F254
G1 X75.116 Y155.472 Z-5.66 F254
G1 X75.082 Y155.436 Z-5.64 F254
G1 X75.055 Y155.394 Z-5.62 F254
G1 X75.034 Y155.349 Z-5.599 F254
G1 X75.02 Y155.301 Z-5.579 F254
G1 X75.015 Y155.252 Z-5.559 F254
G3 X75.145 Y154.983 I0.317 J-0.012 F254
; MOVEMENT_LINK_DIRECT
G1 X75.405 Y154.793 F254
G3 X75.701 Y154.751 I0.187 J0.256 F254
; MOVEMENT_LEAD_IN
G1 X75.747 Y154.772 Z-5.579 F254
G1 X75.788 Y154.799 Z-5.599 F254
G1 X75.825 Y154.833 Z-5.62 F254
G1 X75.856 Y154.872 Z-5.64 F254
G1 X75.88 Y154.915 Z-5.66 F254
G1 X75.898 Y154.962 Z-5.681 F254
G1 X75.908 Y155.01 Z-5.701 F254
G1 X75.91 Y155.06 Z-5.721 F254
G1 X75.904 Y155.11 Z-5.742 F254
G1 X75.891 Y155.158 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X75.819 Y155.335 F254
G1 X75.804 Y155.37 F254
G1 X75.782 Y155.405 F254
G1 X75.755 Y155.44 F254
G1 X75.722 Y155.475 F254
G1 X75.691 Y155.499 F254
G1 X75.661 Y155.518 F254
G1 X75.621 Y155.536 F254
G1 X75.582 Y155.548 F254
G1 X75.542 Y155.554 F254
G1 X75.502 Y155.556 F254
G1 X75.344 Y155.557 F254
G1 X75.185 Y155.568 F254
G1 X75.027 Y155.596 F254
G1 X74.884 Y155.633 F254
G1 X74.781 Y155.669 F254
G1 X74.635 Y155.711 F254
G1 X74.484 Y155.738 F254
G1 X74.332 Y155.747 F254
G1 X74.18 Y155.74 F254
G1 X74.029 Y155.719 F254
G1 X73.881 Y155.682 F254
G1 X73.737 Y155.633 F254
G1 X73.598 Y155.571 F254
G1 X73.465 Y155.497 F254
G1 X73.338 Y155.412 F254
G1 X73.218 Y155.317 F254
G1 X73.211 Y155.311 F254
G1 X73.09 Y155.165 F254
G1 X73.01 Y154.992 F254
G1 X72.977 Y154.804 F254
G1 X72.992 Y154.614 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X73.008 Y154.567 Z-5.742 F254
G1 X73.031 Y154.523 Z-5.721 F254
G1 X73.061 Y154.483 Z-5.701 F254
G1 X73.097 Y154.448 Z-5.681 F254
G1 X73.137 Y154.419 Z-5.66 F254
G1 X73.182 Y154.397 Z-5.64 F254
G1 X73.229 Y154.382 Z-5.62 F254
G1 X73.279 Y154.375 Z-5.599 F254
G1 X73.328 Z-5.579 F254
G1 X73.377 Y154.384 Z-5.559 F254
G3 X73.442 Y154.408 I-0.077 J0.308 F254
G1 X73.601 Y154.487 F254
; MOVEMENT_LINK_DIRECT
G1 X74.797 Y155.083 F254
; MOVEMENT_LEAD_IN
G1 X74.808 Y155.088 F254
G3 X74.963 Y155.258 I-0.142 J0.284 F254
G1 X74.977 Y155.306 Z-5.579 F254
G1 X74.984 Y155.355 Z-5.599 F254
G1 X74.982 Y155.405 Z-5.62 F254
G1 X74.973 Y155.454 Z-5.64 F254
G1 X74.957 Y155.501 Z-5.66 F254
G1 X74.933 Y155.545 Z-5.681 F254
G1 X74.903 Y155.584 Z-5.701 F254
G1 X74.867 Y155.619 Z-5.721 F254
G1 X74.826 Y155.647 Z-5.742 F254
G1 X74.781 Y155.669 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X74.71 Y155.693 F254
G1 X74.491 Y155.792 F254
G1 X74.392 Y155.842 F254
G1 X74.234 Y155.933 F254
G1 X74.208 Y155.951 F254
G1 X74.08 Y156.032 F254
G1 X73.939 Y156.091 F254
G1 X73.791 Y156.126 F254
G1 X73.639 Y156.141 F254
G1 X73.487 Y156.138 F254
G1 X73.439 Y156.13 F254
G1 X73.236 Y156.069 F254
G1 X73.058 Y155.951 F254
G1 X72.921 Y155.788 F254
G1 X72.836 Y155.593 F254
G1 X72.81 Y155.382 F254
G1 X72.845 Y155.171 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X72.866 Y155.126 Z-5.742 F254
G1 X72.893 Y155.084 Z-5.721 F254
G1 X72.927 Y155.048 Z-5.701 F254
G1 X72.965 Y155.017 Z-5.681 F254
G1 X73.009 Y154.992 Z-5.66 F254
G1 X73.055 Y154.974 Z-5.64 F254
G1 X73.104 Y154.964 Z-5.62 F254
G1 X73.154 Y154.962 Z-5.599 F254
G1 X73.203 Y154.967 Z-5.579 F254
G1 X73.251 Y154.98 Z-5.559 F254
G3 X73.281 Y154.993 I-0.107 J0.299 F254
G1 X73.475 Y155.086 F254
; MOVEMENT_LINK_DIRECT
G1 X74.068 Y155.37 F254
; MOVEMENT_LEAD_IN
G1 X74.154 Y155.411 F254
G3 X74.27 Y155.506 I-0.137 J0.286 F254
G1 X74.297 Y155.548 Z-5.579 F254
G1 X74.317 Y155.594 Z-5.599 F254
G1 X74.33 Y155.642 Z-5.62 F254
G1 X74.334 Y155.692 Z-5.64 F254
G1 X74.331 Y155.741 Z-5.66 F254
G1 X74.321 Y155.79 Z-5.681 F254
G1 X74.303 Y155.836 Z-5.701 F254
G1 X74.277 Y155.879 Z-5.721 F254
G1 X74.246 Y155.918 Z-5.742 F254
G1 X74.208 Y155.951 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X74.075 Y156.044 F254
G1 X73.995 Y156.109 F254
G1 X73.813 Y156.268 F254
G1 X73.758 Y156.322 F254
G1 X73.647 Y156.425 F254
G1 X73.512 Y156.496 F254
G1 X73.307 Y156.519 F254
G1 X73.106 Y156.48 F254
G1 X72.925 Y156.382 F254
G1 X72.783 Y156.233 F254
G1 X72.692 Y156.049 F254
G1 X72.662 Y155.846 F254
G1 X72.694 Y155.643 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X72.719 Y155.584 Z-5.736 F254
G1 X72.75 Y155.528 Z-5.71 F254
G1 X72.788 Y155.476 Z-5.684 F254
G1 X72.831 Y155.428 Z-5.657 F254
G1 X72.876 Y155.388 Z-5.633 F254
G1 X72.925 Y155.352 Z-5.608 F254
G1 X72.977 Y155.321 Z-5.583 F254
G1 X73.031 Y155.295 Z-5.559 F254
G3 X73.926 Y155.865 I0.251 J0.593 F254
; MOVEMENT_LEAD_IN
G1 X73.925 Y155.937 Z-5.588 F254
G1 X73.915 Y156.007 Z-5.617 F254
G1 X73.898 Y156.076 Z-5.646 F254
G1 X73.874 Y156.143 Z-5.675 F254
G1 X73.842 Y156.207 Z-5.704 F254
G1 X73.803 Y156.267 Z-5.733 F254
G1 X73.758 Y156.322 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X73.6 Y156.484 F254
G1 X73.508 Y156.585 F254
G1 X73.471 Y156.628 F254
G1 X73.366 Y156.738 F254
G1 X73.233 Y156.813 F254
G1 X73.054 Y156.83 F254
G1 X72.878 Y156.79 F254
G1 X72.723 Y156.698 F254
G1 X72.604 Y156.562 F254
G1 X72.533 Y156.396 F254
G1 X72.517 Y156.217 F254
G1 X72.558 Y156.041 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X72.579 Y155.999 Z-5.743 F254
G1 X72.604 Y155.96 Z-5.724 F254
G1 X72.633 Y155.924 Z-5.705 F254
G1 X72.675 Y155.881 Z-5.681 F254
G1 X72.721 Y155.844 Z-5.656 F254
G1 X72.772 Y155.811 Z-5.632 F254
G1 X72.825 Y155.784 Z-5.608 F254
G1 X72.881 Y155.764 Z-5.583 F254
G1 X72.939 Y155.749 Z-5.559 F254
G3 X73.575 Y156.158 I0.104 J0.537 F254
; MOVEMENT_LEAD_IN
G1 X73.586 Y156.219 Z-5.584 F254
G1 X73.59 Y156.281 Z-5.61 F254
G1 X73.588 Y156.343 Z-5.635 F254
G1 X73.578 Y156.405 Z-5.66 F254
G1 X73.561 Y156.465 Z-5.686 F254
G1 X73.537 Y156.522 Z-5.711 F254
G1 X73.507 Y156.577 Z-5.737 F254
G1 X73.471 Y156.628 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X73.237 Y156.902 F254
G1 X73.203 Y156.943 F254
G1 X73.099 Y157.055 F254
G1 X72.962 Y157.12 F254
G1 X72.782 Y157.118 F254
G1 X72.614 Y157.054 F254
G1 X72.478 Y156.935 F254
G1 X72.392 Y156.777 F254
G1 X72.366 Y156.599 F254
G1 X72.403 Y156.423 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X72.421 Y156.388 Z-5.746 F254
G1 X72.443 Y156.354 Z-5.73 F254
G1 X72.468 Y156.324 Z-5.714 F254
G1 X72.506 Y156.286 Z-5.692 F254
G1 X72.549 Y156.252 Z-5.669 F254
G1 X72.595 Y156.224 Z-5.647 F254
G1 X72.644 Y156.201 Z-5.625 F254
G1 X72.696 Y156.183 Z-5.603 F254
G1 X72.749 Y156.172 Z-5.581 F254
G1 X72.803 Y156.166 Z-5.559 F254
G3 X73.272 Y156.472 I0.022 J0.48 F254
; MOVEMENT_LEAD_IN
G1 X73.29 Y156.524 Z-5.581 F254
G1 X73.301 Y156.578 Z-5.604 F254
G1 X73.305 Y156.634 Z-5.627 F254
G1 X73.304 Y156.689 Z-5.649 F254
G1 X73.295 Y156.744 Z-5.672 F254
G1 X73.281 Y156.797 Z-5.694 F254
G1 X73.261 Y156.849 Z-5.717 F254
G1 X73.235 Y156.898 Z-5.739 F254
G1 X73.203 Y156.943 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X72.97 Y157.22 F254
G1 X72.867 Y157.331 F254
G1 X72.691 Y157.37 F254
G1 X72.514 Y157.338 F254
G1 X72.364 Y157.239 F254
G1 X72.264 Y157.09 F254
G1 X72.23 Y156.913 F254
G1 X72.268 Y156.737 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X72.321 Y156.66 I0.272 J0.13 F254
G3 X72.97 Y157.22 I0.312 J0.295 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X72.807 Y157.417 F254
G1 X72.778 Y157.454 F254
G1 X72.676 Y157.567 F254
G1 X72.537 Y157.629 F254
G1 X72.37 Y157.608 F254
G1 X72.226 Y157.522 F254
G1 X72.128 Y157.386 F254
G1 X72.093 Y157.221 F254
G1 X72.128 Y157.057 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X72.168 Y156.992 I0.344 J0.165 F254
G3 X72.778 Y157.454 I0.305 J0.231 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X72.554 Y157.729 F254
G1 X72.503 Y157.786 F254
G1 X72.368 Y157.858 F254
G1 X72.219 Y157.842 F254
G1 X72.089 Y157.766 F254
G1 X72 Y157.645 F254
G1 X71.968 Y157.498 F254
G1 X71.999 Y157.351 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X72.037 Y157.295 I0.201 J0.097 F254
G3 X72.554 Y157.729 I0.247 J0.23 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X72.49 Y157.808 F254
G1 X72.452 Y157.854 F254
G1 X72.422 Y157.882 F254
G1 X72.392 Y157.903 F254
G1 X72.362 Y157.92 F254
G1 X72.332 Y157.933 F254
G1 X72.292 Y157.945 F254
G1 X72.252 Y157.951 F254
G1 X72.213 Y157.953 F254
G1 X72.173 Y157.949 F254
G1 X72.133 Y157.94 F254
G1 X72.094 Y157.926 F254
G1 X72.054 Y157.906 F254
G1 X72.014 Y157.877 F254
G1 X71.991 Y157.854 F254
G1 X71.958 Y157.814 F254
G1 X71.935 Y157.775 F254
G1 X71.919 Y157.735 F254
G1 X71.909 Y157.695 F254
G1 X71.904 Y157.656 F254
G1 Y157.616 F254
G1 X71.909 Y157.576 F254
G1 X71.919 Y157.537 F254
G1 X72.014 Y157.315 F254
G1 X72.265 Y156.744 F254
G1 X72.402 Y156.426 F254
G1 X72.594 Y155.951 F254
G1 X72.807 Y155.29 F254
G1 X72.901 Y154.999 F254
G1 X72.944 Y154.84 F254
G1 X73.012 Y154.523 F254
G1 X73.042 Y154.365 F254
G1 X73.082 Y154.047 F254
G1 X73.099 Y153.889 F254
G1 X73.104 Y153.433 F254
G1 X73.074 Y153.254 F254
G1 X73.055 Y153.103 F254
G1 X73.064 Y152.951 F254
G1 X73.093 Y152.801 F254
G1 X73.14 Y152.656 F254
G1 X73.203 Y152.518 F254
G1 X73.28 Y152.386 F254
G1 X73.37 Y152.263 F254
G1 X73.385 Y152.246 F254
G1 X73.527 Y152.122 F254
G1 X73.696 Y152.038 F254
G1 X73.881 Y151.999 F254
G1 X74.069 Y152.009 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X74.117 Y152.023 Z-5.742 F254
G1 X74.162 Y152.044 Z-5.721 F254
G1 X74.203 Y152.073 Z-5.701 F254
G1 X74.239 Y152.107 Z-5.681 F254
G1 X74.269 Y152.147 Z-5.66 F254
G1 X74.293 Y152.19 Z-5.64 F254
G1 X74.309 Y152.237 Z-5.62 F254
G1 X74.318 Y152.286 Z-5.599 F254
G1 X74.319 Y152.336 Z-5.579 F254
G1 X74.313 Y152.385 Z-5.559 F254
G3 X74.261 Y152.503 I-0.31 J-0.066 F254
G1 X74.193 Y152.599 F254
; MOVEMENT_LINK_DIRECT
G1 X73.649 Y153.366 F254
; MOVEMENT_LEAD_IN
G1 X73.643 Y153.374 F254
G3 X73.449 Y153.501 I-0.259 J-0.184 F254
G1 X73.399 Y153.507 Z-5.579 F254
G1 X73.35 Y153.505 Z-5.599 F254
G1 X73.301 Y153.496 Z-5.62 F254
G1 X73.254 Y153.479 Z-5.64 F254
G1 X73.21 Y153.455 Z-5.66 F254
G1 X73.171 Y153.425 Z-5.681 F254
G1 X73.137 Y153.388 Z-5.701 F254
G1 X73.109 Y153.347 Z-5.721 F254
G1 X73.087 Y153.302 Z-5.742 F254
G1 X73.074 Y153.254 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X73.018 Y152.937 F254
G1 X72.966 Y152.734 F254
G1 X72.923 Y152.62 F254
G1 X72.871 Y152.477 F254
G1 X72.895 Y152.283 F254
G1 X72.986 Y152.109 F254
G1 X73.133 Y151.979 F254
G1 X73.315 Y151.91 F254
G1 X73.511 Y151.909 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X73.571 Y151.926 Z-5.737 F254
G1 X73.628 Y151.95 Z-5.711 F254
G1 X73.682 Y151.981 Z-5.686 F254
G1 X73.732 Y152.018 Z-5.66 F254
G1 X73.777 Y152.062 Z-5.635 F254
G1 X73.816 Y152.11 Z-5.61 F254
G1 X73.848 Y152.163 Z-5.584 F254
G1 X73.874 Y152.22 Z-5.559 F254
G3 X73.878 Y152.23 I-0.468 J0.179 F254
G3 X73.303 Y152.913 I-0.486 J0.174 F254
; MOVEMENT_LEAD_IN
G1 X73.242 Y152.898 Z-5.584 F254
G1 X73.184 Y152.877 Z-5.61 F254
G1 X73.128 Y152.848 Z-5.635 F254
G1 X73.077 Y152.813 Z-5.66 F254
G1 X73.03 Y152.772 Z-5.686 F254
G1 X72.988 Y152.726 Z-5.711 F254
G1 X72.952 Y152.675 Z-5.737 F254
G1 X72.923 Y152.62 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X72.857 Y152.461 F254
G1 X72.772 Y152.303 F254
G1 X72.755 Y152.263 F254
G1 X72.745 Y152.224 F254
G1 X72.74 Y152.184 F254
G1 X72.739 Y152.144 F254
G1 X72.742 Y152.105 F254
G1 X72.75 Y152.065 F254
G1 X72.764 Y152.025 F254
G1 X72.785 Y151.986 F254
G1 X72.807 Y151.953 F254
G1 X72.825 Y151.933 F254
G1 X72.847 Y151.912 F254
G1 X72.886 Y151.882 F254
G1 X72.926 Y151.861 F254
G1 X72.966 Y151.846 F254
G1 X73.005 Y151.837 F254
G1 X73.045 Y151.833 F254
G1 X73.085 Y151.834 F254
G1 X73.124 Y151.84 F254
G1 X74.71 Y152.123 F254
G1 X75.185 Y152.204 F254
G1 X75.344 Y152.22 F254
G1 X75.589 Y152.242 F254
G1 X75.74 Y152.263 F254
G1 X75.888 Y152.301 F254
G1 X76.029 Y152.359 F254
G1 X76.162 Y152.433 F254
G1 X76.286 Y152.522 F254
G1 X76.4 Y152.623 F254
G1 X76.504 Y152.735 F254
G1 X76.601 Y152.862 F254
G1 X76.707 Y153.026 F254
G1 X76.794 Y153.189 F254
G1 X76.864 Y153.373 F254
G1 X76.882 Y153.568 F254
G1 X76.848 Y153.762 F254
G1 X76.765 Y153.94 F254
G1 X76.637 Y154.09 F254
G1 X76.612 Y154.112 F254
G1 X76.515 Y154.206 F254
G1 X76.453 Y154.274 F254
G1 X76.136 Y154.653 F254
G1 X76.111 Y154.694 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X76.082 Y154.735 Z-5.742 F254
G1 X76.047 Y154.77 Z-5.721 F254
G1 X76.006 Y154.799 Z-5.701 F254
G1 X75.962 Y154.821 Z-5.681 F254
G1 X75.915 Y154.837 Z-5.66 F254
G1 X75.865 Y154.844 Z-5.64 F254
G1 X75.816 Z-5.62 F254
G1 X75.766 Y154.836 Z-5.599 F254
G1 X75.719 Y154.821 Z-5.579 F254
G1 X75.675 Y154.798 Z-5.559 F254
G3 X75.527 Y154.571 I0.167 J-0.27 F254
; MOVEMENT_LINK_DIRECT
G1 X75.283 Y152.787 F254
; MOVEMENT_LEAD_IN
G1 X75.258 Y152.602 F254
G3 X75.256 Y152.542 I0.315 J-0.043 F254
G1 X75.262 Y152.492 Z-5.579 F254
G1 X75.276 Y152.445 Z-5.599 F254
G1 X75.298 Y152.4 Z-5.62 F254
G1 X75.326 Y152.359 Z-5.64 F254
G1 X75.36 Y152.323 Z-5.66 F254
G1 X75.4 Y152.292 Z-5.681 F254
G1 X75.444 Y152.269 Z-5.701 F254
G1 X75.491 Y152.252 Z-5.721 F254
G1 X75.54 Y152.243 Z-5.742 F254
G1 X75.589 Y152.242 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X76.136 Y152.289 F254
G1 X76.295 Y152.301 F254
G1 X76.453 Y152.309 F254
G1 X76.605 Y152.324 F254
G1 X76.752 Y152.364 F254
G1 X76.892 Y152.425 F254
G1 X77.023 Y152.503 F254
G1 X77.143 Y152.597 F254
G1 X77.253 Y152.708 F254
G1 X77.36 Y152.894 F254
G1 X77.408 Y153.102 F254
G1 X77.396 Y153.316 F254
G1 X77.322 Y153.517 F254
G1 X77.194 Y153.689 F254
G1 X77.023 Y153.817 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X76.977 Y153.836 Z-5.742 F254
G1 X76.928 Y153.847 Z-5.721 F254
G1 X76.878 Y153.85 Z-5.701 F254
G1 X76.829 Y153.846 Z-5.681 F254
G1 X76.78 Y153.834 Z-5.66 F254
G1 X76.735 Y153.814 Z-5.64 F254
G1 X76.692 Y153.788 Z-5.62 F254
G1 X76.655 Y153.755 Z-5.599 F254
G1 X76.623 Y153.717 Z-5.579 F254
G1 X76.597 Y153.674 Z-5.559 F254
G1 X76.595 Y153.669 F254
G1 X76.491 Y153.451 F254
; MOVEMENT_LINK_DIRECT
G1 X76.206 Y152.854 F254
; MOVEMENT_LEAD_IN
G1 X76.162 Y152.763 F254
G3 X76.132 Y152.622 I0.287 J-0.137 F254
G1 X76.136 Y152.572 Z-5.579 F254
G1 X76.149 Y152.524 Z-5.599 F254
G1 X76.168 Y152.478 Z-5.62 F254
G1 X76.195 Y152.436 Z-5.64 F254
G1 X76.228 Y152.398 Z-5.66 F254
G1 X76.266 Y152.367 Z-5.681 F254
G1 X76.309 Y152.341 Z-5.701 F254
G1 X76.355 Y152.323 Z-5.721 F254
G1 X76.404 Y152.312 Z-5.742 F254
G1 X76.453 Y152.309 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X76.771 Y152.323 F254
G1 X77.136 Y152.321 F254
G1 X77.288 Y152.327 F254
G1 X77.435 Y152.366 F254
G1 X77.607 Y152.489 F254
G1 X77.736 Y152.656 F254
G1 X77.811 Y152.854 F254
G1 X77.825 Y153.065 F254
G1 X77.776 Y153.271 F254
G1 X77.67 Y153.454 F254
G1 X77.515 Y153.598 F254
G1 X77.325 Y153.691 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X77.276 Y153.701 Z-5.742 F254
G1 X77.227 Y153.703 Z-5.721 F254
G1 X77.177 Y153.697 Z-5.701 F254
G1 X77.129 Y153.683 Z-5.681 F254
G1 X77.084 Y153.662 Z-5.66 F254
G1 X77.043 Y153.634 Z-5.64 F254
G1 X77.006 Y153.6 Z-5.62 F254
G1 X76.976 Y153.561 Z-5.599 F254
G1 X76.951 Y153.517 Z-5.579 F254
G1 X76.934 Y153.471 Z-5.559 F254
G3 X76.925 Y153.424 I0.306 J-0.085 F254
G1 X76.901 Y153.226 F254
; MOVEMENT_LINK_DIRECT
G1 X76.861 Y152.897 F254
; MOVEMENT_LEAD_IN
G1 X76.834 Y152.676 F254
G3 X76.832 Y152.651 I0.315 J-0.038 F254
G1 X76.834 Y152.601 Z-5.579 F254
G1 X76.843 Y152.553 Z-5.599 F254
G1 X76.86 Y152.506 Z-5.62 F254
G1 X76.885 Y152.462 Z-5.64 F254
G1 X76.915 Y152.423 Z-5.66 F254
G1 X76.952 Y152.389 Z-5.681 F254
G1 X76.993 Y152.361 Z-5.701 F254
G1 X77.038 Y152.34 Z-5.721 F254
G1 X77.086 Y152.327 Z-5.742 F254
G1 X77.136 Y152.321 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X77.65 Y152.317 F254
G1 X77.803 Y152.324 F254
G1 X77.946 Y152.376 F254
G1 X78.104 Y152.527 F254
G1 X78.206 Y152.722 F254
G1 X78.24 Y152.938 F254
G1 X78.202 Y153.154 F254
G1 X78.096 Y153.347 F254
G1 X77.934 Y153.495 F254
G1 X77.734 Y153.583 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X77.697 Y153.589 Z-5.747 F254
G1 X77.661 Y153.591 Z-5.732 F254
G1 X77.624 Y153.59 Z-5.717 F254
G1 X77.56 Y153.581 Z-5.691 F254
G1 X77.497 Y153.566 Z-5.664 F254
G1 X77.436 Y153.544 Z-5.638 F254
G1 X77.377 Y153.517 Z-5.612 F254
G1 X77.322 Y153.484 Z-5.585 F254
G1 X77.27 Y153.445 Z-5.559 F254
G3 X77.209 Y152.521 I0.407 J-0.491 F254
; MOVEMENT_LEAD_IN
G1 X77.261 Y152.471 Z-5.588 F254
G1 X77.317 Y152.428 Z-5.617 F254
G1 X77.378 Y152.391 Z-5.646 F254
G1 X77.442 Y152.361 Z-5.675 F254
G1 X77.51 Y152.339 Z-5.704 F254
G1 X77.58 Y152.324 Z-5.733 F254
G1 X77.65 Y152.317 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X77.722 Y152.316 F254
G1 X77.88 Y152.309 F254
G1 X78.039 Y152.298 F254
G1 X78.191 Y152.294 F254
G1 X78.337 Y152.339 F254
G1 X78.466 Y152.42 F254
G1 X78.574 Y152.528 F254
G1 X78.66 Y152.707 F254
G1 X78.687 Y152.905 F254
G1 X78.652 Y153.101 F254
G1 X78.558 Y153.278 F254
G1 X78.415 Y153.417 F254
G1 X78.237 Y153.505 F254
G1 X78.04 Y153.535 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X77.735 Y153.207 I0.013 J-0.317 F254
G1 X77.745 Y152.934 F254
; MOVEMENT_LEAD_IN
G1 X77.756 Y152.602 F254
G3 X78.039 Y152.298 I0.317 J0.011 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X78.197 Y152.286 F254
G1 X78.356 Y152.273 F254
G1 X78.482 Y152.26 F254
G1 X78.634 Y152.251 F254
G1 X78.781 Y152.295 F254
G1 X78.91 Y152.375 F254
G1 X79.019 Y152.482 F254
G1 X79.023 Y152.489 F254
G1 X79.119 Y152.693 F254
G1 X79.143 Y152.918 F254
G1 X79.092 Y153.138 F254
G1 X78.971 Y153.33 F254
G1 X78.795 Y153.471 F254
G1 X78.582 Y153.547 F254
G1 X78.356 Y153.548 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X78.307 Y153.539 Z-5.742 F254
G1 X78.26 Y153.522 Z-5.721 F254
G1 X78.217 Y153.498 Z-5.701 F254
G1 X78.177 Y153.467 Z-5.681 F254
G1 X78.143 Y153.431 Z-5.66 F254
G1 X78.115 Y153.39 Z-5.64 F254
G1 X78.094 Y153.344 Z-5.62 F254
G1 X78.081 Y153.297 Z-5.599 F254
G1 X78.074 Y153.247 Z-5.579 F254
G1 X78.076 Y153.197 Z-5.559 F254
G3 X78.08 Y153.169 I0.316 J0.035 F254
G1 X78.124 Y152.955 F254
; MOVEMENT_LINK_DIRECT
G1 X78.144 Y152.858 F254
; MOVEMENT_LEAD_IN
G1 X78.193 Y152.616 F254
G1 X78.215 Y152.511 Z-5.603 F254
G1 X78.228 Y152.464 Z-5.623 F254
G1 X78.249 Y152.419 Z-5.642 F254
G1 X78.276 Y152.379 Z-5.662 F254
G1 X78.309 Y152.343 Z-5.682 F254
G1 X78.347 Y152.312 Z-5.702 F254
G1 X78.389 Y152.288 Z-5.722 F254
G1 X78.435 Y152.27 Z-5.742 F254
G1 X78.482 Y152.26 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X78.831 Y152.223 F254
G1 X78.919 Y152.214 F254
G1 X79.071 Y152.204 F254
G1 X79.218 Y152.243 F254
G1 X79.35 Y152.32 F254
G1 X79.463 Y152.422 F254
G1 X79.553 Y152.545 F254
G1 X79.622 Y152.681 F254
G1 X79.666 Y152.827 F254
G1 X79.689 Y152.977 F254
G1 Y152.983 F254
G1 X79.674 Y153.133 F254
G1 X79.628 Y153.278 F254
G1 X79.554 Y153.41 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X79.521 Y153.447 Z-5.742 F254
G1 X79.482 Y153.479 Z-5.721 F254
G1 X79.439 Y153.504 Z-5.701 F254
G1 X79.393 Y153.522 Z-5.681 F254
G1 X79.344 Y153.532 Z-5.66 F254
G1 X79.295 Y153.535 Z-5.64 F254
G1 X79.245 Y153.53 Z-5.62 F254
G1 X79.197 Y153.518 Z-5.599 F254
G1 X79.151 Y153.498 Z-5.579 F254
G1 X79.109 Y153.471 Z-5.559 F254
G3 X79.016 Y153.357 I0.192 J-0.253 F254
G1 X78.973 Y153.269 F254
; MOVEMENT_LINK_DIRECT
G1 X78.745 Y152.801 F254
; MOVEMENT_LEAD_IN
G1 X78.679 Y152.667 F254
G3 X78.651 Y152.574 I0.285 J-0.139 F254
G1 X78.647 Y152.524 Z-5.579 F254
G1 X78.652 Y152.474 Z-5.599 F254
G1 X78.664 Y152.426 Z-5.62 F254
G1 X78.684 Y152.38 Z-5.64 F254
G1 X78.71 Y152.338 Z-5.66 F254
G1 X78.743 Y152.301 Z-5.681 F254
G1 X78.781 Y152.269 Z-5.701 F254
G1 X78.824 Y152.243 Z-5.721 F254
G1 X78.87 Y152.225 Z-5.742 F254
G1 X78.919 Y152.214 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X79.307 Y152.17 F254
G1 X79.355 Y152.163 F254
G1 X79.506 Y152.145 F254
G1 X79.657 Y152.17 F254
G1 X79.814 Y152.269 F254
G1 X79.929 Y152.414 F254
G1 X79.989 Y152.589 F254
G1 X79.988 Y152.775 F254
G1 X79.926 Y152.949 F254
G1 X79.81 Y153.094 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X79.754 Y153.134 Z-5.734 F254
G1 X79.695 Y153.167 Z-5.706 F254
G1 X79.639 Y153.191 Z-5.682 F254
G1 X79.581 Y153.208 Z-5.657 F254
G1 X79.522 Y153.218 Z-5.633 F254
G1 X79.462 Y153.222 Z-5.608 F254
G1 X79.402 Y153.218 Z-5.583 F254
G1 X79.342 Y153.208 Z-5.559 F254
G3 X78.977 Y152.459 I0.118 J-0.522 F254
; MOVEMENT_LEAD_IN
G1 X79.006 Y152.404 Z-5.584 F254
G1 X79.042 Y152.353 Z-5.61 F254
G1 X79.084 Y152.307 Z-5.635 F254
G1 X79.131 Y152.266 Z-5.66 F254
G1 X79.182 Y152.23 Z-5.686 F254
G1 X79.237 Y152.201 Z-5.711 F254
G1 X79.295 Y152.178 Z-5.737 F254
G1 X79.355 Y152.163 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X79.466 Y152.144 F254
G1 X79.783 Y152.087 F254
G1 X79.934 Y152.068 F254
G1 X79.937 F254
G1 X80.082 Y152.138 F254
G1 X80.192 Y152.254 F254
G1 X80.254 Y152.403 F254
G1 X80.258 Y152.564 F254
G1 X80.204 Y152.715 F254
G1 X80.1 Y152.838 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X79.915 Y152.915 I-0.221 J-0.268 F254
G3 X79.783 Y152.087 I-0.043 J-0.417 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X80.1 Y152.03 F254
G1 X80.143 Y152.024 F254
G1 X80.179 Y152.019 F254
G1 X80.238 Y152.025 F254
G1 X80.268 Y152.031 F254
G1 X80.298 Y152.039 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X80.122 Y152.395 I-0.088 J0.178 F254
G3 X80.021 Y152.155 I0.088 J-0.178 F254
; MOVEMENT_LEAD_IN
G3 X80.179 Y152.019 I0.191 J0.063 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X80.219 Y152.021 F254
G1 X80.258 Y152.027 F254
G1 X80.298 Y152.039 F254
G1 X80.338 Y152.057 F254
G1 X80.377 Y152.082 F254
G1 X80.417 Y152.117 F254
G1 X80.44 Y152.144 F254
G1 X80.469 Y152.184 F254
G1 X80.491 Y152.224 F254
G1 X80.505 Y152.263 F254
G1 X80.514 Y152.303 F254
G1 X80.518 Y152.342 F254
G1 X80.517 Y152.382 F254
G1 X80.511 Y152.422 F254
G1 X80.5 Y152.461 F254
G1 X80.486 Y152.493 F254
G1 X80.469 Y152.524 F254
G1 X80.446 Y152.555 F254
G1 X80.417 Y152.586 F254
G1 X80.376 Y152.62 F254
G1 X80.173 Y152.779 F254
G1 X80.1 Y152.838 F254
G1 X79.807 Y153.096 F254
G1 X79.783 Y153.121 F254
G1 X79.669 Y153.254 F254
G1 X79.624 Y153.31 F254
G1 X79.44 Y153.572 F254
G1 X79.389 Y153.639 F254
G1 X79.348 Y153.676 F254
G1 X79.307 Y153.706 F254
G1 X79.282 Y153.719 F254
G1 X79.257 Y153.73 F254
G1 X79.23 Y153.739 F254
G1 X79.203 Y153.746 F254
G1 X79.149 Y153.751 F254
G1 X79.119 F254
G1 X79.089 Y153.747 F254
G1 X79.059 Y153.74 F254
G1 X78.99 Y153.716 F254
G1 X78.831 Y153.665 F254
G1 X78.673 Y153.617 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X78.627 Y153.599 Z-5.742 F254
G1 X78.583 Y153.574 Z-5.721 F254
G1 X78.545 Y153.543 Z-5.701 F254
G1 X78.512 Y153.506 Z-5.681 F254
G1 X78.485 Y153.464 Z-5.66 F254
G1 X78.465 Y153.418 Z-5.64 F254
G1 X78.452 Y153.37 Z-5.62 F254
G1 X78.447 Y153.321 Z-5.599 F254
G1 X78.45 Y153.271 Z-5.579 F254
G1 X78.46 Y153.222 Z-5.559 F254
G3 X79.068 Y153.404 I0.304 J0.091 F254
G3 X78.594 Y153.582 I-0.304 J-0.091 F254
; MOVEMENT_LINK_DIRECT
G1 X78.028 Y153.223 F254
G3 X78.367 Y152.686 I0.17 J-0.268 F254
G3 X78.422 Y153.179 I-0.17 J0.268 F254
G3 X78.195 Y153.367 I-1.119 J-1.119 F254
; MOVEMENT_LEAD_IN
G1 X78.111 Y153.421 Z-5.599 F254
G1 X78.024 Y153.469 Z-5.64 F254
G1 X77.934 Y153.512 Z-5.681 F254
G1 X77.841 Y153.548 Z-5.721 F254
G1 X77.746 Y153.579 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X77.405 Y153.666 F254
G1 X77.246 Y153.716 F254
G1 X77.088 Y153.782 F254
G1 X77.023 Y153.817 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X76.612 Y153.701 I-0.141 J-0.284 F254
G1 X76.6 Y153.662 Z-5.759 F254
G1 X76.588 Y153.624 Z-5.751 F254
G1 X76.576 Y153.587 Z-5.738 F254
G1 X76.565 Y153.552 Z-5.72 F254
G1 X76.564 Y153.533 Z-5.708 F254
G1 X76.572 Y153.499 Z-5.681 F254
G1 X76.578 Y153.469 Z-5.649 F254
G1 X76.584 Y153.444 Z-5.613 F254
G1 X76.589 Y153.423 Z-5.574 F254
G1 X76.592 Y153.409 Z-5.532 F254
G1 X76.594 Y153.4 Z-5.489 F254
G1 X76.595 Y153.397 Z-5.445 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X85.746 Y213.027 F254
G1 Z-2.54 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_RAMP_HELIX
G1 X85.778 Y212.933 Z-2.543 F25
G1 X85.818 Y212.841 Z-2.547 F25
G1 X85.864 Y212.752 Z-2.55 F25
G1 X85.917 Y212.668 Z-2.554 F25
G1 X85.976 Y212.588 Z-2.557 F25
G1 X86.042 Y212.513 Z-2.561 F25
G1 X86.113 Y212.443 Z-2.564 F25
G1 X86.189 Y212.378 Z-2.568 F25
G1 X86.27 Y212.32 Z-2.571 F25
G1 X86.355 Y212.269 Z-2.575 F25
G1 X86.444 Y212.224 Z-2.578 F25
G1 X86.537 Y212.186 Z-2.582 F25
G1 X86.632 Y212.156 Z-2.585 F25
G1 X86.729 Y212.133 Z-2.589 F25
G1 X86.827 Y212.117 Z-2.592 F25
G1 X86.927 Y212.11 Z-2.596 F25
G1 X87.026 Z-2.599 F25
G1 X87.126 Y212.118 Z-2.603 F25
G1 X87.224 Y212.133 Z-2.606 F25
G1 X87.321 Y212.156 Z-2.61 F25
G1 X87.416 Y212.187 Z-2.613 F25
G1 X87.508 Y212.225 Z-2.617 F25
G1 X87.597 Y212.27 Z-2.62 F25
G1 X87.683 Y212.321 Z-2.624 F25
G1 X87.764 Y212.38 Z-2.627 F25
G1 X87.84 Y212.444 Z-2.631 F25
G1 X87.911 Y212.514 Z-2.634 F25
G1 X87.976 Y212.589 Z-2.638 F25
G1 X88.035 Y212.669 Z-2.641 F25
G1 X88.088 Y212.754 Z-2.644 F25
G1 X88.134 Y212.842 Z-2.648 F25
G1 X88.173 Y212.934 Z-2.651 F25
G1 X88.205 Y213.028 Z-2.655 F25
G1 X88.229 Y213.125 Z-2.658 F25
G1 X88.246 Y213.223 Z-2.662 F25
G1 X88.255 Y213.322 Z-2.665 F25
G1 X88.257 Y213.422 Z-2.669 F25
G1 X88.25 Y213.521 Z-2.672 F25
G1 X88.236 Y213.62 Z-2.676 F25
G1 X88.215 Y213.717 Z-2.679 F25
G1 X88.185 Y213.812 Z-2.683 F25
G1 X88.149 Y213.905 Z-2.686 F25
G1 X88.105 Y213.994 Z-2.69 F25
G1 X88.055 Y214.08 Z-2.693 F25
G1 X87.998 Y214.162 Z-2.697 F25
G1 X87.935 Y214.239 Z-2.7 F25
G1 X87.866 Y214.311 Z-2.704 F25
G1 X87.792 Y214.377 Z-2.707 F25
G1 X87.712 Y214.438 Z-2.711 F25
G1 X87.629 Y214.492 Z-2.714 F25
G1 X87.541 Y214.539 Z-2.718 F25
G1 X87.45 Y214.579 Z-2.721 F25
G1 X87.356 Y214.612 Z-2.725 F25
G1 X87.26 Y214.638 Z-2.728 F25
G1 X87.163 Y214.656 Z-2.732 F25
G1 X87.064 Y214.667 Z-2.735 F25
G1 X86.964 Y214.67 Z-2.739 F25
G1 X86.865 Y214.665 Z-2.742 F25
G1 X86.766 Y214.652 Z-2.746 F25
G1 X86.669 Y214.632 Z-2.749 F25
G1 X86.573 Y214.604 Z-2.752 F25
G1 X86.48 Y214.569 Z-2.756 F25
G1 X86.39 Y214.527 Z-2.759 F25
G1 X86.303 Y214.478 Z-2.763 F25
G1 X86.221 Y214.422 Z-2.766 F25
G1 X86.143 Y214.36 Z-2.77 F25
G1 X86.07 Y214.293 Z-2.773 F25
G1 X86.003 Y214.219 Z-2.777 F25
G1 X85.942 Y214.141 Z-2.78 F25
G1 X85.886 Y214.058 Z-2.784 F25
G1 X85.838 Y213.972 Z-2.787 F25
G1 X85.796 Y213.881 Z-2.791 F25
G1 X85.762 Y213.788 Z-2.794 F25
G1 X85.734 Y213.692 Z-2.798 F25
G1 X85.715 Y213.595 Z-2.801 F25
G1 X85.703 Y213.496 Z-2.805 F25
G1 X85.698 Y213.397 Z-2.808 F25
G1 X85.702 Y213.298 Z-2.812 F25
G1 X85.713 Y213.199 Z-2.815 F25
G1 X85.732 Y213.101 Z-2.819 F25
G1 X85.758 Y213.005 Z-2.822 F25
G1 X85.792 Y212.912 Z-2.826 F25
G1 X85.832 Y212.821 Z-2.829 F25
G1 X85.88 Y212.734 Z-2.833 F25
G1 X85.935 Y212.651 Z-2.836 F25
G1 X85.995 Y212.572 Z-2.84 F25
G1 X86.062 Y212.499 Z-2.843 F25
G1 X86.134 Y212.43 Z-2.847 F25
G1 X86.211 Y212.368 Z-2.85 F25
G1 X86.293 Y212.311 Z-2.853 F25
G1 X86.379 Y212.262 Z-2.857 F25
G1 X86.469 Y212.219 Z-2.86 F25
G1 X86.561 Y212.183 Z-2.864 F25
G1 X86.656 Y212.154 Z-2.867 F25
G1 X86.754 Y212.133 Z-2.871 F25
G1 X86.852 Y212.12 Z-2.874 F25
G1 X86.951 Y212.114 Z-2.878 F25
G1 X87.051 Y212.116 Z-2.881 F25
G1 X87.149 Y212.126 Z-2.885 F25
G1 X87.247 Y212.143 Z-2.888 F25
G1 X87.343 Y212.168 Z-2.892 F25
G1 X87.437 Y212.2 Z-2.895 F25
G1 X87.528 Y212.239 Z-2.899 F25
G1 X87.616 Y212.286 Z-2.902 F25
G1 X87.7 Y212.339 Z-2.906 F25
G1 X87.779 Y212.398 Z-2.909 F25
G1 X87.854 Y212.464 Z-2.913 F25
G1 X87.923 Y212.535 Z-2.916 F25
G1 X87.987 Y212.611 Z-2.92 F25
G1 X88.044 Y212.692 Z-2.923 F25
G1 X88.095 Y212.777 Z-2.927 F25
G1 X88.14 Y212.866 Z-2.93 F25
G1 X88.177 Y212.958 Z-2.934 F25
G1 X88.207 Y213.053 Z-2.937 F25
G1 X88.229 Y213.149 Z-2.941 F25
G1 X88.244 Y213.247 Z-2.944 F25
G1 X88.251 Y213.346 Z-2.948 F25
G1 Y213.446 Z-2.951 F25
G1 X88.243 Y213.545 Z-2.955 F25
G1 X88.227 Y213.643 Z-2.958 F25
G1 X88.203 Y213.739 Z-2.961 F25
G1 X88.172 Y213.833 Z-2.965 F25
G1 X88.134 Y213.925 Z-2.968 F25
G1 X88.089 Y214.013 Z-2.972 F25
G1 X88.037 Y214.098 Z-2.975 F25
G1 X87.979 Y214.178 Z-2.979 F25
G1 X87.915 Y214.254 Z-2.982 F25
G1 X87.845 Y214.324 Z-2.986 F25
G1 X87.77 Y214.389 Z-2.989 F25
G1 X87.69 Y214.447 Z-2.993 F25
G1 X87.606 Y214.499 Z-2.996 F25
G1 X87.517 Y214.545 Z-3 F25
G1 X87.426 Y214.583 Z-3.003 F25
G1 X87.332 Y214.615 Z-3.007 F25
G1 X87.236 Y214.638 Z-3.01 F25
G1 X87.138 Y214.655 Z-3.014 F25
G1 X87.039 Y214.663 Z-3.017 F25
G1 X86.94 Y214.664 Z-3.021 F25
G1 X86.841 Y214.658 Z-3.024 F25
G1 X86.743 Y214.643 Z-3.028 F25
G1 X86.647 Y214.621 Z-3.031 F25
G1 X86.552 Y214.592 Z-3.035 F25
G1 X86.46 Y214.555 Z-3.038 F25
G1 X86.371 Y214.511 Z-3.042 F25
G1 X86.286 Y214.461 Z-3.045 F25
G1 X86.204 Y214.404 Z-3.049 F25
G1 X86.128 Y214.341 Z-3.052 F25
G1 X86.057 Y214.272 Z-3.056 F25
G1 X85.991 Y214.198 Z-3.059 F25
G1 X85.931 Y214.118 Z-3.062 F25
G1 X85.878 Y214.035 Z-3.066 F25
G1 X85.831 Y213.948 Z-3.069 F25
G1 X85.791 Y213.857 Z-3.073 F25
G1 X85.759 Y213.764 Z-3.076 F25
G1 X85.734 Y213.668 Z-3.08 F25
G1 X85.716 Y213.57 Z-3.083 F25
G1 X85.706 Y213.472 Z-3.087 F25
G1 X85.703 Y213.373 Z-3.09 F25
G1 X85.709 Y213.274 Z-3.094 F25
G1 X85.722 Y213.176 Z-3.097 F25
G1 X85.742 Y213.079 Z-3.101 F25
G1 X85.77 Y212.984 Z-3.104 F25
G1 X85.805 Y212.892 Z-3.108 F25
G1 X85.848 Y212.802 Z-3.111 F25
G1 X85.897 Y212.716 Z-3.115 F25
G1 X85.953 Y212.634 Z-3.118 F25
G1 X86.015 Y212.557 Z-3.122 F25
G1 X86.082 Y212.485 Z-3.125 F25
G1 X86.156 Y212.418 Z-3.129 F25
G1 X86.234 Y212.357 Z-3.132 F25
G1 X86.316 Y212.303 Z-3.136 F25
G1 X86.403 Y212.255 Z-3.139 F25
G1 X86.493 Y212.214 Z-3.143 F25
G1 X86.586 Y212.18 Z-3.146 F25
G1 X86.681 Y212.153 Z-3.15 F25
G1 X86.778 Y212.134 Z-3.153 F25
G1 X86.877 Y212.122 Z-3.157 F25
G1 X86.975 Y212.119 Z-3.16 F25
G1 X87.074 Y212.122 Z-3.164 F25
G1 X87.172 Y212.134 Z-3.167 F25
G1 X87.27 Y212.153 Z-3.17 F25
G1 X87.365 Y212.179 Z-3.174 F25
G1 X87.458 Y212.213 Z-3.177 F25
G1 X87.548 Y212.254 Z-3.181 F25
G1 X87.634 Y212.302 Z-3.184 F25
G1 X87.717 Y212.357 Z-3.188 F25
G1 X87.795 Y212.417 Z-3.191 F25
G1 X87.868 Y212.484 Z-3.195 F25
G1 X87.936 Y212.556 Z-3.198 F25
G1 X87.998 Y212.633 Z-3.202 F25
G1 X88.053 Y212.715 Z-3.205 F25
G1 X88.102 Y212.801 Z-3.209 F25
G1 X88.145 Y212.89 Z-3.212 F25
G1 X88.18 Y212.983 Z-3.216 F25
G1 X88.208 Y213.077 Z-3.219 F25
G1 X88.229 Y213.174 Z-3.223 F25
G1 X88.242 Y213.272 Z-3.226 F25
G1 X88.247 Y213.371 Z-3.23 F25
G1 X88.245 Y213.47 Z-3.233 F25
G1 X88.235 Y213.568 Z-3.237 F25
G1 X88.217 Y213.665 Z-3.24 F25
G1 X88.192 Y213.761 Z-3.244 F25
G1 X88.159 Y213.854 Z-3.247 F25
G1 X88.12 Y213.945 Z-3.251 F25
G1 X88.073 Y214.032 Z-3.254 F25
G1 X88.02 Y214.115 Z-3.258 F25
G1 X87.96 Y214.194 Z-3.261 F25
G1 X87.895 Y214.268 Z-3.265 F25
G1 X87.824 Y214.336 Z-3.268 F25
G1 X87.748 Y214.399 Z-3.271 F25
G1 X87.667 Y214.456 Z-3.275 F25
G1 X87.582 Y214.507 Z-3.278 F25
G1 X87.494 Y214.55 Z-3.282 F25
G1 X87.402 Y214.587 Z-3.285 F25
G1 X87.308 Y214.616 Z-3.289 F25
G1 X87.211 Y214.638 Z-3.292 F25
G1 X87.114 Y214.653 Z-3.296 F25
G1 X87.015 Y214.659 Z-3.299 F25
G1 X86.916 Z-3.303 F25
G1 X86.818 Y214.65 Z-3.306 F25
G1 X86.72 Y214.634 Z-3.31 F25
G1 X86.624 Y214.61 Z-3.313 F25
G1 X86.531 Y214.579 Z-3.317 F25
G1 X86.44 Y214.541 Z-3.32 F25
G1 X86.352 Y214.495 Z-3.324 F25
G1 X86.268 Y214.443 Z-3.327 F25
G1 X86.188 Y214.385 Z-3.331 F25
G1 X86.113 Y214.321 Z-3.334 F25
G1 X86.044 Y214.251 Z-3.338 F25
G1 X85.98 Y214.176 Z-3.341 F25
G1 X85.922 Y214.096 Z-3.345 F25
G1 X85.87 Y214.012 Z-3.348 F25
G1 X85.825 Y213.924 Z-3.352 F25
G1 X85.788 Y213.833 Z-3.355 F25
G1 X85.757 Y213.739 Z-3.359 F25
G1 X85.733 Y213.643 Z-3.362 F25
G1 X85.718 Y213.546 Z-3.366 F25
G1 X85.709 Y213.448 Z-3.369 F25
G1 Y213.349 Z-3.372 F25
G1 X85.716 Y213.251 Z-3.376 F25
G1 X85.731 Y213.153 Z-3.379 F25
G1 X85.753 Y213.057 Z-3.383 F25
G1 X85.783 Y212.963 Z-3.386 F25
G1 X85.82 Y212.871 Z-3.39 F25
G1 X85.864 Y212.783 Z-3.393 F25
G1 X85.914 Y212.698 Z-3.397 F25
G1 X85.971 Y212.618 Z-3.4 F25
G1 X86.034 Y212.542 Z-3.404 F25
G1 X86.103 Y212.472 Z-3.407 F25
G1 X86.177 Y212.406 Z-3.411 F25
G1 X86.256 Y212.347 Z-3.414 F25
G1 X86.34 Y212.295 Z-3.418 F25
G1 X86.427 Y212.249 Z-3.421 F25
G1 X86.517 Y212.209 Z-3.425 F25
G1 X86.61 Y212.177 Z-3.428 F25
G1 X86.706 Y212.153 Z-3.432 F25
G1 X86.803 Y212.135 Z-3.435 F25
G1 X86.901 Y212.126 Z-3.439 F25
G1 X86.999 Y212.124 Z-3.442 F25
G1 X87.098 Y212.129 Z-3.446 F25
G1 X87.195 Y212.143 Z-3.449 F25
G1 X87.292 Y212.163 Z-3.453 F25
G1 X87.386 Y212.192 Z-3.456 F25
G1 X87.478 Y212.227 Z-3.46 F25
G1 X87.567 Y212.27 Z-3.463 F25
G1 X87.652 Y212.319 Z-3.467 F25
G1 X87.733 Y212.375 Z-3.47 F25
G1 X87.81 Y212.437 Z-3.474 F25
G1 X87.881 Y212.505 Z-3.477 F25
G1 X87.948 Y212.578 Z-3.48 F25
G1 X88.008 Y212.656 Z-3.484 F25
G1 X88.062 Y212.738 Z-3.487 F25
G1 X88.109 Y212.825 Z-3.491 F25
G1 X88.15 Y212.914 Z-3.494 F25
G1 X88.183 Y213.007 Z-3.498 F25
G1 X88.209 Y213.102 Z-3.501 F25
G1 X88.228 Y213.199 Z-3.505 F25
G1 X88.239 Y213.296 Z-3.508 F25
G1 X88.242 Y213.395 Z-3.512 F25
G1 X88.238 Y213.493 Z-3.515 F25
G1 X88.226 Y213.591 Z-3.519 F25
G1 X88.207 Y213.687 Z-3.522 F25
G1 X88.18 Y213.782 Z-3.526 F25
G1 X88.146 Y213.874 Z-3.529 F25
G1 X88.105 Y213.964 Z-3.533 F25
G1 X88.057 Y214.05 Z-3.536 F25
G1 X88.002 Y214.132 Z-3.54 F25
G1 X87.941 Y214.209 Z-3.543 F25
G1 X87.875 Y214.281 Z-3.547 F25
G1 X87.803 Y214.349 Z-3.55 F25
G1 X87.726 Y214.41 Z-3.554 F25
G1 X87.644 Y214.465 Z-3.557 F25
G1 X87.559 Y214.514 Z-3.561 F25
G1 X87.469 Y214.555 Z-3.564 F25
G1 X87.377 Y214.59 Z-3.568 F25
G1 X87.283 Y214.618 Z-3.571 F25
G1 X87.187 Y214.638 Z-3.575 F25
G1 X87.089 Y214.65 Z-3.578 F25
G1 X86.991 Y214.655 Z-3.581 F25
G1 X86.892 Y214.652 Z-3.585 F25
G1 X86.794 Y214.642 Z-3.588 F25
G1 X86.698 Y214.624 Z-3.592 F25
G1 X86.603 Y214.598 Z-3.595 F25
G1 X86.51 Y214.566 Z-3.599 F25
G1 X86.42 Y214.526 Z-3.602 F25
G1 X86.334 Y214.479 Z-3.606 F25
G1 X86.251 Y214.426 Z-3.609 F25
G1 X86.173 Y214.366 Z-3.613 F25
G1 X86.1 Y214.301 Z-3.616 F25
G1 X86.032 Y214.23 Z-3.62 F25
G1 X85.969 Y214.154 Z-3.623 F25
G1 X85.913 Y214.073 Z-3.627 F25
G1 X85.863 Y213.989 Z-3.63 F25
G1 X85.82 Y213.9 Z-3.634 F25
G1 X85.784 Y213.809 Z-3.637 F25
G1 X85.755 Y213.715 Z-3.641 F25
G1 X85.734 Y213.619 Z-3.644 F25
G1 X85.72 Y213.522 Z-3.648 F25
G1 X85.714 Y213.423 Z-3.651 F25
G1 X85.715 Y213.325 Z-3.655 F25
G1 X85.724 Y213.227 Z-3.658 F25
G1 X85.74 Y213.13 Z-3.662 F25
G1 X85.764 Y213.035 Z-3.665 F25
G1 X85.796 Y212.942 Z-3.669 F25
G1 X85.834 Y212.851 Z-3.672 F25
G1 X85.88 Y212.764 Z-3.676 F25
G1 X85.932 Y212.681 Z-3.679 F25
G1 X85.99 Y212.602 Z-3.683 F25
G1 X86.054 Y212.528 Z-3.686 F25
G1 X86.124 Y212.459 Z-3.689 F25
G1 X86.199 Y212.395 Z-3.693 F25
G1 X86.279 Y212.338 Z-3.696 F25
G1 X86.363 Y212.287 Z-3.7 F25
G1 X86.45 Y212.243 Z-3.703 F25
G1 X86.541 Y212.206 Z-3.707 F25
G1 X86.635 Y212.175 Z-3.71 F25
G1 X86.73 Y212.153 Z-3.714 F25
G1 X86.827 Y212.137 Z-3.717 F25
G1 X86.925 Y212.129 Z-3.721 F25
G1 X87.023 Z-3.724 F25
G1 X87.121 Y212.137 Z-3.728 F25
G1 X87.218 Y212.152 Z-3.731 F25
G1 X87.314 Y212.174 Z-3.735 F25
G1 X87.407 Y212.204 Z-3.738 F25
G1 X87.498 Y212.242 Z-3.742 F25
G1 X87.586 Y212.286 Z-3.745 F25
G1 X87.67 Y212.336 Z-3.749 F25
G1 X87.75 Y212.394 Z-3.752 F25
G1 X87.825 Y212.457 Z-3.756 F25
G1 X87.895 Y212.526 Z-3.759 F25
G1 X87.959 Y212.6 Z-3.763 F25
G1 X88.018 Y212.678 Z-3.766 F25
G1 X88.07 Y212.761 Z-3.77 F25
G1 X88.115 Y212.848 Z-3.773 F25
G1 X88.154 Y212.938 Z-3.777 F25
G1 X88.185 Y213.031 Z-3.78 F25
G1 X88.21 Y213.126 Z-3.784 F25
G1 X88.226 Y213.223 Z-3.787 F25
G1 X88.236 Y213.32 Z-3.79 F25
G1 X88.237 Y213.419 Z-3.794 F25
G1 X88.231 Y213.516 Z-3.797 F25
G1 X88.217 Y213.614 Z-3.801 F25
G1 X88.196 Y213.709 Z-3.804 F25
G1 X88.168 Y213.803 Z-3.808 F25
G1 X88.132 Y213.894 Z-3.811 F25
G1 X88.089 Y213.983 Z-3.815 F25
G1 X88.04 Y214.067 Z-3.818 F25
G1 X87.984 Y214.148 Z-3.822 F25
G1 X87.922 Y214.224 Z-3.825 F25
G1 X87.854 Y214.295 Z-3.829 F25
G1 X87.781 Y214.36 Z-3.832 F25
G1 X87.703 Y214.42 Z-3.836 F25
G1 X87.621 Y214.473 Z-3.839 F25
G1 X87.535 Y214.52 Z-3.843 F25
G1 X87.445 Y214.56 Z-3.846 F25
G1 X87.353 Y214.593 Z-3.85 F25
G1 X87.258 Y214.618 Z-3.853 F25
G1 X87.162 Y214.637 Z-3.857 F25
G1 X87.065 Y214.647 Z-3.86 F25
G1 X86.967 Y214.65 Z-3.864 F25
G1 X86.869 Y214.646 Z-3.867 F25
G1 X86.772 Y214.633 Z-3.871 F25
G1 X86.676 Y214.614 Z-3.874 F25
G1 X86.582 Y214.587 Z-3.878 F25
G1 X86.49 Y214.552 Z-3.881 F25
G1 X86.401 Y214.511 Z-3.885 F25
G1 X86.316 Y214.463 Z-3.888 F25
G1 X86.235 Y214.408 Z-3.891 F25
G1 X86.158 Y214.347 Z-3.895 F25
G1 X86.086 Y214.281 Z-3.898 F25
G1 X86.02 Y214.209 Z-3.902 F25
G1 X85.959 Y214.132 Z-3.905 F25
G1 X85.904 Y214.05 Z-3.909 F25
G1 X85.856 Y213.965 Z-3.912 F25
G1 X85.815 Y213.876 Z-3.916 F25
G1 X85.781 Y213.784 Z-3.919 F25
G1 X85.754 Y213.69 Z-3.923 F25
G1 X85.734 Y213.594 Z-3.926 F25
G1 X85.722 Y213.497 Z-3.93 F25
G1 X85.718 Y213.399 Z-3.933 F25
G1 X85.721 Y213.301 Z-3.937 F25
G1 X85.732 Y213.204 Z-3.94 F25
G1 X85.75 Y213.108 Z-3.944 F25
G1 X85.776 Y213.014 Z-3.947 F25
G1 X85.809 Y212.922 Z-3.951 F25
G1 X85.849 Y212.832 Z-3.954 F25
G1 X85.896 Y212.746 Z-3.958 F25
G1 X85.949 Y212.664 Z-3.961 F25
G1 X86.009 Y212.587 Z-3.965 F25
G1 X86.074 Y212.514 Z-3.968 F25
G1 X86.145 Y212.447 Z-3.972 F25
G1 X86.221 Y212.385 Z-3.975 F25
G1 X86.301 Y212.329 Z-3.979 F25
G1 X86.386 Y212.28 Z-3.982 F25
G1 X86.474 Y212.238 Z-3.986 F25
G1 X86.565 Y212.202 Z-3.989 F25
G1 X86.659 Y212.174 Z-3.993 F25
G1 X86.754 Y212.153 Z-3.996 F25
G1 X86.851 Y212.14 Z-3.999 F25
G1 X86.949 Y212.134 Z-4.003 F25
G1 X87.047 Y212.135 Z-4.006 F25
G1 X87.144 Y212.145 Z-4.01 F25
G1 X87.241 Y212.162 Z-4.013 F25
G1 X87.335 Y212.186 Z-4.017 F25
G1 X87.428 Y212.217 Z-4.02 F25
G1 X87.518 Y212.256 Z-4.024 F25
G1 X87.604 Y212.302 Z-4.027 F25
G1 X87.687 Y212.354 Z-4.031 F25
G1 X87.765 Y212.412 Z-4.034 F25
G1 X87.839 Y212.476 Z-4.038 F25
G1 X87.907 Y212.546 Z-4.041 F25
G1 X87.97 Y212.621 Z-4.045 F25
G1 X88.027 Y212.701 Z-4.048 F25
G1 X88.077 Y212.784 Z-4.052 F25
G1 X88.121 Y212.872 Z-4.055 F25
G1 X88.158 Y212.962 Z-4.059 F25
G1 X88.187 Y213.055 Z-4.062 F25
G1 X88.209 Y213.151 Z-4.066 F25
G1 X88.224 Y213.247 Z-4.069 F25
G1 X88.232 Y213.345 Z-4.073 F25
G1 X88.231 Y213.442 Z-4.076 F25
G1 X88.223 Y213.54 Z-4.08 F25
G1 X88.208 Y213.636 Z-4.083 F25
G1 X88.185 Y213.731 Z-4.087 F25
G1 X88.155 Y213.824 Z-4.09 F25
G1 X88.118 Y213.914 Z-4.094 F25
G1 X88.073 Y214.001 Z-4.097 F25
G1 X88.022 Y214.085 Z-4.1 F25
G1 X87.965 Y214.164 Z-4.104 F25
G1 X87.902 Y214.239 Z-4.107 F25
G1 X87.833 Y214.308 Z-4.111 F25
G1 X87.76 Y214.372 Z-4.114 F25
G1 X87.681 Y214.43 Z-4.118 F25
G1 X87.598 Y214.481 Z-4.121 F25
G1 X87.511 Y214.526 Z-4.125 F25
G1 X87.422 Y214.564 Z-4.128 F25
G1 X87.329 Y214.595 Z-4.132 F25
G1 X87.234 Y214.619 Z-4.135 F25
G1 X87.138 Y214.635 Z-4.139 F25
G1 X87.041 Y214.644 Z-4.142 F25
G1 X86.943 Y214.645 Z-4.146 F25
G1 X86.846 Y214.638 Z-4.149 F25
G1 X86.749 Y214.624 Z-4.153 F25
G1 X86.654 Y214.603 Z-4.156 F25
G1 X86.561 Y214.574 Z-4.16 F25
G1 X86.47 Y214.538 Z-4.163 F25
G1 X86.382 Y214.495 Z-4.167 F25
G1 X86.298 Y214.446 Z-4.17 F25
G1 X86.218 Y214.39 Z-4.174 F25
G1 X86.143 Y214.328 Z-4.177 F25
G1 X86.073 Y214.26 Z-4.181 F25
G1 X86.008 Y214.187 Z-4.184 F25
G1 X85.949 Y214.109 Z-4.188 F25
G1 X85.896 Y214.027 Z-4.191 F25
G1 X85.85 Y213.941 Z-4.195 F25
G1 X85.811 Y213.852 Z-4.198 F25
G1 X85.778 Y213.76 Z-4.202 F25
G1 X85.753 Y213.666 Z-4.205 F25
G1 X85.736 Y213.57 Z-4.208 F25
G1 X85.726 Y213.473 Z-4.212 F25
G1 X85.723 Y213.376 Z-4.215 F25
G1 X85.728 Y213.278 Z-4.219 F25
G1 X85.741 Y213.182 Z-4.222 F25
G1 X85.761 Y213.086 Z-4.226 F25
G1 X85.788 Y212.993 Z-4.229 F25
G1 X85.822 Y212.902 Z-4.233 F25
G1 X85.864 Y212.813 Z-4.236 F25
G1 X85.912 Y212.729 Z-4.24 F25
G1 X85.967 Y212.648 Z-4.243 F25
G1 X86.028 Y212.572 Z-4.247 F25
G1 X86.094 Y212.501 Z-4.25 F25
G1 X86.166 Y212.435 Z-4.254 F25
G1 X86.243 Y212.375 Z-4.257 F25
G1 X86.324 Y212.321 Z-4.261 F25
G1 X86.409 Y212.274 Z-4.264 F25
G1 X86.498 Y212.233 Z-4.268 F25
G1 X86.59 Y212.199 Z-4.271 F25
G1 X86.683 Y212.173 Z-4.275 F25
G1 X86.779 Y212.154 Z-4.278 F25
G1 X86.876 Y212.142 Z-4.282 F25
G1 X86.973 Y212.138 Z-4.285 F25
G1 X87.07 Y212.142 Z-4.289 F25
G1 X87.167 Y212.153 Z-4.292 F25
G1 X87.263 Y212.171 Z-4.296 F25
G1 X87.356 Y212.197 Z-4.299 F25
G1 X87.448 Y212.231 Z-4.303 F25
G1 X87.537 Y212.271 Z-4.306 F25
G1 X87.622 Y212.318 Z-4.309 F25
G1 X87.703 Y212.371 Z-4.313 F25
G1 X87.78 Y212.431 Z-4.316 F25
G1 X87.852 Y212.496 Z-4.32 F25
G1 X87.919 Y212.567 Z-4.323 F25
G1 X87.98 Y212.643 Z-4.327 F25
G1 X88.035 Y212.723 Z-4.33 F25
G1 X88.084 Y212.808 Z-4.334 F25
G1 X88.126 Y212.896 Z-4.337 F25
G1 X88.161 Y212.986 Z-4.341 F25
G1 X88.188 Y213.08 Z-4.344 F25
G1 X88.209 Y213.175 Z-4.348 F25
G1 X88.222 Y213.271 Z-4.351 F25
G1 X88.227 Y213.369 Z-4.355 F25
G1 X88.225 Y213.466 Z-4.358 F25
G1 X88.215 Y213.563 Z-4.362 F25
G1 X88.198 Y213.659 Z-4.365 F25
G1 X88.174 Y213.753 Z-4.369 F25
G1 X88.142 Y213.845 Z-4.372 F25
G1 X88.103 Y213.934 Z-4.376 F25
G1 X88.057 Y214.02 Z-4.379 F25
G1 X88.005 Y214.102 Z-4.383 F25
G1 X87.947 Y214.179 Z-4.386 F25
G1 X87.883 Y214.252 Z-4.39 F25
G1 X87.813 Y214.32 Z-4.393 F25
G1 X87.738 Y214.382 Z-4.397 F25
G1 X87.659 Y214.438 Z-4.4 F25
G1 X87.575 Y214.488 Z-4.404 F25
G1 X87.488 Y214.531 Z-4.407 F25
G1 X87.398 Y214.568 Z-4.411 F25
G1 X87.305 Y214.597 Z-4.414 F25
G1 X87.21 Y214.619 Z-4.417 F25
G1 X87.114 Y214.633 Z-4.421 F25
G1 X87.017 Y214.64 Z-4.424 F25
G1 X86.92 Y214.639 Z-4.428 F25
G1 X86.823 Y214.631 Z-4.431 F25
G1 X86.727 Y214.615 Z-4.435 F25
G1 X86.632 Y214.592 Z-4.438 F25
G1 X86.54 Y214.561 Z-4.442 F25
G1 X86.45 Y214.524 Z-4.445 F25
G1 X86.364 Y214.479 Z-4.449 F25
G1 X86.281 Y214.428 Z-4.452 F25
G1 X86.202 Y214.371 Z-4.456 F25
G1 X86.129 Y214.308 Z-4.459 F25
G1 X86.06 Y214.239 Z-4.463 F25
G1 X85.997 Y214.166 Z-4.466 F25
G1 X85.94 Y214.087 Z-4.47 F25
G1 X85.889 Y214.004 Z-4.473 F25
G1 X85.844 Y213.918 Z-4.477 F25
G1 X85.807 Y213.828 Z-4.48 F25
G1 X85.776 Y213.736 Z-4.484 F25
G1 X85.753 Y213.642 Z-4.487 F25
G1 X85.737 Y213.546 Z-4.491 F25
G1 X85.729 Y213.449 Z-4.494 F25
G1 X85.728 Y213.352 Z-4.498 F25
G1 X85.735 Y213.255 Z-4.501 F25
G1 X85.75 Y213.159 Z-4.505 F25
G1 X85.771 Y213.065 Z-4.508 F25
G1 X85.8 Y212.972 Z-4.512 F25
G1 X85.837 Y212.882 Z-4.515 F25
G1 X85.88 Y212.795 Z-4.518 F25
G1 X85.929 Y212.711 Z-4.522 F25
G1 X85.985 Y212.632 Z-4.525 F25
G1 X86.047 Y212.557 Z-4.529 F25
G1 X86.115 Y212.488 Z-4.532 F25
G1 X86.188 Y212.423 Z-4.536 F25
G1 X86.265 Y212.365 Z-4.539 F25
G1 X86.347 Y212.313 Z-4.543 F25
G1 X86.433 Y212.267 Z-4.546 F25
G1 X86.522 Y212.229 Z-4.55 F25
G1 X86.614 Y212.197 Z-4.553 F25
G1 X86.707 Y212.172 Z-4.557 F25
G1 X86.803 Y212.155 Z-4.56 F25
G1 X86.899 Y212.145 Z-4.564 F25
G1 X86.996 Y212.143 Z-4.567 F25
G1 X87.093 Y212.149 Z-4.571 F25
G1 X87.189 Y212.162 Z-4.574 F25
G1 X87.284 Y212.182 Z-4.578 F25
G1 X87.377 Y212.21 Z-4.581 F25
G1 X87.468 Y212.244 Z-4.585 F25
G1 X87.555 Y212.286 Z-4.588 F25
G1 X87.639 Y212.334 Z-4.592 F25
G1 X87.72 Y212.389 Z-4.595 F25
G1 X87.795 Y212.45 Z-4.599 F25
G1 X87.866 Y212.517 Z-4.602 F25
G1 X87.931 Y212.588 Z-4.606 F25
G1 X87.99 Y212.665 Z-4.609 F25
G1 X88.044 Y212.746 Z-4.613 F25
G1 X88.09 Y212.831 Z-4.616 F25
G1 X88.13 Y212.919 Z-4.619 F25
G1 X88.164 Y213.011 Z-4.623 F25
G1 X88.189 Y213.104 Z-4.626 F25
G1 X88.208 Y213.199 Z-4.63 F25
G1 X88.219 Y213.296 Z-4.633 F25
G1 X88.223 Y213.392 Z-4.637 F25
G1 X88.219 Y213.489 Z-4.64 F25
G1 X88.207 Y213.585 Z-4.644 F25
G1 X88.188 Y213.68 Z-4.647 F25
G1 X88.162 Y213.774 Z-4.651 F25
G1 X88.129 Y213.865 Z-4.654 F25
G1 X88.088 Y213.953 Z-4.658 F25
G1 X88.041 Y214.037 Z-4.661 F25
G1 X87.988 Y214.118 Z-4.665 F25
G1 X87.928 Y214.194 Z-4.668 F25
G1 X87.863 Y214.266 Z-4.672 F25
G1 X87.792 Y214.332 Z-4.675 F25
G1 X87.716 Y214.393 Z-4.679 F25
G1 X87.636 Y214.447 Z-4.682 F25
G1 X87.552 Y214.495 Z-4.686 F25
G1 X87.464 Y214.536 Z-4.689 F25
G1 X87.374 Y214.571 Z-4.693 F25
G1 X87.281 Y214.598 Z-4.696 F25
G1 X87.186 Y214.618 Z-4.7 F25
G1 X87.09 Y214.63 Z-4.703 F25
G1 X86.993 Y214.635 Z-4.707 F25
G1 X86.896 Y214.633 Z-4.71 F25
G1 X86.8 Y214.623 Z-4.714 F25
G1 X86.704 Y214.605 Z-4.717 F25
G1 X86.611 Y214.58 Z-4.721 F25
G1 X86.52 Y214.548 Z-4.724 F25
G1 X86.431 Y214.509 Z-4.727 F25
G1 X86.346 Y214.464 Z-4.731 F25
G1 X86.264 Y214.411 Z-4.734 F25
G1 X86.187 Y214.353 Z-4.738 F25
G1 X86.115 Y214.289 Z-4.741 F25
G1 X86.048 Y214.219 Z-4.745 F25
G1 X85.986 Y214.144 Z-4.748 F25
G1 X85.931 Y214.065 Z-4.752 F25
G1 X85.882 Y213.982 Z-4.755 F25
G1 X85.839 Y213.895 Z-4.759 F25
G1 X85.803 Y213.805 Z-4.762 F25
G1 X85.775 Y213.712 Z-4.766 F25
G1 X85.754 Y213.618 Z-4.769 F25
G1 X85.74 Y213.522 Z-4.773 F25
G1 X85.733 Y213.426 Z-4.776 F25
G1 X85.734 Y213.329 Z-4.78 F25
G1 X85.743 Y213.232 Z-4.783 F25
G1 X85.759 Y213.137 Z-4.787 F25
G1 X85.783 Y213.043 Z-4.79 F25
G1 X85.813 Y212.951 Z-4.794 F25
G1 X85.851 Y212.862 Z-4.797 F25
G1 X85.895 Y212.776 Z-4.801 F25
G1 X85.947 Y212.694 Z-4.804 F25
G1 X86.004 Y212.616 Z-4.808 F25
G1 X86.067 Y212.543 Z-4.811 F25
G1 X86.136 Y212.475 Z-4.815 F25
G1 X86.209 Y212.412 Z-4.818 F25
G1 X86.288 Y212.356 Z-4.822 F25
G1 X86.37 Y212.306 Z-4.825 F25
G1 X86.456 Y212.262 Z-4.828 F25
G1 X86.546 Y212.225 Z-4.832 F25
G1 X86.637 Y212.195 Z-4.835 F25
G1 X86.731 Y212.172 Z-4.839 F25
G1 X86.827 Y212.157 Z-4.842 F25
G1 X86.923 Y212.149 Z-4.846 F25
G1 X87.02 Z-4.849 F25
G1 X87.116 Y212.156 Z-4.853 F25
G1 X87.212 Y212.171 Z-4.856 F25
G1 X87.306 Y212.193 Z-4.86 F25
G1 X87.398 Y212.222 Z-4.863 F25
G1 X87.487 Y212.258 Z-4.867 F25
G1 X87.574 Y212.302 Z-4.87 F25
G1 X87.657 Y212.351 Z-4.874 F25
G1 X87.735 Y212.408 Z-4.877 F25
G1 X87.81 Y212.47 Z-4.881 F25
G1 X87.879 Y212.537 Z-4.884 F25
G1 X87.942 Y212.61 Z-4.888 F25
G1 X88 Y212.687 Z-4.891 F25
G1 X88.051 Y212.769 Z-4.895 F25
G1 X88.096 Y212.854 Z-4.898 F25
G1 X88.135 Y212.943 Z-4.902 F25
G1 X88.166 Y213.034 Z-4.905 F25
G1 X88.19 Y213.128 Z-4.909 F25
G1 X88.207 Y213.223 Z-4.912 F25
G1 X88.216 Y213.319 Z-4.916 F25
G1 X88.218 Y213.416 Z-4.919 F25
G1 X88.212 Y213.512 Z-4.923 F25
G1 X88.198 Y213.608 Z-4.926 F25
G1 X88.178 Y213.702 Z-4.93 F25
G1 X88.15 Y213.794 Z-4.933 F25
G1 X88.115 Y213.884 Z-4.936 F25
G1 X88.073 Y213.971 Z-4.94 F25
G1 X88.025 Y214.055 Z-4.943 F25
G1 X87.97 Y214.134 Z-4.947 F25
G1 X87.909 Y214.209 Z-4.95 F25
G1 X87.842 Y214.279 Z-4.954 F25
G1 X87.771 Y214.344 Z-4.957 F25
G1 X87.694 Y214.402 Z-4.961 F25
G1 X87.613 Y214.455 Z-4.964 F25
G1 X87.528 Y214.501 Z-4.968 F25
G1 X87.44 Y214.541 Z-4.971 F25
G1 X87.349 Y214.573 Z-4.975 F25
G1 X87.256 Y214.599 Z-4.978 F25
G1 X87.162 Y214.617 Z-4.982 F25
G1 X87.066 Y214.627 Z-4.985 F25
G1 X86.969 Y214.631 Z-4.989 F25
G1 X86.873 Y214.626 Z-4.992 F25
G1 X86.777 Y214.614 Z-4.996 F25
G1 X86.683 Y214.595 Z-4.999 F25
G1 X86.59 Y214.569 Z-5.003 F25
G1 X86.5 Y214.535 Z-5.006 F25
G1 X86.412 Y214.495 Z-5.01 F25
G1 X86.328 Y214.447 Z-5.013 F25
G1 X86.248 Y214.394 Z-5.017 F25
G1 X86.173 Y214.334 Z-5.02 F25
G1 X86.102 Y214.269 Z-5.024 F25
G1 X86.036 Y214.198 Z-5.027 F25
G1 X85.976 Y214.122 Z-5.031 F25
G1 X85.922 Y214.042 Z-5.034 F25
G1 X85.875 Y213.958 Z-5.037 F25
G1 X85.834 Y213.871 Z-5.041 F25
G1 X85.8 Y213.781 Z-5.044 F25
G1 X85.774 Y213.688 Z-5.048 F25
G1 X85.754 Y213.594 Z-5.051 F25
G1 X85.742 Y213.498 Z-5.055 F25
G1 X85.738 Y213.402 Z-5.058 F25
G1 X85.741 Y213.305 Z-5.062 F25
G1 X85.751 Y213.209 Z-5.065 F25
G1 X85.769 Y213.115 Z-5.069 F25
G1 X85.794 Y213.022 Z-5.072 F25
G1 X85.826 Y212.931 Z-5.076 F25
G1 X85.865 Y212.843 Z-5.079 F25
G1 X85.911 Y212.759 Z-5.083 F25
G1 X85.964 Y212.678 Z-5.086 F25
G1 X86.022 Y212.601 Z-5.09 F25
G1 X86.087 Y212.53 Z-5.093 F25
G1 X86.156 Y212.463 Z-5.097 F25
G1 X86.231 Y212.402 Z-5.1 F25
G1 X86.31 Y212.347 Z-5.104 F25
G1 X86.393 Y212.299 Z-5.107 F25
G1 X86.48 Y212.257 Z-5.111 F25
G1 X86.569 Y212.222 Z-5.114 F25
G1 X86.661 Y212.194 Z-5.118 F25
G1 X86.755 Y212.173 Z-5.121 F25
G1 X86.851 Y212.159 Z-5.125 F25
G1 X86.947 Y212.153 Z-5.128 F25
G1 X87.043 Y212.155 Z-5.132 F25
G1 X87.139 Y212.164 Z-5.135 F25
G1 X87.234 Y212.18 Z-5.138 F25
G1 X87.327 Y212.204 Z-5.142 F25
G1 X87.418 Y212.235 Z-5.145 F25
G1 X87.507 Y212.273 Z-5.149 F25
G1 X87.592 Y212.317 Z-5.152 F25
G1 X87.674 Y212.369 Z-5.156 F25
G1 X87.751 Y212.426 Z-5.159 F25
G1 X87.824 Y212.489 Z-5.163 F25
G1 X87.891 Y212.558 Z-5.166 F25
G1 X87.953 Y212.631 Z-5.17 F25
G1 X88.009 Y212.709 Z-5.173 F25
G1 X88.059 Y212.792 Z-5.177 F25
G1 X88.102 Y212.878 Z-5.18 F25
G1 X88.138 Y212.967 Z-5.184 F25
G1 X88.168 Y213.058 Z-5.187 F25
G1 X88.19 Y213.152 Z-5.191 F25
G1 X88.205 Y213.247 Z-5.194 F25
G1 X88.212 Y213.343 Z-5.198 F25
G1 Y213.439 Z-5.201 F25
G1 X88.204 Y213.535 Z-5.205 F25
G1 X88.189 Y213.63 Z-5.208 F25
G1 X88.167 Y213.723 Z-5.212 F25
G1 X88.137 Y213.815 Z-5.215 F25
G1 X88.101 Y213.904 Z-5.219 F25
G1 X88.057 Y213.99 Z-5.222 F25
G1 X88.008 Y214.072 Z-5.226 F25
G1 X87.951 Y214.15 Z-5.229 F25
G1 X87.889 Y214.223 Z-5.233 F25
G1 X87.822 Y214.292 Z-5.236 F25
G1 X87.749 Y214.355 Z-5.24 F25
G1 X87.672 Y214.412 Z-5.243 F25
G1 X87.59 Y214.463 Z-5.246 F25
G1 X87.505 Y214.507 Z-5.25 F25
G1 X87.417 Y214.545 Z-5.253 F25
G1 X87.326 Y214.576 Z-5.257 F25
G1 X87.233 Y214.599 Z-5.26 F25
G1 X87.138 Y214.615 Z-5.264 F25
G1 X87.042 Y214.624 Z-5.267 F25
G1 X86.946 Y214.625 Z-5.271 F25
G1 X86.85 Y214.619 Z-5.274 F25
G1 X86.755 Y214.606 Z-5.278 F25
G1 X86.662 Y214.585 Z-5.281 F25
G1 X86.57 Y214.557 Z-5.285 F25
G1 X86.48 Y214.521 Z-5.288 F25
G1 X86.394 Y214.479 Z-5.292 F25
G1 X86.311 Y214.431 Z-5.295 F25
G1 X86.232 Y214.376 Z-5.299 F25
G1 X86.158 Y214.315 Z-5.302 F25
G1 X86.089 Y214.248 Z-5.306 F25
G1 X86.025 Y214.177 Z-5.309 F25
G1 X85.967 Y214.1 Z-5.313 F25
G1 X85.914 Y214.02 Z-5.316 F25
G1 X85.869 Y213.935 Z-5.32 F25
G1 X85.83 Y213.847 Z-5.323 F25
G1 X85.798 Y213.757 Z-5.327 F25
G1 X85.773 Y213.664 Z-5.33 F25
G1 X85.755 Y213.57 Z-5.334 F25
G1 X85.745 Y213.474 Z-5.337 F25
G1 X85.743 Y213.378 Z-5.341 F25
G1 X85.747 Y213.283 Z-5.344 F25
G1 X85.759 Y213.187 Z-5.347 F25
G1 X85.779 Y213.093 Z-5.351 F25
G1 X85.806 Y213.001 Z-5.354 F25
G1 X85.84 Y212.912 Z-5.358 F25
G1 X85.88 Y212.825 Z-5.361 F25
G1 X85.928 Y212.741 Z-5.365 F25
G1 X85.981 Y212.662 Z-5.368 F25
G1 X86.041 Y212.587 Z-5.372 F25
G1 X86.106 Y212.516 Z-5.375 F25
G1 X86.177 Y212.451 Z-5.379 F25
G1 X86.253 Y212.392 Z-5.382 F25
G1 X86.332 Y212.339 Z-5.386 F25
G1 X86.416 Y212.292 Z-5.389 F25
G1 X86.503 Y212.252 Z-5.393 F25
G1 X86.593 Y212.219 Z-5.396 F25
G1 X86.686 Y212.193 Z-5.4 F25
G1 X86.78 Y212.174 Z-5.403 F25
G1 X86.875 Y212.162 Z-5.407 F25
G1 X86.971 Y212.158 Z-5.41 F25
G1 X87.067 Y212.161 Z-5.414 F25
G1 X87.162 Y212.172 Z-5.417 F25
G1 X87.256 Y212.19 Z-5.421 F25
G1 X87.348 Y212.215 Z-5.424 F25
G1 X87.438 Y212.248 Z-5.428 F25
G1 X87.526 Y212.287 Z-5.431 F25
G1 X87.61 Y212.333 Z-5.435 F25
G1 X87.69 Y212.386 Z-5.438 F25
G1 X87.766 Y212.444 Z-5.442 F25
G1 X87.837 Y212.509 Z-5.445 F25
G1 X87.903 Y212.578 Z-5.449 F25
G1 X87.963 Y212.653 Z-5.452 F25
G1 X88.017 Y212.732 Z-5.455 F25
G1 X88.065 Y212.815 Z-5.459 F25
G1 X88.107 Y212.901 Z-5.462 F25
G1 X88.141 Y212.99 Z-5.466 F25
G1 X88.169 Y213.082 Z-5.469 F25
G1 X88.189 Y213.176 Z-5.473 F25
G1 X88.202 Y213.271 Z-5.476 F25
G1 X88.208 Y213.366 Z-5.48 F25
G1 X88.206 Y213.462 Z-5.483 F25
G1 X88.196 Y213.558 Z-5.487 F25
G1 X88.18 Y213.652 Z-5.49 F25
G1 X88.156 Y213.745 Z-5.494 F25
G1 X88.124 Y213.835 Z-5.497 F25
G1 X88.086 Y213.923 Z-5.501 F25
G1 X88.042 Y214.008 Z-5.504 F25
G1 X87.99 Y214.089 Z-5.508 F25
G1 X87.933 Y214.165 Z-5.511 F25
G1 X87.87 Y214.237 Z-5.515 F25
G1 X87.801 Y214.304 Z-5.518 F25
G1 X87.728 Y214.365 Z-5.522 F25
G1 X87.65 Y214.421 Z-5.525 F25
G1 X87.568 Y214.47 Z-5.529 F25
G1 X87.482 Y214.512 Z-5.532 F25
G1 X87.393 Y214.548 Z-5.536 F25
G1 X87.302 Y214.577 Z-5.539 F25
G1 X87.209 Y214.599 Z-5.543 F25
G1 X87.114 Y214.613 Z-5.546 F25
G1 X87.019 Y214.62 Z-5.55 F25
G1 X86.923 Z-5.553 F25
G1 X86.828 Y214.612 Z-5.556 F25
G1 X86.733 Y214.596 Z-5.56 F25
G1 X86.64 Y214.574 Z-5.563 F25
G1 X86.549 Y214.544 Z-5.567 F25
G1 X86.461 Y214.507 Z-5.57 F25
G1 X86.376 Y214.464 Z-5.574 F25
G1 X86.294 Y214.414 Z-5.577 F25
G1 X86.217 Y214.357 Z-5.581 F25
G1 X86.144 Y214.295 Z-5.584 F25
G1 X86.076 Y214.228 Z-5.588 F25
G1 X86.014 Y214.155 Z-5.591 F25
G1 X85.957 Y214.078 Z-5.595 F25
G1 X85.907 Y213.997 Z-5.598 F25
G1 X85.863 Y213.912 Z-5.602 F25
G1 X85.826 Y213.824 Z-5.605 F25
G1 X85.796 Y213.733 Z-5.609 F25
G1 X85.773 Y213.64 Z-5.612 F25
G1 X85.757 Y213.546 Z-5.616 F25
G1 X85.749 Y213.451 Z-5.619 F25
G1 X85.748 Y213.355 Z-5.623 F25
G1 X85.754 Y213.26 Z-5.626 F25
G1 X85.768 Y213.165 Z-5.63 F25
G1 X85.79 Y213.072 Z-5.633 F25
G1 X85.818 Y212.981 Z-5.637 F25
G1 X85.853 Y212.892 Z-5.64 F25
G1 X85.896 Y212.806 Z-5.644 F25
G1 X85.944 Y212.724 Z-5.647 F25
G1 X85.999 Y212.646 Z-5.651 F25
G1 X86.06 Y212.572 Z-5.654 F25
G1 X86.127 Y212.504 Z-5.658 F25
G1 X86.198 Y212.44 Z-5.661 F25
G1 X86.275 Y212.383 Z-5.664 F25
G1 X86.355 Y212.331 Z-5.668 F25
G1 X86.439 Y212.286 Z-5.671 F25
G1 X86.527 Y212.248 Z-5.675 F25
G1 X86.617 Y212.216 Z-5.678 F25
G1 X86.709 Y212.192 Z-5.682 F25
G1 X86.803 Y212.175 Z-5.685 F25
G1 X86.898 Y212.165 Z-5.689 F25
G1 X86.994 Y212.163 Z-5.692 F25
G1 X87.089 Y212.168 Z-5.696 F25
G1 X87.184 Y212.18 Z-5.699 F25
G1 X87.277 Y212.2 Z-5.703 F25
G1 X87.369 Y212.227 Z-5.706 F25
G1 X87.458 Y212.261 Z-5.71 F25
G1 X87.544 Y212.302 Z-5.713 F25
G1 X87.627 Y212.35 Z-5.717 F25
G1 X87.706 Y212.404 Z-5.72 F25
G1 X87.78 Y212.463 Z-5.724 F25
G1 X87.85 Y212.529 Z-5.727 F25
G1 X87.914 Y212.599 Z-5.731 F25
G1 X87.973 Y212.674 Z-5.734 F25
G1 X88.025 Y212.754 Z-5.738 F25
G1 X88.072 Y212.838 Z-5.741 F25
G1 X88.111 Y212.925 Z-5.745 F25
G1 X88.144 Y213.014 Z-5.748 F25
G1 X88.17 Y213.106 Z-5.752 F25
G1 X88.188 Y213.2 Z-5.755 F25
G1 X88.199 Y213.295 Z-5.759 F25
G1 X88.203 Y213.39 Z-5.762 F25
G3 X85.748 I-1.227 F25
G3 X88.203 I1.227 F25
; MOVEMENT_CUTTING
G1 X88.229 Y214.087 F254
G1 X88.239 Y214.178 F254
G1 X88.202 Y214.399 F254
G1 X88.1 Y214.6 F254
G1 X87.942 Y214.76 F254
G1 X87.744 Y214.866 F254
G1 X87.523 Y214.908 F254
G1 X87.392 Y214.912 F254
G1 X87.234 Y214.914 F254
G1 X87.075 Y214.912 F254
G1 X86.996 Y214.91 F254
G1 X86.917 Y214.895 F254
G1 X86.124 Y214.697 F254
G1 X86.087 Y214.685 F254
G1 X86.05 Y214.669 F254
G1 X85.966 Y214.628 F254
G1 X85.807 Y214.548 F254
G1 X85.709 Y214.475 F254
G1 X85.679 Y214.451 F254
G1 X85.648 Y214.422 F254
G1 X85.627 Y214.396 F254
G1 X85.61 Y214.369 F254
G1 X85.596 Y214.343 F254
G1 X85.586 Y214.316 F254
G1 X85.552 Y214.158 F254
G1 X85.49 Y213.825 F254
G1 X85.477 Y213.753 F254
G1 X85.474 Y213.682 F254
G1 X85.478 Y213.365 F254
G1 X85.486 Y213.206 F254
G1 X85.49 Y213.188 F254
G1 X85.534 Y213.048 F254
G1 X85.589 Y212.889 F254
G1 X85.759 Y212.413 F254
G1 X85.807 Y212.275 F254
G1 X85.864 Y212.134 F254
G1 X85.943 Y212.003 F254
G1 X86.038 Y211.884 F254
G1 X86.148 Y211.779 F254
G1 X86.269 Y211.686 F254
G1 X86.4 Y211.608 F254
G1 X86.538 Y211.544 F254
G1 X86.556 Y211.537 F254
G1 X86.759 Y211.497 F254
G1 X86.966 Y211.515 F254
G1 X87.159 Y211.589 F254
G1 X87.325 Y211.715 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X87.356 Y211.754 Z-5.742 F254
G1 X87.38 Y211.797 Z-5.721 F254
G1 X87.397 Y211.844 Z-5.701 F254
G1 X87.407 Y211.893 Z-5.681 F254
G1 X87.409 Y211.942 Z-5.66 F254
G1 X87.403 Y211.992 Z-5.64 F254
G1 X87.39 Y212.04 Z-5.62 F254
G1 X87.369 Y212.085 Z-5.599 F254
G1 X87.342 Y212.127 Z-5.579 F254
G1 X87.308 Y212.163 Z-5.559 F254
G3 X87.221 Y212.22 I-0.216 J-0.233 F254
G1 X87.091 Y212.279 F254
; MOVEMENT_LINK_DIRECT
G1 X86.256 Y212.652 F254
; MOVEMENT_LEAD_IN
G1 X86.24 Y212.659 F254
G3 X86.016 Y212.672 I-0.13 J-0.29 F254
G1 X85.97 Y212.654 Z-5.579 F254
G1 X85.927 Y212.628 Z-5.599 F254
G1 X85.889 Y212.597 Z-5.62 F254
G1 X85.856 Y212.559 Z-5.64 F254
G1 X85.829 Y212.517 Z-5.66 F254
G1 X85.81 Y212.471 Z-5.681 F254
G1 X85.797 Y212.423 Z-5.701 F254
G1 X85.793 Y212.374 Z-5.721 F254
G1 X85.796 Y212.324 Z-5.742 F254
G1 X85.807 Y212.275 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X85.869 Y212.096 F254
G1 X85.922 Y211.937 F254
G1 X85.95 Y211.779 F254
G1 X85.971 Y211.647 F254
G1 X86.002 Y211.498 F254
G1 X86.107 Y211.344 F254
G1 X86.255 Y211.231 F254
G1 X86.431 Y211.17 F254
G1 X86.618 Y211.168 F254
G1 X86.795 Y211.224 F254
G1 X86.946 Y211.334 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X86.986 Y211.382 Z-5.737 F254
G1 X87.02 Y211.434 Z-5.711 F254
G1 X87.049 Y211.49 Z-5.686 F254
G1 X87.07 Y211.548 Z-5.66 F254
G1 X87.086 Y211.608 Z-5.635 F254
G1 X87.094 Y211.67 Z-5.61 F254
G1 X87.096 Y211.732 Z-5.584 F254
G1 X87.091 Y211.794 Z-5.559 F254
G3 X87.088 Y211.812 I-0.557 J-0.078 F254
G3 X86.122 Y212.105 I-0.557 J-0.096 F254
; MOVEMENT_LEAD_IN
G1 X86.082 Y212.058 Z-5.584 F254
G1 X86.047 Y212.007 Z-5.61 F254
G1 X86.018 Y211.951 Z-5.635 F254
G1 X85.995 Y211.894 Z-5.66 F254
G1 X85.979 Y211.833 Z-5.686 F254
G1 X85.969 Y211.772 Z-5.711 F254
G1 X85.967 Y211.71 Z-5.737 F254
G1 X85.971 Y211.647 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X86 Y211.462 F254
G1 X86.023 Y211.303 F254
G1 X86.027 Y211.255 F254
G1 X86.03 Y211.221 F254
G1 X86.033 Y211.179 F254
G1 X86.041 Y211.122 F254
G1 X86.048 Y211.093 F254
G1 X86.056 Y211.065 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X86.081 Y211.026 Z-5.743 F254
G1 X86.112 Y210.991 Z-5.724 F254
G1 X86.148 Y210.961 Z-5.705 F254
G1 X86.188 Y210.938 Z-5.686 F254
G1 X86.232 Y210.921 Z-5.667 F254
G1 X86.278 Y210.912 Z-5.648 F254
G1 X86.324 Y210.91 Z-5.629 F254
G1 X86.371 Y210.915 Z-5.61 F254
G1 X86.411 Y210.926 Z-5.593 F254
G1 X86.448 Y210.943 Z-5.576 F254
G1 X86.484 Y210.965 Z-5.559 F254
G3 X86.357 Y211.471 I-0.169 J0.226 F254
; MOVEMENT_LEAD_IN
G1 X86.313 Y211.474 Z-5.577 F254
G1 X86.268 Y211.47 Z-5.595 F254
G1 X86.224 Y211.459 Z-5.614 F254
G1 X86.182 Y211.441 Z-5.632 F254
G1 X86.144 Y211.416 Z-5.651 F254
G1 X86.11 Y211.386 Z-5.669 F254
G1 X86.082 Y211.351 Z-5.688 F254
G1 X86.059 Y211.311 Z-5.706 F254
G1 X86.043 Y211.269 Z-5.725 F254
G1 X86.035 Y211.224 Z-5.743 F254
G1 X86.033 Y211.179 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X86.036 Y211.144 F254
G1 X86.043 Y211.105 F254
G1 X86.056 Y211.065 F254
G1 X86.075 Y211.025 F254
G1 X86.102 Y210.986 F254
G1 X86.124 Y210.96 F254
G1 X86.164 Y210.926 F254
G1 X86.203 Y210.898 F254
G1 X86.243 Y210.879 F254
G1 X86.283 Y210.865 F254
G1 X86.322 Y210.857 F254
G1 X86.362 Y210.855 F254
G1 X86.402 Y210.857 F254
G1 X86.441 Y210.864 F254
G1 X86.481 Y210.877 F254
G1 X86.52 Y210.896 F254
G1 X86.56 Y210.923 F254
G1 X86.6 Y210.96 F254
G1 X86.621 Y210.986 F254
G1 X86.759 Y211.144 F254
G1 X86.917 Y211.304 F254
G1 X87.392 Y211.783 F254
G1 X87.551 Y211.938 F254
G1 X87.914 Y212.255 F254
G1 X88.026 Y212.349 F254
G1 X88.431 Y212.666 F254
G1 X88.546 Y212.765 F254
G1 X88.646 Y212.881 F254
G1 X88.75 Y213.025 F254
G1 X88.83 Y213.158 F254
G1 X88.898 Y213.295 F254
G1 X88.96 Y213.448 F254
G1 X89.006 Y213.594 F254
G1 X89.039 Y213.742 F254
G1 X89.058 Y213.895 F254
G1 X89.066 Y214.048 F254
G1 X89.063 Y214.112 F254
G1 X89.018 Y214.339 F254
G1 X88.904 Y214.541 F254
G1 X88.734 Y214.698 F254
G1 X88.524 Y214.795 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X88.474 Y214.803 Z-5.742 F254
G1 X88.425 Z-5.721 F254
G1 X88.375 Y214.795 Z-5.701 F254
G1 X88.328 Y214.78 Z-5.681 F254
G1 X88.284 Y214.758 Z-5.66 F254
G1 X88.243 Y214.729 Z-5.64 F254
G1 X88.208 Y214.694 Z-5.62 F254
G1 X88.178 Y214.653 Z-5.599 F254
G1 X88.156 Y214.609 Z-5.579 F254
G1 X88.14 Y214.562 Z-5.559 F254
G3 X88.133 Y214.528 I0.308 J-0.075 F254
G1 X88.106 Y214.317 F254
; MOVEMENT_LINK_DIRECT
G1 X87.93 Y212.969 F254
; MOVEMENT_LEAD_IN
G1 X87.929 Y212.963 F254
G3 X87.987 Y212.735 I0.315 J-0.041 F254
G1 X88.02 Y212.697 Z-5.579 F254
G1 X88.058 Y212.665 Z-5.599 F254
G1 X88.1 Y212.639 Z-5.62 F254
G1 X88.146 Y212.62 Z-5.64 F254
G1 X88.195 Y212.609 Z-5.66 F254
G1 X88.244 Y212.605 Z-5.681 F254
G1 X88.294 Y212.609 Z-5.701 F254
G1 X88.342 Y212.62 Z-5.721 F254
G1 X88.388 Y212.64 Z-5.742 F254
G1 X88.431 Y212.666 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X88.514 Y212.73 F254
G1 X88.661 Y212.843 F254
G1 X88.978 Y213.051 F254
G1 X89.136 Y213.148 F254
G1 X89.166 Y213.166 F254
G1 X89.294 Y213.249 F254
G1 X89.406 Y213.353 F254
G1 X89.502 Y213.471 F254
G1 X89.58 Y213.602 F254
G1 X89.585 Y213.612 F254
G1 X89.643 Y213.813 F254
G1 X89.642 Y214.023 F254
G1 X89.582 Y214.224 F254
G1 X89.468 Y214.4 F254
G1 X89.31 Y214.538 F254
G1 X89.119 Y214.625 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X89.07 Y214.634 Z-5.742 F254
G1 X89.021 Y214.635 Z-5.721 F254
G1 X88.971 Y214.628 Z-5.701 F254
G1 X88.924 Y214.613 Z-5.681 F254
G1 X88.879 Y214.591 Z-5.66 F254
G1 X88.838 Y214.563 Z-5.64 F254
G1 X88.802 Y214.528 Z-5.62 F254
G1 X88.772 Y214.489 Z-5.599 F254
G1 X88.749 Y214.445 Z-5.579 F254
G1 X88.733 Y214.398 Z-5.559 F254
G3 X88.722 Y214.327 I0.307 J-0.08 F254
G1 X88.718 Y214.151 F254
; MOVEMENT_LINK_DIRECT
G1 X88.7 Y213.535 F254
; MOVEMENT_LEAD_IN
G1 X88.698 Y213.454 F254
G3 X88.736 Y213.295 I0.317 J-0.009 F254
G1 X88.763 Y213.253 Z-5.579 F254
G1 X88.796 Y213.216 Z-5.599 F254
G1 X88.835 Y213.184 Z-5.62 F254
G1 X88.878 Y213.159 Z-5.64 F254
G1 X88.924 Y213.141 Z-5.66 F254
G1 X88.973 Y213.131 Z-5.681 F254
G1 X89.023 Y213.128 Z-5.701 F254
G1 X89.072 Y213.133 Z-5.721 F254
G1 X89.121 Y213.146 Z-5.742 F254
G1 X89.166 Y213.166 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X89.506 Y213.365 F254
G1 X89.612 Y213.425 F254
G1 X89.738 Y213.495 F254
G1 X89.868 Y213.575 F254
G1 X89.964 Y213.727 F254
G1 X90 Y213.904 F254
G1 X89.972 Y214.081 F254
G1 X89.884 Y214.238 F254
G1 X89.745 Y214.353 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X89.693 Y214.376 Z-5.739 F254
G1 X89.638 Y214.394 Z-5.715 F254
G1 X89.581 Y214.404 Z-5.692 F254
G1 X89.524 Y214.408 Z-5.668 F254
G1 X89.47 Y214.406 Z-5.646 F254
G1 X89.417 Y214.397 Z-5.624 F254
G1 X89.366 Y214.383 Z-5.602 F254
G1 X89.316 Y214.363 Z-5.581 F254
G1 X89.269 Y214.338 Z-5.559 F254
G3 X89.262 Y213.517 I0.251 J-0.412 F254
; MOVEMENT_LEAD_IN
G1 X89.311 Y213.491 Z-5.581 F254
G1 X89.362 Y213.469 Z-5.604 F254
G1 X89.415 Y213.454 Z-5.627 F254
G1 X89.47 Y213.445 Z-5.649 F254
G1 X89.525 Y213.443 Z-5.672 F254
G1 X89.58 Y213.447 Z-5.694 F254
G1 X89.635 Y213.457 Z-5.717 F254
G1 X89.688 Y213.473 Z-5.739 F254
G1 X89.738 Y213.495 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X89.994 Y213.637 F254
G1 X90.027 Y213.658 F254
G1 X90.06 Y213.682 F254
G1 X90.087 Y213.708 F254
G1 X90.115 Y213.741 F254
G1 X90.135 Y213.774 F254
G1 X90.151 Y213.807 F254
G1 X90.162 Y213.841 F254
G1 X90.17 Y213.88 F254
G1 X90.174 Y213.92 F254
G1 X90.172 Y213.96 F254
G1 X90.165 Y213.999 F254
G1 X90.154 Y214.035 F254
G1 X90.138 Y214.071 F254
G1 X90.117 Y214.107 F254
G1 X90.087 Y214.143 F254
G1 X90.073 Y214.158 F254
G1 X90.037 Y214.187 F254
G1 X90.001 Y214.209 F254
G1 X89.453 Y214.518 F254
G1 X89.414 Y214.537 F254
G1 X89.374 Y214.55 F254
G1 X88.978 Y214.667 F254
G1 X88.502 Y214.801 F254
G1 X88.344 Y214.833 F254
G1 X87.868 Y214.895 F254
G1 X87.709 Y214.901 F254
G1 X87.523 Y214.908 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X87.207 Y214.621 J-0.317 F254
G1 X87.206 Y214.59 Z-5.761 F254
G1 X87.216 Y214.55 Z-5.753 F254
G1 X87.226 Y214.51 Z-5.741 F254
G1 X87.236 Y214.473 Z-5.723 F254
G1 X87.244 Y214.439 Z-5.7 F254
G1 X87.268 Y214.41 Z-5.667 F254
G1 X87.289 Y214.386 Z-5.63 F254
G1 X87.305 Y214.367 Z-5.588 F254
G1 X87.317 Y214.352 Z-5.542 F254
G1 X87.325 Y214.344 Z-5.494 F254
G1 X87.327 Y214.341 Z-5.445 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X91.7 Y230.22 F254
G1 Z-2.54 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_RAMP_HELIX
G1 X91.769 Y230.134 Z-2.544 F25
G1 X91.844 Y230.054 Z-2.548 F25
G1 X91.925 Y229.978 Z-2.552 F25
G1 X92.01 Y229.909 Z-2.555 F25
G1 X92.101 Y229.846 Z-2.559 F25
G1 X92.195 Y229.79 Z-2.563 F25
G1 X92.294 Y229.74 Z-2.567 F25
G1 X92.395 Y229.697 Z-2.571 F25
G1 X92.5 Y229.662 Z-2.575 F25
G1 X92.606 Y229.634 Z-2.578 F25
G1 X92.715 Y229.613 Z-2.582 F25
G1 X92.824 Y229.601 Z-2.586 F25
G1 X92.934 Y229.596 Z-2.59 F25
G1 X93.044 Y229.599 Z-2.594 F25
G1 X93.154 Y229.609 Z-2.598 F25
G1 X93.263 Y229.627 Z-2.602 F25
G1 X93.37 Y229.653 Z-2.605 F25
G1 X93.475 Y229.687 Z-2.609 F25
G1 X93.577 Y229.727 Z-2.613 F25
G1 X93.677 Y229.775 Z-2.617 F25
G1 X93.772 Y229.83 Z-2.621 F25
G1 X93.864 Y229.891 Z-2.625 F25
G1 X93.951 Y229.959 Z-2.629 F25
G1 X94.033 Y230.033 Z-2.632 F25
G1 X94.11 Y230.112 Z-2.636 F25
G1 X94.18 Y230.196 Z-2.64 F25
G1 X94.245 Y230.285 Z-2.644 F25
G1 X94.303 Y230.379 Z-2.648 F25
G1 X94.355 Y230.476 Z-2.652 F25
G1 X94.399 Y230.577 Z-2.655 F25
G1 X94.437 Y230.68 Z-2.659 F25
G1 X94.467 Y230.786 Z-2.663 F25
G1 X94.489 Y230.894 Z-2.667 F25
G1 X94.504 Y231.003 Z-2.671 F25
G1 X94.511 Y231.113 Z-2.675 F25
G1 X94.51 Y231.223 Z-2.679 F25
G1 X94.502 Y231.333 Z-2.682 F25
G1 X94.485 Y231.442 Z-2.686 F25
G1 X94.461 Y231.549 Z-2.69 F25
G1 X94.43 Y231.655 Z-2.694 F25
G1 X94.391 Y231.758 Z-2.698 F25
G1 X94.345 Y231.858 Z-2.702 F25
G1 X94.293 Y231.954 Z-2.706 F25
G1 X94.233 Y232.047 Z-2.709 F25
G1 X94.167 Y232.135 Z-2.713 F25
G1 X94.095 Y232.218 Z-2.717 F25
G1 X94.018 Y232.296 Z-2.721 F25
G1 X93.935 Y232.369 Z-2.725 F25
G1 X93.847 Y232.435 Z-2.729 F25
G1 X93.755 Y232.495 Z-2.732 F25
G1 X93.658 Y232.548 Z-2.736 F25
G1 X93.558 Y232.595 Z-2.74 F25
G1 X93.456 Y232.634 Z-2.744 F25
G1 X93.35 Y232.666 Z-2.748 F25
G1 X93.243 Y232.69 Z-2.752 F25
G1 X93.134 Y232.707 Z-2.756 F25
G1 X93.025 Y232.716 Z-2.759 F25
G1 X92.915 Y232.718 Z-2.763 F25
G1 X92.805 Y232.711 Z-2.767 F25
G1 X92.696 Y232.697 Z-2.771 F25
G1 X92.588 Y232.675 Z-2.775 F25
G1 X92.482 Y232.646 Z-2.779 F25
G1 X92.379 Y232.609 Z-2.783 F25
G1 X92.278 Y232.565 Z-2.786 F25
G1 X92.18 Y232.514 Z-2.79 F25
G1 X92.087 Y232.456 Z-2.794 F25
G1 X91.997 Y232.392 Z-2.798 F25
G1 X91.913 Y232.322 Z-2.802 F25
G1 X91.834 Y232.246 Z-2.806 F25
G1 X91.76 Y232.164 Z-2.809 F25
G1 X91.692 Y232.078 Z-2.813 F25
G1 X91.63 Y231.987 Z-2.817 F25
G1 X91.575 Y231.892 Z-2.821 F25
G1 X91.527 Y231.793 Z-2.825 F25
G1 X91.486 Y231.691 Z-2.829 F25
G1 X91.452 Y231.586 Z-2.833 F25
G1 X91.425 Y231.48 Z-2.836 F25
G1 X91.407 Y231.371 Z-2.84 F25
G1 X91.396 Y231.262 Z-2.844 F25
G1 X91.392 Y231.152 Z-2.848 F25
G1 X91.397 Y231.042 Z-2.852 F25
G1 X91.409 Y230.933 Z-2.856 F25
G1 X91.428 Y230.825 Z-2.86 F25
G1 X91.456 Y230.719 Z-2.863 F25
G1 X91.49 Y230.614 Z-2.867 F25
G1 X91.532 Y230.513 Z-2.871 F25
G1 X91.582 Y230.415 Z-2.875 F25
G1 X91.637 Y230.32 Z-2.879 F25
G1 X91.7 Y230.23 Z-2.883 F25
G1 X91.768 Y230.144 Z-2.886 F25
G1 X91.843 Y230.063 Z-2.89 F25
G1 X91.923 Y229.988 Z-2.894 F25
G1 X92.008 Y229.918 Z-2.898 F25
G1 X92.098 Y229.855 Z-2.902 F25
G1 X92.192 Y229.798 Z-2.906 F25
G1 X92.29 Y229.748 Z-2.91 F25
G1 X92.391 Y229.705 Z-2.913 F25
G1 X92.494 Y229.67 Z-2.917 F25
G1 X92.601 Y229.641 Z-2.921 F25
G1 X92.708 Y229.62 Z-2.925 F25
G1 X92.817 Y229.607 Z-2.929 F25
G1 X92.927 Y229.602 Z-2.933 F25
G1 X93.037 Y229.604 Z-2.936 F25
G1 X93.146 Y229.614 Z-2.94 F25
G1 X93.255 Y229.632 Z-2.944 F25
G1 X93.361 Y229.657 Z-2.948 F25
G1 X93.466 Y229.69 Z-2.952 F25
G1 X93.569 Y229.73 Z-2.956 F25
G1 X93.668 Y229.777 Z-2.96 F25
G1 X93.763 Y229.831 Z-2.963 F25
G1 X93.855 Y229.892 Z-2.967 F25
G1 X93.941 Y229.959 Z-2.971 F25
G1 X94.023 Y230.032 Z-2.975 F25
G1 X94.1 Y230.11 Z-2.979 F25
G1 X94.171 Y230.194 Z-2.983 F25
G1 X94.236 Y230.282 Z-2.987 F25
G1 X94.294 Y230.375 Z-2.99 F25
G1 X94.346 Y230.472 Z-2.994 F25
G1 X94.391 Y230.572 Z-2.998 F25
G1 X94.429 Y230.675 Z-3.002 F25
G1 X94.459 Y230.78 Z-3.006 F25
G1 X94.482 Y230.888 Z-3.01 F25
G1 X94.497 Y230.996 Z-3.013 F25
G1 X94.505 Y231.106 Z-3.017 F25
G1 X94.504 Y231.215 Z-3.021 F25
G1 X94.496 Y231.325 Z-3.025 F25
G1 X94.481 Y231.433 Z-3.029 F25
G1 X94.457 Y231.541 Z-3.033 F25
G1 X94.427 Y231.646 Z-3.037 F25
G1 X94.389 Y231.749 Z-3.04 F25
G1 X94.343 Y231.849 Z-3.044 F25
G1 X94.291 Y231.945 Z-3.048 F25
G1 X94.232 Y232.038 Z-3.052 F25
G1 X94.167 Y232.126 Z-3.056 F25
G1 X94.096 Y232.209 Z-3.06 F25
G1 X94.019 Y232.287 Z-3.064 F25
G1 X93.936 Y232.36 Z-3.067 F25
G1 X93.849 Y232.426 Z-3.071 F25
G1 X93.758 Y232.486 Z-3.075 F25
G1 X93.662 Y232.54 Z-3.079 F25
G1 X93.563 Y232.587 Z-3.083 F25
G1 X93.461 Y232.626 Z-3.087 F25
G1 X93.356 Y232.658 Z-3.09 F25
G1 X93.249 Y232.683 Z-3.094 F25
G1 X93.141 Y232.7 Z-3.098 F25
G1 X93.032 Y232.71 Z-3.102 F25
G1 X92.922 Y232.712 Z-3.106 F25
G1 X92.813 Y232.706 Z-3.11 F25
G1 X92.704 Y232.692 Z-3.114 F25
G1 X92.597 Y232.671 Z-3.117 F25
G1 X92.491 Y232.642 Z-3.121 F25
G1 X92.388 Y232.606 Z-3.125 F25
G1 X92.287 Y232.563 Z-3.129 F25
G1 X92.19 Y232.512 Z-3.133 F25
G1 X92.096 Y232.455 Z-3.137 F25
G1 X92.007 Y232.392 Z-3.141 F25
G1 X91.922 Y232.322 Z-3.144 F25
G1 X91.843 Y232.247 Z-3.148 F25
G1 X91.769 Y232.166 Z-3.152 F25
G1 X91.701 Y232.08 Z-3.156 F25
G1 X91.639 Y231.99 Z-3.16 F25
G1 X91.584 Y231.895 Z-3.164 F25
G1 X91.535 Y231.797 Z-3.167 F25
G1 X91.494 Y231.696 Z-3.171 F25
G1 X91.459 Y231.592 Z-3.175 F25
G1 X91.433 Y231.485 Z-3.179 F25
G1 X91.414 Y231.378 Z-3.183 F25
G1 X91.402 Y231.269 Z-3.187 F25
G1 X91.398 Y231.16 Z-3.191 F25
G1 X91.402 Y231.05 Z-3.194 F25
G1 X91.413 Y230.941 Z-3.198 F25
G1 X91.433 Y230.834 Z-3.202 F25
G1 X91.459 Y230.727 Z-3.206 F25
G1 X91.493 Y230.623 Z-3.21 F25
G1 X91.535 Y230.522 Z-3.214 F25
G1 X91.583 Y230.424 Z-3.218 F25
G1 X91.639 Y230.33 Z-3.221 F25
G1 X91.7 Y230.239 Z-3.225 F25
G1 X91.768 Y230.153 Z-3.229 F25
G1 X91.842 Y230.073 Z-3.233 F25
G1 X91.921 Y229.997 Z-3.237 F25
G1 X92.006 Y229.928 Z-3.241 F25
G1 X92.095 Y229.864 Z-3.244 F25
G1 X92.188 Y229.807 Z-3.248 F25
G1 X92.286 Y229.757 Z-3.252 F25
G1 X92.386 Y229.714 Z-3.256 F25
G1 X92.49 Y229.677 Z-3.26 F25
G1 X92.595 Y229.649 Z-3.264 F25
G1 X92.702 Y229.627 Z-3.268 F25
G1 X92.811 Y229.614 Z-3.271 F25
G1 X92.92 Y229.608 Z-3.275 F25
G1 X93.029 Y229.61 Z-3.279 F25
G1 X93.138 Y229.619 Z-3.283 F25
G1 X93.246 Y229.636 Z-3.287 F25
G1 X93.353 Y229.661 Z-3.291 F25
G1 X93.457 Y229.693 Z-3.294 F25
G1 X93.559 Y229.733 Z-3.298 F25
G1 X93.658 Y229.779 Z-3.302 F25
G1 X93.754 Y229.832 Z-3.306 F25
G1 X93.845 Y229.892 Z-3.31 F25
G1 X93.932 Y229.959 Z-3.314 F25
G1 X94.014 Y230.031 Z-3.318 F25
G1 X94.091 Y230.109 Z-3.321 F25
G1 X94.162 Y230.192 Z-3.325 F25
G1 X94.227 Y230.28 Z-3.329 F25
G1 X94.286 Y230.372 Z-3.333 F25
G1 X94.338 Y230.468 Z-3.337 F25
G1 X94.383 Y230.568 Z-3.341 F25
G1 X94.421 Y230.67 Z-3.345 F25
G1 X94.451 Y230.775 Z-3.348 F25
G1 X94.475 Y230.882 Z-3.352 F25
G1 X94.49 Y230.99 Z-3.356 F25
G1 X94.498 Y231.099 Z-3.36 F25
G1 X94.499 Y231.208 Z-3.364 F25
G1 X94.491 Y231.317 Z-3.368 F25
G1 X94.476 Y231.426 Z-3.371 F25
G1 X94.453 Y231.532 Z-3.375 F25
G1 X94.423 Y231.637 Z-3.379 F25
G1 X94.386 Y231.74 Z-3.383 F25
G1 X94.341 Y231.84 Z-3.387 F25
G1 X94.29 Y231.936 Z-3.391 F25
G1 X94.231 Y232.028 Z-3.395 F25
G1 X94.167 Y232.116 Z-3.398 F25
G1 X94.096 Y232.2 Z-3.402 F25
G1 X94.02 Y232.278 Z-3.406 F25
G1 X93.938 Y232.35 Z-3.41 F25
G1 X93.852 Y232.417 Z-3.414 F25
G1 X93.761 Y232.477 Z-3.418 F25
G1 X93.666 Y232.531 Z-3.422 F25
G1 X93.567 Y232.578 Z-3.425 F25
G1 X93.466 Y232.618 Z-3.429 F25
G1 X93.362 Y232.651 Z-3.433 F25
G1 X93.255 Y232.676 Z-3.437 F25
G1 X93.148 Y232.693 Z-3.441 F25
G1 X93.039 Y232.703 Z-3.445 F25
G1 X92.93 Y232.706 Z-3.448 F25
G1 X92.821 Y232.7 Z-3.452 F25
G1 X92.712 Y232.687 Z-3.456 F25
G1 X92.605 Y232.667 Z-3.46 F25
G1 X92.499 Y232.639 Z-3.464 F25
G1 X92.396 Y232.603 Z-3.468 F25
G1 X92.296 Y232.56 Z-3.472 F25
G1 X92.199 Y232.511 Z-3.475 F25
G1 X92.105 Y232.454 Z-3.479 F25
G1 X92.016 Y232.391 Z-3.483 F25
G1 X91.931 Y232.322 Z-3.487 F25
G1 X91.852 Y232.248 Z-3.491 F25
G1 X91.778 Y232.168 Z-3.495 F25
G1 X91.71 Y232.083 Z-3.499 F25
G1 X91.648 Y231.993 Z-3.502 F25
G1 X91.592 Y231.899 Z-3.506 F25
G1 X91.544 Y231.801 Z-3.51 F25
G1 X91.502 Y231.701 Z-3.514 F25
G1 X91.467 Y231.597 Z-3.518 F25
G1 X91.44 Y231.492 Z-3.522 F25
G1 X91.421 Y231.384 Z-3.525 F25
G1 X91.409 Y231.276 Z-3.529 F25
G1 X91.404 Y231.167 Z-3.533 F25
G1 X91.407 Y231.058 Z-3.537 F25
G1 X91.418 Y230.949 Z-3.541 F25
G1 X91.437 Y230.842 Z-3.545 F25
G1 X91.463 Y230.736 Z-3.549 F25
G1 X91.497 Y230.632 Z-3.552 F25
G1 X91.538 Y230.531 Z-3.556 F25
G1 X91.585 Y230.433 Z-3.56 F25
G1 X91.64 Y230.339 Z-3.564 F25
G1 X91.701 Y230.248 Z-3.568 F25
G1 X91.768 Y230.163 Z-3.572 F25
G1 X91.842 Y230.082 Z-3.576 F25
G1 X91.92 Y230.006 Z-3.579 F25
G1 X92.004 Y229.937 Z-3.583 F25
G1 X92.092 Y229.873 Z-3.587 F25
G1 X92.185 Y229.816 Z-3.591 F25
G1 X92.282 Y229.765 Z-3.595 F25
G1 X92.382 Y229.722 Z-3.599 F25
G1 X92.484 Y229.685 Z-3.602 F25
G1 X92.589 Y229.656 Z-3.606 F25
G1 X92.696 Y229.634 Z-3.61 F25
G1 X92.804 Y229.62 Z-3.614 F25
G1 X92.913 Y229.614 Z-3.618 F25
G1 X93.022 Y229.615 Z-3.622 F25
G1 X93.13 Y229.624 Z-3.626 F25
G1 X93.238 Y229.641 Z-3.629 F25
G1 X93.344 Y229.665 Z-3.633 F25
G1 X93.448 Y229.696 Z-3.637 F25
G1 X93.55 Y229.735 Z-3.641 F25
G1 X93.649 Y229.781 Z-3.645 F25
G1 X93.744 Y229.834 Z-3.649 F25
G1 X93.836 Y229.893 Z-3.652 F25
G1 X93.922 Y229.959 Z-3.656 F25
G1 X94.005 Y230.03 Z-3.66 F25
G1 X94.081 Y230.108 Z-3.664 F25
G1 X94.153 Y230.19 Z-3.668 F25
G1 X94.218 Y230.277 Z-3.672 F25
G1 X94.277 Y230.369 Z-3.676 F25
G1 X94.329 Y230.464 Z-3.679 F25
G1 X94.375 Y230.563 Z-3.683 F25
G1 X94.413 Y230.665 Z-3.687 F25
G1 X94.444 Y230.77 Z-3.691 F25
G1 X94.468 Y230.876 Z-3.695 F25
G1 X94.484 Y230.983 Z-3.699 F25
G1 X94.492 Y231.092 Z-3.703 F25
G1 X94.493 Y231.201 Z-3.706 F25
G1 X94.486 Y231.309 Z-3.71 F25
G1 X94.471 Y231.417 Z-3.714 F25
G1 X94.449 Y231.524 Z-3.718 F25
G1 X94.42 Y231.628 Z-3.722 F25
G1 X94.383 Y231.731 Z-3.726 F25
G1 X94.339 Y231.83 Z-3.729 F25
G1 X94.288 Y231.926 Z-3.733 F25
G1 X94.231 Y232.019 Z-3.737 F25
G1 X94.167 Y232.107 Z-3.741 F25
G1 X94.097 Y232.19 Z-3.745 F25
G1 X94.021 Y232.268 Z-3.749 F25
G1 X93.94 Y232.341 Z-3.753 F25
G1 X93.854 Y232.408 Z-3.756 F25
G1 X93.764 Y232.468 Z-3.76 F25
G1 X93.669 Y232.522 Z-3.764 F25
G1 X93.571 Y232.57 Z-3.768 F25
G1 X93.47 Y232.61 Z-3.772 F25
G1 X93.367 Y232.643 Z-3.776 F25
G1 X93.261 Y232.669 Z-3.78 F25
G1 X93.154 Y232.687 Z-3.783 F25
G1 X93.045 Y232.697 Z-3.787 F25
G1 X92.937 Y232.7 Z-3.791 F25
G1 X92.828 Y232.695 Z-3.795 F25
G1 X92.72 Y232.683 Z-3.799 F25
G1 X92.613 Y232.663 Z-3.803 F25
G1 X92.508 Y232.635 Z-3.806 F25
G1 X92.405 Y232.6 Z-3.81 F25
G1 X92.305 Y232.558 Z-3.814 F25
G1 X92.208 Y232.509 Z-3.818 F25
G1 X92.115 Y232.453 Z-3.822 F25
G1 X92.026 Y232.391 Z-3.826 F25
G1 X91.941 Y232.323 Z-3.83 F25
G1 X91.862 Y232.249 Z-3.833 F25
G1 X91.787 Y232.169 Z-3.837 F25
G1 X91.719 Y232.085 Z-3.841 F25
G1 X91.657 Y231.996 Z-3.845 F25
G1 X91.601 Y231.902 Z-3.849 F25
G1 X91.552 Y231.805 Z-3.853 F25
G1 X91.51 Y231.705 Z-3.857 F25
G1 X91.475 Y231.602 Z-3.86 F25
G1 X91.448 Y231.497 Z-3.864 F25
G1 X91.428 Y231.39 Z-3.868 F25
G1 X91.415 Y231.282 Z-3.872 F25
G1 X91.41 Y231.174 Z-3.876 F25
G1 X91.413 Y231.065 Z-3.88 F25
G1 X91.423 Y230.957 Z-3.883 F25
G1 X91.441 Y230.85 Z-3.887 F25
G1 X91.467 Y230.744 Z-3.891 F25
G1 X91.5 Y230.641 Z-3.895 F25
G1 X91.54 Y230.54 Z-3.899 F25
G1 X91.587 Y230.442 Z-3.903 F25
G1 X91.641 Y230.348 Z-3.907 F25
G1 X91.701 Y230.258 Z-3.91 F25
G1 X91.768 Y230.172 Z-3.914 F25
G1 X91.841 Y230.091 Z-3.918 F25
G1 X91.919 Y230.016 Z-3.922 F25
G1 X92.002 Y229.946 Z-3.926 F25
G1 X92.09 Y229.882 Z-3.93 F25
G1 X92.182 Y229.825 Z-3.934 F25
G1 X92.278 Y229.774 Z-3.937 F25
G1 X92.377 Y229.73 Z-3.941 F25
G1 X92.479 Y229.693 Z-3.945 F25
G1 X92.583 Y229.664 Z-3.949 F25
G1 X92.69 Y229.642 Z-3.953 F25
G1 X92.797 Y229.627 Z-3.957 F25
G1 X92.906 Y229.62 Z-3.96 F25
G1 X93.014 Y229.621 Z-3.964 F25
G1 X93.122 Y229.629 Z-3.968 F25
G1 X93.23 Y229.645 Z-3.972 F25
G1 X93.336 Y229.669 Z-3.976 F25
G1 X93.44 Y229.7 Z-3.98 F25
G1 X93.541 Y229.738 Z-3.984 F25
G1 X93.64 Y229.783 Z-3.987 F25
G1 X93.735 Y229.835 Z-3.991 F25
G1 X93.827 Y229.894 Z-3.995 F25
G1 X93.913 Y229.959 Z-3.999 F25
G1 X93.995 Y230.03 Z-4.003 F25
G1 X94.072 Y230.106 Z-4.007 F25
G1 X94.144 Y230.188 Z-4.01 F25
G1 X94.209 Y230.275 Z-4.014 F25
G1 X94.268 Y230.366 Z-4.018 F25
G1 X94.321 Y230.46 Z-4.022 F25
G1 X94.366 Y230.559 Z-4.026 F25
G1 X94.405 Y230.66 Z-4.03 F25
G1 X94.436 Y230.764 Z-4.034 F25
G1 X94.46 Y230.87 Z-4.037 F25
G1 X94.477 Y230.977 Z-4.041 F25
G1 X94.486 Y231.085 Z-4.045 F25
G1 X94.487 Y231.193 Z-4.049 F25
G1 X94.481 Y231.301 Z-4.053 F25
G1 X94.467 Y231.409 Z-4.057 F25
G1 X94.445 Y231.515 Z-4.061 F25
G1 X94.416 Y231.62 Z-4.064 F25
G1 X94.38 Y231.722 Z-4.068 F25
G1 X94.337 Y231.821 Z-4.072 F25
G1 X94.286 Y231.917 Z-4.076 F25
G1 X94.23 Y232.01 Z-4.08 F25
G1 X94.166 Y232.098 Z-4.084 F25
G1 X94.097 Y232.181 Z-4.087 F25
G1 X94.022 Y232.259 Z-4.091 F25
G1 X93.942 Y232.332 Z-4.095 F25
G1 X93.856 Y232.399 Z-4.099 F25
G1 X93.767 Y232.46 Z-4.103 F25
G1 X93.673 Y232.514 Z-4.107 F25
G1 X93.576 Y232.561 Z-4.111 F25
G1 X93.475 Y232.602 Z-4.114 F25
G1 X93.372 Y232.635 Z-4.118 F25
G1 X93.267 Y232.661 Z-4.122 F25
G1 X93.16 Y232.68 Z-4.126 F25
G1 X93.053 Y232.691 Z-4.13 F25
G1 X92.944 Y232.694 Z-4.134 F25
G1 X92.836 Y232.69 Z-4.138 F25
G1 X92.728 Y232.678 Z-4.141 F25
G1 X92.622 Y232.658 Z-4.145 F25
G1 X92.517 Y232.631 Z-4.149 F25
G1 X92.414 Y232.597 Z-4.153 F25
G1 X92.314 Y232.556 Z-4.157 F25
G1 X92.217 Y232.507 Z-4.161 F25
G1 X92.124 Y232.452 Z-4.164 F25
G1 X92.035 Y232.391 Z-4.168 F25
G1 X91.95 Y232.323 Z-4.172 F25
G1 X91.871 Y232.25 Z-4.176 F25
G1 X91.797 Y232.171 Z-4.18 F25
G1 X91.728 Y232.087 Z-4.184 F25
G1 X91.666 Y231.998 Z-4.188 F25
G1 X91.61 Y231.906 Z-4.191 F25
G1 X91.561 Y231.809 Z-4.195 F25
G1 X91.518 Y231.709 Z-4.199 F25
G1 X91.483 Y231.607 Z-4.203 F25
G1 X91.455 Y231.503 Z-4.207 F25
G1 X91.434 Y231.396 Z-4.211 F25
G1 X91.422 Y231.289 Z-4.215 F25
G1 X91.416 Y231.181 Z-4.218 F25
G1 X91.418 Y231.073 Z-4.222 F25
G1 X91.428 Y230.965 Z-4.226 F25
G1 X91.446 Y230.858 Z-4.23 F25
G1 X91.471 Y230.753 Z-4.234 F25
G1 X91.503 Y230.65 Z-4.238 F25
G1 X91.543 Y230.549 Z-4.241 F25
G1 X91.589 Y230.452 Z-4.245 F25
G1 X91.642 Y230.357 Z-4.249 F25
G1 X91.702 Y230.267 Z-4.253 F25
G1 X91.768 Y230.182 Z-4.257 F25
G1 X91.84 Y230.101 Z-4.261 F25
G1 X91.917 Y230.025 Z-4.265 F25
G1 X92 Y229.955 Z-4.268 F25
G1 X92.087 Y229.891 Z-4.272 F25
G1 X92.179 Y229.834 Z-4.276 F25
G1 X92.274 Y229.782 Z-4.28 F25
G1 X92.373 Y229.738 Z-4.284 F25
G1 X92.474 Y229.701 Z-4.288 F25
G1 X92.578 Y229.671 Z-4.292 F25
G1 X92.684 Y229.649 Z-4.295 F25
G1 X92.791 Y229.634 Z-4.299 F25
G1 X92.899 Y229.626 Z-4.303 F25
G1 X93.007 Y229.627 Z-4.307 F25
G1 X93.115 Y229.635 Z-4.311 F25
G1 X93.222 Y229.65 Z-4.315 F25
G1 X93.327 Y229.673 Z-4.318 F25
G1 X93.431 Y229.703 Z-4.322 F25
G1 X93.532 Y229.741 Z-4.326 F25
G1 X93.631 Y229.785 Z-4.33 F25
G1 X93.726 Y229.837 Z-4.334 F25
G1 X93.817 Y229.895 Z-4.338 F25
G1 X93.904 Y229.959 Z-4.342 F25
G1 X93.986 Y230.029 Z-4.345 F25
G1 X94.063 Y230.105 Z-4.349 F25
G1 X94.134 Y230.186 Z-4.353 F25
G1 X94.2 Y230.272 Z-4.357 F25
G1 X94.259 Y230.362 Z-4.361 F25
G1 X94.312 Y230.457 Z-4.365 F25
G1 X94.358 Y230.554 Z-4.368 F25
G1 X94.397 Y230.655 Z-4.372 F25
G1 X94.429 Y230.758 Z-4.376 F25
G1 X94.453 Y230.864 Z-4.38 F25
G1 X94.47 Y230.97 Z-4.384 F25
G1 X94.479 Y231.078 Z-4.388 F25
G1 X94.481 Y231.186 Z-4.392 F25
G1 X94.475 Y231.294 Z-4.395 F25
G1 X94.462 Y231.401 Z-4.399 F25
G1 X94.441 Y231.507 Z-4.403 F25
G1 X94.413 Y231.611 Z-4.407 F25
G1 X94.377 Y231.713 Z-4.411 F25
G1 X94.334 Y231.812 Z-4.415 F25
G1 X94.285 Y231.908 Z-4.419 F25
G1 X94.229 Y232 Z-4.422 F25
G1 X94.166 Y232.088 Z-4.426 F25
G1 X94.097 Y232.172 Z-4.43 F25
G1 X94.023 Y232.25 Z-4.434 F25
G1 X93.943 Y232.323 Z-4.438 F25
G1 X93.859 Y232.39 Z-4.442 F25
G1 X93.77 Y232.451 Z-4.445 F25
G1 X93.677 Y232.505 Z-4.449 F25
G1 X93.58 Y232.553 Z-4.453 F25
G1 X93.48 Y232.594 Z-4.457 F25
G1 X93.377 Y232.627 Z-4.461 F25
G1 X93.273 Y232.654 Z-4.465 F25
G1 X93.167 Y232.673 Z-4.469 F25
G1 X93.059 Y232.684 Z-4.472 F25
G1 X92.951 Y232.688 Z-4.476 F25
G1 X92.844 Y232.684 Z-4.48 F25
G1 X92.736 Y232.673 Z-4.484 F25
G1 X92.63 Y232.654 Z-4.488 F25
G1 X92.525 Y232.627 Z-4.492 F25
G1 X92.423 Y232.594 Z-4.496 F25
G1 X92.323 Y232.553 Z-4.499 F25
G1 X92.226 Y232.505 Z-4.503 F25
G1 X92.133 Y232.451 Z-4.507 F25
G1 X92.044 Y232.39 Z-4.511 F25
G1 X91.959 Y232.323 Z-4.515 F25
G1 X91.88 Y232.25 Z-4.519 F25
G1 X91.806 Y232.172 Z-4.522 F25
G1 X91.737 Y232.089 Z-4.526 F25
G1 X91.675 Y232.001 Z-4.53 F25
G1 X91.619 Y231.909 Z-4.534 F25
G1 X91.569 Y231.813 Z-4.538 F25
G1 X91.526 Y231.714 Z-4.542 F25
G1 X91.491 Y231.613 Z-4.546 F25
G1 X91.462 Y231.509 Z-4.549 F25
G1 X91.442 Y231.403 Z-4.553 F25
G1 X91.428 Y231.296 Z-4.557 F25
G1 X91.422 Y231.188 Z-4.561 F25
G1 X91.424 Y231.08 Z-4.565 F25
G1 X91.433 Y230.973 Z-4.569 F25
G1 X91.45 Y230.867 Z-4.573 F25
G1 X91.475 Y230.762 Z-4.576 F25
G1 X91.506 Y230.659 Z-4.58 F25
G1 X91.545 Y230.558 Z-4.584 F25
G1 X91.591 Y230.461 Z-4.588 F25
G1 X91.644 Y230.367 Z-4.592 F25
G1 X91.703 Y230.276 Z-4.596 F25
G1 X91.768 Y230.191 Z-4.599 F25
G1 X91.839 Y230.11 Z-4.603 F25
G1 X91.916 Y230.034 Z-4.607 F25
G1 X91.998 Y229.964 Z-4.611 F25
G1 X92.085 Y229.9 Z-4.615 F25
G1 X92.176 Y229.842 Z-4.619 F25
G1 X92.27 Y229.791 Z-4.623 F25
G1 X92.368 Y229.746 Z-4.626 F25
G1 X92.469 Y229.709 Z-4.63 F25
G1 X92.573 Y229.679 Z-4.634 F25
G1 X92.678 Y229.656 Z-4.638 F25
G1 X92.784 Y229.64 Z-4.642 F25
G1 X92.892 Y229.633 Z-4.646 F25
G1 X92.999 Y229.632 Z-4.65 F25
G1 X93.107 Y229.64 Z-4.653 F25
G1 X93.213 Y229.655 Z-4.657 F25
G1 X93.319 Y229.677 Z-4.661 F25
G1 X93.422 Y229.707 Z-4.665 F25
G1 X93.523 Y229.744 Z-4.669 F25
G1 X93.622 Y229.788 Z-4.673 F25
G1 X93.716 Y229.838 Z-4.676 F25
G1 X93.808 Y229.896 Z-4.68 F25
G1 X93.894 Y229.959 Z-4.684 F25
G1 X93.977 Y230.029 Z-4.688 F25
G1 X94.054 Y230.104 Z-4.692 F25
G1 X94.125 Y230.185 Z-4.696 F25
G1 X94.191 Y230.27 Z-4.7 F25
G1 X94.25 Y230.36 Z-4.703 F25
G1 X94.303 Y230.453 Z-4.707 F25
G1 X94.35 Y230.551 Z-4.711 F25
G1 X94.389 Y230.651 Z-4.715 F25
G1 X94.421 Y230.753 Z-4.719 F25
G1 X94.446 Y230.858 Z-4.723 F25
G1 X94.463 Y230.964 Z-4.726 F25
G1 X94.473 Y231.071 Z-4.73 F25
G1 X94.475 Y231.179 Z-4.734 F25
G1 X94.47 Y231.286 Z-4.738 F25
G1 X94.457 Y231.393 Z-4.742 F25
G1 X94.437 Y231.499 Z-4.746 F25
G1 X94.409 Y231.602 Z-4.75 F25
G1 X94.374 Y231.704 Z-4.753 F25
G1 X94.332 Y231.803 Z-4.757 F25
G1 X94.283 Y231.899 Z-4.761 F25
G1 X94.228 Y231.991 Z-4.765 F25
G1 X94.166 Y232.079 Z-4.769 F25
G1 X94.098 Y232.162 Z-4.773 F25
G1 X94.024 Y232.24 Z-4.777 F25
G1 X93.945 Y232.313 Z-4.78 F25
G1 X93.861 Y232.381 Z-4.784 F25
G1 X93.773 Y232.442 Z-4.788 F25
G1 X93.68 Y232.496 Z-4.792 F25
G1 X93.584 Y232.544 Z-4.796 F25
G1 X93.485 Y232.586 Z-4.8 F25
G1 X93.383 Y232.62 Z-4.803 F25
G1 X93.278 Y232.646 Z-4.807 F25
G1 X93.173 Y232.666 Z-4.811 F25
G1 X93.066 Y232.678 Z-4.815 F25
G1 X92.958 Y232.682 Z-4.819 F25
G1 X92.851 Y232.679 Z-4.823 F25
G1 X92.744 Y232.668 Z-4.827 F25
G1 X92.638 Y232.65 Z-4.83 F25
G1 X92.534 Y232.624 Z-4.834 F25
G1 X92.432 Y232.591 Z-4.838 F25
G1 X92.332 Y232.551 Z-4.842 F25
G1 X92.235 Y232.503 Z-4.846 F25
G1 X92.142 Y232.45 Z-4.85 F25
G1 X92.054 Y232.39 Z-4.854 F25
G1 X91.969 Y232.323 Z-4.857 F25
G1 X91.889 Y232.251 Z-4.861 F25
G1 X91.815 Y232.174 Z-4.865 F25
G1 X91.746 Y232.091 Z-4.869 F25
G1 X91.684 Y232.004 Z-4.873 F25
G1 X91.627 Y231.912 Z-4.877 F25
G1 X91.578 Y231.817 Z-4.88 F25
G1 X91.535 Y231.719 Z-4.884 F25
G1 X91.499 Y231.618 Z-4.888 F25
G1 X91.47 Y231.514 Z-4.892 F25
G1 X91.449 Y231.409 Z-4.896 F25
G1 X91.435 Y231.302 Z-4.9 F25
G1 X91.429 Y231.195 Z-4.904 F25
G1 X91.43 Y231.088 Z-4.907 F25
G1 X91.439 Y230.981 Z-4.911 F25
G1 X91.455 Y230.875 Z-4.915 F25
G1 X91.479 Y230.77 Z-4.919 F25
G1 X91.51 Y230.667 Z-4.923 F25
G1 X91.548 Y230.567 Z-4.927 F25
G1 X91.593 Y230.469 Z-4.931 F25
G1 X91.645 Y230.375 Z-4.934 F25
G1 X91.704 Y230.286 Z-4.938 F25
G1 X91.768 Y230.2 Z-4.942 F25
G1 X91.839 Y230.119 Z-4.946 F25
G1 X91.915 Y230.043 Z-4.95 F25
G1 X91.996 Y229.973 Z-4.954 F25
G1 X92.082 Y229.909 Z-4.957 F25
G1 X92.172 Y229.851 Z-4.961 F25
G1 X92.266 Y229.799 Z-4.965 F25
G1 X92.364 Y229.755 Z-4.969 F25
G1 X92.464 Y229.717 Z-4.973 F25
G1 X92.567 Y229.686 Z-4.977 F25
G1 X92.672 Y229.663 Z-4.981 F25
G1 X92.778 Y229.647 Z-4.984 F25
G1 X92.885 Y229.639 Z-4.988 F25
G1 X92.992 Y229.638 Z-4.992 F25
G1 X93.099 Y229.645 Z-4.996 F25
G1 X93.205 Y229.659 Z-5 F25
G1 X93.31 Y229.681 Z-5.004 F25
G1 X93.414 Y229.71 Z-5.008 F25
G1 X93.515 Y229.747 Z-5.011 F25
G1 X93.613 Y229.79 Z-5.015 F25
G1 X93.707 Y229.84 Z-5.019 F25
G1 X93.799 Y229.897 Z-5.023 F25
G1 X93.885 Y229.96 Z-5.027 F25
G1 X93.968 Y230.029 Z-5.031 F25
G1 X94.045 Y230.103 Z-5.034 F25
G1 X94.116 Y230.183 Z-5.038 F25
G1 X94.182 Y230.268 Z-5.042 F25
G1 X94.242 Y230.357 Z-5.046 F25
G1 X94.295 Y230.45 Z-5.05 F25
G1 X94.341 Y230.546 Z-5.054 F25
G1 X94.381 Y230.646 Z-5.058 F25
G1 X94.413 Y230.748 Z-5.061 F25
G1 X94.439 Y230.852 Z-5.065 F25
G1 X94.456 Y230.958 Z-5.069 F25
G1 X94.467 Y231.064 Z-5.073 F25
G1 X94.469 Y231.171 Z-5.077 F25
G1 X94.465 Y231.278 Z-5.081 F25
G1 X94.452 Y231.385 Z-5.084 F25
G1 X94.433 Y231.49 Z-5.088 F25
G1 X94.405 Y231.594 Z-5.092 F25
G1 X94.371 Y231.695 Z-5.096 F25
G1 X94.33 Y231.794 Z-5.1 F25
G1 X94.281 Y231.89 Z-5.104 F25
G1 X94.226 Y231.982 Z-5.108 F25
G1 X94.165 Y232.07 Z-5.111 F25
G1 X94.098 Y232.153 Z-5.115 F25
G1 X94.025 Y232.231 Z-5.119 F25
G1 X93.946 Y232.304 Z-5.123 F25
G1 X93.863 Y232.372 Z-5.127 F25
G1 X93.775 Y232.433 Z-5.131 F25
G1 X93.683 Y232.488 Z-5.135 F25
G1 X93.587 Y232.536 Z-5.138 F25
G1 X93.489 Y232.578 Z-5.142 F25
G1 X93.387 Y232.612 Z-5.146 F25
G1 X93.284 Y232.639 Z-5.15 F25
G1 X93.179 Y232.659 Z-5.154 F25
G1 X93.072 Y232.671 Z-5.158 F25
G1 X92.966 Y232.676 Z-5.161 F25
G1 X92.859 Y232.673 Z-5.165 F25
G1 X92.752 Y232.663 Z-5.169 F25
G1 X92.647 Y232.645 Z-5.173 F25
G1 X92.543 Y232.62 Z-5.177 F25
G1 X92.441 Y232.588 Z-5.181 F25
G1 X92.341 Y232.548 Z-5.185 F25
G1 X92.245 Y232.502 Z-5.188 F25
G1 X92.152 Y232.448 Z-5.192 F25
G1 X92.063 Y232.389 Z-5.196 F25
G1 X91.978 Y232.323 Z-5.2 F25
G1 X91.899 Y232.252 Z-5.204 F25
G1 X91.824 Y232.175 Z-5.208 F25
G1 X91.756 Y232.093 Z-5.212 F25
G1 X91.693 Y232.006 Z-5.215 F25
G1 X91.636 Y231.915 Z-5.219 F25
G1 X91.586 Y231.821 Z-5.223 F25
G1 X91.543 Y231.723 Z-5.227 F25
G1 X91.506 Y231.622 Z-5.231 F25
G1 X91.477 Y231.519 Z-5.235 F25
G1 X91.456 Y231.415 Z-5.238 F25
G1 X91.441 Y231.308 Z-5.242 F25
G1 X91.435 Y231.202 Z-5.246 F25
G1 Y231.095 Z-5.25 F25
G1 X91.444 Y230.988 Z-5.254 F25
G1 X91.459 Y230.883 Z-5.258 F25
G1 X91.483 Y230.778 Z-5.262 F25
G1 X91.513 Y230.676 Z-5.265 F25
G1 X91.551 Y230.576 Z-5.269 F25
G1 X91.595 Y230.479 Z-5.273 F25
G1 X91.647 Y230.385 Z-5.277 F25
G1 X91.704 Y230.295 Z-5.281 F25
G1 X91.768 Y230.209 Z-5.285 F25
G1 X91.838 Y230.129 Z-5.289 F25
G1 X91.914 Y230.053 Z-5.292 F25
G1 X91.994 Y229.983 Z-5.296 F25
G1 X92.08 Y229.918 Z-5.3 F25
G1 X92.169 Y229.86 Z-5.304 F25
G1 X92.263 Y229.808 Z-5.308 F25
G1 X92.36 Y229.763 Z-5.312 F25
G1 X92.459 Y229.725 Z-5.315 F25
G1 X92.562 Y229.694 Z-5.319 F25
G1 X92.666 Y229.67 Z-5.323 F25
G1 X92.772 Y229.654 Z-5.327 F25
G1 X92.878 Y229.645 Z-5.331 F25
G1 X92.985 Y229.644 Z-5.335 F25
G1 X93.092 Y229.65 Z-5.339 F25
G1 X93.198 Y229.664 Z-5.342 F25
G1 X93.302 Y229.685 Z-5.346 F25
G1 X93.405 Y229.714 Z-5.35 F25
G1 X93.506 Y229.749 Z-5.354 F25
G1 X93.604 Y229.792 Z-5.358 F25
G1 X93.698 Y229.842 Z-5.362 F25
G1 X93.789 Y229.898 Z-5.366 F25
G1 X93.876 Y229.96 Z-5.369 F25
G1 X93.958 Y230.028 Z-5.373 F25
G1 X94.035 Y230.102 Z-5.377 F25
G1 X94.107 Y230.181 Z-5.381 F25
G1 X94.173 Y230.265 Z-5.385 F25
G1 X94.233 Y230.354 Z-5.389 F25
G1 X94.286 Y230.446 Z-5.392 F25
G1 X94.333 Y230.542 Z-5.396 F25
G1 X94.373 Y230.641 Z-5.4 F25
G1 X94.406 Y230.743 Z-5.404 F25
G1 X94.431 Y230.846 Z-5.408 F25
G1 X94.449 Y230.951 Z-5.412 F25
G1 X94.46 Y231.058 Z-5.416 F25
G1 X94.463 Y231.164 Z-5.419 F25
G1 X94.459 Y231.271 Z-5.423 F25
G1 X94.447 Y231.377 Z-5.427 F25
G1 X94.428 Y231.482 Z-5.431 F25
G1 X94.402 Y231.586 Z-5.435 F25
G1 X94.368 Y231.687 Z-5.439 F25
G1 X94.327 Y231.785 Z-5.442 F25
G1 X94.279 Y231.881 Z-5.446 F25
G1 X94.225 Y231.973 Z-5.45 F25
G1 X94.164 Y232.061 Z-5.454 F25
G1 X94.098 Y232.144 Z-5.458 F25
G1 X94.025 Y232.222 Z-5.462 F25
G1 X93.948 Y232.295 Z-5.466 F25
G1 X93.865 Y232.363 Z-5.469 F25
G1 X93.778 Y232.424 Z-5.473 F25
G1 X93.687 Y232.479 Z-5.477 F25
G1 X93.592 Y232.528 Z-5.481 F25
G1 X93.494 Y232.569 Z-5.485 F25
G1 X93.393 Y232.604 Z-5.489 F25
G1 X93.29 Y232.632 Z-5.493 F25
G1 X93.185 Y232.652 Z-5.496 F25
G1 X93.079 Y232.665 Z-5.5 F25
G1 X92.973 Y232.67 Z-5.504 F25
G1 X92.866 Y232.668 Z-5.508 F25
G1 X92.76 Y232.658 Z-5.512 F25
G1 X92.655 Y232.641 Z-5.516 F25
G1 X92.551 Y232.616 Z-5.519 F25
G1 X92.449 Y232.584 Z-5.523 F25
G1 X92.35 Y232.545 Z-5.527 F25
G1 X92.254 Y232.499 Z-5.531 F25
G1 X92.161 Y232.447 Z-5.535 F25
G1 X92.072 Y232.388 Z-5.539 F25
G1 X91.988 Y232.323 Z-5.543 F25
G1 X91.908 Y232.252 Z-5.546 F25
G1 X91.833 Y232.176 Z-5.55 F25
G1 X91.764 Y232.094 Z-5.554 F25
G1 X91.701 Y232.009 Z-5.558 F25
G1 X91.645 Y231.918 Z-5.562 F25
G1 X91.594 Y231.825 Z-5.566 F25
G1 X91.551 Y231.727 Z-5.57 F25
G1 X91.514 Y231.627 Z-5.573 F25
G1 X91.485 Y231.525 Z-5.577 F25
G1 X91.463 Y231.421 Z-5.581 F25
G1 X91.448 Y231.315 Z-5.585 F25
G1 X91.441 Y231.209 Z-5.589 F25
G1 Y231.103 Z-5.593 F25
G1 X91.449 Y230.996 Z-5.596 F25
G1 X91.464 Y230.891 Z-5.6 F25
G1 X91.487 Y230.787 Z-5.604 F25
G1 X91.517 Y230.685 Z-5.608 F25
G1 X91.554 Y230.585 Z-5.612 F25
G1 X91.598 Y230.488 Z-5.616 F25
G1 X91.648 Y230.394 Z-5.62 F25
G1 X91.705 Y230.304 Z-5.623 F25
G1 X91.769 Y230.219 Z-5.627 F25
G1 X91.838 Y230.138 Z-5.631 F25
G1 X91.913 Y230.062 Z-5.635 F25
G1 X91.993 Y229.992 Z-5.639 F25
G1 X92.077 Y229.927 Z-5.643 F25
G1 X92.166 Y229.869 Z-5.647 F25
G1 X92.259 Y229.817 Z-5.65 F25
G1 X92.356 Y229.771 Z-5.654 F25
G1 X92.455 Y229.733 Z-5.658 F25
G1 X92.557 Y229.701 Z-5.662 F25
G1 X92.66 Y229.677 Z-5.666 F25
G1 X92.765 Y229.661 Z-5.67 F25
G1 X92.871 Y229.651 Z-5.673 F25
G1 X92.978 Y229.65 Z-5.677 F25
G1 X93.084 Y229.655 Z-5.681 F25
G1 X93.19 Y229.669 Z-5.685 F25
G1 X93.294 Y229.689 Z-5.689 F25
G1 X93.396 Y229.717 Z-5.693 F25
G1 X93.497 Y229.752 Z-5.697 F25
G1 X93.595 Y229.794 Z-5.7 F25
G1 X93.689 Y229.843 Z-5.704 F25
G1 X93.78 Y229.899 Z-5.708 F25
G1 X93.867 Y229.96 Z-5.712 F25
G1 X93.949 Y230.028 Z-5.716 F25
G1 X94.026 Y230.101 Z-5.72 F25
G1 X94.098 Y230.18 Z-5.724 F25
G1 X94.164 Y230.263 Z-5.727 F25
G1 X94.224 Y230.351 Z-5.731 F25
G1 X94.277 Y230.443 Z-5.735 F25
G1 X94.324 Y230.538 Z-5.739 F25
G1 X94.365 Y230.637 Z-5.743 F25
G1 X94.398 Y230.738 Z-5.747 F25
G1 X94.424 Y230.841 Z-5.75 F25
G1 X94.443 Y230.946 Z-5.754 F25
G1 X94.454 Y231.051 Z-5.758 F25
G1 X94.458 Y231.158 Z-5.762 F25
G3 X91.441 I-1.508 F25
G3 X94.458 I1.508 F25
; MOVEMENT_CUTTING
G1 X94.476 Y231.855 F254
G1 X94.501 Y231.939 F254
G1 X94.525 Y232.089 F254
G1 X94.518 Y232.242 F254
G1 X94.487 Y232.391 F254
G1 X94.436 Y232.534 F254
G1 X94.367 Y232.67 F254
G1 X94.282 Y232.797 F254
G1 X94.185 Y232.915 F254
G1 X94.077 Y233.022 F254
G1 X93.959 Y233.118 F254
G1 X93.832 Y233.203 F254
G1 X93.699 Y233.277 F254
G1 X93.56 Y233.34 F254
G1 X93.414 Y233.392 F254
G1 X93.26 Y233.433 F254
G1 X93.101 Y233.463 F254
G1 X92.936 Y233.48 F254
G1 X92.767 Y233.483 F254
G1 X92.596 Y233.473 F254
G1 X92.424 Y233.449 F254
G1 X92.252 Y233.411 F254
G1 X92.081 Y233.358 F254
G1 X91.914 Y233.291 F254
G1 X91.752 Y233.21 F254
G1 X91.595 Y233.116 F254
G1 X91.445 Y233.009 F254
G1 X91.303 Y232.889 F254
G1 X91.171 Y232.758 F254
G1 X91.049 Y232.615 F254
G1 X90.938 Y232.463 F254
G1 X90.84 Y232.302 F254
G1 X90.754 Y232.132 F254
G1 X90.682 Y231.956 F254
G1 X90.625 Y231.775 F254
G1 X90.582 Y231.588 F254
G1 X90.554 Y231.399 F254
G1 X90.542 Y231.208 F254
G1 X90.544 Y231.016 F254
G1 X90.563 Y230.824 F254
G1 X90.596 Y230.635 F254
G1 X90.645 Y230.448 F254
G1 X90.708 Y230.266 F254
G1 X90.787 Y230.09 F254
G1 X90.879 Y229.92 F254
G1 X90.984 Y229.758 F254
G1 X91.102 Y229.605 F254
G1 X91.232 Y229.462 F254
G1 X91.373 Y229.33 F254
G1 X91.525 Y229.209 F254
G1 X91.685 Y229.101 F254
G1 X91.854 Y229.006 F254
G1 X92.03 Y228.925 F254
G1 X92.212 Y228.859 F254
G1 X92.399 Y228.807 F254
G1 X92.589 Y228.77 F254
G1 X92.782 Y228.749 F254
G1 X92.976 Y228.743 F254
G1 X93.169 Y228.753 F254
G1 X93.361 Y228.778 F254
G1 X93.551 Y228.819 F254
G1 X93.737 Y228.875 F254
G1 X93.917 Y228.945 F254
G1 X94.092 Y229.03 F254
G1 X94.259 Y229.129 F254
G1 X94.417 Y229.24 F254
G1 X94.566 Y229.364 F254
G1 X94.705 Y229.5 F254
G1 X94.833 Y229.646 F254
G1 X94.948 Y229.802 F254
G1 X95.052 Y229.97 F254
G1 X95.163 Y230.184 F254
G1 X95.322 Y230.566 F254
G1 X95.432 Y230.904 F254
G1 X95.498 Y231.181 F254
G1 X95.538 Y231.434 F254
G1 X95.555 Y231.672 F254
G1 X95.554 Y231.897 F254
G1 X95.535 Y232.112 F254
G1 X95.5 Y232.318 F254
G1 X95.449 Y232.52 F254
G1 X95.382 Y232.718 F254
G1 X95.299 Y232.909 F254
G1 X95.201 Y233.094 F254
G1 X95.088 Y233.27 F254
G1 X94.961 Y233.438 F254
G1 X94.819 Y233.597 F254
G1 X94.663 Y233.746 F254
G1 X94.493 Y233.883 F254
G1 X94.31 Y234.009 F254
G1 X94.115 Y234.12 F254
G1 X93.908 Y234.217 F254
G1 X93.691 Y234.299 F254
G1 X93.465 Y234.364 F254
G1 X93.232 Y234.411 F254
G1 X92.992 Y234.439 F254
G1 X92.748 Y234.448 F254
G1 X92.502 Y234.438 F254
G1 X92.254 Y234.407 F254
G1 X92.008 Y234.357 F254
G1 X91.764 Y234.286 F254
G1 X91.526 Y234.195 F254
G1 X91.293 Y234.084 F254
G1 X91.069 Y233.954 F254
G1 X90.854 Y233.806 F254
G1 X90.651 Y233.64 F254
G1 X90.461 Y233.457 F254
G1 X90.286 Y233.259 F254
G1 X90.126 Y233.046 F254
G1 X89.983 Y232.821 F254
G1 X89.858 Y232.584 F254
G1 X89.753 Y232.336 F254
G1 X89.667 Y232.081 F254
G1 X89.602 Y231.818 F254
G1 X89.558 Y231.551 F254
G1 X89.536 Y231.281 F254
G1 Y231.009 F254
G1 X89.557 Y230.737 F254
G1 X89.6 Y230.468 F254
G1 X89.665 Y230.203 F254
G1 X89.751 Y229.943 F254
G1 X89.857 Y229.692 F254
G1 X89.984 Y229.449 F254
G1 X90.129 Y229.217 F254
G1 X90.293 Y228.997 F254
G1 X90.474 Y228.791 F254
G1 X90.671 Y228.6 F254
G1 X90.883 Y228.426 F254
G1 X91.109 Y228.269 F254
G1 X91.346 Y228.13 F254
G1 X91.594 Y228.011 F254
G1 X91.85 Y227.913 F254
G1 X92.114 Y227.835 F254
G1 X92.383 Y227.778 F254
G1 X92.656 Y227.744 F254
G1 X92.93 Y227.731 F254
G1 X93.205 Y227.74 F254
G1 X93.479 Y227.772 F254
G1 X93.749 Y227.825 F254
G1 X94.013 Y227.9 F254
G1 X94.271 Y227.996 F254
G1 X94.521 Y228.112 F254
G1 X94.76 Y228.248 F254
G1 X94.988 Y228.402 F254
G1 X95.203 Y228.575 F254
G1 X95.41 Y228.771 F254
G1 X95.629 Y229.014 F254
G1 X95.834 Y229.282 F254
G1 X96.024 Y229.578 F254
G1 X96.193 Y229.892 F254
G1 X96.334 Y230.215 F254
G1 X96.446 Y230.54 F254
G1 X96.529 Y230.864 F254
G1 X96.584 Y231.183 F254
G1 X96.612 Y231.499 F254
G1 X96.615 Y231.811 F254
G1 X96.594 Y232.119 F254
G1 X96.548 Y232.421 F254
G1 X96.479 Y232.716 F254
G1 X96.386 Y233.003 F254
G1 X96.272 Y233.28 F254
G1 X96.135 Y233.547 F254
G1 X95.978 Y233.803 F254
G1 X95.8 Y234.046 F254
G1 X95.602 Y234.275 F254
G1 X95.385 Y234.488 F254
G1 X95.15 Y234.685 F254
G1 X95.085 Y234.731 F254
G1 X94.909 Y234.823 F254
G1 X94.714 Y234.865 F254
G1 X94.515 Y234.854 F254
G1 X94.114 Y234.776 F254
G1 X93.892 Y234.757 F254
G1 X93.734 Y234.762 F254
G1 X93.596 Y234.776 F254
G1 X93.417 Y234.808 F254
G1 X93.258 Y234.853 F254
G1 X93.1 Y234.903 F254
G1 X92.783 Y235.011 F254
G1 X92.756 Y235.022 F254
G1 X92.614 Y235.076 F254
G1 X92.459 Y235.115 F254
G1 X92.29 Y235.143 F254
G1 X92.099 Y235.159 F254
G1 X91.903 Y235.16 F254
G1 X91.689 Y235.144 F254
G1 X91.458 Y235.108 F254
G1 X91.223 Y235.051 F254
G1 X90.984 Y234.973 F254
G1 X90.735 Y234.869 F254
G1 X90.484 Y234.739 F254
G1 X90.233 Y234.583 F254
G1 X89.99 Y234.402 F254
G1 X89.758 Y234.199 F254
G1 X89.537 Y233.973 F254
G1 X89.331 Y233.724 F254
G1 X89.141 Y233.453 F254
G1 X88.971 Y233.163 F254
G1 X88.822 Y232.857 F254
G1 X88.698 Y232.536 F254
G1 X88.598 Y232.203 F254
G1 X88.595 Y232.189 F254
G1 X88.579 Y232.048 F254
G1 X88.59 Y231.906 F254
G1 X88.628 Y231.77 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X88.651 Y231.726 Z-5.742 F254
G1 X88.68 Y231.686 Z-5.721 F254
G1 X88.716 Y231.651 Z-5.701 F254
G1 X88.756 Y231.622 Z-5.681 F254
G1 X88.801 Y231.599 Z-5.66 F254
G1 X88.848 Y231.584 Z-5.64 F254
G1 X88.897 Y231.577 Z-5.62 F254
G1 X88.947 Z-5.599 F254
G1 X88.996 Y231.585 Z-5.579 F254
G1 X89.044 Y231.601 Z-5.559 F254
G3 X89.114 Y231.642 I-0.123 J0.293 F254
G1 X89.245 Y231.743 F254
; MOVEMENT_LINK_DIRECT
G1 X92.736 Y234.425 F254
; MOVEMENT_LEAD_IN
G1 X92.813 Y234.484 F254
G3 X92.906 Y234.599 I-0.193 J0.252 F254
G1 X92.924 Y234.646 Z-5.579 F254
G1 X92.934 Y234.694 Z-5.599 F254
G1 X92.937 Y234.744 Z-5.62 F254
G1 X92.932 Y234.794 Z-5.64 F254
G1 X92.919 Y234.842 Z-5.66 F254
G1 X92.898 Y234.887 Z-5.681 F254
G1 X92.871 Y234.929 Z-5.701 F254
G1 X92.838 Y234.966 Z-5.721 F254
G1 X92.799 Y234.997 Z-5.742 F254
G1 X92.756 Y235.022 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X92.624 Y235.08 F254
G1 X92.465 Y235.167 F254
G1 X92.307 Y235.282 F254
G1 X92.148 Y235.413 F254
G1 X92.03 Y235.508 F254
G1 X91.9 Y235.589 F254
G1 X91.762 Y235.652 F254
G1 X91.617 Y235.7 F254
G1 X91.468 Y235.734 F254
G1 X91.312 Y235.755 F254
G1 X91.142 Y235.765 F254
G1 X90.95 Y235.76 F254
G1 X90.752 Y235.74 F254
G1 X90.53 Y235.698 F254
G1 X90.3 Y235.636 F254
G1 X90.062 Y235.55 F254
G1 X89.807 Y235.435 F254
G1 X89.546 Y235.29 F254
G1 X89.292 Y235.121 F254
G1 X89.034 Y234.919 F254
G1 X88.779 Y234.683 F254
G1 X88.532 Y234.414 F254
G1 X88.298 Y234.115 F254
G1 X88.27 Y234.072 F254
G1 X88.189 Y233.909 F254
G1 X88.151 Y233.731 F254
G1 X88.157 Y233.549 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X88.17 Y233.501 Z-5.742 F254
G1 X88.19 Y233.456 Z-5.721 F254
G1 X88.218 Y233.414 Z-5.701 F254
G1 X88.251 Y233.377 Z-5.681 F254
G1 X88.29 Y233.346 Z-5.66 F254
G1 X88.334 Y233.322 Z-5.64 F254
G1 X88.38 Y233.304 Z-5.62 F254
G1 X88.429 Y233.294 Z-5.599 F254
G1 X88.479 Y233.292 Z-5.579 F254
G1 X88.528 Y233.297 Z-5.559 F254
G3 X88.6 Y233.32 I-0.06 J0.312 F254
G1 X88.756 Y233.391 F254
; MOVEMENT_LINK_DIRECT
G1 X91.947 Y234.842 F254
; MOVEMENT_LEAD_IN
G1 X92.061 Y234.894 F254
G3 X92.159 Y234.964 I-0.131 J0.289 F254
G1 X92.191 Y235.003 Z-5.579 F254
G1 X92.216 Y235.046 Z-5.599 F254
G1 X92.234 Y235.092 Z-5.62 F254
G1 X92.244 Y235.141 Z-5.64 F254
G1 X92.247 Y235.191 Z-5.66 F254
G1 X92.242 Y235.24 Z-5.681 F254
G1 X92.229 Y235.288 Z-5.701 F254
G1 X92.209 Y235.334 Z-5.721 F254
G1 X92.182 Y235.376 Z-5.742 F254
G1 X92.148 Y235.413 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X91.973 Y235.569 F254
G1 X91.801 Y235.728 F254
G1 X91.673 Y235.849 F254
G1 X91.514 Y236.004 F254
G1 X91.471 Y236.045 F254
G1 X91.353 Y236.141 F254
G1 X91.225 Y236.224 F254
G1 X91.088 Y236.29 F254
G1 X90.945 Y236.342 F254
G1 X90.797 Y236.381 F254
G1 X90.635 Y236.409 F254
G1 X90.466 Y236.424 F254
G1 X90.269 Y236.425 F254
G1 X90.067 Y236.411 F254
G1 X89.844 Y236.377 F254
G1 X89.6 Y236.319 F254
G1 X89.356 Y236.24 F254
G1 X89.089 Y236.129 F254
G1 X88.808 Y235.985 F254
G1 X88.778 Y235.967 F254
G1 X88.694 Y235.906 F254
G1 X88.619 Y235.834 F254
G1 X88.554 Y235.752 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X88.531 Y235.707 Z-5.742 F254
G1 X88.515 Y235.66 Z-5.721 F254
G1 X88.507 Y235.611 Z-5.701 F254
G1 Y235.561 Z-5.681 F254
G1 X88.514 Y235.512 Z-5.66 F254
G1 X88.529 Y235.464 Z-5.64 F254
G1 X88.551 Y235.42 Z-5.62 F254
G1 X88.58 Y235.379 Z-5.599 F254
G1 X88.615 Y235.344 Z-5.579 F254
G1 X88.655 Y235.314 Z-5.559 F254
G3 X88.855 Y235.267 I0.169 J0.269 F254
G1 X88.892 Y235.271 F254
; MOVEMENT_LINK_DIRECT
G1 X91.244 Y235.504 F254
; MOVEMENT_LEAD_IN
G1 X91.276 Y235.507 F254
G3 X91.467 Y235.596 I-0.031 J0.316 F254
G1 X91.499 Y235.634 Z-5.579 F254
G1 X91.526 Y235.676 Z-5.599 F254
G1 X91.545 Y235.722 Z-5.62 F254
G1 X91.557 Y235.77 Z-5.64 F254
G1 X91.562 Y235.82 Z-5.66 F254
G1 X91.558 Y235.869 Z-5.681 F254
G1 X91.547 Y235.918 Z-5.701 F254
G1 X91.529 Y235.964 Z-5.721 F254
G1 X91.503 Y236.007 Z-5.742 F254
G1 X91.471 Y236.045 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X91.197 Y236.289 F254
G1 X90.868 Y236.521 F254
G1 X90.831 Y236.543 F254
G1 X90.795 Y236.562 F254
G1 X90.405 Y236.719 F254
G1 X90.246 Y236.78 F254
G1 X90.167 Y236.794 F254
G1 X90.087 Y236.804 F254
G1 X90.048 Y236.806 F254
G1 X90.008 Y236.804 F254
G1 X89.85 Y236.788 F254
G1 X89.81 Y236.783 F254
G1 X89.77 Y236.772 F254
G1 X89.518 Y236.679 F254
G1 X89.486 Y236.664 F254
G1 X89.453 Y236.645 F254
G1 X89.266 Y236.521 F254
G1 X89.136 Y236.434 F254
G1 X89.061 Y236.362 F254
G1 X88.819 Y236.119 F254
G1 X88.752 Y236.045 F254
G1 X88.502 Y235.674 F254
G1 X88.469 Y235.622 F254
G1 X88.444 Y235.569 F254
G1 X88.271 Y235.173 F254
G1 X88.257 Y235.133 F254
G1 X88.246 Y235.093 F254
G1 X88.185 Y234.831 F254
G1 X88.175 Y234.776 F254
G1 X88.12 Y234.3 F254
G1 X88.116 Y234.142 F254
G1 X88.138 Y233.666 F254
G1 X88.163 Y233.507 F254
G1 X88.216 Y233.19 F254
G1 X88.247 Y233.031 F254
G1 X88.367 Y232.556 F254
G1 X88.515 Y232.08 F254
G1 X88.57 Y231.921 F254
G1 X88.752 Y231.445 F254
G1 X88.978 Y230.909 F254
G1 X89.164 Y230.494 F254
G1 X89.238 Y230.335 F254
G1 X89.48 Y229.859 F254
G1 X90.314 Y228.273 F254
G1 X90.496 Y227.956 F254
G1 X90.579 Y227.828 F254
G1 X90.684 Y227.698 F254
G1 X90.816 Y227.56 F254
G1 X90.964 Y227.427 F254
G1 X91.136 Y227.297 F254
G1 X91.336 Y227.169 F254
G1 X91.552 Y227.054 F254
G1 X91.789 Y226.952 F254
G1 X92.05 Y226.863 F254
G1 X92.333 Y226.792 F254
G1 X92.631 Y226.741 F254
G1 X92.94 Y226.714 F254
G1 X93.257 Y226.712 F254
G1 X93.386 Y226.722 F254
G1 X93.536 Y226.749 F254
G1 X93.677 Y226.805 F254
G1 X93.803 Y226.89 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X93.838 Y226.926 Z-5.742 F254
G1 X93.866 Y226.967 Z-5.721 F254
G1 X93.888 Y227.011 Z-5.701 F254
G1 X93.903 Y227.059 Z-5.681 F254
G1 X93.909 Y227.108 Z-5.66 F254
G1 Y227.158 Z-5.64 F254
G1 X93.9 Y227.207 Z-5.62 F254
G1 X93.884 Y227.254 Z-5.599 F254
G1 X93.86 Y227.298 Z-5.579 F254
G1 X93.83 Y227.338 Z-5.559 F254
G3 X93.697 Y227.427 I-0.238 J-0.211 F254
G1 X93.617 Y227.455 F254
; MOVEMENT_LINK_DIRECT
G1 X90.881 Y228.405 F254
G3 X90.627 Y228.385 I-0.104 J-0.3 F254
; MOVEMENT_LEAD_IN
G1 X90.585 Y228.359 Z-5.579 F254
G1 X90.548 Y228.326 Z-5.599 F254
G1 X90.516 Y228.287 Z-5.62 F254
G1 X90.491 Y228.244 Z-5.64 F254
G1 X90.473 Y228.198 Z-5.66 F254
G1 X90.462 Y228.149 Z-5.681 F254
G1 X90.459 Y228.1 Z-5.701 F254
G1 X90.464 Y228.05 Z-5.721 F254
G1 X90.476 Y228.002 Z-5.742 F254
G1 X90.496 Y227.956 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X90.588 Y227.798 F254
G1 X90.722 Y227.571 F254
G1 X90.88 Y227.307 F254
G1 X90.968 Y227.163 F254
G1 X91.278 Y226.687 F254
G1 X91.37 Y226.566 F254
G1 X91.474 Y226.454 F254
G1 X91.586 Y226.351 F254
G1 X91.724 Y226.245 F254
G1 X91.873 Y226.147 F254
G1 X92.056 Y226.048 F254
G1 X92.072 Y226.041 F254
G1 X92.261 Y225.986 F254
G1 X92.458 Y225.982 F254
G1 X92.649 Y226.031 F254
G1 X92.82 Y226.128 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X92.856 Y226.163 Z-5.742 F254
G1 X92.886 Y226.203 Z-5.721 F254
G1 X92.91 Y226.246 Z-5.701 F254
G1 X92.926 Y226.293 Z-5.681 F254
G1 X92.935 Y226.342 Z-5.66 F254
G1 X92.936 Y226.392 Z-5.64 F254
G1 X92.93 Y226.442 Z-5.62 F254
G1 X92.915 Y226.489 Z-5.599 F254
G1 X92.894 Y226.534 Z-5.579 F254
G1 X92.865 Y226.575 Z-5.559 F254
G3 X92.749 Y226.664 I-0.246 J-0.201 F254
G1 X92.658 Y226.705 F254
; MOVEMENT_LINK_DIRECT
G1 X91.679 Y227.142 F254
G3 X91.385 Y227.123 I-0.13 J-0.29 F254
; MOVEMENT_LEAD_IN
G1 X91.344 Y227.094 Z-5.579 F254
G1 X91.309 Y227.059 Z-5.599 F254
G1 X91.28 Y227.019 Z-5.62 F254
G1 X91.257 Y226.975 Z-5.64 F254
G1 X91.241 Y226.927 Z-5.66 F254
G1 X91.233 Y226.878 Z-5.681 F254
G1 Y226.828 Z-5.701 F254
G1 X91.241 Y226.779 Z-5.721 F254
G1 X91.256 Y226.732 Z-5.742 F254
G1 X91.278 Y226.687 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X91.673 Y226.113 F254
G1 X91.847 Y225.894 F254
G1 X91.919 Y225.809 F254
G1 X91.954 Y225.779 F254
G1 X91.99 Y225.757 F254
G1 X92.039 Y225.736 F254
G1 X92.094 Y225.722 F254
G1 X92.148 Y225.717 F254
G1 X92.177 F254
G1 X92.206 Y225.721 F254
G1 X92.234 Y225.727 F254
G1 X92.263 Y225.736 F254
G1 X92.307 Y225.756 F254
G1 X92.465 Y225.859 F254
G1 X93.417 Y226.583 F254
G1 X93.75 Y226.846 F254
G1 X93.892 Y226.964 F254
G1 X94.843 Y227.815 F254
G1 X94.989 Y227.956 F254
G1 X95.161 Y228.135 F254
G1 X95.319 Y228.306 F254
G1 X95.953 Y228.998 F254
G1 X96.013 Y229.066 F254
G1 X96.143 Y229.225 F254
G1 X96.395 Y229.542 F254
G1 X97.021 Y230.335 F254
G1 X97.144 Y230.511 F254
G1 X97.238 Y230.673 F254
G1 X97.325 Y230.854 F254
G1 X97.403 Y231.056 F254
G1 X97.472 Y231.289 F254
G1 X97.523 Y231.533 F254
G1 X97.557 Y231.8 F254
G1 X97.57 Y232.09 F254
G1 X97.56 Y232.397 F254
G1 X97.524 Y232.711 F254
G1 X97.461 Y233.03 F254
G1 X97.369 Y233.354 F254
G1 X97.248 Y233.681 F254
G1 X97.097 Y234.005 F254
G1 X96.916 Y234.323 F254
G1 X96.708 Y234.63 F254
G1 X96.523 Y234.86 F254
G1 X96.335 Y235.058 F254
G1 X96.319 Y235.073 F254
G1 X96.143 Y235.191 F254
G1 X95.941 Y235.254 F254
G1 X95.729 Y235.258 F254
G1 X95.525 Y235.201 F254
G1 X95.161 Y235.04 F254
G1 X95.002 Y234.979 F254
G1 X94.88 Y234.935 F254
G1 X94.843 Y234.925 F254
G1 X94.685 Y234.889 F254
G1 X94.515 Y234.854 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X94.468 Y234.839 Z-5.742 F254
G1 X94.423 Y234.816 Z-5.721 F254
G1 X94.382 Y234.787 Z-5.701 F254
G1 X94.347 Y234.753 Z-5.681 F254
G1 X94.317 Y234.712 Z-5.66 F254
G1 X94.294 Y234.668 Z-5.64 F254
G1 X94.278 Y234.621 Z-5.62 F254
G1 X94.27 Y234.572 Z-5.599 F254
G1 Y234.522 Z-5.579 F254
G1 X94.277 Y234.473 Z-5.559 F254
G3 X94.308 Y234.392 I0.309 J0.071 F254
G1 X94.385 Y234.251 F254
; MOVEMENT_LINK_DIRECT
G1 X96.438 Y230.502 F254
; MOVEMENT_LEAD_IN
G1 X96.5 Y230.388 F254
G3 X96.574 Y230.298 I0.278 J0.152 F254
G1 X96.614 Y230.269 Z-5.579 F254
G1 X96.659 Y230.246 Z-5.599 F254
G1 X96.706 Y230.231 Z-5.62 F254
G1 X96.756 Y230.224 Z-5.64 F254
G1 X96.805 Z-5.66 F254
G1 X96.855 Y230.232 Z-5.681 F254
G1 X96.902 Y230.248 Z-5.701 F254
G1 X96.946 Y230.27 Z-5.721 F254
G1 X96.986 Y230.3 Z-5.742 F254
G1 X97.021 Y230.335 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X97.758 Y231.287 F254
G1 X97.856 Y231.415 F254
G1 X97.995 Y231.604 F254
G1 X98.079 Y231.731 F254
G1 X98.151 Y231.866 F254
G1 X98.215 Y232.016 F254
G1 X98.268 Y232.175 F254
G1 X98.315 Y232.368 F254
G1 X98.347 Y232.569 F254
G1 X98.366 Y232.804 F254
G1 Y233.054 F254
G1 X98.344 Y233.325 F254
G1 X98.295 Y233.626 F254
G1 X98.219 Y233.936 F254
G1 X98.112 Y234.255 F254
G1 X97.977 Y234.574 F254
G1 X97.824 Y234.865 F254
G1 X97.682 Y235.09 F254
G1 X97.537 Y235.284 F254
G1 X97.405 Y235.433 F254
G1 X97.349 Y235.487 F254
G1 X97.174 Y235.613 F254
G1 X96.97 Y235.682 F254
G1 X96.755 Y235.69 F254
G1 X96.546 Y235.636 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X96.503 Y235.611 Z-5.741 F254
G1 X96.463 Y235.58 Z-5.721 F254
G1 X96.429 Y235.543 Z-5.7 F254
G1 X96.402 Y235.501 Z-5.68 F254
G1 X96.381 Y235.455 Z-5.659 F254
G1 X96.368 Y235.406 Z-5.639 F254
G1 X96.363 Y235.356 Z-5.618 F254
G1 X96.365 Y235.306 Z-5.598 F254
G1 X96.376 Y235.257 Z-5.577 F254
G1 X96.389 Y235.214 Z-5.559 F254
G1 X96.46 Y234.977 F254
; MOVEMENT_LINK_DIRECT
G1 X97.426 Y231.761 F254
; MOVEMENT_LEAD_IN
G1 X97.442 Y231.71 F254
G3 X97.549 Y231.552 I0.304 J0.091 F254
G1 X97.59 Y231.524 Z-5.579 F254
G1 X97.636 Y231.503 Z-5.599 F254
G1 X97.683 Y231.49 Z-5.62 F254
G1 X97.733 Y231.484 Z-5.64 F254
G1 X97.783 Y231.486 Z-5.66 F254
G1 X97.832 Y231.495 Z-5.681 F254
G1 X97.878 Y231.513 Z-5.701 F254
G1 X97.922 Y231.537 Z-5.721 F254
G1 X97.961 Y231.568 Z-5.742 F254
G1 X97.995 Y231.604 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X98.228 Y231.921 F254
G1 X98.559 Y232.397 F254
G1 X98.648 Y232.54 F254
G1 X98.657 Y232.556 F254
G1 X98.732 Y232.714 F254
G1 X98.877 Y233.031 F254
G1 X98.909 Y233.111 F254
G1 X98.935 Y233.19 F254
G1 X98.969 Y233.349 F254
G1 X99.014 Y233.63 F254
G1 X99.03 Y233.825 F254
G1 Y234.045 F254
G1 X99.011 Y234.272 F254
G1 X98.972 Y234.516 F254
G1 X98.909 Y234.769 F254
G1 X98.826 Y235.019 F254
G1 X98.731 Y235.24 F254
G1 X98.625 Y235.443 F254
G1 X98.512 Y235.622 F254
G1 X98.486 Y235.658 F254
G1 X98.344 Y235.8 F254
G1 X98.17 Y235.9 F254
G1 X97.976 Y235.949 F254
G1 X97.775 Y235.944 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X97.727 Y235.931 Z-5.742 F254
G1 X97.682 Y235.91 Z-5.721 F254
G1 X97.64 Y235.883 Z-5.701 F254
G1 X97.604 Y235.849 Z-5.681 F254
G1 X97.573 Y235.81 Z-5.66 F254
G1 X97.548 Y235.766 Z-5.64 F254
G1 X97.531 Y235.72 Z-5.62 F254
G1 X97.521 Y235.671 Z-5.599 F254
G1 X97.519 Y235.621 Z-5.579 F254
G1 X97.525 Y235.572 Z-5.559 F254
G3 X97.539 Y235.522 I0.312 J0.061 F254
G1 X97.607 Y235.339 F254
; MOVEMENT_LINK_DIRECT
G1 X98.364 Y233.314 F254
G3 X98.584 Y233.118 I0.297 J0.111 F254
; MOVEMENT_LEAD_IN
G1 X98.633 Y233.109 Z-5.579 F254
G1 X98.683 Z-5.599 F254
G1 X98.732 Y233.116 Z-5.62 F254
G1 X98.78 Y233.131 Z-5.64 F254
G1 X98.825 Y233.153 Z-5.66 F254
G1 X98.865 Y233.182 Z-5.681 F254
G1 X98.901 Y233.217 Z-5.701 F254
G1 X98.93 Y233.257 Z-5.721 F254
G1 X98.953 Y233.301 Z-5.742 F254
G1 X98.969 Y233.349 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X99.172 Y234.3 F254
G1 X99.185 Y234.38 F254
G1 X99.192 Y234.617 F254
G1 X99.19 Y234.776 F254
G1 X99.165 Y234.935 F254
G1 X99.15 Y235.004 F254
G1 X99.116 Y235.093 F254
G1 X99.08 Y235.173 F254
G1 X99.028 Y235.252 F254
G1 X98.965 Y235.344 F254
G1 X98.903 Y235.41 F254
G1 X98.425 Y235.886 F254
G1 X98.378 Y235.924 F254
G1 X98.331 Y235.953 F254
G1 X98.292 Y235.97 F254
G1 X98.252 Y235.981 F254
G1 X98.212 Y235.987 F254
G1 X98.173 F254
G1 X97.856 Y235.957 F254
G1 X97.697 Y235.932 F254
G1 X97.38 Y235.873 F254
G1 X97.222 Y235.843 F254
G1 X96.904 Y235.778 F254
G1 X96.869 Y235.769 F254
G1 X96.834 Y235.758 F254
G1 X95.953 Y235.385 F254
G1 X95.636 Y235.25 F254
G1 X95.525 Y235.201 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X95.365 Y234.805 I0.138 J-0.286 F254
G1 X95.388 Y234.772 Z-5.759 F254
G1 X95.411 Y234.739 Z-5.751 F254
G1 X95.433 Y234.707 Z-5.738 F254
G1 X95.453 Y234.676 Z-5.72 F254
G1 X95.485 Y234.66 Z-5.695 F254
G1 X95.514 Y234.645 Z-5.666 F254
G1 X95.539 Y234.633 Z-5.633 F254
G1 X95.56 Y234.622 Z-5.597 F254
G1 X95.576 Y234.614 Z-5.557 F254
G1 X95.587 Y234.608 Z-5.516 F254
G1 X95.593 Y234.605 Z-5.473 F254
G1 X95.594 Z-5.444 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X113.361 Y184.263 F254
G1 Z-2.54 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_RAMP_HELIX
G1 X113.43 Y184.178 Z-2.544 F25
G1 X113.505 Y184.097 Z-2.548 F25
G1 X113.586 Y184.022 Z-2.552 F25
G1 X113.672 Y183.953 Z-2.555 F25
G1 X113.762 Y183.889 Z-2.559 F25
G1 X113.857 Y183.833 Z-2.563 F25
G1 X113.955 Y183.783 Z-2.567 F25
G1 X114.057 Y183.741 Z-2.571 F25
G1 X114.161 Y183.705 Z-2.575 F25
G1 X114.268 Y183.677 Z-2.578 F25
G1 X114.376 Y183.657 Z-2.582 F25
G1 X114.485 Y183.644 Z-2.586 F25
G1 X114.596 Y183.639 Z-2.59 F25
G1 X114.706 Y183.642 Z-2.594 F25
G1 X114.815 Y183.653 Z-2.598 F25
G1 X114.924 Y183.671 Z-2.602 F25
G1 X115.031 Y183.697 Z-2.605 F25
G1 X115.136 Y183.73 Z-2.609 F25
G1 X115.239 Y183.771 Z-2.613 F25
G1 X115.338 Y183.819 Z-2.617 F25
G1 X115.434 Y183.873 Z-2.621 F25
G1 X115.525 Y183.935 Z-2.625 F25
G1 X115.612 Y184.002 Z-2.629 F25
G1 X115.694 Y184.076 Z-2.632 F25
G1 X115.771 Y184.155 Z-2.636 F25
G1 X115.842 Y184.239 Z-2.64 F25
G1 X115.907 Y184.329 Z-2.644 F25
G1 X115.965 Y184.422 Z-2.648 F25
G1 X116.016 Y184.519 Z-2.652 F25
G1 X116.061 Y184.62 Z-2.655 F25
G1 X116.098 Y184.724 Z-2.659 F25
G1 X116.128 Y184.83 Z-2.663 F25
G1 X116.15 Y184.937 Z-2.667 F25
G1 X116.165 Y185.046 Z-2.671 F25
G1 X116.172 Y185.156 Z-2.675 F25
G1 X116.171 Y185.266 Z-2.679 F25
G1 X116.163 Y185.376 Z-2.682 F25
G1 X116.147 Y185.485 Z-2.686 F25
G1 X116.123 Y185.592 Z-2.69 F25
G1 X116.091 Y185.698 Z-2.694 F25
G1 X116.053 Y185.801 Z-2.698 F25
G1 X116.007 Y185.901 Z-2.702 F25
G1 X115.954 Y185.998 Z-2.706 F25
G1 X115.894 Y186.09 Z-2.709 F25
G1 X115.829 Y186.178 Z-2.713 F25
G1 X115.757 Y186.262 Z-2.717 F25
G1 X115.679 Y186.34 Z-2.721 F25
G1 X115.596 Y186.412 Z-2.725 F25
G1 X115.508 Y186.479 Z-2.729 F25
G1 X115.416 Y186.539 Z-2.732 F25
G1 X115.32 Y186.592 Z-2.736 F25
G1 X115.22 Y186.638 Z-2.74 F25
G1 X115.117 Y186.678 Z-2.744 F25
G1 X115.012 Y186.709 Z-2.748 F25
G1 X114.904 Y186.734 Z-2.752 F25
G1 X114.796 Y186.751 Z-2.756 F25
G1 X114.686 Y186.76 Z-2.759 F25
G1 X114.576 Y186.761 Z-2.763 F25
G1 X114.466 Y186.755 Z-2.767 F25
G1 X114.357 Y186.74 Z-2.771 F25
G1 X114.25 Y186.719 Z-2.775 F25
G1 X114.144 Y186.689 Z-2.779 F25
G1 X114.04 Y186.652 Z-2.783 F25
G1 X113.939 Y186.608 Z-2.786 F25
G1 X113.842 Y186.558 Z-2.79 F25
G1 X113.748 Y186.5 Z-2.794 F25
G1 X113.659 Y186.436 Z-2.798 F25
G1 X113.574 Y186.365 Z-2.802 F25
G1 X113.495 Y186.289 Z-2.806 F25
G1 X113.421 Y186.208 Z-2.809 F25
G1 X113.353 Y186.121 Z-2.813 F25
G1 X113.292 Y186.03 Z-2.817 F25
G1 X113.236 Y185.935 Z-2.821 F25
G1 X113.188 Y185.836 Z-2.825 F25
G1 X113.147 Y185.734 Z-2.829 F25
G1 X113.113 Y185.63 Z-2.833 F25
G1 X113.087 Y185.523 Z-2.836 F25
G1 X113.068 Y185.415 Z-2.84 F25
G1 X113.057 Y185.305 Z-2.844 F25
G1 X113.054 Y185.195 Z-2.848 F25
G1 X113.058 Y185.085 Z-2.852 F25
G1 X113.07 Y184.976 Z-2.856 F25
G1 X113.09 Y184.868 Z-2.86 F25
G1 X113.117 Y184.762 Z-2.863 F25
G1 X113.152 Y184.658 Z-2.867 F25
G1 X113.194 Y184.556 Z-2.871 F25
G1 X113.243 Y184.458 Z-2.875 F25
G1 X113.299 Y184.363 Z-2.879 F25
G1 X113.361 Y184.273 Z-2.883 F25
G1 X113.43 Y184.187 Z-2.886 F25
G1 X113.504 Y184.107 Z-2.89 F25
G1 X113.584 Y184.031 Z-2.894 F25
G1 X113.669 Y183.962 Z-2.898 F25
G1 X113.759 Y183.899 Z-2.902 F25
G1 X113.853 Y183.842 Z-2.906 F25
G1 X113.951 Y183.792 Z-2.91 F25
G1 X114.052 Y183.749 Z-2.913 F25
G1 X114.156 Y183.713 Z-2.917 F25
G1 X114.262 Y183.685 Z-2.921 F25
G1 X114.37 Y183.664 Z-2.925 F25
G1 X114.479 Y183.651 Z-2.929 F25
G1 X114.588 Y183.645 Z-2.933 F25
G1 X114.698 Y183.648 Z-2.936 F25
G1 X114.808 Y183.658 Z-2.94 F25
G1 X114.916 Y183.675 Z-2.944 F25
G1 X115.023 Y183.701 Z-2.948 F25
G1 X115.128 Y183.733 Z-2.952 F25
G1 X115.23 Y183.774 Z-2.956 F25
G1 X115.329 Y183.821 Z-2.96 F25
G1 X115.424 Y183.875 Z-2.963 F25
G1 X115.516 Y183.935 Z-2.967 F25
G1 X115.603 Y184.002 Z-2.971 F25
G1 X115.685 Y184.075 Z-2.975 F25
G1 X115.762 Y184.154 Z-2.979 F25
G1 X115.832 Y184.237 Z-2.983 F25
G1 X115.897 Y184.326 Z-2.987 F25
G1 X115.956 Y184.418 Z-2.99 F25
G1 X116.008 Y184.515 Z-2.994 F25
G1 X116.052 Y184.615 Z-2.998 F25
G1 X116.09 Y184.718 Z-3.002 F25
G1 X116.12 Y184.824 Z-3.006 F25
G1 X116.143 Y184.931 Z-3.01 F25
G1 X116.158 Y185.04 Z-3.013 F25
G1 X116.166 Y185.149 Z-3.017 F25
G1 Y185.259 Z-3.021 F25
G1 X116.158 Y185.368 Z-3.025 F25
G1 X116.142 Y185.477 Z-3.029 F25
G1 X116.119 Y185.584 Z-3.033 F25
G1 X116.088 Y185.689 Z-3.037 F25
G1 X116.05 Y185.792 Z-3.04 F25
G1 X116.005 Y185.892 Z-3.044 F25
G1 X115.952 Y185.989 Z-3.048 F25
G1 X115.894 Y186.081 Z-3.052 F25
G1 X115.828 Y186.169 Z-3.056 F25
G1 X115.757 Y186.253 Z-3.06 F25
G1 X115.68 Y186.331 Z-3.064 F25
G1 X115.598 Y186.403 Z-3.067 F25
G1 X115.511 Y186.47 Z-3.071 F25
G1 X115.419 Y186.53 Z-3.075 F25
G1 X115.323 Y186.583 Z-3.079 F25
G1 X115.224 Y186.63 Z-3.083 F25
G1 X115.122 Y186.669 Z-3.087 F25
G1 X115.017 Y186.702 Z-3.09 F25
G1 X114.911 Y186.727 Z-3.094 F25
G1 X114.803 Y186.744 Z-3.098 F25
G1 X114.693 Y186.753 Z-3.102 F25
G1 X114.584 Y186.755 Z-3.106 F25
G1 X114.474 Y186.749 Z-3.11 F25
G1 X114.366 Y186.736 Z-3.114 F25
G1 X114.258 Y186.714 Z-3.117 F25
G1 X114.152 Y186.686 Z-3.121 F25
G1 X114.049 Y186.649 Z-3.125 F25
G1 X113.948 Y186.606 Z-3.129 F25
G1 X113.851 Y186.556 Z-3.133 F25
G1 X113.757 Y186.499 Z-3.137 F25
G1 X113.668 Y186.435 Z-3.141 F25
G1 X113.584 Y186.366 Z-3.144 F25
G1 X113.504 Y186.29 Z-3.148 F25
G1 X113.43 Y186.209 Z-3.152 F25
G1 X113.362 Y186.123 Z-3.156 F25
G1 X113.3 Y186.033 Z-3.16 F25
G1 X113.245 Y185.938 Z-3.164 F25
G1 X113.196 Y185.84 Z-3.167 F25
G1 X113.155 Y185.739 Z-3.171 F25
G1 X113.121 Y185.635 Z-3.175 F25
G1 X113.094 Y185.529 Z-3.179 F25
G1 X113.075 Y185.421 Z-3.183 F25
G1 X113.063 Y185.312 Z-3.187 F25
G1 X113.059 Y185.203 Z-3.191 F25
G1 X113.063 Y185.094 Z-3.194 F25
G1 X113.075 Y184.985 Z-3.198 F25
G1 X113.094 Y184.877 Z-3.202 F25
G1 X113.121 Y184.771 Z-3.206 F25
G1 X113.155 Y184.667 Z-3.21 F25
G1 X113.196 Y184.566 Z-3.214 F25
G1 X113.245 Y184.467 Z-3.218 F25
G1 X113.3 Y184.373 Z-3.221 F25
G1 X113.362 Y184.283 Z-3.225 F25
G1 X113.43 Y184.197 Z-3.229 F25
G1 X113.503 Y184.116 Z-3.233 F25
G1 X113.583 Y184.041 Z-3.237 F25
G1 X113.667 Y183.971 Z-3.241 F25
G1 X113.756 Y183.908 Z-3.244 F25
G1 X113.85 Y183.851 Z-3.248 F25
G1 X113.947 Y183.8 Z-3.252 F25
G1 X114.048 Y183.757 Z-3.256 F25
G1 X114.151 Y183.721 Z-3.26 F25
G1 X114.256 Y183.692 Z-3.264 F25
G1 X114.364 Y183.671 Z-3.268 F25
G1 X114.472 Y183.657 Z-3.271 F25
G1 X114.581 Y183.651 Z-3.275 F25
G1 X114.691 Y183.653 Z-3.279 F25
G1 X114.8 Y183.663 Z-3.283 F25
G1 X114.908 Y183.68 Z-3.287 F25
G1 X115.014 Y183.704 Z-3.291 F25
G1 X115.119 Y183.737 Z-3.294 F25
G1 X115.221 Y183.776 Z-3.298 F25
G1 X115.319 Y183.822 Z-3.302 F25
G1 X115.415 Y183.876 Z-3.306 F25
G1 X115.506 Y183.936 Z-3.31 F25
G1 X115.593 Y184.002 Z-3.314 F25
G1 X115.675 Y184.074 Z-3.318 F25
G1 X115.752 Y184.152 Z-3.321 F25
G1 X115.823 Y184.235 Z-3.325 F25
G1 X115.888 Y184.323 Z-3.329 F25
G1 X115.947 Y184.415 Z-3.333 F25
G1 X115.999 Y184.511 Z-3.337 F25
G1 X116.044 Y184.611 Z-3.341 F25
G1 X116.082 Y184.713 Z-3.345 F25
G1 X116.113 Y184.818 Z-3.348 F25
G1 X116.136 Y184.925 Z-3.352 F25
G1 X116.152 Y185.033 Z-3.356 F25
G1 X116.16 Y185.142 Z-3.36 F25
G1 Y185.252 Z-3.364 F25
G1 X116.153 Y185.361 Z-3.368 F25
G1 X116.137 Y185.469 Z-3.371 F25
G1 X116.115 Y185.576 Z-3.375 F25
G1 X116.085 Y185.681 Z-3.379 F25
G1 X116.047 Y185.783 Z-3.383 F25
G1 X116.003 Y185.883 Z-3.387 F25
G1 X115.951 Y185.979 Z-3.391 F25
G1 X115.893 Y186.072 Z-3.395 F25
G1 X115.828 Y186.16 Z-3.398 F25
G1 X115.758 Y186.243 Z-3.402 F25
G1 X115.681 Y186.321 Z-3.406 F25
G1 X115.6 Y186.394 Z-3.41 F25
G1 X115.513 Y186.46 Z-3.414 F25
G1 X115.422 Y186.521 Z-3.418 F25
G1 X115.327 Y186.574 Z-3.422 F25
G1 X115.229 Y186.621 Z-3.425 F25
G1 X115.127 Y186.661 Z-3.429 F25
G1 X115.023 Y186.694 Z-3.433 F25
G1 X114.917 Y186.719 Z-3.437 F25
G1 X114.809 Y186.737 Z-3.441 F25
G1 X114.7 Y186.747 Z-3.445 F25
G1 X114.591 Y186.749 Z-3.448 F25
G1 X114.482 Y186.744 Z-3.452 F25
G1 X114.374 Y186.731 Z-3.456 F25
G1 X114.266 Y186.71 Z-3.46 F25
G1 X114.161 Y186.682 Z-3.464 F25
G1 X114.058 Y186.646 Z-3.468 F25
G1 X113.957 Y186.604 Z-3.472 F25
G1 X113.86 Y186.554 Z-3.475 F25
G1 X113.767 Y186.498 Z-3.479 F25
G1 X113.677 Y186.435 Z-3.483 F25
G1 X113.593 Y186.366 Z-3.487 F25
G1 X113.513 Y186.291 Z-3.491 F25
G1 X113.439 Y186.211 Z-3.495 F25
G1 X113.371 Y186.126 Z-3.499 F25
G1 X113.309 Y186.036 Z-3.502 F25
G1 X113.254 Y185.942 Z-3.506 F25
G1 X113.205 Y185.845 Z-3.51 F25
G1 X113.163 Y185.744 Z-3.514 F25
G1 X113.129 Y185.641 Z-3.518 F25
G1 X113.102 Y185.535 Z-3.522 F25
G1 X113.082 Y185.428 Z-3.525 F25
G1 X113.07 Y185.319 Z-3.529 F25
G1 X113.066 Y185.21 Z-3.533 F25
G1 X113.069 Y185.101 Z-3.537 F25
G1 X113.08 Y184.993 Z-3.541 F25
G1 X113.098 Y184.885 Z-3.545 F25
G1 X113.125 Y184.779 Z-3.549 F25
G1 X113.158 Y184.676 Z-3.552 F25
G1 X113.199 Y184.574 Z-3.556 F25
G1 X113.247 Y184.476 Z-3.56 F25
G1 X113.301 Y184.382 Z-3.564 F25
G1 X113.362 Y184.292 Z-3.568 F25
G1 X113.43 Y184.206 Z-3.572 F25
G1 X113.503 Y184.125 Z-3.576 F25
G1 X113.582 Y184.05 Z-3.579 F25
G1 X113.665 Y183.98 Z-3.583 F25
G1 X113.754 Y183.916 Z-3.587 F25
G1 X113.847 Y183.859 Z-3.591 F25
G1 X113.943 Y183.809 Z-3.595 F25
G1 X114.043 Y183.765 Z-3.599 F25
G1 X114.146 Y183.729 Z-3.602 F25
G1 X114.251 Y183.7 Z-3.606 F25
G1 X114.357 Y183.678 Z-3.61 F25
G1 X114.465 Y183.664 Z-3.614 F25
G1 X114.574 Y183.657 Z-3.618 F25
G1 X114.683 Y183.659 Z-3.622 F25
G1 X114.792 Y183.668 Z-3.626 F25
G1 X114.899 Y183.684 Z-3.629 F25
G1 X115.005 Y183.708 Z-3.633 F25
G1 X115.11 Y183.74 Z-3.637 F25
G1 X115.211 Y183.779 Z-3.641 F25
G1 X115.31 Y183.825 Z-3.645 F25
G1 X115.406 Y183.877 Z-3.649 F25
G1 X115.497 Y183.937 Z-3.652 F25
G1 X115.584 Y184.002 Z-3.656 F25
G1 X115.666 Y184.074 Z-3.66 F25
G1 X115.743 Y184.151 Z-3.664 F25
G1 X115.814 Y184.233 Z-3.668 F25
G1 X115.879 Y184.321 Z-3.672 F25
G1 X115.938 Y184.412 Z-3.676 F25
G1 X115.991 Y184.508 Z-3.679 F25
G1 X116.036 Y184.607 Z-3.683 F25
G1 X116.074 Y184.709 Z-3.687 F25
G1 X116.105 Y184.813 Z-3.691 F25
G1 X116.129 Y184.919 Z-3.695 F25
G1 X116.145 Y185.027 Z-3.699 F25
G1 X116.153 Y185.135 Z-3.703 F25
G1 X116.154 Y185.244 Z-3.706 F25
G1 X116.147 Y185.353 Z-3.71 F25
G1 X116.133 Y185.46 Z-3.714 F25
G1 X116.111 Y185.567 Z-3.718 F25
G1 X116.081 Y185.672 Z-3.722 F25
G1 X116.044 Y185.774 Z-3.726 F25
G1 X116 Y185.874 Z-3.729 F25
G1 X115.95 Y185.97 Z-3.733 F25
G1 X115.892 Y186.062 Z-3.737 F25
G1 X115.828 Y186.15 Z-3.741 F25
G1 X115.758 Y186.234 Z-3.745 F25
G1 X115.682 Y186.312 Z-3.749 F25
G1 X115.602 Y186.384 Z-3.753 F25
G1 X115.516 Y186.451 Z-3.756 F25
G1 X115.425 Y186.512 Z-3.76 F25
G1 X115.331 Y186.566 Z-3.764 F25
G1 X115.233 Y186.613 Z-3.768 F25
G1 X115.132 Y186.653 Z-3.772 F25
G1 X115.028 Y186.686 Z-3.776 F25
G1 X114.922 Y186.712 Z-3.78 F25
G1 X114.815 Y186.73 Z-3.783 F25
G1 X114.707 Y186.74 Z-3.787 F25
G1 X114.598 Y186.743 Z-3.791 F25
G1 X114.489 Y186.738 Z-3.795 F25
G1 X114.382 Y186.726 Z-3.799 F25
G1 X114.275 Y186.706 Z-3.803 F25
G1 X114.17 Y186.678 Z-3.806 F25
G1 X114.067 Y186.644 Z-3.81 F25
G1 X113.966 Y186.601 Z-3.814 F25
G1 X113.869 Y186.552 Z-3.818 F25
G1 X113.776 Y186.497 Z-3.822 F25
G1 X113.687 Y186.435 Z-3.826 F25
G1 X113.602 Y186.366 Z-3.83 F25
G1 X113.523 Y186.292 Z-3.833 F25
G1 X113.449 Y186.213 Z-3.837 F25
G1 X113.381 Y186.128 Z-3.841 F25
G1 X113.318 Y186.039 Z-3.845 F25
G1 X113.263 Y185.946 Z-3.849 F25
G1 X113.214 Y185.849 Z-3.853 F25
G1 X113.171 Y185.749 Z-3.857 F25
G1 X113.137 Y185.646 Z-3.86 F25
G1 X113.109 Y185.541 Z-3.864 F25
G1 X113.089 Y185.434 Z-3.868 F25
G1 X113.076 Y185.326 Z-3.872 F25
G1 X113.072 Y185.217 Z-3.876 F25
G1 X113.074 Y185.109 Z-3.88 F25
G1 X113.085 Y185 Z-3.883 F25
G1 X113.103 Y184.893 Z-3.887 F25
G1 X113.128 Y184.788 Z-3.891 F25
G1 X113.161 Y184.684 Z-3.895 F25
G1 X113.201 Y184.583 Z-3.899 F25
G1 X113.249 Y184.486 Z-3.903 F25
G1 X113.302 Y184.391 Z-3.907 F25
G1 X113.363 Y184.301 Z-3.91 F25
G1 X113.429 Y184.215 Z-3.914 F25
G1 X113.502 Y184.135 Z-3.918 F25
G1 X113.58 Y184.059 Z-3.922 F25
G1 X113.663 Y183.989 Z-3.926 F25
G1 X113.751 Y183.926 Z-3.93 F25
G1 X113.843 Y183.868 Z-3.934 F25
G1 X113.939 Y183.817 Z-3.937 F25
G1 X114.038 Y183.773 Z-3.941 F25
G1 X114.14 Y183.737 Z-3.945 F25
G1 X114.245 Y183.707 Z-3.949 F25
G1 X114.351 Y183.685 Z-3.953 F25
G1 X114.459 Y183.671 Z-3.957 F25
G1 X114.567 Y183.664 Z-3.96 F25
G1 X114.676 Z-3.964 F25
G1 X114.784 Y183.673 Z-3.968 F25
G1 X114.891 Y183.689 Z-3.972 F25
G1 X114.997 Y183.712 Z-3.976 F25
G1 X115.101 Y183.743 Z-3.98 F25
G1 X115.203 Y183.782 Z-3.984 F25
G1 X115.301 Y183.827 Z-3.987 F25
G1 X115.397 Y183.879 Z-3.991 F25
G1 X115.488 Y183.938 Z-3.995 F25
G1 X115.575 Y184.003 Z-3.999 F25
G1 X115.657 Y184.073 Z-4.003 F25
G1 X115.734 Y184.15 Z-4.007 F25
G1 X115.805 Y184.232 Z-4.01 F25
G1 X115.87 Y184.318 Z-4.014 F25
G1 X115.929 Y184.409 Z-4.018 F25
G1 X115.982 Y184.504 Z-4.022 F25
G1 X116.028 Y184.602 Z-4.026 F25
G1 X116.066 Y184.703 Z-4.03 F25
G1 X116.098 Y184.807 Z-4.034 F25
G1 X116.122 Y184.913 Z-4.037 F25
G1 X116.138 Y185.02 Z-4.041 F25
G1 X116.147 Y185.128 Z-4.045 F25
G1 X116.148 Y185.237 Z-4.049 F25
G1 X116.142 Y185.345 Z-4.053 F25
G1 X116.128 Y185.452 Z-4.057 F25
G1 X116.107 Y185.559 Z-4.061 F25
G1 X116.078 Y185.663 Z-4.064 F25
G1 X116.041 Y185.765 Z-4.068 F25
G1 X115.998 Y185.865 Z-4.072 F25
G1 X115.948 Y185.961 Z-4.076 F25
G1 X115.891 Y186.053 Z-4.08 F25
G1 X115.828 Y186.141 Z-4.084 F25
G1 X115.758 Y186.224 Z-4.087 F25
G1 X115.683 Y186.303 Z-4.091 F25
G1 X115.603 Y186.375 Z-4.095 F25
G1 X115.518 Y186.442 Z-4.099 F25
G1 X115.428 Y186.503 Z-4.103 F25
G1 X115.334 Y186.557 Z-4.107 F25
G1 X115.237 Y186.605 Z-4.111 F25
G1 X115.136 Y186.645 Z-4.114 F25
G1 X115.033 Y186.679 Z-4.118 F25
G1 X114.928 Y186.705 Z-4.122 F25
G1 X114.822 Y186.723 Z-4.126 F25
G1 X114.714 Y186.734 Z-4.13 F25
G1 X114.606 Y186.737 Z-4.134 F25
G1 X114.497 Y186.733 Z-4.138 F25
G1 X114.39 Y186.721 Z-4.141 F25
G1 X114.283 Y186.702 Z-4.145 F25
G1 X114.178 Y186.675 Z-4.149 F25
G1 X114.076 Y186.64 Z-4.153 F25
G1 X113.976 Y186.599 Z-4.157 F25
G1 X113.879 Y186.551 Z-4.161 F25
G1 X113.786 Y186.496 Z-4.164 F25
G1 X113.696 Y186.434 Z-4.168 F25
G1 X113.612 Y186.366 Z-4.172 F25
G1 X113.532 Y186.293 Z-4.176 F25
G1 X113.458 Y186.214 Z-4.18 F25
G1 X113.39 Y186.13 Z-4.184 F25
G1 X113.327 Y186.042 Z-4.188 F25
G1 X113.271 Y185.949 Z-4.191 F25
G1 X113.222 Y185.853 Z-4.195 F25
G1 X113.18 Y185.753 Z-4.199 F25
G1 X113.144 Y185.65 Z-4.203 F25
G1 X113.116 Y185.546 Z-4.207 F25
G1 X113.096 Y185.44 Z-4.211 F25
G1 X113.083 Y185.332 Z-4.215 F25
G1 X113.078 Y185.224 Z-4.218 F25
G1 X113.08 Y185.116 Z-4.222 F25
G1 X113.09 Y185.009 Z-4.226 F25
G1 X113.107 Y184.902 Z-4.23 F25
G1 X113.132 Y184.797 Z-4.234 F25
G1 X113.164 Y184.693 Z-4.238 F25
G1 X113.204 Y184.593 Z-4.241 F25
G1 X113.25 Y184.495 Z-4.245 F25
G1 X113.304 Y184.401 Z-4.249 F25
G1 X113.363 Y184.311 Z-4.253 F25
G1 X113.429 Y184.225 Z-4.257 F25
G1 X113.501 Y184.144 Z-4.261 F25
G1 X113.579 Y184.068 Z-4.265 F25
G1 X113.661 Y183.999 Z-4.268 F25
G1 X113.748 Y183.935 Z-4.272 F25
G1 X113.84 Y183.877 Z-4.276 F25
G1 X113.935 Y183.826 Z-4.28 F25
G1 X114.034 Y183.782 Z-4.284 F25
G1 X114.136 Y183.745 Z-4.288 F25
G1 X114.24 Y183.715 Z-4.292 F25
G1 X114.345 Y183.692 Z-4.295 F25
G1 X114.452 Y183.677 Z-4.299 F25
G1 X114.56 Y183.67 Z-4.303 F25
G1 X114.669 Z-4.307 F25
G1 X114.776 Y183.678 Z-4.311 F25
G1 X114.883 Y183.693 Z-4.315 F25
G1 X114.989 Y183.716 Z-4.318 F25
G1 X115.092 Y183.747 Z-4.322 F25
G1 X115.194 Y183.784 Z-4.326 F25
G1 X115.292 Y183.829 Z-4.33 F25
G1 X115.387 Y183.88 Z-4.334 F25
G1 X115.478 Y183.938 Z-4.338 F25
G1 X115.565 Y184.002 Z-4.342 F25
G1 X115.647 Y184.073 Z-4.345 F25
G1 X115.724 Y184.149 Z-4.349 F25
G1 X115.796 Y184.23 Z-4.353 F25
G1 X115.861 Y184.316 Z-4.357 F25
G1 X115.92 Y184.406 Z-4.361 F25
G1 X115.973 Y184.5 Z-4.365 F25
G1 X116.019 Y184.598 Z-4.368 F25
G1 X116.058 Y184.699 Z-4.372 F25
G1 X116.09 Y184.802 Z-4.376 F25
G1 X116.114 Y184.907 Z-4.38 F25
G1 X116.131 Y185.014 Z-4.384 F25
G1 X116.141 Y185.121 Z-4.388 F25
G1 X116.143 Y185.229 Z-4.392 F25
G1 X116.137 Y185.337 Z-4.395 F25
G1 X116.123 Y185.445 Z-4.399 F25
G1 X116.102 Y185.55 Z-4.403 F25
G1 X116.074 Y185.655 Z-4.407 F25
G1 X116.038 Y185.757 Z-4.411 F25
G1 X115.996 Y185.856 Z-4.415 F25
G1 X115.946 Y185.952 Z-4.419 F25
G1 X115.89 Y186.044 Z-4.422 F25
G1 X115.827 Y186.132 Z-4.426 F25
G1 X115.759 Y186.215 Z-4.43 F25
G1 X115.684 Y186.293 Z-4.434 F25
G1 X115.605 Y186.366 Z-4.438 F25
G1 X115.52 Y186.433 Z-4.442 F25
G1 X115.431 Y186.494 Z-4.445 F25
G1 X115.338 Y186.549 Z-4.449 F25
G1 X115.241 Y186.596 Z-4.453 F25
G1 X115.141 Y186.637 Z-4.457 F25
G1 X115.039 Y186.671 Z-4.461 F25
G1 X114.934 Y186.697 Z-4.465 F25
G1 X114.828 Y186.716 Z-4.469 F25
G1 X114.721 Y186.728 Z-4.472 F25
G1 X114.613 Y186.731 Z-4.476 F25
G1 X114.505 Y186.728 Z-4.48 F25
G1 X114.398 Y186.716 Z-4.484 F25
G1 X114.291 Y186.697 Z-4.488 F25
G1 X114.187 Y186.671 Z-4.492 F25
G1 X114.084 Y186.637 Z-4.496 F25
G1 X113.984 Y186.596 Z-4.499 F25
G1 X113.888 Y186.549 Z-4.503 F25
G1 X113.794 Y186.494 Z-4.507 F25
G1 X113.705 Y186.433 Z-4.511 F25
G1 X113.621 Y186.366 Z-4.515 F25
G1 X113.541 Y186.294 Z-4.519 F25
G1 X113.467 Y186.215 Z-4.522 F25
G1 X113.399 Y186.132 Z-4.526 F25
G1 X113.336 Y186.044 Z-4.53 F25
G1 X113.28 Y185.952 Z-4.534 F25
G1 X113.23 Y185.857 Z-4.538 F25
G1 X113.188 Y185.758 Z-4.542 F25
G1 X113.152 Y185.656 Z-4.546 F25
G1 X113.124 Y185.552 Z-4.549 F25
G1 X113.103 Y185.446 Z-4.553 F25
G1 X113.09 Y185.339 Z-4.557 F25
G1 X113.084 Y185.232 Z-4.561 F25
G1 X113.085 Y185.124 Z-4.565 F25
G1 X113.095 Y185.017 Z-4.569 F25
G1 X113.112 Y184.91 Z-4.573 F25
G1 X113.136 Y184.805 Z-4.576 F25
G1 X113.168 Y184.702 Z-4.58 F25
G1 X113.207 Y184.602 Z-4.584 F25
G1 X113.253 Y184.504 Z-4.588 F25
G1 X113.305 Y184.41 Z-4.592 F25
G1 X113.364 Y184.32 Z-4.596 F25
G1 X113.43 Y184.234 Z-4.599 F25
G1 X113.501 Y184.153 Z-4.603 F25
G1 X113.578 Y184.078 Z-4.607 F25
G1 X113.659 Y184.007 Z-4.611 F25
G1 X113.746 Y183.943 Z-4.615 F25
G1 X113.837 Y183.885 Z-4.619 F25
G1 X113.932 Y183.834 Z-4.623 F25
G1 X114.03 Y183.79 Z-4.626 F25
G1 X114.131 Y183.752 Z-4.63 F25
G1 X114.234 Y183.722 Z-4.634 F25
G1 X114.339 Y183.699 Z-4.638 F25
G1 X114.446 Y183.684 Z-4.642 F25
G1 X114.553 Y183.676 Z-4.646 F25
G1 X114.661 Z-4.65 F25
G1 X114.768 Y183.683 Z-4.653 F25
G1 X114.875 Y183.698 Z-4.657 F25
G1 X114.98 Y183.72 Z-4.661 F25
G1 X115.084 Y183.75 Z-4.665 F25
G1 X115.185 Y183.787 Z-4.669 F25
G1 X115.283 Y183.831 Z-4.673 F25
G1 X115.378 Y183.882 Z-4.676 F25
G1 X115.469 Y183.939 Z-4.68 F25
G1 X115.556 Y184.003 Z-4.684 F25
G1 X115.638 Y184.072 Z-4.688 F25
G1 X115.715 Y184.148 Z-4.692 F25
G1 X115.786 Y184.228 Z-4.696 F25
G1 X115.852 Y184.313 Z-4.7 F25
G1 X115.912 Y184.403 Z-4.703 F25
G1 X115.965 Y184.497 Z-4.707 F25
G1 X116.011 Y184.594 Z-4.711 F25
G1 X116.05 Y184.694 Z-4.715 F25
G1 X116.082 Y184.797 Z-4.719 F25
G1 X116.107 Y184.902 Z-4.723 F25
G1 X116.125 Y185.008 Z-4.726 F25
G1 X116.134 Y185.115 Z-4.73 F25
G1 X116.137 Y185.222 Z-4.734 F25
G1 X116.131 Y185.33 Z-4.738 F25
G1 X116.119 Y185.436 Z-4.742 F25
G1 X116.098 Y185.542 Z-4.746 F25
G1 X116.071 Y185.646 Z-4.75 F25
G1 X116.036 Y185.748 Z-4.753 F25
G1 X115.993 Y185.847 Z-4.757 F25
G1 X115.945 Y185.942 Z-4.761 F25
G1 X115.889 Y186.034 Z-4.765 F25
G1 X115.827 Y186.122 Z-4.769 F25
G1 X115.759 Y186.206 Z-4.773 F25
G1 X115.685 Y186.284 Z-4.777 F25
G1 X115.606 Y186.357 Z-4.78 F25
G1 X115.522 Y186.424 Z-4.784 F25
G1 X115.434 Y186.485 Z-4.788 F25
G1 X115.341 Y186.54 Z-4.792 F25
G1 X115.245 Y186.588 Z-4.796 F25
G1 X115.146 Y186.629 Z-4.8 F25
G1 X115.044 Y186.663 Z-4.803 F25
G1 X114.94 Y186.69 Z-4.807 F25
G1 X114.834 Y186.709 Z-4.811 F25
G1 X114.727 Y186.721 Z-4.815 F25
G1 X114.62 Y186.725 Z-4.819 F25
G1 X114.512 Y186.722 Z-4.823 F25
G1 X114.405 Y186.711 Z-4.827 F25
G1 X114.299 Y186.693 Z-4.83 F25
G1 X114.195 Y186.667 Z-4.834 F25
G1 X114.093 Y186.634 Z-4.838 F25
G1 X113.993 Y186.594 Z-4.842 F25
G1 X113.897 Y186.547 Z-4.846 F25
G1 X113.804 Y186.493 Z-4.85 F25
G1 X113.715 Y186.433 Z-4.854 F25
G1 X113.63 Y186.367 Z-4.857 F25
G1 X113.551 Y186.295 Z-4.861 F25
G1 X113.476 Y186.217 Z-4.865 F25
G1 X113.408 Y186.134 Z-4.869 F25
G1 X113.345 Y186.047 Z-4.873 F25
G1 X113.289 Y185.956 Z-4.877 F25
G1 X113.239 Y185.861 Z-4.88 F25
G1 X113.196 Y185.762 Z-4.884 F25
G1 X113.16 Y185.661 Z-4.888 F25
G1 X113.131 Y185.558 Z-4.892 F25
G1 X113.11 Y185.452 Z-4.896 F25
G1 X113.096 Y185.346 Z-4.9 F25
G1 X113.09 Y185.239 Z-4.904 F25
G1 X113.091 Y185.131 Z-4.907 F25
G1 X113.1 Y185.024 Z-4.911 F25
G1 X113.116 Y184.918 Z-4.915 F25
G1 X113.14 Y184.813 Z-4.919 F25
G1 X113.171 Y184.71 Z-4.923 F25
G1 X113.209 Y184.61 Z-4.927 F25
G1 X113.255 Y184.513 Z-4.931 F25
G1 X113.307 Y184.419 Z-4.934 F25
G1 X113.365 Y184.329 Z-4.938 F25
G1 X113.43 Y184.243 Z-4.942 F25
G1 X113.5 Y184.162 Z-4.946 F25
G1 X113.576 Y184.087 Z-4.95 F25
G1 X113.657 Y184.017 Z-4.954 F25
G1 X113.743 Y183.952 Z-4.957 F25
G1 X113.834 Y183.894 Z-4.961 F25
G1 X113.928 Y183.843 Z-4.965 F25
G1 X114.025 Y183.798 Z-4.969 F25
G1 X114.126 Y183.76 Z-4.973 F25
G1 X114.228 Y183.73 Z-4.977 F25
G1 X114.333 Y183.706 Z-4.981 F25
G1 X114.439 Y183.691 Z-4.984 F25
G1 X114.546 Y183.682 Z-4.988 F25
G1 X114.653 Z-4.992 F25
G1 X114.76 Y183.688 Z-4.996 F25
G1 X114.867 Y183.703 Z-5 F25
G1 X114.972 Y183.724 Z-5.004 F25
G1 X115.075 Y183.754 Z-5.008 F25
G1 X115.176 Y183.79 Z-5.011 F25
G1 X115.274 Y183.833 Z-5.015 F25
G1 X115.369 Y183.883 Z-5.019 F25
G1 X115.46 Y183.94 Z-5.023 F25
G1 X115.547 Y184.003 Z-5.027 F25
G1 X115.629 Y184.072 Z-5.031 F25
G1 X115.706 Y184.147 Z-5.034 F25
G1 X115.778 Y184.227 Z-5.038 F25
G1 X115.843 Y184.311 Z-5.042 F25
G1 X115.903 Y184.4 Z-5.046 F25
G1 X115.956 Y184.493 Z-5.05 F25
G1 X116.003 Y184.59 Z-5.054 F25
G1 X116.042 Y184.689 Z-5.058 F25
G1 X116.075 Y184.791 Z-5.061 F25
G1 X116.1 Y184.895 Z-5.065 F25
G1 X116.118 Y185.001 Z-5.069 F25
G1 X116.128 Y185.108 Z-5.073 F25
G1 X116.131 Y185.215 Z-5.077 F25
G1 X116.126 Y185.322 Z-5.081 F25
G1 X116.114 Y185.428 Z-5.084 F25
G1 X116.094 Y185.534 Z-5.088 F25
G1 X116.067 Y185.637 Z-5.092 F25
G1 X116.032 Y185.739 Z-5.096 F25
G1 X115.991 Y185.837 Z-5.1 F25
G1 X115.943 Y185.933 Z-5.104 F25
G1 X115.888 Y186.025 Z-5.108 F25
G1 X115.826 Y186.113 Z-5.111 F25
G1 X115.759 Y186.196 Z-5.115 F25
G1 X115.686 Y186.275 Z-5.119 F25
G1 X115.608 Y186.348 Z-5.123 F25
G1 X115.524 Y186.415 Z-5.127 F25
G1 X115.436 Y186.476 Z-5.131 F25
G1 X115.344 Y186.531 Z-5.135 F25
G1 X115.249 Y186.58 Z-5.138 F25
G1 X115.15 Y186.621 Z-5.142 F25
G1 X115.049 Y186.655 Z-5.146 F25
G1 X114.945 Y186.683 Z-5.15 F25
G1 X114.84 Y186.702 Z-5.154 F25
G1 X114.734 Y186.715 Z-5.158 F25
G1 X114.627 Y186.719 Z-5.161 F25
G1 X114.52 Y186.717 Z-5.165 F25
G1 X114.413 Y186.706 Z-5.169 F25
G1 X114.308 Y186.689 Z-5.173 F25
G1 X114.204 Y186.663 Z-5.177 F25
G1 X114.102 Y186.631 Z-5.181 F25
G1 X114.003 Y186.591 Z-5.185 F25
G1 X113.906 Y186.545 Z-5.188 F25
G1 X113.813 Y186.492 Z-5.192 F25
G1 X113.724 Y186.432 Z-5.196 F25
G1 X113.64 Y186.367 Z-5.2 F25
G1 X113.56 Y186.295 Z-5.204 F25
G1 X113.486 Y186.218 Z-5.208 F25
G1 X113.417 Y186.136 Z-5.212 F25
G1 X113.354 Y186.05 Z-5.215 F25
G1 X113.297 Y185.959 Z-5.219 F25
G1 X113.247 Y185.864 Z-5.223 F25
G1 X113.204 Y185.766 Z-5.227 F25
G1 X113.168 Y185.666 Z-5.231 F25
G1 X113.139 Y185.563 Z-5.235 F25
G1 X113.117 Y185.458 Z-5.238 F25
G1 X113.103 Y185.352 Z-5.242 F25
G1 X113.096 Y185.245 Z-5.246 F25
G1 X113.097 Y185.138 Z-5.25 F25
G1 X113.105 Y185.032 Z-5.254 F25
G1 X113.121 Y184.926 Z-5.258 F25
G1 X113.144 Y184.822 Z-5.262 F25
G1 X113.174 Y184.719 Z-5.265 F25
G1 X113.212 Y184.619 Z-5.269 F25
G1 X113.257 Y184.522 Z-5.273 F25
G1 X113.308 Y184.428 Z-5.277 F25
G1 X113.366 Y184.338 Z-5.281 F25
G1 X113.43 Y184.253 Z-5.285 F25
G1 X113.5 Y184.172 Z-5.289 F25
G1 X113.575 Y184.096 Z-5.292 F25
G1 X113.656 Y184.026 Z-5.296 F25
G1 X113.741 Y183.962 Z-5.3 F25
G1 X113.831 Y183.903 Z-5.304 F25
G1 X113.924 Y183.852 Z-5.308 F25
G1 X114.021 Y183.806 Z-5.312 F25
G1 X114.121 Y183.768 Z-5.315 F25
G1 X114.223 Y183.737 Z-5.319 F25
G1 X114.327 Y183.714 Z-5.323 F25
G1 X114.433 Y183.697 Z-5.327 F25
G1 X114.54 Y183.689 Z-5.331 F25
G1 X114.646 Y183.687 Z-5.335 F25
G1 X114.753 Y183.694 Z-5.339 F25
G1 X114.859 Y183.707 Z-5.342 F25
G1 X114.964 Y183.729 Z-5.346 F25
G1 X115.067 Y183.757 Z-5.35 F25
G1 X115.167 Y183.793 Z-5.354 F25
G1 X115.265 Y183.836 Z-5.358 F25
G1 X115.36 Y183.885 Z-5.362 F25
G1 X115.451 Y183.941 Z-5.366 F25
G1 X115.537 Y184.003 Z-5.369 F25
G1 X115.619 Y184.072 Z-5.373 F25
G1 X115.696 Y184.146 Z-5.377 F25
G1 X115.768 Y184.225 Z-5.381 F25
G1 X115.834 Y184.309 Z-5.385 F25
G1 X115.894 Y184.397 Z-5.389 F25
G1 X115.947 Y184.489 Z-5.392 F25
G1 X115.994 Y184.585 Z-5.396 F25
G1 X116.034 Y184.684 Z-5.4 F25
G1 X116.067 Y184.786 Z-5.404 F25
G1 X116.093 Y184.89 Z-5.408 F25
G1 X116.111 Y184.995 Z-5.412 F25
G1 X116.122 Y185.101 Z-5.416 F25
G1 X116.125 Y185.208 Z-5.419 F25
G1 X116.121 Y185.314 Z-5.423 F25
G1 X116.109 Y185.421 Z-5.427 F25
G1 X116.09 Y185.526 Z-5.431 F25
G1 X116.063 Y185.629 Z-5.435 F25
G1 X116.029 Y185.73 Z-5.439 F25
G1 X115.988 Y185.829 Z-5.442 F25
G1 X115.941 Y185.924 Z-5.446 F25
G1 X115.886 Y186.016 Z-5.45 F25
G1 X115.826 Y186.104 Z-5.454 F25
G1 X115.759 Y186.187 Z-5.458 F25
G1 X115.687 Y186.266 Z-5.462 F25
G1 X115.609 Y186.339 Z-5.466 F25
G1 X115.527 Y186.406 Z-5.469 F25
G1 X115.439 Y186.467 Z-5.473 F25
G1 X115.348 Y186.523 Z-5.477 F25
G1 X115.253 Y186.571 Z-5.481 F25
G1 X115.155 Y186.613 Z-5.485 F25
G1 X115.054 Y186.648 Z-5.489 F25
G1 X114.951 Y186.675 Z-5.493 F25
G1 X114.846 Y186.695 Z-5.496 F25
G1 X114.741 Y186.708 Z-5.5 F25
G1 X114.634 Y186.713 Z-5.504 F25
G1 X114.528 Y186.711 Z-5.508 F25
G1 X114.421 Y186.701 Z-5.512 F25
G1 X114.316 Y186.684 Z-5.516 F25
G1 X114.212 Y186.659 Z-5.519 F25
G1 X114.111 Y186.628 Z-5.523 F25
G1 X114.011 Y186.589 Z-5.527 F25
G1 X113.915 Y186.543 Z-5.531 F25
G1 X113.822 Y186.49 Z-5.535 F25
G1 X113.733 Y186.431 Z-5.539 F25
G1 X113.649 Y186.366 Z-5.543 F25
G1 X113.569 Y186.295 Z-5.546 F25
G1 X113.495 Y186.219 Z-5.55 F25
G1 X113.426 Y186.138 Z-5.554 F25
G1 X113.363 Y186.052 Z-5.558 F25
G1 X113.306 Y185.962 Z-5.562 F25
G1 X113.256 Y185.868 Z-5.566 F25
G1 X113.212 Y185.771 Z-5.57 F25
G1 X113.176 Y185.671 Z-5.573 F25
G1 X113.146 Y185.568 Z-5.577 F25
G1 X113.124 Y185.464 Z-5.581 F25
G1 X113.109 Y185.359 Z-5.585 F25
G1 X113.102 Y185.252 Z-5.589 F25
G1 Y185.146 Z-5.593 F25
G1 X113.11 Y185.04 Z-5.596 F25
G1 X113.125 Y184.934 Z-5.6 F25
G1 X113.148 Y184.83 Z-5.604 F25
G1 X113.178 Y184.728 Z-5.608 F25
G1 X113.215 Y184.628 Z-5.612 F25
G1 X113.259 Y184.531 Z-5.616 F25
G1 X113.31 Y184.438 Z-5.62 F25
G1 X113.367 Y184.348 Z-5.623 F25
G1 X113.43 Y184.262 Z-5.627 F25
G1 X113.499 Y184.181 Z-5.631 F25
G1 X113.574 Y184.105 Z-5.635 F25
G1 X113.654 Y184.035 Z-5.639 F25
G1 X113.739 Y183.97 Z-5.643 F25
G1 X113.828 Y183.912 Z-5.647 F25
G1 X113.921 Y183.86 Z-5.65 F25
G1 X114.017 Y183.815 Z-5.654 F25
G1 X114.116 Y183.776 Z-5.658 F25
G1 X114.218 Y183.745 Z-5.662 F25
G1 X114.322 Y183.721 Z-5.666 F25
G1 X114.427 Y183.704 Z-5.67 F25
G1 X114.533 Y183.695 Z-5.673 F25
G1 X114.639 Y183.693 Z-5.677 F25
G1 X114.745 Y183.699 Z-5.681 F25
G1 X114.851 Y183.712 Z-5.685 F25
G1 X114.955 Y183.733 Z-5.689 F25
G1 X115.058 Y183.761 Z-5.693 F25
G1 X115.158 Y183.796 Z-5.697 F25
G1 X115.256 Y183.838 Z-5.7 F25
G1 X115.35 Y183.887 Z-5.704 F25
G1 X115.441 Y183.942 Z-5.708 F25
G1 X115.528 Y184.004 Z-5.712 F25
G1 X115.61 Y184.071 Z-5.716 F25
G1 X115.687 Y184.145 Z-5.72 F25
G1 X115.759 Y184.223 Z-5.724 F25
G1 X115.825 Y184.307 Z-5.727 F25
G1 X115.885 Y184.394 Z-5.731 F25
G1 X115.939 Y184.486 Z-5.735 F25
G1 X115.986 Y184.582 Z-5.739 F25
G1 X116.026 Y184.68 Z-5.743 F25
G1 X116.059 Y184.781 Z-5.747 F25
G1 X116.085 Y184.884 Z-5.75 F25
G1 X116.104 Y184.989 Z-5.754 F25
G1 X116.115 Y185.095 Z-5.758 F25
G1 X116.119 Y185.201 Z-5.762 F25
G3 X113.103 I-1.508 F25
G3 X116.119 I1.508 F25
; MOVEMENT_CUTTING
G1 X116.137 Y185.899 F254
G1 X116.162 Y185.982 F254
G1 X116.186 Y186.133 F254
G1 X116.18 Y186.285 F254
G1 X116.149 Y186.434 F254
G1 X116.097 Y186.578 F254
G1 X116.028 Y186.714 F254
G1 X115.944 Y186.841 F254
G1 X115.847 Y186.958 F254
G1 X115.738 Y187.065 F254
G1 X115.62 Y187.161 F254
G1 X115.494 Y187.247 F254
G1 X115.361 Y187.321 F254
G1 X115.222 Y187.383 F254
G1 X115.075 Y187.436 F254
G1 X114.922 Y187.477 F254
G1 X114.762 Y187.506 F254
G1 X114.597 Y187.523 F254
G1 X114.428 Y187.527 F254
G1 X114.257 Y187.517 F254
G1 X114.085 Y187.492 F254
G1 X113.913 Y187.454 F254
G1 X113.743 Y187.401 F254
G1 X113.576 Y187.335 F254
G1 X113.567 Y187.33 F254
G1 X113.446 Y187.255 F254
G1 X113.341 Y187.158 F254
G1 X113.258 Y187.042 F254
G1 X112.758 Y186.193 F254
G1 X112.695 Y186.085 F254
G1 X112.638 Y185.927 F254
G1 X112.48 Y185.451 F254
G1 X112.439 Y185.301 F254
G1 X112.41 Y185.151 F254
G1 X112.395 Y185 F254
G1 X112.393 Y184.847 F254
G1 X112.404 Y184.695 F254
G1 X112.428 Y184.542 F254
G1 X112.465 Y184.388 F254
G1 X112.515 Y184.234 F254
G1 X112.578 Y184.081 F254
G1 X112.655 Y183.932 F254
G1 X112.745 Y183.786 F254
G1 X112.849 Y183.647 F254
G1 X112.964 Y183.514 F254
G1 X113.091 Y183.39 F254
G1 X113.229 Y183.275 F254
G1 X113.378 Y183.17 F254
G1 X113.535 Y183.077 F254
G1 X113.701 Y182.997 F254
G1 X113.873 Y182.929 F254
G1 X114.052 Y182.875 F254
G1 X114.235 Y182.836 F254
G1 X114.422 Y182.811 F254
G1 X114.61 Y182.801 F254
G1 X114.8 Y182.807 F254
G1 X114.989 Y182.828 F254
G1 X115.176 Y182.864 F254
G1 X115.36 Y182.915 F254
G1 X115.414 Y182.934 F254
G1 X115.526 Y182.986 F254
G1 X115.628 Y183.056 F254
G1 X115.717 Y183.142 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X115.745 Y183.183 Z-5.742 F254
G1 X115.767 Y183.228 Z-5.721 F254
G1 X115.781 Y183.276 Z-5.701 F254
G1 X115.788 Y183.325 Z-5.681 F254
G1 X115.787 Y183.375 Z-5.66 F254
G1 X115.778 Y183.424 Z-5.64 F254
G1 X115.761 Y183.471 Z-5.62 F254
G1 X115.738 Y183.515 Z-5.599 F254
G1 X115.708 Y183.555 Z-5.579 F254
G1 X115.672 Y183.589 Z-5.559 F254
G3 X115.66 Y183.598 I-0.201 J-0.246 F254
G1 X115.473 Y183.736 F254
; MOVEMENT_LINK_DIRECT
G1 X113.093 Y185.502 F254
; MOVEMENT_LEAD_IN
G1 X112.967 Y185.595 F254
G3 X112.888 Y185.638 I-0.189 J-0.255 F254
G1 X112.84 Y185.652 Z-5.579 F254
G1 X112.791 Y185.658 Z-5.599 F254
G1 X112.741 Y185.656 Z-5.62 F254
G1 X112.692 Y185.646 Z-5.64 F254
G1 X112.646 Y185.629 Z-5.66 F254
G1 X112.602 Y185.605 Z-5.681 F254
G1 X112.563 Y185.574 Z-5.701 F254
G1 X112.529 Y185.537 Z-5.721 F254
G1 X112.501 Y185.496 Z-5.742 F254
G1 X112.48 Y185.451 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X112.244 Y184.737 F254
G1 X112.234 Y184.697 F254
G1 X112.228 Y184.658 F254
G1 X112.169 Y184.023 F254
G1 X112.162 Y183.871 F254
G1 X112.171 Y183.719 F254
G1 X112.196 Y183.569 F254
G1 X112.237 Y183.422 F254
G1 X112.291 Y183.279 F254
G1 X112.358 Y183.14 F254
G1 X112.441 Y182.998 F254
G1 X112.538 Y182.859 F254
G1 X112.651 Y182.72 F254
G1 X112.784 Y182.584 F254
G1 X112.934 Y182.452 F254
G1 X113.098 Y182.329 F254
G1 X113.276 Y182.217 F254
G1 X113.47 Y182.116 F254
G1 X113.679 Y182.028 F254
G1 X113.904 Y181.954 F254
G1 X114.066 Y181.933 F254
G1 X114.229 Y181.948 F254
G1 X114.385 Y181.999 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X114.428 Y182.024 Z-5.742 F254
G1 X114.466 Y182.056 Z-5.721 F254
G1 X114.499 Y182.094 Z-5.701 F254
G1 X114.525 Y182.136 Z-5.681 F254
G1 X114.545 Y182.182 Z-5.66 F254
G1 X114.557 Y182.23 Z-5.64 F254
G1 X114.561 Y182.279 Z-5.62 F254
G1 X114.558 Y182.329 Z-5.599 F254
G1 X114.547 Y182.378 Z-5.579 F254
G1 X114.529 Y182.424 Z-5.559 F254
G3 X114.464 Y182.512 I-0.285 J-0.141 F254
G1 X114.365 Y182.607 F254
; MOVEMENT_LINK_DIRECT
G1 X112.736 Y184.18 F254
; MOVEMENT_LEAD_IN
G1 X112.704 Y184.211 F254
G3 X112.524 Y184.297 I-0.221 J-0.228 F254
G1 X112.474 Y184.3 Z-5.579 F254
G1 X112.425 Y184.295 Z-5.599 F254
G1 X112.377 Y184.282 Z-5.62 F254
G1 X112.331 Y184.261 Z-5.64 F254
G1 X112.29 Y184.234 Z-5.66 F254
G1 X112.253 Y184.201 Z-5.681 F254
G1 X112.221 Y184.162 Z-5.701 F254
G1 X112.197 Y184.119 Z-5.721 F254
G1 X112.179 Y184.072 Z-5.742 F254
G1 X112.169 Y184.023 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X112.124 Y183.547 F254
G1 X112.122 Y183.504 F254
G1 X112.124 Y183.461 F254
G1 X112.251 Y182.675 F254
G1 X112.259 Y182.636 F254
G1 X112.27 Y182.596 F254
G1 X112.282 Y182.567 F254
G1 X112.506 Y182.12 F254
G1 X112.544 Y182.065 F254
G1 X112.599 Y182.01 F254
G1 X112.758 Y181.861 F254
G1 X112.797 Y181.827 F254
G1 X112.836 Y181.803 F254
G1 X112.876 Y181.783 F254
G1 X112.916 Y181.769 F254
G1 X113.075 Y181.723 F254
G1 X113.154 Y181.701 F254
G1 X113.194 Y181.694 F254
G1 X113.234 Y181.692 F254
G1 X113.63 Y181.721 F254
G1 X113.67 Y181.725 F254
G1 X113.709 Y181.733 F254
G1 X113.868 Y181.792 F254
G1 X114.343 Y181.98 F254
G1 X114.423 Y182.016 F254
G1 X114.502 Y182.07 F254
G1 X115.223 Y182.596 F254
G1 X115.259 Y182.624 F254
G1 X115.294 Y182.659 F254
G1 X116.087 Y183.566 F254
G1 X116.117 Y183.601 F254
G1 X116.141 Y183.636 F254
G1 X116.8 Y184.816 F254
G1 X116.841 Y184.896 F254
G1 X116.867 Y184.975 F254
G1 X116.964 Y185.292 F254
G1 X117.038 Y185.587 F254
G1 X117.068 Y185.766 F254
G1 X117.083 Y185.944 F254
G1 X117.084 Y186.118 F254
G1 X117.07 Y186.296 F254
G1 X117.042 Y186.475 F254
G1 X117 Y186.652 F254
G1 X116.943 Y186.824 F254
G1 X116.871 Y186.996 F254
G1 X116.784 Y187.165 F254
G1 X116.681 Y187.33 F254
G1 X116.563 Y187.489 F254
G1 X116.431 Y187.641 F254
G1 X116.284 Y187.784 F254
G1 X116.123 Y187.917 F254
G1 X115.95 Y188.039 F254
G1 X115.763 Y188.149 F254
G1 X115.563 Y188.246 F254
G1 X115.353 Y188.327 F254
G1 X115.133 Y188.393 F254
G1 X114.904 Y188.442 F254
G1 X114.882 Y188.445 F254
G1 X114.701 Y188.446 F254
G1 X114.525 Y188.404 F254
G1 X114.365 Y188.32 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X114.328 Y188.287 Z-5.742 F254
G1 X114.296 Y188.249 Z-5.721 F254
G1 X114.27 Y188.206 Z-5.701 F254
G1 X114.252 Y188.16 Z-5.681 F254
G1 X114.241 Y188.111 Z-5.66 F254
G1 X114.237 Y188.062 Z-5.64 F254
G1 X114.242 Y188.012 Z-5.62 F254
G1 X114.254 Y187.964 Z-5.599 F254
G1 X114.273 Y187.918 Z-5.579 F254
G1 X114.3 Y187.876 Z-5.559 F254
G1 X114.305 Y187.868 F254
G1 X114.453 Y187.682 F254
; MOVEMENT_LINK_DIRECT
G1 X116.374 Y185.25 F254
; MOVEMENT_LEAD_IN
G1 X116.414 Y185.199 F254
G3 X116.56 Y185.095 I0.249 J0.197 F254
G1 X116.609 Y185.083 Z-5.579 F254
G1 X116.658 Y185.078 Z-5.599 F254
G1 X116.708 Y185.081 Z-5.62 F254
G1 X116.756 Y185.092 Z-5.64 F254
G1 X116.803 Y185.11 Z-5.66 F254
G1 X116.846 Y185.135 Z-5.681 F254
G1 X116.884 Y185.167 Z-5.701 F254
G1 X116.917 Y185.204 Z-5.721 F254
G1 X116.944 Y185.246 Z-5.742 F254
G1 X116.964 Y185.292 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X117.206 Y186.085 F254
G1 X117.252 Y186.244 F254
G1 X117.266 Y186.402 F254
G1 X117.31 Y187.037 F254
G1 X117.313 Y187.212 F254
G1 X117.303 Y187.364 F254
G1 X117.278 Y187.514 F254
G1 X117.239 Y187.662 F254
G1 X117.186 Y187.81 F254
G1 X117.119 Y187.958 F254
G1 X117.032 Y188.115 F254
G1 X116.926 Y188.274 F254
G1 X116.805 Y188.429 F254
G1 X116.661 Y188.584 F254
G1 X116.495 Y188.737 F254
G1 X116.309 Y188.883 F254
G1 X116.237 Y188.93 F254
G1 X116.029 Y189.025 F254
G1 X115.802 Y189.052 F254
G1 X115.577 Y189.009 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X115.535 Y188.988 Z-5.743 F254
G1 X115.496 Y188.962 Z-5.724 F254
G1 X115.462 Y188.929 Z-5.704 F254
G1 X115.433 Y188.892 Z-5.685 F254
G1 X115.409 Y188.851 Z-5.666 F254
G1 X115.392 Y188.808 Z-5.647 F254
G1 X115.381 Y188.762 Z-5.627 F254
G1 X115.378 Y188.715 Z-5.608 F254
G1 Y188.714 F254
G1 X115.38 Y188.674 Z-5.592 F254
G1 X115.388 Y188.635 Z-5.575 F254
G1 X115.4 Y188.596 Z-5.559 F254
G3 X115.446 Y188.518 I0.295 J0.118 F254
G1 X115.542 Y188.395 F254
; MOVEMENT_LINK_DIRECT
G1 X116.744 Y186.873 F254
G3 X116.961 Y186.753 I0.249 J0.197 F254
; MOVEMENT_LEAD_IN
G1 X117.011 Y186.752 Z-5.579 F254
G1 X117.06 Y186.759 Z-5.599 F254
G1 X117.108 Y186.773 Z-5.62 F254
G1 X117.153 Y186.795 Z-5.64 F254
G1 X117.194 Y186.823 Z-5.66 F254
G1 X117.23 Y186.857 Z-5.681 F254
G1 X117.26 Y186.897 Z-5.701 F254
G1 X117.284 Y186.941 Z-5.721 F254
G1 X117.301 Y186.988 Z-5.742 F254
G1 X117.31 Y187.037 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X117.331 Y187.354 F254
G1 X117.333 Y187.433 F254
G1 X117.321 Y187.513 F254
G1 X117.182 Y188.229 F254
G1 X117.172 Y188.268 F254
G1 X117.157 Y188.306 F254
G1 X116.942 Y188.702 F254
G1 X116.92 Y188.742 F254
G1 X116.889 Y188.781 F254
G1 X116.88 Y188.79 F254
G1 X116.71 Y188.94 F254
G1 X116.636 Y188.998 F254
G1 X116.6 Y189.018 F254
G1 X116.563 Y189.032 F254
G1 X116.365 Y189.099 F254
G1 X116.335 Y189.107 F254
G1 X116.305 Y189.112 F254
G1 X116.246 Y189.114 F254
G1 X115.929 Y189.102 F254
G1 X115.857 Y189.099 F254
G1 X115.814 Y189.092 F254
G1 X115.77 Y189.078 F254
G1 X115.294 Y188.907 F254
G1 X115.136 Y188.847 F254
G1 X115.033 Y188.781 F254
G1 X114.343 Y188.305 F254
G1 X114.304 Y188.276 F254
G1 X114.264 Y188.24 F254
G1 X113.451 Y187.354 F254
G1 X113.418 Y187.312 F254
G1 X113.392 Y187.271 F254
G1 X113.258 Y187.042 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X113.359 Y186.628 I0.279 J-0.151 F254
G1 X113.397 Y186.614 Z-5.759 F254
G1 X113.435 Y186.6 Z-5.751 F254
G1 X113.472 Y186.587 Z-5.738 F254
G1 X113.506 Y186.575 Z-5.72 F254
G1 X113.537 Y186.573 Z-5.7 F254
G1 X113.573 Y186.581 Z-5.667 F254
G1 X113.604 Y186.587 Z-5.63 F254
G1 X113.629 Y186.592 Z-5.588 F254
G1 X113.647 Y186.596 Z-5.542 F254
G1 X113.658 Y186.598 Z-5.494 F254
G1 X113.662 Y186.599 Z-5.445 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X124.505 Y152.47 F254
G1 Z-2.54 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_RAMP_HELIX
G1 X124.563 Y152.52 Z-2.543 F25
G1 X124.616 Y152.576 Z-2.545 F25
G1 X124.664 Y152.636 Z-2.548 F25
G1 X124.706 Y152.701 Z-2.551 F25
G1 X124.741 Y152.77 Z-2.553 F25
G1 X124.77 Y152.841 Z-2.556 F25
G1 X124.792 Y152.915 Z-2.559 F25
G1 X124.807 Y152.991 Z-2.562 F25
G1 X124.814 Y153.067 Z-2.564 F25
G1 Y153.144 Z-2.567 F25
G1 X124.807 Y153.221 Z-2.57 F25
G1 X124.793 Y153.297 Z-2.572 F25
G1 X124.771 Y153.371 Z-2.575 F25
G1 X124.743 Y153.442 Z-2.578 F25
G1 X124.708 Y153.511 Z-2.58 F25
G1 X124.666 Y153.576 Z-2.583 F25
G1 X124.618 Y153.636 Z-2.586 F25
G1 X124.565 Y153.692 Z-2.588 F25
G1 X124.507 Y153.743 Z-2.591 F25
G1 X124.445 Y153.788 Z-2.594 F25
G1 X124.378 Y153.826 Z-2.597 F25
G1 X124.308 Y153.858 Z-2.599 F25
G1 X124.235 Y153.884 Z-2.602 F25
G1 X124.16 Y153.902 Z-2.605 F25
G1 X124.084 Y153.913 Z-2.607 F25
G1 X124.007 Y153.917 Z-2.61 F25
G1 X123.931 Y153.913 Z-2.613 F25
G1 X123.854 Y153.902 Z-2.615 F25
G1 X123.78 Y153.884 Z-2.618 F25
G1 X123.707 Y153.859 Z-2.621 F25
G1 X123.637 Y153.827 Z-2.623 F25
G1 X123.57 Y153.789 Z-2.626 F25
G1 X123.507 Y153.744 Z-2.629 F25
G1 X123.449 Y153.694 Z-2.632 F25
G1 X123.396 Y153.638 Z-2.634 F25
G1 X123.348 Y153.578 Z-2.637 F25
G1 X123.307 Y153.513 Z-2.64 F25
G1 X123.271 Y153.445 Z-2.642 F25
G1 X123.243 Y153.373 Z-2.645 F25
G1 X123.221 Y153.3 Z-2.648 F25
G1 X123.206 Y153.224 Z-2.65 F25
G1 X123.199 Y153.147 Z-2.653 F25
G1 Y153.071 Z-2.656 F25
G1 X123.206 Y152.994 Z-2.658 F25
G1 X123.221 Y152.919 Z-2.661 F25
G1 X123.242 Y152.845 Z-2.664 F25
G1 X123.271 Y152.773 Z-2.667 F25
G1 X123.306 Y152.705 Z-2.669 F25
G1 X123.348 Y152.64 Z-2.672 F25
G1 X123.395 Y152.58 Z-2.675 F25
G1 X123.448 Y152.524 Z-2.677 F25
G1 X123.506 Y152.474 Z-2.68 F25
G1 X123.569 Y152.429 Z-2.683 F25
G1 X123.635 Y152.391 Z-2.685 F25
G1 X123.705 Y152.359 Z-2.688 F25
G1 X123.778 Y152.334 Z-2.691 F25
G1 X123.853 Y152.316 Z-2.693 F25
G1 X123.929 Y152.305 Z-2.696 F25
G1 X124.005 Y152.301 Z-2.699 F25
G1 X124.082 Y152.305 Z-2.702 F25
G1 X124.158 Y152.316 Z-2.704 F25
G1 X124.233 Y152.334 Z-2.707 F25
G1 X124.306 Y152.359 Z-2.71 F25
G1 X124.375 Y152.391 Z-2.712 F25
G1 X124.442 Y152.429 Z-2.715 F25
G1 X124.504 Y152.474 Z-2.718 F25
G1 X124.562 Y152.524 Z-2.72 F25
G1 X124.615 Y152.58 Z-2.723 F25
G1 X124.663 Y152.64 Z-2.726 F25
G1 X124.704 Y152.705 Z-2.728 F25
G1 X124.739 Y152.773 Z-2.731 F25
G1 X124.768 Y152.844 Z-2.734 F25
G1 X124.789 Y152.918 Z-2.736 F25
G1 X124.804 Y152.993 Z-2.739 F25
G1 X124.811 Y153.07 Z-2.742 F25
G1 Y153.146 Z-2.745 F25
G1 X124.804 Y153.223 Z-2.747 F25
G1 X124.789 Y153.298 Z-2.75 F25
G1 X124.768 Y153.372 Z-2.753 F25
G1 X124.739 Y153.443 Z-2.755 F25
G1 X124.704 Y153.511 Z-2.758 F25
G1 X124.662 Y153.576 Z-2.761 F25
G1 X124.615 Y153.636 Z-2.763 F25
G1 X124.562 Y153.692 Z-2.766 F25
G1 X124.504 Y153.742 Z-2.769 F25
G1 X124.441 Y153.786 Z-2.771 F25
G1 X124.375 Y153.824 Z-2.774 F25
G1 X124.305 Y153.856 Z-2.777 F25
G1 X124.232 Y153.881 Z-2.78 F25
G1 X124.158 Y153.899 Z-2.782 F25
G1 X124.082 Y153.91 Z-2.785 F25
G1 X124.005 Y153.914 Z-2.788 F25
G1 X123.929 Y153.91 Z-2.79 F25
G1 X123.853 Y153.899 Z-2.793 F25
G1 X123.778 Y153.881 Z-2.796 F25
G1 X123.706 Y153.855 Z-2.798 F25
G1 X123.636 Y153.823 Z-2.801 F25
G1 X123.57 Y153.785 Z-2.804 F25
G1 X123.508 Y153.74 Z-2.806 F25
G1 X123.45 Y153.69 Z-2.809 F25
G1 X123.397 Y153.635 Z-2.812 F25
G1 X123.35 Y153.574 Z-2.815 F25
G1 X123.308 Y153.51 Z-2.817 F25
G1 X123.273 Y153.441 Z-2.82 F25
G1 X123.245 Y153.37 Z-2.823 F25
G1 X123.223 Y153.297 Z-2.825 F25
G1 X123.209 Y153.221 Z-2.828 F25
G1 X123.202 Y153.145 Z-2.831 F25
G1 Y153.069 Z-2.833 F25
G1 X123.21 Y152.992 Z-2.836 F25
G1 X123.224 Y152.917 Z-2.839 F25
G1 X123.246 Y152.844 Z-2.841 F25
G1 X123.275 Y152.773 Z-2.844 F25
G1 X123.31 Y152.705 Z-2.847 F25
G1 X123.351 Y152.64 Z-2.85 F25
G1 X123.399 Y152.58 Z-2.852 F25
G1 X123.452 Y152.525 Z-2.855 F25
G1 X123.51 Y152.475 Z-2.858 F25
G1 X123.572 Y152.431 Z-2.86 F25
G1 X123.639 Y152.393 Z-2.863 F25
G1 X123.708 Y152.361 Z-2.866 F25
G1 X123.781 Y152.336 Z-2.868 F25
G1 X123.855 Y152.318 Z-2.871 F25
G1 X123.931 Y152.308 Z-2.874 F25
G1 X124.008 Y152.304 Z-2.876 F25
G1 X124.084 Y152.308 Z-2.879 F25
G1 X124.16 Y152.319 Z-2.882 F25
G1 X124.234 Y152.337 Z-2.885 F25
G1 X124.306 Y152.363 Z-2.887 F25
G1 X124.376 Y152.395 Z-2.89 F25
G1 X124.442 Y152.433 Z-2.893 F25
G1 X124.504 Y152.478 Z-2.895 F25
G1 X124.562 Y152.528 Z-2.898 F25
G1 X124.614 Y152.583 Z-2.901 F25
G1 X124.661 Y152.644 Z-2.903 F25
G1 X124.703 Y152.708 Z-2.906 F25
G1 X124.737 Y152.776 Z-2.909 F25
G1 X124.766 Y152.847 Z-2.911 F25
G1 X124.787 Y152.921 Z-2.914 F25
G1 X124.801 Y152.996 Z-2.917 F25
G1 X124.808 Y153.072 Z-2.92 F25
G1 Y153.149 Z-2.922 F25
G1 X124.8 Y153.225 Z-2.925 F25
G1 X124.786 Y153.3 Z-2.928 F25
G1 X124.764 Y153.373 Z-2.93 F25
G1 X124.735 Y153.444 Z-2.933 F25
G1 X124.7 Y153.512 Z-2.936 F25
G1 X124.658 Y153.576 Z-2.938 F25
G1 X124.611 Y153.636 Z-2.941 F25
G1 X124.558 Y153.691 Z-2.944 F25
G1 X124.5 Y153.741 Z-2.946 F25
G1 X124.438 Y153.785 Z-2.949 F25
G1 X124.371 Y153.823 Z-2.952 F25
G1 X124.302 Y153.854 Z-2.955 F25
G1 X124.229 Y153.879 Z-2.957 F25
G1 X124.155 Y153.897 Z-2.96 F25
G1 X124.079 Y153.907 Z-2.963 F25
G1 X124.003 Y153.91 Z-2.965 F25
G1 X123.927 Y153.906 Z-2.968 F25
G1 X123.851 Y153.895 Z-2.971 F25
G1 X123.777 Y153.877 Z-2.973 F25
G1 X123.705 Y153.852 Z-2.976 F25
G1 X123.636 Y153.82 Z-2.979 F25
G1 X123.57 Y153.781 Z-2.981 F25
G1 X123.508 Y153.737 Z-2.984 F25
G1 X123.45 Y153.686 Z-2.987 F25
G1 X123.398 Y153.631 Z-2.99 F25
G1 X123.351 Y153.57 Z-2.992 F25
G1 X123.31 Y153.506 Z-2.995 F25
G1 X123.275 Y153.438 Z-2.998 F25
G1 X123.247 Y153.367 Z-3 F25
G1 X123.226 Y153.294 Z-3.003 F25
G1 X123.212 Y153.219 Z-3.006 F25
G1 X123.205 Y153.143 Z-3.008 F25
G1 Y153.067 Z-3.011 F25
G1 X123.213 Y152.991 Z-3.014 F25
G1 X123.228 Y152.916 Z-3.016 F25
G1 X123.25 Y152.843 Z-3.019 F25
G1 X123.278 Y152.772 Z-3.022 F25
G1 X123.314 Y152.704 Z-3.025 F25
G1 X123.355 Y152.64 Z-3.027 F25
G1 X123.403 Y152.581 Z-3.03 F25
G1 X123.456 Y152.526 Z-3.033 F25
G1 X123.514 Y152.476 Z-3.035 F25
G1 X123.576 Y152.432 Z-3.038 F25
G1 X123.642 Y152.394 Z-3.041 F25
G1 X123.712 Y152.363 Z-3.043 F25
G1 X123.784 Y152.338 Z-3.046 F25
G1 X123.858 Y152.321 Z-3.049 F25
G1 X123.934 Y152.31 Z-3.051 F25
G1 X124.01 Y152.307 Z-3.054 F25
G1 X124.086 Y152.311 Z-3.057 F25
G1 X124.161 Y152.323 Z-3.06 F25
G1 X124.235 Y152.341 Z-3.062 F25
G1 X124.307 Y152.366 Z-3.065 F25
G1 X124.376 Y152.398 Z-3.068 F25
G1 X124.442 Y152.437 Z-3.07 F25
G1 X124.504 Y152.481 Z-3.073 F25
G1 X124.561 Y152.532 Z-3.076 F25
G1 X124.613 Y152.587 Z-3.078 F25
G1 X124.66 Y152.647 Z-3.081 F25
G1 X124.701 Y152.712 Z-3.084 F25
G1 X124.736 Y152.78 Z-3.086 F25
G1 X124.763 Y152.85 Z-3.089 F25
G1 X124.784 Y152.924 Z-3.092 F25
G1 X124.798 Y152.999 Z-3.094 F25
G1 X124.805 Y153.074 Z-3.097 F25
G1 Y153.151 Z-3.1 F25
G1 X124.797 Y153.227 Z-3.103 F25
G1 X124.782 Y153.301 Z-3.105 F25
G1 X124.759 Y153.378 Z-3.108 F25
G1 X124.728 Y153.452 Z-3.111 F25
G1 X124.69 Y153.522 Z-3.114 F25
G1 X124.646 Y153.588 Z-3.117 F25
G1 X124.594 Y153.649 Z-3.119 F25
G1 X124.537 Y153.705 Z-3.122 F25
G1 X124.475 Y153.756 Z-3.125 F25
G1 X124.408 Y153.799 Z-3.128 F25
G1 X124.337 Y153.836 Z-3.131 F25
G1 X124.263 Y153.865 Z-3.134 F25
G1 X124.186 Y153.887 Z-3.136 F25
G1 X124.107 Y153.901 Z-3.139 F25
G1 X124.028 Y153.907 Z-3.142 F25
G1 X123.948 Y153.905 Z-3.145 F25
G1 X123.868 Y153.895 Z-3.148 F25
G1 X123.79 Y153.878 Z-3.15 F25
G1 X123.715 Y153.852 Z-3.153 F25
G1 X123.642 Y153.819 Z-3.156 F25
G1 X123.573 Y153.779 Z-3.159 F25
G1 X123.508 Y153.733 Z-3.162 F25
G1 X123.448 Y153.68 Z-3.165 F25
G1 X123.394 Y153.621 Z-3.167 F25
G1 X123.346 Y153.558 Z-3.17 F25
G1 X123.304 Y153.489 Z-3.173 F25
G1 X123.269 Y153.418 Z-3.176 F25
G1 X123.242 Y153.342 Z-3.179 F25
G1 X123.223 Y153.265 Z-3.182 F25
G1 X123.211 Y153.186 Z-3.184 F25
G1 X123.207 Y153.106 Z-3.187 F25
G1 X123.212 Y153.027 Z-3.19 F25
G1 X123.224 Y152.948 Z-3.193 F25
G1 X123.244 Y152.871 Z-3.196 F25
G1 X123.271 Y152.796 Z-3.199 F25
G1 X123.306 Y152.724 Z-3.201 F25
G1 X123.348 Y152.656 Z-3.204 F25
G1 X123.397 Y152.593 Z-3.207 F25
G1 X123.451 Y152.534 Z-3.21 F25
G1 X123.511 Y152.482 Z-3.213 F25
G1 X123.576 Y152.436 Z-3.215 F25
G1 X123.646 Y152.396 Z-3.218 F25
G1 X123.719 Y152.364 Z-3.221 F25
G1 X123.794 Y152.339 Z-3.224 F25
G1 X123.872 Y152.322 Z-3.227 F25
G1 X123.951 Y152.312 Z-3.23 F25
G1 X124.031 Y152.311 Z-3.232 F25
G1 X124.11 Y152.317 Z-3.235 F25
G1 X124.189 Y152.332 Z-3.238 F25
G1 X124.265 Y152.354 Z-3.241 F25
G1 X124.339 Y152.384 Z-3.244 F25
G1 X124.41 Y152.421 Z-3.247 F25
G1 X124.477 Y152.464 Z-3.249 F25
G1 X124.538 Y152.515 Z-3.252 F25
G1 X124.595 Y152.571 Z-3.255 F25
G1 X124.646 Y152.632 Z-3.258 F25
G1 X124.69 Y152.699 Z-3.261 F25
G1 X124.727 Y152.769 Z-3.264 F25
G1 X124.758 Y152.843 Z-3.266 F25
G1 X124.78 Y152.919 Z-3.269 F25
G1 X124.795 Y152.998 Z-3.272 F25
G1 X124.802 Y153.077 Z-3.275 F25
G1 X124.801 Y153.157 Z-3.278 F25
G1 X124.792 Y153.236 Z-3.28 F25
G1 X124.776 Y153.314 Z-3.283 F25
G1 X124.751 Y153.389 Z-3.286 F25
G1 X124.72 Y153.462 Z-3.289 F25
G1 X124.681 Y153.532 Z-3.292 F25
G1 X124.635 Y153.597 Z-3.295 F25
G1 X124.583 Y153.657 Z-3.297 F25
G1 X124.525 Y153.712 Z-3.3 F25
G1 X124.462 Y153.761 Z-3.303 F25
G1 X124.395 Y153.803 Z-3.306 F25
G1 X124.323 Y153.838 Z-3.309 F25
G1 X124.249 Y153.866 Z-3.312 F25
G1 X124.172 Y153.887 Z-3.314 F25
G1 X124.093 Y153.899 Z-3.317 F25
G1 X124.014 Y153.904 Z-3.32 F25
G1 X123.934 Y153.901 Z-3.323 F25
G1 X123.855 Y153.89 Z-3.326 F25
G1 X123.778 Y153.871 Z-3.329 F25
G1 X123.703 Y153.844 Z-3.331 F25
G1 X123.631 Y153.81 Z-3.334 F25
G1 X123.563 Y153.769 Z-3.337 F25
G1 X123.499 Y153.722 Z-3.34 F25
G1 X123.44 Y153.668 Z-3.343 F25
G1 X123.387 Y153.609 Z-3.345 F25
G1 X123.341 Y153.545 Z-3.348 F25
G1 X123.3 Y153.476 Z-3.351 F25
G1 X123.267 Y153.404 Z-3.354 F25
G1 X123.241 Y153.329 Z-3.357 F25
G1 X123.223 Y153.251 Z-3.36 F25
G1 X123.213 Y153.172 Z-3.362 F25
G1 X123.211 Y153.093 Z-3.365 F25
G1 X123.216 Y153.014 Z-3.368 F25
G1 X123.23 Y152.935 Z-3.371 F25
G1 X123.251 Y152.858 Z-3.374 F25
G1 X123.28 Y152.784 Z-3.377 F25
G1 X123.316 Y152.713 Z-3.379 F25
G1 X123.358 Y152.646 Z-3.382 F25
G1 X123.408 Y152.584 Z-3.385 F25
G1 X123.463 Y152.527 Z-3.388 F25
G1 X123.524 Y152.476 Z-3.391 F25
G1 X123.589 Y152.431 Z-3.394 F25
G1 X123.659 Y152.393 Z-3.396 F25
G1 X123.732 Y152.362 Z-3.399 F25
G1 X123.808 Y152.338 Z-3.402 F25
G1 X123.886 Y152.322 Z-3.405 F25
G1 X123.965 Y152.314 Z-3.408 F25
G1 X124.044 Z-3.411 F25
G1 X124.123 Y152.322 Z-3.413 F25
G1 X124.201 Y152.338 Z-3.416 F25
G1 X124.277 Y152.361 Z-3.419 F25
G1 X124.35 Y152.392 Z-3.422 F25
G1 X124.42 Y152.43 Z-3.425 F25
G1 X124.486 Y152.475 Z-3.427 F25
G1 X124.546 Y152.526 Z-3.43 F25
G1 X124.602 Y152.583 Z-3.433 F25
G1 X124.651 Y152.645 Z-3.436 F25
G1 X124.694 Y152.712 Z-3.439 F25
G1 X124.73 Y152.783 Z-3.442 F25
G1 X124.759 Y152.857 Z-3.444 F25
G1 X124.78 Y152.933 Z-3.447 F25
G1 X124.794 Y153.011 Z-3.45 F25
G1 X124.8 Y153.09 Z-3.453 F25
G1 X124.797 Y153.17 Z-3.456 F25
G1 X124.787 Y153.248 Z-3.459 F25
G1 X124.769 Y153.326 Z-3.461 F25
G1 X124.744 Y153.401 Z-3.464 F25
G1 X124.711 Y153.473 Z-3.467 F25
G1 X124.671 Y153.541 Z-3.47 F25
G1 X124.624 Y153.606 Z-3.473 F25
G1 X124.571 Y153.665 Z-3.476 F25
G1 X124.513 Y153.718 Z-3.478 F25
G1 X124.449 Y153.766 Z-3.481 F25
G1 X124.381 Y153.807 Z-3.484 F25
G1 X124.31 Y153.841 Z-3.487 F25
G1 X124.235 Y153.867 Z-3.49 F25
G1 X124.158 Y153.887 Z-3.492 F25
G1 X124.079 Y153.898 Z-3.495 F25
G1 X124 Y153.901 Z-3.498 F25
G1 X123.921 Y153.897 Z-3.501 F25
G1 X123.843 Y153.884 Z-3.504 F25
G1 X123.766 Y153.864 Z-3.507 F25
G1 X123.692 Y153.836 Z-3.509 F25
G1 X123.621 Y153.801 Z-3.512 F25
G1 X123.554 Y153.759 Z-3.515 F25
G1 X123.491 Y153.711 Z-3.518 F25
G1 X123.433 Y153.656 Z-3.521 F25
G1 X123.382 Y153.596 Z-3.524 F25
G1 X123.336 Y153.532 Z-3.526 F25
G1 X123.297 Y153.463 Z-3.529 F25
G1 X123.265 Y153.39 Z-3.532 F25
G1 X123.241 Y153.315 Z-3.535 F25
G1 X123.224 Y153.237 Z-3.538 F25
G1 X123.215 Y153.159 Z-3.541 F25
G1 X123.214 Y153.079 Z-3.543 F25
G1 X123.221 Y153 Z-3.546 F25
G1 X123.236 Y152.923 Z-3.549 F25
G1 X123.258 Y152.847 Z-3.552 F25
G1 X123.288 Y152.773 Z-3.555 F25
G1 X123.325 Y152.703 Z-3.557 F25
G1 X123.369 Y152.637 Z-3.56 F25
G1 X123.419 Y152.576 Z-3.563 F25
G1 X123.475 Y152.52 Z-3.566 F25
G1 X123.536 Y152.47 Z-3.569 F25
G1 X123.602 Y152.427 Z-3.572 F25
G1 X123.673 Y152.39 Z-3.574 F25
G1 X123.746 Y152.36 Z-3.577 F25
G1 X123.822 Y152.338 Z-3.58 F25
G1 X123.9 Y152.324 Z-3.583 F25
G1 X123.978 Y152.317 Z-3.586 F25
G1 X124.058 Y152.318 Z-3.589 F25
G1 X124.136 Y152.327 Z-3.591 F25
G1 X124.213 Y152.344 Z-3.594 F25
G1 X124.289 Y152.369 Z-3.597 F25
G1 X124.361 Y152.401 Z-3.6 F25
G1 X124.43 Y152.44 Z-3.603 F25
G1 X124.494 Y152.486 Z-3.606 F25
G1 X124.554 Y152.538 Z-3.608 F25
G1 X124.608 Y152.595 Z-3.611 F25
G1 X124.657 Y152.658 Z-3.614 F25
G1 X124.698 Y152.725 Z-3.617 F25
G1 X124.733 Y152.796 Z-3.62 F25
G1 X124.76 Y152.87 Z-3.622 F25
G1 X124.78 Y152.947 Z-3.625 F25
G1 X124.792 Y153.025 Z-3.628 F25
G1 X124.797 Y153.104 Z-3.631 F25
G1 X124.793 Y153.183 Z-3.634 F25
G1 X124.782 Y153.261 Z-3.637 F25
G1 X124.762 Y153.338 Z-3.639 F25
G1 X124.736 Y153.412 Z-3.642 F25
G1 X124.702 Y153.483 Z-3.645 F25
G1 X124.661 Y153.551 Z-3.648 F25
G1 X124.613 Y153.614 Z-3.651 F25
G1 X124.559 Y153.672 Z-3.654 F25
G1 X124.5 Y153.725 Z-3.656 F25
G1 X124.436 Y153.771 Z-3.659 F25
G1 X124.368 Y153.81 Z-3.662 F25
G1 X124.296 Y153.843 Z-3.665 F25
G1 X124.221 Y153.868 Z-3.668 F25
G1 X124.144 Y153.886 Z-3.671 F25
G1 X124.066 Y153.896 Z-3.673 F25
G1 X123.987 Y153.898 Z-3.676 F25
G1 X123.908 Y153.892 Z-3.679 F25
G1 X123.83 Y153.878 Z-3.682 F25
G1 X123.754 Y153.857 Z-3.685 F25
G1 X123.681 Y153.828 Z-3.687 F25
G1 X123.611 Y153.792 Z-3.69 F25
G1 X123.544 Y153.749 Z-3.693 F25
G1 X123.483 Y153.7 Z-3.696 F25
G1 X123.426 Y153.644 Z-3.699 F25
G1 X123.376 Y153.584 Z-3.702 F25
G1 X123.331 Y153.519 Z-3.704 F25
G1 X123.294 Y153.449 Z-3.707 F25
G1 X123.263 Y153.376 Z-3.71 F25
G1 X123.24 Y153.301 Z-3.713 F25
G1 X123.225 Y153.223 Z-3.716 F25
G1 X123.217 Y153.145 Z-3.719 F25
G1 X123.218 Y153.066 Z-3.721 F25
G1 X123.226 Y152.987 Z-3.724 F25
G1 X123.242 Y152.91 Z-3.727 F25
G1 X123.266 Y152.835 Z-3.73 F25
G1 X123.297 Y152.762 Z-3.733 F25
G1 X123.335 Y152.693 Z-3.736 F25
G1 X123.379 Y152.628 Z-3.738 F25
G1 X123.43 Y152.568 Z-3.741 F25
G1 X123.487 Y152.514 Z-3.744 F25
G1 X123.549 Y152.465 Z-3.747 F25
G1 X123.616 Y152.423 Z-3.75 F25
G1 X123.686 Y152.387 Z-3.752 F25
G1 X123.76 Y152.359 Z-3.755 F25
G1 X123.836 Y152.338 Z-3.758 F25
G1 X123.913 Y152.325 Z-3.761 F25
G1 X123.992 Y152.32 Z-3.764 F25
G1 X124.071 Y152.322 Z-3.767 F25
G1 X124.149 Y152.333 Z-3.769 F25
G1 X124.226 Y152.351 Z-3.772 F25
G1 X124.3 Y152.377 Z-3.775 F25
G1 X124.372 Y152.41 Z-3.778 F25
G1 X124.44 Y152.45 Z-3.781 F25
G1 X124.503 Y152.497 Z-3.784 F25
G1 X124.562 Y152.549 Z-3.786 F25
G1 X124.615 Y152.608 Z-3.789 F25
G1 X124.661 Y152.671 Z-3.792 F25
G1 X124.702 Y152.739 Z-3.795 F25
G1 X124.735 Y152.81 Z-3.798 F25
G1 X124.761 Y152.884 Z-3.801 F25
G1 X124.78 Y152.961 Z-3.803 F25
G1 X124.791 Y153.039 Z-3.806 F25
G1 X124.793 Y153.117 Z-3.809 F25
G1 X124.789 Y153.196 Z-3.812 F25
G1 X124.776 Y153.274 Z-3.815 F25
G1 X124.755 Y153.35 Z-3.817 F25
G1 X124.727 Y153.423 Z-3.82 F25
G1 X124.692 Y153.494 Z-3.823 F25
G1 X124.65 Y153.56 Z-3.826 F25
G1 X124.602 Y153.622 Z-3.829 F25
G1 X124.548 Y153.679 Z-3.832 F25
G1 X124.488 Y153.731 Z-3.834 F25
G1 X124.423 Y153.776 Z-3.837 F25
G1 X124.354 Y153.814 Z-3.84 F25
G1 X124.282 Y153.845 Z-3.843 F25
G1 X124.207 Y153.869 Z-3.846 F25
G1 X124.13 Y153.885 Z-3.849 F25
G1 X124.052 Y153.894 Z-3.851 F25
G1 X123.974 Z-3.854 F25
G1 X123.895 Y153.887 Z-3.857 F25
G1 X123.818 Y153.872 Z-3.86 F25
G1 X123.743 Y153.85 Z-3.863 F25
G1 X123.67 Y153.819 Z-3.866 F25
G1 X123.601 Y153.782 Z-3.868 F25
G1 X123.535 Y153.738 Z-3.871 F25
G1 X123.475 Y153.688 Z-3.874 F25
G1 X123.42 Y153.632 Z-3.877 F25
G1 X123.37 Y153.571 Z-3.88 F25
G1 X123.327 Y153.505 Z-3.882 F25
G1 X123.291 Y153.436 Z-3.885 F25
G1 X123.262 Y153.363 Z-3.888 F25
G1 X123.24 Y153.287 Z-3.891 F25
G1 X123.226 Y153.21 Z-3.894 F25
G1 X123.22 Y153.131 Z-3.897 F25
G1 X123.222 Y153.053 Z-3.899 F25
G1 X123.231 Y152.975 Z-3.902 F25
G1 X123.248 Y152.898 Z-3.905 F25
G1 X123.273 Y152.824 Z-3.908 F25
G1 X123.305 Y152.752 Z-3.911 F25
G1 X123.344 Y152.684 Z-3.914 F25
G1 X123.39 Y152.62 Z-3.916 F25
G1 X123.442 Y152.561 Z-3.919 F25
G1 X123.499 Y152.507 Z-3.922 F25
G1 X123.562 Y152.46 Z-3.925 F25
G1 X123.629 Y152.419 Z-3.928 F25
G1 X123.7 Y152.385 Z-3.931 F25
G1 X123.773 Y152.358 Z-3.933 F25
G1 X123.849 Y152.338 Z-3.936 F25
G1 X123.927 Y152.327 Z-3.939 F25
G1 X124.006 Y152.323 Z-3.942 F25
G1 X124.084 Y152.327 Z-3.945 F25
G1 X124.162 Y152.338 Z-3.948 F25
G1 X124.238 Y152.358 Z-3.95 F25
G1 X124.312 Y152.385 Z-3.953 F25
G1 X124.382 Y152.419 Z-3.956 F25
G1 X124.449 Y152.46 Z-3.959 F25
G1 X124.511 Y152.507 Z-3.962 F25
G1 X124.569 Y152.561 Z-3.964 F25
G1 X124.621 Y152.62 Z-3.967 F25
G1 X124.666 Y152.684 Z-3.97 F25
G1 X124.705 Y152.752 Z-3.973 F25
G1 X124.737 Y152.823 Z-3.976 F25
G1 X124.762 Y152.898 Z-3.979 F25
G1 X124.779 Y152.974 Z-3.981 F25
G1 X124.788 Y153.052 Z-3.984 F25
G1 X124.79 Y153.131 Z-3.987 F25
G1 X124.784 Y153.209 Z-3.99 F25
G1 X124.77 Y153.286 Z-3.993 F25
G1 X124.748 Y153.361 Z-3.996 F25
G1 X124.719 Y153.434 Z-3.998 F25
G1 X124.683 Y153.504 Z-4.001 F25
G1 X124.64 Y153.569 Z-4.004 F25
G1 X124.591 Y153.63 Z-4.007 F25
G1 X124.536 Y153.686 Z-4.01 F25
G1 X124.475 Y153.736 Z-4.013 F25
G1 X124.41 Y153.78 Z-4.015 F25
G1 X124.341 Y153.817 Z-4.018 F25
G1 X124.269 Y153.847 Z-4.021 F25
G1 X124.194 Y153.869 Z-4.024 F25
G1 X124.117 Y153.884 Z-4.027 F25
G1 X124.039 Y153.891 Z-4.029 F25
G1 X123.96 Z-4.032 F25
G1 X123.882 Y153.882 Z-4.035 F25
G1 X123.806 Y153.866 Z-4.038 F25
G1 X123.731 Y153.842 Z-4.041 F25
G1 X123.659 Y153.811 Z-4.044 F25
G1 X123.591 Y153.773 Z-4.046 F25
G1 X123.527 Y153.728 Z-4.049 F25
G1 X123.467 Y153.677 Z-4.052 F25
G1 X123.413 Y153.62 Z-4.055 F25
G1 X123.365 Y153.558 Z-4.058 F25
G1 X123.323 Y153.492 Z-4.061 F25
G1 X123.288 Y153.422 Z-4.063 F25
G1 X123.261 Y153.349 Z-4.066 F25
G1 X123.24 Y153.273 Z-4.069 F25
G1 X123.228 Y153.196 Z-4.072 F25
G1 X123.223 Y153.118 Z-4.075 F25
G1 X123.226 Y153.04 Z-4.078 F25
G1 X123.237 Y152.962 Z-4.08 F25
G1 X123.255 Y152.886 Z-4.083 F25
G1 X123.281 Y152.812 Z-4.086 F25
G1 X123.314 Y152.741 Z-4.089 F25
G1 X123.354 Y152.674 Z-4.092 F25
G1 X123.401 Y152.611 Z-4.094 F25
G1 X123.454 Y152.554 Z-4.097 F25
G1 X123.512 Y152.501 Z-4.1 F25
G1 X123.575 Y152.455 Z-4.103 F25
G1 X123.642 Y152.415 Z-4.106 F25
G1 X123.713 Y152.382 Z-4.109 F25
G1 X123.787 Y152.357 Z-4.111 F25
G1 X123.863 Y152.339 Z-4.114 F25
G1 X123.941 Y152.329 Z-4.117 F25
G1 X124.019 Y152.326 Z-4.12 F25
G1 X124.097 Y152.331 Z-4.123 F25
G1 X124.174 Y152.344 Z-4.126 F25
G1 X124.25 Y152.365 Z-4.128 F25
G1 X124.322 Y152.393 Z-4.131 F25
G1 X124.392 Y152.428 Z-4.134 F25
G1 X124.458 Y152.47 Z-4.137 F25
G1 X124.519 Y152.518 Z-4.14 F25
G1 X124.576 Y152.573 Z-4.143 F25
G1 X124.626 Y152.632 Z-4.145 F25
G1 X124.671 Y152.697 Z-4.148 F25
G1 X124.708 Y152.765 Z-4.151 F25
G1 X124.739 Y152.837 Z-4.154 F25
G1 X124.762 Y152.912 Z-4.157 F25
G1 X124.778 Y152.988 Z-4.159 F25
G1 X124.786 Y153.066 Z-4.162 F25
G1 Y153.144 Z-4.165 F25
G1 X124.779 Y153.222 Z-4.168 F25
G1 X124.764 Y153.298 Z-4.171 F25
G1 X124.741 Y153.373 Z-4.174 F25
G1 X124.711 Y153.445 Z-4.176 F25
G1 X124.673 Y153.514 Z-4.179 F25
G1 X124.63 Y153.578 Z-4.182 F25
G1 X124.579 Y153.638 Z-4.185 F25
G1 X124.524 Y153.693 Z-4.188 F25
G1 X124.463 Y153.742 Z-4.191 F25
G1 X124.397 Y153.784 Z-4.193 F25
G1 X124.328 Y153.82 Z-4.196 F25
G1 X124.255 Y153.848 Z-4.199 F25
G1 X124.18 Y153.869 Z-4.202 F25
G1 X124.103 Y153.883 Z-4.205 F25
G1 X124.025 Y153.889 Z-4.208 F25
G1 X123.947 Y153.887 Z-4.21 F25
G1 X123.87 Y153.877 Z-4.213 F25
G1 X123.794 Y153.859 Z-4.216 F25
G1 X123.72 Y153.834 Z-4.219 F25
G1 X123.649 Y153.802 Z-4.222 F25
G1 X123.581 Y153.763 Z-4.224 F25
G1 X123.518 Y153.717 Z-4.227 F25
G1 X123.46 Y153.665 Z-4.23 F25
G1 X123.407 Y153.608 Z-4.233 F25
G1 X123.36 Y153.546 Z-4.236 F25
G1 X123.319 Y153.479 Z-4.239 F25
G1 X123.286 Y153.409 Z-4.241 F25
G1 X123.26 Y153.335 Z-4.244 F25
G1 X123.241 Y153.26 Z-4.247 F25
G1 X123.229 Y153.182 Z-4.25 F25
G1 X123.226 Y153.105 Z-4.253 F25
G1 X123.23 Y153.027 Z-4.256 F25
G1 X123.242 Y152.95 Z-4.258 F25
G1 X123.262 Y152.874 Z-4.261 F25
G1 X123.289 Y152.801 Z-4.264 F25
G1 X123.323 Y152.731 Z-4.267 F25
G1 X123.364 Y152.665 Z-4.27 F25
G1 X123.412 Y152.603 Z-4.273 F25
G1 X123.465 Y152.546 Z-4.275 F25
G1 X123.524 Y152.495 Z-4.278 F25
G1 X123.588 Y152.45 Z-4.281 F25
G1 X123.656 Y152.412 Z-4.284 F25
G1 X123.727 Y152.38 Z-4.287 F25
G1 X123.801 Y152.356 Z-4.289 F25
G1 X123.877 Y152.34 Z-4.292 F25
G1 X123.954 Y152.331 Z-4.295 F25
G1 X124.032 Y152.329 Z-4.298 F25
G1 X124.11 Y152.336 Z-4.301 F25
G1 X124.186 Y152.35 Z-4.304 F25
G1 X124.261 Y152.372 Z-4.306 F25
G1 X124.333 Y152.401 Z-4.309 F25
G1 X124.402 Y152.437 Z-4.312 F25
G1 X124.467 Y152.48 Z-4.315 F25
G1 X124.527 Y152.53 Z-4.318 F25
G1 X124.582 Y152.585 Z-4.321 F25
G1 X124.632 Y152.645 Z-4.323 F25
G1 X124.675 Y152.71 Z-4.326 F25
G1 X124.711 Y152.778 Z-4.329 F25
G1 X124.741 Y152.851 Z-4.332 F25
G1 X124.763 Y152.925 Z-4.335 F25
G1 X124.777 Y153.002 Z-4.338 F25
G1 X124.784 Y153.079 Z-4.34 F25
G1 X124.783 Y153.157 Z-4.343 F25
G1 X124.774 Y153.234 Z-4.346 F25
G1 X124.757 Y153.311 Z-4.349 F25
G1 X124.733 Y153.385 Z-4.352 F25
G1 X124.702 Y153.456 Z-4.354 F25
G1 X124.664 Y153.523 Z-4.357 F25
G1 X124.619 Y153.587 Z-4.36 F25
G1 X124.568 Y153.646 Z-4.363 F25
G1 X124.512 Y153.699 Z-4.366 F25
G1 X124.45 Y153.747 Z-4.369 F25
G1 X124.384 Y153.788 Z-4.371 F25
G1 X124.314 Y153.822 Z-4.374 F25
G1 X124.242 Y153.849 Z-4.377 F25
G1 X124.166 Y153.869 Z-4.38 F25
G1 X124.09 Y153.881 Z-4.383 F25
G1 X124.012 Y153.886 Z-4.386 F25
G1 X123.934 Y153.882 Z-4.388 F25
G1 X123.857 Y153.871 Z-4.391 F25
G1 X123.782 Y153.853 Z-4.394 F25
G1 X123.709 Y153.826 Z-4.397 F25
G1 X123.638 Y153.793 Z-4.4 F25
G1 X123.572 Y153.753 Z-4.403 F25
G1 X123.51 Y153.706 Z-4.405 F25
G1 X123.452 Y153.654 Z-4.408 F25
G1 X123.401 Y153.596 Z-4.411 F25
G1 X123.355 Y153.533 Z-4.414 F25
G1 X123.316 Y153.466 Z-4.417 F25
G1 X123.284 Y153.395 Z-4.419 F25
G1 X123.259 Y153.322 Z-4.422 F25
G1 X123.241 Y153.246 Z-4.425 F25
G1 X123.231 Y153.169 Z-4.428 F25
G1 X123.229 Y153.091 Z-4.431 F25
G1 X123.235 Y153.014 Z-4.434 F25
G1 X123.248 Y152.937 Z-4.436 F25
G1 X123.269 Y152.863 Z-4.439 F25
G1 X123.297 Y152.79 Z-4.442 F25
G1 X123.333 Y152.721 Z-4.445 F25
G1 X123.375 Y152.656 Z-4.448 F25
G1 X123.423 Y152.595 Z-4.451 F25
G1 X123.477 Y152.54 Z-4.453 F25
G1 X123.537 Y152.49 Z-4.456 F25
G1 X123.601 Y152.446 Z-4.459 F25
G1 X123.669 Y152.409 Z-4.462 F25
G1 X123.74 Y152.379 Z-4.465 F25
G1 X123.814 Y152.356 Z-4.468 F25
G1 X123.89 Y152.341 Z-4.47 F25
G1 X123.968 Y152.333 Z-4.473 F25
G1 X124.045 Z-4.476 F25
G1 X124.122 Y152.341 Z-4.479 F25
G1 X124.198 Y152.356 Z-4.482 F25
G1 X124.272 Y152.379 Z-4.485 F25
G1 X124.344 Y152.41 Z-4.487 F25
G1 X124.412 Y152.447 Z-4.49 F25
G1 X124.476 Y152.491 Z-4.493 F25
G1 X124.535 Y152.541 Z-4.496 F25
G1 X124.589 Y152.597 Z-4.499 F25
G1 X124.637 Y152.657 Z-4.501 F25
G1 X124.679 Y152.723 Z-4.504 F25
G1 X124.714 Y152.792 Z-4.507 F25
G1 X124.742 Y152.864 Z-4.51 F25
G1 X124.763 Y152.939 Z-4.513 F25
G1 X124.776 Y153.015 Z-4.516 F25
G1 X124.781 Y153.093 Z-4.518 F25
G1 X124.779 Y153.17 Z-4.521 F25
G1 X124.769 Y153.247 Z-4.524 F25
G1 X124.751 Y153.322 Z-4.527 F25
G1 X124.726 Y153.396 Z-4.53 F25
G1 X124.693 Y153.466 Z-4.533 F25
G1 X124.654 Y153.533 Z-4.535 F25
G1 X124.608 Y153.595 Z-4.538 F25
G1 X124.557 Y153.653 Z-4.541 F25
G1 X124.5 Y153.705 Z-4.544 F25
G1 X124.437 Y153.752 Z-4.547 F25
G1 X124.371 Y153.791 Z-4.55 F25
G1 X124.301 Y153.824 Z-4.552 F25
G1 X124.228 Y153.85 Z-4.555 F25
G1 X124.153 Y153.869 Z-4.558 F25
G1 X124.076 Y153.879 Z-4.561 F25
G1 X123.999 Y153.882 Z-4.564 F25
G1 X123.921 Y153.878 Z-4.566 F25
G1 X123.845 Y153.866 Z-4.569 F25
G1 X123.77 Y153.846 Z-4.572 F25
G1 X123.698 Y153.818 Z-4.575 F25
G1 X123.628 Y153.784 Z-4.578 F25
G1 X123.563 Y153.743 Z-4.581 F25
G1 X123.502 Y153.695 Z-4.583 F25
G1 X123.445 Y153.642 Z-4.586 F25
G1 X123.395 Y153.584 Z-4.589 F25
G1 X123.351 Y153.52 Z-4.592 F25
G1 X123.313 Y153.453 Z-4.595 F25
G1 X123.282 Y153.382 Z-4.598 F25
G1 X123.258 Y153.308 Z-4.6 F25
G1 X123.242 Y153.233 Z-4.603 F25
G1 X123.234 Y153.156 Z-4.606 F25
G1 X123.233 Y153.078 Z-4.609 F25
G1 X123.24 Y153.001 Z-4.612 F25
G1 X123.254 Y152.925 Z-4.615 F25
G1 X123.276 Y152.851 Z-4.617 F25
G1 X123.306 Y152.78 Z-4.62 F25
G1 X123.342 Y152.711 Z-4.623 F25
G1 X123.385 Y152.647 Z-4.626 F25
G1 X123.434 Y152.587 Z-4.629 F25
G1 X123.489 Y152.533 Z-4.631 F25
G1 X123.549 Y152.484 Z-4.634 F25
G1 X123.614 Y152.442 Z-4.637 F25
G1 X123.682 Y152.406 Z-4.64 F25
G1 X123.754 Y152.377 Z-4.643 F25
G1 X123.828 Y152.356 Z-4.646 F25
G1 X123.904 Y152.342 Z-4.648 F25
G1 X123.981 Y152.335 Z-4.651 F25
G1 X124.058 Y152.337 Z-4.654 F25
G1 X124.135 Y152.346 Z-4.657 F25
G1 X124.21 Y152.363 Z-4.66 F25
G1 X124.284 Y152.387 Z-4.663 F25
G1 X124.354 Y152.418 Z-4.665 F25
G1 X124.421 Y152.457 Z-4.668 F25
G1 X124.484 Y152.501 Z-4.671 F25
G1 X124.542 Y152.552 Z-4.674 F25
G1 X124.595 Y152.609 Z-4.677 F25
G1 X124.642 Y152.67 Z-4.68 F25
G1 X124.683 Y152.736 Z-4.682 F25
G1 X124.716 Y152.805 Z-4.685 F25
G1 X124.743 Y152.878 Z-4.688 F25
G1 X124.762 Y152.953 Z-4.691 F25
G1 X124.774 Y153.029 Z-4.694 F25
G1 X124.778 Y153.106 Z-4.696 F25
G1 X124.774 Y153.183 Z-4.699 F25
G1 X124.763 Y153.259 Z-4.702 F25
G1 X124.744 Y153.334 Z-4.705 F25
G1 X124.718 Y153.407 Z-4.708 F25
G1 X124.684 Y153.476 Z-4.711 F25
G1 X124.644 Y153.542 Z-4.713 F25
G1 X124.598 Y153.604 Z-4.716 F25
G1 X124.545 Y153.66 Z-4.719 F25
G1 X124.487 Y153.711 Z-4.722 F25
G1 X124.425 Y153.756 Z-4.725 F25
G1 X124.358 Y153.795 Z-4.728 F25
G1 X124.288 Y153.826 Z-4.73 F25
G1 X124.214 Y153.851 Z-4.733 F25
G1 X124.139 Y153.868 Z-4.736 F25
G1 X124.063 Y153.877 Z-4.739 F25
G1 X123.985 Y153.879 Z-4.742 F25
G1 X123.908 Y153.873 Z-4.745 F25
G1 X123.833 Y153.86 Z-4.747 F25
G1 X123.759 Y153.839 Z-4.75 F25
G1 X123.687 Y153.81 Z-4.753 F25
G1 X123.618 Y153.775 Z-4.756 F25
G1 X123.554 Y153.733 Z-4.759 F25
G1 X123.494 Y153.685 Z-4.761 F25
G1 X123.439 Y153.631 Z-4.764 F25
G1 X123.39 Y153.571 Z-4.767 F25
G1 X123.346 Y153.507 Z-4.77 F25
G1 X123.31 Y153.44 Z-4.773 F25
G1 X123.28 Y153.368 Z-4.776 F25
G1 X123.258 Y153.295 Z-4.778 F25
G1 X123.243 Y153.219 Z-4.781 F25
G1 X123.236 Y153.142 Z-4.784 F25
G1 Y153.065 Z-4.787 F25
G1 X123.245 Y152.989 Z-4.79 F25
G1 X123.26 Y152.913 Z-4.793 F25
G1 X123.284 Y152.84 Z-4.795 F25
G1 X123.314 Y152.769 Z-4.798 F25
G1 X123.351 Y152.702 Z-4.801 F25
G1 X123.395 Y152.638 Z-4.804 F25
G1 X123.445 Y152.58 Z-4.807 F25
G1 X123.501 Y152.527 Z-4.81 F25
G1 X123.561 Y152.479 Z-4.812 F25
G1 X123.626 Y152.438 Z-4.815 F25
G1 X123.695 Y152.403 Z-4.818 F25
G1 X123.767 Y152.376 Z-4.821 F25
G1 X123.841 Y152.356 Z-4.824 F25
G1 X123.917 Y152.343 Z-4.826 F25
G1 X123.994 Y152.338 Z-4.829 F25
G1 X124.071 Y152.341 Z-4.832 F25
G1 X124.147 Y152.351 Z-4.835 F25
G1 X124.222 Y152.369 Z-4.838 F25
G1 X124.295 Y152.395 Z-4.841 F25
G1 X124.365 Y152.427 Z-4.843 F25
G1 X124.431 Y152.466 Z-4.846 F25
G1 X124.493 Y152.512 Z-4.849 F25
G1 X124.55 Y152.564 Z-4.852 F25
G1 X124.601 Y152.621 Z-4.855 F25
G1 X124.647 Y152.683 Z-4.858 F25
G1 X124.686 Y152.749 Z-4.86 F25
G1 X124.719 Y152.819 Z-4.863 F25
G1 X124.744 Y152.891 Z-4.866 F25
G1 X124.762 Y152.966 Z-4.869 F25
G1 X124.772 Y153.042 Z-4.872 F25
G1 X124.775 Y153.119 Z-4.875 F25
G1 X124.77 Y153.196 Z-4.877 F25
G1 X124.757 Y153.271 Z-4.88 F25
G1 X124.737 Y153.346 Z-4.883 F25
G1 X124.71 Y153.417 Z-4.886 F25
G1 X124.675 Y153.486 Z-4.889 F25
G1 X124.634 Y153.551 Z-4.891 F25
G1 X124.587 Y153.611 Z-4.894 F25
G1 X124.534 Y153.667 Z-4.897 F25
G1 X124.475 Y153.717 Z-4.9 F25
G1 X124.412 Y153.761 Z-4.903 F25
G1 X124.345 Y153.798 Z-4.906 F25
G1 X124.274 Y153.828 Z-4.908 F25
G1 X124.201 Y153.851 Z-4.911 F25
G1 X124.126 Y153.867 Z-4.914 F25
G1 X124.049 Y153.875 Z-4.917 F25
G1 X123.972 Y153.876 Z-4.92 F25
G1 X123.896 Y153.868 Z-4.923 F25
G1 X123.821 Y153.854 Z-4.925 F25
G1 X123.747 Y153.831 Z-4.928 F25
G1 X123.676 Y153.802 Z-4.931 F25
G1 X123.609 Y153.766 Z-4.934 F25
G1 X123.545 Y153.723 Z-4.937 F25
G1 X123.486 Y153.673 Z-4.94 F25
G1 X123.432 Y153.619 Z-4.942 F25
G1 X123.384 Y153.559 Z-4.945 F25
G1 X123.342 Y153.495 Z-4.948 F25
G1 X123.307 Y153.426 Z-4.951 F25
G1 X123.279 Y153.355 Z-4.954 F25
G1 X123.258 Y153.281 Z-4.957 F25
G1 X123.245 Y153.206 Z-4.959 F25
G1 X123.239 Y153.129 Z-4.962 F25
G1 X123.24 Y153.052 Z-4.965 F25
G1 X123.25 Y152.976 Z-4.968 F25
G1 X123.267 Y152.901 Z-4.971 F25
G1 X123.291 Y152.829 Z-4.973 F25
G1 X123.323 Y152.759 Z-4.976 F25
G1 X123.361 Y152.692 Z-4.979 F25
G1 X123.406 Y152.63 Z-4.982 F25
G1 X123.456 Y152.573 Z-4.985 F25
G1 X123.513 Y152.52 Z-4.988 F25
G1 X123.574 Y152.474 Z-4.99 F25
G1 X123.639 Y152.434 Z-4.993 F25
G1 X123.708 Y152.401 Z-4.996 F25
G1 X123.781 Y152.375 Z-4.999 F25
G1 X123.855 Y152.356 Z-5.002 F25
G1 X123.931 Y152.345 Z-5.005 F25
G1 X124.007 Y152.341 Z-5.007 F25
G1 X124.084 Y152.345 Z-5.01 F25
G1 X124.16 Y152.357 Z-5.013 F25
G1 X124.234 Y152.376 Z-5.016 F25
G1 X124.306 Y152.403 Z-5.019 F25
G1 X124.375 Y152.436 Z-5.022 F25
G1 X124.44 Y152.476 Z-5.024 F25
G1 X124.501 Y152.523 Z-5.027 F25
G1 X124.557 Y152.575 Z-5.03 F25
G1 X124.607 Y152.633 Z-5.033 F25
G1 X124.651 Y152.695 Z-5.036 F25
G1 X124.689 Y152.762 Z-5.038 F25
G1 X124.721 Y152.832 Z-5.041 F25
G1 X124.744 Y152.905 Z-5.044 F25
G1 X124.761 Y152.979 Z-5.047 F25
G1 X124.77 Y153.055 Z-5.05 F25
G1 X124.771 Y153.132 Z-5.053 F25
G1 X124.765 Y153.208 Z-5.055 F25
G1 X124.751 Y153.283 Z-5.058 F25
G1 X124.73 Y153.357 Z-5.061 F25
G1 X124.702 Y153.428 Z-5.064 F25
G1 X124.666 Y153.496 Z-5.067 F25
G1 X124.624 Y153.56 Z-5.07 F25
G1 X124.576 Y153.619 Z-5.072 F25
G1 X124.522 Y153.674 Z-5.075 F25
G1 X124.463 Y153.722 Z-5.078 F25
G1 X124.399 Y153.765 Z-5.081 F25
G1 X124.331 Y153.801 Z-5.084 F25
G1 X124.261 Y153.83 Z-5.087 F25
G1 X124.187 Y153.852 Z-5.089 F25
G1 X124.112 Y153.866 Z-5.092 F25
G1 X124.036 Y153.873 Z-5.095 F25
G1 X123.96 Y153.872 Z-5.098 F25
G1 X123.884 Y153.863 Z-5.101 F25
G1 X123.809 Y153.847 Z-5.103 F25
G1 X123.736 Y153.824 Z-5.106 F25
G1 X123.666 Y153.793 Z-5.109 F25
G1 X123.599 Y153.756 Z-5.112 F25
G1 X123.537 Y153.712 Z-5.115 F25
G1 X123.479 Y153.662 Z-5.118 F25
G1 X123.426 Y153.607 Z-5.12 F25
G1 X123.379 Y153.546 Z-5.123 F25
G1 X123.339 Y153.482 Z-5.126 F25
G1 X123.305 Y153.413 Z-5.129 F25
G1 X123.278 Y153.341 Z-5.132 F25
G1 X123.258 Y153.268 Z-5.135 F25
G1 X123.246 Y153.192 Z-5.137 F25
G1 X123.241 Y153.116 Z-5.14 F25
G1 X123.245 Y153.039 Z-5.143 F25
G1 X123.255 Y152.964 Z-5.146 F25
G1 X123.273 Y152.89 Z-5.149 F25
G1 X123.299 Y152.818 Z-5.152 F25
G1 X123.331 Y152.749 Z-5.154 F25
G1 X123.371 Y152.683 Z-5.157 F25
G1 X123.416 Y152.622 Z-5.16 F25
G1 X123.468 Y152.566 Z-5.163 F25
G1 X123.525 Y152.515 Z-5.166 F25
G1 X123.586 Y152.47 Z-5.168 F25
G1 X123.652 Y152.431 Z-5.171 F25
G1 X123.722 Y152.399 Z-5.174 F25
G1 X123.794 Y152.374 Z-5.177 F25
G1 X123.868 Y152.357 Z-5.18 F25
G1 X123.944 Y152.347 Z-5.183 F25
G1 X124.02 Y152.345 Z-5.185 F25
G1 X124.097 Y152.35 Z-5.188 F25
G1 X124.172 Y152.363 Z-5.191 F25
G1 X124.245 Y152.383 Z-5.194 F25
G1 X124.317 Y152.411 Z-5.197 F25
G1 X124.385 Y152.445 Z-5.2 F25
G1 X124.449 Y152.486 Z-5.202 F25
G1 X124.509 Y152.534 Z-5.205 F25
G1 X124.563 Y152.587 Z-5.208 F25
G1 X124.613 Y152.645 Z-5.211 F25
G1 X124.656 Y152.708 Z-5.214 F25
G1 X124.692 Y152.775 Z-5.217 F25
G1 X124.722 Y152.845 Z-5.219 F25
G1 X124.745 Y152.918 Z-5.222 F25
G1 X124.76 Y152.993 Z-5.225 F25
G1 X124.768 Y153.068 Z-5.228 F25
G1 Y153.145 Z-5.231 F25
G1 X124.76 Y153.221 Z-5.233 F25
G1 X124.745 Y153.295 Z-5.236 F25
G1 X124.723 Y153.368 Z-5.239 F25
G1 X124.693 Y153.439 Z-5.242 F25
G1 X124.657 Y153.506 Z-5.245 F25
G1 X124.614 Y153.569 Z-5.248 F25
G1 X124.565 Y153.627 Z-5.25 F25
G1 X124.51 Y153.68 Z-5.253 F25
G1 X124.45 Y153.728 Z-5.256 F25
G1 X124.386 Y153.769 Z-5.259 F25
G1 X124.318 Y153.803 Z-5.262 F25
G1 X124.247 Y153.831 Z-5.265 F25
G1 X124.174 Y153.852 Z-5.267 F25
G1 X124.099 Y153.865 Z-5.27 F25
G1 X124.023 Y153.87 Z-5.273 F25
G1 X123.947 Y153.868 Z-5.276 F25
G1 X123.871 Y153.858 Z-5.279 F25
G1 X123.797 Y153.841 Z-5.282 F25
G1 X123.725 Y153.816 Z-5.284 F25
G1 X123.656 Y153.785 Z-5.287 F25
G1 X123.59 Y153.746 Z-5.29 F25
G1 X123.528 Y153.702 Z-5.293 F25
G1 X123.472 Y153.651 Z-5.296 F25
G1 X123.42 Y153.595 Z-5.298 F25
G1 X123.374 Y153.534 Z-5.301 F25
G1 X123.335 Y153.469 Z-5.304 F25
G1 X123.302 Y153.4 Z-5.307 F25
G1 X123.277 Y153.328 Z-5.31 F25
G1 X123.259 Y153.254 Z-5.313 F25
G1 X123.248 Y153.179 Z-5.315 F25
G1 X123.244 Y153.103 Z-5.318 F25
G1 X123.249 Y153.027 Z-5.321 F25
G1 X123.261 Y152.952 Z-5.324 F25
G1 X123.28 Y152.878 Z-5.327 F25
G1 X123.307 Y152.807 Z-5.33 F25
G1 X123.34 Y152.739 Z-5.332 F25
G1 X123.381 Y152.674 Z-5.335 F25
G1 X123.427 Y152.614 Z-5.338 F25
G1 X123.479 Y152.559 Z-5.341 F25
G1 X123.537 Y152.509 Z-5.344 F25
G1 X123.599 Y152.465 Z-5.347 F25
G1 X123.665 Y152.428 Z-5.349 F25
G1 X123.735 Y152.397 Z-5.352 F25
G1 X123.807 Y152.374 Z-5.355 F25
G1 X123.882 Y152.358 Z-5.358 F25
G1 X123.957 Y152.349 Z-5.361 F25
G1 X124.033 Y152.348 Z-5.363 F25
G1 X124.109 Y152.355 Z-5.366 F25
G1 X124.184 Y152.369 Z-5.369 F25
G1 X124.257 Y152.39 Z-5.372 F25
G1 X124.327 Y152.419 Z-5.375 F25
G1 X124.394 Y152.454 Z-5.378 F25
G1 X124.457 Y152.496 Z-5.38 F25
G1 X124.516 Y152.545 Z-5.383 F25
G1 X124.57 Y152.598 Z-5.386 F25
G1 X124.618 Y152.657 Z-5.389 F25
G1 X124.66 Y152.721 Z-5.392 F25
G1 X124.695 Y152.788 Z-5.395 F25
G1 X124.724 Y152.858 Z-5.397 F25
G1 X124.745 Y152.931 Z-5.4 F25
G1 X124.759 Y153.006 Z-5.403 F25
G1 X124.765 Y153.082 Z-5.406 F25
G1 X124.764 Y153.158 Z-5.409 F25
G1 X124.755 Y153.233 Z-5.412 F25
G1 X124.739 Y153.307 Z-5.414 F25
G1 X124.715 Y153.379 Z-5.417 F25
G1 X124.685 Y153.449 Z-5.42 F25
G1 X124.647 Y153.515 Z-5.423 F25
G1 X124.603 Y153.577 Z-5.426 F25
G1 X124.553 Y153.634 Z-5.428 F25
G1 X124.498 Y153.686 Z-5.431 F25
G1 X124.438 Y153.732 Z-5.434 F25
G1 X124.374 Y153.772 Z-5.437 F25
G1 X124.305 Y153.806 Z-5.44 F25
G1 X124.234 Y153.832 Z-5.443 F25
G1 X124.161 Y153.851 Z-5.445 F25
G1 X124.086 Y153.863 Z-5.448 F25
G1 X124.01 Y153.867 Z-5.451 F25
G1 X123.934 Y153.864 Z-5.454 F25
G1 X123.859 Y153.853 Z-5.457 F25
G1 X123.786 Y153.834 Z-5.46 F25
G1 X123.714 Y153.809 Z-5.462 F25
G1 X123.646 Y153.776 Z-5.465 F25
G1 X123.581 Y153.737 Z-5.468 F25
G1 X123.52 Y153.691 Z-5.471 F25
G1 X123.464 Y153.639 Z-5.474 F25
G1 X123.414 Y153.583 Z-5.477 F25
G1 X123.37 Y153.521 Z-5.479 F25
G1 X123.332 Y153.456 Z-5.482 F25
G1 X123.3 Y153.387 Z-5.485 F25
G1 X123.276 Y153.315 Z-5.488 F25
G1 X123.259 Y153.241 Z-5.491 F25
G1 X123.25 Y153.166 Z-5.493 F25
G1 X123.248 Y153.09 Z-5.496 F25
G1 X123.253 Y153.015 Z-5.499 F25
G1 X123.267 Y152.94 Z-5.502 F25
G1 X123.287 Y152.867 Z-5.505 F25
G1 X123.315 Y152.796 Z-5.508 F25
G1 X123.349 Y152.729 Z-5.51 F25
G1 X123.391 Y152.665 Z-5.513 F25
G1 X123.438 Y152.606 Z-5.516 F25
G1 X123.491 Y152.552 Z-5.519 F25
G1 X123.549 Y152.503 Z-5.522 F25
G1 X123.612 Y152.461 Z-5.525 F25
G1 X123.678 Y152.425 Z-5.527 F25
G1 X123.748 Y152.396 Z-5.53 F25
G1 X123.821 Y152.373 Z-5.533 F25
G1 X123.895 Y152.359 Z-5.536 F25
G1 X123.97 Y152.351 Z-5.539 F25
G1 X124.046 Y152.352 Z-5.542 F25
G1 X124.121 Y152.36 Z-5.544 F25
G1 X124.195 Y152.375 Z-5.547 F25
G1 X124.268 Y152.397 Z-5.55 F25
G1 X124.337 Y152.427 Z-5.553 F25
G1 X124.404 Y152.464 Z-5.556 F25
G1 X124.466 Y152.507 Z-5.559 F25
G1 X124.524 Y152.556 Z-5.561 F25
G1 X124.576 Y152.61 Z-5.564 F25
G1 X124.623 Y152.67 Z-5.567 F25
G1 X124.664 Y152.733 Z-5.57 F25
G1 X124.698 Y152.801 Z-5.573 F25
G1 X124.725 Y152.872 Z-5.575 F25
G1 X124.745 Y152.945 Z-5.578 F25
G1 X124.757 Y153.019 Z-5.581 F25
G1 X124.762 Y153.095 Z-5.584 F25
G1 X124.76 Y153.17 Z-5.587 F25
G1 X124.75 Y153.245 Z-5.59 F25
G1 X124.732 Y153.319 Z-5.592 F25
G1 X124.708 Y153.39 Z-5.595 F25
G1 X124.676 Y153.459 Z-5.598 F25
G1 X124.638 Y153.524 Z-5.601 F25
G1 X124.593 Y153.585 Z-5.604 F25
G1 X124.542 Y153.641 Z-5.607 F25
G1 X124.486 Y153.692 Z-5.609 F25
G1 X124.426 Y153.737 Z-5.612 F25
G1 X124.361 Y153.776 Z-5.615 F25
G1 X124.292 Y153.808 Z-5.618 F25
G1 X124.221 Y153.833 Z-5.621 F25
G1 X124.148 Y153.851 Z-5.624 F25
G1 X124.073 Y153.861 Z-5.626 F25
G1 X123.997 Y153.864 Z-5.629 F25
G1 X123.922 Y153.859 Z-5.632 F25
G1 X123.847 Y153.847 Z-5.635 F25
G1 X123.774 Y153.827 Z-5.638 F25
G1 X123.703 Y153.801 Z-5.64 F25
G1 X123.636 Y153.767 Z-5.643 F25
G1 X123.572 Y153.727 Z-5.646 F25
G1 X123.512 Y153.68 Z-5.649 F25
G1 X123.458 Y153.628 Z-5.652 F25
G1 X123.409 Y153.571 Z-5.655 F25
G1 X123.365 Y153.509 Z-5.657 F25
G1 X123.329 Y153.443 Z-5.66 F25
G1 X123.299 Y153.374 Z-5.663 F25
G1 X123.276 Y153.302 Z-5.666 F25
G1 X123.26 Y153.228 Z-5.669 F25
G1 X123.252 Y153.153 Z-5.672 F25
G1 X123.251 Y153.077 Z-5.674 F25
G1 X123.258 Y153.002 Z-5.677 F25
G1 X123.273 Y152.928 Z-5.68 F25
G1 X123.294 Y152.856 Z-5.683 F25
G1 X123.323 Y152.786 Z-5.686 F25
G1 X123.359 Y152.719 Z-5.689 F25
G1 X123.401 Y152.657 Z-5.691 F25
G1 X123.449 Y152.599 Z-5.694 F25
G1 X123.503 Y152.546 Z-5.697 F25
G1 X123.561 Y152.498 Z-5.7 F25
G1 X123.625 Y152.457 Z-5.703 F25
G1 X123.691 Y152.422 Z-5.705 F25
G1 X123.762 Y152.394 Z-5.708 F25
G1 X123.834 Y152.373 Z-5.711 F25
G1 X123.908 Y152.36 Z-5.714 F25
G1 X123.983 Y152.354 Z-5.717 F25
G1 X124.059 Y152.356 Z-5.72 F25
G1 X124.133 Y152.365 Z-5.722 F25
G1 X124.207 Y152.381 Z-5.725 F25
G1 X124.279 Y152.405 Z-5.728 F25
G1 X124.347 Y152.436 Z-5.731 F25
G1 X124.413 Y152.473 Z-5.734 F25
G1 X124.474 Y152.517 Z-5.737 F25
G1 X124.531 Y152.567 Z-5.739 F25
G1 X124.582 Y152.622 Z-5.742 F25
G1 X124.628 Y152.682 Z-5.745 F25
G1 X124.667 Y152.746 Z-5.748 F25
G1 X124.7 Y152.814 Z-5.751 F25
G1 X124.726 Y152.885 Z-5.754 F25
G1 X124.744 Y152.958 Z-5.756 F25
G1 X124.756 Y153.032 Z-5.759 F25
G1 X124.759 Y153.108 Z-5.762 F25
G3 X123.251 I-0.754 F25
G3 X124.759 I0.754 F25
; MOVEMENT_CUTTING
G1 X124.797 Y153.618 F254
G1 X124.794 Y153.638 F254
G1 X124.786 Y153.657 F254
G1 X124.772 Y153.672 F254
G1 X124.648 Y153.781 F254
G1 X124.49 Y153.922 F254
G1 X124.331 Y154.07 F254
G1 X124.308 Y154.092 F254
G1 X124.273 Y154.127 F254
G1 X124.248 Y154.151 F254
G1 X124.134 Y154.252 F254
G1 X123.981 Y154.281 F254
G1 X123.827 Y154.252 F254
G1 X123.694 Y154.169 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X123.66 Y154.131 Z-5.741 F254
G1 X123.632 Y154.088 Z-5.72 F254
G1 X123.609 Y154.043 Z-5.7 F254
G1 X123.591 Y153.995 Z-5.679 F254
G1 X123.58 Y153.945 Z-5.658 F254
G1 X123.575 Y153.895 Z-5.637 F254
G1 X123.577 Y153.847 Z-5.618 F254
G1 X123.584 Y153.799 Z-5.598 F254
G1 X123.597 Y153.753 Z-5.578 F254
G1 X123.616 Y153.708 Z-5.559 F254
G3 X124.304 Y153.689 I0.35 J0.174 F254
; MOVEMENT_LEAD_IN
G1 X124.328 Y153.739 Z-5.581 F254
G1 X124.345 Y153.791 Z-5.604 F254
G1 X124.354 Y153.846 Z-5.627 F254
G1 X124.355 Y153.901 Z-5.649 F254
G1 X124.348 Y153.956 Z-5.672 F254
G1 X124.334 Y154.01 Z-5.694 F254
G1 X124.312 Y154.061 Z-5.717 F254
G1 X124.284 Y154.108 Z-5.739 F254
G1 X124.248 Y154.151 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X124.172 Y154.225 F254
G1 X124.133 Y154.255 F254
G1 X124.093 Y154.277 F254
G1 X124.054 Y154.292 F254
G1 X124.014 Y154.302 F254
G1 X123.974 Y154.306 F254
G1 X123.935 Y154.305 F254
G1 X123.895 Y154.299 F254
G1 X123.855 Y154.288 F254
G1 X123.824 Y154.275 F254
G1 X123.792 Y154.258 F254
G1 X123.761 Y154.235 F254
G1 X123.729 Y154.206 F254
G1 X123.697 Y154.171 F254
G1 X123.538 Y154.024 F254
G1 X123.378 Y153.889 F254
G1 X123.221 Y153.763 F254
G1 X123.178 Y153.73 F254
G1 X123.156 Y153.712 F254
G1 X123.134 Y153.691 F254
G1 X123.102 Y153.651 F254
G1 X123.08 Y153.611 F254
G1 X123.063 Y153.567 F254
G1 X123.054 Y153.529 F254
G1 X123.049 Y153.49 F254
G1 X123.05 Y153.452 F254
G1 X123.063 Y153.336 F254
G1 X123.069 Y153.254 F254
G1 X123.076 Y153.096 F254
G1 X123.068 Y152.937 F254
G1 X123.063 Y152.883 F254
G1 X123.047 Y152.779 F254
G1 X123.039 Y152.731 F254
G1 X123.034 Y152.697 F254
G1 X123.032 Y152.678 F254
G1 X123.034 Y152.574 F254
G1 X123.063 Y152.475 F254
G1 X123.117 Y152.387 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X123.157 Y152.355 Z-5.741 F254
G1 X123.202 Y152.329 Z-5.72 F254
G1 X123.25 Y152.31 Z-5.699 F254
G1 X123.3 Y152.297 Z-5.678 F254
G1 X123.351 Y152.292 Z-5.657 F254
G1 X123.402 Y152.295 Z-5.636 F254
G1 X123.453 Y152.305 Z-5.615 F254
G1 X123.496 Y152.319 Z-5.596 F254
G1 X123.537 Y152.34 Z-5.577 F254
G1 X123.575 Y152.366 Z-5.559 F254
G3 X123.4 Y152.967 I-0.21 J0.265 F254
; MOVEMENT_LEAD_IN
G1 X123.35 Y152.968 Z-5.579 F254
G1 X123.3 Y152.963 Z-5.599 F254
G1 X123.252 Y152.949 Z-5.62 F254
G1 X123.207 Y152.929 Z-5.64 F254
G1 X123.165 Y152.903 Z-5.66 F254
G1 X123.127 Y152.87 Z-5.681 F254
G1 X123.094 Y152.833 Z-5.701 F254
G1 X123.067 Y152.791 Z-5.721 F254
G1 X123.047 Y152.745 Z-5.742 F254
G1 X123.034 Y152.697 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X123.021 Y152.62 F254
G1 X123.023 Y152.58 F254
G1 X123.031 Y152.541 F254
G1 X123.044 Y152.501 F254
G1 X123.063 Y152.461 F254
G1 X123.097 Y152.412 F254
G1 X123.117 Y152.387 F254
G1 X123.142 Y152.363 F254
G1 X123.182 Y152.333 F254
G1 X123.221 Y152.311 F254
G1 X123.241 Y152.303 F254
G1 X123.276 Y152.292 F254
G1 X123.38 Y152.272 F254
G1 X123.697 Y152.215 F254
G1 X124.172 Y152.137 F254
G1 X124.331 Y152.119 F254
G1 X124.483 Y152.111 F254
G1 X124.634 Y152.13 F254
G1 X124.779 Y152.179 F254
G1 X124.913 Y152.251 F254
G1 X124.976 Y152.299 F254
G1 X125.139 Y152.469 F254
G1 X125.242 Y152.68 F254
G1 X125.276 Y152.913 F254
G1 X125.238 Y153.145 F254
G1 X125.131 Y153.355 F254
G1 X124.965 Y153.522 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X124.922 Y153.547 Z-5.742 F254
G1 X124.875 Y153.564 Z-5.721 F254
G1 X124.827 Y153.575 Z-5.701 F254
G1 X124.777 Y153.577 Z-5.681 F254
G1 X124.727 Y153.572 Z-5.66 F254
G1 X124.679 Y153.559 Z-5.64 F254
G1 X124.634 Y153.539 Z-5.62 F254
G1 X124.592 Y153.511 Z-5.599 F254
G1 X124.555 Y153.478 Z-5.579 F254
G1 X124.524 Y153.439 Z-5.559 F254
G3 X124.501 Y153.4 I0.262 J-0.18 F254
G1 X124.412 Y153.219 F254
; MOVEMENT_LINK_DIRECT
G1 X124.158 Y152.706 F254
; MOVEMENT_LEAD_IN
G1 X124.093 Y152.573 F254
G3 X124.064 Y152.479 I0.285 J-0.14 F254
G1 X124.06 Y152.429 Z-5.579 F254
G1 X124.065 Y152.38 Z-5.599 F254
G1 X124.077 Y152.332 Z-5.62 F254
G1 X124.096 Y152.286 Z-5.64 F254
G1 X124.123 Y152.244 Z-5.66 F254
G1 X124.155 Y152.206 Z-5.681 F254
G1 X124.194 Y152.174 Z-5.701 F254
G1 X124.236 Y152.148 Z-5.721 F254
G1 X124.282 Y152.13 Z-5.742 F254
G1 X124.331 Y152.119 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X124.648 Y152.086 F254
G1 X124.807 Y152.077 F254
G1 X125.052 Y152.092 F254
G1 X125.204 Y152.108 F254
G1 X125.382 Y152.198 F254
G1 X125.526 Y152.336 F254
G1 X125.623 Y152.511 F254
G1 X125.664 Y152.707 F254
G1 X125.646 Y152.905 F254
G1 X125.57 Y153.09 F254
G1 X125.443 Y153.244 F254
G1 X125.276 Y153.354 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X125.236 Y153.368 Z-5.745 F254
G1 X125.195 Y153.376 Z-5.728 F254
G1 X125.153 Y153.379 Z-5.711 F254
G1 X125.107 Y153.375 Z-5.692 F254
G1 X125.061 Y153.365 Z-5.673 F254
G1 X125.018 Y153.348 Z-5.654 F254
G1 X124.977 Y153.326 Z-5.635 F254
G1 X124.941 Y153.297 Z-5.616 F254
G1 X124.908 Y153.264 Z-5.597 F254
G1 X124.881 Y153.226 Z-5.578 F254
G1 X124.86 Y153.184 Z-5.559 F254
G3 X124.84 Y153.113 I0.293 J-0.123 F254
G1 X124.811 Y152.942 F254
; MOVEMENT_LINK_DIRECT
G1 X124.762 Y152.645 F254
; MOVEMENT_LEAD_IN
G1 X124.731 Y152.461 F254
G3 X124.727 Y152.401 I0.313 J-0.052 F254
G1 X124.732 Y152.352 Z-5.579 F254
G1 X124.745 Y152.303 Z-5.599 F254
G1 X124.765 Y152.258 Z-5.62 F254
G1 X124.792 Y152.216 Z-5.64 F254
G1 X124.826 Y152.179 Z-5.66 F254
G1 X124.864 Y152.148 Z-5.681 F254
G1 X124.907 Y152.123 Z-5.701 F254
G1 X124.954 Y152.105 Z-5.721 F254
G1 X125.003 Y152.094 Z-5.742 F254
G1 X125.052 Y152.092 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X125.282 Y152.105 F254
G1 X125.361 Y152.113 F254
G1 X125.647 Y152.185 F254
G1 X125.793 Y152.229 F254
G1 X125.934 Y152.376 F254
G1 X126.014 Y152.562 F254
G1 X126.021 Y152.765 F254
G1 X125.956 Y152.958 F254
G1 X125.827 Y153.114 F254
G1 X125.65 Y153.214 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X125.596 Y153.227 Z-5.739 F254
G1 X125.541 Y153.234 Z-5.717 F254
G1 X125.486 Y153.233 Z-5.694 F254
G1 X125.431 Y153.227 Z-5.672 F254
G1 X125.377 Y153.214 Z-5.649 F254
G1 X125.325 Y153.194 Z-5.627 F254
G1 X125.275 Y153.17 Z-5.604 F254
G1 X125.228 Y153.14 Z-5.581 F254
G1 X125.185 Y153.106 Z-5.559 F254
G3 X125.182 Y152.306 I0.35 J-0.401 F254
; MOVEMENT_LEAD_IN
G1 X125.231 Y152.268 Z-5.584 F254
G1 X125.285 Y152.236 Z-5.61 F254
G1 X125.341 Y152.209 Z-5.635 F254
G1 X125.4 Y152.19 Z-5.66 F254
G1 X125.461 Y152.178 Z-5.686 F254
G1 X125.523 Y152.173 Z-5.711 F254
G1 X125.586 Y152.175 Z-5.737 F254
G1 X125.647 Y152.185 Z-5.762 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X125.916 Y152.253 F254
G1 X126.054 Y152.303 F254
G1 X126.194 Y152.363 F254
G1 X126.287 Y152.486 F254
G1 X126.331 Y152.634 F254
G1 X126.32 Y152.788 F254
G1 X126.256 Y152.928 F254
G1 X126.147 Y153.037 F254
G1 X126.007 Y153.101 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X125.788 Y153.087 I-0.085 J-0.392 F254
G3 X126.054 Y152.303 I0.138 J-0.39 F254
; param: axial-engagement = 0.13425199687480927
; MOVEMENT_CUTTING
G1 X126.233 Y152.369 F254
G1 X126.36 Y152.421 F254
G1 X126.392 Y152.434 F254
G1 X126.438 Y152.461 F254
G1 X126.475 Y152.492 F254
G1 X126.495 Y152.513 F254
G1 X126.511 Y152.535 F254
G1 X126.534 Y152.571 F254
G1 X126.55 Y152.608 F254
G1 X126.555 Y152.62 F254
G1 X126.565 Y152.66 F254
G1 X126.57 Y152.699 F254
G1 Y152.739 F254
G1 X126.565 Y152.779 F254
G1 X126.55 Y152.832 F254
G1 X126.539 Y152.858 F254
G1 X126.525 Y152.884 F254
G1 X126.487 Y152.937 F254
G1 X126.466 Y152.961 F254
G1 X126.439 Y152.985 F254
G1 X126.416 Y153.003 F254
G1 X126.392 Y153.017 F254
G1 X126.352 Y153.035 F254
G1 X126.313 Y153.048 F254
G1 X126.233 Y153.059 F254
G1 X126.075 Y153.084 F254
G1 X125.916 Y153.124 F254
G1 X125.758 Y153.177 F254
G1 X125.441 Y153.286 F254
G1 X125.282 Y153.351 F254
G1 X125.148 Y153.413 F254
G1 X124.965 Y153.522 F254
G1 X124.897 Y153.572 F254
G1 X124.807 Y153.642 F254
G1 X124.772 Y153.672 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X124.262 Y153.356 I-0.2 J-0.247 F254
G1 X124.273 Y153.308 Z-5.758 F254
G1 X124.284 Y153.26 Z-5.746 F254
G1 X124.294 Y153.215 Z-5.727 F254
G1 X124.303 Y153.174 Z-5.701 F254
G1 X124.312 Y153.137 Z-5.669 F254
G1 X124.319 Y153.105 Z-5.631 F254
G1 X124.325 Y153.08 Z-5.589 F254
G1 X124.329 Y153.061 Z-5.543 F254
G1 X124.331 Y153.05 Z-5.494 F254
G1 X124.332 Y153.046 Z-5.444 F254
; MOVEMENT_CUTTING
G1 Z15.24 F254
; *** SECTION end ***
;
; *** STOP begin ***
M400
; COMMAND_COOLANT_OFF
; ---- Coolant: Off cur: Off A: Off B: Off
G0 X0 Y0 F4470
; COMMAND_STOP_SPINDLE
M300 S300 P3000
M0 Turn OFF spindle
M117 Job end
; *** STOP end ***
