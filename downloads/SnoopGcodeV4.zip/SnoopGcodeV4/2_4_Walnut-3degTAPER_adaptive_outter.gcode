; parseSafeZProperty: safeZMode = 'Retract'
; parseSafeZProperty: safeZHeightDefault = 15
; param: product-id = fusion360
;Fusion CAM 2602.1.25
; Posts processor: MPCNC v3.0 Beta 1.cps
; Gcode generated: Sun Aug 10 03:26:59 2025 GMT
; param: hostname = Harrisons-MacBook-Air.local
; param: username = harrisonesterly
; Document: snoop2 v16
; param: document-id = cdd3c627-a981-4b59-b2d6-a8cf2a6a6479
; param: model-version = 1b7ac768-0c1f-4280-92ec-74a9411570f3
; param: leads-supported = 1
; Setup: Setup4
; param: machine-id = 1
; param: machine-v2 = {
   "controller" : {
      "default" : {
         "head_info_part_id" : "head",
         "max_block_processing_speed" : 118,
         "max_normal_speed" : 4000.0000000000005,
         "non_tcp_rapid_interpolation_mode" : "Unsynchronized",
         "parts" : {
            "X" : {
               "coordinate" : 0,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Y" : {
               "coordinate" : 1,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Z" : {
               "coordinate" : 2,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            }
         },
         "table_part_id" : "table",
         "tcp_rapid_interpolation_mode" : "ToolTip"
      }
   },
   "general" : {
      "capabilities" : [ "milling" ],
      "description" : "Generic 3-axis",
      "minimumRevision" : 45805,
      "vendor" : "MP_CNC"
   },
   "interactions" : {
      "default" : {
         "pairs" : [
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            }
         ]
      }
   },
   "kinematics" : {
      "default" : {
         "conventions" : {
            "rotation" : "right-handed"
         },
         "parts" : [
            {
               "control" : "driven",
               "direction" : [ -1, 0, 0 ],
               "id" : "X",
               "max" : 289.99999999999994,
               "min" : 289.99999999999994,
               "name" : "X",
               "parts" : [
                  {
                     "control" : "driven",
                     "direction" : [ 0, -1, 0 ],
                     "id" : "Y",
                     "name" : "Y",
                     "parts" : [
                        {
                           "control" : "driven",
                           "direction" : [ 0, 0, -1 ],
                           "id" : "Z",
                           "max" : 0,
                           "min" : 0,
                           "name" : "Z",
                           "parts" : [
                              {
                                 "attach_frame" : {
                                    "point" : [ 0, 0, 0 ],
                                    "x_direction" : [ 1, 0, 0 ],
                                    "z_direction" : [ 0, 0, 1 ]
                                 },
                                 "display_name" : "table",
                                 "id" : "table",
                                 "type" : "table"
                              }
                           ],
                           "type" : "linear"
                        }
                     ],
                     "type" : "linear"
                  }
               ],
               "type" : "linear"
            },
            {
               "attach_frame" : {
                  "point" : [ 0, 0, 0 ],
                  "x_direction" : [ 1, 0, 0 ],
                  "z_direction" : [ 0, 0, 1 ]
               },
               "display_name" : "head",
               "id" : "head",
               "spindle" : {
                  "max_speed" : 0,
                  "min_speed" : 0
               },
               "tool_station" : {
                  "coolants" : null,
                  "max_tool_diameter" : 0,
                  "max_tool_length" : 0
               },
               "type" : "head"
            }
         ],
         "units" : {
            "angle" : "degrees",
            "length" : "mm"
         }
      }
   },
   "machining" : {
      "default" : {
         "feedrate_ratio" : 1,
         "tool_change_time" : 15
      }
   },
   "post" : {
      "default" : {
         "output_folder" : "/Users/harrisonesterly/Desktop/LIFE/Projects/MPCNC/fusion_GCode",
         "path" : "user://MPCNC.cps"
      }
   },
   "tooling" : {
      "default" : {
         "has_tool_changer" : false,
         "number_of_tools" : 100,
         "supports_tool_preload" : true
      }
   }
}


; param: stock-type = box
; param: stock = 0, 0, -26.496, 109.982, 150.241, 0
; param: stock-lower-x = 0
; param: stock-lower-y = 0
; param: stock-lower-z = -26.496
; param: stock-upper-x = 109.98200000000008
; param: stock-upper-y = 150.24076554149076
; param: stock-upper-z = 0
; param: part-lower-x = 1.0160000000000196
; param: part-lower-y = 1.016
; param: part-lower-z = -26.496
; param: part-upper-x = 108.96600000000007
; param: part-upper-y = 149.22476554149077
; param: part-upper-z = -1.016
; param: areBothSpindlesGrabbed = 0
; param: notes = 
; param: operation-strategy = adaptive2d
; param: autodeskcam:operation-id = 73
; param: leads-supported = 1
; param: autodeskcam:path = Setups\Setup4\2D Adaptive7 4
; param: operation:is2DStrategy = 1
; param: operation:is3DStrategy = 0
; param: operation:isRoughingStrategy = 1
; param: operation:isFinishingStrategy = 0
; param: operation:isMillingStrategy = 1
; param: operation:isTurningStrategy = 0
; param: operation:isJetStrategy = 0
; param: operation:isAdditiveStrategy = 0
; param: operation:isProbingStrategy = 0
; param: operation:isInspectionStrategy = 0
; param: operation:isDrillingStrategy = 0
; param: operation:isHoleMillingStrategy = 0
; param: operation:isThreadStrategy = 0
; param: operation:isSamplingStrategy = 0
; param: operation:isRotaryStrategy = 1
; param: operation:isSubspindleStrategy = 0
; param: operation:isSurfaceStrategy = 0
; param: operation:isCheckSurfaceStrategy = 0
; param: operation:isMultiAxisStrategy = 0
; param: operation:advancedMode = 0
; param: operation:betaMode = 0
; param: operation:alphaMode = 0
; param: operation:isXpress = 0
; param: operation:licenseMultiaxis = 1
; param: operation:license3D = 1
; param: operation:metric = 0
; param: operation:isAssemblyDocument = 1
; param: operation:context = operation
; param: operation:strategy = adaptive2d
; param: operation:operation_description = 2D Adaptive
; param: operation:tool_type = tapered mill
; param: operation:undercut = 0
; param: operation:tool_isTurning = 0
; param: operation:tool_isMill = 1
; param: operation:tool_isDrill = 0
; param: operation:tool_isJet = 0
; param: operation:tool_isDepositing = 0
; param: operation:tool_taperedType = tapered_bull_nose
; param: operation:tool_unit = millimeters
; param: operation:tool_number = 1
; param: operation:tool_diameterOffset = 1
; param: operation:tool_lengthOffset = 1
; param: operation:tool_compensationOffset = 1
; param: operation:tool_turret = 0
; param: operation:tool_manualToolChange = 0
; param: operation:tool_breakControl = 0
; param: operation:tool_live = 1
; param: operation:tool_material = carbide
; param: operation:tool_description = 46473 CNC 2D and 3D Carving 6.2 Deg Tapered Angle Ball Tip x 0.5mm Dia x 0.25mm Radius x 26.5mm x 6mm Shank x 75mm Long x 3 Flute Up-Cut Spiral Solid Carbide ZrN Coated
; param: operation:tool_comment = 
; param: operation:tool_vendor = Amana Tool
; param: operation:tool_productId = 46473
; param: operation:tool_productLink = https://www.amanatool.com/46473-cnc-2d-and-3d-carving-6-2-deg-tapered-angle-ball-tip-x-0-5mm-dia-x-0-25mm-radius-x-26-5mm-x-6mm-shank-x-75mm-long-x-3-flute-up-cut-spiral-solid-carbide-zrn-coated.html
; param: operation:tool_diameter = 0.5
; param: operation:tool_maximumCuttingDiameter = 0
; param: operation:tool_tipDiameter = 0
; param: operation:tool_tipOffset = 0
; param: operation:tool_cornerRadius = 0.25
; param: operation:tool_inclusiveAngle = 0
; param: operation:tool_taperAngle = 6.2
; param: operation:tool_tipAngle = 0
; param: operation:tool_threadTipType = point
; param: operation:tool_threadTipWidth = 0
; param: operation:tool_threadTipRadius = 0
; param: operation:tool_threadProfileAngle = 0
; param: operation:tool_tipLength = 0
; param: operation:tool_fluteLength = 26.5
; param: operation:tool_shoulderLength = 26.5
; param: operation:tool_bodyLength = 40
; param: operation:tool_overallLength = 75
; param: operation:tool_shaftDiameter = 6
; param: operation:tool_segmentHeight = 3
; param: operation:tool_segmentDiameterLower = 12
; param: operation:tool_segmentDiameterUpper = 12
; param: operation:tool_shaftSegmentHeight = 6.75
; param: operation:tool_shaftSegmentDiameterLower = 0.5
; param: operation:tool_shaftSegmentDiameterUpper = 6
; param: operation:tool_threadPitch = 0
; param: operation:tool_maximumThreadPitch = 0
; param: operation:tool_minimumThreadPitch = 0
; param: operation:tool_numberOfTeeth = 0
; param: operation:tool_numberOfFlutes = 3
; param: operation:tool_shoulderDiameter = 6.257643000000001
; param: operation:tool_upperRadius = 1.016
; param: operation:tool_profileRadius = 101.6
; param: operation:tool_lowerRadius = 1.016
; param: operation:tool_axialDistance = 1.016
; param: operation:tool_chamferWidth = 1.016
; param: operation:tool_chamferAngle = 45
; param: operation:holder_attached = 0
; param: operation:holder_description = 
; param: operation:holder_comment = 
; param: operation:holder_vendor = 
; param: operation:holder_productId = 
; param: operation:holder_productLink = 
; param: operation:holder_libraryName = 
; param: operation:tool_holderGaugeLength = 0
; param: operation:tool_assemblyGaugeLength = 40
; param: operation:tool_spindleSpeed = 18000
; param: operation:tool_stockDiameter = 0.5
; param: operation:tool_surfaceSpeed = 28274.33388230814
; param: operation:tool_rampSpindleSpeed = 18000
; param: operation:tool_feedCutting = 254
; param: operation:tool_feedPerTooth = 0.004703703703703704
; param: operation:tool_feedEntry = 254
; param: operation:tool_feedExit = 254
; param: operation:tool_feedTransition = 254
; param: operation:tool_feedRamp = 84.66666666666667
; param: operation:tool_feedPlunge = 84.66666666666667
; param: operation:tool_feedPerRevolution = 0.004703703703703704
; param: operation:tool_feedRetract = 84.66666666666667
; param: operation:tool_clockwise = 1
; param: operation:tool_coolant = disabled
; param: operation:featureOperationId = none
; param: operation:surfaceZHigh = -1.016
; param: operation:surfaceZLow = -26.496
; param: operation:surfaceXLow = 1.01600000000002
; param: operation:surfaceXHigh = 108.96600000000008
; param: operation:surfaceYLow = 1.016
; param: operation:surfaceYHigh = 149.22476554149074
; param: operation:stockZHigh = 0
; param: operation:stockZLow = -26.496
; param: operation:stockXLow = 0
; param: operation:stockXHigh = 109.98200000000008
; param: operation:stockYLow = 0
; param: operation:stockYHigh = 150.24076554149073
; param: operation:multiAxisMachiningType = three_axis
; param: operation:view_orientation_mode = useWCS
; param: operation:view_orientation_flipZ = 0
; param: operation:view_orientation_axesZX_unselected_default = wcs
; param: operation:view_orientation_axesZY_unselected_default = wcs
; param: operation:view_orientation_axesXY_unselected_default = wcs
; param: operation:view_select_angles = turn_and_tilt
; param: operation:view_turn_from_recipe = 0
; param: operation:view_tilt_from_recipe = 0
; param: operation:view_orientation_flipX = 0
; param: operation:view_orientation_flipY = 0
; param: operation:view_origin_mode = jobOrigin
; param: operation:view_origin_boxPoint = top center
; param: operation:show_machine = 0
; param: operation:unwrap = 1
; param: operation:wrap_cylinder_radius = 0
; param: operation:wrap_nominalRadius_offset = 0
; param: operation:wrap_nominalRadius_value = 0
; param: operation:usePolarWhenNecessary = 0
; param: operation:polarMode = automatic
; param: operation:polarLineAngle = 0
; param: operation:pockets_detectOpenPockets = 1
; param: operation:pockets_connectOpenPockets = 1
; param: operation:pockets_errorCheck = 1
; param: operation:pockets_detectOverlaps = 0
; param: operation:restMaterialCutterDiameter = 3.175
; param: operation:restMaterialCornerRadius = 3.175
; param: operation:restMaterialTaperAngle = 0
; param: operation:restMaterialShoulderLength = 3.175
; param: operation:restMaterialTool = 
; param: operation:isClearanceAreaEnabled = 0
; param: operation:clearanceHeight_mode = from retract height
; param: operation:clearanceHeightFromHighest_checkStock = top
; param: operation:clearanceHeightFromLowest_checkStock = bottom
; param: operation:clearanceHeightFromHighest_checkModel = top
; param: operation:clearanceHeightFromLowest_checkModel = bottom
; param: operation:clearanceHeightFromHighest_checkFixture = top
; param: operation:clearanceHeightFromLowest_checkFixture = bottom
; param: operation:clearanceHeight_offset = 10.16
; param: operation:clearanceHeight_value = 15.239999999999998
; param: operation:clearanceHeight_absolute = 1
; param: operation:retractHeight_mode = from stock top
; param: operation:retractHeightFromHighest_checkStock = top
; param: operation:retractHeightFromLowest_checkStock = bottom
; param: operation:retractHeightFromHighest_checkModel = top
; param: operation:retractHeightFromLowest_checkModel = bottom
; param: operation:retractHeightFromHighest_checkFixture = top
; param: operation:retractHeightFromLowest_checkFixture = bottom
; param: operation:retractHeight_offset = 5.08
; param: operation:retractHeight_value = 5.08
; param: operation:retractHeight_absolute = 1
; param: operation:topHeight_mode = from stock top
; param: operation:topHeightFromHighest_checkStock = top
; param: operation:topHeightFromLowest_checkStock = bottom
; param: operation:topHeightFromHighest_checkModel = ignore
; param: operation:topHeightFromLowest_checkModel = ignore
; param: operation:topHeightFromHighest_checkFixture = ignore
; param: operation:topHeightFromLowest_checkFixture = ignore
; param: operation:topHeight_offset = 0
; param: operation:topHeight_value = 0
; param: operation:topHeight_absolute = 1
; param: operation:bottomHeight_mode = from contour
; param: operation:bottomHeightFromHighest_checkStock = bottom
; param: operation:bottomHeightFromLowest_checkStock = ignore
; param: operation:bottomHeightFromHighest_checkModel = bottom
; param: operation:bottomHeightFromLowest_checkModel = bottom
; param: operation:bottomHeightFromHighest_checkFixture = ignore
; param: operation:bottomHeightFromLowest_checkFixture = ignore
; param: operation:bottomHeight_offset = 0
; param: operation:bottomHeight_value = 0
; param: operation:bottomHeight_absolute = 0
; param: operation:tolerance = 0.1016
; param: operation:contourTolerance = 0.0508
; param: operation:totalSurfaceTolerance = 0.0508
; param: operation:surfaceTriangulationTolerance = 0.0508
; param: operation:calculationTolerance = 0.0508
; param: operation:thinningTolerance = 0.000508
; param: operation:chainingTolerance = 0.01016
; param: operation:gougingTolerance = 0.0508
; param: operation:optimalLoad = 0.2
; param: operation:optimalLoadWeight = 0
; param: operation:speedWeight = 0
; param: operation:feedWeight = 0
; param: operation:loadDeviation = 0.020000000000000004
; param: operation:maximumLoad = 0.22000000000000003
; param: operation:bothWays = 0
; param: operation:optimalLoadOtherWay = 0.2
; param: operation:loadDeviationOtherWay = 0.020000000000000004
; param: operation:maximumLoadOtherWay = 0.22000000000000003
; param: operation:otherWayFeedrate = 228.6
; param: operation:maximumCuspHeight = 0.13125657912962088
; param: operation:minimumCuttingRadius = 0.05
; param: operation:minimumCuttingRadiusJl = 0.05
; param: operation:machineCavities = 1
; param: operation:useSlotClearing = 0
; param: operation:slotClearingWidth = 0.625
; param: operation:direction = climb
; param: operation:maximumStepdown = 0
; param: operation:maximumStepdownJl = 2000000
; param: operation:slopeAngle = 0
; param: operation:useEvenStepdowns = 0
; param: operation:curveInRadius = 0.125
; param: operation:fineStepdown = 0
; param: operation:fineStepdownJl = 1000000
; param: operation:minimumStepdownJobline = 0
; param: operation:useSilhouetteAsStockBoundary = 0
; param: operation:orderByDepth = 0
; param: operation:orderByArea = 0
; param: operation:orderByAreaBufferSize = 400
; param: operation:stockToLeave = 0.127
; param: operation:verticalStockToLeave = 0
; param: operation:simpleStockToLeave = 0
; param: operation:useCombinedFilter = 1
; param: operation:useDMKSmoothing = 0
; param: operation:smoothingFilterMode = redistribute
; param: operation:smoothingFilterMaxSpacing = 0.508
; param: operation:smoothingFilterMaxAngle = 3
; param: operation:smoothingFilterToleranceForEvenlySpacedPoints = 0.0508
; param: operation:smoothingFilterToleranceFactor = 0.5
; param: operation:smoothingFilterTolerance = 0
; param: operation:reducedFeedChange = 25
; param: operation:reducedFeedRadius = 0
; param: operation:reducedFeedDistance = 0
; param: operation:reducedFeedrate = 228.6
; param: operation:reduceOnlyInnerCorners = 1
; param: operation:surfaceSpeedOnArcs = 0
; param: operation:maximumReducedFeedrateInternalArcFinishing = 100
; param: operation:maximumIncreasedFeedrateExternalArcFinishing = 100
; param: operation:maximumReducedFeedrateInternalArc = 100
; param: operation:maximumIncreasedFeedrateExternalArc = 100
; param: operation:retractionPolicy = full
; param: operation:highFeedrateMode = disabled
; param: operation:highFeedrate = 254
; param: operation:allowRapidRetract = 1
; param: operation:stayDownDistance = 2.5
; param: operation:minimumStayDownClearance = 2
; param: operation:stayDownLevel = level0
; param: operation:astarSpeedRatioJl = 0
; param: operation:liftHeight = 0.2032
; param: operation:noEngagementFeedrate = 254
; param: operation:leadRadius = 0.05
; param: operation:verticalLeadRadius = 0.05
; param: operation:leadInRadius = 0.05
; param: operation:leadInVerticalRadius = 0.05
; param: operation:leadOutRadius = 0.05
; param: operation:leadOutVerticalRadius = 0.05
; param: operation:rampType = helix
; param: operation:allowPlungingOutsideStockJl = 0
; param: operation:rampAngle = 2
; param: operation:rampTaperAngle = 1
; param: operation:rampClearanceHeight = 2.54
; param: operation:helicalRampDiameter = 0.125
; param: operation:minimumRampDiameter = 0.125
; param: operation:allowPlunging = 0
; param: operation:allowHelicalRamps = 1
; param: operation:isOperationTemplate = 0
; param: operation:use_tool_stepdown = 0
; param: operation:tool_stepdown = 23.85
; param: operation:tool_finishingStepdown = 0.2032
; param: operation:use_tool_stepover = 0
; param: operation:tool_stepover = 0.15
; param: operation:tool_finishingStepover = 0.05
; param: operation:tool_rampType = helix
; param: operation:tool_rampAngle = 2
;When using Fusion for Personal Use, the feedrate of rapid
;moves is reduced to match the feedrate of cutting moves,
;which can increase machining time. Unrestricted rapid moves
;are available with a Fusion Subscription.
; param: movement:lead_in = 254
; param: movement:cutting = 254
; param: movement:lead_out = 254
; param: movement:transition = 254
; param: movement:direct = 254
; param: movement:helix_ramp = 84.66666666666667
; param: movement:profile_ramp = 84.66666666666667
; param: movement:zigzag_ramp = 84.66666666666667
; param: movement:ramp = 84.66666666666667
; param: movement:plunge = 84.66666666666667
; param: movement:predrill = 254
; param: movement:extended = 254
; param: movement:reduced = 254
; param: movement:finish_cutting = 254
; param: movement:high_feed = 254
; param: movement:depositing = 0
; param: movement:connection = 0
; param: movement:drill_breakthrough = 0
; param: movement:gun_drill_positioning = 0
; 
; Ranges Table:
;   X: Min=7.655 Max=110.822 Size=103.168
;   Y: Min=6.379 Max=139.296 Size=132.917
;   Z: Min=-8.096 Max=15.24 Size=23.336
; 
; Tools Table:
;  T1 D=0.5 CR=0.25 TAPER=6.2deg - ZMIN=-8.096 - tapered mill 
; 
; Feedrate and Scaling Properties:
;   Feed: Travel speed X/Y = 4470
;   Feed: Travel Speed Z = 2235
;   Feed: Enforce Feedrate = true
;   Feed: Scale Feedrate = false
;   Feed: Max XY Cut Speed = 1000
;   Feed: Max Z Cut Speed = 400
;   Feed: Max Toolpath Speed = 1000
; 
; G1->G0 Mapping Properties:
;   Map: First G1 -> G0 Rapid = false
;   Map: G1s -> G0 Rapids = false
;   Map: SafeZ Mode = Retract : default = 15
;   Map: Allow Rapid Z = false
; 
; *** START begin ***
;   Set Absolute Positioning
;   Units = mm
G90
G21
;   Disable stepper timeout
M84 S0
;   Set current position to 0,0,0
G92 X0 Y0 Z0
; *** START end ***
; 
; *** SECTION begin ***
;   X Min: 7.655 - X Max: 110.822
;   Y Min: 6.379 - Y Max: 139.296
;   Z Min: -8.096 - Z Max: 15.24
; 2D Adaptive7 4 - Milling - Tool: 1 -  tapered mill
; COMMAND_START_SPINDLE
; COMMAND_SPINDLE_CLOCKWISE
; >>> Spindle Speed: Manual
M0 Turn ON 18000RPM
; COMMAND_COOLANT_ON
;   tool.coolant = 0 strCoolant = Off
; ---- Coolant: Off cur: Off A: Off B: Off
M117  2D Adaptive7 (4)
; MOVEMENT_CUTTING
G1 X110.822 Y138.828 Z15.24 F254
G1 Z5.08 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X110.819 Y138.83 Z-8.065 F254
G1 X110.81 Y138.835 Z-8.081 F254
G1 X110.796 Y138.843 Z-8.092 F254
G1 X110.78 Y138.853 Z-8.096 F254
G3 X109.272 Y139.296 I-1.618 J-2.721 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X109.203 F254
G1 X109.165 Y139.294 F254
G1 X109.089 Y139.161 F254
G1 X109.062 Y139.011 F254
G1 X109.043 Y138.743 F254
G1 Y138.206 F254
G1 X109.031 Y138.169 F254
G1 X108.99 Y138.105 F254
G1 X108.932 Y138.055 F254
G1 X108.798 Y137.979 F254
G1 X108.5 Y137.906 F254
G1 X108.193 Y137.915 F254
G1 X107.886 Y137.913 F254
G1 X60.292 F254
G1 X10.241 F254
G1 X9.205 F254
G1 X9.151 Y137.86 F254
G1 X9.082 Y137.724 F254
G1 X9.057 Y137.574 F254
G1 X9.037 Y137.287 F254
G1 X9.039 Y136.98 F254
G1 X9.038 Y88.771 F254
G1 Y38.721 F254
G1 X9.037 Y7.938 F254
G1 X9.087 Y7.88 F254
G1 X9.221 Y7.808 F254
G1 X9.371 Y7.781 F254
G1 X9.646 Y7.762 F254
G1 X9.953 Y7.763 F254
G1 X28.377 F254
G1 X78.427 Y7.762 F254
G1 X108.75 Y7.761 F254
G1 X108.786 Y7.75 F254
G1 X108.851 Y7.709 F254
G1 X108.901 Y7.651 F254
G1 X108.977 Y7.517 F254
G1 X109.051 Y7.219 F254
G1 X109.042 Y6.912 F254
G1 X109.043 Y6.504 F254
G1 X109.06 Y6.441 F254
G1 X109.106 Y6.396 F254
G1 X109.168 Y6.379 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X109.216 Y6.431 I-0.002 J0.05 F254
G3 X109.165 Y6.479 I-0.05 J-0.002 F254
G1 X109.146 Y6.478 Z-8.092 F254
G1 X109.129 Z-8.081 F254
G1 X109.119 Y6.477 Z-8.065 F254
G1 X109.115 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X109.999 Y139.049 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X109.996 Y139.051 Z-8.065 F254
G1 X109.987 Y139.056 Z-8.081 F254
G1 X109.973 Y139.065 Z-8.092 F254
G1 X109.956 Y139.075 Z-8.096 F254
G3 X109.203 Y139.296 I-0.809 J-1.36 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X109.133 F254
G1 X109.095 Y139.294 F254
G1 X109.027 Y139.259 F254
G1 X108.929 Y139.142 F254
G1 X108.884 Y138.996 F254
G1 X108.86 Y138.846 F254
G1 X108.841 Y138.547 F254
G1 Y138.47 F254
G1 X108.829 Y138.394 F254
G1 X108.794 Y138.327 F254
G1 X108.741 Y138.271 F254
G1 X108.679 Y138.225 F254
G1 X108.543 Y138.154 F254
G1 X108.241 Y138.101 F254
G1 X107.934 Y138.116 F254
G1 X107.627 Y138.113 F254
G1 X107.013 F254
G1 X59.726 F254
G1 X9.675 F254
G1 X9.369 F254
G1 X9.217 Y138.101 F254
G1 X9.082 Y138.03 F254
G1 X8.983 Y137.915 F254
G1 X8.917 Y137.778 F254
G1 X8.879 Y137.63 F254
G1 X8.856 Y137.461 F254
G1 X8.837 Y137.192 F254
G1 X8.84 Y136.885 F254
G1 X8.839 Y136.578 F254
G1 X8.838 Y88.677 F254
G1 Y38.626 F254
G1 X8.837 Y8.075 F254
G1 X8.858 Y7.924 F254
G1 X8.934 Y7.792 F254
G1 X9.052 Y7.695 F254
G1 X9.192 Y7.635 F254
G1 X9.34 Y7.6 F254
G1 X9.5 Y7.578 F254
G1 X9.806 Y7.56 F254
G1 X10.113 Y7.564 F254
G1 X10.42 Y7.563 F254
G1 X28.23 F254
G1 X78.28 Y7.562 F254
G1 X108.526 Y7.561 F254
G1 X108.598 Y7.536 F254
G1 X108.66 Y7.49 F254
G1 X108.71 Y7.432 F254
G1 X108.751 Y7.368 F254
G1 X108.811 Y7.226 F254
G1 X108.852 Y6.922 F254
G1 X108.847 Y6.768 F254
G1 X108.845 Y6.616 F254
G1 X108.864 Y6.465 F254
G1 X108.873 Y6.447 F254
G1 X108.901 Y6.411 F254
G1 X108.939 Y6.387 F254
G1 X108.984 Y6.379 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X109.032 Y6.431 I-0.002 J0.05 F254
G3 X108.981 Y6.479 I-0.05 J-0.002 F254
G1 X108.961 Y6.478 Z-8.092 F254
G1 X108.945 Z-8.081 F254
G1 X108.934 Y6.477 Z-8.065 F254
G1 X108.931 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X109.929 Y139.049 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X109.926 Y139.051 Z-8.065 F254
G1 X109.917 Y139.056 Z-8.081 F254
G1 X109.903 Y139.065 Z-8.092 F254
G1 X109.886 Y139.075 Z-8.096 F254
G3 X109.133 Y139.296 I-0.809 J-1.36 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X108.993 F254
G1 X108.955 Y139.294 F254
G1 X108.885 Y139.264 F254
G1 X108.774 Y139.16 F254
G1 X108.712 Y139.021 F254
G1 X108.678 Y138.872 F254
G1 X108.659 Y138.72 F254
G1 X108.653 Y138.643 F254
G1 X108.629 Y138.57 F254
G1 X108.589 Y138.505 F254
G1 X108.476 Y138.401 F254
G1 X108.334 Y138.341 F254
G1 X108.03 Y138.3 F254
G1 X107.724 Y138.316 F254
G1 X107.417 Y138.312 F254
G1 X107.11 Y138.314 F254
G1 X59.515 Y138.313 F254
G1 X9.465 F254
G1 X9.313 Y138.306 F254
G1 X9.164 Y138.27 F254
G1 X9.026 Y138.207 F254
G1 X8.909 Y138.109 F254
G1 X8.818 Y137.987 F254
G1 X8.751 Y137.85 F254
G1 X8.706 Y137.704 F254
G1 X8.676 Y137.555 F254
G1 X8.651 Y137.35 F254
G1 X8.636 Y137.043 F254
G1 X8.64 Y136.736 F254
G1 X8.639 Y136.429 F254
G1 X8.638 Y88.528 F254
G1 Y38.477 F254
G1 X8.637 Y8.182 F254
G1 X8.648 Y8.03 F254
G1 X8.685 Y7.882 F254
G1 X8.749 Y7.743 F254
G1 X8.848 Y7.628 F254
G1 X8.971 Y7.538 F254
G1 X9.109 Y7.472 F254
G1 X9.255 Y7.427 F254
G1 X9.404 Y7.398 F254
G1 X9.633 Y7.372 F254
G1 X9.939 Y7.359 F254
G1 X10.246 Y7.365 F254
G1 X10.553 Y7.362 F254
G1 X12.703 Y7.363 F254
G1 X28.056 F254
G1 X78.106 Y7.362 F254
G1 X108.275 Y7.361 F254
G1 X108.351 Y7.353 F254
G1 X108.421 Y7.32 F254
G1 X108.48 Y7.271 F254
G1 X108.571 Y7.147 F254
G1 X108.621 Y7.002 F254
G1 X108.654 Y6.697 F254
G1 X108.661 Y6.545 F254
G1 X108.683 Y6.469 F254
G1 X108.708 Y6.422 F254
G1 X108.751 Y6.39 F254
G1 X108.803 Y6.379 F254
G1 X108.984 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X109.032 Y6.431 I-0.002 J0.05 F254
G3 X108.981 Y6.479 I-0.05 J-0.002 F254
G1 X108.961 Y6.478 Z-8.092 F254
G1 X108.945 Z-8.081 F254
G1 X108.934 Y6.477 Z-8.065 F254
G1 X108.931 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X109.79 Y139.049 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X109.787 Y139.051 Z-8.065 F254
G1 X109.777 Y139.056 Z-8.081 F254
G1 X109.763 Y139.065 Z-8.092 F254
G1 X109.747 Y139.075 Z-8.096 F254
G3 X108.993 Y139.296 I-0.809 J-1.36 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X108.854 F254
G1 X108.778 Y139.292 F254
G1 X108.642 Y139.222 F254
G1 X108.559 Y139.094 F254
G1 X108.509 Y138.95 F254
G1 X108.478 Y138.8 F254
G1 X108.443 Y138.732 F254
G1 X108.393 Y138.673 F254
G1 X108.269 Y138.582 F254
G1 X108.124 Y138.533 F254
G1 X107.819 Y138.502 F254
G1 X107.512 Y138.516 F254
G1 X107.205 Y138.512 F254
G1 X106.898 Y138.514 F254
G1 X58.997 Y138.513 F254
G1 X9.56 F254
G1 X9.408 Y138.509 F254
G1 X9.257 Y138.487 F254
G1 X9.11 Y138.447 F254
G1 X8.971 Y138.385 F254
G1 X8.845 Y138.299 F254
G1 X8.738 Y138.19 F254
G1 X8.652 Y138.065 F254
G1 X8.584 Y137.928 F254
G1 X8.533 Y137.785 F254
G1 X8.495 Y137.628 F254
G1 X8.468 Y137.465 F254
G1 X8.443 Y137.192 F254
G1 X8.437 Y136.885 F254
G1 X8.441 Y136.578 F254
G1 X8.438 Y136.271 F254
G1 X8.439 Y135.35 F254
G1 X8.438 Y88.37 F254
G1 Y38.319 F254
G1 X8.437 Y8.232 F254
G1 X8.448 Y8.08 F254
G1 X8.475 Y7.93 F254
G1 X8.523 Y7.785 F254
G1 X8.595 Y7.651 F254
G1 X8.689 Y7.531 F254
G1 X8.802 Y7.429 F254
G1 X8.931 Y7.349 F254
G1 X9.071 Y7.287 F254
G1 X9.217 Y7.243 F254
G1 X9.394 Y7.206 F254
G1 X9.602 Y7.178 F254
G1 X9.908 Y7.16 F254
G1 X10.215 Y7.164 F254
G1 X10.829 Y7.163 F254
G1 X28.024 F254
G1 X78.075 Y7.162 F254
G1 X108.09 Y7.161 F254
G1 X108.165 Y7.148 F254
G1 X108.234 Y7.114 F254
G1 X108.291 Y7.062 F254
G1 X108.379 Y6.936 F254
G1 X108.47 Y6.643 F254
G1 X108.488 Y6.492 F254
G1 X108.504 Y6.454 F254
G1 X108.531 Y6.415 F254
G1 X108.571 Y6.388 F254
G1 X108.618 Y6.379 F254
G1 X108.803 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X108.851 Y6.431 I-0.002 J0.05 F254
G3 X108.799 Y6.479 I-0.05 J-0.002 F254
G1 X108.78 Y6.478 Z-8.092 F254
G1 X108.764 Z-8.081 F254
G1 X108.753 Y6.477 Z-8.065 F254
G1 X108.749 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X109.65 Y139.049 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X109.647 Y139.051 Z-8.065 F254
G1 X109.638 Y139.056 Z-8.081 F254
G1 X109.624 Y139.065 Z-8.092 F254
G1 X109.607 Y139.075 Z-8.096 F254
G3 X108.854 Y139.296 I-0.809 J-1.36 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X108.644 F254
G1 X108.606 Y139.294 F254
G1 X108.537 Y139.262 F254
G1 X108.421 Y139.163 F254
G1 X108.315 Y138.96 F254
G1 X108.268 Y138.899 F254
G1 X108.211 Y138.848 F254
G1 X108.079 Y138.77 F254
G1 X107.931 Y138.73 F254
G1 X107.625 Y138.703 F254
G1 X107.318 Y138.716 F254
G1 X107.011 Y138.712 F254
G1 X106.704 Y138.714 F254
G1 X58.803 Y138.713 F254
G1 X9.673 F254
G1 X9.498 Y138.71 F254
G1 X9.346 Y138.697 F254
G1 X9.196 Y138.669 F254
G1 X9.05 Y138.624 F254
G1 X8.911 Y138.563 F254
G1 X8.781 Y138.484 F254
G1 X8.665 Y138.385 F254
G1 X8.565 Y138.27 F254
G1 X8.481 Y138.142 F254
G1 X8.413 Y138.006 F254
G1 X8.36 Y137.863 F254
G1 X8.318 Y137.713 F254
G1 X8.282 Y137.536 F254
G1 X8.253 Y137.307 F254
G1 X8.238 Y137 F254
G1 X8.24 Y136.386 F254
G1 X8.239 Y136.079 F254
G1 X8.238 Y88.485 F254
G1 Y38.434 F254
G1 X8.237 Y8.342 F254
G1 X8.244 Y8.178 F254
G1 X8.261 Y8.027 F254
G1 X8.294 Y7.878 F254
G1 X8.343 Y7.734 F254
G1 X8.411 Y7.597 F254
G1 X8.496 Y7.47 F254
G1 X8.599 Y7.358 F254
G1 X8.717 Y7.262 F254
G1 X8.847 Y7.183 F254
G1 X8.986 Y7.119 F254
G1 X9.13 Y7.07 F254
G1 X9.287 Y7.03 F254
G1 X9.472 Y6.997 F254
G1 X9.741 Y6.969 F254
G1 X10.048 Y6.96 F254
G1 X10.355 Y6.965 F254
G1 X10.662 Y6.963 F254
G1 X27.55 F254
G1 X77.601 Y6.962 F254
G1 X107.846 Y6.961 F254
G1 X107.923 Y6.96 F254
G1 X107.996 Y6.938 F254
G1 X108.061 Y6.897 F254
G1 X108.168 Y6.787 F254
G1 X108.303 Y6.511 F254
G1 X108.321 Y6.462 F254
G1 X108.348 Y6.419 F254
G1 X108.389 Y6.389 F254
G1 X108.439 Y6.379 F254
G1 X108.618 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X108.615 Y6.479 I-0.002 J0.05 F254
G1 X108.596 Y6.478 Z-8.092 F254
G1 X108.58 Z-8.081 F254
G1 X108.569 Y6.477 Z-8.065 F254
G1 X108.565 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X109.441 Y139.049 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X109.438 Y139.051 Z-8.065 F254
G1 X109.428 Y139.056 Z-8.081 F254
G1 X109.414 Y139.065 Z-8.092 F254
G1 X109.398 Y139.075 Z-8.096 F254
G3 X108.644 Y139.296 I-0.809 J-1.36 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X108.505 F254
G1 X108.429 Y139.292 F254
G1 X108.29 Y139.229 F254
G1 X108.188 Y139.114 F254
G1 X108.07 Y139.016 F254
G1 X107.927 Y138.958 F254
G1 X107.627 Y138.897 F254
G1 X107.354 Y138.915 F254
G1 X107.047 Y138.913 F254
G1 X105.205 F254
G1 X58.532 F254
G1 X9.709 F254
G1 X9.511 Y138.908 F254
G1 X9.354 Y138.892 F254
G1 X9.204 Y138.866 F254
G1 X9.056 Y138.827 F254
G1 X8.913 Y138.774 F254
G1 X8.777 Y138.705 F254
G1 X8.651 Y138.62 F254
G1 X8.536 Y138.52 F254
G1 X8.434 Y138.406 F254
G1 X8.346 Y138.282 F254
G1 X8.271 Y138.149 F254
G1 X8.209 Y138.01 F254
G1 X8.16 Y137.866 F254
G1 X8.116 Y137.698 F254
G1 X8.077 Y137.487 F254
G1 X8.047 Y137.206 F254
G1 X8.036 Y136.899 F254
G1 X8.04 Y136.592 F254
G1 Y136.285 F254
G1 X8.039 Y135.978 F254
G1 Y135.671 F254
G1 X8.038 Y88.384 F254
G1 Y38.333 F254
G1 X8.037 Y8.548 F254
G1 X8.039 Y8.281 F254
G1 X8.053 Y8.115 F254
G1 X8.077 Y7.965 F254
G1 X8.113 Y7.817 F254
G1 X8.164 Y7.673 F254
G1 X8.23 Y7.536 F254
G1 X8.31 Y7.406 F254
G1 X8.405 Y7.287 F254
G1 X8.515 Y7.181 F254
G1 X8.637 Y7.09 F254
G1 X8.768 Y7.012 F254
G1 X8.906 Y6.948 F254
G1 X9.05 Y6.895 F254
G1 X9.217 Y6.848 F254
G1 X9.41 Y6.809 F254
G1 X9.648 Y6.778 F254
G1 X9.955 Y6.761 F254
G1 X10.569 Y6.764 F254
G1 X10.876 Y6.763 F254
G1 X27.15 F254
G1 X77.201 Y6.762 F254
G1 X107.753 Y6.761 F254
G1 X107.826 Y6.736 F254
G1 X107.954 Y6.652 F254
G1 X108.132 Y6.427 F254
G1 X108.159 Y6.401 F254
G1 X108.193 Y6.385 F254
G1 X108.23 Y6.379 F254
G1 X108.439 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X108.435 Y6.479 I-0.002 J0.05 F254
G1 X108.416 Y6.478 Z-8.092 F254
G1 X108.4 Z-8.081 F254
G1 X108.389 Y6.477 Z-8.065 F254
G1 X108.385 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X109.301 Y139.049 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X109.298 Y139.051 Z-8.065 F254
G1 X109.289 Y139.056 Z-8.081 F254
G1 X109.275 Y139.065 Z-8.092 F254
G1 X109.258 Y139.075 Z-8.096 F254
G3 X108.505 Y139.296 I-0.809 J-1.36 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X108.295 F254
G1 X108.143 Y139.288 F254
G1 X107.872 Y139.145 F254
G1 X107.569 Y139.091 F254
G1 X107.373 Y139.109 F254
G1 X107.066 Y139.114 F254
G1 X106.759 Y139.113 F254
G1 X101.232 F254
G1 X58.244 F254
G1 X9.729 F254
G1 X9.517 Y139.106 F254
G1 X9.336 Y139.087 F254
G1 X9.18 Y139.058 F254
G1 X9.032 Y139.02 F254
G1 X8.888 Y138.97 F254
G1 X8.75 Y138.906 F254
G1 X8.618 Y138.83 F254
G1 X8.496 Y138.739 F254
G1 X8.384 Y138.635 F254
G1 X8.284 Y138.52 F254
G1 X8.239 Y138.458 F254
G1 X8.154 Y138.331 F254
G1 X8.082 Y138.197 F254
G1 X8.022 Y138.056 F254
G1 X7.969 Y137.898 F254
G1 X7.919 Y137.705 F254
G1 X7.874 Y137.46 F254
G1 X7.846 Y137.191 F254
G1 X7.836 Y136.884 F254
G1 X7.84 Y136.577 F254
G1 Y136.27 F254
G1 X7.838 Y135.963 F254
G1 X7.839 Y135.656 F254
G1 X7.838 Y88.369 F254
G1 Y38.318 F254
G1 X7.837 Y8.533 F254
G1 X7.839 Y8.309 F254
G1 X7.855 Y8.121 F254
G1 X7.881 Y7.961 F254
G1 X7.915 Y7.813 F254
G1 X7.962 Y7.667 F254
G1 X8.02 Y7.527 F254
G1 X8.092 Y7.392 F254
G1 X8.177 Y7.266 F254
G1 X8.276 Y7.149 F254
G1 X8.386 Y7.044 F254
G1 X8.506 Y6.951 F254
G1 X8.635 Y6.869 F254
G1 X8.77 Y6.799 F254
G1 X8.917 Y6.738 F254
G1 X9.073 Y6.686 F254
G1 X9.26 Y6.639 F254
G1 X9.487 Y6.599 F254
G1 X9.784 Y6.569 F254
G1 X10.091 Y6.561 F254
G1 X10.398 Y6.564 F254
G1 X10.705 F254
G1 X11.012 Y6.563 F254
G1 X26.979 F254
G1 X77.03 Y6.562 F254
G1 X107.582 Y6.561 F254
G1 X107.656 Y6.54 F254
G1 X107.792 Y6.469 F254
G1 X107.856 Y6.412 F254
G1 X107.881 Y6.394 F254
G1 X107.909 Y6.383 F254
G1 X107.94 Y6.379 F254
G1 X108.23 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X108.226 Y6.479 I-0.002 J0.05 F254
G1 X108.207 Y6.478 Z-8.092 F254
G1 X108.191 Z-8.081 F254
G1 X108.18 Y6.477 Z-8.065 F254
G1 X108.176 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X109.121 Y139.172 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X109.118 Y139.173 Z-8.065 F254
G1 X109.107 Y139.175 Z-8.081 F254
G1 X109.091 Y139.179 Z-8.092 F254
G1 X109.073 Y139.184 Z-8.096 F254
G3 X108.295 Y139.296 I-0.905 J-3.532 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X9.667 F254
G1 X9.362 Y139.28 F254
G1 X9.211 Y139.26 F254
G1 X9.062 Y139.228 F254
G1 X8.916 Y139.185 F254
G1 X8.773 Y139.13 F254
G1 X8.637 Y139.063 F254
G1 X8.507 Y138.983 F254
G1 X8.384 Y138.892 F254
G1 X8.271 Y138.79 F254
G1 X8.168 Y138.678 F254
G1 X8.074 Y138.558 F254
G1 X7.991 Y138.43 F254
G1 X7.918 Y138.296 F254
G1 X7.852 Y138.148 F254
G1 X7.789 Y137.974 F254
G1 X7.734 Y137.776 F254
G1 X7.688 Y137.55 F254
G1 X7.655 Y137.284 F254
G1 Y137.279 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X7.755 Y137.283 I0.05 J0.002 F254
G1 X7.754 Y137.302 Z-8.092 F254
G1 X7.753 Y137.318 Z-8.081 F254
G1 Y137.329 Z-8.065 F254
G1 Y137.333 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X12.05 Y137.189 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X12.049 Y137.193 Z-8.065 F254
G1 X12.048 Y137.203 Z-8.081 F254
G1 X12.045 Y137.219 Z-8.092 F254
G1 X12.041 Y137.238 Z-8.096 F254
G3 X9.667 Y139.296 I-2.461 J-0.441 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X8.9 F254
G1 X8.748 Y139.288 F254
G1 X8.602 Y139.245 F254
G1 X8.465 Y139.177 F254
G1 X8.337 Y139.095 F254
G1 X8.217 Y139 F254
G1 X8.106 Y138.896 F254
G1 X8.005 Y138.782 F254
G1 X7.912 Y138.661 F254
G1 X7.828 Y138.531 F254
G1 X7.749 Y138.387 F254
G1 X7.673 Y138.222 F254
G1 X7.663 Y138.193 F254
G1 X7.658 Y138.179 F254
G1 X7.656 Y138.164 F254
G1 X7.655 Y138.149 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X7.659 Y138.13 Z-8.045 F254
G1 X7.671 Y138.115 Z-7.994 F254
G1 X7.687 Y138.104 Z-7.944 F254
G1 X7.706 Y138.101 Z-7.893 F254
G3 X7.739 Y138.114 I-0.002 J0.05 F254
G1 X8.131 Y138.474 F254
; MOVEMENT_LINK_DIRECT
G1 X8.543 Y138.852 F254
; MOVEMENT_LEAD_IN
G1 X8.932 Y139.209 F254
G3 X8.948 Y139.244 I-0.034 J0.037 F254
G1 X8.945 Y139.263 Z-7.944 F254
G1 X8.935 Y139.28 Z-7.994 F254
G1 X8.919 Y139.291 Z-8.045 F254
G1 X8.9 Y139.296 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X8.513 F254
G1 X8.36 Y139.288 F254
G1 X8.221 Y139.226 F254
G1 X8.096 Y139.139 F254
G1 X7.982 Y139.038 F254
G1 X7.878 Y138.927 F254
G1 X7.78 Y138.805 F254
G1 X7.686 Y138.668 F254
G1 X7.672 Y138.644 F254
G1 X7.662 Y138.624 F254
G1 X7.657 Y138.602 F254
G1 X7.655 Y138.581 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X7.659 Y138.562 Z-8.045 F254
G1 X7.671 Y138.546 Z-7.994 F254
G1 X7.687 Y138.535 Z-7.944 F254
G1 X7.706 Y138.532 Z-7.893 F254
G3 X7.736 Y138.544 I-0.002 J0.05 F254
G1 X8.137 Y138.873 F254
; MOVEMENT_LEAD_IN
G1 X8.543 Y139.207 F254
G3 X8.561 Y139.244 I-0.032 J0.039 F254
G1 X8.558 Y139.263 Z-7.944 F254
G1 X8.547 Y139.28 Z-7.994 F254
G1 X8.532 Y139.291 Z-8.045 F254
G1 X8.513 Y139.296 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X8.202 F254
G1 X8.05 Y139.288 F254
G1 X7.916 Y139.215 F254
G1 X7.8 Y139.116 F254
G1 X7.696 Y139.005 F254
G1 X7.681 Y138.987 F254
G1 X7.667 Y138.964 F254
G1 X7.658 Y138.938 F254
G1 X7.655 Y138.91 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X7.659 Y138.891 Z-8.045 F254
G1 X7.671 Y138.875 Z-7.994 F254
G1 X7.687 Y138.865 Z-7.944 F254
G1 X7.706 Y138.862 Z-7.893 F254
G3 X7.733 Y138.87 I-0.002 J0.05 F254
G1 X7.797 Y138.914 F254
; MOVEMENT_LEAD_IN
G1 X8.228 Y139.204 F254
G3 X8.25 Y139.244 I-0.028 J0.041 F254
G1 Y139.245 Z-7.895 F254
G1 Y139.246 Z-7.897 F254
G1 X8.247 Y139.265 Z-7.947 F254
G1 X8.236 Y139.281 Z-7.997 F254
G1 X8.221 Y139.292 Z-8.046 F254
G1 X8.202 Y139.296 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X7.923 F254
G1 X7.885 F254
G1 X7.853 F254
G1 X7.777 Y139.292 F254
G1 X7.712 Y139.251 F254
G1 X7.682 Y139.223 F254
G1 X7.662 Y139.186 F254
G1 X7.655 Y139.145 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X7.659 Y139.126 Z-8.045 F254
G1 X7.671 Y139.111 Z-7.994 F254
G1 X7.687 Y139.1 Z-7.944 F254
G1 X7.706 Y139.097 Z-7.893 F254
G3 X7.733 Y139.106 I-0.002 J0.05 F254
G1 X7.879 Y139.204 F254
G3 X7.901 Y139.244 I-0.028 J0.041 F254
G1 Y139.245 Z-7.895 F254
G1 Y139.246 Z-7.897 F254
G1 X7.898 Y139.265 Z-7.947 F254
G1 X7.887 Y139.281 Z-7.997 F254
G1 X7.872 Y139.292 Z-8.046 F254
G1 X7.853 Y139.296 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X7.731 F254
G1 X7.714 Y139.295 F254
G1 X7.703 Y139.292 F254
G1 X7.693 Y139.286 F254
G1 X7.672 Y139.266 F254
G1 X7.66 Y139.251 F254
G1 X7.655 Y139.236 F254
G1 Y139.027 F254
G1 Y8.323 F254
G1 X7.66 Y8.214 F254
G1 X7.671 Y8.062 F254
G1 X7.695 Y7.911 F254
G1 X7.73 Y7.763 F254
G1 X7.776 Y7.618 F254
G1 X7.834 Y7.476 F254
G1 X7.902 Y7.34 F254
G1 X7.983 Y7.211 F254
G1 X8.074 Y7.089 F254
G1 X8.177 Y6.977 F254
G1 X8.291 Y6.875 F254
G1 X8.412 Y6.783 F254
G1 X8.542 Y6.702 F254
G1 X8.68 Y6.63 F254
G1 X8.833 Y6.564 F254
G1 X9.008 Y6.503 F254
G1 X9.213 Y6.448 F254
G1 X9.432 Y6.407 F254
G1 X9.678 Y6.379 F254
G1 X9.683 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X9.731 Y6.431 I-0.002 J0.05 F254
G3 X9.679 Y6.479 I-0.05 J-0.002 F254
G1 X9.66 Y6.478 Z-8.092 F254
G1 X9.644 Z-8.081 F254
G1 X9.633 Y6.477 Z-8.065 F254
G1 X9.629 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X9.762 Y10.706 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X9.758 Y10.705 Z-8.065 F254
G1 X9.747 Y10.703 Z-8.081 F254
G1 X9.731 Y10.7 Z-8.092 F254
G1 X9.712 Y10.697 Z-8.096 F254
G3 X7.655 Y8.323 I0.441 J-2.461 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y7.625 F254
G1 X7.662 Y7.473 F254
G1 X7.707 Y7.327 F254
G1 X7.774 Y7.19 F254
G1 X7.856 Y7.062 F254
G1 X7.95 Y6.942 F254
G1 X8.054 Y6.831 F254
G1 X8.168 Y6.729 F254
G1 X8.289 Y6.637 F254
G1 X8.421 Y6.551 F254
G1 X8.568 Y6.47 F254
G1 X8.733 Y6.395 F254
G1 X8.755 Y6.387 F254
G1 X8.769 Y6.382 F254
G1 X8.783 Y6.38 F254
G1 X8.798 Y6.379 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X8.817 Y6.383 Z-8.045 F254
G1 X8.833 Y6.395 Z-7.994 F254
G1 X8.843 Y6.411 Z-7.944 F254
G1 X8.846 Y6.431 Z-7.893 F254
G3 X8.833 Y6.463 I-0.05 J-0.002 F254
G1 X8.474 Y6.855 F254
; MOVEMENT_LINK_DIRECT
G1 X8.098 Y7.267 F254
; MOVEMENT_LEAD_IN
G1 X7.742 Y7.657 F254
G3 X7.706 Y7.673 I-0.037 J-0.034 F254
G1 X7.687 Y7.67 Z-7.944 F254
G1 X7.671 Y7.66 Z-7.994 F254
G1 X7.659 Y7.644 Z-8.045 F254
G1 X7.655 Y7.625 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y7.238 F254
G1 X7.662 Y7.085 F254
G1 X7.724 Y6.946 F254
G1 X7.811 Y6.821 F254
G1 X7.912 Y6.707 F254
G1 X8.023 Y6.602 F254
G1 X8.145 Y6.504 F254
G1 X8.283 Y6.409 F254
G1 X8.306 Y6.396 F254
G1 X8.326 Y6.387 F254
G1 X8.347 Y6.381 F254
G1 X8.369 Y6.379 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X8.388 Y6.383 Z-8.045 F254
G1 X8.404 Y6.395 Z-7.994 F254
G1 X8.414 Y6.411 Z-7.944 F254
G1 X8.417 Y6.431 Z-7.893 F254
G3 X8.406 Y6.461 I-0.05 J-0.002 F254
G1 X8.077 Y6.862 F254
; MOVEMENT_LEAD_IN
G1 X7.743 Y7.268 F254
G3 X7.706 Y7.286 I-0.039 J-0.032 F254
G1 X7.687 Y7.283 Z-7.944 F254
G1 X7.671 Y7.272 Z-7.994 F254
G1 X7.659 Y7.257 Z-8.045 F254
G1 X7.655 Y7.238 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y6.927 F254
G1 X7.662 Y6.775 F254
G1 X7.736 Y6.641 F254
G1 X7.833 Y6.524 F254
G1 X7.944 Y6.42 F254
G1 X7.963 Y6.406 F254
G1 X7.986 Y6.391 F254
G1 X8.012 Y6.382 F254
G1 X8.04 Y6.379 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X8.059 Y6.383 Z-8.045 F254
G1 X8.075 Y6.395 Z-7.994 F254
G1 X8.085 Y6.411 Z-7.944 F254
G1 X8.088 Y6.431 Z-7.893 F254
G3 X8.08 Y6.457 I-0.05 J-0.002 F254
G1 X8.036 Y6.521 F254
; MOVEMENT_LEAD_IN
G1 X7.746 Y6.953 F254
G3 X7.706 Y6.975 I-0.042 J-0.028 F254
G1 Z-7.895 F254
G1 X7.705 Z-7.897 F254
G1 X7.686 Y6.972 Z-7.947 F254
G1 X7.67 Y6.961 Z-7.997 F254
G1 X7.659 Y6.946 Z-8.046 F254
G1 X7.655 Y6.927 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y6.648 F254
G1 Y6.61 F254
G1 Y6.578 F254
G1 X7.659 Y6.502 F254
G1 X7.7 Y6.437 F254
G1 X7.728 Y6.406 F254
G1 X7.764 Y6.386 F254
G1 X7.805 Y6.379 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X7.824 Y6.383 Z-8.045 F254
G1 X7.84 Y6.395 Z-7.994 F254
G1 X7.85 Y6.411 Z-7.944 F254
G1 X7.854 Y6.431 Z-7.893 F254
G3 X7.845 Y6.457 I-0.05 J-0.002 F254
G1 X7.746 Y6.604 F254
G3 X7.706 Y6.626 I-0.042 J-0.028 F254
G1 X7.687 Y6.623 Z-7.944 F254
G1 X7.671 Y6.613 Z-7.994 F254
G1 X7.659 Y6.597 Z-8.045 F254
G1 X7.655 Y6.578 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y6.439 F254
G1 X7.66 Y6.424 F254
G1 X7.672 Y6.409 F254
G1 X7.693 Y6.389 F254
G1 X7.703 Y6.383 F254
G1 X7.714 Y6.38 F254
G1 X7.748 Y6.379 F254
G1 X107.94 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X107.988 Y6.431 I-0.002 J0.05 F254
G3 X107.936 Y6.479 I-0.05 J-0.002 F254
G1 X107.917 Y6.478 Z-8.092 F254
G1 X107.901 Z-8.081 F254
G1 X107.89 Y6.477 Z-8.065 F254
G1 X107.886 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X14.861 Y36.307 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 Y36.311 Z-8.065 F254
G1 X14.864 Y36.321 Z-8.081 F254
G1 X14.868 Y36.337 Z-8.092 F254
G1 X14.873 Y36.356 Z-8.096 F254
G3 X15.097 Y37.91 I-7.063 J1.809 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y38.218 F254
G1 X15.104 Y38.294 F254
G1 X15.107 Y38.446 F254
G1 X15.079 Y38.752 F254
G1 X15.029 Y39.055 F254
G1 X15.018 Y39.362 F254
G1 X15.064 Y39.665 F254
G1 X15.123 Y39.967 F254
G1 X15.187 Y40.267 F254
G1 X15.294 Y40.555 F254
G1 X15.408 Y40.84 F254
G1 X15.526 Y41.123 F254
G1 X15.681 Y41.389 F254
G1 X15.84 Y41.652 F254
G1 X16 Y41.914 F254
G1 X16.196 Y42.15 F254
G1 X16.403 Y42.377 F254
G1 X16.608 Y42.605 F254
G1 X16.835 Y42.812 F254
G1 X17.346 Y43.153 F254
G1 X17.613 Y43.305 F254
G1 X17.901 Y43.411 F254
G1 X18.19 Y43.513 F254
G1 X18.49 Y43.579 F254
G1 X18.797 Y43.599 F254
G1 X19.41 Y43.635 F254
G1 X19.716 Y43.616 F254
G1 X20.022 Y43.583 F254
G1 X20.327 Y43.551 F254
G1 X20.634 Y43.539 F254
G1 X20.787 Y43.535 F254
G1 X20.99 Y43.536 F254
G1 X21.296 Y43.56 F254
G1 X21.448 Y43.58 F254
G1 X21.75 Y43.637 F254
G1 X22.048 Y43.708 F254
G1 X22.647 Y43.847 F254
G1 X22.945 Y43.921 F254
G1 X24.134 Y44.227 F254
G1 X24.433 Y44.298 F254
G1 X24.738 Y44.331 F254
G1 X26.263 Y44.507 F254
G1 X26.57 Y44.511 F254
G1 X26.875 Y44.473 F254
G1 X27.332 Y44.419 F254
G1 X27.37 Y44.413 F254
G1 X27.436 Y44.452 F254
G1 X27.534 Y44.569 F254
G1 X27.592 Y44.709 F254
G1 X27.663 Y44.948 F254
G1 X27.729 Y45.248 F254
G1 X27.912 Y46.151 F254
G1 X27.978 Y46.45 F254
G1 X28.057 Y46.747 F254
G1 X28.133 Y47.045 F254
G1 X28.229 Y47.336 F254
G1 X28.369 Y47.61 F254
G1 X28.503 Y47.886 F254
G1 X28.668 Y48.145 F254
G1 X28.879 Y48.368 F254
G1 X29.119 Y48.56 F254
G1 X29.36 Y48.75 F254
G1 X29.621 Y48.912 F254
G1 X29.906 Y49.026 F254
G1 X30.205 Y49.093 F254
G1 X30.507 Y49.154 F254
G1 X30.809 Y49.205 F254
G1 X31.116 Y49.204 F254
G1 X31.42 Y49.157 F254
G1 X31.723 Y49.107 F254
G1 X32.025 Y49.05 F254
G1 X32.312 Y48.941 F254
G1 X32.581 Y48.793 F254
G1 X32.846 Y48.638 F254
G1 X33.08 Y48.439 F254
G1 X33.283 Y48.209 F254
G1 X33.48 Y47.973 F254
G1 X33.634 Y47.708 F254
G1 X33.742 Y47.42 F254
G1 X33.816 Y47.122 F254
G1 X33.894 Y46.825 F254
G1 X33.957 Y46.525 F254
G1 X33.972 Y46.218 F254
G1 X33.947 Y45.912 F254
G1 X33.908 Y45.299 F254
G1 X33.867 Y44.995 F254
G1 X33.855 Y44.919 F254
G1 X33.931 Y44.924 F254
G1 X34.063 Y45 F254
G1 X34.161 Y45.117 F254
G1 X34.299 Y45.328 F254
G1 X34.448 Y45.597 F254
G1 X34.595 Y45.866 F254
G1 X34.881 Y46.41 F254
G1 X35.02 Y46.684 F254
G1 X35.708 Y48.056 F254
G1 X35.858 Y48.324 F254
G1 X36.304 Y49.13 F254
G1 X36.457 Y49.396 F254
G1 X36.642 Y49.641 F254
G1 X36.832 Y49.883 F254
G1 X37.026 Y50.121 F254
G1 X37.251 Y50.33 F254
G1 X37.479 Y50.535 F254
G1 X37.712 Y50.736 F254
G1 X37.97 Y50.902 F254
G1 X38.23 Y51.065 F254
G1 X38.497 Y51.216 F254
G1 X38.782 Y51.332 F254
G1 X39.064 Y51.453 F254
G1 X39.362 Y51.526 F254
G1 X39.664 Y51.585 F254
G1 X39.964 Y51.647 F254
G1 X40.268 Y51.693 F254
G1 X40.575 Y51.683 F254
G1 X40.881 Y51.66 F254
G1 X41.184 Y51.609 F254
G1 X41.472 Y51.504 F254
G1 X41.756 Y51.387 F254
G1 X42.027 Y51.242 F254
G1 X42.266 Y51.049 F254
G1 X42.47 Y50.82 F254
G1 X42.652 Y50.573 F254
G1 X42.822 Y50.317 F254
G1 X42.946 Y50.036 F254
G1 X43.017 Y49.737 F254
G1 X43.046 Y49.431 F254
G1 X43.073 Y49.126 F254
G1 X43.055 Y48.819 F254
G1 X43.018 Y48.67 F254
G1 X42.989 Y48.567 F254
G1 X43.058 Y48.534 F254
G1 X43.211 Y48.531 F254
G1 X43.356 Y48.579 F254
G1 X43.601 Y48.689 F254
G1 X44.411 Y49.127 F254
G1 X44.689 Y49.258 F254
G1 X44.984 Y49.344 F254
G1 X45.281 Y49.419 F254
G1 X45.587 Y49.453 F254
G1 X45.893 Y49.433 F254
G1 X46.199 Y49.403 F254
G1 X46.495 Y49.324 F254
G1 X46.775 Y49.198 F254
G1 X47.03 Y49.026 F254
G1 X47.249 Y48.811 F254
G1 X47.429 Y48.563 F254
G1 X47.587 Y48.299 F254
G1 X47.654 Y48.161 F254
G1 X47.669 Y48.126 F254
G1 X47.736 Y48.161 F254
G1 X47.825 Y48.285 F254
G1 X47.865 Y48.432 F254
G1 X47.913 Y48.735 F254
G1 X47.952 Y49.04 F254
G1 X48.031 Y49.336 F254
G1 X48.105 Y49.634 F254
G1 X48.183 Y49.931 F254
G1 X48.288 Y50.22 F254
G1 X48.492 Y50.799 F254
G1 X48.735 Y51.363 F254
G1 X48.866 Y51.641 F254
G1 X49.138 Y52.191 F254
G1 X49.435 Y52.729 F254
G1 X49.584 Y52.997 F254
G1 X49.741 Y53.261 F254
G1 X50.221 Y54.048 F254
G1 X50.395 Y54.3 F254
G1 X51.607 Y56.075 F254
G1 X51.794 Y56.319 F254
G1 X52.904 Y57.789 F254
G1 X53.092 Y58.032 F254
G1 X54.233 Y59.479 F254
G1 X54.42 Y59.723 F254
G1 X55.164 Y60.699 F254
G1 X55.346 Y60.947 F254
G1 X55.887 Y61.692 F254
G1 X56.057 Y61.948 F254
G1 X56.185 Y62.139 F254
G1 X56.232 Y62.284 F254
G1 X56.201 Y62.433 F254
G1 X56.113 Y62.727 F254
G1 X56.035 Y63.024 F254
G1 X55.959 Y63.322 F254
G1 X55.922 Y63.627 F254
G1 X55.942 Y63.933 F254
G1 X55.972 Y64.239 F254
G1 X56.007 Y64.544 F254
G1 X56.094 Y64.838 F254
G1 X56.198 Y65.127 F254
G1 X56.249 Y65.272 F254
G1 X56.257 Y65.309 F254
G1 X56.248 Y65.384 F254
G1 X56.187 Y65.524 F254
G1 X56.088 Y65.64 F254
G1 X55.979 Y65.747 F254
G1 X55.755 Y65.934 F254
G1 X55.587 Y66.054 F254
G1 X55.511 Y66.05 F254
G1 X55.371 Y65.989 F254
G1 X55.272 Y65.874 F254
G1 X55.15 Y65.687 F254
G1 X55.001 Y65.419 F254
G1 X54.843 Y65.156 F254
G1 X54.677 Y64.897 F254
G1 X54.501 Y64.646 F254
G1 X54.302 Y64.411 F254
G1 X54.1 Y64.18 F254
G1 X53.88 Y63.966 F254
G1 X53.661 Y63.75 F254
G1 X53.422 Y63.558 F254
G1 X53.185 Y63.362 F254
G1 X52.942 Y63.175 F254
G1 X52.687 Y63.004 F254
G1 X52.18 Y62.658 F254
G1 X51.91 Y62.512 F254
G1 X51.641 Y62.363 F254
G1 X51.372 Y62.214 F254
G1 X51.102 Y62.069 F254
G1 X50.816 Y61.956 F254
G1 X49.966 Y61.602 F254
G1 X49.672 Y61.512 F254
G1 X49.375 Y61.435 F254
G1 X48.781 Y61.277 F254
G1 X48.484 Y61.201 F254
G1 X48.18 Y61.16 F254
G1 X47.875 Y61.126 F254
G1 X47.265 Y61.056 F254
G1 X46.958 Y61.039 F254
G1 X46.651 Y61.047 F254
G1 X46.037 Y61.062 F254
G1 X45.731 Y61.088 F254
G1 X45.427 Y61.131 F254
G1 X45.123 Y61.171 F254
G1 X44.82 Y61.22 F254
G1 X44.526 Y61.31 F254
G1 X43.346 Y61.651 F254
G1 X43.054 Y61.746 F254
G1 X42.778 Y61.881 F254
G1 X41.679 Y62.429 F254
G1 X41.406 Y62.569 F254
G1 X41.152 Y62.742 F254
G1 X40.903 Y62.921 F254
G1 X39.903 Y63.635 F254
G1 X39.672 Y63.837 F254
G1 X39.449 Y64.048 F254
G1 X38.778 Y64.679 F254
G1 X38.556 Y64.891 F254
G1 X38.351 Y65.12 F254
G1 X38.156 Y65.357 F254
G1 X37.567 Y66.066 F254
G1 X37.374 Y66.304 F254
G1 X36.547 Y67.598 F254
G1 X36.4 Y67.868 F254
G1 X36.269 Y68.145 F254
G1 X35.868 Y68.974 F254
G1 X35.743 Y69.255 F254
G1 X35.64 Y69.544 F254
G1 X35.324 Y70.409 F254
G1 X35.227 Y70.701 F254
G1 X35.151 Y70.998 F254
G1 X34.993 Y71.592 F254
G1 X34.917 Y71.889 F254
G1 X34.869 Y72.192 F254
G1 X34.765 Y72.798 F254
G1 X34.73 Y73.103 F254
G1 X34.705 Y73.409 F254
G1 X34.679 Y73.715 F254
G1 X34.678 Y74.022 F254
G1 X34.675 Y74.329 F254
G1 X34.701 Y74.635 F254
G1 X34.802 Y75.859 F254
G1 X34.804 Y75.936 F254
G1 X34.795 Y76.088 F254
G1 X34.767 Y76.274 F254
G1 X34.703 Y76.556 F254
G1 X34.614 Y76.85 F254
G1 X34.536 Y77.147 F254
G1 X34.475 Y77.448 F254
G1 X34.349 Y78.049 F254
G1 X34.309 Y78.353 F254
G1 X34.182 Y79.265 F254
G1 X34.073 Y80.489 F254
G1 X34.055 Y80.795 F254
G1 X34.03 Y81.409 F254
G1 X34.017 Y81.716 F254
G1 X34.008 Y82.023 F254
G1 X34.015 Y82.33 F254
G1 X34.03 Y83.251 F254
G1 X34.061 Y83.556 F254
G1 X34.115 Y84.168 F254
G1 X34.144 Y84.474 F254
G1 X34.194 Y84.777 F254
G1 X34.288 Y85.383 F254
G1 X34.343 Y85.686 F254
G1 X34.409 Y85.985 F254
G1 X34.474 Y86.286 F254
G1 X34.54 Y86.585 F254
G1 X34.623 Y86.881 F254
G1 X34.702 Y87.178 F254
G1 X34.787 Y87.473 F254
G1 X34.882 Y87.765 F254
G1 X34.975 Y88.058 F254
G1 X35.186 Y88.634 F254
G1 X35.556 Y89.478 F254
G1 X35.707 Y89.745 F254
G1 X35.872 Y90.004 F254
G1 X36.361 Y90.785 F254
G1 X36.525 Y91.045 F254
G1 X36.718 Y91.283 F254
G1 X36.923 Y91.512 F254
G1 X37.126 Y91.742 F254
G1 X37.34 Y91.963 F254
G1 X37.569 Y92.167 F254
G1 X38.024 Y92.579 F254
G1 X38.273 Y92.759 F254
G1 X38.768 Y93.122 F254
G1 X39.027 Y93.288 F254
G1 X39.296 Y93.436 F254
G1 X39.563 Y93.586 F254
G1 X39.833 Y93.734 F254
G1 X40.115 Y93.854 F254
G1 X40.403 Y93.963 F254
G1 X40.689 Y94.073 F254
G1 X40.978 Y94.177 F254
G1 X41.278 Y94.244 F254
G1 X41.576 Y94.316 F254
G1 X41.875 Y94.387 F254
G1 X42.177 Y94.44 F254
G1 X42.781 Y94.551 F254
G1 X43.683 Y94.739 F254
G1 X43.983 Y94.807 F254
G1 X46.073 Y95.307 F254
G1 X46.371 Y95.379 F254
G1 X46.966 Y95.533 F254
G1 X47.857 Y95.767 F254
G1 X48.153 Y95.847 F254
G1 X49.042 Y96.091 F254
G1 X49.336 Y96.178 F254
G1 X49.63 Y96.269 F254
G1 X50.213 Y96.461 F254
G1 X50.501 Y96.567 F254
G1 X50.787 Y96.678 F254
G1 X51.069 Y96.8 F254
G1 X51.343 Y96.938 F254
G1 X51.895 Y97.209 F254
G1 X52.03 Y97.281 F254
G1 X52.294 Y97.438 F254
G1 X52.551 Y97.605 F254
G1 X53.068 Y97.937 F254
G1 X53.324 Y98.107 F254
G1 X53.572 Y98.288 F254
G1 X53.821 Y98.467 F254
G1 X54.811 Y99.195 F254
G1 X55.059 Y99.376 F254
G1 X57.555 Y101.163 F254
G1 X57.809 Y101.336 F254
G1 X58.065 Y101.506 F254
G1 X58.322 Y101.675 F254
G1 X58.582 Y101.837 F254
G1 X58.842 Y102.001 F254
G1 X59.114 Y102.144 F254
G1 X59.934 Y102.563 F254
G1 X60.221 Y102.672 F254
G1 X60.516 Y102.757 F254
G1 X61.104 Y102.935 F254
G1 X61.4 Y103.016 F254
G1 X61.703 Y103.064 F254
G1 X62.006 Y103.116 F254
G1 X62.31 Y103.156 F254
G1 X62.921 Y103.225 F254
G1 X63.227 Y103.244 F254
G1 X64.76 Y103.327 F254
G1 X65.067 Y103.338 F254
G1 X65.374 Y103.329 F254
G1 X65.681 Y103.323 F254
G1 X65.988 Y103.313 F254
G1 X66.294 Y103.285 F254
G1 X66.447 Y103.272 F254
G1 X66.754 Y103.263 F254
G1 X66.983 Y103.266 F254
G1 X67.128 Y103.311 F254
G1 X67.296 Y103.389 F254
G1 X67.564 Y103.54 F254
G1 X67.823 Y103.704 F254
G1 X68.085 Y103.865 F254
G1 X68.356 Y104.009 F254
G1 X68.629 Y104.15 F254
G1 X68.902 Y104.289 F254
G1 X69.189 Y104.4 F254
G1 X69.479 Y104.499 F254
G1 X69.769 Y104.6 F254
G1 X70.062 Y104.691 F254
G1 X70.365 Y104.746 F254
G1 X70.967 Y104.865 F254
G1 X71.272 Y104.905 F254
G1 X71.577 Y104.934 F254
G1 X71.883 Y104.965 F254
G1 X72.188 Y104.993 F254
G1 X72.495 Y104.985 F254
G1 X73.109 Y104.957 F254
G1 X73.415 Y104.937 F254
G1 X73.716 Y104.873 F254
G1 X74.313 Y104.733 F254
G1 X74.612 Y104.661 F254
G1 X74.901 Y104.557 F254
G1 X75.174 Y104.416 F254
G1 X75.724 Y104.144 F254
G1 X75.999 Y104.007 F254
G1 X76.261 Y103.846 F254
G1 X76.492 Y103.644 F254
G1 X76.718 Y103.437 F254
G1 X76.937 Y103.222 F254
G1 X77.118 Y102.973 F254
G1 X77.288 Y102.718 F254
G1 X77.45 Y102.457 F254
G1 X77.565 Y102.172 F254
G1 X77.651 Y101.877 F254
G1 X77.83 Y101.29 F254
G1 X77.905 Y100.992 F254
G1 X77.969 Y100.381 F254
G1 X77.984 Y100.075 F254
G1 Y99.768 F254
G1 X77.973 Y99.461 F254
G1 X77.936 Y99.156 F254
G1 X77.898 Y98.851 F254
G1 X77.821 Y98.554 F254
G1 X77.736 Y98.259 F254
G1 X77.621 Y97.974 F254
G1 X77.559 Y97.834 F254
G1 X77.502 Y97.692 F254
G1 X77.48 Y97.541 F254
G1 X77.49 Y97.389 F254
G1 X77.522 Y97.24 F254
G1 X77.61 Y96.946 F254
G1 X77.717 Y96.658 F254
G1 X77.818 Y96.369 F254
G1 X77.961 Y95.771 F254
G1 X78.017 Y95.469 F254
G1 X78.046 Y95.164 F254
G1 X78.08 Y94.858 F254
G1 X78.105 Y94.552 F254
G1 X78.104 Y94.245 F254
G1 X78.113 Y92.71 F254
G1 X78.101 Y92.403 F254
G1 X78.077 Y92.097 F254
G1 X77.964 Y90.566 F254
G1 X77.934 Y90.26 F254
G1 X77.885 Y89.957 F254
G1 X77.793 Y89.35 F254
G1 X77.727 Y89.05 F254
G1 X77.591 Y88.451 F254
G1 X77.512 Y88.155 F254
G1 X77.414 Y87.864 F254
G1 X77.031 Y86.697 F254
G1 X76.926 Y86.408 F254
G1 X76.796 Y86.13 F254
G1 X76.29 Y85.011 F254
G1 X76.154 Y84.736 F254
G1 X75.995 Y84.473 F254
G1 X74.435 Y81.828 F254
G1 X74.268 Y81.57 F254
G1 X72.937 Y79.506 F254
G1 X72.776 Y79.244 F254
G1 X72.463 Y78.716 F254
G1 X71.837 Y77.659 F254
G1 X71.688 Y77.391 F254
G1 X71.55 Y77.116 F254
G1 X71.411 Y76.843 F254
G1 X71.274 Y76.568 F254
G1 X71.15 Y76.287 F254
G1 X70.898 Y75.727 F254
G1 X70.779 Y75.444 F254
G1 X70.551 Y74.874 F254
G1 X70.436 Y74.589 F254
G1 X70.326 Y74.302 F254
G1 X70.114 Y73.726 F254
G1 X69.796 Y72.861 F254
G1 X69.694 Y72.571 F254
G1 X69.493 Y71.991 F254
G1 X69.393 Y71.701 F254
G1 X69.203 Y71.117 F254
G1 X69.117 Y70.822 F254
G1 X69.046 Y70.523 F254
G1 X69.032 Y70.448 F254
G1 X69.01 Y70.297 F254
G1 X69.021 Y70.145 F254
G1 X69.071 Y70.001 F254
G1 X69.144 Y69.868 F254
G1 X69.234 Y69.744 F254
G1 X69.425 Y69.529 F254
G1 X69.646 Y69.315 F254
G1 X69.864 Y69.1 F254
G1 X70.48 Y68.414 F254
G1 X70.684 Y68.186 F254
G1 X70.868 Y67.94 F254
G1 X71.036 Y67.683 F254
G1 X71.207 Y67.427 F254
G1 X71.361 Y67.162 F254
G1 X71.503 Y66.889 F254
G1 X71.646 Y66.618 F254
G1 X71.784 Y66.344 F254
G1 X71.908 Y66.063 F254
G1 X72.033 Y65.782 F254
G1 X72.147 Y65.497 F254
G1 X72.263 Y65.213 F254
G1 X72.373 Y64.926 F254
G1 X72.59 Y64.352 F254
G1 X72.695 Y64.063 F254
G1 X73.004 Y63.195 F254
G1 X73.582 Y61.446 F254
G1 X73.675 Y61.153 F254
G1 X73.761 Y60.858 F254
G1 X74.021 Y59.975 F254
G1 X74.104 Y59.679 F254
G1 X74.257 Y59.084 F254
G1 X74.334 Y58.787 F254
G1 X74.407 Y58.489 F254
G1 X74.54 Y57.889 F254
G1 X74.605 Y57.589 F254
G1 X74.66 Y57.287 F254
G1 X74.716 Y56.985 F254
G1 X74.771 Y56.683 F254
G1 X74.922 Y55.774 F254
G1 X74.976 Y55.472 F254
G1 X75.248 Y53.961 F254
G1 X75.316 Y53.662 F254
G1 X75.456 Y53.064 F254
G1 X75.545 Y52.77 F254
G1 X75.631 Y52.475 F254
G1 X75.675 Y52.328 F254
G1 X75.778 Y52.039 F254
G1 X75.893 Y51.754 F254
G1 X75.949 Y51.611 F254
G1 X76.009 Y51.471 F254
G1 X76.153 Y51.2 F254
G1 X76.274 Y51.005 F254
G1 X76.395 Y50.912 F254
G1 X76.546 Y50.891 F254
G1 X76.766 F254
G1 X77.072 Y50.912 F254
G1 X77.378 Y50.937 F254
G1 X77.686 Y50.935 F254
G1 X78.3 Y50.926 F254
G1 X78.605 Y50.896 F254
G1 X78.907 Y50.841 F254
G1 X79.21 Y50.788 F254
G1 X79.505 Y50.704 F254
G1 X79.801 Y50.624 F254
G1 X80.092 Y50.524 F254
G1 X80.377 Y50.41 F254
G1 X81.234 Y50.072 F254
G1 X81.517 Y49.954 F254
G1 X81.79 Y49.812 F254
G1 X82.611 Y49.395 F254
G1 X82.881 Y49.249 F254
G1 X83.13 Y49.07 F254
G1 X83.881 Y48.535 F254
G1 X84.104 Y48.325 F254
G1 X84.681 Y47.607 F254
G1 X84.87 Y47.364 F254
G1 X84.908 Y47.298 F254
G1 X84.926 Y47.264 F254
G1 X85.001 Y47.249 F254
G1 X85.148 Y47.288 F254
G1 X85.273 Y47.375 F254
G1 X85.505 Y47.576 F254
G1 X85.745 Y47.768 F254
G1 X86.012 Y47.919 F254
G1 X86.543 Y48.228 F254
G1 X86.821 Y48.358 F254
G1 X87.118 Y48.437 F254
G1 X87.419 Y48.495 F254
G1 X87.72 Y48.556 F254
G1 X88.024 Y48.605 F254
G1 X88.328 Y48.641 F254
G1 X88.48 Y48.665 F254
G1 X88.781 Y48.726 F254
G1 X89.08 Y48.798 F254
G1 X89.377 Y48.876 F254
G1 X89.969 Y49.038 F254
G1 X90.268 Y49.105 F254
G1 X90.573 Y49.147 F254
G1 X90.876 Y49.192 F254
G1 X91.183 Y49.215 F254
G1 X91.488 Y49.184 F254
G1 X91.783 Y49.098 F254
G1 X92.061 Y48.969 F254
G1 X92.33 Y48.82 F254
G1 X92.572 Y48.632 F254
G1 X92.778 Y48.403 F254
G1 X92.944 Y48.145 F254
G1 X93.061 Y47.861 F254
G1 X93.127 Y47.561 F254
G1 X93.17 Y47.257 F254
G1 X93.179 Y46.95 F254
G1 X93.135 Y46.646 F254
G1 X93.055 Y46.35 F254
G1 X92.97 Y46.055 F254
G1 X92.848 Y45.773 F254
G1 X92.731 Y45.489 F254
G1 X92.613 Y45.25 F254
G1 X92.683 Y45.219 F254
G1 X92.835 Y45.217 F254
G1 X93.129 Y45.305 F254
G1 X93.419 Y45.408 F254
G1 X93.718 Y45.479 F254
G1 X94.017 Y45.546 F254
G1 X94.324 Y45.564 F254
G1 X94.631 Y45.561 F254
G1 X94.937 Y45.545 F254
G1 X95.237 Y45.479 F254
G1 X95.52 Y45.359 F254
G1 X95.798 Y45.229 F254
G1 X96.064 Y45.076 F254
G1 X96.301 Y44.881 F254
G1 X96.498 Y44.645 F254
G1 X96.654 Y44.381 F254
G1 X96.786 Y44.103 F254
G1 X96.909 Y43.822 F254
G1 X96.984 Y43.524 F254
G1 X97.004 Y43.218 F254
G1 X96.98 Y42.912 F254
G1 X96.954 Y42.606 F254
G1 X96.898 Y42.304 F254
G1 X96.79 Y42.016 F254
G1 X96.677 Y41.737 F254
G1 X96.662 Y41.702 F254
G1 X96.723 Y41.656 F254
G1 X96.868 Y41.61 F254
G1 X97.021 F254
G1 X97.173 Y41.633 F254
G1 X97.382 Y41.681 F254
G1 X97.529 Y41.726 F254
G1 X97.815 Y41.838 F254
G1 X98.094 Y41.967 F254
G1 X98.374 Y42.093 F254
G1 X98.646 Y42.235 F254
G1 X98.914 Y42.386 F254
G1 X99.45 Y42.684 F254
G1 X99.726 Y42.819 F254
G1 X100.004 Y42.95 F254
G1 X100.56 Y43.211 F254
G1 X100.84 Y43.337 F254
G1 X101.133 Y43.428 F254
G1 X101.428 Y43.515 F254
G1 X101.724 Y43.594 F254
G1 X102.029 Y43.631 F254
G1 X102.334 Y43.667 F254
G1 X102.64 Y43.69 F254
G1 X102.946 Y43.663 F254
G1 X103.251 Y43.628 F254
G1 X103.555 Y43.58 F254
G1 X103.844 Y43.478 F254
G1 X104.128 Y43.361 F254
G1 X104.407 Y43.233 F254
G1 X104.656 Y43.052 F254
G1 X104.894 Y42.859 F254
G1 X105.12 Y42.651 F254
G1 X105.306 Y42.407 F254
G1 X105.47 Y42.147 F254
G1 X105.623 Y41.881 F254
G1 X105.728 Y41.592 F254
G1 X105.795 Y41.293 F254
G1 X105.861 Y40.993 F254
G1 X105.874 Y40.686 F254
G1 X105.842 Y40.381 F254
G1 X105.808 Y40.075 F254
G1 X105.735 Y39.777 F254
G1 X105.616 Y39.494 F254
G1 X105.493 Y39.213 F254
G1 X105.342 Y38.945 F254
G1 X104.965 Y38.461 F254
G1 X104.747 Y38.244 F254
G1 X104.503 Y38.058 F254
G1 X104.022 Y37.676 F254
G1 X103.769 Y37.503 F254
G1 X103.492 Y37.37 F254
G1 X102.943 Y37.094 F254
G1 X102.663 Y36.968 F254
G1 X102.369 Y36.881 F254
G1 X100.901 Y36.431 F254
G1 X100.606 Y36.346 F254
G1 X100.303 Y36.293 F254
G1 X98.492 Y35.958 F254
G1 X98.188 Y35.916 F254
G1 X94.841 Y35.46 F254
G1 X94.538 Y35.409 F254
G1 X94.237 Y35.35 F254
G1 X93.03 Y35.12 F254
G1 X92.136 Y34.899 F254
G1 X91.245 Y34.663 F254
G1 X90.947 Y34.593 F254
G1 X90.346 Y34.463 F254
G1 X90.044 Y34.411 F254
G1 X89.738 Y34.386 F254
G1 X89.432 Y34.357 F254
G1 X89.126 Y34.33 F254
G1 X88.819 Y34.34 F254
G1 X88.513 Y34.358 F254
G1 X87.899 Y34.392 F254
G1 X87.596 Y34.437 F254
G1 X86.687 Y34.586 F254
G1 X86.384 Y34.641 F254
G1 X85.782 Y34.762 F254
G1 X85.18 Y34.882 F254
G1 X84.876 Y34.925 F254
G1 X83.965 Y35.061 F254
G1 X83.659 Y35.085 F254
G1 X83.352 Y35.095 F254
G1 X82.585 Y35.126 F254
G1 X82.369 Y35.124 F254
G1 X82.063 Y35.1 F254
G1 X81.452 Y35.041 F254
G1 X80.994 Y34.997 F254
G1 X80.689 Y34.954 F254
G1 X80.389 Y34.892 F254
G1 X78.581 Y34.537 F254
G1 X78.279 Y34.48 F254
G1 X77.975 Y34.437 F254
G1 X77.669 Y34.413 F254
G1 X77.362 Y34.403 F254
G1 X77.056 Y34.423 F254
G1 X76.751 Y34.457 F254
G1 X76.453 Y34.531 F254
G1 X76.154 Y34.6 F254
G1 X75.702 Y34.691 F254
G1 X75.487 Y34.724 F254
G1 X75.257 Y34.742 F254
G1 X74.95 Y34.744 F254
G1 X74.643 Y34.736 F254
G1 X74.337 Y34.714 F254
G1 X74.03 Y34.692 F254
G1 X73.725 Y34.657 F254
G1 X73.42 Y34.624 F254
G1 X73.115 Y34.587 F254
G1 X72.811 Y34.543 F254
G1 X71.291 Y34.328 F254
G1 X69.16 Y34.047 F254
G1 X68.854 Y34.021 F254
G1 X68.242 Y33.97 F254
G1 X67.936 Y33.952 F254
G1 X67.629 Y33.949 F254
G1 X67.015 Y33.939 F254
G1 X66.709 Y33.971 F254
G1 X66.403 Y33.999 F254
G1 X66.098 Y34.032 F254
G1 X65.8 Y34.108 F254
G1 X65.505 Y34.191 F254
G1 X65.211 Y34.281 F254
G1 X64.936 Y34.416 F254
G1 X64.413 Y34.738 F254
G1 X64.182 Y34.94 F254
G1 X63.98 Y35.172 F254
G1 X63.78 Y35.405 F254
G1 X63.616 Y35.665 F254
G1 X63.486 Y35.943 F254
G1 X63.351 Y36.219 F254
G1 X63.247 Y36.423 F254
G1 X63.138 Y36.529 F254
G1 X63.001 Y36.596 F254
G1 X62.858 Y36.649 F254
G1 X62.711 Y36.691 F254
G1 X62.442 Y36.738 F254
G1 X62.136 Y36.768 F254
G1 X61.983 Y36.78 F254
G1 X61.676 Y36.788 F254
G1 X61.369 Y36.782 F254
G1 X61.062 Y36.779 F254
G1 X60.756 Y36.761 F254
G1 X60.45 Y36.731 F254
G1 X59.839 Y36.674 F254
G1 X59.535 Y36.629 F254
G1 X58.625 Y36.485 F254
G1 X58.324 Y36.424 F254
G1 X57.423 Y36.23 F254
G1 X57.126 Y36.154 F254
G1 X56.236 Y35.917 F254
G1 X55.943 Y35.825 F254
G1 X55.356 Y35.643 F254
G1 X54.776 Y35.442 F254
G1 X54.486 Y35.341 F254
G1 X54.199 Y35.232 F254
G1 X53.337 Y34.907 F254
G1 X52.467 Y34.605 F254
G1 X52.177 Y34.504 F254
G1 X51.883 Y34.416 F254
G1 X51.583 Y34.35 F254
G1 X50.686 Y34.141 F254
G1 X50.385 Y34.078 F254
G1 X50.08 Y34.043 F254
G1 X49.775 Y34.003 F254
G1 X49.471 Y33.967 F254
G1 X49.164 Y33.952 F254
G1 X48.551 Y33.917 F254
G1 X48.244 Y33.918 F254
G1 X47.937 Y33.93 F254
G1 X46.403 Y33.984 F254
G1 X46.096 Y34 F254
G1 X45.793 Y34.049 F254
G1 X44.277 Y34.293 F254
G1 X43.976 Y34.355 F254
G1 X43.68 Y34.435 F254
G1 X42.788 Y34.665 F254
G1 X42.491 Y34.743 F254
G1 X41.306 Y35.067 F254
G1 X41.008 Y35.141 F254
G1 X40.706 Y35.194 F254
G1 X40.102 Y35.306 F254
G1 X39.95 Y35.328 F254
G1 X39.644 Y35.355 F254
G1 X39.337 Y35.367 F254
G1 X39.184 Y35.374 F254
G1 X39.018 Y35.38 F254
G1 X38.711 Y35.368 F254
G1 X38.405 Y35.341 F254
G1 X38.252 Y35.329 F254
G1 X37.948 Y35.29 F254
G1 X37.646 Y35.233 F254
G1 X36.437 Y35.017 F254
G1 X36.133 Y34.975 F254
G1 X35.523 Y34.9 F254
G1 X35.217 Y34.872 F254
G1 X34.91 Y34.883 F254
G1 X34.297 Y34.898 F254
G1 X33.991 Y34.933 F254
G1 X33.692 Y35.002 F254
G1 X33.092 Y35.131 F254
G1 X32.797 Y35.218 F254
G1 X32.512 Y35.33 F254
G1 X31.937 Y35.548 F254
G1 X31.654 Y35.668 F254
G1 X30.451 Y36.172 F254
G1 X30.308 Y36.225 F254
G1 X30.014 Y36.304 F254
G1 X29.864 Y36.333 F254
G1 X29.679 Y36.338 F254
G1 X29.527 Y36.331 F254
G1 X29.376 Y36.308 F254
G1 X29.078 Y36.234 F254
G1 X28.786 Y36.14 F254
G1 X28.208 Y35.933 F254
G1 X27.918 Y35.832 F254
G1 X27.623 Y35.745 F254
G1 X27.324 Y35.675 F254
G1 X27.026 Y35.602 F254
G1 X26.727 Y35.53 F254
G1 X26.424 Y35.483 F254
G1 X26.118 Y35.454 F254
G1 X25.813 Y35.422 F254
G1 X25.507 Y35.396 F254
G1 X25.2 Y35.412 F254
G1 X23.975 Y35.495 F254
G1 X23.673 Y35.55 F254
G1 X23.382 Y35.647 F254
G1 X23.089 Y35.74 F254
G1 X22.802 Y35.85 F254
G1 X22.54 Y36.009 F254
G1 X22.285 Y36.18 F254
G1 X22.052 Y36.38 F254
G1 X21.862 Y36.621 F254
G1 X21.684 Y36.872 F254
G1 X21.61 Y37.006 F254
G1 X21.577 Y37.075 F254
G1 X21.562 Y37.11 F254
G1 X21.504 Y37.16 F254
G1 X21.358 Y37.202 F254
G1 X21.205 Y37.198 F254
G1 X20.928 Y37.16 F254
G1 X20.627 Y37.097 F254
G1 X20.025 Y36.974 F254
G1 X19.723 Y36.92 F254
G1 X19.42 Y36.873 F254
G1 X18.813 Y36.778 F254
G1 X18.508 Y36.739 F254
G1 X18.203 Y36.704 F254
G1 X17.897 Y36.683 F254
G1 X17.59 Y36.674 F254
G1 X17.285 Y36.708 F254
G1 X16.979 Y36.74 F254
G1 X16.679 Y36.805 F254
G1 X16.395 Y36.921 F254
G1 X16.135 Y37.085 F254
G1 X15.899 Y37.28 F254
G1 X15.661 Y37.475 F254
G1 X15.456 Y37.703 F254
G1 X15.373 Y37.833 F254
G1 X15.326 Y37.979 F254
G1 X15.291 Y38.284 F254
G1 X15.296 Y38.445 F254
G1 X15.286 Y38.652 F254
G1 X15.25 Y38.957 F254
G1 X15.217 Y39.262 F254
G1 X15.248 Y39.568 F254
G1 X15.308 Y39.869 F254
G1 X15.371 Y40.17 F254
G1 X15.471 Y40.46 F254
G1 X15.585 Y40.745 F254
G1 X15.703 Y41.028 F254
G1 X15.857 Y41.294 F254
G1 X16.016 Y41.557 F254
G1 X16.176 Y41.819 F254
G1 X16.376 Y42.052 F254
G1 X16.584 Y42.278 F254
G1 X16.789 Y42.507 F254
G1 X17.023 Y42.705 F254
G1 X17.283 Y42.868 F254
G1 X17.539 Y43.038 F254
G1 X17.815 Y43.173 F254
G1 X18.106 Y43.271 F254
G1 X18.4 Y43.36 F254
G1 X18.705 Y43.396 F254
G1 X19.012 Y43.411 F254
G1 X19.318 Y43.429 F254
G1 X19.625 Y43.424 F254
G1 X20.236 Y43.359 F254
G1 X20.542 Y43.342 F254
G1 X20.849 Y43.334 F254
G1 X21.156 Y43.347 F254
G1 X21.431 Y43.376 F254
G1 X21.733 Y43.43 F254
G1 X22.032 Y43.499 F254
G1 X22.331 Y43.569 F254
G1 X22.631 Y43.638 F254
G1 X22.929 Y43.71 F254
G1 X24.118 Y44.016 F254
G1 X24.417 Y44.089 F254
G1 X24.721 Y44.13 F254
G1 X25.026 Y44.163 F254
G1 X26.246 Y44.303 F254
G1 X26.553 Y44.312 F254
G1 X26.858 Y44.273 F254
G1 X27.163 Y44.237 F254
G1 X27.315 Y44.226 F254
G1 X27.462 Y44.267 F254
G1 X27.585 Y44.357 F254
G1 X27.681 Y44.476 F254
G1 X27.751 Y44.611 F254
G1 X27.805 Y44.753 F254
G1 X27.876 Y44.993 F254
G1 X27.942 Y45.292 F254
G1 X28.002 Y45.594 F254
G1 X28.126 Y46.195 F254
G1 X28.195 Y46.494 F254
G1 X28.275 Y46.791 F254
G1 X28.354 Y47.088 F254
G1 X28.465 Y47.374 F254
G1 X28.753 Y47.916 F254
G1 X28.946 Y48.155 F254
G1 X29.179 Y48.355 F254
G1 X29.421 Y48.544 F254
G1 X29.677 Y48.714 F254
G1 X29.96 Y48.834 F254
G1 X30.259 Y48.9 F254
G1 X30.561 Y48.96 F254
G1 X30.863 Y49.011 F254
G1 X31.17 Y49 F254
G1 X31.472 Y48.945 F254
G1 X31.775 Y48.895 F254
G1 X32.074 Y48.826 F254
G1 X32.352 Y48.695 F254
G1 X32.617 Y48.54 F254
G1 X32.868 Y48.363 F254
G1 X33.08 Y48.141 F254
G1 X33.277 Y47.905 F254
G1 X33.442 Y47.646 F254
G1 X33.552 Y47.359 F254
G1 X33.624 Y47.061 F254
G1 X33.703 Y46.764 F254
G1 X33.766 Y46.464 F254
G1 X33.773 Y46.157 F254
G1 X33.741 Y45.851 F254
G1 X33.724 Y45.545 F254
G1 X33.702 Y45.238 F254
G1 X33.679 Y45.088 F254
G1 X33.677 Y45.012 F254
G1 X33.703 Y44.862 F254
G1 X33.726 Y44.801 F254
G1 X33.741 Y44.74 F254
G1 X33.892 Y44.719 F254
G1 X34.034 Y44.772 F254
G1 X34.163 Y44.855 F254
G1 X34.271 Y44.961 F254
G1 X34.366 Y45.082 F254
G1 X34.493 Y45.271 F254
G1 X34.645 Y45.537 F254
G1 X34.791 Y45.807 F254
G1 X34.933 Y46.08 F254
G1 X35.076 Y46.351 F254
G1 X35.214 Y46.625 F254
G1 X35.903 Y47.998 F254
G1 X36.055 Y48.265 F254
G1 X36.202 Y48.534 F254
G1 X36.5 Y49.071 F254
G1 X36.654 Y49.336 F254
G1 X36.846 Y49.576 F254
G1 X37.036 Y49.818 F254
G1 X37.235 Y50.051 F254
G1 X37.466 Y50.254 F254
G1 X37.695 Y50.458 F254
G1 X37.935 Y50.649 F254
G1 X38.46 Y50.968 F254
G1 X38.736 Y51.102 F254
G1 X39.022 Y51.216 F254
G1 X39.313 Y51.313 F254
G1 X39.614 Y51.372 F254
G1 X39.915 Y51.433 F254
G1 X40.218 Y51.484 F254
G1 X40.525 Y51.487 F254
G1 X40.831 Y51.463 F254
G1 X41.134 Y51.415 F254
G1 X41.422 Y51.309 F254
G1 X41.706 Y51.191 F254
G1 X41.974 Y51.042 F254
G1 X42.199 Y50.833 F254
G1 X42.392 Y50.593 F254
G1 X42.568 Y50.342 F254
G1 X42.717 Y50.074 F254
G1 X42.805 Y49.779 F254
G1 X42.843 Y49.474 F254
G1 X42.868 Y49.168 F254
G1 X42.859 Y48.862 F254
G1 X42.821 Y48.714 F254
G1 X42.818 Y48.562 F254
G1 X42.841 Y48.489 F254
G1 X42.847 Y48.452 F254
G1 X42.981 Y48.379 F254
G1 X43.131 Y48.351 F254
G1 X43.283 Y48.368 F254
G1 X43.429 Y48.409 F254
G1 X43.574 Y48.465 F254
G1 X43.852 Y48.595 F254
G1 X44.121 Y48.744 F254
G1 X44.391 Y48.889 F254
G1 X44.665 Y49.028 F254
G1 X44.954 Y49.131 F254
G1 X45.252 Y49.205 F254
G1 X45.556 Y49.251 F254
G1 X45.863 Y49.236 F254
G1 X46.168 Y49.205 F254
G1 X46.465 Y49.125 F254
G1 X46.74 Y48.99 F254
G1 X46.983 Y48.802 F254
G1 X47.184 Y48.57 F254
G1 X47.349 Y48.311 F254
G1 X47.461 Y48.097 F254
G1 X47.571 Y47.992 F254
G1 X47.611 Y47.955 F254
G1 X47.629 Y47.935 F254
G1 X47.645 Y47.913 F254
G1 X47.786 Y47.973 F254
G1 X47.897 Y48.077 F254
G1 X47.979 Y48.206 F254
G1 X48.033 Y48.348 F254
G1 X48.08 Y48.542 F254
G1 X48.181 Y49.148 F254
G1 X48.265 Y49.443 F254
G1 X48.339 Y49.741 F254
G1 X48.43 Y50.034 F254
G1 X48.537 Y50.322 F254
G1 X48.638 Y50.612 F254
G1 X48.75 Y50.898 F254
G1 X48.874 Y51.179 F254
G1 X49 Y51.459 F254
G1 X49.271 Y52.01 F254
G1 X49.415 Y52.281 F254
G1 X49.565 Y52.549 F254
G1 X49.713 Y52.818 F254
G1 X49.867 Y53.084 F254
G1 X50.347 Y53.87 F254
G1 X50.516 Y54.126 F254
G1 X50.691 Y54.379 F254
G1 X51.73 Y55.9 F254
G1 X51.913 Y56.147 F254
G1 X52.099 Y56.391 F254
G1 X53.024 Y57.616 F254
G1 X53.211 Y57.86 F254
G1 X54.352 Y59.307 F254
G1 X54.539 Y59.55 F254
G1 X55.284 Y60.527 F254
G1 X55.467 Y60.773 F254
G1 X56.008 Y61.519 F254
G1 X56.181 Y61.773 F254
G1 X56.227 Y61.843 F254
G1 X56.31 Y61.971 F254
G1 X56.373 Y62.109 F254
G1 X56.402 Y62.259 F254
G1 X56.392 Y62.411 F254
G1 X56.336 Y62.685 F254
G1 X56.252 Y62.98 F254
G1 X56.177 Y63.278 F254
G1 X56.126 Y63.58 F254
G1 X56.137 Y63.887 F254
G1 X56.168 Y64.193 F254
G1 X56.203 Y64.498 F254
G1 X56.289 Y64.793 F254
G1 X56.342 Y64.937 F254
G1 X56.393 Y65.08 F254
G1 X56.431 Y65.228 F254
G1 X56.427 Y65.38 F254
G1 X56.386 Y65.527 F254
G1 X56.31 Y65.659 F254
G1 X56.215 Y65.778 F254
G1 X56.075 Y65.92 F254
G1 X55.922 Y66.053 F254
G1 X55.8 Y66.145 F254
G1 X55.663 Y66.212 F254
G1 X55.511 Y66.221 F254
G1 X55.363 Y66.184 F254
G1 X55.237 Y66.098 F254
G1 X55.131 Y65.989 F254
G1 X55.039 Y65.868 F254
G1 X54.874 Y65.608 F254
G1 X54.723 Y65.341 F254
G1 X54.558 Y65.082 F254
G1 X54.385 Y64.828 F254
G1 X54.193 Y64.589 F254
G1 X53.99 Y64.359 F254
G1 X53.774 Y64.14 F254
G1 X53.554 Y63.926 F254
G1 X53.318 Y63.73 F254
G1 X53.08 Y63.535 F254
G1 X52.838 Y63.347 F254
G1 X52.583 Y63.175 F254
G1 X52.076 Y62.829 F254
G1 X51.806 Y62.683 F254
G1 X51.537 Y62.534 F254
G1 X51.269 Y62.386 F254
G1 X50.998 Y62.241 F254
G1 X50.712 Y62.13 F254
G1 X50.429 Y62.01 F254
G1 X49.861 Y61.775 F254
G1 X49.566 Y61.69 F254
G1 X49.269 Y61.614 F254
G1 X48.972 Y61.535 F254
G1 X48.675 Y61.456 F254
G1 X48.378 Y61.381 F254
G1 X48.072 Y61.349 F254
G1 X47.462 Y61.28 F254
G1 X47.157 Y61.247 F254
G1 X46.85 Y61.238 F254
G1 X46.543 Y61.25 F254
G1 X46.236 Y61.257 F254
G1 X45.929 Y61.27 F254
G1 X45.624 Y61.304 F254
G1 X45.32 Y61.347 F254
G1 X45.016 Y61.39 F254
G1 X44.716 Y61.456 F254
G1 X44.423 Y61.548 F254
G1 X44.128 Y61.632 F254
G1 X43.538 Y61.803 F254
G1 X43.244 Y61.893 F254
G1 X42.96 Y62.01 F254
G1 X42.688 Y62.151 F254
G1 X41.863 Y62.561 F254
G1 X41.589 Y62.7 F254
G1 X41.328 Y62.861 F254
G1 X41.079 Y63.041 F254
G1 X40.08 Y63.755 F254
G1 X39.843 Y63.951 F254
G1 X39.396 Y64.372 F254
G1 X38.949 Y64.793 F254
G1 X38.726 Y65.004 F254
G1 X38.519 Y65.231 F254
G1 X38.324 Y65.468 F254
G1 X37.735 Y66.177 F254
G1 X37.542 Y66.415 F254
G1 X37.044 Y67.19 F254
G1 X36.714 Y67.708 F254
G1 X36.568 Y67.978 F254
G1 X36.438 Y68.256 F254
G1 X36.17 Y68.809 F254
G1 X36.036 Y69.085 F254
G1 X35.912 Y69.366 F254
G1 X35.813 Y69.657 F254
G1 X35.706 Y69.945 F254
G1 X35.496 Y70.522 F254
G1 X35.4 Y70.813 F254
G1 X35.329 Y71.112 F254
G1 X35.248 Y71.408 F254
G1 X35.17 Y71.705 F254
G1 X35.096 Y72.003 F254
G1 X35.053 Y72.307 F254
G1 X34.999 Y72.61 F254
G1 X34.95 Y72.913 F254
G1 X34.92 Y73.218 F254
G1 X34.897 Y73.524 F254
G1 X34.875 Y73.831 F254
G1 X34.881 Y74.445 F254
G1 X34.912 Y74.75 F254
G1 X34.937 Y75.056 F254
G1 X34.987 Y75.668 F254
G1 X34.998 Y75.839 F254
G1 X34.996 Y75.991 F254
G1 X34.98 Y76.168 F254
G1 X34.94 Y76.412 F254
G1 X34.868 Y76.711 F254
G1 X34.777 Y77.004 F254
G1 X34.706 Y77.303 F254
G1 X34.647 Y77.604 F254
G1 X34.584 Y77.904 F254
G1 X34.527 Y78.206 F254
G1 X34.489 Y78.511 F254
G1 X34.446 Y78.815 F254
G1 X34.404 Y79.119 F254
G1 X34.366 Y79.424 F254
G1 X34.342 Y79.73 F254
G1 X34.287 Y80.342 F254
G1 X34.263 Y80.648 F254
G1 X34.248 Y80.954 F254
G1 X34.236 Y81.261 F254
G1 X34.223 Y81.568 F254
G1 X34.212 Y81.875 F254
G1 X34.21 Y82.182 F254
G1 X34.218 Y82.489 F254
G1 X34.222 Y82.796 F254
G1 X34.228 Y83.103 F254
G1 X34.244 Y83.41 F254
G1 X34.276 Y83.715 F254
G1 X34.302 Y84.021 F254
G1 X34.331 Y84.327 F254
G1 X34.37 Y84.631 F254
G1 X34.421 Y84.934 F254
G1 X34.468 Y85.237 F254
G1 X34.519 Y85.54 F254
G1 X34.581 Y85.841 F254
G1 X34.648 Y86.141 F254
G1 X34.713 Y86.441 F254
G1 X34.789 Y86.738 F254
G1 X34.954 Y87.33 F254
G1 X35.045 Y87.623 F254
G1 X35.139 Y87.915 F254
G1 X35.24 Y88.205 F254
G1 X35.347 Y88.493 F254
G1 X35.465 Y88.776 F254
G1 X35.59 Y89.057 F254
G1 X35.713 Y89.338 F254
G1 X35.858 Y89.609 F254
G1 X36.022 Y89.869 F254
G1 X36.675 Y90.909 F254
G1 X36.866 Y91.149 F254
G1 X37.072 Y91.378 F254
G1 X37.275 Y91.608 F254
G1 X37.488 Y91.829 F254
G1 X37.719 Y92.032 F254
G1 X37.945 Y92.238 F254
G1 X38.173 Y92.444 F254
G1 X38.424 Y92.621 F254
G1 X38.671 Y92.804 F254
G1 X38.919 Y92.985 F254
G1 X39.179 Y93.148 F254
G1 X39.45 Y93.292 F254
G1 X39.717 Y93.444 F254
G1 X39.988 Y93.589 F254
G1 X40.274 Y93.701 F254
G1 X40.561 Y93.809 F254
G1 X40.848 Y93.92 F254
G1 X41.14 Y94.014 F254
G1 X41.441 Y94.076 F254
G1 X41.739 Y94.15 F254
G1 X42.039 Y94.216 F254
G1 X42.341 Y94.267 F254
G1 X42.643 Y94.323 F254
G1 X42.945 Y94.381 F254
G1 X43.245 Y94.444 F254
G1 X43.546 Y94.506 F254
G1 X43.846 Y94.57 F254
G1 X44.145 Y94.64 F254
G1 X44.743 Y94.783 F254
G1 X46.236 Y95.14 F254
G1 X46.534 Y95.215 F254
G1 X47.128 Y95.369 F254
G1 X48.019 Y95.604 F254
G1 X48.315 Y95.684 F254
G1 X48.908 Y95.846 F254
G1 X49.203 Y95.929 F254
G1 X49.497 Y96.018 F254
G1 X49.79 Y96.11 F254
G1 X50.372 Y96.305 F254
G1 X50.659 Y96.414 F254
G1 X50.945 Y96.527 F254
G1 X51.225 Y96.653 F254
G1 X51.499 Y96.792 F254
G1 X51.775 Y96.927 F254
G1 X52.05 Y97.063 F254
G1 X52.316 Y97.217 F254
G1 X52.575 Y97.381 F254
G1 X52.833 Y97.548 F254
G1 X53.091 Y97.714 F254
G1 X53.348 Y97.882 F254
G1 X53.599 Y98.059 F254
G1 X54.095 Y98.421 F254
G1 X54.837 Y98.966 F254
G1 X55.085 Y99.148 F254
G1 X55.335 Y99.327 F254
G1 X57.581 Y100.936 F254
G1 X57.834 Y101.111 F254
G1 X58.089 Y101.282 F254
G1 X58.345 Y101.451 F254
G1 X58.604 Y101.616 F254
G1 X58.865 Y101.779 F254
G1 X59.132 Y101.93 F254
G1 X59.406 Y102.068 F254
G1 X59.953 Y102.348 F254
G1 X60.236 Y102.466 F254
G1 X60.825 Y102.642 F254
G1 X61.119 Y102.73 F254
G1 X61.414 Y102.813 F254
G1 X62.02 Y102.916 F254
G1 X62.324 Y102.957 F254
G1 X62.934 Y103.026 F254
G1 X63.241 Y103.044 F254
G1 X64.774 Y103.127 F254
G1 X65.081 Y103.139 F254
G1 X65.388 Y103.128 F254
G1 X65.695 Y103.122 F254
G1 X66.002 Y103.113 F254
G1 X66.307 Y103.082 F254
G1 X66.614 Y103.066 F254
G1 X66.811 Y103.065 F254
G1 X66.963 Y103.076 F254
G1 X67.112 Y103.108 F254
G1 X67.255 Y103.16 F254
G1 X67.463 Y103.257 F254
G1 X67.731 Y103.406 F254
G1 X67.989 Y103.572 F254
G1 X68.252 Y103.732 F254
G1 X68.526 Y103.871 F254
G1 X68.798 Y104.012 F254
G1 X69.074 Y104.147 F254
G1 X69.364 Y104.249 F254
G1 X69.945 Y104.447 F254
G1 X70.242 Y104.526 F254
G1 X70.545 Y104.577 F254
G1 X70.846 Y104.638 F254
G1 X71.148 Y104.69 F254
G1 X71.453 Y104.722 F254
G1 X72.065 Y104.782 F254
G1 X72.372 Y104.792 F254
G1 X72.678 Y104.776 F254
G1 X72.985 Y104.763 F254
G1 X73.292 Y104.746 F254
G1 X73.595 Y104.698 F254
G1 X73.893 Y104.625 F254
G1 X74.192 Y104.555 F254
G1 X74.491 Y104.484 F254
G1 X74.783 Y104.389 F254
G1 X75.332 Y104.115 F254
G1 X75.883 Y103.842 F254
G1 X76.145 Y103.683 F254
G1 X76.376 Y103.48 F254
G1 X76.602 Y103.272 F254
G1 X76.82 Y103.056 F254
G1 X76.992 Y102.802 F254
G1 X77.162 Y102.546 F254
G1 X77.315 Y102.28 F254
G1 X77.413 Y101.989 F254
G1 X77.497 Y101.694 F254
G1 X77.588 Y101.4 F254
G1 X77.673 Y101.105 F254
G1 X77.728 Y100.803 F254
G1 X77.78 Y100.191 F254
G1 X77.785 Y99.884 F254
G1 X77.778 Y99.577 F254
G1 X77.751 Y99.271 F254
G1 X77.711 Y98.967 F254
G1 X77.646 Y98.667 F254
G1 X77.56 Y98.372 F254
G1 X77.451 Y98.085 F254
G1 X77.384 Y97.928 F254
G1 X77.334 Y97.784 F254
G1 X77.302 Y97.635 F254
G1 X77.296 Y97.482 F254
G1 X77.311 Y97.331 F254
G1 X77.352 Y97.126 F254
G1 X77.418 Y96.895 F254
G1 X77.523 Y96.606 F254
G1 X77.625 Y96.317 F254
G1 X77.768 Y95.719 F254
G1 X77.823 Y95.417 F254
G1 X77.85 Y95.111 F254
G1 X77.884 Y94.806 F254
G1 X77.909 Y94.5 F254
G1 X77.903 Y94.193 F254
G1 X77.907 Y93.886 F254
G1 X77.913 Y92.658 F254
G1 X77.898 Y92.351 F254
G1 X77.872 Y92.045 F254
G1 X77.85 Y91.739 F254
G1 X77.759 Y90.514 F254
G1 X77.727 Y90.209 F254
G1 X77.674 Y89.906 F254
G1 X77.629 Y89.603 F254
G1 X77.581 Y89.299 F254
G1 X77.511 Y89 F254
G1 X77.442 Y88.701 F254
G1 X77.373 Y88.402 F254
G1 X77.288 Y88.107 F254
G1 X77.188 Y87.817 F254
G1 X77.093 Y87.525 F254
G1 X76.901 Y86.941 F254
G1 X76.803 Y86.65 F254
G1 X76.689 Y86.365 F254
G1 X76.557 Y86.088 F254
G1 X76.431 Y85.808 F254
G1 X76.178 Y85.248 F254
G1 X76.048 Y84.97 F254
G1 X75.902 Y84.7 F254
G1 X75.742 Y84.438 F254
G1 X75.587 Y84.173 F254
G1 X74.339 Y82.057 F254
G1 X74.178 Y81.796 F254
G1 X74.009 Y81.539 F254
G1 X72.845 Y79.732 F254
G1 X72.681 Y79.473 F254
G1 X72.523 Y79.21 F254
G1 X72.367 Y78.945 F254
G1 X71.74 Y77.889 F254
G1 X71.587 Y77.622 F254
G1 X71.444 Y77.351 F254
G1 X71.306 Y77.076 F254
G1 X71.167 Y76.803 F254
G1 X71.035 Y76.525 F254
G1 X70.912 Y76.244 F254
G1 X70.785 Y75.964 F254
G1 X70.662 Y75.683 F254
G1 X70.546 Y75.399 F254
G1 X70.432 Y75.114 F254
G1 X70.317 Y74.829 F254
G1 X70.204 Y74.543 F254
G1 X70.095 Y74.256 F254
G1 X69.991 Y73.968 F254
G1 X69.672 Y73.103 F254
G1 X69.567 Y72.815 F254
G1 X69.265 Y71.944 F254
G1 X69.167 Y71.654 F254
G1 X69.073 Y71.361 F254
G1 X68.979 Y71.069 F254
G1 X68.898 Y70.773 F254
G1 X68.848 Y70.546 F254
G1 X68.826 Y70.395 F254
G1 X68.823 Y70.243 F254
G1 X68.847 Y70.092 F254
G1 X68.895 Y69.948 F254
G1 X68.961 Y69.811 F254
G1 X69.044 Y69.682 F254
G1 X69.168 Y69.523 F254
G1 X69.374 Y69.296 F254
G1 X69.597 Y69.084 F254
G1 X69.811 Y68.864 F254
G1 X70.014 Y68.634 F254
G1 X70.424 Y68.177 F254
G1 X70.622 Y67.942 F254
G1 X70.795 Y67.688 F254
G1 X70.963 Y67.431 F254
G1 X71.127 Y67.172 F254
G1 X71.272 Y66.901 F254
G1 X71.555 Y66.356 F254
G1 X71.684 Y66.077 F254
G1 X71.807 Y65.796 F254
G1 X71.927 Y65.513 F254
G1 X72.04 Y65.228 F254
G1 X72.153 Y64.943 F254
G1 X72.37 Y64.368 F254
G1 X72.476 Y64.08 F254
G1 X72.786 Y63.212 F254
G1 X72.885 Y62.922 F254
G1 X73.366 Y61.464 F254
G1 X73.46 Y61.171 F254
G1 X73.548 Y60.877 F254
G1 X73.807 Y59.993 F254
G1 X73.891 Y59.698 F254
G1 X73.969 Y59.401 F254
G1 X74.123 Y58.806 F254
G1 X74.196 Y58.508 F254
G1 X74.264 Y58.209 F254
G1 X74.33 Y57.909 F254
G1 X74.396 Y57.609 F254
G1 X74.453 Y57.307 F254
G1 X74.564 Y56.703 F254
G1 X74.716 Y55.795 F254
G1 X74.769 Y55.492 F254
G1 X75.041 Y53.981 F254
G1 X75.106 Y53.681 F254
G1 X75.246 Y53.083 F254
G1 X75.33 Y52.788 F254
G1 X75.506 Y52.199 F254
G1 X75.613 Y51.911 F254
G1 X75.803 Y51.445 F254
G1 X75.934 Y51.184 F254
G1 X76.014 Y51.049 F254
G1 X76.101 Y50.924 F254
G1 X76.211 Y50.818 F254
G1 X76.347 Y50.75 F254
G1 X76.495 Y50.715 F254
G1 X76.647 Y50.701 F254
G1 X76.904 Y50.7 F254
G1 X77.21 Y50.722 F254
G1 X77.517 Y50.74 F254
G1 X77.824 Y50.733 F254
G1 X78.131 Y50.728 F254
G1 X78.438 Y50.715 F254
G1 X78.741 Y50.67 F254
G1 X79.043 Y50.613 F254
G1 X79.343 Y50.546 F254
G1 X79.638 Y50.46 F254
G1 X79.931 Y50.37 F254
G1 X80.217 Y50.259 F254
G1 X80.503 Y50.145 F254
G1 X81.074 Y49.92 F254
G1 X81.358 Y49.804 F254
G1 X81.634 Y49.669 F254
G1 X81.907 Y49.528 F254
G1 X82.454 Y49.25 F254
G1 X82.726 Y49.106 F254
G1 X82.98 Y48.934 F254
G1 X83.229 Y48.754 F254
G1 X83.729 Y48.398 F254
G1 X83.956 Y48.191 F254
G1 X84.147 Y47.951 F254
G1 X84.533 Y47.473 F254
G1 X84.699 Y47.258 F254
G1 X84.801 Y47.145 F254
G1 X84.942 Y47.087 F254
G1 X85.094 Y47.091 F254
G1 X85.238 Y47.141 F254
G1 X85.369 Y47.219 F254
G1 X85.615 Y47.403 F254
G1 X85.851 Y47.599 F254
G1 X86.119 Y47.75 F254
G1 X86.649 Y48.059 F254
G1 X86.928 Y48.187 F254
G1 X87.227 Y48.257 F254
G1 X87.529 Y48.312 F254
G1 X87.83 Y48.374 F254
G1 X88.134 Y48.418 F254
G1 X88.426 Y48.453 F254
G1 X88.727 Y48.511 F254
G1 X89.027 Y48.579 F254
G1 X89.324 Y48.655 F254
G1 X89.621 Y48.735 F254
G1 X89.917 Y48.817 F254
G1 X90.215 Y48.89 F254
G1 X90.518 Y48.939 F254
G1 X90.822 Y48.982 F254
G1 X91.128 Y49.012 F254
G1 X91.434 Y48.991 F254
G1 X91.729 Y48.906 F254
G1 X92.006 Y48.773 F254
G1 X92.273 Y48.622 F254
G1 X92.504 Y48.419 F254
G1 X92.692 Y48.177 F254
G1 X92.833 Y47.904 F254
G1 X92.916 Y47.608 F254
G1 X92.962 Y47.304 F254
G1 X92.979 Y46.998 F254
G1 X92.941 Y46.693 F254
G1 X92.86 Y46.397 F254
G1 X92.775 Y46.102 F254
G1 X92.651 Y45.821 F254
G1 X92.535 Y45.537 F254
G1 X92.468 Y45.4 F254
G1 X92.448 Y45.249 F254
G1 X92.451 Y45.211 F254
G1 X92.452 Y45.173 F254
G1 X92.573 Y45.08 F254
G1 X92.721 Y45.043 F254
G1 X92.873 Y45.047 F254
G1 X93.023 Y45.076 F254
G1 X93.319 Y45.157 F254
G1 X93.61 Y45.254 F254
G1 X93.911 Y45.317 F254
G1 X94.214 Y45.364 F254
G1 X94.521 Y45.363 F254
G1 X94.828 Y45.351 F254
G1 X95.131 Y45.301 F254
G1 X95.416 Y45.187 F254
G1 X95.694 Y45.057 F254
G1 X95.961 Y44.905 F254
G1 X96.196 Y44.707 F254
G1 X96.382 Y44.463 F254
G1 X96.526 Y44.192 F254
G1 X96.652 Y43.912 F254
G1 X96.76 Y43.624 F254
G1 X96.802 Y43.32 F254
G1 X96.79 Y43.013 F254
G1 X96.762 Y42.707 F254
G1 X96.715 Y42.404 F254
G1 X96.615 Y42.114 F254
G1 X96.54 Y41.932 F254
G1 X96.493 Y41.787 F254
G1 X96.505 Y41.712 F254
G1 X96.571 Y41.575 F254
G1 X96.696 Y41.487 F254
G1 X96.841 Y41.441 F254
G1 X96.993 Y41.428 F254
G1 X97.145 Y41.439 F254
G1 X97.235 Y41.453 F254
G1 X97.39 Y41.485 F254
G1 X97.579 Y41.538 F254
G1 X97.846 Y41.635 F254
G1 X98.126 Y41.761 F254
G1 X98.406 Y41.888 F254
G1 X98.68 Y42.026 F254
G1 X99.485 Y42.475 F254
G1 X99.759 Y42.614 F254
G1 X100.592 Y43.005 F254
G1 X100.872 Y43.133 F254
G1 X101.163 Y43.23 F254
G1 X101.458 Y43.315 F254
G1 X101.755 Y43.395 F254
G1 X102.059 Y43.434 F254
G1 X102.364 Y43.469 F254
G1 X102.67 Y43.492 F254
G1 X102.976 Y43.459 F254
G1 X103.281 Y43.423 F254
G1 X103.583 Y43.369 F254
G1 X103.867 Y43.252 F254
G1 X104.15 Y43.133 F254
G1 X104.42 Y42.986 F254
G1 X104.658 Y42.793 F254
G1 X104.891 Y42.593 F254
G1 X105.094 Y42.362 F254
G1 X105.261 Y42.105 F254
G1 X105.417 Y41.84 F254
G1 X105.531 Y41.555 F254
G1 X105.598 Y41.256 F254
G1 X105.664 Y40.956 F254
G1 X105.675 Y40.649 F254
G1 X105.636 Y40.344 F254
G1 X105.602 Y40.039 F254
G1 X105.511 Y39.745 F254
G1 X105.385 Y39.466 F254
G1 X105.255 Y39.187 F254
G1 X105.084 Y38.932 F254
G1 X104.892 Y38.693 F254
G1 X104.689 Y38.462 F254
G1 X104.452 Y38.267 F254
G1 X104.209 Y38.08 F254
G1 X103.969 Y37.888 F254
G1 X103.719 Y37.709 F254
G1 X103.447 Y37.568 F254
G1 X103.171 Y37.433 F254
G1 X102.897 Y37.294 F254
G1 X102.618 Y37.167 F254
G1 X102.324 Y37.076 F254
G1 X101.443 Y36.806 F254
G1 X100.856 Y36.626 F254
G1 X100.561 Y36.541 F254
G1 X100.259 Y36.489 F254
G1 X99.655 Y36.377 F254
G1 X98.447 Y36.153 F254
G1 X96.013 Y35.822 F254
G1 X94.796 Y35.656 F254
G1 X94.494 Y35.604 F254
G1 X94.192 Y35.545 F254
G1 X92.986 Y35.315 F254
G1 X92.091 Y35.094 F254
G1 X91.201 Y34.859 F254
G1 X90.902 Y34.788 F254
G1 X90.302 Y34.658 F254
G1 X89.999 Y34.607 F254
G1 X89.693 Y34.583 F254
G1 X89.387 Y34.554 F254
G1 X89.081 Y34.527 F254
G1 X88.775 Y34.543 F254
G1 X88.468 Y34.561 F254
G1 X87.855 Y34.595 F254
G1 X87.552 Y34.648 F254
G1 X86.643 Y34.796 F254
G1 X86.342 Y34.853 F254
G1 X86.041 Y34.915 F254
G1 X85.438 Y35.035 F254
G1 X85.137 Y35.092 F254
G1 X84.833 Y35.133 F254
G1 X84.529 Y35.18 F254
G1 X84.073 Y35.246 F254
G1 X83.768 Y35.278 F254
G1 X83.461 Y35.292 F254
G1 X83.154 Y35.303 F254
G1 X82.542 Y35.327 F254
G1 X82.235 Y35.316 F254
G1 X81.93 Y35.288 F254
G1 X81.624 Y35.258 F254
G1 X81.013 Y35.2 F254
G1 X80.708 Y35.159 F254
G1 X80.407 Y35.101 F254
G1 X80.106 Y35.041 F254
G1 X78.599 Y34.745 F254
G1 X78.298 Y34.687 F254
G1 X77.994 Y34.641 F254
G1 X77.688 Y34.615 F254
G1 X77.381 Y34.603 F254
G1 X77.075 Y34.621 F254
G1 X76.77 Y34.656 F254
G1 X76.472 Y34.733 F254
G1 X76.173 Y34.801 F254
G1 X75.872 Y34.86 F254
G1 X75.605 Y34.909 F254
G1 X75.354 Y34.935 F254
G1 X75.047 Y34.944 F254
G1 X74.74 Y34.939 F254
G1 X74.434 Y34.922 F254
G1 X74.127 Y34.899 F254
G1 X73.822 Y34.87 F254
G1 X73.517 Y34.835 F254
G1 X73.212 Y34.8 F254
G1 X72.907 Y34.76 F254
G1 X72.603 Y34.715 F254
G1 X71.387 Y34.543 F254
G1 X71.083 Y34.502 F254
G1 X69.256 Y34.262 F254
G1 X68.951 Y34.228 F254
G1 X68.645 Y34.204 F254
G1 X68.339 Y34.178 F254
G1 X68.033 Y34.157 F254
G1 X67.726 Y34.149 F254
G1 X67.419 Y34.146 F254
G1 X67.112 Y34.141 F254
G1 X66.805 Y34.159 F254
G1 X66.194 Y34.222 F254
G1 X65.894 Y34.288 F254
G1 X65.599 Y34.372 F254
G1 X65.305 Y34.461 F254
G1 X65.028 Y34.593 F254
G1 X64.767 Y34.755 F254
G1 X64.506 Y34.916 F254
G1 X64.279 Y35.123 F254
G1 X63.887 Y35.596 F254
G1 X63.739 Y35.865 F254
G1 X63.612 Y36.144 F254
G1 X63.504 Y36.359 F254
G1 X63.426 Y36.49 F254
G1 X63.328 Y36.606 F254
G1 X63.205 Y36.697 F254
G1 X63.071 Y36.769 F254
G1 X62.929 Y36.825 F254
G1 X62.772 Y36.872 F254
G1 X62.581 Y36.914 F254
G1 X62.277 Y36.957 F254
G1 X61.971 Y36.982 F254
G1 X61.664 Y36.988 F254
G1 X61.357 Y36.982 F254
G1 X61.05 Y36.979 F254
G1 X60.744 Y36.96 F254
G1 X60.438 Y36.93 F254
G1 X59.826 Y36.874 F254
G1 X59.523 Y36.829 F254
G1 X58.613 Y36.685 F254
G1 X58.311 Y36.626 F254
G1 X57.411 Y36.432 F254
G1 X57.113 Y36.358 F254
G1 X56.223 Y36.121 F254
G1 X55.343 Y35.848 F254
G1 X55.052 Y35.75 F254
G1 X54.472 Y35.548 F254
G1 X54.184 Y35.44 F254
G1 X53.323 Y35.115 F254
G1 X53.033 Y35.012 F254
G1 X52.163 Y34.711 F254
G1 X51.869 Y34.62 F254
G1 X50.673 Y34.344 F254
G1 X50.372 Y34.28 F254
G1 X50.068 Y34.242 F254
G1 X49.763 Y34.204 F254
G1 X49.458 Y34.167 F254
G1 X49.151 Y34.152 F254
G1 X48.538 Y34.116 F254
G1 X48.231 Y34.118 F254
G1 X47.925 Y34.131 F254
G1 X46.39 Y34.184 F254
G1 X46.084 Y34.201 F254
G1 X45.781 Y34.255 F254
G1 X45.478 Y34.302 F254
G1 X44.265 Y34.498 F254
G1 X43.965 Y34.563 F254
G1 X43.669 Y34.645 F254
G1 X43.372 Y34.72 F254
G1 X42.777 Y34.874 F254
G1 X42.48 Y34.953 F254
G1 X42.184 Y35.035 F254
G1 X41.296 Y35.277 F254
G1 X40.997 Y35.349 F254
G1 X40.694 Y35.398 F254
G1 X40.392 Y35.456 F254
G1 X40.09 Y35.511 F254
G1 X39.785 Y35.544 F254
G1 X39.479 Y35.562 F254
G1 X39.172 Y35.575 F254
G1 X38.865 Y35.576 F254
G1 X38.558 Y35.556 F254
G1 X38.253 Y35.529 F254
G1 X37.948 Y35.492 F254
G1 X37.041 Y35.329 F254
G1 X36.437 Y35.22 F254
G1 X36.133 Y35.177 F254
G1 X35.523 Y35.101 F254
G1 X35.217 Y35.073 F254
G1 X34.911 Y35.083 F254
G1 X34.297 Y35.099 F254
G1 X33.992 Y35.134 F254
G1 X33.693 Y35.207 F254
G1 X33.393 Y35.27 F254
G1 X33.093 Y35.335 F254
G1 X32.8 Y35.427 F254
G1 X32.516 Y35.544 F254
G1 X32.228 Y35.651 F254
G1 X31.941 Y35.761 F254
G1 X31.659 Y35.883 F254
G1 X31.093 Y36.12 F254
G1 X30.528 Y36.356 F254
G1 X30.271 Y36.443 F254
G1 X30.091 Y36.488 F254
G1 X29.941 Y36.515 F254
G1 X29.789 Y36.529 F254
G1 X29.637 Y36.53 F254
G1 X29.485 Y36.519 F254
G1 X29.265 Y36.483 F254
G1 X29.031 Y36.427 F254
G1 X28.738 Y36.335 F254
G1 X28.159 Y36.129 F254
G1 X27.87 Y36.027 F254
G1 X27.575 Y35.94 F254
G1 X27.276 Y35.869 F254
G1 X26.978 Y35.796 F254
G1 X26.68 Y35.725 F254
G1 X26.376 Y35.679 F254
G1 X26.07 Y35.65 F254
G1 X25.765 Y35.617 F254
G1 X25.459 Y35.593 F254
G1 X25.153 Y35.616 F254
G1 X24.234 Y35.678 F254
G1 X23.927 Y35.7 F254
G1 X23.628 Y35.77 F254
G1 X23.339 Y35.872 F254
G1 X23.047 Y35.967 F254
G1 X22.768 Y36.096 F254
G1 X22.513 Y36.268 F254
G1 X22.268 Y36.453 F254
G1 X22.064 Y36.682 F254
G1 X21.886 Y36.932 F254
G1 X21.841 Y37.013 F254
G1 X21.766 Y37.146 F254
G1 X21.666 Y37.26 F254
G1 X21.533 Y37.335 F254
G1 X21.385 Y37.374 F254
G1 X21.233 Y37.383 F254
G1 X21.067 Y37.373 F254
G1 X20.815 Y37.34 F254
G1 X19.912 Y37.156 F254
G1 X19.61 Y37.104 F254
G1 X19.306 Y37.058 F254
G1 X19.003 Y37.01 F254
G1 X18.699 Y36.964 F254
G1 X18.394 Y36.927 F254
G1 X18.089 Y36.894 F254
G1 X17.782 Y36.878 F254
G1 X17.475 Y36.882 F254
G1 X17.171 Y36.922 F254
G1 X16.867 Y36.964 F254
G1 X16.574 Y37.059 F254
G1 X16.307 Y37.209 F254
G1 X16.066 Y37.4 F254
G1 X15.829 Y37.595 F254
G1 X15.618 Y37.818 F254
G1 X15.557 Y37.959 F254
G1 X15.488 Y38.258 F254
G1 X15.492 Y38.481 F254
G1 X15.474 Y38.788 F254
G1 X15.435 Y39.093 F254
G1 X15.423 Y39.399 F254
G1 X15.478 Y39.702 F254
G1 X15.54 Y40.002 F254
G1 X15.623 Y40.298 F254
G1 X15.736 Y40.584 F254
G1 X15.853 Y40.867 F254
G1 X15.996 Y41.139 F254
G1 X16.315 Y41.664 F254
G1 X16.508 Y41.902 F254
G1 X16.717 Y42.128 F254
G1 X16.922 Y42.356 F254
G1 X17.156 Y42.555 F254
G1 X17.417 Y42.716 F254
G1 X17.673 Y42.886 F254
G1 X17.952 Y43.015 F254
G1 X18.246 Y43.104 F254
G1 X18.542 Y43.184 F254
G1 X18.848 Y43.204 F254
G1 X19.155 Y43.219 F254
G1 X19.462 Y43.23 F254
G1 X19.768 Y43.211 F254
G1 X20.073 Y43.175 F254
G1 X20.379 Y43.15 F254
G1 X20.686 Y43.137 F254
G1 X20.993 Y43.138 F254
G1 X21.3 Y43.159 F254
G1 X21.604 Y43.202 F254
G1 X21.904 Y43.263 F254
G1 X22.801 Y43.473 F254
G1 X23.099 Y43.547 F254
G1 X23.991 Y43.777 F254
G1 X24.289 Y43.852 F254
G1 X24.59 Y43.915 F254
G1 X24.895 Y43.947 F254
G1 X25.2 Y43.982 F254
G1 X26.115 Y44.087 F254
G1 X26.421 Y44.111 F254
G1 X26.728 Y44.092 F254
G1 X27.032 Y44.051 F254
G1 X27.184 Y44.037 F254
G1 X27.336 Y44.047 F254
G1 X27.484 Y44.083 F254
G1 X27.619 Y44.154 F254
G1 X27.734 Y44.254 F254
G1 X27.829 Y44.373 F254
G1 X27.906 Y44.505 F254
G1 X27.968 Y44.645 F254
G1 X28.03 Y44.821 F254
G1 X28.111 Y45.117 F254
G1 X28.232 Y45.719 F254
G1 X28.294 Y46.02 F254
G1 X28.359 Y46.32 F254
G1 X28.434 Y46.618 F254
G1 X28.515 Y46.914 F254
G1 X28.611 Y47.206 F254
G1 X28.747 Y47.481 F254
G1 X28.893 Y47.751 F254
G1 X29.074 Y48 F254
G1 X29.306 Y48.201 F254
G1 X29.548 Y48.389 F254
G1 X29.804 Y48.558 F254
G1 X30.091 Y48.667 F254
G1 X30.393 Y48.723 F254
G1 X30.695 Y48.782 F254
G1 X31 Y48.815 F254
G1 X31.305 Y48.776 F254
G1 X31.908 Y48.662 F254
G1 X32.195 Y48.554 F254
G1 X32.461 Y48.4 F254
G1 X32.715 Y48.228 F254
G1 X32.931 Y48.009 F254
G1 X33.127 Y47.773 F254
G1 X33.289 Y47.512 F254
G1 X33.385 Y47.22 F254
G1 X33.453 Y46.921 F254
G1 X33.531 Y46.624 F254
G1 X33.577 Y46.32 F254
G1 X33.56 Y46.014 F254
G1 X33.531 Y45.708 F254
G1 X33.514 Y45.401 F254
G1 X33.502 Y45.296 F254
G1 X33.488 Y45.144 F254
G1 X33.493 Y44.992 F254
G1 X33.518 Y44.841 F254
G1 X33.565 Y44.696 F254
G1 X33.624 Y44.64 F254
G1 X33.643 Y44.607 F254
G1 X33.659 Y44.573 F254
G1 X33.808 Y44.541 F254
G1 X33.96 Y44.558 F254
G1 X34.103 Y44.608 F254
G1 X34.236 Y44.683 F254
G1 X34.354 Y44.78 F254
G1 X34.458 Y44.891 F254
G1 X34.569 Y45.035 F254
G1 X34.721 Y45.266 F254
G1 X34.871 Y45.534 F254
G1 X35.016 Y45.805 F254
G1 X35.157 Y46.077 F254
G1 X35.3 Y46.349 F254
G1 X35.988 Y47.722 F254
G1 X36.128 Y47.995 F254
G1 X36.282 Y48.261 F254
G1 X36.429 Y48.53 F254
G1 X36.727 Y49.067 F254
G1 X36.893 Y49.325 F254
G1 X37.09 Y49.561 F254
G1 X37.281 Y49.801 F254
G1 X37.496 Y50.021 F254
G1 X37.963 Y50.419 F254
G1 X38.218 Y50.59 F254
G1 X38.482 Y50.747 F254
G1 X38.754 Y50.891 F254
G1 X39.037 Y51.008 F254
G1 X39.328 Y51.108 F254
G1 X39.628 Y51.172 F254
G1 X39.929 Y51.231 F254
G1 X40.232 Y51.284 F254
G1 X40.539 Y51.287 F254
G1 X40.845 Y51.261 F254
G1 X41.147 Y51.209 F254
G1 X41.43 Y51.089 F254
G1 X41.711 Y50.966 F254
G1 X41.963 Y50.791 F254
G1 X42.166 Y50.56 F254
G1 X42.346 Y50.311 F254
G1 X42.505 Y50.048 F254
G1 X42.605 Y49.758 F254
G1 X42.644 Y49.454 F254
G1 X42.669 Y49.148 F254
G1 X42.657 Y48.841 F254
G1 X42.634 Y48.69 F254
G1 X42.643 Y48.538 F254
G1 X42.687 Y48.392 F254
G1 X42.732 Y48.33 F254
G1 X42.856 Y48.242 F254
G1 X42.999 Y48.19 F254
G1 X43.151 Y48.175 F254
G1 X43.303 Y48.187 F254
G1 X43.451 Y48.22 F254
G1 X43.606 Y48.272 F254
G1 X43.824 Y48.362 F254
G1 X44.098 Y48.5 F254
G1 X44.366 Y48.649 F254
G1 X44.639 Y48.791 F254
G1 X44.922 Y48.911 F254
G1 X45.218 Y48.992 F254
G1 X45.52 Y49.045 F254
G1 X45.827 Y49.039 F254
G1 X46.132 Y49.007 F254
G1 X46.429 Y48.928 F254
G1 X46.699 Y48.782 F254
G1 X46.925 Y48.574 F254
G1 X47.107 Y48.327 F254
G1 X47.167 Y48.22 F254
G1 X47.24 Y48.086 F254
G1 X47.337 Y47.96 F254
G1 X47.439 Y47.846 F254
G1 X47.631 Y47.722 F254
G1 X47.777 Y47.766 F254
G1 X47.908 Y47.844 F254
G1 X48.02 Y47.947 F254
G1 X48.111 Y48.069 F254
G1 X48.179 Y48.205 F254
G1 X48.229 Y48.35 F254
G1 X48.286 Y48.577 F254
G1 X48.392 Y49.182 F254
G1 X48.482 Y49.476 F254
G1 X48.554 Y49.774 F254
G1 X48.653 Y50.065 F254
G1 X48.76 Y50.353 F254
G1 X48.862 Y50.643 F254
G1 X48.979 Y50.926 F254
G1 X49.105 Y51.207 F254
G1 X49.234 Y51.485 F254
G1 X49.509 Y52.034 F254
G1 X49.656 Y52.304 F254
G1 X49.956 Y52.84 F254
G1 X50.113 Y53.104 F254
G1 X50.274 Y53.365 F254
G1 X50.433 Y53.628 F254
G1 X50.596 Y53.888 F254
G1 X50.77 Y54.141 F254
G1 X50.944 Y54.394 F254
G1 X51.81 Y55.662 F254
G1 X51.987 Y55.913 F254
G1 X52.358 Y56.402 F254
G1 X53.098 Y57.382 F254
G1 X53.284 Y57.627 F254
G1 X53.472 Y57.869 F254
G1 X54.423 Y59.074 F254
G1 X54.612 Y59.316 F254
G1 X54.985 Y59.805 F254
G1 X55.357 Y60.293 F254
G1 X55.542 Y60.538 F254
G1 X55.724 Y60.786 F254
G1 X56.084 Y61.283 F254
G1 X56.261 Y61.534 F254
G1 X56.4 Y61.742 F254
G1 X56.475 Y61.875 F254
G1 X56.536 Y62.015 F254
G1 X56.575 Y62.162 F254
G1 X56.585 Y62.314 F254
G1 X56.571 Y62.476 F254
G1 X56.545 Y62.638 F254
G1 X56.474 Y62.936 F254
G1 X56.393 Y63.232 F254
G1 X56.335 Y63.534 F254
G1 X56.333 Y63.841 F254
G1 X56.365 Y64.146 F254
G1 X56.399 Y64.452 F254
G1 X56.484 Y64.747 F254
G1 X56.557 Y64.945 F254
G1 X56.599 Y65.092 F254
G1 X56.616 Y65.243 F254
G1 X56.607 Y65.395 F254
G1 X56.573 Y65.544 F254
G1 X56.512 Y65.684 F254
G1 X56.429 Y65.812 F254
G1 X56.332 Y65.929 F254
G1 X56.207 Y66.06 F254
G1 X56.086 Y66.17 F254
G1 X55.965 Y66.263 F254
G1 X55.834 Y66.341 F254
G1 X55.689 Y66.386 F254
G1 X55.537 Y66.4 F254
G1 X55.386 Y66.38 F254
G1 X55.245 Y66.321 F254
G1 X55.12 Y66.234 F254
G1 X55.009 Y66.13 F254
G1 X54.911 Y66.013 F254
G1 X54.774 Y65.821 F254
G1 X54.615 Y65.559 F254
G1 X54.459 Y65.295 F254
G1 X54.288 Y65.039 F254
G1 X54.104 Y64.794 F254
G1 X53.903 Y64.562 F254
G1 X53.691 Y64.339 F254
G1 X53.472 Y64.125 F254
G1 X53.24 Y63.923 F254
G1 X53.002 Y63.729 F254
G1 X52.76 Y63.54 F254
G1 X52.508 Y63.365 F254
G1 X52.254 Y63.193 F254
G1 X52 Y63.019 F254
G1 X51.732 Y62.87 F254
G1 X51.194 Y62.573 F254
G1 X50.924 Y62.428 F254
G1 X50.638 Y62.315 F254
G1 X50.355 Y62.196 F254
G1 X49.788 Y61.961 F254
G1 X49.492 Y61.877 F254
G1 X49.195 Y61.802 F254
G1 X48.898 Y61.722 F254
G1 X48.601 Y61.644 F254
G1 X48.303 Y61.569 F254
G1 X47.997 Y61.543 F254
G1 X47.387 Y61.472 F254
G1 X47.082 Y61.44 F254
G1 X46.775 Y61.438 F254
G1 X46.468 Y61.453 F254
G1 X46.161 Y61.459 F254
G1 X45.855 Y61.475 F254
G1 X45.55 Y61.515 F254
G1 X45.246 Y61.56 F254
G1 X44.943 Y61.606 F254
G1 X44.646 Y61.684 F254
G1 X44.353 Y61.777 F254
G1 X44.058 Y61.86 F254
G1 X43.468 Y62.033 F254
G1 X43.178 Y62.132 F254
G1 X42.9 Y62.263 F254
G1 X42.627 Y62.405 F254
G1 X42.352 Y62.541 F254
G1 X41.803 Y62.815 F254
G1 X41.535 Y62.965 F254
G1 X41.282 Y63.139 F254
G1 X41.034 Y63.32 F254
G1 X40.284 Y63.855 F254
G1 X40.042 Y64.044 F254
G1 X39.815 Y64.251 F254
G1 X39.593 Y64.463 F254
G1 X39.145 Y64.883 F254
G1 X38.922 Y65.094 F254
G1 X38.71 Y65.316 F254
G1 X38.513 Y65.552 F254
G1 X38.318 Y65.789 F254
G1 X37.925 Y66.261 F254
G1 X37.731 Y66.499 F254
G1 X37.56 Y66.754 F254
G1 X37.396 Y67.013 F254
G1 X36.899 Y67.789 F254
G1 X36.752 Y68.058 F254
G1 X36.621 Y68.336 F254
G1 X36.22 Y69.166 F254
G1 X36.095 Y69.446 F254
G1 X35.997 Y69.737 F254
G1 X35.89 Y70.025 F254
G1 X35.68 Y70.602 F254
G1 X35.584 Y70.894 F254
G1 X35.515 Y71.193 F254
G1 X35.433 Y71.489 F254
G1 X35.356 Y71.786 F254
G1 X35.282 Y72.084 F254
G1 X35.244 Y72.389 F254
G1 X35.187 Y72.691 F254
G1 X35.14 Y72.994 F254
G1 X35.114 Y73.3 F254
G1 X35.091 Y73.606 F254
G1 X35.071 Y73.912 F254
G1 X35.079 Y74.219 F254
G1 X35.085 Y74.526 F254
G1 X35.121 Y74.831 F254
G1 X35.143 Y75.138 F254
G1 X35.17 Y75.444 F254
G1 X35.193 Y75.75 F254
G1 X35.194 Y75.944 F254
G1 X35.18 Y76.148 F254
G1 X35.146 Y76.385 F254
G1 X35.081 Y76.685 F254
G1 X34.994 Y76.98 F254
G1 X34.916 Y77.277 F254
G1 X34.856 Y77.578 F254
G1 X34.794 Y77.879 F254
G1 X34.735 Y78.18 F254
G1 X34.652 Y78.789 F254
G1 X34.609 Y79.093 F254
G1 X34.571 Y79.397 F254
G1 X34.518 Y80.009 F254
G1 X34.49 Y80.315 F254
G1 X34.466 Y80.621 F254
G1 X34.45 Y80.928 F254
G1 X34.438 Y81.234 F254
G1 X34.425 Y81.541 F254
G1 X34.413 Y81.848 F254
G1 X34.41 Y82.155 F254
G1 X34.417 Y82.462 F254
G1 X34.427 Y83.076 F254
G1 X34.443 Y83.383 F254
G1 X34.474 Y83.688 F254
G1 X34.501 Y83.994 F254
G1 X34.529 Y84.3 F254
G1 X34.568 Y84.604 F254
G1 X34.619 Y84.907 F254
G1 X34.666 Y85.211 F254
G1 X34.718 Y85.513 F254
G1 X34.78 Y85.814 F254
G1 X34.847 Y86.114 F254
G1 X34.912 Y86.414 F254
G1 X34.989 Y86.711 F254
G1 X35.154 Y87.303 F254
G1 X35.246 Y87.595 F254
G1 X35.341 Y87.888 F254
G1 X35.442 Y88.177 F254
G1 X35.55 Y88.465 F254
G1 X35.671 Y88.747 F254
G1 X35.796 Y89.028 F254
G1 X35.919 Y89.309 F254
G1 X36.07 Y89.576 F254
G1 X36.237 Y89.834 F254
G1 X36.726 Y90.614 F254
G1 X36.894 Y90.872 F254
G1 X37.093 Y91.105 F254
G1 X37.3 Y91.333 F254
G1 X37.505 Y91.561 F254
G1 X37.725 Y91.775 F254
G1 X37.957 Y91.977 F254
G1 X38.183 Y92.184 F254
G1 X38.42 Y92.379 F254
G1 X38.672 Y92.554 F254
G1 X38.919 Y92.737 F254
G1 X39.172 Y92.91 F254
G1 X39.44 Y93.062 F254
G1 X39.709 Y93.208 F254
G1 X39.978 Y93.357 F254
G1 X40.258 Y93.483 F254
G1 X40.546 Y93.589 F254
G1 X40.833 Y93.699 F254
G1 X41.123 Y93.8 F254
G1 X41.422 Y93.87 F254
G1 X42.02 Y94.008 F254
G1 X42.323 Y94.061 F254
G1 X42.625 Y94.116 F254
G1 X42.927 Y94.174 F254
G1 X43.528 Y94.298 F254
G1 X43.828 Y94.362 F254
G1 X44.128 Y94.43 F254
G1 X46.218 Y94.93 F254
G1 X46.516 Y95.004 F254
G1 X47.111 Y95.158 F254
G1 X48.002 Y95.392 F254
G1 X48.298 Y95.472 F254
G1 X48.89 Y95.634 F254
G1 X49.186 Y95.717 F254
G1 X49.48 Y95.804 F254
G1 X49.774 Y95.896 F254
G1 X50.065 Y95.991 F254
G1 X50.356 Y96.089 F254
G1 X50.645 Y96.194 F254
G1 X50.931 Y96.306 F254
G1 X51.213 Y96.427 F254
G1 X51.489 Y96.562 F254
G1 X51.763 Y96.7 F254
G1 X52.039 Y96.835 F254
G1 X52.309 Y96.981 F254
G1 X52.571 Y97.141 F254
G1 X53.345 Y97.641 F254
G1 X53.599 Y97.814 F254
G1 X53.848 Y97.993 F254
G1 X54.344 Y98.355 F254
G1 X55.086 Y98.901 F254
G1 X55.335 Y99.081 F254
G1 X57.582 Y100.69 F254
G1 X57.832 Y100.867 F254
G1 X58.086 Y101.04 F254
G1 X58.342 Y101.21 F254
G1 X58.6 Y101.377 F254
G1 X58.86 Y101.54 F254
G1 X59.124 Y101.697 F254
G1 X59.395 Y101.84 F254
G1 X59.67 Y101.978 F254
G1 X59.943 Y102.118 F254
G1 X60.222 Y102.245 F254
G1 X60.514 Y102.342 F254
G1 X60.809 Y102.428 F254
G1 X61.103 Y102.517 F254
G1 X61.398 Y102.601 F254
G1 X61.699 Y102.66 F254
G1 X62.002 Y102.709 F254
G1 X62.306 Y102.753 F254
G1 X62.916 Y102.822 F254
G1 X63.223 Y102.843 F254
G1 X64.143 Y102.893 F254
G1 X64.756 Y102.926 F254
G1 X65.063 Y102.938 F254
G1 X65.37 Y102.929 F254
G1 X65.677 Y102.923 F254
G1 X65.983 Y102.913 F254
G1 X66.289 Y102.883 F254
G1 X66.596 Y102.867 F254
G1 X66.782 Y102.868 F254
G1 X66.934 Y102.88 F254
G1 X67.084 Y102.905 F254
G1 X67.23 Y102.947 F254
G1 X67.403 Y103.014 F254
G1 X67.638 Y103.126 F254
G1 X67.905 Y103.278 F254
G1 X68.162 Y103.446 F254
G1 X68.427 Y103.601 F254
G1 X68.703 Y103.736 F254
G1 X68.975 Y103.878 F254
G1 X69.255 Y104.004 F254
G1 X69.547 Y104.1 F254
G1 X69.837 Y104.199 F254
G1 X70.13 Y104.293 F254
G1 X70.43 Y104.358 F254
G1 X70.732 Y104.41 F254
G1 X71.034 Y104.469 F254
G1 X71.338 Y104.511 F254
G1 X71.644 Y104.54 F254
G1 X71.949 Y104.569 F254
G1 X72.256 Y104.59 F254
G1 X72.563 Y104.584 F254
G1 X72.869 Y104.567 F254
G1 X73.176 Y104.552 F254
G1 X73.481 Y104.516 F254
G1 X73.78 Y104.448 F254
G1 X74.079 Y104.376 F254
G1 X74.378 Y104.306 F254
G1 X74.671 Y104.216 F254
G1 X74.949 Y104.084 F254
G1 X75.223 Y103.946 F254
G1 X75.773 Y103.673 F254
G1 X76.036 Y103.516 F254
G1 X76.265 Y103.31 F254
G1 X76.491 Y103.103 F254
G1 X76.708 Y102.885 F254
G1 X76.868 Y102.624 F254
G1 X77.038 Y102.368 F254
G1 X77.176 Y102.093 F254
G1 X77.259 Y101.798 F254
G1 X77.346 Y101.503 F254
G1 X77.436 Y101.21 F254
G1 X77.509 Y100.911 F254
G1 X77.547 Y100.607 F254
G1 X77.57 Y100.3 F254
G1 X77.586 Y99.994 F254
G1 X77.581 Y99.687 F254
G1 X77.561 Y99.38 F254
G1 X77.524 Y99.076 F254
G1 X77.466 Y98.774 F254
G1 X77.384 Y98.478 F254
G1 X77.278 Y98.19 F254
G1 X77.206 Y98.015 F254
G1 X77.159 Y97.87 F254
G1 X77.125 Y97.722 F254
G1 X77.108 Y97.57 F254
G1 X77.11 Y97.418 F254
G1 X77.13 Y97.256 F254
G1 X77.17 Y97.053 F254
G1 X77.234 Y96.821 F254
G1 X77.439 Y96.242 F254
G1 X77.508 Y95.943 F254
G1 X77.581 Y95.645 F254
G1 X77.633 Y95.342 F254
G1 X77.656 Y95.036 F254
G1 X77.692 Y94.731 F254
G1 X77.713 Y94.425 F254
G1 X77.702 Y94.118 F254
G1 X77.708 Y93.811 F254
G1 Y93.504 F254
G1 X77.712 Y92.89 F254
G1 X77.713 Y92.583 F254
G1 X77.693 Y92.276 F254
G1 X77.665 Y91.971 F254
G1 X77.644 Y91.664 F254
G1 X77.599 Y91.052 F254
G1 X77.576 Y90.746 F254
G1 X77.552 Y90.439 F254
G1 X77.514 Y90.135 F254
G1 X77.46 Y89.832 F254
G1 X77.416 Y89.529 F254
G1 X77.362 Y89.226 F254
G1 X77.288 Y88.928 F254
G1 X77.221 Y88.629 F254
G1 X77.147 Y88.331 F254
G1 X77.055 Y88.038 F254
G1 X76.954 Y87.748 F254
G1 X76.86 Y87.455 F254
G1 X76.667 Y86.872 F254
G1 X76.563 Y86.583 F254
G1 X76.439 Y86.302 F254
G1 X76.308 Y86.025 F254
G1 X76.183 Y85.744 F254
G1 X75.928 Y85.186 F254
G1 X75.791 Y84.911 F254
G1 X75.636 Y84.646 F254
G1 X75.477 Y84.383 F254
G1 X75.322 Y84.118 F254
G1 X74.23 Y82.267 F254
G1 X74.072 Y82.004 F254
G1 X73.906 Y81.745 F254
G1 X73.738 Y81.488 F254
G1 X72.74 Y79.939 F254
G1 X72.575 Y79.68 F254
G1 X72.414 Y79.419 F254
G1 X71.632 Y78.098 F254
G1 X71.477 Y77.833 F254
G1 X71.329 Y77.564 F254
G1 X71.189 Y77.29 F254
G1 X71.052 Y77.016 F254
G1 X70.916 Y76.741 F254
G1 X70.788 Y76.461 F254
G1 X70.664 Y76.18 F254
G1 X70.538 Y75.9 F254
G1 X70.419 Y75.617 F254
G1 X70.076 Y74.762 F254
G1 X69.964 Y74.476 F254
G1 X69.858 Y74.188 F254
G1 X69.753 Y73.9 F254
G1 X69.54 Y73.324 F254
G1 X69.435 Y73.035 F254
G1 X69.331 Y72.746 F254
G1 X69.13 Y72.166 F254
G1 X69.031 Y71.875 F254
G1 X68.934 Y71.584 F254
G1 X68.84 Y71.292 F254
G1 X68.751 Y70.998 F254
G1 X68.714 Y70.849 F254
G1 X68.666 Y70.649 F254
G1 X68.643 Y70.498 F254
G1 X68.631 Y70.346 F254
G1 X68.64 Y70.194 F254
G1 X68.667 Y70.044 F254
G1 X68.713 Y69.899 F254
G1 X68.776 Y69.76 F254
G1 X68.852 Y69.628 F254
G1 X68.943 Y69.496 F254
G1 X69.101 Y69.301 F254
G1 X69.311 Y69.077 F254
G1 X69.534 Y68.866 F254
G1 X69.743 Y68.641 F254
G1 X69.945 Y68.41 F254
G1 X70.151 Y68.182 F254
G1 X70.354 Y67.952 F254
G1 X70.543 Y67.71 F254
G1 X70.71 Y67.452 F254
G1 X70.877 Y67.194 F254
G1 X71.032 Y66.93 F254
G1 X71.315 Y66.385 F254
G1 X71.451 Y66.109 F254
G1 X71.575 Y65.828 F254
G1 X71.696 Y65.546 F254
G1 X71.812 Y65.262 F254
G1 X71.925 Y64.976 F254
G1 X72.035 Y64.69 F254
G1 X72.251 Y64.115 F254
G1 X72.355 Y63.826 F254
G1 X72.561 Y63.247 F254
G1 X72.662 Y62.957 F254
G1 X73.144 Y61.5 F254
G1 X73.238 Y61.208 F254
G1 X73.328 Y60.914 F254
G1 X73.588 Y60.03 F254
G1 X73.673 Y59.735 F254
G1 X73.753 Y59.439 F254
G1 X73.906 Y58.844 F254
G1 X73.981 Y58.546 F254
G1 X74.051 Y58.247 F254
G1 X74.183 Y57.647 F254
G1 X74.243 Y57.346 F254
G1 X74.354 Y56.742 F254
G1 X74.406 Y56.44 F254
G1 X74.507 Y55.834 F254
G1 X74.559 Y55.531 F254
G1 X74.831 Y54.02 F254
G1 X74.893 Y53.719 F254
G1 X74.962 Y53.42 F254
G1 X75.032 Y53.121 F254
G1 X75.111 Y52.825 F254
G1 X75.198 Y52.53 F254
G1 X75.286 Y52.236 F254
G1 X75.386 Y51.945 F254
G1 X75.499 Y51.66 F254
G1 X75.616 Y51.376 F254
G1 X75.734 Y51.136 F254
G1 X75.823 Y50.985 F254
G1 X75.91 Y50.86 F254
G1 X76.011 Y50.746 F254
G1 X76.133 Y50.655 F254
G1 X76.269 Y50.587 F254
G1 X76.415 Y50.543 F254
G1 X76.565 Y50.518 F254
G1 X76.749 Y50.506 F254
G1 X77.056 Y50.508 F254
G1 X77.362 Y50.532 F254
G1 X77.669 Y50.54 F254
G1 X77.976 Y50.53 F254
G1 X78.283 Y50.523 F254
G1 X78.588 Y50.494 F254
G1 X78.89 Y50.439 F254
G1 X79.191 Y50.376 F254
G1 X79.488 Y50.297 F254
G1 X79.781 Y50.207 F254
G1 X80.07 Y50.103 F254
G1 X80.355 Y49.988 F254
G1 X80.926 Y49.763 F254
G1 X81.211 Y49.648 F254
G1 X81.489 Y49.519 F254
G1 X81.762 Y49.378 F254
G1 X82.31 Y49.099 F254
G1 X82.581 Y48.956 F254
G1 X82.839 Y48.789 F254
G1 X83.088 Y48.609 F254
G1 X83.588 Y48.253 F254
G1 X83.817 Y48.048 F254
G1 X84.006 Y47.807 F254
G1 X84.199 Y47.568 F254
G1 X84.392 Y47.329 F254
G1 X84.513 Y47.173 F254
G1 X84.615 Y47.059 F254
G1 X84.742 Y46.975 F254
G1 X84.885 Y46.922 F254
G1 X85.037 Y46.907 F254
G1 X85.187 Y46.931 F254
G1 X85.33 Y46.985 F254
G1 X85.463 Y47.058 F254
G1 X85.64 Y47.175 F254
G1 X85.883 Y47.363 F254
G1 X86.137 Y47.536 F254
G1 X86.406 Y47.684 F254
G1 X86.67 Y47.84 F254
G1 X86.945 Y47.977 F254
G1 X87.241 Y48.057 F254
G1 X87.544 Y48.112 F254
G1 X87.845 Y48.173 F254
G1 X88.148 Y48.219 F254
G1 X88.453 Y48.255 F254
G1 X88.755 Y48.313 F254
G1 X89.054 Y48.38 F254
G1 X89.352 Y48.456 F254
G1 X89.648 Y48.536 F254
G1 X89.944 Y48.617 F254
G1 X90.242 Y48.691 F254
G1 X90.545 Y48.741 F254
G1 X90.849 Y48.783 F254
G1 X91.155 Y48.813 F254
G1 X91.461 Y48.787 F254
G1 X91.749 Y48.681 F254
G1 X92.02 Y48.537 F254
G1 X92.275 Y48.365 F254
G1 X92.477 Y48.134 F254
G1 X92.629 Y47.868 F254
G1 X92.719 Y47.574 F254
G1 X92.765 Y47.27 F254
G1 X92.781 Y46.964 F254
G1 X92.732 Y46.661 F254
G1 X92.643 Y46.367 F254
G1 X92.552 Y46.073 F254
G1 X92.422 Y45.795 F254
G1 X92.377 Y45.688 F254
G1 X92.317 Y45.548 F254
G1 X92.279 Y45.4 F254
G1 X92.264 Y45.248 F254
G1 X92.305 Y45.102 F254
G1 X92.405 Y44.986 F254
G1 X92.537 Y44.911 F254
G1 X92.684 Y44.871 F254
G1 X92.837 Y44.863 F254
G1 X92.988 Y44.878 F254
G1 X93.204 Y44.921 F254
G1 X93.499 Y45.004 F254
G1 X93.793 Y45.093 F254
G1 X94.096 Y45.144 F254
G1 X94.402 Y45.168 F254
G1 X94.709 Y45.156 F254
G1 X95.014 Y45.121 F254
G1 X95.304 Y45.02 F254
G1 X95.581 Y44.888 F254
G1 X95.85 Y44.739 F254
G1 X96.084 Y44.54 F254
G1 X96.257 Y44.287 F254
G1 X96.39 Y44.01 F254
G1 X96.511 Y43.728 F254
G1 X96.593 Y43.432 F254
G1 X96.597 Y43.125 F254
G1 X96.572 Y42.819 F254
G1 X96.531 Y42.514 F254
G1 X96.443 Y42.22 F254
G1 X96.372 Y42.044 F254
G1 X96.326 Y41.899 F254
G1 X96.32 Y41.747 F254
G1 X96.359 Y41.6 F254
G1 X96.44 Y41.47 F254
G1 X96.552 Y41.367 F254
G1 X96.688 Y41.298 F254
G1 X96.835 Y41.259 F254
G1 X96.987 Y41.245 F254
G1 X97.139 Y41.249 F254
G1 X97.29 Y41.269 F254
G1 X97.468 Y41.305 F254
G1 X97.699 Y41.371 F254
G1 X97.951 Y41.463 F254
G1 X98.511 Y41.716 F254
G1 X98.784 Y41.855 F254
G1 X99.589 Y42.304 F254
G1 X99.863 Y42.442 F254
G1 X100.141 Y42.572 F254
G1 X100.697 Y42.833 F254
G1 X100.977 Y42.961 F254
G1 X101.269 Y43.053 F254
G1 X101.565 Y43.137 F254
G1 X101.862 Y43.215 F254
G1 X102.167 Y43.244 F254
G1 X102.472 Y43.279 F254
G1 X102.779 Y43.287 F254
G1 X103.083 Y43.244 F254
G1 X103.388 Y43.203 F254
G1 X103.683 Y43.119 F254
G1 X103.963 Y42.994 F254
G1 X104.24 Y42.86 F254
G1 X104.487 Y42.678 F254
G1 X104.719 Y42.477 F254
G1 X104.927 Y42.251 F254
G1 X105.095 Y41.994 F254
G1 X105.25 Y41.729 F254
G1 X105.359 Y41.442 F254
G1 X105.418 Y41.141 F254
G1 X105.478 Y40.84 F254
G1 X105.464 Y40.533 F254
G1 X105.421 Y40.229 F254
G1 X105.366 Y39.927 F254
G1 X105.248 Y39.643 F254
G1 X105.117 Y39.365 F254
G1 X104.961 Y39.101 F254
G1 X104.77 Y38.86 F254
G1 X104.569 Y38.628 F254
G1 X104.336 Y38.429 F254
G1 X104.092 Y38.242 F254
G1 X103.852 Y38.051 F254
G1 X103.602 Y37.872 F254
G1 X103.329 Y37.732 F254
G1 X103.053 Y37.597 F254
G1 X102.779 Y37.459 F254
G1 X102.499 Y37.333 F254
G1 X102.204 Y37.249 F254
G1 X100.736 Y36.799 F254
G1 X100.44 Y36.717 F254
G1 X100.136 Y36.671 F254
G1 X99.835 Y36.613 F254
G1 X99.231 Y36.502 F254
G1 X98.627 Y36.39 F254
G1 X98.325 Y36.336 F254
G1 X98.02 Y36.297 F254
G1 X94.977 Y35.883 F254
G1 X94.674 Y35.839 F254
G1 X94.371 Y35.784 F254
G1 X94.07 Y35.725 F254
G1 X93.165 Y35.553 F254
G1 X92.864 Y35.493 F254
G1 X92.566 Y35.417 F254
G1 X92.268 Y35.344 F254
G1 X91.97 Y35.269 F254
G1 X91.674 Y35.19 F254
G1 X91.08 Y35.034 F254
G1 X90.781 Y34.965 F254
G1 X90.18 Y34.838 F254
G1 X89.876 Y34.793 F254
G1 X89.57 Y34.774 F254
G1 X89.264 Y34.743 F254
G1 X88.957 Y34.727 F254
G1 X88.651 Y34.751 F254
G1 X88.038 Y34.785 F254
G1 X87.732 Y34.814 F254
G1 X87.431 Y34.871 F254
G1 X87.127 Y34.92 F254
G1 X86.824 Y34.969 F254
G1 X86.522 Y35.022 F254
G1 X86.221 Y35.082 F254
G1 X85.92 Y35.143 F254
G1 X85.317 Y35.261 F254
G1 X85.014 Y35.311 F254
G1 X84.71 Y35.353 F254
G1 X84.407 Y35.4 F254
G1 X84.103 Y35.444 F254
G1 X83.797 Y35.476 F254
G1 X83.491 Y35.491 F254
G1 X83.184 Y35.502 F254
G1 X82.57 Y35.526 F254
G1 X82.263 Y35.518 F254
G1 X81.957 Y35.492 F254
G1 X81.346 Y35.432 F254
G1 X81.04 Y35.403 F254
G1 X80.736 Y35.365 F254
G1 X80.434 Y35.31 F254
G1 X80.133 Y35.25 F254
G1 X78.626 Y34.954 F254
G1 X78.325 Y34.895 F254
G1 X78.021 Y34.847 F254
G1 X77.716 Y34.817 F254
G1 X77.409 Y34.804 F254
G1 X77.102 Y34.819 F254
G1 X76.797 Y34.854 F254
G1 X76.5 Y34.933 F254
G1 X76.201 Y34.999 F254
G1 X75.899 Y35.059 F254
G1 X75.633 Y35.107 F254
G1 X75.365 Y35.135 F254
G1 X75.058 Y35.144 F254
G1 X74.751 Y35.139 F254
G1 X74.444 Y35.123 F254
G1 X74.138 Y35.101 F254
G1 X73.832 Y35.072 F254
G1 X73.222 Y35.003 F254
G1 X72.918 Y34.963 F254
G1 X72.31 Y34.876 F254
G1 X71.398 Y34.747 F254
G1 X71.093 Y34.705 F254
G1 X69.267 Y34.465 F254
G1 X68.962 Y34.43 F254
G1 X68.35 Y34.38 F254
G1 X68.043 Y34.358 F254
G1 X67.736 Y34.349 F254
G1 X67.429 Y34.346 F254
G1 X67.122 Y34.341 F254
G1 X66.816 Y34.359 F254
G1 X66.51 Y34.391 F254
G1 X66.205 Y34.422 F254
G1 X65.906 Y34.491 F254
G1 X65.611 Y34.577 F254
G1 X65.317 Y34.667 F254
G1 X65.047 Y34.812 F254
G1 X64.788 Y34.978 F254
G1 X64.533 Y35.149 F254
G1 X64.326 Y35.375 F254
G1 X64.133 Y35.614 F254
G1 X63.959 Y35.867 F254
G1 X63.83 Y36.146 F254
G1 X63.713 Y36.389 F254
G1 X63.637 Y36.521 F254
G1 X63.547 Y36.644 F254
G1 X63.44 Y36.752 F254
G1 X63.318 Y36.844 F254
G1 X63.187 Y36.921 F254
G1 X63.048 Y36.983 F254
G1 X62.902 Y37.035 F254
G1 X62.732 Y37.081 F254
G1 X62.465 Y37.133 F254
G1 X62.16 Y37.169 F254
G1 X61.853 Y37.186 F254
G1 X61.546 Y37.187 F254
G1 X60.932 Y37.174 F254
G1 X60.626 Y37.151 F254
G1 X60.32 Y37.12 F254
G1 X60.015 Y37.092 F254
G1 X59.709 Y37.06 F254
G1 X59.406 Y37.013 F254
G1 X58.799 Y36.917 F254
G1 X58.496 Y36.867 F254
G1 X58.195 Y36.806 F254
G1 X57.895 Y36.741 F254
G1 X57.595 Y36.676 F254
G1 X57.295 Y36.611 F254
G1 X56.998 Y36.534 F254
G1 X56.404 Y36.376 F254
G1 X56.108 Y36.296 F254
G1 X55.815 Y36.204 F254
G1 X55.228 Y36.022 F254
G1 X54.648 Y35.821 F254
G1 X54.358 Y35.72 F254
G1 X53.496 Y35.394 F254
G1 X53.209 Y35.286 F254
G1 X52.919 Y35.184 F254
G1 X52.049 Y34.883 F254
G1 X51.755 Y34.795 F254
G1 X51.454 Y34.73 F254
G1 X50.557 Y34.522 F254
G1 X50.256 Y34.462 F254
G1 X49.951 Y34.43 F254
G1 X49.646 Y34.39 F254
G1 X49.341 Y34.357 F254
G1 X49.034 Y34.346 F254
G1 X48.728 Y34.327 F254
G1 X48.421 Y34.314 F254
G1 X48.114 Y34.322 F254
G1 X47.807 Y34.335 F254
G1 X47.5 Y34.345 F254
G1 X46.58 Y34.378 F254
G1 X46.273 Y34.39 F254
G1 X45.967 Y34.419 F254
G1 X45.665 Y34.477 F254
G1 X45.362 Y34.523 F254
G1 X44.756 Y34.621 F254
G1 X44.453 Y34.67 F254
G1 X44.15 Y34.725 F254
G1 X43.853 Y34.8 F254
G1 X43.556 Y34.88 F254
G1 X43.259 Y34.956 F254
G1 X42.664 Y35.111 F254
G1 X42.368 Y35.191 F254
G1 X42.072 Y35.273 F254
G1 X41.48 Y35.434 F254
G1 X41.182 Y35.511 F254
G1 X40.881 Y35.572 F254
G1 X40.578 Y35.622 F254
G1 X40.277 Y35.681 F254
G1 X39.973 Y35.726 F254
G1 X39.667 Y35.752 F254
G1 X39.361 Y35.768 F254
G1 X39.054 Y35.776 F254
G1 X38.747 Y35.771 F254
G1 X38.44 Y35.747 F254
G1 X38.135 Y35.717 F254
G1 X37.831 Y35.676 F254
G1 X37.529 Y35.619 F254
G1 X36.622 Y35.457 F254
G1 X36.32 Y35.404 F254
G1 X36.015 Y35.363 F254
G1 X35.406 Y35.29 F254
G1 X35.099 Y35.271 F254
G1 X34.793 Y35.288 F254
G1 X34.486 Y35.293 F254
G1 X34.179 Y35.31 F254
G1 X33.877 Y35.364 F254
G1 X33.578 Y35.437 F254
G1 X33.278 Y35.499 F254
G1 X32.981 Y35.577 F254
G1 X32.693 Y35.685 F254
G1 X32.408 Y35.798 F254
G1 X32.12 Y35.906 F254
G1 X31.836 Y36.023 F254
G1 X31.554 Y36.144 F254
G1 X30.988 Y36.381 F254
G1 X30.704 Y36.499 F254
G1 X30.442 Y36.597 F254
G1 X30.228 Y36.659 F254
G1 X30.066 Y36.693 F254
G1 X29.906 Y36.714 F254
G1 X29.754 Y36.723 F254
G1 X29.601 Y36.721 F254
G1 X29.409 Y36.704 F254
G1 X29.187 Y36.667 F254
G1 X28.921 Y36.603 F254
G1 X28.629 Y36.509 F254
G1 X28.34 Y36.405 F254
G1 X28.051 Y36.302 F254
G1 X27.761 Y36.201 F254
G1 X27.466 Y36.117 F254
G1 X27.166 Y36.049 F254
G1 X26.868 Y35.975 F254
G1 X26.569 Y35.905 F254
G1 X26.265 Y35.867 F254
G1 X25.959 Y35.84 F254
G1 X25.653 Y35.807 F254
G1 X25.347 Y35.795 F254
G1 X25.041 Y35.825 F254
G1 X24.735 Y35.844 F254
G1 X24.122 Y35.886 F254
G1 X23.817 Y35.924 F254
G1 X23.524 Y36.016 F254
G1 X23.234 Y36.117 F254
G1 X22.948 Y36.229 F254
G1 X22.686 Y36.389 F254
G1 X22.44 Y36.573 F254
G1 X22.228 Y36.795 F254
G1 X22.051 Y37.046 F254
G1 X21.975 Y37.178 F254
G1 X21.884 Y37.3 F254
G1 X21.772 Y37.403 F254
G1 X21.642 Y37.482 F254
G1 X21.499 Y37.536 F254
G1 X21.349 Y37.563 F254
G1 X21.197 Y37.57 F254
G1 X21.002 Y37.561 F254
G1 X20.772 Y37.533 F254
G1 X20.47 Y37.474 F254
G1 X19.869 Y37.351 F254
G1 X19.566 Y37.299 F254
G1 X19.262 Y37.254 F254
G1 X18.959 Y37.206 F254
G1 X18.655 Y37.159 F254
G1 X18.35 Y37.123 F254
G1 X18.045 Y37.09 F254
G1 X17.738 Y37.077 F254
G1 X17.431 Y37.083 F254
G1 X16.825 Y37.177 F254
G1 X16.542 Y37.298 F254
G1 X16.29 Y37.473 F254
G1 X16.054 Y37.67 F254
G1 X15.942 Y37.775 F254
G1 X15.839 Y37.889 F254
G1 X15.77 Y38.026 F254
G1 X15.722 Y38.172 F254
G1 X15.683 Y38.476 F254
G1 X15.678 Y38.702 F254
G1 X15.649 Y39.008 F254
G1 X15.624 Y39.314 F254
G1 X15.662 Y39.619 F254
G1 X15.727 Y39.919 F254
G1 X15.806 Y40.215 F254
G1 X15.918 Y40.501 F254
G1 X16.035 Y40.785 F254
G1 X16.178 Y41.057 F254
G1 X16.34 Y41.318 F254
G1 X16.499 Y41.581 F254
G1 X16.697 Y41.815 F254
G1 X16.908 Y42.039 F254
G1 X17.113 Y42.267 F254
G1 X17.358 Y42.452 F254
G1 X17.622 Y42.609 F254
G1 X17.883 Y42.772 F254
G1 X18.171 Y42.876 F254
G1 X18.467 Y42.957 F254
G1 X18.771 Y43.004 F254
G1 X19.078 Y43.014 F254
G1 X19.384 Y43.028 F254
G1 X19.691 Y43.017 F254
G1 X19.996 Y42.983 F254
G1 X20.302 Y42.955 F254
G1 X20.609 Y42.94 F254
G1 X20.916 Y42.937 F254
G1 X21.223 Y42.953 F254
G1 X21.528 Y42.988 F254
G1 X21.83 Y43.043 F254
G1 X22.129 Y43.11 F254
G1 X22.727 Y43.25 F254
G1 X23.026 Y43.323 F254
G1 X24.216 Y43.627 F254
G1 X24.515 Y43.696 F254
G1 X24.819 Y43.74 F254
G1 X25.124 Y43.771 F254
G1 X26.039 Y43.877 F254
G1 X26.345 Y43.906 F254
G1 X26.652 Y43.899 F254
G1 X26.956 Y43.859 F254
G1 X27.108 Y43.847 F254
G1 X27.261 Y43.849 F254
G1 X27.412 Y43.87 F254
G1 X27.557 Y43.917 F254
G1 X27.693 Y43.986 F254
G1 X27.815 Y44.077 F254
G1 X27.921 Y44.186 F254
G1 X28.011 Y44.309 F254
G1 X28.085 Y44.442 F254
G1 X28.153 Y44.593 F254
G1 X28.234 Y44.816 F254
G1 X28.304 Y45.066 F254
G1 X28.426 Y45.668 F254
G1 X28.488 Y45.969 F254
G1 X28.552 Y46.269 F254
G1 X28.627 Y46.567 F254
G1 X28.708 Y46.863 F254
G1 X28.805 Y47.155 F254
G1 X28.945 Y47.428 F254
G1 X29.092 Y47.698 F254
G1 X29.288 Y47.934 F254
G1 X29.53 Y48.122 F254
G1 X29.777 Y48.305 F254
G1 X30.05 Y48.445 F254
G1 X30.349 Y48.514 F254
G1 X30.652 Y48.569 F254
G1 X30.956 Y48.611 F254
G1 X31.261 Y48.582 F254
G1 X31.563 Y48.523 F254
G1 X31.865 Y48.466 F254
G1 X32.151 Y48.356 F254
G1 X32.412 Y48.195 F254
G1 X32.66 Y48.013 F254
G1 X32.861 Y47.781 F254
G1 X33.045 Y47.535 F254
G1 X33.17 Y47.255 F254
G1 X33.241 Y46.956 F254
G1 X33.315 Y46.658 F254
G1 X33.372 Y46.356 F254
G1 X33.364 Y46.049 F254
G1 X33.334 Y45.744 F254
G1 X33.316 Y45.437 F254
G1 X33.299 Y45.265 F254
G1 X33.295 Y45.113 F254
G1 X33.306 Y44.961 F254
G1 X33.333 Y44.811 F254
G1 X33.379 Y44.665 F254
G1 X33.455 Y44.533 F254
G1 X33.571 Y44.433 F254
G1 X33.712 Y44.378 F254
G1 X33.864 Y44.366 F254
G1 X34.015 Y44.387 F254
G1 X34.16 Y44.435 F254
G1 X34.296 Y44.504 F254
G1 X34.421 Y44.591 F254
G1 X34.534 Y44.693 F254
G1 X34.635 Y44.807 F254
G1 X34.771 Y44.983 F254
G1 X34.919 Y45.21 F254
G1 X35.068 Y45.478 F254
G1 X35.212 Y45.749 F254
G1 X35.353 Y46.022 F254
G1 X35.496 Y46.294 F254
G1 X35.633 Y46.569 F254
G1 X36.184 Y47.666 F254
G1 X36.324 Y47.939 F254
G1 X36.48 Y48.204 F254
G1 X36.626 Y48.474 F254
G1 X36.925 Y49.011 F254
G1 X37.095 Y49.266 F254
G1 X37.298 Y49.497 F254
G1 X37.49 Y49.737 F254
G1 X37.713 Y49.947 F254
G1 X37.949 Y50.144 F254
G1 X38.188 Y50.336 F254
G1 X38.45 Y50.496 F254
G1 X38.718 Y50.647 F254
G1 X38.996 Y50.778 F254
G1 X39.284 Y50.883 F254
G1 X39.581 Y50.96 F254
G1 X39.883 Y51.018 F254
G1 X40.185 Y51.074 F254
G1 X40.492 Y51.089 F254
G1 X40.798 Y51.065 F254
G1 X41.101 Y51.014 F254
G1 X41.382 Y50.891 F254
G1 X41.664 Y50.769 F254
G1 X41.901 Y50.574 F254
G1 X42.087 Y50.33 F254
G1 X42.259 Y50.075 F254
G1 X42.387 Y49.796 F254
G1 X42.44 Y49.494 F254
G1 X42.465 Y49.188 F254
G1 X42.46 Y48.881 F254
G1 X42.447 Y48.729 F254
G1 X42.451 Y48.577 F254
G1 X42.479 Y48.427 F254
G1 X42.542 Y48.288 F254
G1 X42.645 Y48.175 F254
G1 X42.77 Y48.089 F254
G1 X42.91 Y48.029 F254
G1 X43.059 Y47.997 F254
G1 X43.212 Y47.991 F254
G1 X43.363 Y48.008 F254
G1 X43.512 Y48.041 F254
G1 X43.692 Y48.098 F254
G1 X43.894 Y48.178 F254
G1 X44.17 Y48.312 F254
G1 X44.438 Y48.461 F254
G1 X44.711 Y48.603 F254
G1 X44.993 Y48.724 F254
G1 X45.289 Y48.804 F254
G1 X45.592 Y48.854 F254
G1 X45.899 Y48.833 F254
G1 X46.202 Y48.789 F254
G1 X46.488 Y48.677 F254
G1 X46.73 Y48.488 F254
G1 X46.92 Y48.247 F254
G1 X46.974 Y48.152 F254
G1 X47.053 Y48.021 F254
G1 X47.144 Y47.893 F254
G1 X47.241 Y47.776 F254
G1 X47.358 Y47.678 F254
G1 X47.483 Y47.591 F254
G1 X47.632 Y47.56 F254
G1 X47.783 Y47.581 F254
G1 X47.924 Y47.639 F254
G1 X48.05 Y47.725 F254
G1 X48.16 Y47.831 F254
G1 X48.253 Y47.951 F254
G1 X48.328 Y48.084 F254
G1 X48.387 Y48.225 F254
G1 X48.441 Y48.395 F254
G1 X48.512 Y48.694 F254
G1 X48.562 Y48.997 F254
G1 X48.631 Y49.296 F254
G1 X48.718 Y49.591 F254
G1 X48.8 Y49.887 F254
G1 X48.907 Y50.174 F254
G1 X49.011 Y50.463 F254
G1 X49.121 Y50.75 F254
G1 X49.245 Y51.031 F254
G1 X49.373 Y51.31 F254
G1 X49.507 Y51.586 F254
G1 X49.645 Y51.86 F254
G1 X49.789 Y52.132 F254
G1 X50.089 Y52.668 F254
G1 X50.243 Y52.933 F254
G1 X50.564 Y53.457 F254
G1 X50.725 Y53.718 F254
G1 X50.896 Y53.973 F254
G1 X51.071 Y54.226 F254
G1 X51.937 Y55.494 F254
G1 X52.113 Y55.745 F254
G1 X52.297 Y55.991 F254
G1 X52.483 Y56.235 F254
G1 X53.223 Y57.215 F254
G1 X53.408 Y57.46 F254
G1 X53.596 Y57.703 F254
G1 X54.547 Y58.908 F254
G1 X54.736 Y59.15 F254
G1 X54.923 Y59.394 F254
G1 X55.482 Y60.126 F254
G1 X55.667 Y60.371 F254
G1 X55.849 Y60.619 F254
G1 X56.21 Y61.116 F254
G1 X56.388 Y61.366 F254
G1 X56.536 Y61.585 F254
G1 X56.614 Y61.721 F254
G1 X56.68 Y61.859 F254
G1 X56.731 Y62.002 F254
G1 X56.76 Y62.152 F254
G1 X56.77 Y62.304 F254
G1 X56.764 Y62.456 F254
G1 X56.743 Y62.628 F254
G1 X56.683 Y62.929 F254
G1 X56.603 Y63.225 F254
G1 X56.539 Y63.526 F254
G1 X56.532 Y63.833 F254
G1 X56.565 Y64.138 F254
G1 X56.599 Y64.443 F254
G1 X56.691 Y64.736 F254
G1 X56.74 Y64.88 F254
G1 X56.778 Y65.028 F254
G1 X56.799 Y65.179 F254
G1 X56.801 Y65.331 F254
G1 X56.781 Y65.483 F254
G1 X56.739 Y65.629 F254
G1 X56.676 Y65.768 F254
G1 X56.597 Y65.898 F254
G1 X56.505 Y66.02 F254
G1 X56.398 Y66.142 F254
G1 X56.281 Y66.257 F254
G1 X56.165 Y66.355 F254
G1 X56.039 Y66.442 F254
G1 X55.903 Y66.51 F254
G1 X55.758 Y66.557 F254
G1 X55.608 Y66.581 F254
G1 X55.455 Y66.578 F254
G1 X55.307 Y66.544 F254
G1 X55.167 Y66.484 F254
G1 X55.038 Y66.403 F254
G1 X54.921 Y66.306 F254
G1 X54.815 Y66.196 F254
G1 X54.698 Y66.051 F254
G1 X54.524 Y65.799 F254
G1 X54.368 Y65.534 F254
G1 X54.207 Y65.273 F254
G1 X54.028 Y65.024 F254
G1 X53.835 Y64.785 F254
G1 X53.626 Y64.56 F254
G1 X53.409 Y64.342 F254
G1 X53.182 Y64.136 F254
G1 X52.945 Y63.94 F254
G1 X52.704 Y63.75 F254
G1 X52.455 Y63.57 F254
G1 X52.201 Y63.398 F254
G1 X51.947 Y63.225 F254
G1 X51.683 Y63.069 F254
G1 X51.413 Y62.923 F254
G1 X51.144 Y62.774 F254
G1 X50.874 Y62.628 F254
G1 X49.739 Y62.158 F254
G1 X49.445 Y62.071 F254
G1 X49.147 Y61.996 F254
G1 X48.851 Y61.916 F254
G1 X48.554 Y61.838 F254
G1 X48.256 Y61.763 F254
G1 X47.95 Y61.74 F254
G1 X47.645 Y61.703 F254
G1 X47.34 Y61.668 F254
G1 X47.034 Y61.636 F254
G1 X46.727 Y61.639 F254
G1 X46.421 Y61.655 F254
G1 X46.114 Y61.659 F254
G1 X45.807 Y61.679 F254
G1 X45.504 Y61.725 F254
G1 X45.2 Y61.769 F254
G1 X44.897 Y61.819 F254
G1 X44.603 Y61.907 F254
G1 X44.31 Y61.999 F254
G1 X44.014 Y62.08 F254
G1 X43.425 Y62.256 F254
G1 X43.139 Y62.367 F254
G1 X42.592 Y62.646 F254
G1 X42.316 Y62.782 F254
G1 X42.042 Y62.919 F254
G1 X41.769 Y63.061 F254
G1 X41.508 Y63.222 F254
G1 X41.26 Y63.403 F254
G1 X41.01 Y63.582 F254
G1 X40.511 Y63.939 F254
G1 X40.264 Y64.122 F254
G1 X40.031 Y64.322 F254
G1 X39.808 Y64.533 F254
G1 X39.138 Y65.165 F254
G1 X38.921 Y65.383 F254
G1 X38.72 Y65.614 F254
G1 X38.525 Y65.852 F254
G1 X38.133 Y66.324 F254
G1 X37.938 Y66.561 F254
G1 X37.76 Y66.812 F254
G1 X37.596 Y67.071 F254
G1 X37.099 Y67.847 F254
G1 X36.948 Y68.114 F254
G1 X36.816 Y68.391 F254
G1 X36.549 Y68.944 F254
G1 X36.415 Y69.221 F254
G1 X36.29 Y69.501 F254
G1 X36.189 Y69.791 F254
G1 X36.083 Y70.079 F254
G1 X35.873 Y70.656 F254
G1 X35.777 Y70.948 F254
G1 X35.708 Y71.247 F254
G1 X35.626 Y71.543 F254
G1 X35.548 Y71.84 F254
G1 X35.474 Y72.138 F254
G1 X35.457 Y72.291 F254
G1 X35.41 Y72.594 F254
G1 X35.356 Y72.897 F254
G1 X35.321 Y73.202 F254
G1 X35.277 Y73.814 F254
G1 X35.274 Y74.121 F254
G1 X35.284 Y74.428 F254
G1 X35.309 Y74.734 F254
G1 X35.338 Y75.04 F254
G1 X35.361 Y75.346 F254
G1 X35.387 Y75.652 F254
G1 X35.393 Y75.878 F254
G1 X35.383 Y76.098 F254
G1 X35.354 Y76.343 F254
G1 X35.295 Y76.644 F254
G1 X35.215 Y76.941 F254
G1 X35.133 Y77.236 F254
G1 X35.067 Y77.536 F254
G1 X34.946 Y78.138 F254
G1 X34.9 Y78.442 F254
G1 X34.86 Y78.746 F254
G1 X34.817 Y79.051 F254
G1 X34.778 Y79.355 F254
G1 X34.748 Y79.661 F254
G1 X34.722 Y79.967 F254
G1 X34.695 Y80.272 F254
G1 X34.67 Y80.578 F254
G1 X34.652 Y80.885 F254
G1 X34.615 Y81.805 F254
G1 X34.61 Y82.112 F254
G1 X34.622 Y82.726 F254
G1 X34.627 Y83.033 F254
G1 X34.64 Y83.34 F254
G1 X34.671 Y83.646 F254
G1 X34.726 Y84.257 F254
G1 X34.764 Y84.562 F254
G1 X34.815 Y84.865 F254
G1 X34.862 Y85.168 F254
G1 X34.913 Y85.471 F254
G1 X34.976 Y85.772 F254
G1 X35.042 Y86.072 F254
G1 X35.107 Y86.372 F254
G1 X35.184 Y86.669 F254
G1 X35.35 Y87.26 F254
G1 X35.443 Y87.553 F254
G1 X35.537 Y87.845 F254
G1 X35.639 Y88.135 F254
G1 X35.748 Y88.422 F254
G1 X35.87 Y88.704 F254
G1 X35.995 Y88.984 F254
G1 X36.118 Y89.266 F254
G1 X36.275 Y89.529 F254
G1 X36.444 Y89.786 F254
G1 X36.606 Y90.047 F254
G1 X36.933 Y90.567 F254
G1 X37.104 Y90.821 F254
G1 X37.312 Y91.048 F254
G1 X37.517 Y91.276 F254
G1 X37.725 Y91.502 F254
G1 X37.951 Y91.709 F254
G1 X38.183 Y91.911 F254
G1 X38.411 Y92.116 F254
G1 X38.655 Y92.303 F254
G1 X38.907 Y92.478 F254
G1 X39.155 Y92.659 F254
G1 X39.416 Y92.822 F254
G1 X39.686 Y92.968 F254
G1 X39.955 Y93.116 F254
G1 X40.229 Y93.254 F254
G1 X40.515 Y93.366 F254
G1 X40.803 Y93.473 F254
G1 X41.091 Y93.578 F254
G1 X41.387 Y93.659 F254
G1 X41.687 Y93.725 F254
G1 X41.986 Y93.795 F254
G1 X42.288 Y93.853 F254
G1 X42.59 Y93.906 F254
G1 X42.892 Y93.963 F254
G1 X43.193 Y94.024 F254
G1 X43.794 Y94.15 F254
G1 X44.094 Y94.217 F254
G1 X46.184 Y94.717 F254
G1 X46.482 Y94.79 F254
G1 X46.78 Y94.865 F254
G1 X47.374 Y95.02 F254
G1 X47.968 Y95.176 F254
G1 X48.265 Y95.256 F254
G1 X48.857 Y95.418 F254
G1 X49.153 Y95.5 F254
G1 X49.448 Y95.586 F254
G1 X49.741 Y95.676 F254
G1 X50.034 Y95.77 F254
G1 X50.325 Y95.867 F254
G1 X50.614 Y95.97 F254
G1 X50.901 Y96.079 F254
G1 X51.185 Y96.197 F254
G1 X51.463 Y96.326 F254
G1 X52.013 Y96.6 F254
G1 X52.286 Y96.74 F254
G1 X52.552 Y96.894 F254
G1 X52.812 Y97.058 F254
G1 X53.327 Y97.392 F254
G1 X53.583 Y97.561 F254
G1 X53.835 Y97.737 F254
G1 X54.331 Y98.098 F254
G1 X55.074 Y98.644 F254
G1 X55.322 Y98.825 F254
G1 X55.571 Y99.004 F254
G1 X57.818 Y100.613 F254
G1 X58.07 Y100.788 F254
G1 X58.325 Y100.959 F254
G1 X58.582 Y101.127 F254
G1 X58.841 Y101.293 F254
G1 X59.103 Y101.453 F254
G1 X59.371 Y101.603 F254
G1 X59.919 Y101.881 F254
G1 X60.195 Y102.015 F254
G1 X60.482 Y102.124 F254
G1 X61.071 Y102.298 F254
G1 X61.365 Y102.384 F254
G1 X61.665 Y102.451 F254
G1 X61.968 Y102.501 F254
G1 X62.272 Y102.546 F254
G1 X62.577 Y102.583 F254
G1 X62.882 Y102.617 F254
G1 X63.188 Y102.641 F254
G1 X64.721 Y102.724 F254
G1 X65.028 Y102.737 F254
G1 X65.335 Y102.731 F254
G1 X65.642 Y102.723 F254
G1 X65.949 Y102.714 F254
G1 X66.254 Y102.686 F254
G1 X66.561 Y102.668 F254
G1 X66.758 Y102.67 F254
G1 X66.918 Y102.683 F254
G1 X67.069 Y102.707 F254
G1 X67.217 Y102.743 F254
G1 X67.37 Y102.792 F254
G1 X67.579 Y102.878 F254
G1 X67.835 Y103.006 F254
G1 X68.099 Y103.163 F254
G1 X68.356 Y103.331 F254
G1 X68.625 Y103.478 F254
G1 X68.901 Y103.613 F254
G1 X69.175 Y103.752 F254
G1 X69.46 Y103.866 F254
G1 X69.753 Y103.958 F254
G1 X70.044 Y104.057 F254
G1 X70.34 Y104.137 F254
G1 X70.945 Y104.247 F254
G1 X71.247 Y104.299 F254
G1 X71.553 Y104.331 F254
G1 X71.858 Y104.359 F254
G1 X72.164 Y104.384 F254
G1 X72.471 Y104.388 F254
G1 X73.085 Y104.356 F254
G1 X73.39 Y104.327 F254
G1 X73.691 Y104.264 F254
G1 X73.989 Y104.192 F254
G1 X74.288 Y104.121 F254
G1 X74.583 Y104.035 F254
G1 X74.861 Y103.905 F254
G1 X75.135 Y103.766 F254
G1 X75.685 Y103.493 F254
G1 X75.948 Y103.335 F254
G1 X76.171 Y103.124 F254
G1 X76.398 Y102.917 F254
G1 X76.606 Y102.691 F254
G1 X76.757 Y102.424 F254
G1 X76.924 Y102.166 F254
G1 X77.035 Y101.879 F254
G1 X77.113 Y101.582 F254
G1 X77.202 Y101.289 F254
G1 X77.285 Y100.993 F254
G1 X77.338 Y100.691 F254
G1 X77.364 Y100.385 F254
G1 X77.382 Y100.078 F254
G1 X77.384 Y99.771 F254
G1 X77.367 Y99.464 F254
G1 X77.334 Y99.159 F254
G1 X77.279 Y98.857 F254
G1 X77.2 Y98.56 F254
G1 X77.095 Y98.272 F254
G1 X77.023 Y98.085 F254
G1 X76.977 Y97.937 F254
G1 X76.944 Y97.788 F254
G1 X76.923 Y97.637 F254
G1 X76.918 Y97.485 F254
G1 X76.926 Y97.333 F254
G1 X76.952 Y97.149 F254
G1 X76.999 Y96.93 F254
G1 X77.085 Y96.635 F254
G1 X77.191 Y96.347 F254
G1 X77.282 Y96.054 F254
G1 X77.414 Y95.454 F254
G1 X77.45 Y95.149 F254
G1 X77.476 Y94.843 F254
G1 X77.507 Y94.538 F254
G1 X77.508 Y94.231 F254
G1 X77.504 Y93.924 F254
G1 X77.509 Y93.617 F254
G1 Y93.31 F254
G1 X77.511 Y93.003 F254
G1 X77.512 Y92.695 F254
G1 X77.501 Y92.389 F254
G1 X77.475 Y92.083 F254
G1 X77.451 Y91.777 F254
G1 X77.429 Y91.47 F254
G1 X77.36 Y90.552 F254
G1 X77.327 Y90.246 F254
G1 X77.278 Y89.943 F254
G1 X77.23 Y89.64 F254
G1 X77.179 Y89.337 F254
G1 X77.11 Y89.038 F254
G1 X77.04 Y88.739 F254
G1 X76.968 Y88.44 F254
G1 X76.88 Y88.146 F254
G1 X76.78 Y87.856 F254
G1 X76.589 Y87.272 F254
G1 X76.492 Y86.981 F254
G1 X76.39 Y86.692 F254
G1 X76.269 Y86.409 F254
G1 X76.138 Y86.132 F254
G1 X76.012 Y85.851 F254
G1 X75.758 Y85.293 F254
G1 X75.621 Y85.017 F254
G1 X75.467 Y84.752 F254
G1 X75.308 Y84.489 F254
G1 X75.153 Y84.224 F254
G1 X74.061 Y82.373 F254
G1 X73.902 Y82.11 F254
G1 X73.737 Y81.851 F254
G1 X73.569 Y81.595 F254
G1 X72.571 Y80.046 F254
G1 X72.406 Y79.787 F254
G1 X72.245 Y79.525 F254
G1 X71.462 Y78.204 F254
G1 X71.308 Y77.939 F254
G1 X71.159 Y77.67 F254
G1 X71.019 Y77.397 F254
G1 X70.881 Y77.123 F254
G1 X70.745 Y76.847 F254
G1 X70.617 Y76.568 F254
G1 X70.493 Y76.287 F254
G1 X70.367 Y76.007 F254
G1 X70.247 Y75.725 F254
G1 X70.132 Y75.44 F254
G1 X69.903 Y74.87 F254
G1 X69.792 Y74.584 F254
G1 X69.684 Y74.296 F254
G1 X69.579 Y74.008 F254
G1 X69.261 Y73.143 F254
G1 X69.158 Y72.854 F254
G1 X68.956 Y72.274 F254
G1 X68.856 Y71.984 F254
G1 X68.759 Y71.693 F254
G1 X68.665 Y71.4 F254
G1 X68.575 Y71.107 F254
G1 X68.498 Y70.809 F254
G1 X68.462 Y70.621 F254
G1 X68.444 Y70.47 F254
G1 X68.441 Y70.318 F254
G1 X68.453 Y70.166 F254
G1 X68.481 Y70.016 F254
G1 X68.524 Y69.87 F254
G1 X68.581 Y69.728 F254
G1 X68.65 Y69.593 F254
G1 X68.73 Y69.463 F254
G1 X68.857 Y69.289 F254
G1 X69.041 Y69.071 F254
G1 X69.255 Y68.852 F254
G1 X69.477 Y68.639 F254
G1 X69.681 Y68.41 F254
G1 X69.884 Y68.179 F254
G1 X70.089 Y67.951 F254
G1 X70.287 Y67.716 F254
G1 X70.466 Y67.467 F254
G1 X70.63 Y67.207 F254
G1 X70.792 Y66.946 F254
G1 X70.94 Y66.677 F254
G1 X71.08 Y66.404 F254
G1 X71.218 Y66.13 F254
G1 X71.347 Y65.851 F254
G1 X71.469 Y65.569 F254
G1 X71.587 Y65.286 F254
G1 X71.701 Y65 F254
G1 X71.812 Y64.714 F254
G1 X71.921 Y64.427 F254
G1 X72.028 Y64.139 F254
G1 X72.133 Y63.851 F254
G1 X72.34 Y63.272 F254
G1 X72.441 Y62.983 F254
G1 X72.54 Y62.692 F254
G1 X72.924 Y61.525 F254
G1 X73.02 Y61.234 F254
G1 X73.112 Y60.941 F254
G1 X73.372 Y60.057 F254
G1 X73.457 Y59.762 F254
G1 X73.539 Y59.466 F254
G1 X73.692 Y58.871 F254
G1 X73.768 Y58.574 F254
G1 X73.839 Y58.275 F254
G1 X73.906 Y57.975 F254
G1 X73.972 Y57.675 F254
G1 X74.034 Y57.375 F254
G1 X74.145 Y56.771 F254
G1 X74.198 Y56.468 F254
G1 X74.299 Y55.863 F254
G1 X74.351 Y55.56 F254
G1 X74.459 Y54.955 F254
G1 X74.622 Y54.049 F254
G1 X74.682 Y53.748 F254
G1 X74.75 Y53.448 F254
G1 X74.82 Y53.149 F254
G1 X74.896 Y52.852 F254
G1 X74.981 Y52.557 F254
G1 X75.07 Y52.263 F254
G1 X75.165 Y51.971 F254
G1 X75.274 Y51.684 F254
G1 X75.39 Y51.399 F254
G1 X75.508 Y51.14 F254
G1 X75.611 Y50.955 F254
G1 X75.694 Y50.827 F254
G1 X75.787 Y50.707 F254
G1 X75.896 Y50.6 F254
G1 X76.018 Y50.509 F254
G1 X76.152 Y50.436 F254
G1 X76.294 Y50.382 F254
G1 X76.442 Y50.345 F254
G1 X76.594 Y50.324 F254
G1 X76.832 Y50.308 F254
G1 X77.111 Y50.311 F254
G1 X77.417 Y50.336 F254
G1 X77.724 Y50.34 F254
G1 X78.031 Y50.328 F254
G1 X78.338 Y50.321 F254
G1 X78.642 Y50.284 F254
G1 X78.943 Y50.224 F254
G1 X79.243 Y50.158 F254
G1 X79.538 Y50.073 F254
G1 X79.831 Y49.979 F254
G1 X80.118 Y49.87 F254
G1 X80.402 Y49.754 F254
G1 X80.688 Y49.642 F254
G1 X80.973 Y49.529 F254
G1 X81.256 Y49.409 F254
G1 X81.532 Y49.273 F254
G1 X81.804 Y49.132 F254
G1 X82.078 Y48.993 F254
G1 X82.351 Y48.852 F254
G1 X82.617 Y48.699 F254
G1 X82.868 Y48.522 F254
G1 X83.117 Y48.342 F254
G1 X83.367 Y48.165 F254
G1 X83.607 Y47.972 F254
G1 X83.808 Y47.74 F254
G1 X83.997 Y47.499 F254
G1 X84.191 Y47.26 F254
G1 X84.265 Y47.165 F254
G1 X84.363 Y47.048 F254
G1 X84.471 Y46.94 F254
G1 X84.593 Y46.848 F254
G1 X84.729 Y46.78 F254
G1 X84.876 Y46.74 F254
G1 X85.028 Y46.728 F254
G1 X85.179 Y46.743 F254
G1 X85.326 Y46.783 F254
G1 X85.466 Y46.844 F254
G1 X85.613 Y46.926 F254
G1 X85.869 Y47.096 F254
G1 X86.113 Y47.282 F254
G1 X86.375 Y47.443 F254
G1 X86.912 Y47.74 F254
G1 X87.201 Y47.844 F254
G1 X87.502 Y47.902 F254
G1 X87.804 Y47.96 F254
G1 X88.107 Y48.011 F254
G1 X88.411 Y48.049 F254
G1 X88.714 Y48.1 F254
G1 X89.014 Y48.166 F254
G1 X89.312 Y48.239 F254
G1 X89.609 Y48.318 F254
G1 X89.905 Y48.399 F254
G1 X90.203 Y48.476 F254
G1 X90.504 Y48.533 F254
G1 X90.808 Y48.576 F254
G1 X91.114 Y48.609 F254
G1 X91.42 Y48.592 F254
G1 X91.707 Y48.483 F254
G1 X91.975 Y48.333 F254
G1 X92.218 Y48.145 F254
G1 X92.392 Y47.892 F254
G1 X92.506 Y47.606 F254
G1 X92.559 Y47.304 F254
G1 X92.58 Y46.998 F254
G1 X92.536 Y46.694 F254
G1 X92.353 Y46.107 F254
G1 X92.221 Y45.839 F254
G1 X92.164 Y45.697 F254
G1 X92.118 Y45.552 F254
G1 X92.089 Y45.402 F254
G1 X92.086 Y45.25 F254
G1 X92.114 Y45.1 F254
G1 X92.187 Y44.966 F254
G1 X92.291 Y44.855 F254
G1 X92.418 Y44.77 F254
G1 X92.559 Y44.713 F254
G1 X92.709 Y44.684 F254
G1 X92.861 Y44.679 F254
G1 X93.014 Y44.692 F254
G1 X93.178 Y44.718 F254
G1 X93.477 Y44.788 F254
G1 X93.771 Y44.878 F254
G1 X94.072 Y44.939 F254
G1 X94.378 Y44.966 F254
G1 X94.685 Y44.957 F254
G1 X94.99 Y44.923 F254
G1 X95.278 Y44.816 F254
G1 X95.553 Y44.679 F254
G1 X95.815 Y44.519 F254
G1 X96.022 Y44.292 F254
G1 X96.166 Y44.021 F254
G1 X96.289 Y43.74 F254
G1 X96.384 Y43.448 F254
G1 X96.399 Y43.141 F254
G1 X96.372 Y42.835 F254
G1 X96.332 Y42.531 F254
G1 X96.238 Y42.238 F254
G1 X96.184 Y42.096 F254
G1 X96.148 Y41.948 F254
G1 X96.136 Y41.796 F254
G1 X96.155 Y41.645 F254
G1 X96.209 Y41.502 F254
G1 X96.29 Y41.373 F254
G1 X96.394 Y41.262 F254
G1 X96.52 Y41.175 F254
G1 X96.66 Y41.115 F254
G1 X96.807 Y41.078 F254
G1 X96.959 Y41.06 F254
G1 X97.111 Y41.059 F254
G1 X97.269 Y41.072 F254
G1 X97.432 Y41.099 F254
G1 X97.641 Y41.149 F254
G1 X97.888 Y41.227 F254
G1 X98.173 Y41.341 F254
G1 X98.451 Y41.47 F254
G1 X98.729 Y41.601 F254
G1 X99 Y41.745 F254
G1 X99.536 Y42.045 F254
G1 X99.806 Y42.191 F254
G1 X100.082 Y42.325 F254
G1 X100.361 Y42.454 F254
G1 X100.639 Y42.585 F254
G1 X100.917 Y42.715 F254
G1 X101.203 Y42.827 F254
G1 X101.498 Y42.91 F254
G1 X101.795 Y42.991 F254
G1 X102.098 Y43.041 F254
G1 X102.403 Y43.069 F254
G1 X102.71 Y43.087 F254
G1 X103.015 Y43.054 F254
G1 X103.319 Y43.01 F254
G1 X103.616 Y42.932 F254
G1 X103.896 Y42.805 F254
G1 X104.172 Y42.671 F254
G1 X104.414 Y42.481 F254
G1 X104.641 Y42.275 F254
G1 X104.836 Y42.038 F254
G1 X104.992 Y41.774 F254
G1 X105.13 Y41.499 F254
G1 X105.206 Y41.202 F254
G1 X105.261 Y40.9 F254
G1 X105.271 Y40.593 F254
G1 X105.227 Y40.289 F254
G1 X105.174 Y39.987 F254
G1 X105.056 Y39.703 F254
G1 X104.925 Y39.426 F254
G1 X104.764 Y39.164 F254
G1 X104.566 Y38.929 F254
G1 X104.36 Y38.702 F254
G1 X104.117 Y38.513 F254
G1 X103.874 Y38.325 F254
G1 X103.632 Y38.136 F254
G1 X103.373 Y37.973 F254
G1 X103.095 Y37.841 F254
G1 X102.82 Y37.704 F254
G1 X102.544 Y37.57 F254
G1 X102.255 Y37.467 F254
G1 X101.959 Y37.384 F254
G1 X101.666 Y37.293 F254
G1 X100.785 Y37.023 F254
G1 X100.49 Y36.937 F254
G1 X100.189 Y36.878 F254
G1 X99.886 Y36.827 F254
G1 X99.585 Y36.77 F254
G1 X98.981 Y36.659 F254
G1 X98.377 Y36.548 F254
G1 X98.073 Y36.504 F254
G1 X97.768 Y36.465 F254
G1 X95.03 Y36.092 F254
G1 X94.726 Y36.049 F254
G1 X94.423 Y35.997 F254
G1 X93.82 Y35.881 F254
G1 X93.217 Y35.766 F254
G1 X92.916 Y35.707 F254
G1 X92.617 Y35.637 F254
G1 X92.319 Y35.562 F254
G1 X92.021 Y35.488 F254
G1 X91.724 Y35.411 F254
G1 X91.13 Y35.254 F254
G1 X90.832 Y35.181 F254
G1 X90.531 Y35.117 F254
G1 X90.231 Y35.053 F254
G1 X89.928 Y35.002 F254
G1 X89.622 Y34.976 F254
G1 X89.316 Y34.95 F254
G1 X89.01 Y34.929 F254
G1 X88.703 Y34.946 F254
G1 X88.397 Y34.966 F254
G1 X88.09 Y34.982 F254
G1 X87.785 Y35.01 F254
G1 X87.482 Y35.064 F254
G1 X86.876 Y35.163 F254
G1 X86.574 Y35.216 F254
G1 X86.272 Y35.275 F254
G1 X85.972 Y35.336 F254
G1 X85.369 Y35.455 F254
G1 X85.066 Y35.506 F254
G1 X84.762 Y35.548 F254
G1 X84.459 Y35.594 F254
G1 X84.155 Y35.639 F254
G1 X83.849 Y35.672 F254
G1 X83.543 Y35.689 F254
G1 X82.929 Y35.712 F254
G1 X82.622 Y35.724 F254
G1 X82.315 Y35.72 F254
G1 X82.009 Y35.697 F254
G1 X81.092 Y35.609 F254
G1 X80.787 Y35.573 F254
G1 X80.484 Y35.523 F254
G1 X78.677 Y35.167 F254
G1 X78.375 Y35.109 F254
G1 X78.073 Y35.057 F254
G1 X77.767 Y35.022 F254
G1 X77.461 Y35.006 F254
G1 X77.154 Y35.016 F254
G1 X76.849 Y35.049 F254
G1 X76.551 Y35.126 F254
G1 X76.252 Y35.193 F254
G1 X75.95 Y35.253 F254
G1 X75.664 Y35.304 F254
G1 X75.381 Y35.334 F254
G1 X75.074 Y35.344 F254
G1 X74.767 Y35.34 F254
G1 X74.461 Y35.324 F254
G1 X74.154 Y35.303 F254
G1 X73.849 Y35.275 F254
G1 X73.238 Y35.206 F254
G1 X72.934 Y35.167 F254
G1 X71.414 Y34.951 F254
G1 X71.11 Y34.909 F254
G1 X69.283 Y34.668 F254
G1 X68.978 Y34.633 F254
G1 X68.672 Y34.607 F254
G1 X68.366 Y34.582 F254
G1 X68.06 Y34.56 F254
G1 X67.753 Y34.549 F254
G1 X67.446 Y34.546 F254
G1 X67.139 Y34.541 F254
G1 X66.832 Y34.558 F254
G1 X66.527 Y34.591 F254
G1 X66.221 Y34.622 F254
G1 X65.923 Y34.692 F254
G1 X65.628 Y34.781 F254
G1 X65.335 Y34.87 F254
G1 X65.073 Y35.031 F254
G1 X64.816 Y35.199 F254
G1 X64.573 Y35.386 F254
G1 X64.38 Y35.626 F254
G1 X64.195 Y35.871 F254
G1 X64.048 Y36.14 F254
G1 X63.93 Y36.399 F254
G1 X63.856 Y36.535 F254
G1 X63.774 Y36.663 F254
G1 X63.678 Y36.781 F254
G1 X63.569 Y36.888 F254
G1 X63.449 Y36.982 F254
G1 X63.32 Y37.063 F254
G1 X63.184 Y37.132 F254
G1 X63.039 Y37.191 F254
G1 X62.882 Y37.243 F254
G1 X62.65 Y37.299 F254
G1 X62.358 Y37.348 F254
G1 X62.052 Y37.377 F254
G1 X61.745 Y37.388 F254
G1 X61.438 Y37.385 F254
G1 X61.131 Y37.378 F254
G1 X60.824 Y37.368 F254
G1 X60.519 Y37.341 F254
G1 X60.213 Y37.31 F254
G1 X59.907 Y37.283 F254
G1 X59.602 Y37.248 F254
G1 X59.299 Y37.199 F254
G1 X58.693 Y37.103 F254
G1 X58.39 Y37.051 F254
G1 X58.089 Y36.988 F254
G1 X57.789 Y36.922 F254
G1 X57.489 Y36.858 F254
G1 X57.189 Y36.791 F254
G1 X56.892 Y36.713 F254
G1 X56.596 Y36.634 F254
G1 X56.299 Y36.555 F254
G1 X56.003 Y36.475 F254
G1 X55.71 Y36.38 F254
G1 X55.124 Y36.199 F254
G1 X54.834 Y36.097 F254
G1 X54.544 Y35.997 F254
G1 X54.254 Y35.895 F254
G1 X53.967 Y35.785 F254
G1 X53.105 Y35.461 F254
G1 X52.815 Y35.36 F254
G1 X52.525 Y35.26 F254
G1 X51.945 Y35.059 F254
G1 X51.65 Y34.973 F254
G1 X51.349 Y34.912 F254
G1 X51.05 Y34.841 F254
G1 X50.452 Y34.703 F254
G1 X50.15 Y34.647 F254
G1 X49.844 Y34.619 F254
G1 X49.54 Y34.578 F254
G1 X49.234 Y34.55 F254
G1 X48.927 Y34.541 F254
G1 X48.621 Y34.521 F254
G1 X48.314 Y34.513 F254
G1 X48.007 Y34.527 F254
G1 X47.7 Y34.539 F254
G1 X47.393 Y34.549 F254
G1 X46.473 Y34.582 F254
G1 X46.166 Y34.598 F254
G1 X45.862 Y34.639 F254
G1 X45.56 Y34.697 F254
G1 X45.256 Y34.742 F254
G1 X44.953 Y34.793 F254
G1 X44.65 Y34.841 F254
G1 X44.347 Y34.892 F254
G1 X44.047 Y34.954 F254
G1 X43.75 Y35.035 F254
G1 X43.454 Y35.113 F254
G1 X43.156 Y35.189 F254
G1 X42.562 Y35.345 F254
G1 X41.97 Y35.508 F254
G1 X41.674 Y35.589 F254
G1 X41.377 Y35.667 F254
G1 X41.078 Y35.737 F254
G1 X40.776 Y35.793 F254
G1 X40.473 Y35.845 F254
G1 X40.171 Y35.9 F254
G1 X39.866 Y35.938 F254
G1 X39.56 Y35.959 F254
G1 X39.253 Y35.971 F254
G1 X38.946 Y35.976 F254
G1 X38.639 Y35.965 F254
G1 X38.334 Y35.938 F254
G1 X38.028 Y35.906 F254
G1 X37.724 Y35.861 F254
G1 X37.423 Y35.802 F254
G1 X37.121 Y35.749 F254
G1 X36.516 Y35.641 F254
G1 X36.213 Y35.589 F254
G1 X35.604 Y35.515 F254
G1 X35.299 Y35.48 F254
G1 X34.992 Y35.472 F254
G1 X34.685 Y35.492 F254
G1 X34.378 Y35.497 F254
G1 X34.073 Y35.527 F254
G1 X33.773 Y35.594 F254
G1 X33.474 Y35.664 F254
G1 X33.174 Y35.73 F254
G1 X32.882 Y35.824 F254
G1 X32.597 Y35.939 F254
G1 X32.31 Y36.049 F254
G1 X32.024 Y36.161 F254
G1 X31.742 Y36.281 F254
G1 X31.459 Y36.4 F254
G1 X30.893 Y36.637 F254
G1 X30.607 Y36.75 F254
G1 X30.365 Y36.827 F254
G1 X30.176 Y36.872 F254
G1 X30.001 Y36.9 F254
G1 X29.829 Y36.915 F254
G1 X29.644 Y36.918 F254
G1 X29.456 Y36.907 F254
G1 X29.235 Y36.877 F254
G1 X28.971 Y36.821 F254
G1 X28.676 Y36.736 F254
G1 X28.386 Y36.635 F254
G1 X28.097 Y36.531 F254
G1 X27.808 Y36.429 F254
G1 X27.515 Y36.337 F254
G1 X27.216 Y36.264 F254
G1 X26.917 Y36.194 F254
G1 X26.619 Y36.122 F254
G1 X26.316 Y36.073 F254
G1 X26.01 Y36.045 F254
G1 X25.705 Y36.014 F254
G1 X25.398 Y35.996 F254
G1 X25.092 Y36.02 F254
G1 X24.786 Y36.042 F254
G1 X24.479 Y36.062 F254
G1 X24.173 Y36.083 F254
G1 X23.868 Y36.119 F254
G1 X23.575 Y36.21 F254
G1 X23.285 Y36.312 F254
G1 X22.999 Y36.424 F254
G1 X22.742 Y36.592 F254
G1 X22.503 Y36.785 F254
G1 X22.307 Y37.021 F254
G1 X22.231 Y37.143 F254
G1 X22.147 Y37.27 F254
G1 X22.054 Y37.391 F254
G1 X21.948 Y37.5 F254
G1 X21.826 Y37.592 F254
G1 X21.691 Y37.663 F254
G1 X21.548 Y37.713 F254
G1 X21.398 Y37.744 F254
G1 X21.246 Y37.758 F254
G1 X21.094 Y37.759 F254
G1 X20.89 Y37.746 F254
G1 X20.586 Y37.703 F254
G1 X20.285 Y37.64 F254
G1 X19.984 Y37.578 F254
G1 X19.683 Y37.521 F254
G1 X19.38 Y37.473 F254
G1 X19.076 Y37.427 F254
G1 X18.773 Y37.379 F254
G1 X18.468 Y37.337 F254
G1 X18.163 Y37.304 F254
G1 X17.857 Y37.28 F254
G1 X17.55 Y37.279 F254
G1 X17.245 Y37.312 F254
G1 X16.942 Y37.362 F254
G1 X16.652 Y37.464 F254
G1 X16.4 Y37.64 F254
G1 X16.165 Y37.837 F254
G1 X16.061 Y37.95 F254
G1 X15.983 Y38.082 F254
G1 X15.886 Y38.374 F254
G1 X15.878 Y38.681 F254
G1 X15.826 Y39.293 F254
G1 X15.861 Y39.598 F254
G1 X15.928 Y39.897 F254
G1 X16.008 Y40.194 F254
G1 X16.124 Y40.478 F254
G1 X16.242 Y40.761 F254
G1 X16.393 Y41.029 F254
G1 X16.557 Y41.289 F254
G1 X16.722 Y41.547 F254
G1 X17.14 Y41.997 F254
G1 X17.359 Y42.212 F254
G1 X17.619 Y42.377 F254
G1 X17.882 Y42.535 F254
G1 X18.159 Y42.666 F254
G1 X18.456 Y42.747 F254
G1 X18.758 Y42.802 F254
G1 X19.371 Y42.827 F254
G1 X19.678 Y42.818 F254
G1 X19.983 Y42.783 F254
G1 X20.289 Y42.755 F254
G1 X20.596 Y42.74 F254
G1 X20.903 Y42.737 F254
G1 X21.21 Y42.752 F254
G1 X21.515 Y42.785 F254
G1 X21.817 Y42.837 F254
G1 X22.118 Y42.902 F254
G1 X22.716 Y43.042 F254
G1 X23.014 Y43.114 F254
G1 X23.312 Y43.189 F254
G1 X24.204 Y43.418 F254
G1 X24.503 Y43.489 F254
G1 X24.806 Y43.538 F254
G1 X25.111 Y43.569 F254
G1 X26.027 Y43.674 F254
G1 X26.332 Y43.704 F254
G1 X26.639 Y43.7 F254
G1 X26.791 Y43.68 F254
G1 X26.991 Y43.658 F254
G1 X27.144 Y43.653 F254
G1 X27.296 Y43.661 F254
G1 X27.446 Y43.687 F254
G1 X27.592 Y43.731 F254
G1 X27.731 Y43.794 F254
G1 X27.86 Y43.874 F254
G1 X27.977 Y43.972 F254
G1 X28.08 Y44.085 F254
G1 X28.169 Y44.208 F254
G1 X28.246 Y44.34 F254
G1 X28.328 Y44.511 F254
G1 X28.399 Y44.691 F254
G1 X28.473 Y44.931 F254
G1 X28.543 Y45.23 F254
G1 X28.602 Y45.532 F254
G1 X28.664 Y45.832 F254
G1 X28.727 Y46.133 F254
G1 X28.799 Y46.431 F254
G1 X28.878 Y46.728 F254
G1 X28.97 Y47.021 F254
G1 X29.101 Y47.299 F254
G1 X29.249 Y47.568 F254
G1 X29.441 Y47.807 F254
G1 X29.935 Y48.172 F254
G1 X30.219 Y48.289 F254
G1 X30.521 Y48.342 F254
G1 X30.824 Y48.393 F254
G1 X31.131 Y48.401 F254
G1 X31.433 Y48.345 F254
G1 X31.735 Y48.287 F254
G1 X32.027 Y48.193 F254
G1 X32.291 Y48.036 F254
G1 X32.538 Y47.854 F254
G1 X32.736 Y47.619 F254
G1 X32.914 Y47.369 F254
G1 X33.013 Y47.078 F254
G1 X33.078 Y46.778 F254
G1 X33.148 Y46.479 F254
G1 X33.174 Y46.173 F254
G1 X33.145 Y45.868 F254
G1 X33.111 Y45.416 F254
G1 X33.1 Y45.229 F254
G1 X33.103 Y45.077 F254
G1 X33.118 Y44.925 F254
G1 X33.147 Y44.776 F254
G1 X33.194 Y44.631 F254
G1 X33.261 Y44.494 F254
G1 X33.358 Y44.376 F254
G1 X33.48 Y44.284 F254
G1 X33.604 Y44.196 F254
G1 X33.755 Y44.178 F254
G1 X33.908 Y44.183 F254
G1 X34.058 Y44.208 F254
G1 X34.203 Y44.253 F254
G1 X34.342 Y44.316 F254
G1 X34.472 Y44.395 F254
G1 X34.593 Y44.488 F254
G1 X34.702 Y44.594 F254
G1 X34.827 Y44.737 F254
G1 X34.972 Y44.929 F254
G1 X35.129 Y45.172 F254
G1 X35.276 Y45.442 F254
G1 X35.419 Y45.713 F254
G1 X35.56 Y45.986 F254
G1 X35.703 Y46.258 F254
G1 X35.839 Y46.533 F254
G1 X36.39 Y47.631 F254
G1 X36.531 Y47.904 F254
G1 X36.69 Y48.167 F254
G1 X36.833 Y48.438 F254
G1 X36.984 Y48.705 F254
G1 X37.135 Y48.973 F254
G1 X37.315 Y49.222 F254
G1 X37.52 Y49.451 F254
G1 X37.717 Y49.686 F254
G1 X37.95 Y49.885 F254
G1 X38.188 Y50.08 F254
G1 X38.437 Y50.259 F254
G1 X38.704 Y50.41 F254
G1 X38.977 Y50.551 F254
G1 X39.263 Y50.664 F254
G1 X39.558 Y50.749 F254
G1 X39.859 Y50.811 F254
G1 X40.161 Y50.866 F254
G1 X40.467 Y50.889 F254
G1 X40.773 Y50.867 F254
G1 X41.076 Y50.816 F254
G1 X41.353 Y50.684 F254
G1 X41.493 Y50.62 F254
G1 X41.748 Y50.449 F254
G1 X41.932 Y50.203 F254
G1 X42.103 Y49.948 F254
G1 X42.22 Y49.664 F254
G1 X42.252 Y49.359 F254
G1 X42.267 Y49.052 F254
G1 X42.259 Y48.908 F254
G1 X42.253 Y48.755 F254
G1 X42.259 Y48.603 F254
G1 X42.281 Y48.452 F254
G1 X42.328 Y48.307 F254
G1 X42.404 Y48.175 F254
G1 X42.504 Y48.06 F254
G1 X42.623 Y47.965 F254
G1 X42.756 Y47.89 F254
G1 X42.9 Y47.84 F254
G1 X43.05 Y47.813 F254
G1 X43.202 Y47.806 F254
G1 X43.354 Y47.817 F254
G1 X43.504 Y47.844 F254
G1 X43.653 Y47.882 F254
G1 X43.841 Y47.946 F254
G1 X44.101 Y48.055 F254
G1 X44.375 Y48.195 F254
G1 X44.643 Y48.344 F254
G1 X44.919 Y48.478 F254
G1 X45.209 Y48.58 F254
G1 X45.51 Y48.64 F254
G1 X45.817 Y48.643 F254
G1 X46.121 Y48.599 F254
G1 X46.266 Y48.547 F254
G1 X46.4 Y48.473 F254
G1 X46.525 Y48.384 F254
G1 X46.739 Y48.164 F254
G1 X46.847 Y47.978 F254
G1 X46.947 Y47.83 F254
G1 X47.042 Y47.711 F254
G1 X47.15 Y47.603 F254
G1 X47.268 Y47.507 F254
G1 X47.402 Y47.434 F254
G1 X47.548 Y47.39 F254
G1 X47.617 Y47.358 F254
G1 X47.767 Y47.384 F254
G1 X47.913 Y47.429 F254
G1 X48.049 Y47.499 F254
G1 X48.173 Y47.587 F254
G1 X48.284 Y47.691 F254
G1 X48.381 Y47.809 F254
G1 X48.463 Y47.937 F254
G1 X48.531 Y48.073 F254
G1 X48.587 Y48.218 F254
G1 X48.659 Y48.452 F254
G1 X48.727 Y48.752 F254
G1 X48.777 Y49.055 F254
G1 X48.854 Y49.352 F254
G1 X49.029 Y49.941 F254
G1 X49.14 Y50.227 F254
G1 X49.244 Y50.516 F254
G1 X49.36 Y50.8 F254
G1 X49.487 Y51.08 F254
G1 X49.617 Y51.358 F254
G1 X49.754 Y51.633 F254
G1 X49.895 Y51.906 F254
G1 X50.042 Y52.175 F254
G1 X50.192 Y52.443 F254
G1 X50.344 Y52.71 F254
G1 X50.502 Y52.973 F254
G1 X50.823 Y53.497 F254
G1 X50.989 Y53.755 F254
G1 X51.337 Y54.261 F254
G1 X52.03 Y55.275 F254
G1 X52.204 Y55.528 F254
G1 X52.385 Y55.776 F254
G1 X52.756 Y56.265 F254
G1 X53.497 Y57.245 F254
G1 X53.683 Y57.489 F254
G1 X53.873 Y57.731 F254
G1 X54.634 Y58.695 F254
G1 X54.823 Y58.937 F254
G1 X55.011 Y59.179 F254
G1 X55.57 Y59.912 F254
G1 X55.755 Y60.157 F254
G1 X55.939 Y60.403 F254
G1 X56.12 Y60.651 F254
G1 X56.3 Y60.899 F254
G1 X56.479 Y61.149 F254
G1 X56.654 Y61.401 F254
G1 X56.751 Y61.561 F254
G1 X56.82 Y61.697 F254
G1 X56.878 Y61.838 F254
G1 X56.921 Y61.984 F254
G1 X56.948 Y62.134 F254
G1 X56.959 Y62.286 F254
G1 X56.956 Y62.441 F254
G1 X56.939 Y62.625 F254
G1 X56.897 Y62.878 F254
G1 X56.753 Y63.475 F254
G1 X56.73 Y63.782 F254
G1 X56.76 Y64.087 F254
G1 X56.795 Y64.392 F254
G1 X56.931 Y64.84 F254
G1 X56.965 Y64.988 F254
G1 X56.985 Y65.139 F254
G1 X56.99 Y65.291 F254
G1 X56.979 Y65.443 F254
G1 X56.948 Y65.593 F254
G1 X56.898 Y65.737 F254
G1 X56.833 Y65.874 F254
G1 X56.753 Y66.005 F254
G1 X56.662 Y66.13 F254
G1 X56.554 Y66.257 F254
G1 X56.441 Y66.371 F254
G1 X56.326 Y66.472 F254
G1 X56.204 Y66.563 F254
G1 X56.073 Y66.64 F254
G1 X55.933 Y66.7 F254
G1 X55.786 Y66.742 F254
G1 X55.635 Y66.764 F254
G1 X55.483 Y66.765 F254
G1 X55.332 Y66.743 F254
G1 X55.187 Y66.698 F254
G1 X55.049 Y66.632 F254
G1 X54.921 Y66.549 F254
G1 X54.803 Y66.453 F254
G1 X54.693 Y66.344 F254
G1 X54.58 Y66.214 F254
G1 X54.429 Y66.012 F254
G1 X54.263 Y65.754 F254
G1 X54.107 Y65.489 F254
G1 X53.935 Y65.235 F254
G1 X53.747 Y64.992 F254
G1 X53.543 Y64.762 F254
G1 X53.328 Y64.543 F254
G1 X53.104 Y64.334 F254
G1 X52.869 Y64.136 F254
G1 X52.629 Y63.945 F254
G1 X52.381 Y63.763 F254
G1 X51.873 Y63.417 F254
G1 X51.611 Y63.258 F254
G1 X51.341 Y63.111 F254
G1 X51.072 Y62.963 F254
G1 X50.802 Y62.817 F254
G1 X50.52 Y62.697 F254
G1 X50.236 Y62.58 F254
G1 X49.668 Y62.345 F254
G1 X49.374 Y62.258 F254
G1 X49.076 Y62.185 F254
G1 X48.779 Y62.104 F254
G1 X48.482 Y62.026 F254
G1 X48.185 Y61.952 F254
G1 X48.031 Y61.944 F254
G1 X47.725 Y61.915 F254
G1 X47.421 Y61.878 F254
G1 X47.115 Y61.846 F254
G1 X46.808 Y61.836 F254
G1 X46.502 Y61.851 F254
G1 X46.195 Y61.859 F254
G1 X45.888 Y61.873 F254
G1 X45.584 Y61.914 F254
G1 X45.28 Y61.959 F254
G1 X44.977 Y62.008 F254
G1 X44.681 Y62.091 F254
G1 X44.388 Y62.184 F254
G1 X44.093 Y62.266 F254
G1 X43.798 Y62.353 F254
G1 X43.504 Y62.441 F254
G1 X43.217 Y62.55 F254
G1 X42.67 Y62.83 F254
G1 X42.395 Y62.966 F254
G1 X42.121 Y63.104 F254
G1 X41.848 Y63.245 F254
G1 X41.588 Y63.408 F254
G1 X41.341 Y63.591 F254
G1 X41.092 Y63.77 F254
G1 X40.592 Y64.127 F254
G1 X40.346 Y64.311 F254
G1 X40.116 Y64.514 F254
G1 X39.895 Y64.727 F254
G1 X39.447 Y65.148 F254
G1 X39.224 Y65.359 F254
G1 X39.011 Y65.58 F254
G1 X38.813 Y65.815 F254
G1 X38.619 Y66.052 F254
G1 X38.226 Y66.525 F254
G1 X38.034 Y66.764 F254
G1 X37.863 Y67.019 F254
G1 X37.7 Y67.28 F254
G1 X37.369 Y67.797 F254
G1 X37.207 Y68.057 F254
G1 X37.064 Y68.329 F254
G1 X36.934 Y68.607 F254
G1 X36.667 Y69.16 F254
G1 X36.536 Y69.438 F254
G1 X36.421 Y69.723 F254
G1 X36.322 Y70.013 F254
G1 X36.215 Y70.301 F254
G1 X36.11 Y70.59 F254
G1 X36.009 Y70.88 F254
G1 X35.927 Y71.176 F254
G1 X35.854 Y71.474 F254
G1 X35.772 Y71.77 F254
G1 X35.698 Y72.068 F254
G1 X35.645 Y72.37 F254
G1 X35.601 Y72.674 F254
G1 X35.544 Y72.976 F254
G1 X35.514 Y73.282 F254
G1 X35.494 Y73.588 F254
G1 X35.473 Y73.894 F254
G1 X35.475 Y74.201 F254
G1 X35.488 Y74.508 F254
G1 X35.545 Y75.12 F254
G1 X35.589 Y75.707 F254
G1 Y75.96 F254
G1 X35.57 Y76.217 F254
G1 X35.526 Y76.512 F254
G1 X35.459 Y76.812 F254
G1 X35.376 Y77.107 F254
G1 X35.298 Y77.404 F254
G1 X35.177 Y78.006 F254
G1 X35.12 Y78.308 F254
G1 X35.079 Y78.612 F254
G1 X35.038 Y78.917 F254
G1 X34.996 Y79.221 F254
G1 X34.961 Y79.526 F254
G1 X34.881 Y80.443 F254
G1 X34.859 Y80.75 F254
G1 X34.845 Y81.056 F254
G1 X34.82 Y81.67 F254
G1 X34.811 Y81.977 F254
G1 X34.812 Y82.284 F254
G1 X34.819 Y82.591 F254
G1 X34.824 Y82.898 F254
G1 X34.834 Y83.205 F254
G1 X34.857 Y83.511 F254
G1 X34.887 Y83.817 F254
G1 X34.914 Y84.123 F254
G1 X34.948 Y84.428 F254
G1 X34.995 Y84.731 F254
G1 X35.093 Y85.338 F254
G1 X35.151 Y85.639 F254
G1 X35.283 Y86.239 F254
G1 X35.356 Y86.537 F254
G1 X35.521 Y87.129 F254
G1 X35.61 Y87.422 F254
G1 X35.705 Y87.714 F254
G1 X35.805 Y88.005 F254
G1 X35.912 Y88.292 F254
G1 X36.031 Y88.576 F254
G1 X36.157 Y88.856 F254
G1 X36.28 Y89.137 F254
G1 X36.432 Y89.404 F254
G1 X36.601 Y89.66 F254
G1 X36.763 Y89.921 F254
G1 X37.09 Y90.441 F254
G1 X37.261 Y90.696 F254
G1 X37.468 Y90.922 F254
G1 X37.674 Y91.151 F254
G1 X37.882 Y91.376 F254
G1 X38.11 Y91.582 F254
G1 X38.341 Y91.784 F254
G1 X38.569 Y91.99 F254
G1 X38.816 Y92.173 F254
G1 X39.069 Y92.347 F254
G1 X39.316 Y92.529 F254
G1 X39.58 Y92.686 F254
G1 X39.851 Y92.83 F254
G1 X40.12 Y92.978 F254
G1 X40.397 Y93.11 F254
G1 X40.685 Y93.216 F254
G1 X40.973 Y93.323 F254
G1 X41.264 Y93.422 F254
G1 X41.562 Y93.494 F254
G1 X42.162 Y93.627 F254
G1 X42.766 Y93.736 F254
G1 X43.068 Y93.794 F254
G1 X43.368 Y93.856 F254
G1 X43.669 Y93.919 F254
G1 X43.969 Y93.984 F254
G1 X44.268 Y94.053 F254
G1 X46.06 Y94.481 F254
G1 X46.359 Y94.553 F254
G1 X46.657 Y94.627 F254
G1 X47.251 Y94.781 F254
G1 X48.142 Y95.016 F254
G1 X48.438 Y95.096 F254
G1 X49.031 Y95.258 F254
G1 X49.326 Y95.341 F254
G1 X49.621 Y95.429 F254
G1 X49.914 Y95.521 F254
G1 X50.205 Y95.616 F254
G1 X50.496 Y95.715 F254
G1 X50.785 Y95.82 F254
G1 X51.071 Y95.932 F254
G1 X51.353 Y96.053 F254
G1 X51.63 Y96.185 F254
G1 X51.904 Y96.323 F254
G1 X52.179 Y96.459 F254
G1 X52.451 Y96.602 F254
G1 X52.715 Y96.759 F254
G1 X52.974 Y96.924 F254
G1 X53.489 Y97.258 F254
G1 X53.745 Y97.429 F254
G1 X53.996 Y97.605 F254
G1 X54.739 Y98.15 F254
G1 X55.234 Y98.513 F254
G1 X55.482 Y98.694 F254
G1 X55.731 Y98.874 F254
G1 X57.729 Y100.303 F254
G1 X57.979 Y100.482 F254
G1 X58.231 Y100.657 F254
G1 X58.487 Y100.826 F254
G1 X58.744 Y100.994 F254
G1 X59.003 Y101.159 F254
G1 X59.266 Y101.317 F254
G1 X59.536 Y101.465 F254
G1 X59.811 Y101.601 F254
G1 X60.085 Y101.74 F254
G1 X60.363 Y101.87 F254
G1 X60.654 Y101.968 F254
G1 X60.949 Y102.052 F254
G1 X61.243 Y102.14 F254
G1 X61.54 Y102.221 F254
G1 X61.841 Y102.28 F254
G1 X62.145 Y102.326 F254
G1 X62.449 Y102.367 F254
G1 X62.754 Y102.401 F254
G1 X63.06 Y102.432 F254
G1 X63.366 Y102.451 F254
G1 X63.673 Y102.467 F254
G1 X64.592 Y102.517 F254
G1 X64.899 Y102.532 F254
G1 X65.206 Y102.535 F254
G1 X65.513 Y102.526 F254
G1 X65.82 Y102.518 F254
G1 X66.127 Y102.499 F254
G1 X66.433 Y102.474 F254
G1 X66.675 Y102.47 F254
G1 X66.86 Y102.48 F254
G1 X67.026 Y102.501 F254
G1 X67.19 Y102.535 F254
G1 X67.353 Y102.581 F254
G1 X67.554 Y102.654 F254
G1 X67.8 Y102.765 F254
G1 X68.07 Y102.911 F254
G1 X68.33 Y103.074 F254
G1 X68.591 Y103.236 F254
G1 X68.866 Y103.374 F254
G1 X69.141 Y103.51 F254
G1 X69.42 Y103.638 F254
G1 X69.711 Y103.736 F254
G1 X70.003 Y103.831 F254
G1 X70.297 Y103.92 F254
G1 X70.598 Y103.982 F254
G1 X71.203 Y104.088 F254
G1 X71.507 Y104.126 F254
G1 X71.813 Y104.154 F254
G1 X72.119 Y104.18 F254
G1 X72.426 Y104.188 F254
G1 X72.733 Y104.174 F254
G1 X73.039 Y104.158 F254
G1 X73.345 Y104.13 F254
G1 X73.646 Y104.07 F254
G1 X73.944 Y103.997 F254
G1 X74.243 Y103.927 F254
G1 X74.538 Y103.84 F254
G1 X74.814 Y103.706 F254
G1 X75.087 Y103.566 F254
G1 X75.363 Y103.43 F254
G1 X75.638 Y103.293 F254
G1 X75.895 Y103.125 F254
G1 X76.11 Y102.906 F254
G1 X76.335 Y102.697 F254
G1 X76.521 Y102.453 F254
G1 X76.67 Y102.185 F254
G1 X76.815 Y101.914 F254
G1 X76.898 Y101.618 F254
G1 X76.982 Y101.323 F254
G1 X77.068 Y101.028 F254
G1 X77.131 Y100.728 F254
G1 X77.161 Y100.422 F254
G1 X77.179 Y100.115 F254
G1 X77.184 Y99.808 F254
G1 X77.169 Y99.502 F254
G1 X77.137 Y99.196 F254
G1 X77.083 Y98.894 F254
G1 X77.002 Y98.598 F254
G1 X76.896 Y98.31 F254
G1 X76.827 Y98.119 F254
G1 X76.782 Y97.958 F254
G1 X76.752 Y97.808 F254
G1 X76.733 Y97.657 F254
G1 X76.727 Y97.505 F254
G1 X76.733 Y97.338 F254
G1 X76.755 Y97.146 F254
G1 X76.792 Y96.949 F254
G1 X76.869 Y96.658 F254
G1 X76.969 Y96.367 F254
G1 X77.067 Y96.076 F254
G1 X77.139 Y95.778 F254
G1 X77.203 Y95.478 F254
G1 X77.247 Y95.174 F254
G1 X77.273 Y94.868 F254
G1 X77.303 Y94.562 F254
G1 X77.309 Y94.255 F254
G1 X77.305 Y93.948 F254
G1 X77.309 Y93.641 F254
G1 Y93.334 F254
G1 X77.312 Y92.72 F254
G1 X77.302 Y92.413 F254
G1 X77.276 Y92.107 F254
G1 X77.253 Y91.801 F254
G1 X77.231 Y91.495 F254
G1 X77.161 Y90.576 F254
G1 X77.129 Y90.271 F254
G1 X77.079 Y89.968 F254
G1 X77.031 Y89.664 F254
G1 X76.981 Y89.362 F254
G1 X76.841 Y88.764 F254
G1 X76.769 Y88.465 F254
G1 X76.679 Y88.172 F254
G1 X76.577 Y87.882 F254
G1 X76.483 Y87.59 F254
G1 X76.29 Y87.006 F254
G1 X76.187 Y86.717 F254
G1 X76.062 Y86.437 F254
G1 X75.93 Y86.159 F254
G1 X75.806 Y85.879 F254
G1 X75.55 Y85.32 F254
G1 X75.411 Y85.047 F254
G1 X75.094 Y84.521 F254
G1 X74.939 Y84.255 F254
G1 X74.783 Y83.991 F254
G1 X73.847 Y82.404 F254
G1 X73.687 Y82.142 F254
G1 X73.352 Y81.628 F254
G1 X73.186 Y81.369 F254
G1 X72.354 Y80.079 F254
G1 X72.19 Y79.819 F254
G1 X72.031 Y79.557 F254
G1 X71.718 Y79.028 F254
G1 X71.249 Y78.235 F254
G1 X71.095 Y77.97 F254
G1 X70.949 Y77.7 F254
G1 X70.81 Y77.426 F254
G1 X70.672 Y77.151 F254
G1 X70.537 Y76.876 F254
G1 X70.41 Y76.596 F254
G1 X70.287 Y76.315 F254
G1 X70.161 Y76.035 F254
G1 X70.041 Y75.752 F254
G1 X69.699 Y74.897 F254
G1 X69.588 Y74.611 F254
G1 X69.481 Y74.323 F254
G1 X69.376 Y74.034 F254
G1 X69.163 Y73.458 F254
G1 X69.058 Y73.17 F254
G1 X68.955 Y72.88 F254
G1 X68.753 Y72.3 F254
G1 X68.654 Y72.01 F254
G1 X68.557 Y71.718 F254
G1 X68.463 Y71.426 F254
G1 X68.374 Y71.132 F254
G1 X68.336 Y70.984 F254
G1 X68.284 Y70.753 F254
G1 X68.261 Y70.593 F254
G1 X68.249 Y70.441 F254
G1 X68.251 Y70.288 F254
G1 X68.265 Y70.137 F254
G1 X68.293 Y69.987 F254
G1 X68.333 Y69.84 F254
G1 X68.386 Y69.697 F254
G1 X68.451 Y69.559 F254
G1 X68.532 Y69.414 F254
G1 X68.638 Y69.255 F254
G1 X68.798 Y69.049 F254
G1 X69.003 Y68.821 F254
G1 X69.222 Y68.606 F254
G1 X69.438 Y68.387 F254
G1 X69.638 Y68.154 F254
G1 X69.843 Y67.925 F254
G1 X70.045 Y67.695 F254
G1 X70.233 Y67.452 F254
G1 X70.402 Y67.195 F254
G1 X70.564 Y66.934 F254
G1 X70.718 Y66.669 F254
G1 X70.859 Y66.396 F254
G1 X70.998 Y66.122 F254
G1 X71.131 Y65.845 F254
G1 X71.254 Y65.564 F254
G1 X71.372 Y65.281 F254
G1 X71.487 Y64.996 F254
G1 X71.599 Y64.71 F254
G1 X71.708 Y64.423 F254
G1 X71.816 Y64.135 F254
G1 X71.922 Y63.847 F254
G1 X72.128 Y63.269 F254
G1 X72.231 Y62.979 F254
G1 X72.33 Y62.689 F254
G1 X72.81 Y61.231 F254
G1 X72.903 Y60.938 F254
G1 X72.991 Y60.644 F254
G1 X73.25 Y59.76 F254
G1 X73.332 Y59.464 F254
G1 X73.41 Y59.167 F254
G1 X73.562 Y58.572 F254
G1 X73.634 Y58.273 F254
G1 X73.702 Y57.974 F254
G1 X73.768 Y57.674 F254
G1 X73.83 Y57.373 F254
G1 X73.887 Y57.071 F254
G1 X73.942 Y56.769 F254
G1 X73.996 Y56.467 F254
G1 X74.097 Y55.861 F254
G1 X74.148 Y55.559 F254
G1 X74.256 Y54.954 F254
G1 X74.419 Y54.047 F254
G1 X74.479 Y53.746 F254
G1 X74.545 Y53.446 F254
G1 X74.615 Y53.147 F254
G1 X74.69 Y52.85 F254
G1 X74.774 Y52.554 F254
G1 X74.862 Y52.26 F254
G1 X74.956 Y51.968 F254
G1 X75.061 Y51.679 F254
G1 X75.175 Y51.394 F254
G1 X75.3 Y51.114 F254
G1 X75.404 Y50.918 F254
G1 X75.494 Y50.773 F254
G1 X75.584 Y50.65 F254
G1 X75.686 Y50.536 F254
G1 X75.8 Y50.435 F254
G1 X75.924 Y50.347 F254
G1 X76.058 Y50.274 F254
G1 X76.199 Y50.216 F254
G1 X76.345 Y50.173 F254
G1 X76.494 Y50.144 F254
G1 X76.689 Y50.121 F254
G1 X76.94 Y50.11 F254
G1 X77.247 Y50.119 F254
G1 X77.553 Y50.142 F254
G1 X77.86 Y50.136 F254
G1 X78.167 Y50.124 F254
G1 X78.474 Y50.108 F254
G1 X78.776 Y50.055 F254
G1 X79.076 Y49.99 F254
G1 X79.374 Y49.915 F254
G1 X79.667 Y49.822 F254
G1 X79.956 Y49.719 F254
G1 X80.526 Y49.491 F254
G1 X80.812 Y49.378 F254
G1 X81.095 Y49.261 F254
G1 X81.373 Y49.13 F254
G1 X81.646 Y48.988 F254
G1 X82.193 Y48.709 F254
G1 X82.461 Y48.559 F254
G1 X82.715 Y48.387 F254
G1 X82.963 Y48.206 F254
G1 X83.214 Y48.028 F254
G1 X83.455 Y47.839 F254
G1 X83.658 Y47.609 F254
G1 X83.847 Y47.366 F254
G1 X84.159 Y46.981 F254
G1 X84.263 Y46.87 F254
G1 X84.378 Y46.77 F254
G1 X84.504 Y46.685 F254
G1 X84.641 Y46.617 F254
G1 X84.786 Y46.571 F254
G1 X84.936 Y46.546 F254
G1 X85.089 Y46.545 F254
G1 X85.24 Y46.566 F254
G1 X85.386 Y46.607 F254
G1 X85.528 Y46.664 F254
G1 X85.681 Y46.743 F254
G1 X85.89 Y46.87 F254
G1 X86.139 Y47.049 F254
G1 X86.392 Y47.223 F254
G1 X86.929 Y47.521 F254
G1 X87.212 Y47.64 F254
G1 X87.513 Y47.701 F254
G1 X87.815 Y47.758 F254
G1 X88.118 Y47.81 F254
G1 X88.422 Y47.849 F254
G1 X88.725 Y47.899 F254
G1 X89.025 Y47.963 F254
G1 X89.324 Y48.036 F254
G1 X89.621 Y48.114 F254
G1 X89.917 Y48.195 F254
G1 X90.214 Y48.272 F254
G1 X90.515 Y48.332 F254
G1 X90.819 Y48.376 F254
G1 X91.124 Y48.409 F254
G1 X91.278 Y48.4 F254
G1 X91.576 Y48.327 F254
G1 X91.844 Y48.177 F254
G1 X91.967 Y48.085 F254
G1 X92.073 Y47.975 F254
G1 X92.166 Y47.852 F254
G1 X92.308 Y47.58 F254
G1 X92.361 Y47.277 F254
G1 X92.381 Y46.971 F254
G1 X92.326 Y46.669 F254
G1 X92.226 Y46.378 F254
G1 X92.13 Y46.087 F254
G1 X92.056 Y45.942 F254
G1 X91.997 Y45.801 F254
G1 X91.949 Y45.657 F254
G1 X91.913 Y45.509 F254
G1 X91.898 Y45.357 F254
G1 X91.906 Y45.205 F254
G1 X91.941 Y45.057 F254
G1 X92.003 Y44.918 F254
G1 X92.093 Y44.794 F254
G1 X92.205 Y44.691 F254
G1 X92.334 Y44.609 F254
G1 X92.474 Y44.549 F254
G1 X92.621 Y44.51 F254
G1 X92.772 Y44.492 F254
G1 X92.925 F254
G1 X93.079 Y44.507 F254
G1 X93.322 Y44.547 F254
G1 X93.62 Y44.62 F254
G1 X93.915 Y44.709 F254
G1 X94.218 Y44.756 F254
G1 X94.525 Y44.766 F254
G1 X94.831 Y44.741 F254
G1 X95.128 Y44.665 F254
G1 X95.404 Y44.53 F254
G1 X95.669 Y44.375 F254
G1 X95.88 Y44.152 F254
G1 X96.014 Y43.875 F254
G1 X96.132 Y43.592 F254
G1 X96.202 Y43.293 F254
G1 X96.187 Y42.986 F254
G1 X96.151 Y42.682 F254
G1 X96.079 Y42.383 F254
G1 X96.023 Y42.232 F254
G1 X95.981 Y42.085 F254
G1 X95.956 Y41.935 F254
G1 X95.952 Y41.782 F254
G1 X95.972 Y41.631 F254
G1 X96.016 Y41.485 F254
G1 X96.083 Y41.349 F254
G1 X96.173 Y41.225 F254
G1 X96.282 Y41.119 F254
G1 X96.406 Y41.031 F254
G1 X96.542 Y40.962 F254
G1 X96.686 Y40.913 F254
G1 X96.836 Y40.882 F254
G1 X96.987 Y40.869 F254
G1 X97.14 Y40.87 F254
G1 X97.302 Y40.883 F254
G1 X97.495 Y40.914 F254
G1 X97.62 Y40.943 F254
G1 X97.84 Y41.003 F254
G1 X98.129 Y41.106 F254
G1 X98.41 Y41.23 F254
G1 X98.688 Y41.36 F254
G1 X98.963 Y41.498 F254
G1 X99.232 Y41.646 F254
G1 X99.499 Y41.796 F254
G1 X99.768 Y41.944 F254
G1 X100.041 Y42.085 F254
G1 X100.598 Y42.345 F254
G1 X100.876 Y42.475 F254
G1 X101.158 Y42.597 F254
G1 X101.45 Y42.692 F254
G1 X101.747 Y42.771 F254
G1 X102.047 Y42.833 F254
G1 X102.353 Y42.864 F254
G1 X102.659 Y42.884 F254
G1 X102.965 Y42.86 F254
G1 X103.269 Y42.815 F254
G1 X103.566 Y42.738 F254
G1 X103.844 Y42.608 F254
G1 X104.12 Y42.473 F254
G1 X104.35 Y42.27 F254
G1 X104.571 Y42.057 F254
G1 X104.747 Y41.805 F254
G1 X104.891 Y41.534 F254
G1 X104.995 Y41.245 F254
G1 X105.05 Y40.943 F254
G1 X105.072 Y40.636 F254
G1 X105.032 Y40.332 F254
G1 X104.978 Y40.03 F254
G1 X104.858 Y39.747 F254
G1 X104.724 Y39.471 F254
G1 X104.555 Y39.214 F254
G1 X104.349 Y38.987 F254
G1 X104.133 Y38.769 F254
G1 X103.885 Y38.588 F254
G1 X103.643 Y38.399 F254
G1 X103.395 Y38.218 F254
G1 X103.124 Y38.073 F254
G1 X102.846 Y37.942 F254
G1 X102.571 Y37.805 F254
G1 X102.288 Y37.688 F254
G1 X101.699 Y37.513 F254
G1 X101.406 Y37.422 F254
G1 X100.818 Y37.242 F254
G1 X100.524 Y37.155 F254
G1 X100.225 Y37.087 F254
G1 X99.922 Y37.036 F254
G1 X98.714 Y36.813 F254
G1 X98.412 Y36.758 F254
G1 X98.109 Y36.711 F254
G1 X97.804 Y36.671 F254
G1 X95.066 Y36.298 F254
G1 X94.762 Y36.256 F254
G1 X94.459 Y36.207 F254
G1 X94.157 Y36.15 F254
G1 X93.554 Y36.034 F254
G1 X93.252 Y35.977 F254
G1 X92.951 Y35.918 F254
G1 X92.651 Y35.851 F254
G1 X92.055 Y35.703 F254
G1 X91.758 Y35.627 F254
G1 X91.164 Y35.469 F254
G1 X90.866 Y35.395 F254
G1 X90.566 Y35.328 F254
G1 X90.266 Y35.265 F254
G1 X89.964 Y35.21 F254
G1 X89.658 Y35.179 F254
G1 X89.352 Y35.154 F254
G1 X89.046 Y35.131 F254
G1 X88.739 Y35.143 F254
G1 X88.433 Y35.164 F254
G1 X88.126 Y35.181 F254
G1 X87.82 Y35.207 F254
G1 X87.518 Y35.261 F254
G1 X86.912 Y35.36 F254
G1 X86.609 Y35.413 F254
G1 X86.308 Y35.472 F254
G1 X86.007 Y35.533 F254
G1 X85.405 Y35.652 F254
G1 X85.102 Y35.703 F254
G1 X84.798 Y35.745 F254
G1 X84.494 Y35.791 F254
G1 X84.19 Y35.836 F254
G1 X83.885 Y35.87 F254
G1 X83.579 Y35.888 F254
G1 X82.658 Y35.923 F254
G1 X82.351 Y35.921 F254
G1 X82.045 Y35.901 F254
G1 X81.739 Y35.872 F254
G1 X81.128 Y35.813 F254
G1 X80.823 Y35.779 F254
G1 X80.519 Y35.732 F254
G1 X80.217 Y35.675 F254
G1 X79.615 Y35.556 F254
G1 X78.41 Y35.319 F254
G1 X78.107 Y35.265 F254
G1 X77.803 Y35.226 F254
G1 X77.496 Y35.207 F254
G1 X77.189 Y35.214 F254
G1 X76.884 Y35.246 F254
G1 X76.587 Y35.323 F254
G1 X76.287 Y35.39 F254
G1 X75.986 Y35.449 F254
G1 X75.835 Y35.477 F254
G1 X75.551 Y35.518 F254
G1 X75.245 Y35.54 F254
G1 X74.938 Y35.543 F254
G1 X74.631 Y35.534 F254
G1 X74.324 Y35.516 F254
G1 X74.018 Y35.491 F254
G1 X73.713 Y35.461 F254
G1 X73.408 Y35.427 F254
G1 X73.103 Y35.391 F254
G1 X72.798 Y35.35 F254
G1 X71.582 Y35.177 F254
G1 X71.278 Y35.134 F254
G1 X70.974 Y35.092 F254
G1 X69.452 Y34.892 F254
G1 X69.147 Y34.853 F254
G1 X68.842 Y34.821 F254
G1 X68.23 Y34.772 F254
G1 X67.923 Y34.753 F254
G1 X67.616 Y34.747 F254
G1 X67.309 Y34.744 F254
G1 X67.002 Y34.746 F254
G1 X66.696 Y34.772 F254
G1 X66.391 Y34.806 F254
G1 X66.088 Y34.854 F254
G1 X65.793 Y34.939 F254
G1 X65.499 Y35.029 F254
G1 X65.224 Y35.166 F254
G1 X64.97 Y35.338 F254
G1 X64.723 Y35.521 F254
G1 X64.529 Y35.759 F254
G1 X64.345 Y36.005 F254
G1 X64.203 Y36.277 F254
G1 X64.121 Y36.458 F254
G1 X64.039 Y36.608 F254
G1 X63.956 Y36.736 F254
G1 X63.864 Y36.857 F254
G1 X63.76 Y36.97 F254
G1 X63.647 Y37.071 F254
G1 X63.524 Y37.162 F254
G1 X63.394 Y37.241 F254
G1 X63.256 Y37.31 F254
G1 X63.101 Y37.374 F254
G1 X62.902 Y37.439 F254
G1 X62.659 Y37.5 F254
G1 X62.397 Y37.545 F254
G1 X62.091 Y37.574 F254
G1 X61.784 Y37.587 F254
G1 X61.477 Y37.586 F254
G1 X61.17 Y37.579 F254
G1 X60.863 Y37.569 F254
G1 X60.557 Y37.546 F254
G1 X60.252 Y37.515 F254
G1 X59.946 Y37.487 F254
G1 X59.641 Y37.454 F254
G1 X59.337 Y37.408 F254
G1 X59.034 Y37.359 F254
G1 X58.731 Y37.311 F254
G1 X58.428 Y37.261 F254
G1 X58.127 Y37.201 F254
G1 X57.227 Y37.005 F254
G1 X56.929 Y36.93 F254
G1 X56.039 Y36.692 F254
G1 X55.745 Y36.602 F254
G1 X55.452 Y36.51 F254
G1 X55.159 Y36.419 F254
G1 X54.868 Y36.322 F254
G1 X54.288 Y36.119 F254
G1 X54 Y36.013 F254
G1 X53.713 Y35.903 F254
G1 X53.138 Y35.687 F254
G1 X52.85 Y35.583 F254
G1 X52.559 Y35.483 F254
G1 X51.979 Y35.282 F254
G1 X51.686 Y35.19 F254
G1 X51.386 Y35.122 F254
G1 X51.087 Y35.056 F254
G1 X50.788 Y34.986 F254
G1 X50.488 Y34.917 F254
G1 X50.187 Y34.857 F254
G1 X49.882 Y34.822 F254
G1 X49.577 Y34.786 F254
G1 X49.272 Y34.753 F254
G1 X48.965 Y34.742 F254
G1 X48.659 Y34.725 F254
G1 X48.352 Y34.714 F254
G1 X48.045 Y34.725 F254
G1 X47.738 Y34.738 F254
G1 X47.431 Y34.748 F254
G1 X46.511 Y34.781 F254
G1 X46.204 Y34.796 F254
G1 X45.899 Y34.836 F254
G1 X45.598 Y34.893 F254
G1 X45.294 Y34.939 F254
G1 X44.991 Y34.989 F254
G1 X44.688 Y35.037 F254
G1 X44.385 Y35.088 F254
G1 X44.085 Y35.151 F254
G1 X43.788 Y35.232 F254
G1 X43.491 Y35.31 F254
G1 X43.194 Y35.386 F254
G1 X42.6 Y35.542 F254
G1 X42.008 Y35.705 F254
G1 X41.712 Y35.786 F254
G1 X41.415 Y35.864 F254
G1 X41.116 Y35.934 F254
G1 X40.814 Y35.989 F254
G1 X40.511 Y36.041 F254
G1 X40.209 Y36.097 F254
G1 X39.904 Y36.135 F254
G1 X39.598 Y36.157 F254
G1 X39.291 Y36.17 F254
G1 X38.984 Y36.175 F254
G1 X38.677 Y36.167 F254
G1 X38.371 Y36.142 F254
G1 X38.066 Y36.111 F254
G1 X37.762 Y36.069 F254
G1 X37.158 Y35.958 F254
G1 X36.855 Y35.905 F254
G1 X36.553 Y35.851 F254
G1 X36.25 Y35.798 F254
G1 X35.946 Y35.757 F254
G1 X35.336 Y35.685 F254
G1 X35.029 Y35.672 F254
G1 X34.723 Y35.689 F254
G1 X34.416 Y35.697 F254
G1 X34.11 Y35.724 F254
G1 X33.81 Y35.791 F254
G1 X33.511 Y35.861 F254
G1 X33.212 Y35.927 F254
G1 X32.92 Y36.023 F254
G1 X32.636 Y36.139 F254
G1 X32.349 Y36.248 F254
G1 X32.063 Y36.36 F254
G1 X31.781 Y36.482 F254
G1 X30.931 Y36.838 F254
G1 X30.788 Y36.894 F254
G1 X30.525 Y36.986 F254
G1 X30.304 Y37.046 F254
G1 X30.105 Y37.084 F254
G1 X29.915 Y37.106 F254
G1 X29.718 Y37.115 F254
G1 X29.517 Y37.109 F254
G1 X29.29 Y37.085 F254
G1 X29.027 Y37.037 F254
G1 X28.729 Y36.961 F254
G1 X28.438 Y36.865 F254
G1 X27.859 Y36.659 F254
G1 X27.568 Y36.562 F254
G1 X27.271 Y36.482 F254
G1 X26.972 Y36.412 F254
G1 X26.674 Y36.341 F254
G1 X26.372 Y36.282 F254
G1 X26.067 Y36.25 F254
G1 X25.761 Y36.221 F254
G1 X25.455 Y36.199 F254
G1 X25.148 Y36.214 F254
G1 X24.842 Y36.239 F254
G1 X24.536 Y36.259 F254
G1 X24.229 Y36.28 F254
G1 X23.924 Y36.313 F254
G1 X23.63 Y36.401 F254
G1 X23.341 Y36.504 F254
G1 X23.055 Y36.617 F254
G1 X22.804 Y36.794 F254
G1 X22.574 Y36.997 F254
G1 X22.396 Y37.248 F254
G1 X22.31 Y37.375 F254
G1 X22.216 Y37.495 F254
G1 X22.111 Y37.605 F254
G1 X21.994 Y37.704 F254
G1 X21.866 Y37.786 F254
G1 X21.728 Y37.851 F254
G1 X21.583 Y37.898 F254
G1 X21.434 Y37.929 F254
G1 X21.282 Y37.946 F254
G1 X21.106 Y37.952 F254
G1 X20.911 Y37.944 F254
G1 X20.629 Y37.911 F254
G1 X20.328 Y37.854 F254
G1 X20.027 Y37.791 F254
G1 X19.726 Y37.732 F254
G1 X19.423 Y37.682 F254
G1 X19.119 Y37.636 F254
G1 X18.816 Y37.589 F254
G1 X18.512 Y37.545 F254
G1 X18.207 Y37.51 F254
G1 X17.901 Y37.483 F254
G1 X17.594 Y37.478 F254
G1 X17.288 Y37.508 F254
G1 X16.985 Y37.558 F254
G1 X16.696 Y37.661 F254
G1 X16.455 Y37.852 F254
G1 X16.341 Y37.954 F254
G1 X16.241 Y38.071 F254
G1 X16.169 Y38.206 F254
G1 X16.117 Y38.351 F254
G1 X16.071 Y38.654 F254
G1 X16.057 Y38.961 F254
G1 X16.029 Y39.267 F254
G1 X16.058 Y39.572 F254
G1 X16.127 Y39.872 F254
G1 X16.208 Y40.168 F254
G1 X16.33 Y40.45 F254
G1 X16.447 Y40.733 F254
G1 X16.607 Y40.995 F254
G1 X16.772 Y41.255 F254
G1 X16.946 Y41.508 F254
G1 X17.162 Y41.725 F254
G1 X17.373 Y41.949 F254
G1 X17.61 Y42.144 F254
G1 X17.876 Y42.297 F254
G1 X18.147 Y42.442 F254
G1 X18.439 Y42.538 F254
G1 X18.74 Y42.596 F254
G1 X19.047 Y42.615 F254
G1 X19.353 Y42.626 F254
G1 X19.66 Y42.619 F254
G1 X19.966 Y42.584 F254
G1 X20.271 Y42.556 F254
G1 X20.578 Y42.541 F254
G1 X20.885 Y42.538 F254
G1 X21.192 Y42.55 F254
G1 X21.497 Y42.582 F254
G1 X21.8 Y42.631 F254
G1 X22.101 Y42.694 F254
G1 X22.699 Y42.833 F254
G1 X22.998 Y42.904 F254
G1 X23.296 Y42.979 F254
G1 X24.188 Y43.208 F254
G1 X24.486 Y43.28 F254
G1 X24.789 Y43.333 F254
G1 X25.399 Y43.401 F254
G1 X26.009 Y43.471 F254
G1 X26.315 Y43.501 F254
G1 X26.622 F254
G1 X26.9 Y43.466 F254
G1 X27.069 Y43.458 F254
G1 X27.221 Y43.462 F254
G1 X27.373 Y43.478 F254
G1 X27.522 Y43.51 F254
G1 X27.667 Y43.558 F254
G1 X27.805 Y43.621 F254
G1 X27.936 Y43.699 F254
G1 X28.057 Y43.792 F254
G1 X28.167 Y43.897 F254
G1 X28.265 Y44.014 F254
G1 X28.351 Y44.14 F254
G1 X28.436 Y44.289 F254
G1 X28.518 Y44.461 F254
G1 X28.601 Y44.676 F254
G1 X28.682 Y44.941 F254
G1 X28.75 Y45.241 F254
G1 X28.808 Y45.543 F254
G1 X28.87 Y45.843 F254
G1 X28.934 Y46.143 F254
G1 X29.007 Y46.442 F254
G1 X29.089 Y46.738 F254
G1 X29.187 Y47.029 F254
G1 X29.329 Y47.301 F254
G1 X29.491 Y47.562 F254
G1 X29.716 Y47.77 F254
G1 X29.968 Y47.946 F254
G1 X30.24 Y48.088 F254
G1 X30.542 Y48.143 F254
G1 X30.845 Y48.193 F254
G1 X31.152 Y48.201 F254
G1 X31.453 Y48.137 F254
G1 X31.754 Y48.079 F254
G1 X32.039 Y47.965 F254
G1 X32.291 Y47.789 F254
G1 X32.517 Y47.581 F254
G1 X32.695 Y47.331 F254
G1 X32.816 Y47.049 F254
G1 X32.879 Y46.749 F254
G1 X32.95 Y46.45 F254
G1 X32.976 Y46.144 F254
G1 X32.941 Y45.839 F254
G1 X32.904 Y45.298 F254
G1 X32.905 Y45.122 F254
G1 X32.918 Y44.967 F254
G1 X32.942 Y44.817 F254
G1 X32.979 Y44.669 F254
G1 X33.033 Y44.527 F254
G1 X33.108 Y44.394 F254
G1 X33.203 Y44.275 F254
G1 X33.316 Y44.172 F254
G1 X33.436 Y44.079 F254
G1 X33.578 Y44.024 F254
G1 X33.729 Y43.998 F254
G1 X33.881 Y43.995 F254
G1 X34.033 Y44.012 F254
G1 X34.181 Y44.046 F254
G1 X34.324 Y44.098 F254
G1 X34.461 Y44.165 F254
G1 X34.59 Y44.247 F254
G1 X34.71 Y44.34 F254
G1 X34.829 Y44.45 F254
G1 X34.958 Y44.59 F254
G1 X35.088 Y44.753 F254
G1 X35.245 Y44.983 F254
G1 X35.4 Y45.248 F254
G1 X35.543 Y45.52 F254
G1 X35.827 Y46.064 F254
G1 X35.966 Y46.338 F254
G1 X36.102 Y46.613 F254
G1 X36.378 Y47.162 F254
G1 X36.516 Y47.436 F254
G1 X36.656 Y47.71 F254
G1 X36.958 Y48.244 F254
G1 X37.104 Y48.514 F254
G1 X37.256 Y48.781 F254
G1 X37.424 Y49.038 F254
G1 X37.825 Y49.503 F254
G1 X38.051 Y49.712 F254
G1 X38.29 Y49.904 F254
G1 X38.537 Y50.086 F254
G1 X38.805 Y50.237 F254
G1 X39.078 Y50.377 F254
G1 X39.364 Y50.489 F254
G1 X39.66 Y50.57 F254
G1 X39.962 Y50.627 F254
G1 X40.265 Y50.679 F254
G1 X40.571 Y50.688 F254
G1 X40.876 Y50.649 F254
G1 X41.17 Y50.56 F254
G1 X41.443 Y50.419 F254
G1 X41.683 Y50.227 F254
G1 X41.848 Y49.968 F254
G1 X41.997 Y49.7 F254
G1 X42.052 Y49.398 F254
G1 X42.065 Y49.091 F254
G1 X42.06 Y48.938 F254
G1 X42.057 Y48.752 F254
G1 X42.066 Y48.6 F254
G1 X42.089 Y48.449 F254
G1 X42.13 Y48.303 F254
G1 X42.193 Y48.164 F254
G1 X42.277 Y48.037 F254
G1 X42.38 Y47.924 F254
G1 X42.498 Y47.827 F254
G1 X42.627 Y47.747 F254
G1 X42.767 Y47.686 F254
G1 X42.914 Y47.645 F254
G1 X43.064 Y47.623 F254
G1 X43.217 Y47.618 F254
G1 X43.369 Y47.629 F254
G1 X43.519 Y47.652 F254
G1 X43.693 Y47.693 F254
G1 X43.887 Y47.754 F254
G1 X44.12 Y47.846 F254
G1 X44.396 Y47.98 F254
G1 X44.666 Y48.127 F254
G1 X44.939 Y48.267 F254
G1 X45.226 Y48.376 F254
G1 X45.526 Y48.44 F254
G1 X45.833 Y48.443 F254
G1 X45.985 Y48.418 F254
G1 X46.131 Y48.372 F254
G1 X46.269 Y48.304 F254
G1 X46.516 Y48.121 F254
G1 X46.685 Y47.865 F254
G1 X46.781 Y47.728 F254
G1 X46.877 Y47.609 F254
G1 X46.982 Y47.499 F254
G1 X47.097 Y47.399 F254
G1 X47.224 Y47.315 F254
G1 X47.377 Y47.245 F254
G1 X47.556 Y47.18 F254
G1 X47.593 Y47.153 F254
G1 X47.743 Y47.181 F254
G1 X47.891 Y47.219 F254
G1 X48.032 Y47.276 F254
G1 X48.165 Y47.351 F254
G1 X48.288 Y47.44 F254
G1 X48.401 Y47.543 F254
G1 X48.502 Y47.657 F254
G1 X48.59 Y47.781 F254
G1 X48.666 Y47.914 F254
G1 X48.73 Y48.052 F254
G1 X48.802 Y48.248 F254
G1 X48.879 Y48.514 F254
G1 X48.942 Y48.815 F254
G1 X48.994 Y49.117 F254
G1 X49.08 Y49.412 F254
G1 X49.168 Y49.706 F254
G1 X49.262 Y49.999 F254
G1 X49.374 Y50.284 F254
G1 X49.481 Y50.572 F254
G1 X49.603 Y50.854 F254
G1 X49.733 Y51.132 F254
G1 X49.865 Y51.409 F254
G1 X50.005 Y51.683 F254
G1 X50.148 Y51.954 F254
G1 X50.297 Y52.223 F254
G1 X50.449 Y52.49 F254
G1 X50.603 Y52.755 F254
G1 X50.924 Y53.279 F254
G1 X51.087 Y53.539 F254
G1 X51.258 Y53.794 F254
G1 X51.433 Y54.047 F254
G1 X52.126 Y55.061 F254
G1 X52.299 Y55.314 F254
G1 X52.477 Y55.565 F254
G1 X52.661 Y55.81 F254
G1 X52.847 Y56.054 F254
G1 X53.588 Y57.035 F254
G1 X53.774 Y57.279 F254
G1 X53.962 Y57.521 F254
G1 X54.913 Y58.727 F254
G1 X55.101 Y58.969 F254
G1 X55.288 Y59.213 F254
G1 X55.846 Y59.946 F254
G1 X56.031 Y60.191 F254
G1 X56.213 Y60.439 F254
G1 X56.393 Y60.687 F254
G1 X56.573 Y60.936 F254
G1 X56.749 Y61.187 F254
G1 X56.877 Y61.386 F254
G1 X56.961 Y61.54 F254
G1 X57.024 Y61.679 F254
G1 X57.075 Y61.823 F254
G1 X57.113 Y61.97 F254
G1 X57.138 Y62.121 F254
G1 X57.149 Y62.273 F254
G1 X57.148 Y62.444 F254
G1 X57.132 Y62.66 F254
G1 X57.099 Y62.877 F254
G1 X57.031 Y63.177 F254
G1 X56.958 Y63.475 F254
G1 X56.929 Y63.781 F254
G1 X56.961 Y64.086 F254
G1 X56.996 Y64.391 F254
G1 X57.093 Y64.683 F254
G1 X57.138 Y64.857 F254
G1 X57.164 Y65.007 F254
G1 X57.179 Y65.158 F254
G1 X57.18 Y65.311 F254
G1 X57.166 Y65.463 F254
G1 X57.137 Y65.612 F254
G1 X57.092 Y65.758 F254
G1 X57.033 Y65.898 F254
G1 X56.962 Y66.033 F254
G1 X56.879 Y66.161 F254
G1 X56.779 Y66.293 F254
G1 X56.665 Y66.421 F254
G1 X56.548 Y66.536 F254
G1 X56.431 Y66.634 F254
G1 X56.307 Y66.723 F254
G1 X56.175 Y66.799 F254
G1 X56.036 Y66.862 F254
G1 X55.892 Y66.91 F254
G1 X55.743 Y66.942 F254
G1 X55.591 Y66.955 F254
G1 X55.439 Y66.949 F254
G1 X55.288 Y66.924 F254
G1 X55.142 Y66.88 F254
G1 X55.003 Y66.819 F254
G1 X54.87 Y66.743 F254
G1 X54.747 Y66.655 F254
G1 X54.632 Y66.555 F254
G1 X54.515 Y66.436 F254
G1 X54.372 Y66.266 F254
G1 X54.198 Y66.027 F254
G1 X54.037 Y65.766 F254
G1 X53.878 Y65.503 F254
G1 X53.7 Y65.253 F254
G1 X53.504 Y65.016 F254
G1 X53.294 Y64.792 F254
G1 X53.074 Y64.578 F254
G1 X52.844 Y64.374 F254
G1 X52.606 Y64.181 F254
G1 X52.361 Y63.995 F254
G1 X52.11 Y63.819 F254
G1 X51.855 Y63.647 F254
G1 X51.597 Y63.482 F254
G1 X51.329 Y63.331 F254
G1 X50.79 Y63.037 F254
G1 X50.511 Y62.908 F254
G1 X50.227 Y62.793 F254
G1 X49.659 Y62.558 F254
G1 X49.367 Y62.463 F254
G1 X49.069 Y62.389 F254
G1 X48.476 Y62.231 F254
G1 X48.178 Y62.156 F254
G1 X47.872 Y62.13 F254
G1 X47.567 Y62.098 F254
G1 X47.262 Y62.061 F254
G1 X46.956 Y62.038 F254
G1 X46.649 Y62.042 F254
G1 X46.342 Y62.056 F254
G1 X46.035 Y62.065 F254
G1 X45.729 Y62.093 F254
G1 X45.122 Y62.187 F254
G1 X44.823 Y62.256 F254
G1 X44.53 Y62.348 F254
G1 X44.236 Y62.434 F254
G1 X43.94 Y62.519 F254
G1 X43.646 Y62.607 F254
G1 X43.357 Y62.71 F254
G1 X43.081 Y62.844 F254
G1 X42.808 Y62.985 F254
G1 X42.533 Y63.121 F254
G1 X42.258 Y63.258 F254
G1 X41.985 Y63.399 F254
G1 X41.723 Y63.559 F254
G1 X41.475 Y63.74 F254
G1 X41.226 Y63.92 F254
G1 X40.726 Y64.276 F254
G1 X40.48 Y64.46 F254
G1 X40.249 Y64.662 F254
G1 X40.029 Y64.876 F254
G1 X39.581 Y65.296 F254
G1 X39.358 Y65.508 F254
G1 X39.145 Y65.729 F254
G1 X38.949 Y65.965 F254
G1 X38.754 Y66.203 F254
G1 X38.362 Y66.675 F254
G1 X38.17 Y66.915 F254
G1 X38.002 Y67.172 F254
G1 X37.84 Y67.433 F254
G1 X37.674 Y67.691 F254
G1 X37.509 Y67.95 F254
G1 X37.347 Y68.211 F254
G1 X37.21 Y68.486 F254
G1 X37.081 Y68.764 F254
G1 X36.946 Y69.04 F254
G1 X36.813 Y69.317 F254
G1 X36.684 Y69.596 F254
G1 X36.576 Y69.883 F254
G1 X36.477 Y70.173 F254
G1 X36.368 Y70.461 F254
G1 X36.265 Y70.75 F254
G1 X36.168 Y71.041 F254
G1 X36.017 Y71.637 F254
G1 X35.936 Y71.933 F254
G1 X35.869 Y72.232 F254
G1 X35.823 Y72.536 F254
G1 X35.775 Y72.839 F254
G1 X35.725 Y73.142 F254
G1 X35.703 Y73.448 F254
G1 X35.683 Y73.755 F254
G1 X35.671 Y74.062 F254
G1 X35.682 Y74.369 F254
G1 X35.703 Y74.675 F254
G1 X35.733 Y74.98 F254
G1 X35.759 Y75.286 F254
G1 X35.781 Y75.593 F254
G1 X35.789 Y75.859 F254
G1 X35.777 Y76.13 F254
G1 X35.742 Y76.428 F254
G1 X35.684 Y76.73 F254
G1 X35.607 Y77.027 F254
G1 X35.525 Y77.323 F254
G1 X35.456 Y77.622 F254
G1 X35.339 Y78.225 F254
G1 X35.291 Y78.528 F254
G1 X35.251 Y78.833 F254
G1 X35.21 Y79.137 F254
G1 X35.171 Y79.442 F254
G1 X35.142 Y79.747 F254
G1 X35.116 Y80.053 F254
G1 X35.089 Y80.359 F254
G1 X35.065 Y80.665 F254
G1 X35.048 Y80.972 F254
G1 X35.024 Y81.586 F254
G1 X35.013 Y81.893 F254
G1 X35.011 Y82.2 F254
G1 X35.023 Y82.814 F254
G1 X35.031 Y83.121 F254
G1 X35.05 Y83.427 F254
G1 X35.08 Y83.733 F254
G1 X35.108 Y84.038 F254
G1 X35.14 Y84.344 F254
G1 X35.184 Y84.648 F254
G1 X35.282 Y85.254 F254
G1 X35.339 Y85.556 F254
G1 X35.47 Y86.156 F254
G1 X35.541 Y86.454 F254
G1 X35.622 Y86.75 F254
G1 X35.705 Y87.046 F254
G1 X35.794 Y87.34 F254
G1 X35.889 Y87.632 F254
G1 X35.988 Y87.923 F254
G1 X36.095 Y88.21 F254
G1 X36.214 Y88.494 F254
G1 X36.34 Y88.774 F254
G1 X36.462 Y89.055 F254
G1 X36.615 Y89.322 F254
G1 X36.786 Y89.577 F254
G1 X36.947 Y89.838 F254
G1 X37.274 Y90.358 F254
G1 X37.446 Y90.612 F254
G1 X37.659 Y90.833 F254
G1 X37.863 Y91.063 F254
G1 X38.073 Y91.287 F254
G1 X38.305 Y91.488 F254
G1 X38.536 Y91.69 F254
G1 X38.766 Y91.894 F254
G1 X39.27 Y92.245 F254
G1 X39.52 Y92.424 F254
G1 X39.789 Y92.571 F254
G1 X40.331 Y92.86 F254
G1 X40.614 Y92.98 F254
G1 X40.903 Y93.083 F254
G1 X41.191 Y93.188 F254
G1 X41.486 Y93.273 F254
G1 X41.786 Y93.339 F254
G1 X42.086 Y93.405 F254
G1 X42.387 Y93.465 F254
G1 X42.69 Y93.518 F254
G1 X42.991 Y93.576 F254
G1 X43.292 Y93.636 F254
G1 X43.593 Y93.699 F254
G1 X43.893 Y93.763 F254
G1 X44.193 Y93.83 F254
G1 X44.492 Y93.901 F254
G1 X46.284 Y94.329 F254
G1 X46.582 Y94.402 F254
G1 X46.879 Y94.478 F254
G1 X47.474 Y94.633 F254
G1 X48.068 Y94.789 F254
G1 X48.364 Y94.868 F254
G1 X48.957 Y95.03 F254
G1 X49.252 Y95.113 F254
G1 X49.547 Y95.198 F254
G1 X49.841 Y95.288 F254
G1 X50.133 Y95.382 F254
G1 X50.424 Y95.479 F254
G1 X50.714 Y95.581 F254
G1 X51.001 Y95.689 F254
G1 X51.286 Y95.806 F254
G1 X51.566 Y95.932 F254
G1 X51.841 Y96.067 F254
G1 X52.39 Y96.343 F254
G1 X52.659 Y96.491 F254
G1 X52.921 Y96.652 F254
G1 X53.436 Y96.986 F254
G1 X53.693 Y97.153 F254
G1 X53.948 Y97.326 F254
G1 X54.197 Y97.504 F254
G1 X54.94 Y98.049 F254
G1 X55.187 Y98.231 F254
G1 X55.683 Y98.593 F254
G1 X57.182 Y99.665 F254
G1 X57.931 Y100.202 F254
G1 X58.181 Y100.379 F254
G1 X58.435 Y100.553 F254
G1 X58.691 Y100.721 F254
G1 X58.949 Y100.888 F254
G1 X59.209 Y101.051 F254
G1 X59.475 Y101.205 F254
G1 X59.747 Y101.348 F254
G1 X60.297 Y101.62 F254
G1 X60.581 Y101.737 F254
G1 X60.875 Y101.824 F254
G1 X61.465 Y101.995 F254
G1 X61.765 Y102.063 F254
G1 X62.068 Y102.112 F254
G1 X62.372 Y102.155 F254
G1 X62.677 Y102.192 F254
G1 X62.982 Y102.223 F254
G1 X63.288 Y102.247 F254
G1 X64.208 Y102.296 F254
G1 X64.515 Y102.312 F254
G1 X64.822 Y102.328 F254
G1 X65.128 Y102.335 F254
G1 X65.435 Y102.329 F254
G1 X65.742 Y102.32 F254
G1 X66.049 Y102.304 F254
G1 X66.355 Y102.28 F254
G1 X66.499 Y102.275 F254
G1 X66.712 Y102.274 F254
G1 X66.907 Y102.288 F254
G1 X67.093 Y102.315 F254
G1 X67.274 Y102.355 F254
G1 X67.475 Y102.416 F254
G1 X67.71 Y102.506 F254
G1 X67.976 Y102.631 F254
G1 X68.243 Y102.781 F254
G1 X68.502 Y102.947 F254
G1 X68.765 Y103.105 F254
G1 X69.042 Y103.237 F254
G1 X69.318 Y103.372 F254
G1 X69.6 Y103.493 F254
G1 X69.893 Y103.585 F254
G1 X70.186 Y103.678 F254
G1 X70.482 Y103.758 F254
G1 X70.785 Y103.812 F254
G1 X71.087 Y103.865 F254
G1 X71.39 Y103.912 F254
G1 X71.696 Y103.943 F254
G1 X72.002 Y103.97 F254
G1 X72.308 Y103.987 F254
G1 X72.615 Y103.981 F254
G1 X72.922 Y103.964 F254
G1 X73.228 Y103.941 F254
G1 X73.531 Y103.891 F254
G1 X74.128 Y103.748 F254
G1 X74.424 Y103.666 F254
G1 X74.704 Y103.539 F254
G1 X74.976 Y103.398 F254
G1 X75.252 Y103.262 F254
G1 X75.527 Y103.125 F254
G1 X75.785 Y102.959 F254
G1 X75.996 Y102.736 F254
G1 X76.223 Y102.529 F254
G1 X76.397 Y102.276 F254
G1 X76.539 Y102.004 F254
G1 X76.67 Y101.726 F254
G1 X76.742 Y101.428 F254
G1 X76.829 Y101.133 F254
G1 X76.907 Y100.836 F254
G1 X76.952 Y100.533 F254
G1 X76.973 Y100.226 F254
G1 X76.984 Y99.919 F254
G1 X76.976 Y99.612 F254
G1 X76.948 Y99.307 F254
G1 X76.9 Y99.003 F254
G1 X76.826 Y98.706 F254
G1 X76.723 Y98.416 F254
G1 X76.65 Y98.214 F254
G1 X76.598 Y98.031 F254
G1 X76.564 Y97.862 F254
G1 X76.543 Y97.699 F254
G1 X76.534 Y97.531 F254
G1 X76.538 Y97.345 F254
G1 X76.557 Y97.146 F254
G1 X76.593 Y96.936 F254
G1 X76.661 Y96.662 F254
G1 X76.756 Y96.37 F254
G1 X76.855 Y96.079 F254
G1 X76.934 Y95.782 F254
G1 X76.998 Y95.482 F254
G1 X77.045 Y95.179 F254
G1 X77.072 Y94.873 F254
G1 X77.102 Y94.567 F254
G1 X77.109 Y94.26 F254
G1 X77.105 Y93.953 F254
G1 X77.108 Y93.646 F254
G1 X77.112 Y92.725 F254
G1 X77.102 Y92.418 F254
G1 X77.076 Y92.112 F254
G1 X77.052 Y91.806 F254
G1 X77.03 Y91.5 F254
G1 X76.961 Y90.581 F254
G1 X76.928 Y90.276 F254
G1 X76.877 Y89.973 F254
G1 X76.829 Y89.67 F254
G1 X76.779 Y89.367 F254
G1 X76.706 Y89.069 F254
G1 X76.637 Y88.769 F254
G1 X76.564 Y88.471 F254
G1 X76.471 Y88.179 F254
G1 X76.368 Y87.889 F254
G1 X76.275 Y87.596 F254
G1 X76.082 Y87.014 F254
G1 X75.976 Y86.725 F254
G1 X75.715 Y86.17 F254
G1 X75.591 Y85.889 F254
G1 X75.334 Y85.331 F254
G1 X75.189 Y85.06 F254
G1 X75.027 Y84.799 F254
G1 X74.87 Y84.535 F254
G1 X74.716 Y84.27 F254
G1 X74.559 Y84.006 F254
G1 X73.779 Y82.683 F254
G1 X73.622 Y82.419 F254
G1 X73.461 Y82.158 F254
G1 X73.292 Y81.902 F254
G1 X73.125 Y81.644 F254
G1 X72.959 Y81.386 F254
G1 X72.293 Y80.354 F254
G1 X72.128 Y80.095 F254
G1 X71.965 Y79.835 F254
G1 X71.807 Y79.571 F254
G1 X71.495 Y79.043 F254
G1 X71.181 Y78.514 F254
G1 X71.026 Y78.25 F254
G1 X70.874 Y77.983 F254
G1 X70.729 Y77.712 F254
G1 X70.592 Y77.437 F254
G1 X70.455 Y77.163 F254
G1 X70.321 Y76.886 F254
G1 X70.196 Y76.606 F254
G1 X70.072 Y76.325 F254
G1 X69.947 Y76.044 F254
G1 X69.829 Y75.761 F254
G1 X69.487 Y74.906 F254
G1 X69.377 Y74.619 F254
G1 X69.271 Y74.331 F254
G1 X69.166 Y74.042 F254
G1 X69.059 Y73.754 F254
G1 X68.848 Y73.178 F254
G1 X68.745 Y72.888 F254
G1 X68.545 Y72.308 F254
G1 X68.445 Y72.017 F254
G1 X68.349 Y71.726 F254
G1 X68.256 Y71.433 F254
G1 X68.168 Y71.139 F254
G1 X68.099 Y70.843 F254
G1 X68.071 Y70.656 F254
G1 X68.057 Y70.487 F254
G1 X68.056 Y70.329 F254
G1 X68.067 Y70.177 F254
G1 X68.089 Y70.026 F254
G1 X68.122 Y69.877 F254
G1 X68.167 Y69.732 F254
G1 X68.224 Y69.587 F254
G1 X68.298 Y69.435 F254
G1 X68.392 Y69.272 F254
G1 X68.525 Y69.077 F254
G1 X68.703 Y68.854 F254
G1 X68.911 Y68.628 F254
G1 X69.132 Y68.415 F254
G1 X69.345 Y68.194 F254
G1 X69.543 Y67.959 F254
G1 X69.748 Y67.731 F254
G1 X69.948 Y67.498 F254
G1 X70.13 Y67.251 F254
G1 X70.294 Y66.991 F254
G1 X70.454 Y66.729 F254
G1 X70.603 Y66.461 F254
G1 X70.741 Y66.186 F254
G1 X70.878 Y65.912 F254
G1 X71.007 Y65.633 F254
G1 X71.127 Y65.35 F254
G1 X71.244 Y65.066 F254
G1 X71.357 Y64.781 F254
G1 X71.467 Y64.494 F254
G1 X71.576 Y64.207 F254
G1 X71.683 Y63.919 F254
G1 X71.787 Y63.63 F254
G1 X71.993 Y63.052 F254
G1 X72.094 Y62.762 F254
G1 X72.191 Y62.471 F254
G1 X72.576 Y61.304 F254
G1 X72.67 Y61.012 F254
G1 X72.76 Y60.718 F254
G1 X73.02 Y59.834 F254
G1 X73.104 Y59.539 F254
G1 X73.184 Y59.243 F254
G1 X73.337 Y58.648 F254
G1 X73.411 Y58.35 F254
G1 X73.48 Y58.051 F254
G1 X73.546 Y57.751 F254
G1 X73.61 Y57.451 F254
G1 X73.669 Y57.149 F254
G1 X73.725 Y56.847 F254
G1 X73.779 Y56.545 F254
G1 X73.831 Y56.242 F254
G1 X73.932 Y55.637 F254
G1 X73.985 Y55.334 F254
G1 X74.202 Y54.125 F254
G1 X74.259 Y53.824 F254
G1 X74.323 Y53.523 F254
G1 X74.391 Y53.224 F254
G1 X74.464 Y52.926 F254
G1 X74.544 Y52.629 F254
G1 X74.63 Y52.334 F254
G1 X74.721 Y52.041 F254
G1 X74.821 Y51.751 F254
G1 X74.931 Y51.464 F254
G1 X75.05 Y51.181 F254
G1 X75.163 Y50.945 F254
G1 X75.268 Y50.761 F254
G1 X75.357 Y50.629 F254
G1 X75.451 Y50.509 F254
G1 X75.555 Y50.398 F254
G1 X75.669 Y50.297 F254
G1 X75.793 Y50.207 F254
G1 X75.924 Y50.129 F254
G1 X76.062 Y50.065 F254
G1 X76.205 Y50.013 F254
G1 X76.353 Y49.975 F254
G1 X76.53 Y49.943 F254
G1 X76.757 Y49.92 F254
G1 X77.047 Y49.911 F254
G1 X77.354 Y49.925 F254
G1 X77.66 Y49.945 F254
G1 X77.967 Y49.931 F254
G1 X78.274 Y49.919 F254
G1 X78.579 Y49.892 F254
G1 X78.88 Y49.829 F254
G1 X79.179 Y49.759 F254
G1 X79.474 Y49.675 F254
G1 X79.765 Y49.576 F254
G1 X80.052 Y49.466 F254
G1 X80.336 Y49.351 F254
G1 X80.622 Y49.238 F254
G1 X80.907 Y49.123 F254
G1 X81.187 Y48.998 F254
G1 X81.461 Y48.86 F254
G1 X81.734 Y48.719 F254
G1 X82.008 Y48.579 F254
G1 X82.278 Y48.433 F254
G1 X82.537 Y48.268 F254
G1 X83.035 Y47.91 F254
G1 X83.279 Y47.723 F254
G1 X83.49 Y47.5 F254
G1 X83.678 Y47.257 F254
G1 X83.871 Y47.019 F254
G1 X83.999 Y46.866 F254
G1 X84.104 Y46.756 F254
G1 X84.218 Y46.654 F254
G1 X84.34 Y46.564 F254
G1 X84.472 Y46.487 F254
G1 X84.612 Y46.427 F254
G1 X84.759 Y46.385 F254
G1 X84.909 Y46.362 F254
G1 X85.062 Y46.357 F254
G1 X85.213 Y46.371 F254
G1 X85.363 Y46.402 F254
G1 X85.508 Y46.449 F254
G1 X85.65 Y46.511 F254
G1 X85.836 Y46.607 F254
G1 X86.097 Y46.769 F254
G1 X86.345 Y46.95 F254
G1 X86.603 Y47.116 F254
G1 X86.874 Y47.261 F254
G1 X87.147 Y47.401 F254
G1 X87.442 Y47.488 F254
G1 X87.744 Y47.541 F254
G1 X88.046 Y47.596 F254
G1 X88.35 Y47.639 F254
G1 X88.654 Y47.684 F254
G1 X88.955 Y47.743 F254
G1 X89.254 Y47.813 F254
G1 X89.552 Y47.889 F254
G1 X90.145 Y48.048 F254
G1 X90.444 Y48.116 F254
G1 X90.748 Y48.165 F254
G1 X91.052 Y48.201 F254
G1 X91.359 Y48.186 F254
G1 X91.643 Y48.069 F254
G1 X91.768 Y47.979 F254
G1 X91.879 Y47.874 F254
G1 X91.973 Y47.753 F254
G1 X92.053 Y47.622 F254
G1 X92.159 Y47.333 F254
G1 X92.176 Y47.027 F254
G1 X92.136 Y46.722 F254
G1 X92.033 Y46.433 F254
G1 X91.937 Y46.141 F254
G1 X91.861 Y45.982 F254
G1 X91.804 Y45.836 F254
G1 X91.759 Y45.69 F254
G1 X91.727 Y45.541 F254
G1 X91.712 Y45.39 F254
G1 X91.715 Y45.237 F254
G1 X91.739 Y45.087 F254
G1 X91.786 Y44.942 F254
G1 X91.857 Y44.807 F254
G1 X91.947 Y44.684 F254
G1 X92.055 Y44.577 F254
G1 X92.177 Y44.485 F254
G1 X92.311 Y44.412 F254
G1 X92.454 Y44.359 F254
G1 X92.602 Y44.323 F254
G1 X92.753 Y44.305 F254
G1 X92.906 Y44.302 F254
G1 X93.092 Y44.314 F254
G1 X93.286 Y44.341 F254
G1 X93.586 Y44.405 F254
G1 X93.881 Y44.489 F254
G1 X94.182 Y44.551 F254
G1 X94.489 Y44.566 F254
G1 X94.795 Y44.544 F254
G1 X95.092 Y44.467 F254
G1 X95.364 Y44.325 F254
G1 X95.492 Y44.24 F254
G1 X95.607 Y44.138 F254
G1 X95.796 Y43.896 F254
G1 X95.907 Y43.61 F254
G1 X95.996 Y43.316 F254
G1 X95.99 Y43.009 F254
G1 X95.952 Y42.704 F254
G1 X95.879 Y42.406 F254
G1 X95.83 Y42.262 F254
G1 X95.792 Y42.114 F254
G1 X95.77 Y41.963 F254
G1 X95.765 Y41.811 F254
G1 X95.778 Y41.659 F254
G1 X95.81 Y41.51 F254
G1 X95.863 Y41.367 F254
G1 X95.936 Y41.234 F254
G1 X96.027 Y41.111 F254
G1 X96.134 Y41.002 F254
G1 X96.253 Y40.908 F254
G1 X96.383 Y40.829 F254
G1 X96.523 Y40.767 F254
G1 X96.669 Y40.723 F254
G1 X96.818 Y40.694 F254
G1 X96.97 Y40.68 F254
G1 X97.125 Y40.678 F254
G1 X97.304 Y40.689 F254
G1 X97.479 Y40.713 F254
G1 X97.714 Y40.763 F254
G1 X97.989 Y40.843 F254
G1 X98.276 Y40.95 F254
G1 X98.556 Y41.076 F254
G1 X98.833 Y41.208 F254
G1 X99.107 Y41.347 F254
G1 X99.375 Y41.497 F254
G1 X99.643 Y41.648 F254
G1 X99.912 Y41.795 F254
G1 X100.186 Y41.934 F254
G1 X100.465 Y42.062 F254
G1 X100.743 Y42.192 F254
G1 X101.021 Y42.322 F254
G1 X101.305 Y42.439 F254
G1 X101.6 Y42.526 F254
G1 X101.898 Y42.6 F254
G1 X102.2 Y42.652 F254
G1 X102.507 Y42.674 F254
G1 X102.814 Y42.677 F254
G1 X103.118 Y42.636 F254
G1 X103.419 Y42.573 F254
G1 X103.703 Y42.457 F254
G1 X103.978 Y42.32 F254
G1 X104.215 Y42.126 F254
G1 X104.434 Y41.91 F254
G1 X104.606 Y41.656 F254
G1 X104.741 Y41.38 F254
G1 X104.828 Y41.085 F254
G1 X104.864 Y40.781 F254
G1 X104.856 Y40.474 F254
G1 X104.8 Y40.172 F254
G1 X104.703 Y39.88 F254
G1 X104.566 Y39.605 F254
G1 X104.403 Y39.345 F254
G1 X104.197 Y39.118 F254
G1 X103.981 Y38.899 F254
G1 X103.73 Y38.723 F254
G1 X103.49 Y38.532 F254
G1 X103.24 Y38.353 F254
G1 X102.964 Y38.217 F254
G1 X102.686 Y38.087 F254
G1 X102.411 Y37.951 F254
G1 X102.124 Y37.843 F254
G1 X101.828 Y37.76 F254
G1 X101.534 Y37.671 F254
G1 X101.241 Y37.58 F254
G1 X100.653 Y37.401 F254
G1 X100.357 Y37.319 F254
G1 X100.056 Y37.26 F254
G1 X99.753 Y37.209 F254
G1 X99.15 Y37.097 F254
G1 X98.546 Y36.985 F254
G1 X98.243 Y36.933 F254
G1 X97.939 Y36.89 F254
G1 X97.635 Y36.85 F254
G1 X94.896 Y36.477 F254
G1 X94.593 Y36.432 F254
G1 X94.29 Y36.379 F254
G1 X93.687 Y36.263 F254
G1 X93.084 Y36.148 F254
G1 X92.783 Y36.086 F254
G1 X92.484 Y36.016 F254
G1 X91.888 Y35.867 F254
G1 X91.591 Y35.79 F254
G1 X91.295 Y35.711 F254
G1 X90.997 Y35.633 F254
G1 X90.699 Y35.561 F254
G1 X90.399 Y35.497 F254
G1 X90.098 Y35.436 F254
G1 X89.794 Y35.39 F254
G1 X89.182 Y35.342 F254
G1 X88.875 Y35.334 F254
G1 X88.569 Y35.356 F254
G1 X88.262 Y35.374 F254
G1 X87.956 Y35.395 F254
G1 X87.652 Y35.438 F254
G1 X87.349 Y35.492 F254
G1 X87.046 Y35.541 F254
G1 X86.743 Y35.592 F254
G1 X86.442 Y35.649 F254
G1 X85.84 Y35.77 F254
G1 X85.538 Y35.83 F254
G1 X85.236 Y35.883 F254
G1 X84.628 Y35.972 F254
G1 X84.325 Y36.018 F254
G1 X84.02 Y36.056 F254
G1 X83.714 Y36.081 F254
G1 X83.407 Y36.095 F254
G1 X82.794 Y36.118 F254
G1 X82.487 Y36.123 F254
G1 X82.18 Y36.111 F254
G1 X81.874 Y36.086 F254
G1 X81.263 Y36.027 F254
G1 X80.957 Y35.996 F254
G1 X80.653 Y35.956 F254
G1 X80.35 Y35.905 F254
G1 X78.542 Y35.549 F254
G1 X78.241 Y35.491 F254
G1 X77.937 Y35.443 F254
G1 X77.632 Y35.414 F254
G1 X77.325 Y35.409 F254
G1 X77.018 Y35.431 F254
G1 X76.717 Y35.492 F254
G1 X76.419 Y35.566 F254
G1 X76.119 Y35.627 F254
G1 X75.817 Y35.683 F254
G1 X75.514 Y35.724 F254
G1 X75.207 Y35.743 F254
G1 X74.9 F254
G1 X74.593 Y35.733 F254
G1 X74.287 Y35.714 F254
G1 X73.981 Y35.689 F254
G1 X73.675 Y35.659 F254
G1 X73.065 Y35.587 F254
G1 X72.761 Y35.547 F254
G1 X72.153 Y35.46 F254
G1 X71.241 Y35.331 F254
G1 X70.936 Y35.289 F254
G1 X69.414 Y35.089 F254
G1 X69.11 Y35.05 F254
G1 X68.804 Y35.018 F254
G1 X68.192 Y34.97 F254
G1 X67.886 Y34.951 F254
G1 X67.579 Y34.947 F254
G1 X67.272 Y34.944 F254
G1 X66.964 Y34.946 F254
G1 X66.659 Y34.977 F254
G1 X66.354 Y35.011 F254
G1 X66.052 Y35.066 F254
G1 X65.759 Y35.159 F254
G1 X65.469 Y35.259 F254
G1 X65.205 Y35.416 F254
G1 X64.956 Y35.596 F254
G1 X64.736 Y35.81 F254
G1 X64.555 Y36.058 F254
G1 X64.401 Y36.324 F254
G1 X64.309 Y36.524 F254
G1 X64.218 Y36.69 F254
G1 X64.126 Y36.831 F254
G1 X64.034 Y36.952 F254
G1 X63.933 Y37.066 F254
G1 X63.823 Y37.172 F254
G1 X63.705 Y37.268 F254
G1 X63.579 Y37.355 F254
G1 X63.444 Y37.432 F254
G1 X63.291 Y37.506 F254
G1 X63.104 Y37.58 F254
G1 X62.979 Y37.618 F254
G1 X62.779 Y37.674 F254
G1 X62.523 Y37.726 F254
G1 X62.218 Y37.764 F254
G1 X61.912 Y37.782 F254
G1 X61.605 Y37.787 F254
G1 X61.298 Y37.782 F254
G1 X60.991 Y37.774 F254
G1 X60.684 Y37.757 F254
G1 X60.379 Y37.729 F254
G1 X59.767 Y37.669 F254
G1 X59.463 Y37.63 F254
G1 X58.553 Y37.485 F254
G1 X58.251 Y37.43 F254
G1 X57.95 Y37.367 F254
G1 X57.35 Y37.237 F254
G1 X57.051 Y37.168 F254
G1 X56.754 Y37.091 F254
G1 X56.161 Y36.932 F254
G1 X55.865 Y36.849 F254
G1 X55.572 Y36.757 F254
G1 X54.986 Y36.573 F254
G1 X54.696 Y36.473 F254
G1 X54.116 Y36.27 F254
G1 X53.829 Y36.162 F254
G1 X53.542 Y36.052 F254
G1 X52.967 Y35.837 F254
G1 X52.677 Y35.734 F254
G1 X52.387 Y35.635 F254
G1 X52.097 Y35.535 F254
G1 X51.806 Y35.436 F254
G1 X51.511 Y35.352 F254
G1 X51.21 Y35.289 F254
G1 X50.911 Y35.221 F254
G1 X50.612 Y35.15 F254
G1 X50.312 Y35.084 F254
G1 X50.009 Y35.035 F254
G1 X49.704 Y35.003 F254
G1 X49.399 Y34.967 F254
G1 X49.092 Y34.944 F254
G1 X48.786 Y34.933 F254
G1 X48.479 Y34.917 F254
G1 X48.172 Y34.918 F254
G1 X47.865 Y34.933 F254
G1 X46.638 Y34.976 F254
G1 X46.331 Y34.99 F254
G1 X46.025 Y35.019 F254
G1 X45.723 Y35.072 F254
G1 X45.42 Y35.123 F254
G1 X45.117 Y35.17 F254
G1 X44.511 Y35.27 F254
G1 X44.209 Y35.328 F254
G1 X43.912 Y35.404 F254
G1 X43.615 Y35.484 F254
G1 X43.318 Y35.561 F254
G1 X43.021 Y35.638 F254
G1 X42.724 Y35.716 F254
G1 X42.427 Y35.797 F254
G1 X41.835 Y35.959 F254
G1 X41.538 Y36.038 F254
G1 X41.24 Y36.11 F254
G1 X40.939 Y36.17 F254
G1 X40.636 Y36.223 F254
G1 X40.334 Y36.277 F254
G1 X40.03 Y36.321 F254
G1 X39.724 Y36.349 F254
G1 X39.418 Y36.365 F254
G1 X39.111 Y36.374 F254
G1 X38.804 Y36.371 F254
G1 X38.497 Y36.354 F254
G1 X38.191 Y36.325 F254
G1 X37.887 Y36.289 F254
G1 X37.583 Y36.24 F254
G1 X37.282 Y36.184 F254
G1 X36.375 Y36.022 F254
G1 X36.071 Y35.974 F254
G1 X35.767 Y35.937 F254
G1 X35.462 Y35.901 F254
G1 X35.156 Y35.875 F254
G1 X34.849 Y35.879 F254
G1 X34.542 Y35.895 F254
G1 X34.235 Y35.911 F254
G1 X33.933 Y35.965 F254
G1 X33.635 Y36.038 F254
G1 X33.335 Y36.105 F254
G1 X33.041 Y36.192 F254
G1 X32.755 Y36.305 F254
G1 X32.183 Y36.528 F254
G1 X31.618 Y36.768 F254
G1 X31.051 Y37.005 F254
G1 X30.765 Y37.115 F254
G1 X30.515 Y37.196 F254
G1 X30.287 Y37.251 F254
G1 X30.072 Y37.287 F254
G1 X29.859 Y37.307 F254
G1 X29.644 Y37.31 F254
G1 X29.413 Y37.297 F254
G1 X29.153 Y37.263 F254
G1 X28.856 Y37.202 F254
G1 X28.56 Y37.118 F254
G1 X28.27 Y37.018 F254
G1 X27.981 Y36.914 F254
G1 X27.691 Y36.813 F254
G1 X27.398 Y36.721 F254
G1 X27.1 Y36.646 F254
G1 X26.502 Y36.509 F254
G1 X26.198 Y36.462 F254
G1 X25.587 Y36.408 F254
G1 X25.28 Y36.404 F254
G1 X24.974 Y36.429 F254
G1 X24.667 Y36.451 F254
G1 X24.361 Y36.471 F254
G1 X24.055 Y36.499 F254
G1 X23.756 Y36.568 F254
G1 X23.467 Y36.672 F254
G1 X23.18 Y36.782 F254
G1 X22.924 Y36.951 F254
G1 X22.697 Y37.157 F254
G1 X22.526 Y37.413 F254
G1 X22.427 Y37.546 F254
G1 X22.327 Y37.661 F254
G1 X22.217 Y37.767 F254
G1 X22.098 Y37.862 F254
G1 X21.969 Y37.943 F254
G1 X21.832 Y38.011 F254
G1 X21.69 Y38.064 F254
G1 X21.542 Y38.102 F254
G1 X21.392 Y38.128 F254
G1 X21.229 Y38.142 F254
G1 X21.039 Y38.145 F254
G1 X20.788 Y38.13 F254
G1 X20.484 Y38.09 F254
G1 X19.882 Y37.966 F254
G1 X19.581 Y37.91 F254
G1 X19.277 Y37.862 F254
G1 X18.974 Y37.816 F254
G1 X18.67 Y37.769 F254
G1 X18.366 Y37.728 F254
G1 X18.06 Y37.697 F254
G1 X17.754 Y37.678 F254
G1 X17.447 Y37.69 F254
G1 X17.143 Y37.733 F254
G1 X16.847 Y37.815 F254
G1 X16.596 Y37.991 F254
G1 X16.488 Y38.1 F254
G1 X16.4 Y38.226 F254
G1 X16.28 Y38.509 F254
G1 X16.263 Y38.815 F254
G1 X16.244 Y39.122 F254
G1 X16.238 Y39.429 F254
G1 X16.298 Y39.73 F254
G1 X16.376 Y40.027 F254
G1 X16.486 Y40.314 F254
G1 X16.607 Y40.596 F254
G1 X16.758 Y40.863 F254
G1 X16.924 Y41.121 F254
G1 X17.097 Y41.375 F254
G1 X17.313 Y41.593 F254
G1 X17.523 Y41.817 F254
G1 X17.763 Y42.009 F254
G1 X18.033 Y42.155 F254
G1 X18.307 Y42.294 F254
G1 X18.604 Y42.37 F254
G1 X18.909 Y42.41 F254
G1 X19.216 Y42.42 F254
G1 X19.523 Y42.424 F254
G1 X19.829 Y42.401 F254
G1 X20.134 Y42.367 F254
G1 X20.44 Y42.347 F254
G1 X20.747 Y42.338 F254
G1 X21.054 Y42.343 F254
G1 X21.361 Y42.365 F254
G1 X21.665 Y42.405 F254
G1 X21.967 Y42.46 F254
G1 X22.267 Y42.526 F254
G1 X22.865 Y42.667 F254
G1 X23.163 Y42.739 F254
G1 X23.461 Y42.814 F254
G1 X24.056 Y42.967 F254
G1 X24.354 Y43.043 F254
G1 X24.653 Y43.109 F254
G1 X24.957 Y43.153 F254
G1 X25.263 Y43.184 F254
G1 X25.873 Y43.254 F254
G1 X26.178 Y43.287 F254
G1 X26.485 Y43.305 F254
G1 X26.791 Y43.281 F254
G1 X26.972 Y43.266 F254
G1 X27.13 Y43.264 F254
G1 X27.282 Y43.273 F254
G1 X27.433 Y43.295 F254
G1 X27.581 Y43.329 F254
G1 X27.726 Y43.378 F254
G1 X27.865 Y43.439 F254
G1 X27.998 Y43.514 F254
G1 X28.123 Y43.601 F254
G1 X28.239 Y43.7 F254
G1 X28.345 Y43.809 F254
G1 X28.44 Y43.929 F254
G1 X28.53 Y44.063 F254
G1 X28.62 Y44.223 F254
G1 X28.712 Y44.417 F254
G1 X28.803 Y44.654 F254
G1 X28.881 Y44.914 F254
G1 X28.948 Y45.213 F254
G1 X29.006 Y45.515 F254
G1 X29.133 Y46.116 F254
G1 X29.206 Y46.414 F254
G1 X29.288 Y46.71 F254
G1 X29.389 Y47 F254
G1 X29.54 Y47.267 F254
G1 X29.719 Y47.517 F254
G1 X29.963 Y47.702 F254
G1 X30.227 Y47.86 F254
G1 X30.523 Y47.942 F254
G1 X30.827 Y47.987 F254
G1 X31.133 Y48.002 F254
G1 X31.433 Y47.937 F254
G1 X31.735 Y47.879 F254
G1 X32.014 Y47.752 F254
G1 X32.253 Y47.558 F254
G1 X32.459 Y47.331 F254
G1 X32.6 Y47.058 F254
G1 X32.675 Y46.76 F254
G1 X32.741 Y46.46 F254
G1 X32.776 Y46.155 F254
G1 X32.741 Y45.85 F254
G1 X32.72 Y45.544 F254
G1 X32.706 Y45.32 F254
G1 X32.709 Y45.124 F254
G1 X32.724 Y44.954 F254
G1 X32.749 Y44.803 F254
G1 X32.785 Y44.655 F254
G1 X32.835 Y44.511 F254
G1 X32.9 Y44.374 F254
G1 X32.984 Y44.246 F254
G1 X33.083 Y44.131 F254
G1 X33.194 Y44.026 F254
G1 X33.318 Y43.938 F254
G1 X33.455 Y43.871 F254
G1 X33.602 Y43.829 F254
G1 X33.753 Y43.81 F254
G1 X33.905 Y43.809 F254
G1 X34.057 Y43.825 F254
G1 X34.206 Y43.858 F254
G1 X34.351 Y43.905 F254
G1 X34.49 Y43.966 F254
G1 X34.624 Y44.04 F254
G1 X34.749 Y44.126 F254
G1 X34.869 Y44.224 F254
G1 X35 Y44.349 F254
G1 X35.137 Y44.5 F254
G1 X35.292 Y44.698 F254
G1 X35.455 Y44.942 F254
G1 X35.607 Y45.209 F254
G1 X35.89 Y45.753 F254
G1 X36.032 Y46.026 F254
G1 X36.171 Y46.3 F254
G1 X36.306 Y46.575 F254
G1 X36.445 Y46.849 F254
G1 X36.72 Y47.398 F254
G1 X36.861 Y47.671 F254
G1 X37.015 Y47.937 F254
G1 X37.165 Y48.205 F254
G1 X37.31 Y48.475 F254
G1 X37.465 Y48.74 F254
G1 X37.641 Y48.992 F254
G1 X37.847 Y49.22 F254
G1 X38.052 Y49.448 F254
G1 X38.286 Y49.646 F254
G1 X38.529 Y49.834 F254
G1 X38.787 Y50.002 F254
G1 X39.059 Y50.143 F254
G1 X39.34 Y50.268 F254
G1 X39.634 Y50.357 F254
G1 X39.934 Y50.419 F254
G1 X40.237 Y50.471 F254
G1 X40.544 Y50.489 F254
G1 X40.848 Y50.451 F254
G1 X41.141 Y50.359 F254
G1 X41.406 Y50.204 F254
G1 X41.616 Y49.98 F254
G1 X41.762 Y49.71 F254
G1 X41.853 Y49.416 F254
G1 X41.863 Y49.11 F254
G1 X41.858 Y48.81 F254
G1 X41.867 Y48.641 F254
G1 X41.886 Y48.49 F254
G1 X41.919 Y48.341 F254
G1 X41.969 Y48.197 F254
G1 X42.037 Y48.061 F254
G1 X42.122 Y47.935 F254
G1 X42.222 Y47.819 F254
G1 X42.334 Y47.717 F254
G1 X42.458 Y47.628 F254
G1 X42.592 Y47.555 F254
G1 X42.734 Y47.499 F254
G1 X42.881 Y47.46 F254
G1 X43.032 Y47.437 F254
G1 X43.184 Y47.429 F254
G1 X43.336 Y47.434 F254
G1 X43.498 Y47.453 F254
G1 X43.664 Y47.485 F254
G1 X43.852 Y47.536 F254
G1 X44.079 Y47.616 F254
G1 X44.36 Y47.739 F254
G1 X44.633 Y47.881 F254
G1 X44.904 Y48.025 F254
G1 X45.185 Y48.15 F254
G1 X45.481 Y48.229 F254
G1 X45.788 Y48.246 F254
G1 X45.938 Y48.214 F254
G1 X46.082 Y48.161 F254
G1 X46.214 Y48.083 F254
G1 X46.333 Y47.985 F254
G1 X46.53 Y47.75 F254
G1 X46.623 Y47.616 F254
G1 X46.721 Y47.496 F254
G1 X46.825 Y47.385 F254
G1 X46.938 Y47.283 F254
G1 X47.061 Y47.193 F254
G1 X47.194 Y47.119 F254
G1 X47.373 Y47.039 F254
G1 X47.516 Y46.987 F254
G1 X47.612 Y46.936 F254
G1 X47.87 Y47.007 F254
G1 X48.014 Y47.059 F254
G1 X48.152 Y47.123 F254
G1 X48.283 Y47.201 F254
G1 X48.405 Y47.292 F254
G1 X48.519 Y47.393 F254
G1 X48.622 Y47.505 F254
G1 X48.715 Y47.626 F254
G1 X48.797 Y47.755 F254
G1 X48.868 Y47.889 F254
G1 X48.942 Y48.06 F254
G1 X49.023 Y48.293 F254
G1 X49.102 Y48.589 F254
G1 X49.159 Y48.891 F254
G1 X49.218 Y49.192 F254
G1 X49.311 Y49.485 F254
G1 X49.4 Y49.779 F254
G1 X49.502 Y50.069 F254
G1 X49.614 Y50.354 F254
G1 X49.726 Y50.641 F254
G1 X49.854 Y50.92 F254
G1 X49.985 Y51.197 F254
G1 X50.121 Y51.473 F254
G1 X50.263 Y51.745 F254
G1 X50.41 Y52.015 F254
G1 X50.561 Y52.282 F254
G1 X50.714 Y52.548 F254
G1 X50.871 Y52.812 F254
G1 X51.032 Y53.073 F254
G1 X51.194 Y53.334 F254
G1 X51.362 Y53.591 F254
G1 X51.71 Y54.097 F254
G1 X52.403 Y55.111 F254
G1 X52.579 Y55.363 F254
G1 X52.761 Y55.61 F254
G1 X53.132 Y56.1 F254
G1 X53.687 Y56.835 F254
G1 X53.873 Y57.079 F254
G1 X54.061 Y57.322 F254
G1 X55.011 Y58.528 F254
G1 X55.2 Y58.77 F254
G1 X55.387 Y59.013 F254
G1 X55.946 Y59.746 F254
G1 X56.131 Y59.991 F254
G1 X56.313 Y60.238 F254
G1 X56.494 Y60.486 F254
G1 X56.674 Y60.735 F254
G1 X56.852 Y60.985 F254
G1 X57.013 Y61.227 F254
G1 X57.107 Y61.393 F254
G1 X57.18 Y61.548 F254
G1 X57.236 Y61.692 F254
G1 X57.28 Y61.838 F254
G1 X57.312 Y61.987 F254
G1 X57.333 Y62.138 F254
G1 X57.343 Y62.308 F254
G1 X57.34 Y62.51 F254
G1 X57.321 Y62.729 F254
G1 X57.273 Y63.022 F254
G1 X57.202 Y63.321 F254
G1 X57.138 Y63.621 F254
G1 X57.139 Y63.928 F254
G1 X57.18 Y64.232 F254
G1 X57.247 Y64.532 F254
G1 X57.299 Y64.699 F254
G1 X57.336 Y64.857 F254
G1 X57.359 Y65.008 F254
G1 X57.371 Y65.16 F254
G1 Y65.312 F254
G1 X57.358 Y65.464 F254
G1 X57.331 Y65.614 F254
G1 X57.292 Y65.762 F254
G1 X57.24 Y65.905 F254
G1 X57.175 Y66.043 F254
G1 X57.1 Y66.175 F254
G1 X57.007 Y66.313 F254
G1 X56.898 Y66.453 F254
G1 X56.778 Y66.584 F254
G1 X56.657 Y66.698 F254
G1 X56.539 Y66.794 F254
G1 X56.414 Y66.882 F254
G1 X56.282 Y66.958 F254
G1 X56.144 Y67.023 F254
G1 X56.001 Y67.076 F254
G1 X55.854 Y67.115 F254
G1 X55.703 Y67.138 F254
G1 X55.551 Y67.145 F254
G1 X55.399 Y67.134 F254
G1 X55.249 Y67.108 F254
G1 X55.103 Y67.065 F254
G1 X54.961 Y67.009 F254
G1 X54.826 Y66.938 F254
G1 X54.698 Y66.856 F254
G1 X54.577 Y66.763 F254
G1 X54.458 Y66.655 F254
G1 X54.319 Y66.507 F254
G1 X54.152 Y66.303 F254
G1 X53.976 Y66.052 F254
G1 X53.817 Y65.789 F254
G1 X53.656 Y65.528 F254
G1 X53.469 Y65.284 F254
G1 X53.267 Y65.053 F254
G1 X53.052 Y64.833 F254
G1 X52.827 Y64.624 F254
G1 X52.593 Y64.426 F254
G1 X52.351 Y64.237 F254
G1 X52.103 Y64.056 F254
G1 X51.849 Y63.883 F254
G1 X51.592 Y63.715 F254
G1 X51.328 Y63.558 F254
G1 X50.789 Y63.264 F254
G1 X50.514 Y63.128 F254
G1 X50.23 Y63.01 F254
G1 X49.946 Y62.893 F254
G1 X49.663 Y62.775 F254
G1 X49.373 Y62.673 F254
G1 X48.779 Y62.519 F254
G1 X48.482 Y62.439 F254
G1 X48.185 Y62.364 F254
G1 X47.879 Y62.33 F254
G1 X47.574 Y62.3 F254
G1 X47.269 Y62.264 F254
G1 X46.963 Y62.239 F254
G1 X46.656 Y62.241 F254
G1 X46.349 Y62.256 F254
G1 X46.042 Y62.265 F254
G1 X45.736 Y62.294 F254
G1 X45.13 Y62.388 F254
G1 X44.831 Y62.46 F254
G1 X44.539 Y62.556 F254
G1 X43.949 Y62.725 F254
G1 X43.655 Y62.814 F254
G1 X43.367 Y62.92 F254
G1 X43.095 Y63.062 F254
G1 X42.821 Y63.202 F254
G1 X42.546 Y63.338 F254
G1 X42.272 Y63.476 F254
G1 X42 Y63.62 F254
G1 X41.743 Y63.787 F254
G1 X41.498 Y63.972 F254
G1 X40.997 Y64.328 F254
G1 X40.749 Y64.508 F254
G1 X40.507 Y64.697 F254
G1 X40.282 Y64.907 F254
G1 X40.062 Y65.12 F254
G1 X39.837 Y65.33 F254
G1 X39.614 Y65.541 F254
G1 X39.395 Y65.755 F254
G1 X39.19 Y65.984 F254
G1 X38.996 Y66.223 F254
G1 X38.801 Y66.459 F254
G1 X38.604 Y66.695 F254
G1 X38.41 Y66.933 F254
G1 X38.231 Y67.182 F254
G1 X38.069 Y67.444 F254
G1 X37.904 Y67.703 F254
G1 X37.738 Y67.961 F254
G1 X37.575 Y68.221 F254
G1 X37.428 Y68.491 F254
G1 X37.299 Y68.769 F254
G1 X37.166 Y69.046 F254
G1 X37.032 Y69.322 F254
G1 X36.902 Y69.601 F254
G1 X36.787 Y69.885 F254
G1 X36.687 Y70.176 F254
G1 X36.476 Y70.752 F254
G1 X36.378 Y71.043 F254
G1 X36.297 Y71.34 F254
G1 X36.224 Y71.638 F254
G1 X36.144 Y71.934 F254
G1 X36.073 Y72.233 F254
G1 X36.024 Y72.536 F254
G1 X35.977 Y72.839 F254
G1 X35.927 Y73.142 F254
G1 X35.903 Y73.449 F254
G1 X35.884 Y73.755 F254
G1 X35.871 Y74.062 F254
G1 X35.882 Y74.369 F254
G1 X35.904 Y74.675 F254
G1 X35.934 Y74.981 F254
G1 X35.959 Y75.287 F254
G1 X35.982 Y75.593 F254
G1 X35.989 Y75.869 F254
G1 X35.982 Y76.022 F254
G1 X35.957 Y76.322 F254
G1 X35.909 Y76.626 F254
G1 X35.841 Y76.925 F254
G1 X35.761 Y77.222 F254
G1 X35.683 Y77.518 F254
G1 X35.62 Y77.819 F254
G1 X35.563 Y78.121 F254
G1 X35.509 Y78.423 F254
G1 X35.466 Y78.727 F254
G1 X35.386 Y79.336 F254
G1 X35.352 Y79.641 F254
G1 X35.299 Y80.253 F254
G1 X35.274 Y80.559 F254
G1 X35.254 Y80.865 F254
G1 X35.24 Y81.172 F254
G1 X35.217 Y81.786 F254
G1 X35.211 Y82.093 F254
G1 X35.215 Y82.4 F254
G1 X35.228 Y83.014 F254
G1 X35.243 Y83.32 F254
G1 X35.27 Y83.626 F254
G1 X35.299 Y83.932 F254
G1 X35.329 Y84.238 F254
G1 X35.37 Y84.542 F254
G1 X35.467 Y85.148 F254
G1 X35.522 Y85.45 F254
G1 X35.585 Y85.751 F254
G1 X35.652 Y86.051 F254
G1 X35.722 Y86.35 F254
G1 X35.801 Y86.646 F254
G1 X35.884 Y86.942 F254
G1 X35.971 Y87.236 F254
G1 X36.065 Y87.529 F254
G1 X36.164 Y87.819 F254
G1 X36.27 Y88.108 F254
G1 X36.387 Y88.391 F254
G1 X36.513 Y88.672 F254
G1 X36.636 Y88.953 F254
G1 X36.787 Y89.22 F254
G1 X36.959 Y89.475 F254
G1 X37.119 Y89.737 F254
G1 X37.446 Y90.256 F254
G1 X37.619 Y90.511 F254
G1 X37.836 Y90.728 F254
G1 X38.038 Y90.959 F254
G1 X38.249 Y91.182 F254
G1 X38.485 Y91.378 F254
G1 X38.715 Y91.581 F254
G1 X38.946 Y91.784 F254
G1 X39.202 Y91.953 F254
G1 X39.453 Y92.13 F254
G1 X39.705 Y92.305 F254
G1 X39.979 Y92.445 F254
G1 X40.249 Y92.59 F254
G1 X40.523 Y92.729 F254
G1 X40.81 Y92.839 F254
G1 X41.099 Y92.941 F254
G1 X41.39 Y93.04 F254
G1 X41.688 Y93.114 F254
G1 X42.289 Y93.243 F254
G1 X42.59 Y93.299 F254
G1 X42.893 Y93.353 F254
G1 X43.194 Y93.412 F254
G1 X43.495 Y93.474 F254
G1 X43.795 Y93.538 F254
G1 X44.095 Y93.603 F254
G1 X44.394 Y93.672 F254
G1 X46.186 Y94.1 F254
G1 X46.485 Y94.173 F254
G1 X46.783 Y94.247 F254
G1 X47.08 Y94.323 F254
G1 X47.971 Y94.557 F254
G1 X48.268 Y94.636 F254
G1 X48.564 Y94.716 F254
G1 X49.157 Y94.878 F254
G1 X49.452 Y94.962 F254
G1 X49.746 Y95.05 F254
G1 X50.039 Y95.141 F254
G1 X50.331 Y95.237 F254
G1 X50.622 Y95.336 F254
G1 X50.91 Y95.441 F254
G1 X51.196 Y95.552 F254
G1 X51.479 Y95.673 F254
G1 X51.757 Y95.802 F254
G1 X52.032 Y95.939 F254
G1 X52.306 Y96.077 F254
G1 X52.579 Y96.218 F254
G1 X52.846 Y96.37 F254
G1 X53.106 Y96.533 F254
G1 X53.621 Y96.868 F254
G1 X53.878 Y97.036 F254
G1 X54.131 Y97.21 F254
G1 X54.38 Y97.39 F254
G1 X55.37 Y98.117 F254
G1 X55.866 Y98.479 F254
G1 X56.366 Y98.835 F254
G1 X58.114 Y100.087 F254
G1 X58.365 Y100.264 F254
G1 X58.619 Y100.435 F254
G1 X58.876 Y100.603 F254
G1 X59.135 Y100.769 F254
G1 X59.396 Y100.93 F254
G1 X59.664 Y101.081 F254
G1 X59.938 Y101.22 F254
G1 X60.213 Y101.355 F254
G1 X60.49 Y101.487 F254
G1 X60.779 Y101.591 F254
G1 X61.075 Y101.673 F254
G1 X61.37 Y101.759 F254
G1 X61.667 Y101.838 F254
G1 X61.968 Y101.896 F254
G1 X62.272 Y101.939 F254
G1 X62.577 Y101.979 F254
G1 X62.882 Y102.012 F254
G1 X63.188 Y102.039 F254
G1 X63.494 Y102.058 F254
G1 X63.801 Y102.073 F254
G1 X64.721 Y102.122 F254
G1 X65.028 Y102.133 F254
G1 X65.335 Y102.132 F254
G1 X65.642 Y102.123 F254
G1 X65.949 Y102.11 F254
G1 X66.255 Y102.088 F254
G1 X66.541 Y102.074 F254
G1 X66.78 Y102.08 F254
G1 X66.996 Y102.101 F254
G1 X67.199 Y102.137 F254
G1 X67.409 Y102.189 F254
G1 X67.644 Y102.267 F254
G1 X67.907 Y102.377 F254
G1 X68.182 Y102.515 F254
G1 X68.446 Y102.672 F254
G1 X68.704 Y102.837 F254
G1 X68.973 Y102.987 F254
G1 X69.251 Y103.116 F254
G1 X69.528 Y103.248 F254
G1 X69.816 Y103.354 F254
G1 X70.11 Y103.444 F254
G1 X70.404 Y103.532 F254
G1 X70.704 Y103.597 F254
G1 X71.007 Y103.648 F254
G1 X71.31 Y103.698 F254
G1 X71.615 Y103.735 F254
G1 X71.921 Y103.762 F254
G1 X72.227 Y103.783 F254
G1 X72.534 Y103.784 F254
G1 X72.841 Y103.769 F254
G1 X73.147 Y103.747 F254
G1 X73.451 Y103.703 F254
G1 X73.75 Y103.633 F254
G1 X74.049 Y103.561 F254
G1 X74.345 Y103.481 F254
G1 X74.625 Y103.355 F254
G1 X74.897 Y103.213 F254
G1 X75.173 Y103.078 F254
G1 X75.448 Y102.941 F254
G1 X75.704 Y102.772 F254
G1 X75.805 Y102.656 F254
G1 X76.022 Y102.439 F254
G1 X76.213 Y102.199 F254
G1 X76.354 Y101.926 F254
G1 X76.486 Y101.649 F254
G1 X76.555 Y101.349 F254
G1 X76.644 Y101.056 F254
G1 X76.721 Y100.758 F254
G1 X76.76 Y100.454 F254
G1 X76.777 Y100.147 F254
G1 X76.785 Y99.84 F254
G1 X76.771 Y99.533 F254
G1 X76.736 Y99.228 F254
G1 X76.679 Y98.927 F254
G1 X76.591 Y98.632 F254
G1 X76.484 Y98.345 F254
G1 X76.422 Y98.141 F254
G1 X76.381 Y97.955 F254
G1 X76.354 Y97.77 F254
G1 X76.34 Y97.577 F254
G1 Y97.375 F254
G1 X76.356 Y97.168 F254
G1 X76.388 Y96.952 F254
G1 X76.45 Y96.678 F254
G1 X76.54 Y96.384 F254
G1 X76.639 Y96.093 F254
G1 X76.724 Y95.798 F254
G1 X76.79 Y95.498 F254
G1 X76.841 Y95.196 F254
G1 X76.87 Y94.89 F254
G1 X76.899 Y94.584 F254
G1 X76.91 Y94.277 F254
G1 X76.905 Y93.97 F254
G1 X76.908 Y93.663 F254
G1 X76.912 Y92.742 F254
G1 X76.903 Y92.435 F254
G1 X76.877 Y92.129 F254
G1 X76.853 Y91.823 F254
G1 X76.831 Y91.517 F254
G1 X76.762 Y90.598 F254
G1 X76.729 Y90.293 F254
G1 X76.677 Y89.99 F254
G1 X76.63 Y89.687 F254
G1 X76.579 Y89.384 F254
G1 X76.504 Y89.086 F254
G1 X76.435 Y88.787 F254
G1 X76.363 Y88.489 F254
G1 X76.266 Y88.197 F254
G1 X76.163 Y87.908 F254
G1 X76.072 Y87.615 F254
G1 X75.974 Y87.324 F254
G1 X75.877 Y87.032 F254
G1 X75.77 Y86.745 F254
G1 X75.634 Y86.469 F254
G1 X75.505 Y86.191 F254
G1 X75.382 Y85.909 F254
G1 X75.252 Y85.631 F254
G1 X75.123 Y85.352 F254
G1 X74.973 Y85.085 F254
G1 X74.809 Y84.825 F254
G1 X74.499 Y84.295 F254
G1 X74.341 Y84.031 F254
G1 X74.186 Y83.766 F254
G1 X73.562 Y82.709 F254
G1 X73.404 Y82.445 F254
G1 X73.241 Y82.185 F254
G1 X73.071 Y81.929 F254
G1 X72.904 Y81.671 F254
G1 X72.739 Y81.413 F254
G1 X72.572 Y81.155 F254
G1 X72.073 Y80.381 F254
G1 X71.908 Y80.122 F254
G1 X71.747 Y79.86 F254
G1 X71.589 Y79.597 F254
G1 X71.434 Y79.332 F254
G1 X70.964 Y78.54 F254
G1 X70.809 Y78.275 F254
G1 X70.659 Y78.007 F254
G1 X70.516 Y77.735 F254
G1 X70.243 Y77.185 F254
G1 X70.11 Y76.908 F254
G1 X69.863 Y76.346 F254
G1 X69.738 Y76.065 F254
G1 X69.621 Y75.781 F254
G1 X69.28 Y74.926 F254
G1 X69.171 Y74.639 F254
G1 X68.96 Y74.062 F254
G1 X68.853 Y73.774 F254
G1 X68.642 Y73.197 F254
G1 X68.54 Y72.908 F254
G1 X68.44 Y72.617 F254
G1 X68.34 Y72.327 F254
G1 X68.24 Y72.037 F254
G1 X68.145 Y71.745 F254
G1 X68.052 Y71.452 F254
G1 X67.964 Y71.158 F254
G1 X67.933 Y71.013 F254
G1 X67.889 Y70.786 F254
G1 X67.867 Y70.589 F254
G1 X67.86 Y70.412 F254
G1 X67.866 Y70.241 F254
G1 X67.884 Y70.076 F254
G1 X67.913 Y69.917 F254
G1 X67.953 Y69.764 F254
G1 X68.006 Y69.609 F254
G1 X68.074 Y69.447 F254
G1 X68.162 Y69.276 F254
G1 X68.281 Y69.083 F254
G1 X68.44 Y68.863 F254
G1 X68.637 Y68.627 F254
G1 X68.85 Y68.407 F254
G1 X69.071 Y68.193 F254
G1 X69.278 Y67.967 F254
G1 X69.476 Y67.732 F254
G1 X69.682 Y67.504 F254
G1 X69.875 Y67.265 F254
G1 X70.047 Y67.011 F254
G1 X70.207 Y66.749 F254
G1 X70.363 Y66.484 F254
G1 X70.505 Y66.212 F254
G1 X70.642 Y65.937 F254
G1 X70.775 Y65.661 F254
G1 X70.898 Y65.379 F254
G1 X71.016 Y65.096 F254
G1 X71.13 Y64.811 F254
G1 X71.242 Y64.525 F254
G1 X71.351 Y64.238 F254
G1 X71.458 Y63.95 F254
G1 X71.564 Y63.662 F254
G1 X71.77 Y63.083 F254
G1 X71.872 Y62.793 F254
G1 X71.97 Y62.503 F254
G1 X72.355 Y61.336 F254
G1 X72.45 Y61.044 F254
G1 X72.541 Y60.751 F254
G1 X72.629 Y60.457 F254
G1 X72.802 Y59.867 F254
G1 X72.887 Y59.572 F254
G1 X72.968 Y59.276 F254
G1 X73.045 Y58.979 F254
G1 X73.122 Y58.682 F254
G1 X73.196 Y58.384 F254
G1 X73.267 Y58.085 F254
G1 X73.334 Y57.785 F254
G1 X73.398 Y57.485 F254
G1 X73.459 Y57.184 F254
G1 X73.515 Y56.882 F254
G1 X73.569 Y56.58 F254
G1 X73.622 Y56.277 F254
G1 X73.723 Y55.672 F254
G1 X73.776 Y55.369 F254
G1 X73.992 Y54.16 F254
G1 X74.049 Y53.858 F254
G1 X74.111 Y53.558 F254
G1 X74.178 Y53.258 F254
G1 X74.25 Y52.96 F254
G1 X74.328 Y52.662 F254
G1 X74.412 Y52.367 F254
G1 X74.502 Y52.074 F254
G1 X74.598 Y51.782 F254
G1 X74.705 Y51.494 F254
G1 X74.821 Y51.21 F254
G1 X74.948 Y50.93 F254
G1 X75.06 Y50.723 F254
G1 X75.159 Y50.57 F254
G1 X75.258 Y50.439 F254
G1 X75.358 Y50.324 F254
G1 X75.467 Y50.217 F254
G1 X75.584 Y50.12 F254
G1 X75.709 Y50.033 F254
G1 X75.841 Y49.957 F254
G1 X75.979 Y49.893 F254
G1 X76.122 Y49.839 F254
G1 X76.281 Y49.794 F254
G1 X76.467 Y49.756 F254
G1 X76.669 Y49.729 F254
G1 X76.945 Y49.714 F254
G1 X77.252 Y49.719 F254
G1 X77.559 Y49.738 F254
G1 X77.866 Y49.739 F254
G1 X78.172 Y49.722 F254
G1 X78.479 Y49.701 F254
G1 X78.781 Y49.647 F254
G1 X79.08 Y49.577 F254
G1 X79.376 Y49.496 F254
G1 X79.667 Y49.398 F254
G1 X79.954 Y49.289 F254
G1 X80.239 Y49.174 F254
G1 X80.525 Y49.061 F254
G1 X80.809 Y48.947 F254
G1 X81.09 Y48.822 F254
G1 X81.365 Y48.685 F254
G1 X81.637 Y48.543 F254
G1 X81.911 Y48.404 F254
G1 X82.181 Y48.258 F254
G1 X82.44 Y48.093 F254
G1 X82.688 Y47.912 F254
G1 X82.938 Y47.734 F254
G1 X83.181 Y47.546 F254
G1 X83.385 Y47.316 F254
G1 X83.57 Y47.071 F254
G1 X83.765 Y46.834 F254
G1 X83.898 Y46.685 F254
G1 X84.01 Y46.578 F254
G1 X84.127 Y46.48 F254
G1 X84.252 Y46.393 F254
G1 X84.385 Y46.319 F254
G1 X84.525 Y46.258 F254
G1 X84.671 Y46.213 F254
G1 X84.82 Y46.182 F254
G1 X84.972 Y46.168 F254
G1 X85.124 Y46.17 F254
G1 X85.275 Y46.189 F254
G1 X85.424 Y46.223 F254
G1 X85.569 Y46.269 F254
G1 X85.737 Y46.338 F254
G1 X85.93 Y46.435 F254
G1 X86.157 Y46.571 F254
G1 X86.408 Y46.747 F254
G1 X86.663 Y46.918 F254
G1 X86.932 Y47.066 F254
G1 X87.206 Y47.206 F254
G1 X87.499 Y47.297 F254
G1 X87.802 Y47.347 F254
G1 X88.104 Y47.403 F254
G1 X88.408 Y47.445 F254
G1 X88.712 Y47.49 F254
G1 X89.013 Y47.551 F254
G1 X89.312 Y47.621 F254
G1 X89.609 Y47.697 F254
G1 X90.202 Y47.856 F254
G1 X90.502 Y47.924 F254
G1 X90.805 Y47.971 F254
G1 X91.11 Y48.006 F254
G1 X91.262 Y47.984 F254
G1 X91.409 Y47.94 F254
G1 X91.547 Y47.872 F254
G1 X91.669 Y47.779 F254
G1 X91.772 Y47.665 F254
G1 X91.853 Y47.535 F254
G1 X91.916 Y47.395 F254
G1 X91.982 Y47.095 F254
G1 X91.944 Y46.79 F254
G1 X91.748 Y46.208 F254
G1 X91.666 Y46.025 F254
G1 X91.611 Y45.872 F254
G1 X91.569 Y45.725 F254
G1 X91.54 Y45.575 F254
G1 X91.525 Y45.424 F254
G1 Y45.271 F254
G1 X91.541 Y45.12 F254
G1 X91.576 Y44.971 F254
G1 X91.632 Y44.83 F254
G1 X91.706 Y44.697 F254
G1 X91.797 Y44.574 F254
G1 X91.902 Y44.464 F254
G1 X92.02 Y44.367 F254
G1 X92.148 Y44.284 F254
G1 X92.285 Y44.218 F254
G1 X92.43 Y44.17 F254
G1 X92.578 Y44.136 F254
G1 X92.729 Y44.117 F254
G1 X92.891 Y44.111 F254
G1 X93.072 Y44.118 F254
G1 X93.262 Y44.138 F254
G1 X93.543 Y44.191 F254
G1 X93.84 Y44.269 F254
G1 X94.139 Y44.34 F254
G1 X94.445 Y44.365 F254
G1 X94.751 Y44.348 F254
G1 X95.049 Y44.272 F254
G1 X95.317 Y44.122 F254
G1 X95.542 Y43.913 F254
G1 X95.688 Y43.643 F254
G1 X95.777 Y43.349 F254
G1 X95.796 Y43.042 F254
G1 X95.754 Y42.738 F254
G1 X95.681 Y42.44 F254
G1 X95.636 Y42.291 F254
G1 X95.603 Y42.142 F254
G1 X95.582 Y41.991 F254
G1 X95.575 Y41.839 F254
G1 X95.584 Y41.687 F254
G1 X95.608 Y41.537 F254
G1 X95.651 Y41.39 F254
G1 X95.711 Y41.25 F254
G1 X95.788 Y41.119 F254
G1 X95.879 Y40.997 F254
G1 X95.984 Y40.886 F254
G1 X96.1 Y40.787 F254
G1 X96.226 Y40.701 F254
G1 X96.36 Y40.63 F254
G1 X96.502 Y40.574 F254
G1 X96.649 Y40.533 F254
G1 X96.799 Y40.505 F254
G1 X96.95 Y40.49 F254
G1 X97.121 Y40.485 F254
G1 X97.3 Y40.494 F254
G1 X97.513 Y40.52 F254
G1 X97.73 Y40.563 F254
G1 X98.001 Y40.638 F254
G1 X98.29 Y40.741 F254
G1 X98.572 Y40.863 F254
G1 X98.849 Y40.994 F254
G1 X99.124 Y41.131 F254
G1 X99.394 Y41.278 F254
G1 X99.662 Y41.429 F254
G1 X99.93 Y41.577 F254
G1 X100.203 Y41.719 F254
G1 X100.481 Y41.849 F254
G1 X100.759 Y41.978 F254
G1 X101.037 Y42.109 F254
G1 X101.319 Y42.23 F254
G1 X101.612 Y42.323 F254
G1 X101.91 Y42.397 F254
G1 X102.212 Y42.451 F254
G1 X102.518 Y42.475 F254
G1 X102.825 Y42.477 F254
G1 X103.129 Y42.432 F254
G1 X103.429 Y42.364 F254
G1 X103.707 Y42.233 F254
G1 X103.972 Y42.079 F254
G1 X104.194 Y41.867 F254
G1 X104.389 Y41.63 F254
G1 X104.531 Y41.358 F254
G1 X104.627 Y41.066 F254
G1 X104.666 Y40.761 F254
G1 X104.655 Y40.454 F254
G1 X104.591 Y40.154 F254
G1 X104.479 Y39.868 F254
G1 X104.331 Y39.599 F254
G1 X104.148 Y39.352 F254
G1 X103.932 Y39.134 F254
G1 X103.696 Y38.937 F254
G1 X103.448 Y38.757 F254
G1 X103.204 Y38.571 F254
G1 X102.935 Y38.422 F254
G1 X102.656 Y38.294 F254
G1 X102.38 Y38.159 F254
G1 X102.095 Y38.044 F254
G1 X101.8 Y37.96 F254
G1 X101.506 Y37.872 F254
G1 X101.213 Y37.781 F254
G1 X100.625 Y37.602 F254
G1 X100.33 Y37.519 F254
G1 X100.029 Y37.458 F254
G1 X99.726 Y37.407 F254
G1 X99.122 Y37.295 F254
G1 X98.518 Y37.184 F254
G1 X98.216 Y37.131 F254
G1 X97.912 Y37.088 F254
G1 X97.607 Y37.048 F254
G1 X94.869 Y36.675 F254
G1 X94.565 Y36.63 F254
G1 X94.263 Y36.577 F254
G1 X93.056 Y36.346 F254
G1 X92.756 Y36.285 F254
G1 X92.456 Y36.215 F254
G1 X91.861 Y36.066 F254
G1 X91.564 Y35.989 F254
G1 X91.267 Y35.91 F254
G1 X90.97 Y35.833 F254
G1 X90.671 Y35.76 F254
G1 X90.371 Y35.696 F254
G1 X90.07 Y35.635 F254
G1 X89.767 Y35.588 F254
G1 X89.154 Y35.54 F254
G1 X88.847 Y35.534 F254
G1 X88.541 Y35.558 F254
G1 X88.235 Y35.576 F254
G1 X87.928 Y35.598 F254
G1 X87.625 Y35.645 F254
G1 X87.323 Y35.7 F254
G1 X87.02 Y35.748 F254
G1 X86.717 Y35.8 F254
G1 X86.415 Y35.858 F254
G1 X86.115 Y35.92 F254
G1 X85.814 Y35.979 F254
G1 X85.512 Y36.038 F254
G1 X85.21 Y36.09 F254
G1 X84.602 Y36.178 F254
G1 X84.298 Y36.224 F254
G1 X83.993 Y36.261 F254
G1 X83.687 Y36.283 F254
G1 X83.38 Y36.296 F254
G1 X82.767 Y36.319 F254
G1 X82.46 Y36.323 F254
G1 X82.153 Y36.31 F254
G1 X81.847 Y36.285 F254
G1 X81.236 Y36.225 F254
G1 X80.93 Y36.194 F254
G1 X80.626 Y36.154 F254
G1 X80.323 Y36.103 F254
G1 X80.022 Y36.044 F254
G1 X79.419 Y35.925 F254
G1 X78.515 Y35.747 F254
G1 X78.214 Y35.69 F254
G1 X77.91 Y35.641 F254
G1 X77.605 Y35.612 F254
G1 X77.298 Y35.609 F254
G1 X76.992 Y35.635 F254
G1 X76.692 Y35.703 F254
G1 X76.394 Y35.777 F254
G1 X76.093 Y35.836 F254
G1 X75.791 Y35.89 F254
G1 X75.494 Y35.928 F254
G1 X75.188 Y35.944 F254
G1 X74.881 Y35.942 F254
G1 X74.574 Y35.932 F254
G1 X74.267 Y35.913 F254
G1 X73.961 Y35.888 F254
G1 X73.656 Y35.858 F254
G1 X73.046 Y35.787 F254
G1 X72.741 Y35.746 F254
G1 X71.525 Y35.573 F254
G1 X71.221 Y35.53 F254
G1 X70.917 Y35.488 F254
G1 X69.395 Y35.288 F254
G1 X69.09 Y35.249 F254
G1 X68.785 Y35.217 F254
G1 X68.173 Y35.169 F254
G1 X67.866 Y35.151 F254
G1 X67.559 Y35.146 F254
G1 X67.252 Y35.144 F254
G1 X66.945 Y35.146 F254
G1 X66.335 Y35.215 F254
G1 X66.033 Y35.274 F254
G1 X65.744 Y35.377 F254
G1 X65.457 Y35.486 F254
G1 X65.205 Y35.662 F254
G1 X64.968 Y35.857 F254
G1 X64.772 Y36.093 F254
G1 X64.612 Y36.355 F254
G1 X64.478 Y36.632 F254
G1 X64.37 Y36.819 F254
G1 X64.264 Y36.973 F254
G1 X64.159 Y37.105 F254
G1 X64.052 Y37.221 F254
G1 X63.939 Y37.326 F254
G1 X63.819 Y37.423 F254
G1 X63.687 Y37.514 F254
G1 X63.538 Y37.601 F254
G1 X63.366 Y37.686 F254
G1 X63.18 Y37.76 F254
G1 X62.942 Y37.836 F254
G1 X62.683 Y37.898 F254
G1 X62.38 Y37.947 F254
G1 X62.074 Y37.974 F254
G1 X61.767 Y37.985 F254
G1 X61.46 F254
G1 X61.153 Y37.978 F254
G1 X60.846 Y37.967 F254
G1 X60.54 Y37.946 F254
G1 X59.929 Y37.886 F254
G1 X59.623 Y37.853 F254
G1 X59.319 Y37.811 F254
G1 X58.713 Y37.713 F254
G1 X58.41 Y37.663 F254
G1 X58.108 Y37.605 F254
G1 X57.808 Y37.541 F254
G1 X57.508 Y37.475 F254
G1 X57.208 Y37.41 F254
G1 X56.909 Y37.339 F254
G1 X56.613 Y37.26 F254
G1 X56.02 Y37.1 F254
G1 X55.724 Y37.016 F254
G1 X54.846 Y36.738 F254
G1 X54.267 Y36.535 F254
G1 X53.977 Y36.432 F254
G1 X53.403 Y36.213 F254
G1 X52.828 Y35.999 F254
G1 X52.538 Y35.898 F254
G1 X52.247 Y35.799 F254
G1 X51.957 Y35.698 F254
G1 X51.666 Y35.601 F254
G1 X51.369 Y35.523 F254
G1 X51.068 Y35.462 F254
G1 X50.47 Y35.323 F254
G1 X50.169 Y35.261 F254
G1 X49.865 Y35.218 F254
G1 X49.559 Y35.188 F254
G1 X49.254 Y35.155 F254
G1 X48.948 Y35.138 F254
G1 X48.334 Y35.115 F254
G1 X48.027 Y35.124 F254
G1 X47.72 Y35.139 F254
G1 X46.8 Y35.17 F254
G1 X46.493 Y35.182 F254
G1 X46.186 Y35.202 F254
G1 X45.882 Y35.245 F254
G1 X45.58 Y35.299 F254
G1 X44.974 Y35.396 F254
G1 X44.671 Y35.446 F254
G1 X44.368 Y35.5 F254
G1 X44.069 Y35.569 F254
G1 X43.773 Y35.649 F254
G1 X43.476 Y35.727 F254
G1 X43.178 Y35.803 F254
G1 X42.881 Y35.881 F254
G1 X42.585 Y35.961 F254
G1 X41.993 Y36.124 F254
G1 X41.696 Y36.203 F254
G1 X41.398 Y36.278 F254
G1 X41.098 Y36.343 F254
G1 X40.796 Y36.398 F254
G1 X40.494 Y36.451 F254
G1 X40.191 Y36.501 F254
G1 X39.886 Y36.536 F254
G1 X39.579 Y36.557 F254
G1 X39.272 Y36.57 F254
G1 X38.965 Y36.573 F254
G1 X38.658 Y36.564 F254
G1 X38.352 Y36.542 F254
G1 X38.047 Y36.51 F254
G1 X37.742 Y36.469 F254
G1 X37.44 Y36.418 F254
G1 X37.138 Y36.361 F254
G1 X36.231 Y36.201 F254
G1 X35.927 Y36.156 F254
G1 X35.622 Y36.121 F254
G1 X35.317 Y36.088 F254
G1 X35.01 Y36.073 F254
G1 X34.703 Y36.087 F254
G1 X34.397 Y36.103 F254
G1 X34.091 Y36.136 F254
G1 X33.792 Y36.205 F254
G1 X33.493 Y36.275 F254
G1 X33.196 Y36.352 F254
G1 X32.908 Y36.458 F254
G1 X32.623 Y36.572 F254
G1 X32.336 Y36.683 F254
G1 X32.052 Y36.8 F254
G1 X31.77 Y36.92 F254
G1 X31.204 Y37.157 F254
G1 X30.918 Y37.271 F254
G1 X30.639 Y37.367 F254
G1 X30.389 Y37.432 F254
G1 X30.156 Y37.475 F254
G1 X29.927 Y37.501 F254
G1 X29.697 Y37.509 F254
G1 X29.455 Y37.5 F254
G1 X29.186 Y37.469 F254
G1 X28.885 Y37.413 F254
G1 X28.588 Y37.334 F254
G1 X28.296 Y37.239 F254
G1 X27.717 Y37.033 F254
G1 X27.425 Y36.938 F254
G1 X27.129 Y36.858 F254
G1 X26.53 Y36.721 F254
G1 X26.228 Y36.668 F254
G1 X25.922 Y36.638 F254
G1 X25.616 Y36.612 F254
G1 X25.309 Y36.603 F254
G1 X25.003 Y36.627 F254
G1 X24.697 Y36.649 F254
G1 X24.39 Y36.669 F254
G1 X24.085 Y36.697 F254
G1 X23.786 Y36.767 F254
G1 X23.498 Y36.874 F254
G1 X23.212 Y36.985 F254
G1 X22.969 Y37.174 F254
G1 X22.763 Y37.401 F254
G1 X22.67 Y37.545 F254
G1 X22.572 Y37.674 F254
G1 X22.471 Y37.788 F254
G1 X22.362 Y37.894 F254
G1 X22.244 Y37.99 F254
G1 X22.118 Y38.076 F254
G1 X21.985 Y38.15 F254
G1 X21.845 Y38.212 F254
G1 X21.701 Y38.26 F254
G1 X21.552 Y38.296 F254
G1 X21.393 Y38.321 F254
G1 X21.211 Y38.337 F254
G1 X20.986 Y38.34 F254
G1 X20.714 Y38.323 F254
G1 X20.42 Y38.283 F254
G1 X20.12 Y38.219 F254
G1 X19.819 Y38.157 F254
G1 X19.517 Y38.101 F254
G1 X19.214 Y38.054 F254
G1 X18.91 Y38.009 F254
G1 X18.606 Y37.962 F254
G1 X18.302 Y37.921 F254
G1 X17.996 Y37.892 F254
G1 X17.69 Y37.875 F254
G1 X17.383 Y37.896 F254
G1 X17.081 Y37.952 F254
G1 X16.941 Y38.014 F254
G1 X16.81 Y38.093 F254
G1 X16.694 Y38.194 F254
G1 X16.602 Y38.317 F254
G1 X16.53 Y38.453 F254
G1 X16.456 Y38.751 F254
G1 X16.453 Y38.888 F254
G1 X16.452 Y38.9 F254
G1 X16.42 Y39.097 F254
G1 X16.41 Y39.167 F254
G1 X16.401 Y39.237 F254
G1 Y39.272 F254
G1 X16.404 Y39.307 F254
G1 X16.416 Y39.376 F254
G1 X16.506 Y39.84 F254
G1 X16.511 Y39.865 F254
G1 X16.534 Y39.935 F254
G1 X16.729 Y40.423 F254
G1 X16.758 Y40.493 F254
G1 X16.88 Y40.702 F254
G1 X17.09 Y41.051 F254
G1 X17.134 Y41.121 F254
G1 X17.192 Y41.191 F254
G1 X17.572 Y41.609 F254
G1 X17.622 Y41.663 F254
G1 X17.651 Y41.692 F254
G1 X17.901 Y41.862 F254
G1 X18.111 Y42.001 F254
G1 X18.154 Y42.028 F254
G1 X18.18 Y42.042 F254
G1 X18.25 Y42.07 F254
G1 X18.529 Y42.168 F254
G1 X18.599 Y42.191 F254
G1 X18.669 Y42.207 F254
G1 X18.808 Y42.217 F254
G1 X19.297 Y42.243 F254
G1 X19.436 Y42.25 F254
G1 X19.506 Y42.248 F254
G1 X20.134 Y42.182 F254
G1 X20.204 Y42.175 F254
G1 X20.413 Y42.162 F254
G1 X20.832 Y42.151 F254
G1 X20.902 Y42.15 F254
G1 X21.111 Y42.152 F254
G1 X21.53 Y42.195 F254
G1 X21.599 Y42.203 F254
G1 X21.809 Y42.233 F254
G1 X23.029 Y42.517 F254
G1 X23.204 Y42.559 F254
G1 X24.6 Y42.919 F254
G1 X24.809 Y42.95 F254
G1 X25.019 Y42.974 F254
G1 X26.205 Y43.109 F254
G1 X26.449 Y43.131 F254
G1 X26.466 Y43.13 F254
G1 X26.763 Y43.095 F254
G1 X27.068 Y43.074 F254
G1 X27.221 Y43.076 F254
G1 X27.372 Y43.09 F254
G1 X27.522 Y43.117 F254
G1 X27.67 Y43.156 F254
G1 X27.813 Y43.207 F254
G1 X27.952 Y43.27 F254
G1 X28.085 Y43.344 F254
G1 X28.211 Y43.429 F254
G1 X28.33 Y43.525 F254
G1 X28.44 Y43.631 F254
G1 X28.54 Y43.745 F254
G1 X28.632 Y43.868 F254
G1 X28.729 Y44.019 F254
G1 X28.828 Y44.202 F254
G1 X28.927 Y44.423 F254
G1 X29.018 Y44.674 F254
G1 X29.031 Y44.718 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X28.932 Y44.735 I-0.049 J0.009 F254
G1 X28.929 Y44.717 Z-8.092 F254
G1 X28.926 Y44.701 Z-8.081 F254
G1 X28.924 Y44.69 Z-8.065 F254
G1 X28.923 Y44.686 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X26.103 Y44.553 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X26.101 Y44.549 Z-8.065 F254
G1 X26.096 Y44.54 Z-8.081 F254
G1 X26.088 Y44.526 Z-8.092 F254
G1 X26.079 Y44.509 Z-8.096 F254
G3 X26.763 Y43.095 I0.832 J-0.47 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X27.321 Y43.027 F254
G1 X27.356 Y43.019 F254
G1 X27.402 Y43.005 F254
G1 X27.548 Y42.961 F254
G1 X27.699 Y42.979 F254
G1 X27.846 Y43.02 F254
G1 X27.988 Y43.076 F254
G1 X28.124 Y43.145 F254
G1 X28.254 Y43.225 F254
G1 X28.377 Y43.314 F254
G1 X28.493 Y43.413 F254
G1 X28.6 Y43.521 F254
G1 X28.704 Y43.642 F254
G1 X28.794 Y43.763 F254
G1 X28.802 Y43.776 F254
G1 X28.808 Y43.789 F254
G1 X28.813 Y43.803 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X28.814 Y43.823 Z-8.045 F254
G1 X28.808 Y43.841 Z-7.994 F254
G1 X28.794 Y43.855 Z-7.944 F254
G1 X28.777 Y43.864 Z-7.893 F254
G3 X28.74 Y43.859 I-0.012 J-0.049 F254
G1 X28.279 Y43.597 F254
; MOVEMENT_LINK_DIRECT
G1 X27.859 Y43.359 F254
; MOVEMENT_LEAD_IN
G1 X27.395 Y43.095 F254
G3 X27.374 Y43.07 I0.025 J-0.043 F254
G1 X27.37 Y43.051 Z-7.944 F254
G1 X27.374 Y43.032 Z-7.994 F254
G1 X27.385 Y43.016 Z-8.045 F254
G1 X27.402 Y43.005 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X27.709 Y42.896 F254
G1 X27.782 Y42.874 F254
G1 X27.934 Y42.877 F254
G1 X28.08 Y42.921 F254
G1 X28.219 Y42.984 F254
G1 X28.35 Y43.061 F254
G1 X28.475 Y43.148 F254
G1 X28.594 Y43.246 F254
G1 X28.655 Y43.304 F254
G1 X28.669 Y43.321 F254
G1 X28.681 Y43.34 F254
G1 X28.689 Y43.361 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X28.69 Y43.38 Z-8.045 F254
G1 X28.683 Y43.399 Z-7.994 F254
G1 X28.67 Y43.413 Z-7.944 F254
G1 X28.652 Y43.421 Z-7.893 F254
G3 X28.619 Y43.418 I-0.012 J-0.049 F254
G1 X28.185 Y43.214 F254
; MOVEMENT_LEAD_IN
G1 X27.706 Y42.988 F254
G3 X27.68 Y42.961 I0.021 J-0.045 F254
G1 X27.677 Y42.942 Z-7.944 F254
G1 X27.681 Y42.923 Z-7.994 F254
G1 X27.692 Y42.907 Z-8.045 F254
G1 X27.709 Y42.896 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X27.949 Y42.81 F254
G1 X28.022 Y42.787 F254
G1 X28.174 Y42.788 F254
G1 X28.319 Y42.836 F254
G1 X28.454 Y42.907 F254
G1 X28.547 Y42.968 F254
G1 X28.569 Y42.988 F254
G1 X28.587 Y43.011 F254
G1 X28.598 Y43.039 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X28.599 Y43.058 Z-8.045 F254
G1 X28.592 Y43.076 Z-7.994 F254
G1 X28.579 Y43.091 Z-7.944 F254
G1 X28.561 Y43.099 Z-7.893 F254
G3 X28.534 Y43.098 I-0.012 J-0.049 F254
G1 X28.45 Y43.07 F254
; MOVEMENT_LEAD_IN
G1 X27.952 Y42.904 F254
G3 X27.922 Y42.876 I0.016 J-0.047 F254
G1 X27.918 Y42.856 Z-7.944 F254
G1 X27.922 Y42.837 Z-7.994 F254
G1 X27.933 Y42.821 Z-8.045 F254
G1 X27.949 Y42.81 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X27.989 Y42.796 F254
G1 X28.019 Y42.781 F254
G1 X28.089 Y42.745 F254
G1 X28.123 Y42.726 F254
G1 X28.159 Y42.706 F254
G1 X28.197 Y42.685 F254
G1 X28.231 Y42.668 F254
G1 X28.383 Y42.685 F254
G1 X28.448 Y42.71 F254
G1 X28.475 Y42.725 F254
G1 X28.498 Y42.746 F254
G1 X28.515 Y42.772 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X28.519 Y42.791 Z-8.045 F254
G1 X28.516 Y42.81 Z-7.994 F254
G1 X28.505 Y42.827 Z-7.944 F254
G1 X28.489 Y42.838 Z-7.893 F254
G3 X28.456 Y42.841 I-0.02 J-0.046 F254
G1 X28.21 Y42.776 F254
G3 X28.18 Y42.753 I0.013 J-0.048 F254
G1 X28.173 Y42.735 Z-7.944 F254
G1 X28.174 Y42.716 Z-7.994 F254
G1 X28.183 Y42.698 Z-8.045 F254
G1 X28.197 Y42.685 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X28.337 Y42.607 F254
G1 X28.368 Y42.59 F254
G1 X28.378 Y42.586 F254
G1 X28.391 Y42.585 F254
G1 X28.407 Y42.586 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G3 X28.425 Y42.617 I-0.017 J0.031 F254
G3 X28.358 I-0.034 F254
G3 X28.378 Y42.586 I0.034 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X28.392 Y42.584 F254
G1 X28.407 Y42.586 F254
G1 X28.422 Y42.594 F254
G1 X28.438 Y42.613 F254
G1 X28.534 Y42.813 F254
G1 X28.864 Y43.982 F254
G1 X28.929 Y44.261 F254
G1 X29.022 Y44.68 F254
G1 X29.166 Y45.378 F254
G1 X29.294 Y46.006 F254
G1 X29.309 Y46.076 F254
G1 X29.471 Y46.704 F254
G1 X29.484 Y46.744 F254
G1 X29.495 Y46.773 F254
G1 X29.703 Y47.192 F254
G1 X29.74 Y47.262 F254
G1 X29.764 Y47.294 F254
G1 X29.796 Y47.332 F254
G1 X29.833 Y47.364 F254
G1 X29.903 Y47.42 F254
G1 X30.182 Y47.637 F254
G1 X30.252 Y47.681 F254
G1 X30.287 Y47.696 F254
G1 X30.322 Y47.707 F254
G1 X30.392 Y47.722 F254
G1 X30.887 Y47.82 F254
G1 X30.95 Y47.826 F254
G1 X31.02 Y47.821 F254
G1 X31.089 Y47.811 F254
G1 X31.578 Y47.73 F254
G1 X31.648 Y47.716 F254
G1 X31.682 Y47.705 F254
G1 X31.717 Y47.691 F254
G1 X31.74 Y47.681 F254
G1 X31.996 Y47.537 F254
G1 X32.031 Y47.516 F254
G1 X32.066 Y47.49 F254
G1 X32.088 Y47.471 F254
G1 X32.136 Y47.421 F254
G1 X32.277 Y47.262 F254
G1 X32.345 Y47.181 F254
G1 X32.364 Y47.152 F254
G1 X32.381 Y47.122 F254
G1 X32.407 Y47.052 F254
G1 X32.555 Y46.482 F254
G1 X32.569 Y46.424 F254
G1 X32.584 Y46.355 F254
G1 X32.586 Y46.337 F254
G1 X32.587 Y46.32 F254
G1 X32.575 Y46.076 F254
G1 X32.533 Y45.447 F254
G1 X32.526 Y45.378 F254
G1 X32.512 Y45.226 F254
G1 X32.519 Y45.045 F254
G1 X32.538 Y44.879 F254
G1 X32.567 Y44.729 F254
G1 X32.607 Y44.582 F254
G1 X32.659 Y44.439 F254
G1 X32.725 Y44.302 F254
G1 X32.805 Y44.172 F254
G1 X32.899 Y44.052 F254
G1 X33.004 Y43.941 F254
G1 X33.121 Y43.844 F254
G1 X33.25 Y43.762 F254
G1 X33.388 Y43.699 F254
G1 X33.534 Y43.654 F254
G1 X33.684 Y43.628 F254
G1 X33.836 Y43.619 F254
G1 X33.989 Y43.625 F254
G1 X34.14 Y43.647 F254
G1 X34.288 Y43.683 F254
G1 X34.432 Y43.732 F254
G1 X34.571 Y43.794 F254
G1 X34.705 Y43.867 F254
G1 X34.832 Y43.95 F254
G1 X34.966 Y44.054 F254
G1 X35.105 Y44.178 F254
G1 X35.238 Y44.317 F254
G1 X35.395 Y44.505 F254
G1 X35.541 Y44.711 F254
G1 X35.543 Y44.715 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X35.454 Y44.761 I-0.044 J0.023 F254
G1 X35.445 Y44.744 Z-8.092 F254
G1 X35.438 Y44.73 Z-8.081 F254
G1 X35.433 Y44.72 Z-8.065 F254
G1 X35.431 Y44.717 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X33.999 Y46.002 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X33.996 Y46.004 Z-8.065 F254
G1 X33.987 Y46.009 Z-8.081 F254
G1 X33.973 Y46.018 Z-8.092 F254
G1 X33.956 Y46.027 Z-8.096 F254
G3 X32.526 Y45.378 I-0.49 J-0.82 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.496 Y45.168 F254
G1 X32.441 Y44.819 F254
G1 X32.425 Y44.668 F254
G1 X32.443 Y44.517 F254
G1 X32.488 Y44.371 F254
G1 X32.55 Y44.232 F254
G1 X32.627 Y44.1 F254
G1 X32.716 Y43.976 F254
G1 X32.815 Y43.861 F254
G1 X32.926 Y43.756 F254
G1 X33.047 Y43.664 F254
G1 X33.179 Y43.587 F254
G1 X33.318 Y43.525 F254
G1 X33.463 Y43.479 F254
G1 X33.612 Y43.448 F254
G1 X33.764 Y43.431 F254
G1 X33.916 Y43.429 F254
G1 X34.068 Y43.442 F254
G1 X34.218 Y43.468 F254
G1 X34.366 Y43.507 F254
G1 X34.509 Y43.557 F254
G1 X34.649 Y43.619 F254
G1 X34.785 Y43.691 F254
G1 X34.925 Y43.78 F254
G1 X35.061 Y43.882 F254
G1 X35.074 Y43.893 F254
G1 X35.086 Y43.906 F254
G1 X35.095 Y43.92 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X35.074 Y43.988 I-0.044 J0.023 F254
G3 X35.007 Y43.967 I-0.023 J-0.044 F254
G1 X34.998 Y43.95 Z-8.092 F254
G1 X34.99 Y43.936 Z-8.081 F254
G1 X34.985 Y43.926 Z-8.065 F254
G1 X34.984 Y43.923 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X34.578 Y47.18 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X34.574 Y47.179 Z-8.065 F254
G1 X34.564 Y47.176 Z-8.081 F254
G1 X34.549 Y47.171 Z-8.092 F254
G1 X34.53 Y47.165 Z-8.096 F254
G3 X32.441 Y44.819 I0.928 J-2.93 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.38 Y44.432 F254
G1 X32.364 Y44.281 F254
G1 X32.405 Y44.134 F254
G1 X32.474 Y43.998 F254
G1 X32.559 Y43.872 F254
G1 X32.656 Y43.754 F254
G1 X32.764 Y43.646 F254
G1 X32.882 Y43.549 F254
G1 X33.008 Y43.464 F254
G1 X33.143 Y43.393 F254
G1 X33.284 Y43.335 F254
G1 X33.43 Y43.291 F254
G1 X33.579 Y43.261 F254
G1 X33.73 Y43.243 F254
G1 X33.883 Y43.238 F254
G1 X34.035 Y43.246 F254
G1 X34.186 Y43.266 F254
G1 X34.335 Y43.298 F254
G1 X34.481 Y43.342 F254
G1 X34.627 Y43.397 F254
G1 X34.775 Y43.466 F254
G1 X34.832 Y43.498 F254
G1 X34.85 Y43.51 F254
G1 X34.866 Y43.525 F254
G1 X34.878 Y43.543 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X34.858 Y43.611 I-0.044 J0.024 F254
G3 X34.791 Y43.591 I-0.024 J-0.044 F254
G1 X34.781 Y43.574 Z-8.092 F254
G1 X34.774 Y43.56 Z-8.081 F254
G1 X34.768 Y43.55 Z-8.065 F254
G1 X34.767 Y43.547 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X34.52 Y47.63 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X34.517 Y47.627 Z-8.065 F254
G1 X34.508 Y47.621 Z-8.081 F254
G1 X34.494 Y47.612 Z-8.092 F254
G1 X34.478 Y47.602 Z-8.096 F254
G3 X32.38 Y44.432 I2.767 J-4.112 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.353 Y44.261 F254
G1 X32.333 Y44.122 F254
G1 X32.32 Y43.97 F254
G1 X32.376 Y43.828 F254
G1 X32.459 Y43.7 F254
G1 X32.557 Y43.584 F254
G1 X32.667 Y43.478 F254
G1 X32.786 Y43.383 F254
G1 X32.914 Y43.3 F254
G1 X33.048 Y43.228 F254
G1 X33.188 Y43.168 F254
G1 X33.333 Y43.12 F254
G1 X33.481 Y43.084 F254
G1 X33.631 Y43.06 F254
G1 X33.783 Y43.048 F254
G1 X33.936 Y43.047 F254
G1 X34.088 Y43.058 F254
G1 X34.245 Y43.081 F254
G1 X34.402 Y43.117 F254
G1 X34.56 Y43.165 F254
G1 X34.633 Y43.193 F254
G1 X34.657 Y43.205 F254
G1 X34.678 Y43.223 F254
G1 X34.695 Y43.244 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X34.676 Y43.312 I-0.043 J0.025 F254
G3 X34.608 Y43.293 I-0.025 J-0.043 F254
G1 X34.598 Y43.277 Z-8.092 F254
G1 X34.59 Y43.263 Z-8.081 F254
G1 X34.585 Y43.253 Z-8.065 F254
G1 X34.583 Y43.25 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X33.873 Y44.534 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X33.87 Y44.537 Z-8.065 F254
G1 X33.863 Y44.545 Z-8.081 F254
G1 X33.851 Y44.557 Z-8.092 F254
G1 X33.838 Y44.57 Z-8.096 F254
G3 X32.333 Y44.122 I-0.641 J-0.6 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.295 Y43.842 F254
G1 X32.288 Y43.767 F254
G1 X32.323 Y43.618 F254
G1 X32.404 Y43.489 F254
G1 X32.505 Y43.375 F254
G1 X32.618 Y43.273 F254
G1 X32.741 Y43.183 F254
G1 X32.871 Y43.103 F254
G1 X33.007 Y43.035 F254
G1 X33.149 Y42.978 F254
G1 X33.294 Y42.932 F254
G1 X33.447 Y42.895 F254
G1 X33.602 Y42.87 F254
G1 X33.76 Y42.856 F254
G1 X33.921 Y42.854 F254
G1 X34.087 Y42.864 F254
G1 X34.256 Y42.887 F254
G1 X34.427 Y42.923 F254
G1 X34.466 Y42.934 F254
G1 X34.494 Y42.946 F254
G1 X34.518 Y42.965 F254
G1 X34.537 Y42.989 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X34.543 Y43.007 Z-8.045 F254
G1 X34.542 Y43.027 Z-7.994 F254
G1 X34.533 Y43.044 Z-7.944 F254
G1 X34.519 Y43.057 Z-7.893 F254
G1 X34.512 Y43.06 F254
G1 X33.989 Y43.26 F254
; MOVEMENT_LINK_DIRECT
G1 X32.883 Y43.682 F254
; MOVEMENT_LEAD_IN
G1 X32.362 Y43.881 F254
G1 X32.352 Y43.883 F254
G1 X32.333 Z-7.944 F254
G1 X32.315 Y43.875 Z-7.994 F254
G1 X32.302 Y43.861 Z-8.045 F254
G1 X32.295 Y43.842 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.261 Y43.595 F254
G1 X32.254 Y43.519 F254
G1 X32.296 Y43.372 F254
G1 X32.383 Y43.247 F254
G1 X32.491 Y43.139 F254
G1 X32.61 Y43.044 F254
G1 X32.737 Y42.961 F254
G1 X32.871 Y42.888 F254
G1 X33.013 Y42.824 F254
G1 X33.165 Y42.769 F254
G1 X33.323 Y42.724 F254
G1 X33.487 Y42.69 F254
G1 X33.656 Y42.669 F254
G1 X33.829 Y42.659 F254
G1 X34.007 Y42.663 F254
G1 X34.188 Y42.68 F254
G1 X34.308 Y42.7 F254
G1 X34.34 Y42.71 F254
G1 X34.369 Y42.729 F254
G1 X34.392 Y42.755 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X34.398 Y42.773 Z-8.045 F254
G1 X34.397 Y42.793 Z-7.994 F254
G1 X34.389 Y42.811 Z-7.944 F254
G1 X34.375 Y42.824 Z-7.893 F254
G1 X34.367 Y42.827 F254
G1 X33.847 Y43.033 F254
; MOVEMENT_LINK_DIRECT
G1 X32.847 Y43.428 F254
; MOVEMENT_LEAD_IN
G1 X32.328 Y43.633 F254
G3 X32.319 Y43.636 I-0.018 J-0.047 F254
G1 X32.299 Y43.635 Z-7.944 F254
G1 X32.281 Y43.627 Z-7.994 F254
G1 X32.268 Y43.613 Z-8.045 F254
G1 X32.261 Y43.595 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.232 Y43.385 F254
G1 X32.226 Y43.309 F254
G1 X32.257 Y43.16 F254
G1 X32.345 Y43.036 F254
G1 X32.455 Y42.93 F254
G1 X32.577 Y42.838 F254
G1 X32.706 Y42.758 F254
G1 X32.842 Y42.688 F254
G1 X32.993 Y42.624 F254
G1 X33.157 Y42.568 F254
G1 X33.329 Y42.523 F254
G1 X33.508 Y42.49 F254
G1 X33.692 Y42.47 F254
G1 X33.881 Y42.464 F254
G1 X34.075 Y42.472 F254
G1 X34.152 Y42.481 F254
G1 X34.184 Y42.489 F254
G1 X34.213 Y42.505 F254
G1 X34.237 Y42.529 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X34.245 Y42.546 Z-8.045 F254
G1 Y42.566 Z-7.994 F254
G1 X34.238 Y42.584 Z-7.944 F254
G1 X34.225 Y42.598 Z-7.893 F254
G3 X34.216 Y42.604 I-0.029 J-0.041 F254
G1 X33.704 Y42.823 F254
; MOVEMENT_LINK_DIRECT
G1 X32.812 Y43.204 F254
; MOVEMENT_LEAD_IN
G1 X32.301 Y43.423 F254
G3 X32.29 Y43.426 I-0.02 J-0.046 F254
G1 X32.27 Z-7.944 F254
G1 X32.253 Y43.418 Z-7.994 F254
G1 X32.239 Y43.404 Z-8.045 F254
G1 X32.232 Y43.385 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.199 Y43.145 F254
G1 X32.193 Y43.069 F254
G1 X32.239 Y42.923 F254
G1 X32.334 Y42.804 F254
G1 X32.448 Y42.704 F254
G1 X32.574 Y42.617 F254
G1 X32.709 Y42.541 F254
G1 X32.86 Y42.469 F254
G1 X33.019 Y42.408 F254
G1 X33.194 Y42.355 F254
G1 X33.38 Y42.313 F254
G1 X33.575 Y42.285 F254
G1 X33.775 Y42.27 F254
G1 X33.953 F254
G1 X33.986 Y42.273 F254
G1 X34.02 Y42.28 F254
G1 X34.051 Y42.297 F254
G1 X34.076 Y42.321 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X34.084 Y42.339 Z-8.045 F254
G1 Y42.358 Z-7.994 F254
G1 X34.078 Y42.376 Z-7.944 F254
G1 X34.064 Y42.391 Z-7.893 F254
G3 X34.055 Y42.396 I-0.029 J-0.041 F254
G1 X33.545 Y42.62 F254
; MOVEMENT_LINK_DIRECT
G1 X32.777 Y42.958 F254
; MOVEMENT_LEAD_IN
G1 X32.269 Y43.182 F254
G3 X32.257 Y43.185 I-0.02 J-0.046 F254
G1 X32.238 Z-7.944 F254
G1 X32.22 Y43.177 Z-7.994 F254
G1 X32.206 Y43.163 Z-8.045 F254
G1 X32.199 Y43.145 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.19 Y43.075 F254
G1 X32.178 Y42.897 F254
G1 X32.177 Y42.821 F254
G1 X32.236 Y42.68 F254
G1 X32.337 Y42.567 F254
G1 X32.457 Y42.472 F254
G1 X32.586 Y42.392 F254
G1 X32.73 Y42.317 F254
G1 X32.889 Y42.249 F254
G1 X33.057 Y42.191 F254
G1 X33.247 Y42.141 F254
G1 X33.449 Y42.103 F254
G1 X33.661 Y42.08 F254
G1 X33.813 Y42.074 F254
G1 X33.83 Y42.075 F254
G1 X33.865 Y42.082 F254
G1 X33.897 Y42.098 F254
G1 X33.923 Y42.123 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X33.931 Y42.141 Z-8.045 F254
G1 X33.932 Y42.161 Z-7.994 F254
G1 X33.925 Y42.179 Z-7.944 F254
G1 X33.911 Y42.193 Z-7.893 F254
G3 X33.903 Y42.198 I-0.029 J-0.041 F254
G1 X33.394 Y42.426 F254
; MOVEMENT_LINK_DIRECT
G1 X32.752 Y42.712 F254
; MOVEMENT_LEAD_IN
G1 X32.248 Y42.937 F254
G3 X32.233 Y42.941 I-0.02 J-0.046 F254
G1 X32.213 Y42.94 Z-7.944 F254
G1 X32.196 Y42.931 Z-7.994 F254
G1 X32.184 Y42.916 Z-8.045 F254
G1 X32.178 Y42.897 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.176 Y42.865 F254
G1 X32.169 Y42.688 F254
G1 X32.168 Y42.656 F254
G1 X32.167 Y42.618 F254
G1 X32.169 Y42.569 F254
G1 X32.17 Y42.565 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X32.177 Y42.547 Z-8.045 F254
G1 X32.191 Y42.533 Z-7.994 F254
G1 X32.208 Y42.525 Z-7.944 F254
G1 X32.228 Z-7.893 F254
G3 X32.269 Y42.576 I-0.009 J0.049 F254
G1 X32.267 Y42.618 F254
G3 X32.22 Y42.665 I-0.05 J-0.002 F254
G1 X32.2 Y42.662 Z-7.944 F254
G1 X32.184 Y42.652 Z-7.994 F254
G1 X32.172 Y42.637 Z-8.045 F254
G1 X32.167 Y42.618 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y42.586 F254
G1 X32.172 Y42.548 F254
G1 X32.177 Y42.522 F254
G1 X32.269 Y42.4 F254
G1 X32.385 Y42.301 F254
G1 X32.512 Y42.217 F254
G1 X32.651 Y42.143 F254
G1 X32.81 Y42.072 F254
G1 X32.99 Y42.008 F254
G1 X33.187 Y41.954 F254
G1 X33.398 Y41.912 F254
G1 X33.587 Y41.889 F254
G1 X33.61 Y41.887 F254
G1 X33.64 Y41.89 F254
G1 X33.669 Y41.899 F254
G1 X33.695 Y41.916 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X33.707 Y41.931 Z-8.045 F254
G1 X33.712 Y41.95 Z-7.994 F254
G1 X33.709 Y41.969 Z-7.944 F254
G1 X33.7 Y41.986 Z-7.893 F254
G3 X33.681 Y41.999 I-0.038 J-0.033 F254
G1 X33.178 Y42.209 F254
; MOVEMENT_LINK_DIRECT
G1 X32.742 Y42.391 F254
; MOVEMENT_LEAD_IN
G1 X32.241 Y42.599 F254
G3 X32.217 Y42.603 I-0.019 J-0.046 F254
G1 X32.198 Y42.597 Z-7.944 F254
G1 X32.183 Y42.585 Z-7.994 F254
G1 X32.174 Y42.567 Z-8.045 F254
G1 X32.172 Y42.548 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.184 Y42.464 F254
G1 X32.19 Y42.447 F254
G1 X32.206 Y42.424 F254
G1 X32.352 Y42.237 F254
G1 X32.383 Y42.214 F254
G1 X32.545 Y42.098 F254
G1 X32.694 Y42.001 F254
G1 X32.882 Y41.889 F254
G1 X32.904 Y41.876 F254
G1 X32.942 Y41.853 F254
G1 X33.007 Y41.819 F254
G1 X33.023 Y41.813 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X33.042 Y41.812 Z-8.045 F254
G1 X33.06 Y41.819 Z-7.994 F254
G1 X33.075 Y41.832 Z-7.944 F254
G1 X33.083 Y41.85 Z-7.893 F254
G3 X33.057 Y41.906 I-0.048 J0.012 F254
G1 X32.991 Y41.94 F254
G3 X32.927 Y41.922 I-0.023 J-0.045 F254
G1 X32.92 Y41.904 Z-7.944 F254
G1 Y41.884 Z-7.994 F254
G1 X32.928 Y41.867 Z-8.045 F254
G1 X32.942 Y41.853 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X32.973 Y41.834 F254
G1 X33.004 Y41.819 F254
G1 X33.183 Y41.769 F254
G1 X33.257 Y41.749 F254
G1 X33.289 Y41.742 F254
G1 X33.306 Y41.741 F254
G1 X33.392 Y41.763 F254
G1 X33.532 Y41.799 F254
G1 X33.554 Y41.805 F254
G1 X33.577 Y41.819 F254
G1 X33.868 Y42.058 F254
G1 X33.88 Y42.069 F254
G1 X34.281 Y42.586 F254
G1 X34.373 Y42.726 F254
G1 X34.418 Y42.796 F254
G1 X34.857 Y43.508 F254
G1 X34.93 Y43.633 F254
G1 X35.206 Y44.115 F254
G1 X35.406 Y44.471 F254
G1 X35.64 Y44.889 F254
G1 X35.904 Y45.382 F254
G1 X36.156 Y45.866 F254
G1 X36.332 Y46.215 F254
G1 X36.856 Y47.262 F254
G1 X36.966 Y47.471 F254
G1 X37.584 Y48.588 F254
G1 X37.628 Y48.658 F254
G1 X37.681 Y48.727 F254
G1 X37.955 Y49.076 F254
G1 X38.019 Y49.146 F254
G1 X38.084 Y49.216 F254
G1 X38.137 Y49.269 F254
G1 X38.486 Y49.582 F254
G1 X38.556 Y49.638 F254
G1 X38.625 Y49.683 F254
G1 X38.997 Y49.914 F254
G1 X39.044 Y49.941 F254
G1 X39.184 Y50.003 F254
G1 X39.48 Y50.13 F254
G1 X39.498 Y50.137 F254
G1 X39.745 Y50.193 F254
G1 X40.3 Y50.305 F254
G1 X40.37 Y50.31 F254
G1 X40.44 Y50.307 F254
G1 X40.719 Y50.288 F254
G1 X40.788 Y50.28 F254
G1 X40.858 Y50.261 F254
G1 X41.197 Y50.123 F254
G1 X41.207 Y50.118 F254
G1 X41.277 Y50.075 F254
G1 X41.306 Y50.053 F254
G1 X41.347 Y50.009 F254
G1 X41.525 Y49.774 F254
G1 X41.574 Y49.704 F254
G1 X41.617 Y49.634 F254
G1 X41.626 Y49.614 F254
G1 X41.638 Y49.577 F254
G1 X41.666 Y49.355 F254
G1 X41.686 Y49.146 F254
G1 X41.689 Y49.076 F254
G1 X41.687 Y49.041 F254
G1 X41.681 Y49.006 F254
G1 X41.659 Y48.856 F254
G1 X41.668 Y48.666 F254
G1 X41.688 Y48.505 F254
G1 X41.718 Y48.356 F254
G1 X41.76 Y48.21 F254
G1 X41.819 Y48.069 F254
G1 X41.892 Y47.935 F254
G1 X41.98 Y47.81 F254
G1 X42.079 Y47.695 F254
G1 X42.191 Y47.591 F254
G1 X42.312 Y47.498 F254
G1 X42.442 Y47.419 F254
G1 X42.579 Y47.354 F254
G1 X42.723 Y47.304 F254
G1 X42.871 Y47.268 F254
G1 X43.022 Y47.247 F254
G1 X43.175 Y47.238 F254
G1 X43.331 Y47.242 F254
G1 X43.499 Y47.259 F254
G1 X43.683 Y47.29 F254
G1 X43.884 Y47.341 F254
G1 X44.097 Y47.411 F254
G1 X44.286 Y47.49 F254
G1 X44.29 Y47.492 F254
G1 X45.115 Y47.935 F254
G1 X45.169 Y47.96 F254
G1 X45.185 Y47.966 F254
G1 X45.324 Y48.004 F254
G1 X45.533 Y48.059 F254
G1 X45.568 Y48.065 F254
G1 X45.603 Y48.068 F254
G1 X45.673 Y48.066 F254
G1 X45.813 Y48.053 F254
G1 X45.952 Y48.038 F254
G1 X46.001 Y48.029 F254
G1 X46.022 Y48.024 F254
G1 X46.057 Y48.01 F254
G1 X46.092 Y47.994 F254
G1 X46.144 Y47.96 F254
G1 X46.161 Y47.945 F254
G1 X46.215 Y47.89 F254
G1 X46.231 Y47.87 F254
G1 X46.301 Y47.756 F254
G1 X46.473 Y47.501 F254
G1 X46.567 Y47.382 F254
G1 X46.67 Y47.27 F254
G1 X46.782 Y47.166 F254
G1 X46.902 Y47.072 F254
G1 X47.03 Y46.99 F254
G1 X47.177 Y46.914 F254
G1 X47.398 Y46.819 F254
G1 X47.47 Y46.794 F254
G1 X47.502 Y46.779 F254
G1 X47.531 Y46.755 F254
G1 X47.577 Y46.693 F254
G1 X47.603 Y46.621 F254
G1 X47.627 Y46.469 F254
G1 X47.592 Y46.164 F254
G1 X47.478 Y45.879 F254
G1 X47.369 Y45.592 F254
G1 X47.224 Y45.321 F254
G1 X46.939 Y44.777 F254
G1 X46.785 Y44.511 F254
G1 X46.623 Y44.251 F254
G1 X46.3 Y43.728 F254
G1 X46.122 Y43.478 F254
G1 X45.769 Y42.975 F254
G1 X45.58 Y42.734 F254
G1 X45.194 Y42.256 F254
G1 X44.982 Y42.034 F254
G1 X44.772 Y41.81 F254
G1 X44.548 Y41.6 F254
G1 X44.312 Y41.406 F254
G1 X44.353 Y41.341 F254
G1 X44.475 Y41.25 F254
G1 X44.619 Y41.199 F254
G1 X44.899 Y41.13 F254
G1 X45.202 Y41.078 F254
G1 X45.807 Y40.971 F254
G1 X46.112 Y40.938 F254
G1 X46.265 Y40.93 F254
G1 X46.49 Y40.934 F254
G1 X46.642 Y40.947 F254
G1 X46.944 Y41.001 F254
G1 X47.093 Y41.039 F254
G1 X47.384 Y41.136 F254
G1 X47.527 Y41.193 F254
G1 X47.766 Y41.302 F254
G1 X48.305 Y41.596 F254
G1 X48.37 Y41.637 F254
G1 X48.546 Y41.758 F254
G1 X48.786 Y41.95 F254
G1 X48.962 Y42.096 F254
G1 X49.021 Y42.237 F254
G1 X49.025 Y42.389 F254
G1 X48.998 Y42.539 F254
G1 X48.918 Y42.823 F254
G1 X48.813 Y43.111 F254
G1 X48.704 Y43.398 F254
G1 X48.482 Y43.971 F254
G1 X48.375 Y44.259 F254
G1 X48.288 Y44.553 F254
G1 X48.021 Y45.435 F254
G1 X47.963 Y45.736 F254
G1 X47.925 Y46.041 F254
G1 X47.864 Y46.498 F254
G1 Y46.574 F254
G1 X47.889 Y46.647 F254
G1 X47.979 Y46.772 F254
G1 X48.228 Y46.951 F254
G1 X48.361 Y47.026 F254
G1 X48.486 Y47.113 F254
G1 X48.603 Y47.211 F254
G1 X48.712 Y47.318 F254
G1 X48.811 Y47.433 F254
G1 X48.9 Y47.557 F254
G1 X48.98 Y47.687 F254
G1 X49.06 Y47.844 F254
G1 X49.147 Y48.048 F254
G1 X49.235 Y48.309 F254
G1 X49.272 Y48.456 F254
G1 X49.274 Y48.47 F254
G1 X49.291 Y48.658 F254
G1 X49.303 Y48.727 F254
G1 X49.354 Y48.937 F254
G1 X49.46 Y49.355 F254
G1 X49.521 Y49.565 F254
G1 X49.768 Y50.263 F254
G1 X49.86 Y50.484 F254
G1 X49.999 Y50.804 F254
G1 X50.071 Y50.96 F254
G1 X50.313 Y51.449 F254
G1 X50.422 Y51.658 F254
G1 X50.809 Y52.356 F254
G1 X51.148 Y52.914 F254
G1 X51.361 Y53.263 F254
G1 X51.407 Y53.333 F254
G1 X51.644 Y53.682 F254
G1 X52.651 Y55.152 F254
G1 X52.746 Y55.287 F254
G1 X52.797 Y55.357 F254
G1 X54.065 Y57.031 F254
G1 X54.186 Y57.187 F254
G1 X55.33 Y58.637 F254
G1 X56.349 Y59.974 F254
G1 X56.419 Y60.069 F254
G1 X56.977 Y60.841 F254
G1 X57.047 Y60.942 F254
G1 X57.139 Y61.079 F254
G1 X57.21 Y61.198 F254
G1 X57.287 Y61.329 F254
G1 X57.355 Y61.47 F254
G1 X57.413 Y61.617 F254
G1 X57.46 Y61.767 F254
G1 X57.495 Y61.921 F254
G1 X57.521 Y62.089 F254
G1 X57.537 Y62.278 F254
G1 X57.538 Y62.484 F254
G1 X57.523 Y62.696 F254
G1 X57.483 Y62.983 F254
G1 X57.471 Y63.034 F254
G1 X57.465 Y63.05 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X57.454 Y63.065 Z-8.045 F254
G1 X57.437 Y63.076 Z-7.994 F254
G1 X57.418 Y63.079 Z-7.944 F254
G1 X57.399 Y63.074 Z-7.893 F254
G3 X57.371 Y63.037 I0.021 J-0.045 F254
G1 X57.285 Y62.525 F254
; MOVEMENT_LINK_DIRECT
G1 X57.134 Y61.621 F254
; MOVEMENT_LEAD_IN
G1 X57.049 Y61.116 F254
G3 X57.069 Y61.068 I0.049 J-0.008 F254
G1 X57.087 Y61.06 Z-7.944 F254
G1 X57.107 Y61.059 Z-7.994 F254
G1 X57.125 Y61.066 Z-8.045 F254
G1 X57.139 Y61.079 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X57.561 Y61.707 F254
G1 X57.585 Y61.743 F254
G1 X57.605 Y61.773 F254
G1 X57.684 Y61.904 F254
G1 X57.712 Y62.068 F254
G1 X57.73 Y62.258 F254
G1 X57.734 Y62.467 F254
G1 X57.732 Y62.484 F254
G1 X57.728 Y62.5 F254
G1 X57.722 Y62.516 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X57.71 Y62.531 Z-8.045 F254
G1 X57.692 Y62.54 Z-7.994 F254
G1 X57.673 Y62.542 Z-7.944 F254
G1 X57.654 Y62.537 Z-7.893 F254
G3 X57.628 Y62.5 I0.023 J-0.044 F254
G1 X57.598 Y62.316 F254
; MOVEMENT_LEAD_IN
G1 X57.515 Y61.811 F254
G3 X57.535 Y61.762 I0.049 J-0.008 F254
G1 X57.553 Y61.754 Z-7.944 F254
G1 X57.572 Y61.753 Z-7.994 F254
G1 X57.591 Y61.76 Z-8.045 F254
G1 X57.605 Y61.773 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X57.675 Y61.878 F254
G1 X57.685 Y61.897 F254
G1 X57.787 Y62.161 F254
G1 X57.793 Y62.178 F254
G1 X57.796 Y62.195 F254
G1 X57.79 Y62.335 F254
G1 X57.788 Y62.37 F254
G1 X57.784 Y62.387 F254
G1 X57.776 Y62.405 F254
G1 X57.572 Y62.823 F254
G1 X57.465 Y63.05 F254
G1 X57.443 Y63.103 F254
G1 X57.326 Y63.546 F254
G1 X57.315 Y63.591 F254
G1 X57.31 Y63.626 F254
G1 X57.308 Y63.661 F254
G1 X57.312 Y63.731 F254
G1 X57.317 Y63.8 F254
G1 X57.358 Y64.219 F254
G1 X57.363 Y64.254 F254
G1 X57.369 Y64.289 F254
G1 X57.396 Y64.371 F254
G1 X57.484 Y64.665 F254
G1 X57.521 Y64.813 F254
G1 X57.546 Y64.964 F254
G1 X57.561 Y65.116 F254
G1 X57.564 Y65.268 F254
G1 X57.555 Y65.42 F254
G1 X57.535 Y65.571 F254
G1 X57.504 Y65.72 F254
G1 X57.46 Y65.866 F254
G1 X57.404 Y66.008 F254
G1 X57.337 Y66.148 F254
G1 X57.253 Y66.294 F254
G1 X57.152 Y66.443 F254
G1 X57.037 Y66.589 F254
G1 X56.913 Y66.724 F254
G1 X56.786 Y66.843 F254
G1 X56.658 Y66.947 F254
G1 X56.529 Y67.036 F254
G1 X56.398 Y67.114 F254
G1 X56.261 Y67.181 F254
G1 X56.119 Y67.238 F254
G1 X55.974 Y67.283 F254
G1 X55.825 Y67.315 F254
G1 X55.673 Y67.332 F254
G1 X55.521 Y67.334 F254
G1 X55.369 Y67.322 F254
G1 X55.219 Y67.295 F254
G1 X55.072 Y67.255 F254
G1 X54.929 Y67.202 F254
G1 X54.791 Y67.137 F254
G1 X54.659 Y67.061 F254
G1 X54.534 Y66.974 F254
G1 X54.411 Y66.874 F254
G1 X54.271 Y66.742 F254
G1 X54.109 Y66.564 F254
G1 X53.93 Y66.338 F254
G1 X53.906 Y66.3 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X53.996 Y66.256 I0.045 J-0.022 F254
G1 X54.004 Y66.273 Z-8.092 F254
G1 X54.011 Y66.288 Z-8.081 F254
G1 X54.016 Y66.298 Z-8.065 F254
G1 X54.018 Y66.301 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X55.888 Y63.82 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X55.891 Y63.818 Z-8.065 F254
G1 X55.901 Y63.813 Z-8.081 F254
G1 X55.916 Y63.806 Z-8.092 F254
G1 X55.933 Y63.798 Z-8.096 F254
G3 X57.396 Y64.371 I0.465 J0.966 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X57.675 Y65.158 F254
G1 X57.688 Y65.196 F254
G1 X57.702 Y65.235 F254
G1 X57.73 Y65.329 F254
G1 X57.732 Y65.343 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X57.73 Y65.346 Z-8.084 F254
G1 X57.715 Y65.358 Z-8.036 F254
G1 X57.698 Y65.364 Z-7.989 F254
G1 X57.68 Y65.363 Z-7.941 F254
G1 X57.663 Y65.356 Z-7.893 F254
G3 X57.644 Y65.332 I0.028 J-0.041 F254
G1 X57.457 Y64.829 F254
; MOVEMENT_LINK_DIRECT
G1 X57.345 Y64.527 F254
G3 X57.376 Y64.462 I0.047 J-0.017 F254
G3 X57.439 Y64.494 I0.016 J0.047 F254
G2 X57.673 Y65.161 I10.731 J-3.387 F254
; MOVEMENT_LEAD_IN
G1 X57.702 Y65.235 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X57.725 Y65.301 F254
G1 X57.732 Y65.336 F254
G1 X57.736 Y65.374 F254
G1 X57.74 Y65.405 F254
G1 X57.745 Y65.438 F254
G1 X57.756 Y65.59 F254
G1 X57.662 Y65.882 F254
G1 X57.597 Y66.053 F254
G1 X57.554 Y66.144 F254
G1 X57.542 Y66.162 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X57.526 Y66.174 Z-8.045 F254
G1 X57.507 Y66.178 Z-7.994 F254
G1 X57.488 Y66.176 Z-7.944 F254
G1 X57.471 Y66.166 Z-7.893 F254
G3 X57.456 Y66.115 I0.033 J-0.037 F254
G1 X57.51 Y65.925 F254
; MOVEMENT_LEAD_IN
G1 X57.647 Y65.433 F254
G3 X57.687 Y65.397 I0.048 J0.013 F254
G1 X57.707 Y65.398 Z-7.944 F254
G1 X57.724 Y65.406 Z-7.994 F254
G1 X57.738 Y65.42 Z-8.045 F254
G1 X57.745 Y65.438 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X57.774 Y65.667 F254
G1 X57.773 Y65.685 F254
G1 X57.745 Y65.775 F254
G1 X57.675 Y65.984 F254
G1 X57.665 Y66.009 F254
G1 X57.659 Y66.021 F254
G1 X57.396 Y66.337 F254
G1 X57.354 Y66.382 F254
G1 X57.186 Y66.545 F254
G1 X56.802 Y66.871 F254
G1 X56.719 Y66.941 F254
G1 X56.239 Y67.29 F254
G1 X56.209 Y67.309 F254
G1 X56.07 Y67.396 F254
G1 X55.937 Y67.469 F254
G1 X55.789 Y67.506 F254
G1 X55.637 Y67.522 F254
G1 X55.485 F254
G1 X55.333 Y67.509 F254
G1 X55.183 Y67.482 F254
G1 X55.035 Y67.443 F254
G1 X54.892 Y67.393 F254
G1 X54.752 Y67.332 F254
G1 X54.617 Y67.26 F254
G1 X54.51 Y67.192 F254
G1 X54.498 Y67.184 F254
G1 X54.487 Y67.174 F254
G1 X54.478 Y67.163 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X54.47 Y67.146 Z-8.045 F254
G1 X54.469 Y67.126 Z-7.994 F254
G1 X54.476 Y67.108 Z-7.944 F254
G1 X54.489 Y67.093 Z-7.893 F254
G3 X54.526 Y67.084 I0.029 J0.04 F254
G1 X55.049 Y67.16 F254
; MOVEMENT_LINK_DIRECT
G1 X55.529 Y67.229 F254
; MOVEMENT_LEAD_IN
G1 X56.049 Y67.304 F254
G3 X56.084 Y67.326 I-0.007 J0.049 F254
G1 X56.091 Y67.344 Z-7.944 F254
G1 Y67.364 Z-7.994 F254
G1 X56.084 Y67.382 Z-8.045 F254
G1 X56.07 Y67.396 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X56 Y67.438 F254
G1 X55.899 Y67.499 F254
G1 X55.861 Y67.52 F254
G1 X55.535 Y67.639 F254
G1 X55.512 Y67.645 F254
G1 X55.494 Y67.648 F254
G1 X55.221 Y67.646 F254
G1 X55.209 Y67.645 F254
G1 X55.185 Y67.639 F254
G1 X54.901 Y67.526 F254
G1 X54.884 Y67.516 F254
G1 X54.744 Y67.409 F254
G1 X54.562 Y67.269 F254
G1 X54.548 Y67.252 F254
G1 X54.249 Y66.871 F254
G1 X54.196 Y66.801 F254
G1 X54.103 Y66.662 F254
G1 X54.062 Y66.592 F254
G1 X53.837 Y66.172 F254
G1 X53.799 Y66.103 F254
G1 X53.674 Y65.894 F254
G1 X53.54 Y65.685 F254
G1 X53.488 Y65.61 F254
G1 X53.392 Y65.475 F254
G1 X53.159 Y65.196 F254
G1 X52.807 Y64.847 F254
G1 X52.721 Y64.769 F254
G1 X52.648 Y64.708 F254
G1 X52.232 Y64.367 F254
G1 X52.093 Y64.269 F254
G1 X51.534 Y63.889 F254
G1 X51.395 Y63.805 F254
G1 X50.627 Y63.382 F254
G1 X50.557 Y63.345 F254
G1 X50.348 Y63.256 F254
G1 X49.47 Y62.893 F254
G1 X49.441 Y62.883 F254
G1 X49.225 Y62.823 F254
G1 X48.325 Y62.586 F254
G1 X48.255 Y62.572 F254
G1 X48.109 Y62.544 F254
G1 X48.045 Y62.535 F254
G1 X47.069 Y62.425 F254
G1 X46.929 Y62.423 F254
G1 X46.231 Y62.439 F254
G1 X46.022 Y62.446 F254
G1 X45.952 Y62.453 F254
G1 X45.324 Y62.539 F254
G1 X45.288 Y62.544 F254
G1 X45.115 Y62.579 F254
G1 X45.045 Y62.596 F254
G1 X43.719 Y62.981 F254
G1 X43.649 Y63.003 F254
G1 X43.58 Y63.026 F254
G1 X43.562 Y63.033 F254
G1 X42.306 Y63.661 F254
G1 X42.114 Y63.762 F254
G1 X42.044 Y63.802 F254
G1 X40.779 Y64.708 F254
G1 X40.719 Y64.753 F254
G1 X40.69 Y64.777 F254
G1 X40.615 Y64.847 F254
G1 X39.532 Y65.867 F254
G1 X39.505 Y65.894 F254
G1 X39.323 Y66.112 F254
G1 X38.556 Y67.039 F254
G1 X38.525 Y67.08 F254
G1 X38.382 Y67.29 F254
G1 X37.788 Y68.222 F254
G1 X37.679 Y68.406 F254
G1 X37.648 Y68.463 F254
G1 X37.102 Y69.592 F254
G1 X37.073 Y69.662 F254
G1 X37.017 Y69.802 F254
G1 X36.99 Y69.872 F254
G1 X36.583 Y70.988 F254
G1 X36.471 Y71.407 F254
G1 X36.305 Y72.035 F254
G1 X36.287 Y72.105 F254
G1 X36.271 Y72.174 F254
G1 X36.13 Y73.012 F254
G1 X36.118 Y73.082 F254
G1 X36.067 Y73.71 F254
G1 X36.062 Y73.779 F254
G1 X36.058 Y74.059 F254
G1 X36.057 Y74.198 F254
G1 X36.06 Y74.268 F254
G1 X36.073 Y74.477 F254
G1 X36.158 Y75.454 F254
G1 X36.169 Y75.594 F254
G1 X36.174 Y75.664 F254
G1 X36.178 Y75.801 F254
G1 X36.179 Y76.02 F254
G1 X36.161 Y76.292 F254
G1 X36.117 Y76.596 F254
G1 X36.106 Y76.649 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X36.097 Y76.667 Z-8.045 F254
G1 X36.083 Y76.68 Z-7.994 F254
G1 X36.064 Y76.686 Z-7.944 F254
G1 X36.045 Y76.685 Z-7.893 F254
G3 X36.007 Y76.633 I0.012 J-0.048 F254
G1 X36.04 Y76.163 F254
; MOVEMENT_LEAD_IN
G1 X36.075 Y75.666 F254
G3 X36.119 Y75.62 I0.05 J0.003 F254
G1 X36.138 Y75.621 Z-7.944 F254
G1 X36.156 Y75.63 Z-7.994 F254
G1 X36.168 Y75.645 Z-8.045 F254
G1 X36.174 Y75.664 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X36.213 Y76.152 F254
G1 X36.211 Y76.17 F254
G1 X36.077 Y76.78 F254
G1 X36.058 Y76.85 F254
G1 X35.931 Y77.269 F254
G1 X35.879 Y77.478 F254
G1 X35.835 Y77.687 F254
G1 X35.734 Y78.176 F254
G1 X35.711 Y78.315 F254
G1 X35.695 Y78.412 F254
G1 X35.564 Y79.362 F254
G1 X35.542 Y79.571 F254
G1 X35.456 Y80.548 F254
G1 X35.44 Y80.758 F254
G1 X35.394 Y81.874 F254
G1 X35.392 Y81.944 F254
G1 X35.393 Y82.153 F254
G1 X35.409 Y83.061 F254
G1 X35.421 Y83.27 F254
G1 X35.433 Y83.41 F254
G1 X35.503 Y84.177 F254
G1 X35.511 Y84.247 F254
G1 X35.541 Y84.456 F254
G1 X35.651 Y85.154 F254
G1 X35.695 Y85.395 F254
G1 X35.84 Y86.061 F254
G1 X35.889 Y86.271 F254
G1 X35.907 Y86.34 F254
G1 X36.078 Y86.968 F254
G1 X36.099 Y87.038 F254
G1 X36.279 Y87.597 F254
G1 X36.327 Y87.736 F254
G1 X36.462 Y88.098 F254
G1 X36.484 Y88.155 F254
G1 X36.791 Y88.853 F254
G1 X36.911 Y89.062 F254
G1 X36.954 Y89.132 F254
G1 X37.656 Y90.248 F254
G1 X37.858 Y90.484 F254
G1 X38.137 Y90.797 F254
G1 X38.211 Y90.876 F254
G1 X38.277 Y90.946 F254
G1 X38.817 Y91.435 F254
G1 X39.044 Y91.613 F254
G1 X39.47 Y91.923 F254
G1 X39.532 Y91.967 F254
G1 X39.677 Y92.063 F254
G1 X39.742 Y92.104 F254
G1 X40.42 Y92.481 F254
G1 X40.44 Y92.491 F254
G1 X40.579 Y92.551 F254
G1 X41.207 Y92.791 F254
G1 X41.347 Y92.841 F254
G1 X41.593 Y92.9 F254
G1 X42.044 Y93.007 F254
G1 X42.114 Y93.023 F254
G1 X42.254 Y93.051 F254
G1 X42.962 Y93.179 F254
G1 X43.301 Y93.248 F254
G1 X44.068 Y93.408 F254
G1 X44.138 Y93.422 F254
G1 X46.51 Y93.99 F254
G1 X46.789 Y94.06 F254
G1 X47.704 Y94.296 F254
G1 X48.491 Y94.505 F254
G1 X48.813 Y94.592 F254
G1 X49.371 Y94.748 F254
G1 X49.511 Y94.788 F254
G1 X49.86 Y94.892 F254
G1 X49.999 Y94.936 F254
G1 X50.627 Y95.142 F254
G1 X50.767 Y95.191 F254
G1 X50.906 Y95.243 F254
G1 X51.349 Y95.412 F254
G1 X51.534 Y95.494 F254
G1 X51.604 Y95.525 F254
G1 X52.721 Y96.075 F254
G1 X52.79 Y96.114 F254
G1 X53.907 Y96.833 F254
G1 X54.116 Y96.976 F254
G1 X54.754 Y97.436 F254
G1 X55.796 Y98.204 F254
G1 X58.33 Y100.018 F254
G1 X58.582 Y100.19 F254
G1 X59.001 Y100.469 F254
G1 X59.14 Y100.558 F254
G1 X59.504 Y100.786 F254
G1 X59.698 Y100.891 F254
G1 X59.768 Y100.928 F254
G1 X60.466 Y101.282 F254
G1 X60.536 Y101.317 F254
G1 X60.613 Y101.344 F254
G1 X60.675 Y101.364 F254
G1 X61.582 Y101.635 F254
G1 X61.792 Y101.678 F254
G1 X62.001 Y101.714 F254
G1 X62.28 Y101.761 F254
G1 X62.629 Y101.801 F254
G1 X63.048 Y101.848 F254
G1 X63.187 Y101.859 F254
G1 X64.792 Y101.945 F254
G1 X65.002 Y101.953 F254
G1 X65.071 Y101.955 F254
G1 X65.769 Y101.938 F254
G1 X65.978 Y101.926 F254
G1 X66.327 Y101.895 F254
G1 X66.634 Y101.883 F254
G1 X66.832 Y101.889 F254
G1 X67.041 Y101.91 F254
G1 X67.258 Y101.948 F254
G1 X67.493 Y102.008 F254
G1 X67.749 Y102.094 F254
G1 X68.003 Y102.2 F254
G1 X68.094 Y102.246 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X68.108 Y102.26 Z-8.045 F254
G1 X68.116 Y102.277 Z-7.994 F254
G1 Y102.297 Z-7.944 F254
G1 X68.109 Y102.315 Z-7.893 F254
G3 X68.057 Y102.337 I-0.042 J-0.027 F254
G1 X67.559 Y102.239 F254
; MOVEMENT_LINK_DIRECT
G1 X66.819 Y102.092 F254
; MOVEMENT_LEAD_IN
G1 X66.324 Y101.994 F254
G3 X66.284 Y101.951 I0.01 J-0.049 F254
G1 X66.285 Y101.932 Z-7.944 F254
G1 X66.294 Y101.914 Z-7.994 F254
G1 X66.309 Y101.901 Z-8.045 F254
G1 X66.327 Y101.895 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X66.397 Y101.889 F254
G1 X66.467 Y101.884 F254
G1 X66.676 Y101.881 F254
G1 X67.339 Y101.887 F254
G1 X67.357 Y101.89 F254
G1 X67.374 Y101.895 F254
G1 X67.583 Y101.975 F254
G1 X67.653 Y102.003 F254
G1 X67.793 Y102.072 F254
G1 X67.866 Y102.111 F254
G1 X68.219 Y102.321 F254
G1 X68.7 Y102.62 F254
G1 X68.78 Y102.67 F254
G1 X68.839 Y102.703 F254
G1 X69.467 Y103.027 F254
G1 X69.537 Y103.056 F254
G1 X69.816 Y103.155 F254
G1 X70.165 Y103.275 F254
G1 X70.239 Y103.298 F254
G1 X70.374 Y103.337 F254
G1 X70.444 Y103.356 F254
G1 X71.072 Y103.479 F254
G1 X71.142 Y103.491 F254
G1 X71.351 Y103.524 F254
G1 X72.049 Y103.593 F254
G1 X72.258 Y103.611 F254
G1 X72.328 Y103.609 F254
G1 X73.166 Y103.572 F254
G1 X73.235 Y103.562 F254
G1 X73.445 Y103.517 F254
G1 X74.212 Y103.337 F254
G1 X74.282 Y103.316 F254
G1 X74.352 Y103.284 F254
G1 X75.329 Y102.797 F254
G1 X75.414 Y102.751 F254
G1 X75.429 Y102.74 F254
G1 X75.468 Y102.707 F254
G1 X75.51 Y102.67 F254
G1 X75.87 Y102.338 F254
G1 X75.887 Y102.318 F254
G1 X75.937 Y102.251 F254
G1 X75.957 Y102.224 F254
G1 X76.173 Y101.902 F254
G1 X76.215 Y101.832 F254
G1 X76.236 Y101.783 F254
G1 X76.243 Y101.763 F254
G1 X76.518 Y100.855 F254
G1 X76.535 Y100.786 F254
G1 X76.567 Y100.506 F254
G1 X76.588 Y100.297 F254
G1 X76.593 Y100.227 F254
G1 X76.6 Y100.088 F254
G1 X76.603 Y100.018 F254
G1 X76.604 Y99.809 F254
G1 X76.595 Y99.599 F254
G1 X76.585 Y99.493 F254
G1 X76.549 Y99.181 F254
G1 X76.539 Y99.111 F254
G1 X76.483 Y98.901 F254
G1 X76.422 Y98.692 F254
G1 X76.396 Y98.622 F254
G1 X76.375 Y98.575 F254
G1 X76.268 Y98.294 F254
G1 X76.22 Y98.128 F254
G1 X76.182 Y97.943 F254
G1 X76.155 Y97.746 F254
G1 X76.143 Y97.538 F254
G1 X76.147 Y97.322 F254
G1 X76.167 Y97.097 F254
G1 X76.209 Y96.837 F254
G1 X76.265 Y96.605 F254
G1 X76.267 Y96.601 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X76.277 Y96.585 Z-8.045 F254
G1 X76.294 Y96.574 Z-7.994 F254
G1 X76.313 Y96.57 Z-7.944 F254
G1 X76.332 Y96.573 Z-7.893 F254
G3 X76.363 Y96.617 I-0.019 J0.046 F254
G1 X76.391 Y97.127 F254
; MOVEMENT_LINK_DIRECT
G1 X76.442 Y98.042 F254
; MOVEMENT_LEAD_IN
G1 X76.47 Y98.55 F254
G3 X76.442 Y98.598 I-0.05 J0.003 F254
G1 X76.423 Y98.603 Z-7.944 F254
G1 X76.404 Y98.6 Z-7.994 F254
G1 X76.387 Y98.591 Z-8.045 F254
G1 X76.375 Y98.575 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X76.166 Y98.103 F254
G1 X76.153 Y98.064 F254
G1 X76.037 Y97.576 F254
G1 X76.034 Y97.558 F254
G1 Y97.541 F254
G1 X76.04 Y97.506 F254
G1 X76.155 Y96.947 F254
G1 X76.169 Y96.878 F254
G1 X76.192 Y96.808 F254
G1 X76.445 Y96.109 F254
G1 X76.467 Y96.04 F254
G1 X76.527 Y95.831 F254
G1 X76.626 Y95.412 F254
G1 X76.639 Y95.342 F254
G1 X76.707 Y94.714 F254
G1 X76.712 Y94.645 F254
G1 X76.72 Y94.505 F254
G1 X76.723 Y94.435 F254
G1 X76.731 Y92.76 F254
G1 Y92.621 F254
G1 X76.724 Y92.518 F254
G1 X76.58 Y90.597 F254
G1 X76.575 Y90.527 F254
G1 X76.565 Y90.458 F254
G1 X76.436 Y89.62 F254
G1 X76.424 Y89.55 F254
G1 X76.409 Y89.481 F254
G1 X76.234 Y88.713 F254
G1 X76.217 Y88.643 F254
G1 X75.691 Y87.038 F254
G1 X75.567 Y86.759 F254
G1 X75.029 Y85.573 F254
G1 X74.995 Y85.503 F254
G1 X74.959 Y85.433 F254
G1 X74.878 Y85.294 F254
G1 X73.305 Y82.632 F254
G1 X73.135 Y82.363 F254
G1 X72.366 Y81.176 F254
G1 X71.739 Y80.2 F254
G1 X71.652 Y80.06 F254
G1 X70.577 Y78.246 F254
G1 X70.539 Y78.176 F254
G1 X70.29 Y77.687 F254
G1 X70.077 Y77.269 F254
G1 X69.95 Y76.989 F254
G1 X69.668 Y76.361 F254
G1 X69.576 Y76.152 F254
G1 X69.537 Y76.059 F254
G1 X69.098 Y74.966 F254
G1 X68.968 Y74.617 F254
G1 X68.531 Y73.431 F254
G1 X68.457 Y73.221 F254
G1 X68.236 Y72.593 F254
G1 X68.046 Y72.035 F254
G1 X67.932 Y71.681 F254
G1 X67.862 Y71.459 F254
G1 X67.793 Y71.22 F254
G1 X67.751 Y71.058 F254
G1 X67.722 Y70.912 F254
G1 X67.693 Y70.758 F254
G1 X67.673 Y70.585 F254
G1 X67.666 Y70.406 F254
G1 X67.672 Y70.226 F254
G1 X67.691 Y70.049 F254
G1 X67.723 Y69.877 F254
G1 X67.768 Y69.706 F254
G1 X67.827 Y69.532 F254
G1 X67.904 Y69.353 F254
G1 X68.004 Y69.159 F254
G1 X68.136 Y68.944 F254
G1 X68.29 Y68.729 F254
G1 X68.396 Y68.603 F254
G1 X68.399 Y68.601 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X68.466 Y68.674 I0.034 J0.037 F254
G1 X68.452 Y68.687 Z-8.092 F254
G1 X68.44 Y68.698 Z-8.081 F254
G1 X68.432 Y68.706 Z-8.065 F254
G1 X68.43 Y68.708 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X70.607 Y72.447 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X70.604 Y72.448 Z-8.065 F254
G1 X70.594 Y72.452 Z-8.081 F254
G1 X70.578 Y72.458 Z-8.092 F254
G1 X70.56 Y72.465 Z-8.096 F254
G3 X67.751 Y71.058 I-0.751 J-2.008 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X67.734 Y70.988 F254
G1 X67.672 Y70.709 F254
G1 X67.642 Y70.569 F254
G1 X67.629 Y70.5 F254
G1 X67.598 Y70.151 F254
G1 X67.599 Y70.133 F254
G1 X67.609 Y70.081 F254
G1 X67.736 Y69.453 F254
G1 X67.742 Y69.435 F254
G1 X67.754 Y69.418 F254
G1 X68.173 Y68.825 F254
G1 X68.191 Y68.805 F254
G1 X68.839 Y68.17 F254
G1 X68.88 Y68.127 F254
G1 X69.008 Y67.987 F254
G1 X69.506 Y67.429 F254
G1 X69.629 Y67.29 F254
G1 X69.677 Y67.234 F254
G1 X69.966 Y66.801 F254
G1 X70.01 Y66.731 F254
G1 X70.095 Y66.59 F254
G1 X70.135 Y66.522 F254
G1 X70.466 Y65.894 F254
G1 X70.501 Y65.824 F254
G1 X70.657 Y65.475 F254
G1 X70.723 Y65.324 F254
G1 X70.807 Y65.126 F254
G1 X71.004 Y64.638 F254
G1 X71.072 Y64.462 F254
G1 X71.351 Y63.717 F254
G1 X71.546 Y63.172 F254
G1 X71.669 Y62.823 F254
G1 X71.765 Y62.544 F254
G1 X72.294 Y60.939 F254
G1 X72.358 Y60.73 F254
G1 X72.707 Y59.544 F254
G1 X72.766 Y59.334 F254
G1 X73.017 Y58.357 F254
G1 X73.051 Y58.218 F254
G1 X73.068 Y58.148 F254
G1 X73.221 Y57.45 F254
G1 X73.264 Y57.241 F254
G1 X73.356 Y56.752 F254
G1 X73.441 Y56.264 F254
G1 X73.584 Y55.395 F254
G1 X73.881 Y53.752 F254
G1 X73.933 Y53.505 F254
G1 X74.087 Y52.844 F254
G1 X74.144 Y52.635 F254
G1 X74.205 Y52.426 F254
G1 X74.352 Y51.924 F254
G1 X74.37 Y51.868 F254
G1 X74.443 Y51.658 F254
G1 X74.665 Y51.1 F254
G1 X74.792 Y50.821 F254
G1 X74.87 Y50.667 F254
G1 X74.96 Y50.516 F254
G1 X75.059 Y50.376 F254
G1 X75.166 Y50.246 F254
G1 X75.276 Y50.131 F254
G1 X75.389 Y50.029 F254
G1 X75.509 Y49.936 F254
G1 X75.636 Y49.852 F254
G1 X75.77 Y49.778 F254
G1 X75.91 Y49.714 F254
G1 X76.063 Y49.656 F254
G1 X76.24 Y49.605 F254
G1 X76.435 Y49.563 F254
G1 X76.674 Y49.531 F254
G1 X76.921 Y49.515 F254
G1 X76.958 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X76.946 Y49.615 I-0.006 J0.05 F254
G1 X76.927 Y49.612 Z-8.092 F254
G1 X76.911 Y49.61 Z-8.081 F254
G1 X76.9 Y49.609 Z-8.065 F254
G1 X76.896 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X76.16 Y53.901 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X76.157 Y53.9 Z-8.065 F254
G1 X76.146 Y53.898 Z-8.081 F254
G1 X76.131 Y53.893 Z-8.092 F254
G1 X76.112 Y53.888 Z-8.096 F254
G3 X74.665 Y51.1 I0.572 J-2.067 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X74.776 Y50.821 F254
G1 X74.811 Y50.751 F254
G1 X74.84 Y50.699 F254
G1 X75.301 Y49.95 F254
G1 X75.332 Y49.914 F254
G1 X75.438 Y49.806 F254
G1 X75.468 Y49.776 F254
G1 X75.47 Y49.774 F254
G1 X75.574 Y49.681 F254
G1 X75.578 Y49.678 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X75.596 Y49.67 Z-8.045 F254
G1 X75.615 Y49.671 Z-7.994 F254
G1 X75.633 Y49.678 Z-7.944 F254
G1 X75.647 Y49.692 Z-7.893 F254
G3 X75.638 Y49.757 I-0.042 J0.027 F254
G1 X75.54 Y49.845 F254
G3 X75.473 I-0.033 J-0.037 F254
G1 X75.461 Y49.829 Z-7.944 F254
G1 X75.457 Y49.81 Z-7.994 F254
G1 X75.46 Y49.791 Z-8.045 F254
G1 X75.47 Y49.774 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X75.54 Y49.704 F254
G1 X75.608 Y49.656 F254
G1 X75.641 Y49.634 F254
G1 X75.678 Y49.61 F254
G1 X75.75 Y49.568 F254
G1 X75.76 Y49.564 F254
G1 X75.771 Y49.561 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X75.791 Y49.56 Z-8.045 F254
G1 X75.809 Y49.567 Z-7.994 F254
G1 X75.823 Y49.58 Z-7.944 F254
G1 X75.831 Y49.598 Z-7.893 F254
G3 X75.806 Y49.653 I-0.049 J0.011 F254
G1 X75.731 Y49.695 F254
G3 X75.666 Y49.68 I-0.024 J-0.044 F254
G1 X75.658 Y49.662 Z-7.944 F254
G1 X75.657 Y49.643 Z-7.994 F254
G1 X75.664 Y49.625 Z-8.045 F254
G1 X75.678 Y49.61 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X75.73 Y49.576 F254
G1 X75.756 Y49.565 F254
G1 X76.184 Y49.452 F254
G1 X76.201 Y49.451 F254
G1 X76.236 Y49.453 F254
G1 X77.352 Y49.549 F254
G1 X77.422 Y49.553 F254
G1 X77.631 Y49.555 F254
G1 X78.19 Y49.544 F254
G1 X78.259 Y49.543 F254
G1 X78.329 Y49.539 F254
G1 X78.748 Y49.468 F254
G1 X78.818 Y49.453 F254
G1 X78.957 Y49.42 F254
G1 X79.027 Y49.403 F254
G1 X79.454 Y49.286 F254
G1 X79.585 Y49.236 F254
G1 X79.795 Y49.155 F254
G1 X80.841 Y48.742 F254
G1 X80.874 Y48.727 F254
G1 X81.152 Y48.588 F254
G1 X81.972 Y48.169 F254
G1 X82.027 Y48.139 F254
G1 X82.237 Y48.011 F254
G1 X83.004 Y47.463 F254
G1 X83.038 Y47.436 F254
G1 X83.074 Y47.399 F254
G1 X83.144 Y47.315 F254
G1 X83.632 Y46.706 F254
G1 X83.721 Y46.605 F254
G1 X83.824 Y46.492 F254
G1 X83.935 Y46.389 F254
G1 X84.055 Y46.295 F254
G1 X84.183 Y46.212 F254
G1 X84.318 Y46.14 F254
G1 X84.458 Y46.081 F254
G1 X84.603 Y46.034 F254
G1 X84.752 Y46.001 F254
G1 X84.903 Y45.982 F254
G1 X85.056 Y45.977 F254
G1 X85.208 Y45.987 F254
G1 X85.358 Y46.01 F254
G1 X85.506 Y46.047 F254
G1 X85.668 Y46.101 F254
G1 X85.854 Y46.178 F254
G1 X86.069 Y46.287 F254
G1 X86.311 Y46.433 F254
G1 X86.326 Y46.447 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X86.253 Y46.514 I-0.037 J0.034 F254
G1 X86.24 Y46.5 Z-8.092 F254
G1 X86.229 Y46.488 Z-8.081 F254
G1 X86.222 Y46.48 Z-8.065 F254
G1 X86.219 Y46.478 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X83.325 Y49.876 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X83.323 Y49.872 Z-8.065 F254
G1 X83.319 Y49.862 Z-8.081 F254
G1 X83.312 Y49.848 Z-8.092 F254
G1 X83.304 Y49.83 Z-8.096 F254
G3 X83.632 Y46.706 I2.792 J-1.286 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X83.702 Y46.619 F254
G1 X83.742 Y46.564 F254
G1 X83.775 Y46.494 F254
G1 X83.832 Y46.355 F254
G1 X83.897 Y46.217 F254
G1 X84.007 Y46.111 F254
G1 X84.133 Y46.025 F254
G1 X84.268 Y45.954 F254
G1 X84.409 Y45.896 F254
G1 X84.554 Y45.85 F254
G1 X84.703 Y45.817 F254
G1 X84.854 Y45.796 F254
G1 X85.006 Y45.787 F254
G1 X85.158 Y45.791 F254
G1 X85.31 Y45.807 F254
G1 X85.459 Y45.836 F254
G1 X85.619 Y45.879 F254
G1 X85.802 Y45.944 F254
G1 X85.833 Y45.958 F254
G1 X85.848 Y45.965 F254
G1 X85.861 Y45.974 F254
G1 X85.872 Y45.985 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X85.882 Y46.001 Z-8.045 F254
G1 X85.885 Y46.021 Z-7.994 F254
G1 X85.881 Y46.04 Z-7.944 F254
G1 X85.869 Y46.055 Z-7.893 F254
G3 X85.844 Y46.068 I-0.034 J-0.037 F254
G1 X85.314 Y46.164 F254
; MOVEMENT_LINK_DIRECT
G1 X84.42 Y46.325 F254
; MOVEMENT_LEAD_IN
G1 X83.888 Y46.421 F254
G3 X83.862 Y46.419 I-0.009 J-0.049 F254
G1 X83.845 Y46.409 Z-7.944 F254
G1 X83.834 Y46.393 Z-7.994 F254
G1 X83.829 Y46.374 Z-8.045 F254
G1 X83.832 Y46.355 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X83.944 Y46.076 F254
G1 X84.007 Y45.937 F254
G1 X84.121 Y45.835 F254
G1 X84.253 Y45.759 F254
G1 X84.394 Y45.701 F254
G1 X84.539 Y45.657 F254
G1 X84.688 Y45.625 F254
G1 X84.84 Y45.604 F254
G1 X84.992 Y45.596 F254
G1 X85.144 Y45.598 F254
G1 X85.298 Y45.612 F254
G1 X85.458 Y45.639 F254
G1 X85.55 Y45.661 F254
G1 X85.575 Y45.67 F254
G1 X85.598 Y45.684 F254
G1 X85.617 Y45.703 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X85.626 Y45.721 Z-8.045 F254
G1 X85.627 Y45.74 Z-7.994 F254
G1 X85.62 Y45.759 Z-7.944 F254
G1 X85.608 Y45.773 Z-7.893 F254
G3 X85.588 Y45.782 I-0.03 J-0.04 F254
G1 X85.056 Y45.903 F254
; MOVEMENT_LINK_DIRECT
G1 X84.528 Y46.022 F254
; MOVEMENT_LEAD_IN
G1 X84.002 Y46.141 F254
G3 X83.974 Y46.139 I-0.011 J-0.049 F254
G1 X83.957 Y46.129 Z-7.944 F254
G1 X83.946 Y46.114 Z-7.994 F254
G1 X83.941 Y46.095 Z-8.045 F254
G1 X83.944 Y46.076 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.051 Y45.806 F254
G1 X84.114 Y45.667 F254
G1 X84.237 Y45.577 F254
G1 X84.375 Y45.513 F254
G1 X84.521 Y45.467 F254
G1 X84.67 Y45.435 F254
G1 X84.823 Y45.414 F254
G1 X84.983 Y45.404 F254
G1 X85.147 Y45.405 F254
G1 X85.316 Y45.42 F254
G1 X85.35 Y45.425 F254
G1 X85.379 Y45.434 F254
G1 X85.405 Y45.449 F254
G1 X85.427 Y45.47 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X85.436 Y45.487 Z-8.045 F254
G1 X85.437 Y45.507 Z-7.994 F254
G1 X85.43 Y45.525 Z-7.944 F254
G1 X85.417 Y45.54 Z-7.893 F254
G3 X85.399 Y45.549 I-0.03 J-0.04 F254
G1 X84.868 Y45.682 F254
; MOVEMENT_LINK_DIRECT
G1 X84.632 Y45.741 F254
; MOVEMENT_LEAD_IN
G1 X84.11 Y45.871 F254
G3 X84.081 Y45.87 I-0.012 J-0.049 F254
G1 X84.064 Y45.86 Z-7.944 F254
G1 X84.053 Y45.844 Z-7.994 F254
G1 X84.048 Y45.825 Z-8.045 F254
G1 X84.051 Y45.806 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.121 Y45.631 F254
G1 X84.135 Y45.587 F254
G1 X84.161 Y45.515 F254
G1 X84.256 Y45.396 F254
G1 X84.389 Y45.322 F254
G1 X84.533 Y45.272 F254
G1 X84.682 Y45.24 F254
G1 X84.836 Y45.22 F254
G1 X85.002 Y45.21 F254
G1 X85.159 Y45.213 F254
G1 X85.171 Y45.214 F254
G1 X85.203 Y45.221 F254
G1 X85.232 Y45.237 F254
G1 X85.256 Y45.26 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X85.265 Y45.277 Z-8.045 F254
G1 X85.266 Y45.297 Z-7.994 F254
G1 X85.26 Y45.315 Z-7.944 F254
G1 X85.247 Y45.33 Z-7.893 F254
G3 X85.231 Y45.338 I-0.03 J-0.04 F254
G1 X84.715 Y45.493 F254
; MOVEMENT_LEAD_IN
G1 X84.198 Y45.648 F254
G3 X84.171 I-0.014 J-0.048 F254
G1 X84.153 Y45.64 Z-7.944 F254
G1 X84.14 Y45.625 Z-7.994 F254
G1 X84.134 Y45.607 Z-8.045 F254
G1 X84.135 Y45.587 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.191 Y45.405 F254
G1 X84.198 Y45.378 F254
G1 X84.219 Y45.304 F254
G1 X84.315 Y45.187 F254
G1 X84.45 Y45.115 F254
G1 X84.595 Y45.069 F254
G1 X84.745 Y45.039 F254
G1 X84.896 Y45.022 F254
G1 X84.997 Y45.019 F254
G1 X85.035 Y45.023 F254
G1 X85.07 Y45.039 F254
G1 X85.098 Y45.065 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X85.107 Y45.083 Z-8.045 F254
G1 X85.108 Y45.102 Z-7.994 F254
G1 X85.102 Y45.12 Z-7.944 F254
G1 X85.089 Y45.135 Z-7.893 F254
G3 X85.075 Y45.142 I-0.03 J-0.04 F254
G1 X84.773 Y45.251 F254
; MOVEMENT_LEAD_IN
G1 X84.264 Y45.434 F254
G3 X84.238 Y45.436 I-0.017 J-0.047 F254
G1 X84.219 Y45.429 Z-7.944 F254
G1 X84.206 Y45.415 Z-7.994 F254
G1 X84.198 Y45.397 Z-8.045 F254
G1 Y45.378 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.246 Y45.168 F254
G1 X84.267 Y45.095 F254
G1 X84.368 Y44.981 F254
G1 X84.504 Y44.912 F254
G1 X84.65 Y44.868 F254
G1 X84.8 Y44.841 F254
G1 X84.846 Y44.838 F254
G1 X84.884 Y44.842 F254
G1 X84.92 Y44.857 F254
G1 X84.949 Y44.883 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X84.958 Y44.9 Z-8.045 F254
G1 X84.959 Y44.92 Z-7.994 F254
G1 X84.953 Y44.938 Z-7.944 F254
G1 X84.941 Y44.953 Z-7.893 F254
G3 X84.93 Y44.959 I-0.031 J-0.039 F254
G1 X84.809 Y45.011 F254
; MOVEMENT_LEAD_IN
G1 X84.315 Y45.224 F254
G3 X84.286 Y45.227 I-0.02 J-0.046 F254
G1 X84.268 Y45.22 Z-7.944 F254
G1 X84.254 Y45.206 Z-7.994 F254
G1 X84.246 Y45.188 Z-8.045 F254
G1 Y45.168 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.287 Y44.99 F254
G1 X84.308 Y44.917 F254
G1 X84.396 Y44.793 F254
G1 X84.529 Y44.719 F254
G1 X84.675 Y44.674 F254
G1 X84.7 Y44.671 F254
G1 X84.741 Y44.674 F254
G1 X84.778 Y44.689 F254
G1 X84.809 Y44.715 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X84.818 Y44.733 Z-8.045 F254
G1 X84.819 Y44.752 Z-7.994 F254
G1 X84.813 Y44.771 Z-7.944 F254
G1 X84.801 Y44.786 Z-7.893 F254
; MOVEMENT_LEAD_IN
G1 X84.795 Y44.789 F254
G1 X84.362 Y45.043 F254
G3 X84.327 Y45.049 I-0.025 J-0.043 F254
G1 X84.309 Y45.042 Z-7.944 F254
G1 X84.295 Y45.028 Z-7.994 F254
G1 X84.287 Y45.01 Z-8.045 F254
G1 Y44.99 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.337 Y44.774 F254
G1 X84.343 Y44.75 F254
G1 X84.352 Y44.711 F254
G1 X84.362 Y44.675 F254
G1 X84.474 Y44.571 F254
G1 X84.543 Y44.541 F254
G1 X84.594 Y44.531 F254
G1 X84.645 Y44.542 F254
G1 X84.686 Y44.573 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X84.696 Y44.59 Z-8.045 F254
G1 X84.697 Y44.61 Z-7.994 F254
G1 X84.692 Y44.629 Z-7.944 F254
G1 X84.679 Y44.644 Z-7.893 F254
G3 X84.669 Y44.65 I-0.032 J-0.039 F254
G1 X84.422 Y44.766 F254
G3 X84.391 Y44.77 I-0.021 J-0.045 F254
G1 X84.373 Y44.763 Z-7.944 F254
G1 X84.359 Y44.749 Z-7.994 F254
G1 X84.352 Y44.731 Z-8.045 F254
G1 Y44.711 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.386 Y44.572 F254
G1 X84.394 Y44.54 F254
G1 X84.4 Y44.519 F254
G1 X84.408 Y44.491 F254
G1 X84.428 Y44.474 F254
G1 X84.484 Y44.445 F254
G1 X84.547 Y44.447 F254
G1 X84.601 Y44.479 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X84.611 Y44.496 Z-8.045 F254
G1 X84.614 Y44.515 Z-7.994 F254
G1 X84.609 Y44.534 Z-7.944 F254
G1 X84.598 Y44.55 Z-7.893 F254
G3 X84.571 Y44.562 I-0.034 J-0.037 F254
G1 X84.456 Y44.579 F254
G3 X84.438 Y44.578 I-0.007 J-0.049 F254
G1 X84.42 Y44.571 Z-7.944 F254
G1 X84.407 Y44.557 Z-7.994 F254
G1 X84.4 Y44.539 Z-8.045 F254
G1 Y44.519 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.422 Y44.436 F254
G1 X84.428 Y44.418 F254
G1 X84.439 Y44.401 F254
G1 X84.454 Y44.388 F254
G1 X84.47 Y44.38 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G3 X84.507 Y44.398 I0.002 J0.043 F254
G3 X84.441 Y44.444 I-0.033 J0.023 F254
G3 X84.439 Y44.401 I0.033 J-0.023 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X84.454 Y44.386 F254
G1 X84.47 Y44.38 F254
G1 X84.483 Y44.378 F254
G1 X84.497 Y44.381 F254
G1 X84.51 Y44.388 F254
G1 X84.539 Y44.417 F254
G1 X84.609 Y44.488 F254
G1 X84.657 Y44.54 F254
G1 X84.779 Y44.68 F254
G1 X84.958 Y44.893 F254
G1 X85.656 Y45.751 F254
G1 X85.726 Y45.835 F254
G1 X86.423 Y46.545 F254
G1 X86.443 Y46.564 F254
G1 X86.468 Y46.584 F254
G1 X86.493 Y46.602 F254
G1 X86.788 Y46.773 F254
G1 X87.15 Y46.983 F254
G1 X87.191 Y47.005 F254
G1 X87.282 Y47.052 F254
G1 X87.306 Y47.06 F254
G1 X87.4 Y47.083 F254
G1 X88.028 Y47.209 F254
G1 X88.098 Y47.222 F254
G1 X88.307 Y47.245 F254
G1 X88.517 Y47.272 F254
G1 X88.587 Y47.282 F254
G1 X88.796 Y47.317 F254
G1 X89.005 Y47.36 F254
G1 X89.494 Y47.475 F254
G1 X89.773 Y47.55 F254
G1 X90.401 Y47.723 F254
G1 X90.471 Y47.736 F254
G1 X90.82 Y47.787 F254
G1 X91.099 Y47.827 F254
G1 X91.134 Y47.83 F254
G1 X91.168 F254
G1 X91.241 Y47.82 F254
G1 X91.308 Y47.799 F254
G1 X91.405 Y47.75 F254
G1 X91.54 Y47.681 F254
G1 X91.587 Y47.652 F254
G1 X91.637 Y47.611 F254
G1 X91.657 Y47.59 F254
G1 X91.694 Y47.541 F254
G1 X91.727 Y47.481 F254
G1 X91.731 Y47.471 F254
G1 X91.752 Y47.401 F254
G1 X91.784 Y47.192 F254
G1 X91.796 Y47.101 F254
G1 X91.798 Y47.052 F254
G1 X91.796 Y47.019 F254
G1 X91.791 Y46.983 F254
G1 X91.756 Y46.843 F254
G1 X91.701 Y46.634 F254
G1 X91.68 Y46.564 F254
G1 X91.566 Y46.285 F254
G1 X91.517 Y46.169 F254
G1 X91.414 Y45.883 F254
G1 X91.375 Y45.735 F254
G1 X91.348 Y45.585 F254
G1 X91.335 Y45.433 F254
G1 X91.334 Y45.281 F254
G1 X91.349 Y45.129 F254
G1 X91.378 Y44.98 F254
G1 X91.425 Y44.835 F254
G1 X91.488 Y44.696 F254
G1 X91.567 Y44.566 F254
G1 X91.66 Y44.445 F254
G1 X91.765 Y44.335 F254
G1 X91.881 Y44.236 F254
G1 X92.006 Y44.149 F254
G1 X92.14 Y44.076 F254
G1 X92.281 Y44.017 F254
G1 X92.427 Y43.973 F254
G1 X92.576 Y43.943 F254
G1 X92.729 Y43.925 F254
G1 X92.903 Y43.918 F254
G1 X93.093 Y43.924 F254
G1 X93.335 Y43.95 F254
G1 X93.566 Y43.992 F254
G1 X93.577 Y43.995 F254
G1 X93.589 Y43.999 F254
G1 X93.6 Y44.003 F254
G1 X93.68 Y44.044 F254
G1 X93.96 Y44.116 F254
G1 X94.099 Y44.15 F254
G1 X94.169 Y44.165 F254
G1 X94.239 Y44.178 F254
G1 X94.256 Y44.18 F254
G1 X94.448 F254
G1 X94.657 Y44.179 F254
G1 X94.727 Y44.176 F254
G1 X94.797 Y44.164 F254
G1 X94.814 Y44.159 F254
G1 X95.052 Y44.052 F254
G1 X95.216 Y43.974 F254
G1 X95.25 Y43.956 F254
G1 X95.285 Y43.931 F254
G1 X95.309 Y43.912 F254
G1 X95.334 Y43.888 F254
G1 X95.355 Y43.864 F254
G1 X95.371 Y43.842 F254
G1 X95.411 Y43.773 F254
G1 X95.579 Y43.424 F254
G1 X95.606 Y43.354 F254
G1 X95.613 Y43.319 F254
G1 X95.618 Y43.284 F254
G1 X95.619 Y43.214 F254
G1 X95.596 Y42.935 F254
G1 X95.584 Y42.796 F254
G1 X95.576 Y42.726 F254
G1 X95.564 Y42.675 F254
G1 X95.531 Y42.586 F254
G1 X95.497 Y42.491 F254
G1 X95.452 Y42.345 F254
G1 X95.418 Y42.197 F254
G1 X95.396 Y42.046 F254
G1 X95.385 Y41.894 F254
G1 X95.388 Y41.741 F254
G1 X95.404 Y41.59 F254
G1 X95.436 Y41.441 F254
G1 X95.484 Y41.296 F254
G1 X95.547 Y41.157 F254
G1 X95.623 Y41.026 F254
G1 X95.713 Y40.902 F254
G1 X95.814 Y40.788 F254
G1 X95.925 Y40.684 F254
G1 X96.046 Y40.591 F254
G1 X96.175 Y40.51 F254
G1 X96.312 Y40.443 F254
G1 X96.455 Y40.389 F254
G1 X96.601 Y40.348 F254
G1 X96.751 Y40.319 F254
G1 X96.915 Y40.299 F254
G1 X97.094 Y40.292 F254
G1 X97.294 Y40.297 F254
G1 X97.502 Y40.319 F254
G1 X97.72 Y40.358 F254
G1 X97.992 Y40.428 F254
G1 X98.203 Y40.499 F254
G1 X98.207 Y40.5 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X98.23 Y40.567 I-0.022 J0.045 F254
G3 X98.163 Y40.59 I-0.045 J-0.022 F254
G1 X98.146 Y40.582 Z-8.092 F254
G1 X98.131 Y40.574 Z-8.081 F254
G1 X98.122 Y40.57 Z-8.065 F254
G1 X98.118 Y40.568 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X97.062 Y43.068 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X97.058 Y43.07 Z-8.065 F254
G1 X97.049 Y43.075 Z-8.081 F254
G1 X97.035 Y43.083 Z-8.092 F254
G1 X97.018 Y43.092 Z-8.096 F254
G3 X95.531 Y42.586 I-0.509 J-0.944 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X95.355 Y42.155 F254
G1 X95.316 Y42.063 F254
G1 X95.305 Y42.046 F254
G1 X95.229 Y41.914 F254
G1 X95.209 Y41.763 F254
G1 X95.215 Y41.61 F254
G1 X95.238 Y41.46 F254
G1 X95.277 Y41.312 F254
G1 X95.33 Y41.17 F254
G1 X95.397 Y41.033 F254
G1 X95.476 Y40.903 F254
G1 X95.567 Y40.78 F254
G1 X95.668 Y40.665 F254
G1 X95.778 Y40.56 F254
G1 X95.896 Y40.464 F254
G1 X96.022 Y40.379 F254
G1 X96.156 Y40.305 F254
G1 X96.295 Y40.243 F254
G1 X96.439 Y40.193 F254
G1 X96.589 Y40.154 F254
G1 X96.654 Y40.142 F254
G1 X96.666 Y40.14 F254
G1 X96.679 F254
G1 X96.691 Y40.141 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X96.709 Y40.147 Z-8.045 F254
G1 X96.724 Y40.16 Z-7.994 F254
G1 X96.732 Y40.178 Z-7.944 F254
G1 X96.733 Y40.197 Z-7.893 F254
G3 X96.724 Y40.22 I-0.049 J-0.007 F254
G1 X96.403 Y40.658 F254
; MOVEMENT_LINK_DIRECT
G1 X95.712 Y41.602 F254
; MOVEMENT_LEAD_IN
G1 X95.386 Y42.046 F254
G3 X95.375 Y42.058 I-0.04 J-0.03 F254
G1 X95.357 Y42.066 Z-7.944 F254
G1 X95.337 Z-7.994 F254
G1 X95.319 Y42.059 Z-8.045 F254
G1 X95.305 Y42.046 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X95.248 Y41.958 F254
G1 X95.15 Y41.819 F254
G1 X95.069 Y41.69 F254
G1 X95.051 Y41.538 F254
G1 X95.067 Y41.387 F254
G1 X95.104 Y41.239 F254
G1 X95.156 Y41.096 F254
G1 X95.222 Y40.958 F254
G1 X95.298 Y40.827 F254
G1 X95.386 Y40.702 F254
G1 X95.482 Y40.584 F254
G1 X95.588 Y40.474 F254
G1 X95.701 Y40.372 F254
G1 X95.823 Y40.28 F254
G1 X95.951 Y40.198 F254
G1 X96.067 Y40.136 F254
G1 X96.087 Y40.128 F254
G1 X96.108 Y40.123 F254
G1 X96.13 Y40.121 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X96.149 Y40.127 Z-8.045 F254
G1 X96.164 Y40.138 Z-7.994 F254
G1 X96.174 Y40.155 Z-7.944 F254
G1 X96.176 Y40.175 Z-7.893 F254
G3 X96.17 Y40.196 I-0.05 J-0.003 F254
G1 X95.897 Y40.668 F254
; MOVEMENT_LINK_DIRECT
G1 X95.508 Y41.34 F254
; MOVEMENT_LEAD_IN
G1 X95.234 Y41.814 F254
G3 X95.22 Y41.829 I-0.043 J-0.025 F254
G1 X95.203 Y41.837 Z-7.944 F254
G1 X95.183 Y41.838 Z-7.994 F254
G1 X95.165 Y41.832 Z-8.045 F254
G1 X95.15 Y41.819 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.977 Y41.571 F254
G1 X94.936 Y41.507 F254
G1 X94.91 Y41.356 F254
G1 X94.928 Y41.205 F254
G1 X94.971 Y41.059 F254
G1 X95.03 Y40.918 F254
G1 X95.101 Y40.784 F254
G1 X95.183 Y40.655 F254
G1 X95.274 Y40.532 F254
G1 X95.375 Y40.416 F254
G1 X95.484 Y40.306 F254
G1 X95.601 Y40.206 F254
G1 X95.697 Y40.134 F254
G1 X95.721 Y40.12 F254
G1 X95.748 Y40.112 F254
G1 X95.776 Y40.11 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X95.795 Y40.115 Z-8.045 F254
G1 X95.81 Y40.127 Z-7.994 F254
G1 X95.82 Y40.144 Z-7.944 F254
G1 X95.822 Y40.163 Z-7.893 F254
G3 X95.816 Y40.184 I-0.05 J-0.003 F254
G1 X95.554 Y40.663 F254
; MOVEMENT_LINK_DIRECT
G1 X95.323 Y41.086 F254
; MOVEMENT_LEAD_IN
G1 X95.06 Y41.565 F254
G3 X95.047 Y41.581 I-0.044 J-0.024 F254
G1 X95.029 Y41.589 Z-7.944 F254
G1 X95.01 Y41.59 Z-7.994 F254
G1 X94.991 Y41.584 Z-8.045 F254
G1 X94.977 Y41.571 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.857 Y41.4 F254
G1 X94.816 Y41.336 F254
G1 X94.775 Y41.189 F254
G1 X94.794 Y41.037 F254
G1 X94.839 Y40.892 F254
G1 X94.902 Y40.753 F254
G1 X94.976 Y40.62 F254
G1 X95.062 Y40.492 F254
G1 X95.16 Y40.366 F254
G1 X95.27 Y40.244 F254
G1 X95.392 Y40.128 F254
G1 X95.417 Y40.112 F254
G1 X95.446 Y40.103 F254
G1 X95.475 Y40.1 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X95.494 Y40.105 Z-8.045 F254
G1 X95.51 Y40.117 Z-7.994 F254
G1 X95.519 Y40.134 Z-7.944 F254
G1 X95.522 Y40.153 Z-7.893 F254
G3 X95.517 Y40.171 I-0.05 J-0.003 F254
G1 X95.283 Y40.668 F254
; MOVEMENT_LINK_DIRECT
G1 X95.174 Y40.9 F254
; MOVEMENT_LEAD_IN
G1 X94.942 Y41.391 F254
G3 X94.927 Y41.41 I-0.045 J-0.021 F254
G1 X94.909 Y41.418 Z-7.944 F254
G1 X94.89 Y41.419 Z-7.994 F254
G1 X94.871 Y41.413 Z-8.045 F254
G1 X94.857 Y41.4 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.727 Y41.216 F254
G1 X94.686 Y41.152 F254
G1 X94.646 Y41.005 F254
G1 X94.668 Y40.854 F254
G1 X94.718 Y40.71 F254
G1 X94.785 Y40.573 F254
G1 X94.864 Y40.442 F254
G1 X94.956 Y40.312 F254
G1 X95.061 Y40.185 F254
G1 X95.113 Y40.13 F254
G1 X95.14 Y40.108 F254
G1 X95.173 Y40.095 F254
G1 X95.207 Y40.091 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X95.226 Y40.096 Z-8.045 F254
G1 X95.242 Y40.108 Z-7.994 F254
G1 X95.251 Y40.125 Z-7.944 F254
G1 X95.254 Y40.145 Z-7.893 F254
G3 X95.25 Y40.161 I-0.05 J-0.003 F254
G1 X95.037 Y40.669 F254
; MOVEMENT_LINK_DIRECT
G1 X95.022 Y40.705 F254
; MOVEMENT_LEAD_IN
G1 X94.813 Y41.205 F254
G3 X94.797 Y41.225 I-0.046 J-0.019 F254
G1 X94.78 Y41.234 Z-7.944 F254
G1 X94.76 Y41.235 Z-7.994 F254
G1 X94.742 Y41.229 Z-8.045 F254
G1 X94.727 Y41.216 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.588 Y41.023 F254
G1 X94.543 Y40.961 F254
G1 X94.519 Y40.811 F254
G1 X94.549 Y40.661 F254
G1 X94.605 Y40.519 F254
G1 X94.676 Y40.385 F254
G1 X94.762 Y40.252 F254
G1 X94.854 Y40.13 F254
G1 X94.879 Y40.109 F254
G1 X94.909 Y40.096 F254
G1 X94.941 Y40.091 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X94.96 Y40.094 Z-8.045 F254
G1 X94.976 Y40.105 Z-7.994 F254
G1 X94.987 Y40.121 Z-7.944 F254
G1 X94.991 Y40.141 Z-7.893 F254
G3 X94.988 Y40.158 I-0.05 F254
G1 X94.861 Y40.5 F254
; MOVEMENT_LEAD_IN
G1 X94.672 Y41.008 F254
G3 X94.658 Y41.029 I-0.047 J-0.017 F254
G1 X94.641 Y41.038 Z-7.944 F254
G1 X94.622 Y41.04 Z-7.994 F254
G1 X94.603 Y41.035 Z-8.045 F254
G1 X94.588 Y41.023 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.47 Y40.878 F254
G1 X94.425 Y40.817 F254
G1 X94.387 Y40.669 F254
G1 X94.414 Y40.519 F254
G1 X94.469 Y40.377 F254
G1 X94.541 Y40.242 F254
G1 X94.59 Y40.168 F254
G1 X94.613 Y40.141 F254
G1 X94.644 Y40.121 F254
G1 X94.679 Y40.112 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X94.698 Y40.114 Z-8.045 F254
G1 X94.716 Y40.123 Z-7.994 F254
G1 X94.728 Y40.139 Z-7.944 F254
G1 X94.733 Y40.157 Z-7.893 F254
G3 X94.732 Y40.174 I-0.05 J0.004 F254
G1 X94.69 Y40.337 F254
; MOVEMENT_LEAD_IN
G1 X94.556 Y40.858 F254
G3 X94.541 Y40.883 I-0.048 J-0.012 F254
G1 X94.524 Y40.893 Z-7.944 F254
G1 X94.505 Y40.895 Z-7.994 F254
G1 X94.486 Y40.89 Z-8.045 F254
G1 X94.47 Y40.878 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.35 Y40.73 F254
G1 X94.305 Y40.669 F254
G1 X94.257 Y40.524 F254
G1 X94.281 Y40.374 F254
G1 X94.336 Y40.232 F254
G1 X94.352 Y40.202 F254
G1 X94.377 Y40.172 F254
G1 X94.409 Y40.151 F254
G1 X94.446 Y40.14 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X94.465 Y40.142 Z-8.045 F254
G1 X94.482 Y40.152 Z-7.994 F254
G1 X94.494 Y40.167 Z-7.944 F254
G1 X94.5 Y40.186 Z-7.893 F254
; MOVEMENT_LEAD_IN
G3 Y40.196 I-0.05 J0.004 F254
G1 X94.437 Y40.704 F254
G3 X94.421 Y40.735 I-0.05 J-0.006 F254
G1 X94.404 Y40.745 Z-7.944 F254
G1 X94.384 Y40.747 Z-7.994 F254
G1 X94.366 Y40.742 Z-8.045 F254
G1 X94.35 Y40.73 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.213 Y40.563 F254
G1 X94.189 Y40.533 F254
G1 X94.169 Y40.508 F254
G1 X94.146 Y40.477 F254
G1 X94.131 Y40.326 F254
G1 X94.149 Y40.257 F254
G1 X94.17 Y40.212 F254
G1 X94.208 Y40.179 F254
G1 X94.255 Y40.164 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X94.274 Y40.166 Z-8.045 F254
G1 X94.291 Y40.175 Z-7.994 F254
G1 X94.303 Y40.19 Z-7.944 F254
G1 X94.309 Y40.209 Z-7.893 F254
G3 X94.308 Y40.223 I-0.05 J0.004 F254
G1 X94.256 Y40.485 F254
G3 X94.239 Y40.513 I-0.049 J-0.01 F254
G1 X94.222 Y40.522 Z-7.944 F254
G1 X94.203 Y40.525 Z-7.994 F254
G1 X94.184 Y40.52 Z-8.045 F254
G1 X94.169 Y40.508 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.071 Y40.388 F254
G1 X94.057 Y40.371 F254
G1 X94.048 Y40.353 F254
G1 X94.029 Y40.315 F254
G1 X94.038 Y40.265 F254
G1 X94.068 Y40.223 F254
G1 X94.112 Y40.198 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X94.138 Y40.195 Z-8.028 F254
G1 X94.164 Y40.198 Z-7.961 F254
G1 X94.188 Y40.207 Z-7.893 F254
G3 X94.236 Y40.263 I-0.049 J0.091 F254
G3 X94.109 Y40.399 I-0.099 J0.035 F254
G1 X94.085 Y40.389 Z-7.961 F254
G1 X94.064 Y40.374 Z-8.028 F254
G1 X94.048 Y40.353 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X94.019 Y40.302 F254
G1 X94.011 Y40.284 F254
G1 X94.009 Y40.27 F254
G1 X94.011 Y40.257 F254
G1 X94.017 Y40.244 F254
G1 X94.029 Y40.231 F254
G1 X94.046 Y40.221 F254
G1 X94.063 Y40.214 F254
G1 X94.204 Y40.17 F254
G1 X94.797 Y40.098 F254
G1 X94.867 Y40.093 F254
G1 X95.006 Y40.088 F254
G1 X95.076 Y40.087 F254
G1 X96.681 Y40.139 F254
G1 X96.751 Y40.148 F254
G1 X96.89 Y40.168 F254
G1 X97.03 Y40.191 F254
G1 X97.379 Y40.25 F254
G1 X97.448 Y40.266 F254
G1 X97.588 Y40.301 F254
G1 X97.658 Y40.32 F254
G1 X97.867 Y40.379 F254
G1 X98.076 Y40.445 F254
G1 X98.146 Y40.473 F254
G1 X98.984 Y40.851 F254
G1 X99.053 Y40.884 F254
G1 X99.123 Y40.92 F254
G1 X99.235 Y40.981 F254
G1 X99.985 Y41.4 F254
G1 X100.17 Y41.5 F254
G1 X100.25 Y41.54 F254
G1 X101.147 Y41.959 F254
G1 X101.356 Y42.054 F254
G1 X101.775 Y42.176 F254
G1 X101.844 Y42.195 F254
G1 X102.019 Y42.237 F254
G1 X102.054 Y42.245 F254
G1 X102.542 Y42.299 F254
G1 X102.612 Y42.306 F254
G1 X102.682 Y42.301 F254
G1 X102.752 Y42.295 F254
G1 X103.17 Y42.245 F254
G1 X103.21 Y42.237 F254
G1 X103.24 Y42.23 F254
G1 X103.31 Y42.203 F254
G1 X103.589 Y42.09 F254
G1 X103.659 Y42.06 F254
G1 X103.718 Y42.028 F254
G1 X103.728 Y42.021 F254
G1 X103.811 Y41.958 F254
G1 X103.938 Y41.855 F254
G1 X104.077 Y41.738 F254
G1 X104.093 Y41.723 F254
G1 X104.147 Y41.651 F254
G1 X104.308 Y41.4 F254
G1 X104.356 Y41.317 F254
G1 X104.382 Y41.26 F254
G1 X104.401 Y41.191 F254
G1 X104.466 Y40.912 F254
G1 X104.482 Y40.842 F254
G1 X104.491 Y40.772 F254
G1 X104.487 Y40.702 F254
G1 X104.465 Y40.493 F254
G1 X104.45 Y40.353 F254
G1 X104.44 Y40.284 F254
G1 X104.426 Y40.228 F254
G1 X104.421 Y40.214 F254
G1 X104.393 Y40.144 F254
G1 X104.271 Y39.865 F254
G1 X104.239 Y39.795 F254
G1 X104.217 Y39.756 F254
G1 X104.197 Y39.725 F254
G1 X103.938 Y39.387 F254
G1 X103.929 Y39.376 F254
G1 X103.868 Y39.315 F254
G1 X103.17 Y38.762 F254
G1 X103.15 Y38.748 F254
G1 X103.1 Y38.717 F254
G1 X102.821 Y38.578 F254
G1 X102.263 Y38.299 F254
G1 X102.193 Y38.274 F254
G1 X102.124 Y38.251 F254
G1 X101.914 Y38.186 F254
G1 X100.449 Y37.738 F254
G1 X100.379 Y37.718 F254
G1 X100.17 Y37.673 F254
G1 X98.286 Y37.326 F254
G1 X98.216 Y37.314 F254
G1 X94.588 Y36.821 F254
G1 X94.378 Y36.785 F254
G1 X92.773 Y36.478 F254
G1 X92.704 Y36.464 F254
G1 X91.785 Y36.236 F254
G1 X91.448 Y36.148 F254
G1 X90.889 Y35.999 F254
G1 X90.75 Y35.966 F254
G1 X90.61 Y35.934 F254
G1 X90.122 Y35.829 F254
G1 X89.982 Y35.8 F254
G1 X89.912 Y35.788 F254
G1 X89.284 Y35.731 F254
G1 X89.215 Y35.725 F254
G1 X89.005 Y35.714 F254
G1 X88.098 Y35.763 F254
G1 X87.959 Y35.781 F254
G1 X87.889 Y35.79 F254
G1 X87.819 Y35.8 F254
G1 X86.912 Y35.95 F254
G1 X86.703 Y35.987 F254
G1 X85.516 Y36.224 F254
G1 X85.307 Y36.259 F254
G1 X84.191 Y36.426 F254
G1 X84.121 Y36.435 F254
G1 X83.911 Y36.457 F254
G1 X83.772 Y36.463 F254
G1 X82.516 Y36.512 F254
G1 X82.376 Y36.51 F254
G1 X82.307 Y36.509 F254
G1 X82.237 Y36.506 F254
G1 X80.771 Y36.364 F254
G1 X80.632 Y36.35 F254
G1 X78.818 Y35.992 F254
G1 X78.12 Y35.855 F254
G1 X78.05 Y35.843 F254
G1 X77.841 Y35.813 F254
G1 X77.631 Y35.796 F254
G1 X77.492 Y35.791 F254
G1 X77.422 Y35.788 F254
G1 X77.352 Y35.789 F254
G1 X77.143 Y35.801 F254
G1 X77.073 Y35.808 F254
G1 X77.014 Y35.817 F254
G1 X76.515 Y35.936 F254
G1 X76.42 Y35.957 F254
G1 X75.817 Y36.078 F254
G1 X75.747 Y36.091 F254
G1 X75.538 Y36.11 F254
G1 X75.329 Y36.125 F254
G1 X75.259 Y36.128 F254
G1 X74.98 Y36.127 F254
G1 X74.84 Y36.126 F254
G1 X74.631 Y36.119 F254
G1 X74.561 Y36.115 F254
G1 X74.143 Y36.087 F254
G1 X73.933 Y36.07 F254
G1 X73.863 Y36.063 F254
G1 X73.166 Y35.986 F254
G1 X72.934 Y35.957 F254
G1 X71.002 Y35.683 F254
G1 X69.049 Y35.427 F254
G1 X68.979 Y35.419 F254
G1 X68.766 Y35.399 F254
G1 X68.072 Y35.342 F254
G1 X67.862 Y35.333 F254
G1 X67.165 Y35.322 F254
G1 X67.025 Y35.33 F254
G1 X66.955 Y35.334 F254
G1 X66.886 Y35.34 F254
G1 X66.397 Y35.387 F254
G1 X66.327 Y35.397 F254
G1 X66.258 Y35.415 F254
G1 X66.048 Y35.473 F254
G1 X65.769 Y35.552 F254
G1 X65.699 Y35.576 F254
G1 X65.638 Y35.608 F254
G1 X65.281 Y35.823 F254
G1 X65.211 Y35.87 F254
G1 X65.193 Y35.887 F254
G1 X65.129 Y35.957 F254
G1 X65.002 Y36.101 F254
G1 X64.932 Y36.184 F254
G1 X64.873 Y36.255 F254
G1 X64.862 Y36.274 F254
G1 X64.81 Y36.376 F254
G1 X64.675 Y36.655 F254
G1 X64.528 Y36.923 F254
G1 X64.438 Y37.062 F254
G1 X64.336 Y37.196 F254
G1 X64.224 Y37.322 F254
G1 X64.103 Y37.44 F254
G1 X63.972 Y37.55 F254
G1 X63.827 Y37.654 F254
G1 X63.665 Y37.754 F254
G1 X63.488 Y37.846 F254
G1 X63.3 Y37.926 F254
G1 X63.065 Y38.006 F254
G1 X62.8 Y38.075 F254
G1 X62.604 Y38.111 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X62.598 Y38.011 I-0.003 J-0.05 F254
G1 X62.617 Y38.01 Z-8.092 F254
G1 X62.633 Y38.009 Z-8.081 F254
G1 X62.644 Y38.008 Z-8.065 F254
G1 X62.648 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X65.185 Y33.506 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X65.186 Y33.51 Z-8.065 F254
G1 X65.187 Y33.52 Z-8.081 F254
G1 X65.188 Y33.537 Z-8.092 F254
G1 X65.19 Y33.556 Z-8.096 F254
G3 X64.675 Y36.655 I-6.307 J0.546 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X64.574 Y36.864 F254
G1 X64.469 Y37.073 F254
G1 X64.337 Y37.318 F254
G1 X64.304 Y37.359 F254
G1 X64.127 Y37.562 F254
G1 X64.094 Y37.598 F254
G1 X63.955 Y37.686 F254
G1 X63.676 Y37.858 F254
G1 X63.658 Y37.866 F254
G1 X62.926 Y38.078 F254
G1 X62.908 Y38.081 F254
G1 X62.071 Y38.165 F254
G1 X62.001 Y38.169 F254
G1 X61.792 Y38.172 F254
G1 X60.885 Y38.159 F254
G1 X60.815 Y38.154 F254
G1 X60.536 Y38.129 F254
G1 X59.698 Y38.049 F254
G1 X59.489 Y38.021 F254
G1 X58.303 Y37.833 F254
G1 X57.117 Y37.578 F254
G1 X56.977 Y37.545 F254
G1 X55.99 Y37.283 F254
G1 X55.721 Y37.203 F254
G1 X55.023 Y36.987 F254
G1 X54.814 Y36.919 F254
G1 X54.116 Y36.677 F254
G1 X53.558 Y36.467 F254
G1 X52.93 Y36.231 F254
G1 X52.721 Y36.155 F254
G1 X51.813 Y35.839 F254
G1 X51.744 Y35.817 F254
G1 X51.604 Y35.774 F254
G1 X51.534 Y35.755 F254
G1 X50.278 Y35.464 F254
G1 X50.209 Y35.45 F254
G1 X49.511 Y35.363 F254
G1 X49.441 Y35.355 F254
G1 X49.232 Y35.338 F254
G1 X48.604 Y35.303 F254
G1 X48.534 Y35.3 F254
G1 X48.325 Y35.298 F254
G1 X46.441 Y35.366 F254
G1 X46.231 Y35.378 F254
G1 X44.626 Y35.636 F254
G1 X44.387 Y35.678 F254
G1 X44.347 Y35.687 F254
G1 X42.952 Y36.051 F254
G1 X42.672 Y36.126 F254
G1 X41.626 Y36.413 F254
G1 X41.499 Y36.445 F254
G1 X41.347 Y36.483 F254
G1 X40.23 Y36.688 F254
G1 X40.16 Y36.699 F254
G1 X39.951 Y36.724 F254
G1 X39.044 Y36.765 F254
G1 X38.974 F254
G1 X38.765 Y36.758 F254
G1 X38.067 Y36.7 F254
G1 X37.858 Y36.675 F254
G1 X37.718 Y36.651 F254
G1 X36.253 Y36.389 F254
G1 X36.171 Y36.376 F254
G1 X35.974 Y36.347 F254
G1 X35.346 Y36.271 F254
G1 X35.276 Y36.264 F254
G1 X35.067 Y36.26 F254
G1 X34.369 Y36.278 F254
G1 X34.299 Y36.284 F254
G1 X34.229 Y36.297 F254
G1 X33.462 Y36.465 F254
G1 X33.392 Y36.485 F254
G1 X33.252 Y36.528 F254
G1 X33.183 Y36.552 F254
G1 X32.415 Y36.845 F254
G1 X31.043 Y37.422 F254
G1 X30.754 Y37.527 F254
G1 X30.576 Y37.585 F254
G1 X30.359 Y37.639 F254
G1 X30.127 Y37.678 F254
G1 X29.888 Y37.701 F254
G1 X29.638 Y37.706 F254
G1 X29.37 Y37.692 F254
G1 X29.073 Y37.654 F254
G1 X28.837 Y37.605 F254
G1 X28.833 Y37.604 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X28.816 Y37.594 Z-8.045 F254
G1 X28.805 Y37.579 Z-7.994 F254
G1 X28.8 Y37.56 Z-7.944 F254
G1 X28.803 Y37.54 Z-7.893 F254
G3 X28.846 Y37.507 I0.047 J0.017 F254
G1 X29.354 Y37.465 F254
; MOVEMENT_LINK_DIRECT
G1 X30.513 Y37.369 F254
; MOVEMENT_LEAD_IN
G1 X31.018 Y37.327 F254
G3 X31.067 Y37.356 I0.004 J0.05 F254
G1 X31.072 Y37.375 Z-7.944 F254
G1 X31.069 Y37.394 Z-7.994 F254
G1 X31.059 Y37.411 Z-8.045 F254
G1 X31.043 Y37.422 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X30.671 Y37.579 F254
G1 X30.531 Y37.608 F254
G1 X29.851 Y37.745 F254
G1 X29.833 Y37.746 F254
G1 X29.136 Y37.691 F254
G1 X29.101 Y37.687 F254
G1 X29.066 Y37.678 F254
G1 X28.438 Y37.479 F254
G1 X28.298 Y37.434 F254
G1 X27.6 Y37.184 F254
G1 X27.391 Y37.114 F254
G1 X27.321 Y37.095 F254
G1 X26.484 Y36.893 F254
G1 X26.414 Y36.879 F254
G1 X26.205 Y36.851 F254
G1 X25.577 Y36.786 F254
G1 X25.507 Y36.781 F254
G1 X25.298 Y36.79 F254
G1 X24.181 Y36.866 F254
G1 X24.111 Y36.872 F254
G1 X24.042 Y36.886 F254
G1 X23.89 Y36.934 F254
G1 X23.46 Y37.073 F254
G1 X23.414 Y37.093 F254
G1 X23.344 Y37.135 F254
G1 X23.204 Y37.227 F254
G1 X23.122 Y37.283 F254
G1 X23.065 Y37.329 F254
G1 X23.04 Y37.353 F254
G1 X22.988 Y37.422 F254
G1 X22.839 Y37.632 F254
G1 X22.791 Y37.7 F254
G1 X22.698 Y37.821 F254
G1 X22.596 Y37.934 F254
G1 X22.486 Y38.04 F254
G1 X22.368 Y38.136 F254
G1 X22.243 Y38.223 F254
G1 X22.111 Y38.3 F254
G1 X21.974 Y38.365 F254
G1 X21.831 Y38.42 F254
G1 X21.685 Y38.463 F254
G1 X21.529 Y38.496 F254
G1 X21.35 Y38.521 F254
G1 X21.134 Y38.535 F254
G1 X20.877 Y38.533 F254
G1 X20.659 Y38.514 F254
G1 X20.654 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X20.636 Y38.505 Z-8.045 F254
G1 X20.623 Y38.491 Z-7.994 F254
G1 X20.616 Y38.473 Z-7.944 F254
G1 X20.617 Y38.453 Z-7.893 F254
G3 X20.626 Y38.434 I0.049 J0.012 F254
G1 X20.959 Y38.001 F254
; MOVEMENT_LINK_DIRECT
G1 X22.401 Y36.127 F254
G2 X22.322 Y36.066 I-0.04 J-0.03 F254
G2 X22.341 Y36.142 I0.04 J0.03 F254
G3 X22.874 Y37.562 I-0.443 J0.976 F254
; MOVEMENT_LEAD_IN
G1 X22.839 Y37.632 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X22.819 Y37.667 F254
G1 X22.801 Y37.702 F254
G1 X22.786 Y37.741 F254
G1 X22.778 Y37.771 F254
G1 X22.767 Y37.841 F254
G1 X22.763 Y37.879 F254
G1 X22.752 Y37.955 F254
G1 X22.679 Y38.089 F254
G1 X22.577 Y38.202 F254
G1 X22.461 Y38.301 F254
G1 X22.337 Y38.389 F254
G1 X22.205 Y38.466 F254
G1 X22.068 Y38.533 F254
G1 X21.923 Y38.591 F254
G1 X21.767 Y38.64 F254
G1 X21.595 Y38.681 F254
G1 X21.481 Y38.699 F254
G1 X21.464 Y38.701 F254
G1 X21.446 Y38.7 F254
G1 X21.429 Y38.697 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X21.412 Y38.688 Z-8.045 F254
G1 X21.4 Y38.673 Z-7.994 F254
G1 X21.394 Y38.654 Z-7.944 F254
G1 X21.396 Y38.635 Z-7.893 F254
G3 X21.418 Y38.606 I0.048 J0.014 F254
G1 X21.871 Y38.33 F254
; MOVEMENT_LINK_DIRECT
G1 X22.229 Y38.113 F254
; MOVEMENT_LEAD_IN
G1 X22.687 Y37.834 F254
G3 X22.716 Y37.826 I0.026 J0.043 F254
G1 X22.735 Y37.831 Z-7.944 F254
G1 X22.751 Y37.843 Z-7.994 F254
G1 X22.761 Y37.86 Z-8.045 F254
G1 X22.763 Y37.879 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X22.753 Y37.981 F254
G1 X22.742 Y38.12 F254
G1 X22.733 Y38.196 F254
G1 X22.669 Y38.334 F254
G1 X22.565 Y38.446 F254
G1 X22.445 Y38.54 F254
G1 X22.316 Y38.621 F254
G1 X22.179 Y38.693 F254
G1 X22.028 Y38.757 F254
G1 X21.905 Y38.8 F254
G1 X21.882 Y38.805 F254
G1 X21.857 Y38.806 F254
G1 X21.833 Y38.802 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X21.816 Y38.793 Z-8.045 F254
G1 X21.804 Y38.778 Z-7.994 F254
G1 X21.798 Y38.76 Z-7.944 F254
G1 X21.8 Y38.74 Z-7.893 F254
G3 X21.817 Y38.714 I0.048 J0.014 F254
G1 X22.237 Y38.399 F254
; MOVEMENT_LEAD_IN
G1 X22.662 Y38.078 F254
G3 X22.695 Y38.068 I0.03 J0.04 F254
G1 X22.714 Y38.073 Z-7.944 F254
G1 X22.729 Y38.084 Z-7.994 F254
G1 X22.74 Y38.101 Z-8.045 F254
G1 X22.742 Y38.12 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X22.737 Y38.19 F254
G1 X22.74 Y38.225 F254
G1 X22.746 Y38.26 F254
G1 X22.758 Y38.298 F254
G1 X22.767 Y38.335 F254
G1 X22.736 Y38.485 F254
G1 X22.644 Y38.606 F254
G1 X22.528 Y38.705 F254
G1 X22.401 Y38.789 F254
G1 X22.267 Y38.862 F254
G1 X22.231 Y38.878 F254
G1 X22.205 Y38.886 F254
G1 X22.177 Y38.889 F254
G1 X22.149 Y38.885 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X22.131 Y38.875 Z-8.045 F254
G1 X22.119 Y38.86 Z-7.994 F254
G1 X22.113 Y38.842 Z-7.944 F254
G1 X22.115 Y38.822 Z-7.893 F254
G3 X22.128 Y38.8 I0.048 J0.014 F254
G1 X22.281 Y38.655 F254
; MOVEMENT_LEAD_IN
G1 X22.676 Y38.278 F254
G3 X22.694 Y38.267 I0.035 J0.036 F254
G1 X22.714 Y38.264 Z-7.944 F254
G1 X22.732 Y38.269 Z-7.994 F254
G1 X22.748 Y38.281 Z-8.045 F254
G1 X22.758 Y38.298 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X22.767 Y38.33 F254
G1 X22.804 Y38.438 F254
G1 X22.825 Y38.511 F254
G1 X22.798 Y38.661 F254
G1 X22.708 Y38.783 F254
G1 X22.593 Y38.884 F254
G1 X22.512 Y38.939 F254
G1 X22.478 Y38.955 F254
G1 X22.442 Y38.96 F254
G1 X22.406 Y38.955 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X22.389 Y38.945 Z-8.045 F254
G1 X22.377 Y38.93 Z-7.994 F254
G1 X22.372 Y38.911 Z-7.944 F254
G1 X22.374 Y38.891 Z-7.893 F254
G3 X22.382 Y38.878 I0.047 J0.016 F254
G1 X22.395 Y38.859 F254
; MOVEMENT_LEAD_IN
G1 X22.717 Y38.426 F254
G3 X22.739 Y38.409 I0.04 J0.03 F254
G1 X22.758 Y38.406 Z-7.944 F254
G1 X22.777 Y38.41 Z-7.994 F254
G1 X22.793 Y38.421 Z-8.045 F254
G1 X22.804 Y38.438 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X22.863 Y38.609 F254
G1 X22.888 Y38.681 F254
G1 X22.866 Y38.831 F254
G1 X22.778 Y38.956 F254
G1 X22.736 Y38.993 F254
G1 X22.7 Y39.015 F254
G1 X22.658 Y39.024 F254
G1 X22.616 Y39.019 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X22.6 Y39.009 Z-8.045 F254
G1 X22.588 Y38.994 Z-7.994 F254
G1 X22.583 Y38.975 Z-7.944 F254
G1 X22.585 Y38.956 Z-7.893 F254
; MOVEMENT_LEAD_IN
G1 X22.589 Y38.948 F254
G1 X22.774 Y38.606 F254
G3 X22.797 Y38.584 I0.044 J0.024 F254
G1 X22.816 Y38.58 Z-7.944 F254
G1 X22.835 Y38.583 Z-7.994 F254
G1 X22.852 Y38.593 Z-8.045 F254
G1 X22.863 Y38.609 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X22.893 Y38.679 F254
G1 X22.908 Y38.704 F254
G1 X22.925 Y38.73 F254
G1 X22.946 Y38.762 F254
G1 X22.964 Y38.836 F254
G1 X22.946 Y38.988 F254
G1 X22.919 Y39.024 F254
G1 X22.881 Y39.058 F254
G1 X22.833 Y39.074 F254
G1 X22.782 Y39.069 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X22.765 Y39.06 Z-8.045 F254
G1 X22.753 Y39.044 Z-7.994 F254
G1 X22.748 Y39.025 Z-7.944 F254
G1 X22.751 Y39.006 Z-7.893 F254
G1 X22.841 Y38.747 F254
G3 X22.855 Y38.726 I0.047 J0.016 F254
G1 X22.871 Y38.716 Z-7.944 F254
G1 X22.891 Y38.714 Z-7.994 F254
G1 X22.91 Y38.719 Z-8.045 F254
G1 X22.925 Y38.73 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X22.998 Y38.818 F254
G1 X23.031 Y38.856 F254
G1 X23.057 Y38.888 F254
G1 X23.08 Y38.918 F254
G1 X23.076 Y38.994 F254
G1 X23.063 Y39.031 F254
G1 X23.027 Y39.082 F254
G1 X22.971 Y39.111 F254
G1 X22.909 Y39.108 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X22.892 Y39.098 Z-8.045 F254
G1 X22.88 Y39.083 Z-7.994 F254
G1 X22.875 Y39.064 Z-7.944 F254
G1 X22.878 Y39.045 Z-7.893 F254
G3 X22.884 Y39.032 I0.047 J0.016 F254
G1 X22.979 Y38.893 F254
G3 X22.986 Y38.884 I0.041 J0.028 F254
G1 X23.003 Y38.874 Z-7.944 F254
G1 X23.023 Y38.871 Z-7.994 F254
G1 X23.041 Y38.876 Z-8.045 F254
G1 X23.057 Y38.888 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X23.116 Y38.958 F254
G1 X23.135 Y38.98 F254
G1 X23.157 Y39.006 F254
G1 X23.18 Y39.036 F254
G1 X23.174 Y39.055 F254
G1 X23.14 Y39.112 F254
G1 X23.083 Y39.143 F254
G1 X23.017 Y39.141 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X23.002 Y39.133 Z-8.051 F254
G1 X22.99 Y39.12 Z-8.006 F254
G1 X22.982 Y39.105 Z-7.961 F254
G1 X22.978 Y39.079 Z-7.893 F254
G3 X23.088 Y38.972 I0.103 J-0.004 F254
G1 X23.113 Y38.978 Z-7.961 F254
G1 X23.137 Y38.989 Z-8.028 F254
G1 X23.157 Y39.006 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X23.204 Y39.062 F254
G1 X23.234 Y39.097 F254
G1 X23.246 Y39.115 F254
G1 X23.249 Y39.141 F254
G1 Y39.148 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G3 X23.205 Y39.183 I-0.037 J-0.002 F254
G3 X23.176 Y39.134 I0.007 J-0.037 F254
G1 X23.18 Y39.124 F254
G3 X23.246 Y39.115 I0.035 J0.012 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X23.249 Y39.132 F254
G1 Y39.15 F254
G1 X23.244 Y39.167 F254
G1 X23.237 Y39.177 F254
G1 X23.224 Y39.188 F254
G1 X23.204 Y39.194 F254
G1 X23.187 Y39.193 F254
G1 X22.367 Y38.943 F254
G1 X22.227 Y38.905 F254
G1 X21.09 Y38.609 F254
G1 X20.902 Y38.565 F254
G1 X20.762 Y38.536 F254
G1 X19.715 Y38.322 F254
G1 X19.436 Y38.274 F254
G1 X18.529 Y38.134 F254
G1 X18.25 Y38.1 F254
G1 X18.111 Y38.084 F254
G1 X18.041 Y38.078 F254
G1 X17.901 Y38.068 F254
G1 X17.831 Y38.064 F254
G1 X17.622 Y38.061 F254
G1 X17.203 Y38.105 F254
G1 X17.134 Y38.115 F254
G1 X17.11 Y38.12 F254
G1 X17.064 Y38.136 F254
G1 X17.029 Y38.153 F254
G1 X16.994 Y38.173 F254
G1 X16.97 Y38.19 F254
G1 X16.924 Y38.225 F254
G1 X16.625 Y38.469 F254
G1 X16.575 Y38.518 F254
G1 X16.558 Y38.539 F254
G1 X16.535 Y38.574 F254
G1 X16.516 Y38.609 F254
G1 X16.506 Y38.631 F254
G1 X16.497 Y38.655 F254
G1 X16.49 Y38.679 F254
G1 X16.452 Y38.9 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X16.354 Y38.88 I-0.049 J-0.01 F254
G1 X16.357 Y38.861 Z-8.092 F254
G1 X16.361 Y38.846 Z-8.081 F254
G1 X16.363 Y38.835 Z-8.065 F254
G1 Y38.831 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X43.04 Y49.87 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X43.036 Y49.871 Z-8.065 F254
G1 X43.026 Y49.872 Z-8.081 F254
G1 X43.009 Y49.873 Z-8.092 F254
G1 X42.99 Y49.875 Z-8.096 F254
G3 X41.681 Y49.006 I-0.117 J-1.245 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.662 Y48.937 F254
G1 X41.62 Y48.797 F254
G1 X41.565 Y48.62 F254
G1 X41.528 Y48.473 F254
G1 X41.541 Y48.321 F254
G1 X41.577 Y48.173 F254
G1 X41.63 Y48.03 F254
G1 X41.698 Y47.893 F254
G1 X41.778 Y47.764 F254
G1 X41.87 Y47.642 F254
G1 X41.974 Y47.531 F254
G1 X42.087 Y47.429 F254
G1 X42.21 Y47.338 F254
G1 X42.34 Y47.259 F254
G1 X42.477 Y47.192 F254
G1 X42.619 Y47.137 F254
G1 X42.766 Y47.096 F254
G1 X42.915 Y47.067 F254
G1 X43.067 Y47.05 F254
G1 X43.224 Y47.045 F254
G1 X43.396 Y47.053 F254
G1 X43.562 Y47.072 F254
G1 X43.583 Y47.076 F254
G1 X43.602 Y47.084 F254
G1 X43.62 Y47.094 F254
G1 X43.789 Y47.213 F254
G1 X43.868 Y47.262 F254
G1 X43.929 Y47.297 F254
G1 X44.29 Y47.492 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X44.287 Y47.58 I-0.025 J0.043 F254
G1 X44.276 Y47.582 Z-8.095 F254
G1 X44.265 Y47.585 Z-8.09 F254
G1 X44.251 Y47.581 Z-8.079 F254
G1 X44.242 Y47.579 Z-8.064 F254
G1 X44.239 Y47.578 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X43.117 Y49.01 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X43.114 Y49.012 Z-8.065 F254
G1 X43.106 Y49.019 Z-8.081 F254
G1 X43.093 Y49.029 Z-8.092 F254
G1 X43.079 Y49.041 Z-8.096 F254
G3 X41.565 Y48.62 I-0.611 J-0.735 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.469 Y48.309 F254
G1 X41.432 Y48.161 F254
G1 X41.452 Y48.01 F254
G1 X41.504 Y47.867 F254
G1 X41.574 Y47.731 F254
G1 X41.658 Y47.604 F254
G1 X41.754 Y47.485 F254
G1 X41.859 Y47.376 F254
G1 X41.974 Y47.275 F254
G1 X42.096 Y47.184 F254
G1 X42.226 Y47.104 F254
G1 X42.361 Y47.034 F254
G1 X42.502 Y46.976 F254
G1 X42.647 Y46.929 F254
G1 X42.795 Y46.893 F254
G1 X42.946 Y46.868 F254
G1 X43.106 Y46.855 F254
G1 X43.237 Y46.853 F254
G1 X43.263 Y46.855 F254
G1 X43.287 Y46.863 F254
G1 X43.31 Y46.876 F254
G1 X43.62 Y47.094 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X43.559 Y47.174 I-0.03 J0.04 F254
G1 X43.544 Y47.162 Z-8.092 F254
G1 X43.531 Y47.152 Z-8.081 F254
G1 X43.523 Y47.146 Z-8.065 F254
G1 X43.52 Y47.143 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X43.242 Y50.961 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X43.239 Y50.958 Z-8.065 F254
G1 X43.231 Y50.951 Z-8.081 F254
G1 X43.219 Y50.94 Z-8.092 F254
G1 X43.204 Y50.927 Z-8.096 F254
G3 X41.469 Y48.309 I4.244 J-4.697 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.426 Y48.169 F254
G1 X41.416 Y48.144 F254
G1 X41.396 Y48.099 F254
G1 X41.374 Y48.061 F254
G1 X41.34 Y47.993 F254
G1 X41.341 Y47.84 F254
G1 X41.39 Y47.696 F254
G1 X41.462 Y47.561 F254
G1 X41.548 Y47.436 F254
G1 X41.646 Y47.319 F254
G1 X41.754 Y47.212 F254
G1 X41.87 Y47.113 F254
G1 X41.993 Y47.023 F254
G1 X42.123 Y46.942 F254
G1 X42.259 Y46.871 F254
G1 X42.403 Y46.809 F254
G1 X42.552 Y46.756 F254
G1 X42.707 Y46.715 F254
G1 X42.87 Y46.684 F254
G1 X42.983 Y46.671 F254
G1 X43.017 Y46.672 F254
G1 X43.049 Y46.681 F254
G1 X43.077 Y46.699 F254
G1 X43.169 Y46.773 F254
G1 X43.231 Y46.82 F254
G1 X43.31 Y46.876 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X43.323 Y46.89 Z-8.045 F254
G1 X43.33 Y46.909 Z-7.994 F254
G1 X43.328 Y46.928 Z-7.944 F254
G1 X43.32 Y46.946 Z-7.893 F254
G3 X43.306 Y46.959 I-0.04 J-0.03 F254
G1 X42.836 Y47.241 F254
; MOVEMENT_LINK_DIRECT
G1 X41.929 Y47.785 F254
; MOVEMENT_LEAD_IN
G1 X41.443 Y48.078 F254
G1 X41.424 Y48.084 Z-7.944 F254
G1 X41.405 Y48.083 Z-7.995 F254
G1 X41.387 Y48.075 Z-8.045 F254
G1 X41.374 Y48.061 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.278 Y47.89 F254
G1 X41.244 Y47.822 F254
G1 X41.233 Y47.67 F254
G1 X41.28 Y47.525 F254
G1 X41.352 Y47.391 F254
G1 X41.441 Y47.267 F254
G1 X41.541 Y47.152 F254
G1 X41.651 Y47.046 F254
G1 X41.773 Y46.944 F254
G1 X41.905 Y46.849 F254
G1 X42.047 Y46.763 F254
G1 X42.197 Y46.686 F254
G1 X42.354 Y46.62 F254
G1 X42.517 Y46.565 F254
G1 X42.688 Y46.521 F254
G1 X42.774 Y46.505 F254
G1 X42.81 Y46.504 F254
G1 X42.845 Y46.513 F254
G1 X42.876 Y46.532 F254
G1 X43.077 Y46.699 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X43.089 Y46.715 Z-8.045 F254
G1 X43.094 Y46.734 Z-7.994 F254
G1 X43.091 Y46.753 Z-7.944 F254
G1 X43.082 Y46.77 Z-7.893 F254
G3 X43.072 Y46.778 I-0.037 J-0.033 F254
G1 X42.608 Y47.082 F254
; MOVEMENT_LINK_DIRECT
G1 X41.822 Y47.596 F254
; MOVEMENT_LEAD_IN
G1 X41.348 Y47.906 F254
G1 X41.347 Y47.907 F254
G1 X41.328 Y47.913 Z-7.944 F254
G1 X41.309 Y47.912 Z-7.994 F254
G1 X41.291 Y47.904 Z-8.045 F254
G1 X41.278 Y47.89 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.178 Y47.712 F254
G1 X41.144 Y47.644 F254
G1 X41.128 Y47.492 F254
G1 X41.175 Y47.347 F254
G1 X41.25 Y47.215 F254
G1 X41.341 Y47.092 F254
G1 X41.443 Y46.979 F254
G1 X41.557 Y46.872 F254
G1 X41.688 Y46.766 F254
G1 X41.832 Y46.666 F254
G1 X41.987 Y46.575 F254
G1 X42.15 Y46.494 F254
G1 X42.321 Y46.425 F254
G1 X42.498 Y46.368 F254
G1 X42.577 Y46.349 F254
G1 X42.616 Y46.346 F254
G1 X42.653 Y46.354 F254
G1 X42.686 Y46.374 F254
G1 X42.876 Y46.532 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.888 Y46.548 Z-8.045 F254
G1 X42.893 Y46.566 Z-7.994 F254
G1 X42.89 Y46.586 Z-7.944 F254
G1 X42.88 Y46.603 Z-7.893 F254
G3 X42.871 Y46.611 I-0.037 J-0.033 F254
G1 X42.414 Y46.925 F254
; MOVEMENT_LINK_DIRECT
G1 X41.714 Y47.407 F254
; MOVEMENT_LEAD_IN
G1 X41.249 Y47.727 F254
G1 X41.247 Y47.729 F254
G1 X41.228 Y47.735 Z-7.944 F254
G1 X41.209 Y47.734 Z-7.994 F254
G1 X41.191 Y47.726 Z-8.045 F254
G1 X41.178 Y47.712 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.068 Y47.516 F254
G1 X41.032 Y47.449 F254
G1 X41.029 Y47.296 F254
G1 X41.082 Y47.153 F254
G1 X41.161 Y47.023 F254
G1 X41.255 Y46.903 F254
G1 X41.36 Y46.793 F254
G1 X41.479 Y46.685 F254
G1 X41.619 Y46.576 F254
G1 X41.775 Y46.473 F254
G1 X41.942 Y46.378 F254
G1 X42.12 Y46.295 F254
G1 X42.3 Y46.226 F254
G1 X42.391 Y46.198 F254
G1 X42.434 Y46.193 F254
G1 X42.477 Y46.204 F254
G1 X42.513 Y46.228 F254
G1 X42.533 Y46.247 F254
G1 X42.686 Y46.374 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.698 Y46.39 Z-8.045 F254
G1 X42.703 Y46.409 Z-7.994 F254
G1 X42.7 Y46.428 Z-7.944 F254
G1 X42.69 Y46.445 Z-7.893 F254
G3 X42.682 Y46.453 I-0.037 J-0.033 F254
G1 X42.226 Y46.771 F254
; MOVEMENT_LINK_DIRECT
G1 X41.602 Y47.206 F254
; MOVEMENT_LEAD_IN
G1 X41.138 Y47.53 F254
G1 X41.137 Y47.531 F254
G1 X41.118 Y47.538 Z-7.944 F254
G1 X41.099 Z-7.994 F254
G1 X41.081 Y47.53 Z-8.045 F254
G1 X41.068 Y47.516 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.976 Y47.362 F254
G1 X40.94 Y47.295 F254
G1 X40.92 Y47.144 F254
G1 X40.969 Y46.999 F254
G1 X41.046 Y46.868 F254
G1 X41.141 Y46.748 F254
G1 X41.246 Y46.638 F254
G1 X41.372 Y46.524 F254
G1 X41.519 Y46.41 F254
G1 X41.682 Y46.301 F254
G1 X41.859 Y46.201 F254
G1 X42.045 Y46.114 F254
G1 X42.187 Y46.059 F254
G1 X42.237 Y46.046 F254
G1 X42.279 Y46.042 F254
G1 X42.32 Y46.053 F254
G1 X42.356 Y46.077 F254
G1 X42.513 Y46.228 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.524 Y46.244 Z-8.045 F254
G1 X42.528 Y46.263 Z-7.994 F254
G1 X42.523 Y46.282 Z-7.944 F254
G1 X42.512 Y46.299 Z-7.893 F254
G1 X42.507 Y46.303 F254
G1 X42.055 Y46.635 F254
; MOVEMENT_LINK_DIRECT
G1 X41.502 Y47.041 F254
; MOVEMENT_LEAD_IN
G1 X41.047 Y47.375 F254
G1 X41.045 Y47.377 F254
G1 X41.027 Y47.384 Z-7.944 F254
G1 X41.007 Z-7.994 F254
G1 X40.989 Y47.376 Z-8.045 F254
G1 X40.976 Y47.362 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.928 Y47.284 F254
G1 X40.86 Y47.192 F254
G1 X40.839 Y47.16 F254
G1 X40.804 Y47.012 F254
G1 X40.846 Y46.865 F254
G1 X40.92 Y46.732 F254
G1 X41.012 Y46.611 F254
G1 X41.116 Y46.499 F254
G1 X41.242 Y46.381 F254
G1 X41.391 Y46.262 F254
G1 X41.558 Y46.147 F254
G1 X41.74 Y46.041 F254
G1 X41.908 Y45.959 F254
G1 X42.05 Y45.902 F254
G1 X42.086 Y45.894 F254
G1 X42.128 Y45.891 F254
G1 X42.169 Y45.902 F254
G1 X42.204 Y45.927 F254
G1 X42.356 Y46.077 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.366 Y46.093 Z-8.045 F254
G1 X42.37 Y46.112 Z-7.994 F254
G1 X42.366 Y46.131 Z-7.944 F254
G1 X42.355 Y46.147 Z-7.893 F254
G1 X42.349 Y46.152 F254
G1 X41.898 Y46.485 F254
; MOVEMENT_LINK_DIRECT
G1 X41.387 Y46.863 F254
; MOVEMENT_LEAD_IN
G1 X40.93 Y47.2 F254
G1 X40.929 Y47.201 Z-7.898 F254
G1 X40.912 Y47.209 Z-7.947 F254
G1 X40.893 Y47.21 Z-7.997 F254
G1 X40.875 Y47.204 Z-8.046 F254
G1 X40.86 Y47.192 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.756 Y47.052 F254
G1 X40.714 Y46.989 F254
G1 X40.693 Y46.838 F254
G1 X40.74 Y46.693 F254
G1 X40.817 Y46.561 F254
G1 X40.91 Y46.441 F254
G1 X41.015 Y46.33 F254
G1 X41.148 Y46.208 F254
G1 X41.304 Y46.084 F254
G1 X41.48 Y45.965 F254
G1 X41.66 Y45.862 F254
G1 X41.805 Y45.793 F254
G1 X41.918 Y45.748 F254
G1 X41.965 Y45.74 F254
G1 X42.012 Y45.749 F254
G1 X42.052 Y45.776 F254
G1 X42.204 Y45.927 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.214 Y45.943 Z-8.045 F254
G1 X42.217 Y45.962 Z-7.994 F254
G1 X42.213 Y45.981 Z-7.944 F254
G1 X42.201 Y45.997 Z-7.893 F254
G1 X42.198 Y46 F254
G1 X41.753 Y46.344 F254
; MOVEMENT_LINK_DIRECT
G1 X41.276 Y46.713 F254
; MOVEMENT_LEAD_IN
G1 X40.827 Y47.06 F254
G1 X40.826 Y47.061 Z-7.895 F254
G1 X40.809 Y47.069 Z-7.945 F254
G1 X40.789 Y47.071 Z-7.995 F254
G1 X40.771 Y47.065 Z-8.046 F254
G1 X40.756 Y47.052 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.649 Y46.908 F254
G1 X40.607 Y46.844 F254
G1 X40.578 Y46.695 F254
G1 X40.621 Y46.549 F254
G1 X40.696 Y46.416 F254
G1 X40.789 Y46.295 F254
G1 X40.895 Y46.18 F254
G1 X41.03 Y46.054 F254
G1 X41.19 Y45.926 F254
G1 X41.365 Y45.806 F254
G1 X41.533 Y45.707 F254
G1 X41.67 Y45.64 F254
G1 X41.77 Y45.601 F254
G1 X41.817 Y45.593 F254
G1 X41.864 Y45.602 F254
G1 X41.903 Y45.629 F254
G1 X42.052 Y45.776 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.062 Y45.792 Z-8.045 F254
G1 X42.065 Y45.812 Z-7.994 F254
G1 X42.061 Y45.831 Z-7.944 F254
G1 X42.049 Y45.846 Z-7.893 F254
G1 X42.046 Y45.849 F254
G1 X41.607 Y46.202 F254
; MOVEMENT_LINK_DIRECT
G1 X41.162 Y46.56 F254
; MOVEMENT_LEAD_IN
G1 X40.719 Y46.916 F254
G1 X40.702 Y46.925 Z-7.944 F254
G1 X40.682 Y46.926 Z-7.994 F254
G1 X40.664 Y46.92 Z-8.045 F254
G1 X40.649 Y46.908 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.527 Y46.744 F254
G1 X40.485 Y46.681 F254
G1 X40.464 Y46.53 F254
G1 X40.511 Y46.385 F254
G1 X40.587 Y46.253 F254
G1 X40.68 Y46.132 F254
G1 X40.791 Y46.014 F254
G1 X40.931 Y45.884 F254
G1 X41.094 Y45.753 F254
G1 X41.267 Y45.635 F254
G1 X41.426 Y45.543 F254
G1 X41.563 Y45.477 F254
G1 X41.632 Y45.453 F254
G1 X41.68 Y45.446 F254
G1 X41.726 Y45.458 F254
G1 X41.764 Y45.486 F254
G1 X41.835 Y45.561 F254
G1 X41.903 Y45.629 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.914 Y45.645 Z-8.045 F254
G1 X41.917 Y45.665 Z-7.994 F254
G1 X41.912 Y45.684 Z-7.944 F254
G1 X41.901 Y45.7 Z-7.893 F254
G1 X41.898 Y45.702 F254
G1 X41.46 Y46.056 F254
; MOVEMENT_LINK_DIRECT
G1 X41.039 Y46.395 F254
; MOVEMENT_LEAD_IN
G1 X40.598 Y46.752 F254
G1 X40.597 F254
G1 X40.58 Y46.761 Z-7.944 F254
G1 X40.561 Y46.762 Z-7.994 F254
G1 X40.542 Y46.757 Z-8.045 F254
G1 X40.527 Y46.744 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.414 Y46.592 F254
G1 X40.372 Y46.528 F254
G1 X40.349 Y46.378 F254
G1 X40.395 Y46.232 F254
G1 X40.471 Y46.1 F254
G1 X40.563 Y45.979 F254
G1 X40.676 Y45.858 F254
G1 X40.818 Y45.725 F254
G1 X40.98 Y45.594 F254
G1 X41.147 Y45.479 F254
G1 X41.298 Y45.391 F254
G1 X41.434 Y45.324 F254
G1 X41.497 Y45.304 F254
G1 X41.543 Y45.298 F254
G1 X41.589 Y45.31 F254
G1 X41.626 Y45.338 F254
G1 X41.764 Y45.486 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.774 Y45.502 Z-8.045 F254
G1 X41.777 Y45.522 Z-7.994 F254
G1 X41.772 Y45.541 Z-7.944 F254
G1 X41.76 Y45.556 Z-7.893 F254
G1 X41.758 Y45.557 F254
G1 X41.32 Y45.916 F254
; MOVEMENT_LINK_DIRECT
G1 X40.924 Y46.24 F254
; MOVEMENT_LEAD_IN
G1 X40.485 Y46.599 F254
G1 Y46.6 F254
G1 X40.467 Y46.609 Z-7.944 F254
G1 X40.448 Y46.61 Z-7.994 F254
G1 X40.429 Y46.604 Z-8.045 F254
G1 X40.414 Y46.592 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.3 Y46.438 F254
G1 X40.258 Y46.375 F254
G1 X40.234 Y46.224 F254
G1 X40.279 Y46.079 F254
G1 X40.355 Y45.946 F254
G1 X40.448 Y45.825 F254
G1 X40.561 Y45.701 F254
G1 X40.703 Y45.567 F254
G1 X40.863 Y45.437 F254
G1 X41.025 Y45.325 F254
G1 X41.168 Y45.24 F254
G1 X41.305 Y45.172 F254
G1 X41.361 Y45.155 F254
G1 X41.407 Y45.15 F254
G1 X41.451 Y45.162 F254
G1 X41.489 Y45.19 F254
G1 X41.626 Y45.338 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.636 Y45.355 Z-8.045 F254
G1 X41.638 Y45.374 Z-7.994 F254
G1 X41.633 Y45.393 Z-7.944 F254
G1 X41.621 Y45.408 Z-7.893 F254
G1 X41.62 Y45.409 F254
G1 X41.184 Y45.771 F254
; MOVEMENT_LINK_DIRECT
G1 X40.807 Y46.084 F254
; MOVEMENT_LEAD_IN
G1 X40.371 Y46.445 F254
G1 X40.37 Y46.446 F254
G1 X40.353 Y46.455 Z-7.944 F254
G1 X40.334 Y46.456 Z-7.994 F254
G1 X40.315 Y46.451 Z-8.045 F254
G1 X40.3 Y46.438 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.186 Y46.285 F254
G1 X40.144 Y46.222 F254
G1 X40.119 Y46.071 F254
G1 X40.164 Y45.926 F254
G1 X40.239 Y45.793 F254
G1 X40.331 Y45.672 F254
G1 X40.445 Y45.546 F254
G1 X40.586 Y45.412 F254
G1 X40.743 Y45.284 F254
G1 X40.9 Y45.173 F254
G1 X41.038 Y45.09 F254
G1 X41.174 Y45.022 F254
G1 X41.224 Y45.007 F254
G1 X41.27 Y45.003 F254
G1 X41.314 Y45.015 F254
G1 X41.351 Y45.042 F254
G1 X41.489 Y45.19 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.498 Y45.207 Z-8.045 F254
G1 X41.501 Y45.226 Z-7.994 F254
G1 X41.496 Y45.245 Z-7.944 F254
G1 X41.484 Y45.26 Z-7.893 F254
G1 X41.483 Y45.261 F254
G1 X41.049 Y45.626 F254
; MOVEMENT_LINK_DIRECT
G1 X40.691 Y45.927 F254
; MOVEMENT_LEAD_IN
G1 X40.258 Y46.292 F254
G1 X40.257 Y46.293 F254
G1 X40.239 Y46.302 Z-7.944 F254
G1 X40.22 Y46.303 Z-7.994 F254
G1 X40.201 Y46.297 Z-8.045 F254
G1 X40.186 Y46.285 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.054 Y46.107 F254
G1 X40.032 Y46.075 F254
G1 X40.002 Y45.926 F254
G1 X40.044 Y45.78 F254
G1 X40.118 Y45.647 F254
G1 X40.209 Y45.524 F254
G1 X40.321 Y45.398 F254
G1 X40.459 Y45.265 F254
G1 X40.611 Y45.138 F254
G1 X40.764 Y45.029 F254
G1 X40.902 Y44.944 F254
G1 X41.038 Y44.874 F254
G1 X41.087 Y44.86 F254
G1 X41.133 Y44.855 F254
G1 X41.177 Y44.868 F254
G1 X41.214 Y44.895 F254
G1 X41.351 Y45.042 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.361 Y45.059 Z-8.045 F254
G1 X41.363 Y45.078 Z-7.994 F254
G1 X41.358 Y45.097 Z-7.944 F254
G1 X41.346 Y45.113 Z-7.893 F254
G1 X41.345 Y45.114 F254
G1 X40.907 Y45.472 F254
; MOVEMENT_LINK_DIRECT
G1 X40.563 Y45.754 F254
; MOVEMENT_LEAD_IN
G1 X40.124 Y46.114 F254
G1 X40.107 Y46.123 Z-7.944 F254
G1 X40.087 Y46.125 Z-7.994 F254
G1 X40.069 Y46.119 Z-8.045 F254
G1 X40.054 Y46.107 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.951 Y45.972 F254
G1 X39.908 Y45.909 F254
G1 X39.888 Y45.758 F254
G1 X39.935 Y45.613 F254
G1 X40.01 Y45.48 F254
G1 X40.101 Y45.359 F254
G1 X40.214 Y45.233 F254
G1 X40.352 Y45.1 F254
G1 X40.504 Y44.975 F254
G1 X40.656 Y44.866 F254
G1 X40.786 Y44.788 F254
G1 X40.923 Y44.719 F254
G1 X40.95 Y44.713 F254
G1 X40.992 Y44.709 F254
G1 X41.033 Y44.721 F254
G1 X41.068 Y44.745 F254
G1 X41.144 Y44.819 F254
G1 X41.214 Y44.895 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.224 Y44.912 Z-8.045 F254
G1 X41.226 Y44.931 Z-7.994 F254
G1 X41.221 Y44.95 Z-7.944 F254
G1 X41.209 Y44.965 Z-7.893 F254
G1 Y44.966 F254
G1 X40.777 Y45.334 F254
; MOVEMENT_LINK_DIRECT
G1 X40.453 Y45.611 F254
; MOVEMENT_LEAD_IN
G1 X40.022 Y45.978 F254
G1 X40.021 Y45.979 F254
G1 X40.004 Y45.988 Z-7.944 F254
G1 X39.985 Y45.99 Z-7.994 F254
G1 X39.966 Y45.984 Z-8.045 F254
G1 X39.951 Y45.972 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.881 Y45.882 F254
G1 X39.838 Y45.828 F254
G1 X39.793 Y45.766 F254
G1 X39.769 Y45.616 F254
G1 X39.813 Y45.47 F254
G1 X39.887 Y45.336 F254
G1 X39.977 Y45.214 F254
G1 X40.088 Y45.088 F254
G1 X40.223 Y44.956 F254
G1 X40.371 Y44.831 F254
G1 X40.516 Y44.725 F254
G1 X40.648 Y44.644 F254
G1 X40.784 Y44.573 F254
G1 X40.803 Y44.568 F254
G1 X40.846 Y44.565 F254
G1 X40.886 Y44.576 F254
G1 X40.921 Y44.6 F254
G1 X41.068 Y44.745 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.078 Y44.761 Z-8.045 F254
G1 X41.082 Y44.78 Z-7.994 F254
G1 X41.077 Y44.799 Z-7.944 F254
G1 X41.066 Y44.815 Z-7.893 F254
G1 X41.065 Y44.817 F254
G1 X40.64 Y45.19 F254
; MOVEMENT_LINK_DIRECT
G1 X40.334 Y45.458 F254
; MOVEMENT_LEAD_IN
G1 X39.908 Y45.833 F254
G1 X39.891 Y45.843 Z-7.944 F254
G1 X39.872 Y45.845 Z-7.994 F254
G1 X39.853 Y45.84 Z-8.045 F254
G1 X39.838 Y45.828 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.719 Y45.68 F254
G1 X39.674 Y45.619 F254
G1 X39.649 Y45.468 F254
G1 X39.693 Y45.322 F254
G1 X39.766 Y45.188 F254
G1 X39.855 Y45.065 F254
G1 X39.965 Y44.939 F254
G1 X40.097 Y44.808 F254
G1 X40.242 Y44.684 F254
G1 X40.387 Y44.578 F254
G1 X40.516 Y44.497 F254
G1 X40.651 Y44.426 F254
G1 X40.66 Y44.424 F254
G1 X40.701 Y44.422 F254
G1 X40.741 Y44.433 F254
G1 X40.775 Y44.457 F254
G1 X40.921 Y44.6 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.932 Y44.617 Z-8.045 F254
G1 X40.935 Y44.636 Z-7.994 F254
G1 X40.931 Y44.655 Z-7.944 F254
G1 X40.919 Y44.671 Z-7.893 F254
G1 X40.918 Y44.672 F254
G1 X40.497 Y45.05 F254
; MOVEMENT_LINK_DIRECT
G1 X40.212 Y45.306 F254
; MOVEMENT_LEAD_IN
G1 X39.79 Y45.685 F254
G1 X39.789 F254
G1 X39.772 Y45.695 Z-7.944 F254
G1 X39.753 Y45.697 Z-7.994 F254
G1 X39.734 Y45.692 Z-8.045 F254
G1 X39.719 Y45.68 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.602 Y45.536 F254
G1 X39.557 Y45.474 F254
G1 X39.529 Y45.325 F254
G1 X39.57 Y45.178 F254
G1 X39.642 Y45.044 F254
G1 X39.731 Y44.92 F254
G1 X39.838 Y44.794 F254
G1 X39.968 Y44.664 F254
G1 X40.111 Y44.54 F254
G1 X40.254 Y44.434 F254
G1 X40.382 Y44.352 F254
G1 X40.486 Y44.296 F254
G1 X40.536 Y44.282 F254
G1 X40.588 Y44.289 F254
G1 X40.632 Y44.317 F254
G1 X40.775 Y44.457 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.785 Y44.473 Z-8.045 F254
G1 X40.788 Y44.492 Z-7.994 F254
G1 X40.784 Y44.511 Z-7.944 F254
G1 X40.773 Y44.527 Z-7.893 F254
G1 X40.772 Y44.528 F254
G1 X40.356 Y44.912 F254
; MOVEMENT_LINK_DIRECT
G1 X40.09 Y45.157 F254
; MOVEMENT_LEAD_IN
G1 X39.674 Y45.54 F254
G1 X39.673 Y45.541 F254
G1 X39.656 Y45.551 Z-7.944 F254
G1 X39.636 Y45.553 Z-7.994 F254
G1 X39.618 Y45.548 Z-8.045 F254
G1 X39.602 Y45.536 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.474 Y45.378 F254
G1 X39.43 Y45.316 F254
G1 X39.41 Y45.165 F254
G1 X39.454 Y45.019 F254
G1 X39.526 Y44.885 F254
G1 X39.615 Y44.761 F254
G1 X39.723 Y44.636 F254
G1 X39.854 Y44.506 F254
G1 X39.996 Y44.383 F254
G1 X40.138 Y44.277 F254
G1 X40.267 Y44.196 F254
G1 X40.351 Y44.156 F254
G1 X40.4 Y44.144 F254
G1 X40.45 Y44.152 F254
G1 X40.492 Y44.179 F254
G1 X40.632 Y44.317 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.643 Y44.334 Z-8.045 F254
G1 X40.646 Y44.353 Z-7.994 F254
G1 X40.642 Y44.372 Z-7.944 F254
G1 X40.631 Y44.388 Z-7.893 F254
G1 X40.63 F254
G1 X40.212 Y44.771 F254
; MOVEMENT_LINK_DIRECT
G1 X39.963 Y44.999 F254
; MOVEMENT_LEAD_IN
G1 X39.546 Y45.382 F254
G1 X39.545 Y45.383 F254
G1 X39.528 Y45.392 Z-7.944 F254
G1 X39.509 Y45.395 Z-7.994 F254
G1 X39.49 Y45.39 Z-8.045 F254
G1 X39.474 Y45.378 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.362 Y45.238 F254
G1 X39.317 Y45.176 F254
G1 X39.289 Y45.027 F254
G1 X39.329 Y44.88 F254
G1 X39.4 Y44.745 F254
G1 X39.487 Y44.62 F254
G1 X39.593 Y44.495 F254
G1 X39.72 Y44.365 F254
G1 X39.861 Y44.242 F254
G1 X39.993 Y44.142 F254
G1 X40.121 Y44.059 F254
G1 X40.21 Y44.017 F254
G1 X40.259 Y44.005 F254
G1 X40.309 Y44.014 F254
G1 X40.351 Y44.041 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.361 Y44.056 Z-8.049 F254
G1 X40.365 Y44.073 Z-8.003 F254
G1 X40.362 Y44.091 Z-7.956 F254
G1 X40.354 Y44.107 Z-7.91 F254
G1 X40.35 Y44.112 Z-7.893 F254
G1 X39.992 Y44.553 F254
; MOVEMENT_LINK_DIRECT
G1 X39.79 Y44.803 F254
; MOVEMENT_LEAD_IN
G1 X39.439 Y45.237 F254
G1 X39.432 Y45.243 F254
G1 X39.415 Y45.253 Z-7.944 F254
G1 X39.396 Y45.255 Z-7.994 F254
G1 X39.377 Y45.25 Z-8.045 F254
G1 X39.362 Y45.238 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.249 Y45.099 F254
G1 X39.204 Y45.037 F254
G1 X39.167 Y44.889 F254
G1 X39.204 Y44.741 F254
G1 X39.272 Y44.605 F254
G1 X39.359 Y44.48 F254
G1 X39.462 Y44.356 F254
G1 X39.586 Y44.226 F254
G1 X39.721 Y44.106 F254
G1 X39.848 Y44.008 F254
G1 X39.975 Y43.924 F254
G1 X40.068 Y43.879 F254
G1 X40.117 Y43.867 F254
G1 X40.167 Y43.875 F254
G1 X40.21 Y43.902 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.22 Y43.917 Z-8.05 F254
G1 X40.224 Y43.935 Z-8.004 F254
G1 X40.221 Y43.952 Z-7.958 F254
G1 X40.213 Y43.968 Z-7.911 F254
G1 X40.209 Y43.973 Z-7.893 F254
G1 X39.858 Y44.42 F254
; MOVEMENT_LINK_DIRECT
G1 X39.671 Y44.658 F254
; MOVEMENT_LEAD_IN
G1 X39.326 Y45.097 F254
G1 X39.32 Y45.104 F254
G1 X39.303 Y45.113 Z-7.944 F254
G1 X39.284 Y45.116 Z-7.994 F254
G1 X39.265 Y45.111 Z-8.045 F254
G1 X39.249 Y45.099 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.138 Y44.959 F254
G1 X39.114 Y44.925 F254
G1 X39.074 Y44.86 F254
G1 X39.053 Y44.709 F254
G1 X39.097 Y44.563 F254
G1 X39.169 Y44.429 F254
G1 X39.256 Y44.304 F254
G1 X39.359 Y44.183 F254
G1 X39.484 Y44.056 F254
G1 X39.617 Y43.94 F254
G1 X39.738 Y43.849 F254
G1 X39.867 Y43.768 F254
G1 X39.933 Y43.739 F254
G1 X39.981 Y43.729 F254
G1 X40.029 Y43.738 F254
G1 X40.07 Y43.765 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.08 Y43.78 Z-8.05 F254
G1 X40.084 Y43.797 Z-8.003 F254
G1 X40.081 Y43.815 Z-7.957 F254
G1 X40.073 Y43.831 Z-7.91 F254
G1 X40.068 Y43.836 Z-7.893 F254
G1 X39.713 Y44.278 F254
; MOVEMENT_LINK_DIRECT
G1 X39.54 Y44.494 F254
; MOVEMENT_LEAD_IN
G1 X39.193 Y44.926 F254
G3 X39.184 Y44.935 I-0.039 J-0.031 F254
G1 X39.166 Y44.943 Z-7.944 F254
G1 X39.147 Y44.944 Z-7.994 F254
G1 X39.128 Y44.938 Z-8.045 F254
G1 X39.114 Y44.925 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.992 Y44.75 F254
G1 X38.953 Y44.684 F254
G1 X38.942 Y44.532 F254
G1 X38.989 Y44.388 F254
G1 X39.063 Y44.254 F254
G1 X39.153 Y44.131 F254
G1 X39.257 Y44.011 F254
G1 X39.382 Y43.887 F254
G1 X39.507 Y43.781 F254
G1 X39.629 Y43.69 F254
G1 X39.76 Y43.612 F254
G1 X39.801 Y43.598 F254
G1 X39.846 Y43.591 F254
G1 X39.891 Y43.601 F254
G1 X39.929 Y43.627 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.939 Y43.642 Z-8.049 F254
G1 X39.943 Y43.659 Z-8.003 F254
G1 X39.94 Y43.677 Z-7.956 F254
G1 X39.932 Y43.693 Z-7.909 F254
G1 X39.928 Y43.698 Z-7.893 F254
G1 X39.57 Y44.138 F254
; MOVEMENT_LINK_DIRECT
G1 X39.421 Y44.32 F254
; MOVEMENT_LEAD_IN
G1 X39.071 Y44.751 F254
G3 X39.062 Y44.76 I-0.039 J-0.032 F254
G1 X39.045 Y44.768 Z-7.944 F254
G1 X39.025 Y44.769 Z-7.994 F254
G1 X39.007 Y44.763 Z-8.045 F254
G1 X38.992 Y44.75 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.974 Y44.723 F254
G1 X38.879 Y44.572 F254
G1 X38.841 Y44.505 F254
G1 X38.835 Y44.353 F254
G1 X38.885 Y44.209 F254
G1 X38.961 Y44.077 F254
G1 X39.052 Y43.955 F254
G1 X39.158 Y43.837 F254
G1 X39.279 Y43.719 F254
G1 X39.397 Y43.621 F254
G1 X39.521 Y43.532 F254
G1 X39.654 Y43.457 F254
G1 X39.668 Y43.454 F254
G1 X39.71 Y43.451 F254
G1 X39.751 Y43.462 F254
G1 X39.786 Y43.486 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.795 Y43.501 Z-8.049 F254
G1 X39.799 Y43.519 Z-8.003 F254
G1 X39.797 Y43.536 Z-7.956 F254
G1 X39.788 Y43.552 Z-7.909 F254
G1 X39.784 Y43.557 Z-7.893 F254
G1 X39.427 Y43.998 F254
; MOVEMENT_LINK_DIRECT
G1 X39.307 Y44.145 F254
; MOVEMENT_LEAD_IN
G1 X38.959 Y44.575 F254
G3 X38.948 Y44.585 I-0.039 J-0.031 F254
G1 X38.93 Y44.592 Z-7.944 F254
G1 X38.911 Y44.593 Z-7.994 F254
G1 X38.893 Y44.585 Z-8.045 F254
G1 X38.879 Y44.572 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.771 Y44.401 F254
G1 X38.733 Y44.334 F254
G1 X38.727 Y44.182 F254
G1 X38.778 Y44.039 F254
G1 X38.855 Y43.907 F254
G1 X38.947 Y43.786 F254
G1 X39.053 Y43.67 F254
G1 X39.17 Y43.558 F254
G1 X39.288 Y43.462 F254
G1 X39.414 Y43.375 F254
G1 X39.501 Y43.329 F254
G1 X39.551 Y43.315 F254
G1 X39.603 Y43.322 F254
G1 X39.647 Y43.35 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.657 Y43.365 Z-8.049 F254
G1 X39.661 Y43.383 Z-8.003 F254
G1 X39.658 Y43.4 Z-7.956 F254
G1 X39.65 Y43.416 Z-7.91 F254
G1 X39.646 Y43.421 Z-7.893 F254
G1 X39.289 Y43.862 F254
; MOVEMENT_LINK_DIRECT
G1 X39.199 Y43.974 F254
; MOVEMENT_LEAD_IN
G1 X38.851 Y44.404 F254
G3 X38.84 Y44.414 I-0.039 J-0.031 F254
G1 X38.822 Y44.422 Z-7.944 F254
G1 X38.803 Z-7.994 F254
G1 X38.785 Y44.414 Z-8.045 F254
G1 X38.771 Y44.401 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.658 Y44.223 F254
G1 X38.621 Y44.156 F254
G1 Y44.004 F254
G1 X38.675 Y43.862 F254
G1 X38.754 Y43.731 F254
G1 X38.848 Y43.611 F254
G1 X38.952 Y43.5 F254
G1 X39.065 Y43.394 F254
G1 X39.185 Y43.299 F254
G1 X39.312 Y43.215 F254
G1 X39.371 Y43.189 F254
G1 X39.417 Y43.179 F254
G1 X39.462 Y43.186 F254
G1 X39.503 Y43.21 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.514 Y43.225 Z-8.047 F254
G1 X39.518 Y43.243 Z-7.999 F254
G1 X39.516 Y43.261 Z-7.95 F254
G1 X39.507 Y43.278 Z-7.901 F254
G1 X39.505 Y43.28 Z-7.893 F254
G1 X39.148 Y43.721 F254
; MOVEMENT_LINK_DIRECT
G1 X39.087 Y43.797 F254
; MOVEMENT_LEAD_IN
G1 X38.738 Y44.226 F254
G3 X38.728 Y44.236 I-0.039 J-0.031 F254
G1 X38.71 Y44.244 Z-7.944 F254
G1 X38.69 Z-7.994 F254
G1 X38.672 Y44.236 Z-8.045 F254
G1 X38.658 Y44.223 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.556 Y44.06 F254
G1 X38.518 Y43.994 F254
G1 X38.512 Y43.842 F254
G1 X38.565 Y43.699 F254
G1 X38.644 Y43.568 F254
G1 X38.738 Y43.449 F254
G1 X38.843 Y43.338 F254
G1 X38.956 Y43.235 F254
G1 X39.076 Y43.142 F254
G1 X39.205 Y43.061 F254
G1 X39.228 Y43.053 F254
G1 X39.27 Y43.047 F254
G1 X39.313 Y43.055 F254
G1 X39.35 Y43.077 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.361 Y43.092 Z-8.048 F254
G1 X39.365 Y43.11 Z-8 F254
G1 X39.363 Y43.128 Z-7.952 F254
G1 X39.355 Y43.145 Z-7.904 F254
G1 X39.352 Y43.148 Z-7.893 F254
G1 X39.003 Y43.595 F254
; MOVEMENT_LINK_DIRECT
G1 X38.977 Y43.628 F254
; MOVEMENT_LEAD_IN
G1 X38.636 Y44.063 F254
G3 X38.625 Y44.073 I-0.039 J-0.031 F254
G1 X38.607 Y44.081 Z-7.944 F254
G1 X38.588 Z-7.994 F254
G1 X38.569 Y44.074 Z-8.045 F254
G1 X38.556 Y44.06 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.462 Y43.912 F254
G1 X38.425 Y43.846 F254
G1 X38.402 Y43.695 F254
G1 X38.449 Y43.55 F254
G1 X38.526 Y43.419 F254
G1 X38.62 Y43.299 F254
G1 X38.724 Y43.187 F254
G1 X38.837 Y43.085 F254
G1 X38.958 Y42.992 F254
G1 X39.048 Y42.937 F254
G1 X39.096 Y42.921 F254
G1 X39.146 Y42.924 F254
G1 X39.191 Y42.947 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.203 Y42.962 Z-8.048 F254
G1 X39.208 Y42.979 Z-8 F254
G1 X39.207 Y42.998 Z-7.952 F254
G1 X39.199 Y43.014 Z-7.903 F254
G1 X39.197 Y43.018 Z-7.893 F254
G1 X38.868 Y43.469 F254
; MOVEMENT_LEAD_IN
G1 X38.544 Y43.914 F254
G3 X38.531 Y43.925 I-0.04 J-0.029 F254
G1 X38.514 Y43.933 Z-7.944 F254
G1 X38.494 Z-7.994 F254
G1 X38.476 Y43.926 Z-8.045 F254
G1 X38.462 Y43.912 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.416 Y43.839 F254
G1 X38.376 Y43.773 F254
G1 X38.346 Y43.718 F254
G1 X38.313 Y43.65 F254
G1 X38.306 Y43.498 F254
G1 X38.36 Y43.355 F254
G1 X38.441 Y43.226 F254
G1 X38.538 Y43.108 F254
G1 X38.644 Y42.999 F254
G1 X38.76 Y42.9 F254
G1 X38.885 Y42.813 F254
G1 X38.911 Y42.803 F254
G1 X38.954 Y42.794 F254
G1 X38.997 Y42.801 F254
G1 X39.035 Y42.822 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.047 Y42.836 Z-8.048 F254
G1 X39.052 Y42.854 Z-7.999 F254
G1 X39.051 Y42.872 Z-7.951 F254
G1 X39.043 Y42.889 Z-7.903 F254
G1 X39.041 Y42.892 Z-7.893 F254
G1 X38.754 Y43.281 F254
; MOVEMENT_LEAD_IN
G1 X38.429 Y43.722 F254
G3 X38.415 Y43.736 I-0.04 J-0.03 F254
G1 X38.396 Y43.742 Z-7.944 F254
G1 X38.377 Y43.741 Z-7.994 F254
G1 X38.359 Y43.733 Z-8.045 F254
G1 X38.346 Y43.718 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.276 Y43.591 F254
G1 X38.263 Y43.563 F254
G1 X38.247 Y43.525 F254
G1 X38.22 Y43.454 F254
G1 X38.217 Y43.301 F254
G1 X38.275 Y43.16 F254
G1 X38.359 Y43.033 F254
G1 X38.458 Y42.918 F254
G1 X38.568 Y42.811 F254
G1 X38.687 Y42.716 F254
G1 X38.746 Y42.685 F254
G1 X38.792 Y42.672 F254
G1 X38.84 Y42.676 F254
G1 X38.883 Y42.699 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X38.894 Y42.713 Z-8.048 F254
G1 X38.9 Y42.731 Z-8 F254
G1 X38.898 Y42.749 Z-7.952 F254
G1 X38.89 Y42.766 Z-7.904 F254
G1 X38.888 Y42.769 Z-7.893 F254
G1 X38.651 Y43.094 F254
; MOVEMENT_LEAD_IN
G1 X38.332 Y43.533 F254
G3 X38.313 Y43.549 I-0.04 J-0.029 F254
G1 X38.294 Y43.554 Z-7.944 F254
G1 X38.275 Y43.551 Z-7.994 F254
G1 X38.258 Y43.541 Z-8.045 F254
G1 X38.247 Y43.525 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.156 Y43.316 F254
G1 X38.13 Y43.244 F254
G1 X38.137 Y43.092 F254
G1 X38.201 Y42.954 F254
G1 X38.289 Y42.829 F254
G1 X38.392 Y42.717 F254
G1 X38.506 Y42.615 F254
G1 X38.586 Y42.567 F254
G1 X38.631 Y42.55 F254
G1 X38.679 Y42.552 F254
G1 X38.723 Y42.572 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X38.735 Y42.586 Z-8.046 F254
G1 X38.742 Y42.604 Z-7.996 F254
G1 X38.741 Y42.623 Z-7.946 F254
G1 X38.733 Y42.641 Z-7.896 F254
G1 X38.732 Y42.642 Z-7.893 F254
G1 X38.559 Y42.883 F254
; MOVEMENT_LEAD_IN
G1 X38.242 Y43.323 F254
G3 X38.223 Y43.339 I-0.041 J-0.029 F254
G1 X38.204 Y43.344 Z-7.944 F254
G1 X38.185 Y43.341 Z-7.994 F254
G1 X38.168 Y43.331 Z-8.045 F254
G1 X38.156 Y43.316 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.067 Y43.108 F254
G1 X38.041 Y43.037 F254
G1 X38.059 Y42.886 F254
G1 X38.128 Y42.75 F254
G1 X38.221 Y42.629 F254
G1 X38.327 Y42.52 F254
G1 X38.409 Y42.462 F254
G1 X38.453 Y42.442 F254
G1 X38.501 Y42.441 F254
G1 X38.546 Y42.458 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X38.56 Y42.471 Z-8.045 F254
G1 X38.568 Y42.489 Z-7.994 F254
G1 Y42.509 Z-7.944 F254
G1 X38.561 Y42.527 Z-7.893 F254
G1 X38.56 Y42.528 F254
G1 X38.461 Y42.67 F254
; MOVEMENT_LEAD_IN
G1 X38.153 Y43.116 F254
G3 X38.134 Y43.132 I-0.041 J-0.028 F254
G1 X38.123 Y43.136 Z-7.921 F254
G1 X38.113 Y43.137 Z-7.949 F254
G1 X38.112 Z-7.95 F254
G1 X38.094 Y43.134 Z-7.999 F254
G1 X38.078 Y43.124 Z-8.047 F254
G1 X38.067 Y43.108 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X38.053 Y43.075 F254
G1 X38.026 Y43.005 F254
G1 X37.997 Y42.917 F254
G1 X37.978 Y42.843 F254
G1 X37.985 Y42.691 F254
G1 X38.055 Y42.556 F254
G1 X38.15 Y42.436 F254
G1 X38.233 Y42.366 F254
G1 X38.278 Y42.342 F254
G1 X38.33 Y42.338 F254
G1 X38.379 Y42.355 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X38.392 Y42.368 Z-8.046 F254
G1 X38.4 Y42.386 Z-7.997 F254
G1 Y42.405 Z-7.947 F254
G1 X38.394 Y42.423 Z-7.897 F254
G1 X38.393 Y42.424 Z-7.893 F254
G1 X38.365 Y42.47 F254
; MOVEMENT_LEAD_IN
G1 X38.087 Y42.926 F254
G3 X38.061 Y42.947 I-0.043 J-0.026 F254
G1 X38.042 Y42.95 Z-7.944 F254
G1 X38.023 Y42.945 Z-7.994 F254
G1 X38.007 Y42.934 Z-8.045 F254
G1 X37.997 Y42.917 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X37.981 Y42.865 F254
G1 X37.934 Y42.695 F254
G1 X37.918 Y42.62 F254
G1 X37.932 Y42.469 F254
G1 X38.009 Y42.337 F254
G1 X38.072 Y42.277 F254
G1 X38.119 Y42.249 F254
G1 X38.172 Y42.243 F254
G1 X38.224 Y42.26 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X38.237 Y42.273 Z-8.047 F254
G1 X38.245 Y42.29 Z-7.999 F254
G1 X38.246 Y42.309 Z-7.95 F254
G1 X38.24 Y42.327 Z-7.902 F254
; MOVEMENT_LEAD_IN
G1 X38.238 Y42.33 Z-7.893 F254
G1 X38.026 Y42.705 F254
G3 X37.997 Y42.728 I-0.044 J-0.025 F254
G1 X37.977 Y42.73 Z-7.944 F254
G1 X37.959 Y42.724 Z-7.994 F254
G1 X37.944 Y42.712 Z-8.045 F254
G1 X37.934 Y42.695 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X37.876 Y42.478 F254
G1 X37.868 Y42.447 F254
G1 X37.858 Y42.41 F254
G1 X37.852 Y42.383 F254
G1 X37.893 Y42.236 F254
G1 X37.93 Y42.197 F254
G1 X37.977 Y42.166 F254
G1 X38.033 Y42.158 F254
G1 X38.086 Y42.176 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X38.1 Y42.19 Z-8.045 F254
G1 X38.108 Y42.208 Z-7.994 F254
G1 Y42.227 Z-7.944 F254
G1 X38.1 Y42.245 Z-7.893 F254
G1 X38.097 Y42.251 F254
G1 X37.943 Y42.428 F254
G3 X37.92 Y42.443 I-0.038 J-0.033 F254
G1 X37.901 Y42.445 Z-7.944 F254
G1 X37.882 Y42.439 Z-7.994 F254
G1 X37.867 Y42.427 Z-8.045 F254
G1 X37.858 Y42.41 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X37.84 Y42.342 F254
G1 X37.836 Y42.325 F254
G1 X37.83 Y42.237 F254
G1 X37.828 Y42.199 F254
G1 X37.826 Y42.168 F254
G1 X37.83 Y42.15 F254
G1 X37.832 Y42.144 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G3 X37.866 Y42.134 I0.025 J0.023 F254
G3 X37.85 Y42.196 I-0.008 J0.031 F254
G3 X37.826 Y42.168 I0.008 J-0.031 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X37.827 Y42.156 F254
G1 X37.832 Y42.144 F254
G1 X37.845 Y42.128 F254
G1 X37.858 Y42.12 F254
G1 X37.875 Y42.11 F254
G1 X37.893 Y42.107 F254
G1 X37.91 Y42.11 F254
G1 X38.032 Y42.149 F254
G1 X38.05 Y42.155 F254
G1 X38.072 Y42.168 F254
G1 X38.556 Y42.463 F254
G1 X38.695 Y42.552 F254
G1 X38.743 Y42.586 F254
G1 X39.263 Y43.005 F254
G1 X39.323 Y43.054 F254
G1 X39.508 Y43.214 F254
G1 X40.492 Y44.179 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X40.42 Y44.248 I-0.036 J0.034 F254
G1 X40.406 Y44.234 Z-8.092 F254
G1 X40.395 Y44.223 Z-8.081 F254
G1 X40.388 Y44.215 Z-8.065 F254
G1 X40.385 Y44.212 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X46.372 Y49.369 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X46.37 Y49.365 Z-8.065 F254
G1 X46.364 Y49.356 Z-8.081 F254
G1 X46.355 Y49.342 Z-8.092 F254
G1 X46.345 Y49.326 Z-8.096 F254
G3 X46.301 Y47.756 I1.298 J-0.822 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X46.387 Y47.611 F254
G1 X46.423 Y47.541 F254
G1 X46.441 Y47.486 F254
G1 X46.443 Y47.471 F254
G1 X46.45 Y47.401 F254
G1 X46.458 Y47.326 F254
G1 X46.521 Y47.187 F254
G1 X46.618 Y47.069 F254
G1 X46.73 Y46.966 F254
G1 X46.853 Y46.876 F254
G1 X46.983 Y46.797 F254
G1 X47.12 Y46.728 F254
G1 X47.19 Y46.696 F254
G1 X47.255 Y46.655 F254
G1 X47.305 Y46.596 F254
G1 X47.338 Y46.527 F254
G1 X47.379 Y46.379 F254
G1 X47.369 Y46.226 F254
G1 X47.291 Y45.929 F254
G1 X47.174 Y45.645 F254
G1 X47.026 Y45.376 F254
G1 X46.885 Y45.103 F254
G1 X46.742 Y44.831 F254
G1 X46.586 Y44.567 F254
G1 X46.422 Y44.307 F254
G1 X46.1 Y43.784 F254
G1 X45.918 Y43.537 F254
G1 X45.743 Y43.285 F254
G1 X45.566 Y43.034 F254
G1 X45.179 Y42.557 F254
G1 X44.985 Y42.319 F254
G1 X44.769 Y42.101 F254
G1 X44.558 Y41.878 F254
G1 X44.328 Y41.675 F254
G1 X44.214 Y41.573 F254
G1 X44.185 Y41.503 F254
G1 X44.173 Y41.466 F254
G1 X44.159 Y41.431 F254
G1 X44.196 Y41.283 F254
G1 X44.294 Y41.166 F254
G1 X44.421 Y41.083 F254
G1 X44.562 Y41.024 F254
G1 X44.722 Y40.974 F254
G1 X45.02 Y40.904 F254
G1 X45.324 Y40.855 F254
G1 X45.626 Y40.8 F254
G1 X45.93 Y40.755 F254
G1 X46.181 Y40.735 F254
G1 X46.418 Y40.733 F254
G1 X46.591 Y40.745 F254
G1 X46.857 Y40.782 F254
G1 X47.056 Y40.826 F254
G1 X47.351 Y40.913 F254
G1 X47.625 Y41.016 F254
G1 X47.895 Y41.142 F254
G1 X48.163 Y41.292 F254
G1 X48.298 Y41.365 F254
G1 X48.503 Y41.488 F254
G1 X48.752 Y41.663 F254
G1 X48.958 Y41.832 F254
G1 X49.068 Y41.937 F254
G1 X49.148 Y42.067 F254
G1 X49.193 Y42.213 F254
G1 X49.205 Y42.364 F254
G1 X49.192 Y42.516 F254
G1 X49.154 Y42.7 F254
G1 X49.085 Y42.947 F254
G1 X48.98 Y43.236 F254
G1 X48.871 Y43.522 F254
G1 X48.649 Y44.095 F254
G1 X48.542 Y44.383 F254
G1 X48.46 Y44.679 F254
G1 X48.37 Y44.972 F254
G1 X48.281 Y45.266 F254
G1 X48.194 Y45.561 F254
G1 X48.146 Y45.864 F254
G1 X48.11 Y46.169 F254
G1 X48.09 Y46.321 F254
G1 X48.089 Y46.398 F254
G1 X48.107 Y46.473 F254
G1 X48.176 Y46.61 F254
G1 X48.389 Y46.831 F254
G1 X48.521 Y46.907 F254
G1 X48.645 Y46.996 F254
G1 X48.76 Y47.095 F254
G1 X48.867 Y47.204 F254
G1 X48.965 Y47.32 F254
G1 X49.058 Y47.447 F254
G1 X49.149 Y47.595 F254
G1 X49.198 Y47.688 F254
G1 X49.204 Y47.703 F254
G1 X49.209 Y47.719 F254
G1 X49.211 Y47.735 F254
G1 X49.274 Y48.47 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X49.225 Y48.523 I-0.05 J0.003 F254
G1 X49.224 F254
G3 X49.2 Y48.516 J-0.05 F254
G1 X49.19 Y48.5 Z-8.092 F254
G1 X49.182 Y48.487 Z-8.081 F254
G1 X49.176 Y48.478 Z-8.065 F254
G1 X49.175 Y48.475 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X47.416 Y48.695 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X47.412 Y48.694 Z-8.065 F254
G1 X47.402 Y48.689 Z-8.081 F254
G1 X47.387 Y48.683 Z-8.092 F254
G1 X47.37 Y48.675 Z-8.096 F254
G3 X46.45 Y47.401 I0.612 J-1.41 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X46.447 Y47.332 F254
G1 X46.437 Y47.223 F254
G1 X46.433 Y47.147 F254
G1 X46.471 Y47 F254
G1 X46.562 Y46.878 F254
G1 X46.674 Y46.775 F254
G1 X46.798 Y46.686 F254
G1 X46.93 Y46.608 F254
G1 X46.995 Y46.566 F254
G1 X47.048 Y46.51 F254
G1 X47.085 Y46.443 F254
G1 X47.128 Y46.296 F254
G1 X47.12 Y46.143 F254
G1 X47.05 Y45.844 F254
G1 X46.907 Y45.572 F254
G1 X46.762 Y45.301 F254
G1 X46.62 Y45.029 F254
G1 X46.47 Y44.761 F254
G1 X46.146 Y44.24 F254
G1 X45.985 Y43.978 F254
G1 X45.811 Y43.725 F254
G1 X45.631 Y43.476 F254
G1 X45.455 Y43.224 F254
G1 X45.267 Y42.981 F254
G1 X44.879 Y42.506 F254
G1 X44.669 Y42.282 F254
G1 X44.456 Y42.061 F254
G1 X44.23 Y41.853 F254
G1 X44.119 Y41.748 F254
G1 X44.039 Y41.619 F254
G1 X43.993 Y41.473 F254
G1 X44.001 Y41.321 F254
G1 X44.06 Y41.181 F254
G1 X44.153 Y41.06 F254
G1 X44.27 Y40.962 F254
G1 X44.403 Y40.888 F254
G1 X44.544 Y40.83 F254
G1 X44.763 Y40.761 F254
G1 X45.037 Y40.697 F254
G1 X45.341 Y40.65 F254
G1 X45.643 Y40.594 F254
G1 X45.795 Y40.572 F254
G1 X46.075 Y40.542 F254
G1 X46.334 Y40.534 F254
G1 X46.54 Y40.542 F254
G1 X46.801 Y40.572 F254
G1 X47.027 Y40.616 F254
G1 X47.315 Y40.693 F254
G1 X47.604 Y40.793 F254
G1 X47.885 Y40.916 F254
G1 X48.157 Y41.058 F254
G1 X48.426 Y41.207 F254
G1 X48.681 Y41.366 F254
G1 X48.915 Y41.536 F254
G1 X49.059 Y41.658 F254
G1 X49.167 Y41.765 F254
G1 X49.259 Y41.887 F254
G1 X49.326 Y42.023 F254
G1 X49.369 Y42.17 F254
G1 X49.388 Y42.321 F254
G1 X49.385 Y42.473 F254
G1 X49.365 Y42.625 F254
G1 X49.322 Y42.829 F254
G1 X49.242 Y43.103 F254
G1 X49.135 Y43.391 F254
G1 X49.025 Y43.678 F254
G1 X48.914 Y43.964 F254
G1 X48.804 Y44.251 F254
G1 X48.701 Y44.54 F254
G1 X48.623 Y44.837 F254
G1 X48.53 Y45.13 F254
G1 X48.443 Y45.424 F254
G1 X48.365 Y45.721 F254
G1 X48.31 Y46.178 F254
G1 Y46.255 F254
G1 X48.323 Y46.331 F254
G1 X48.377 Y46.474 F254
G1 X48.467 Y46.599 F254
G1 X48.702 Y46.796 F254
G1 X48.824 Y46.893 F254
G1 X48.938 Y46.999 F254
G1 X49.048 Y47.116 F254
G1 X49.153 Y47.246 F254
G1 X49.163 Y47.265 F254
G1 X49.171 Y47.285 F254
G1 X49.174 Y47.306 F254
G1 X49.211 Y47.735 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X49.162 Y47.788 I-0.05 J0.003 F254
G1 X49.161 F254
G3 X49.136 Y47.781 J-0.05 F254
G1 X49.127 Y47.765 Z-8.092 F254
G1 X49.119 Y47.752 Z-8.081 F254
G1 X49.113 Y47.743 Z-8.065 F254
G1 X49.111 Y47.74 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X47.627 Y48.307 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X47.623 Z-8.065 F254
G1 X47.613 Y48.306 Z-8.081 F254
G1 X47.596 Y48.305 Z-8.092 F254
G1 X47.577 Y48.303 Z-8.096 F254
G3 X46.437 Y47.223 I0.098 J-1.246 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X46.42 Y47.052 F254
G1 X46.414 Y47.014 F254
G1 X46.406 Y46.938 F254
G1 X46.439 Y46.789 F254
G1 X46.531 Y46.668 F254
G1 X46.645 Y46.567 F254
G1 X46.77 Y46.478 F254
G1 X46.817 Y46.417 F254
G1 X46.849 Y46.347 F254
G1 X46.883 Y46.198 F254
G1 X46.875 Y46.044 F254
G1 X46.788 Y45.75 F254
G1 X46.632 Y45.486 F254
G1 X46.491 Y45.213 F254
G1 X46.344 Y44.943 F254
G1 X46.185 Y44.68 F254
G1 X46.022 Y44.42 F254
G1 X45.861 Y44.159 F254
G1 X45.692 Y43.903 F254
G1 X45.513 Y43.653 F254
G1 X45.336 Y43.402 F254
G1 X45.151 Y43.157 F254
G1 X44.764 Y42.681 F254
G1 X44.557 Y42.453 F254
G1 X44.343 Y42.233 F254
G1 X44.12 Y42.022 F254
G1 X44.013 Y41.913 F254
G1 X43.922 Y41.791 F254
G1 X43.856 Y41.654 F254
G1 X43.82 Y41.506 F254
G1 X43.816 Y41.353 F254
G1 X43.852 Y41.205 F254
G1 X43.92 Y41.069 F254
G1 X44.012 Y40.947 F254
G1 X44.123 Y40.843 F254
G1 X44.249 Y40.758 F254
G1 X44.385 Y40.689 F254
G1 X44.553 Y40.623 F254
G1 X44.782 Y40.553 F254
G1 X45.063 Y40.489 F254
G1 X45.367 Y40.444 F254
G1 X45.658 Y40.388 F254
G1 X45.963 Y40.353 F254
G1 X46.237 Y40.337 F254
G1 X46.472 Y40.34 F254
G1 X46.737 Y40.364 F254
G1 X46.985 Y40.404 F254
G1 X47.273 Y40.473 F254
G1 X47.565 Y40.567 F254
G1 X47.851 Y40.681 F254
G1 X48.127 Y40.815 F254
G1 X48.396 Y40.962 F254
G1 X48.661 Y41.117 F254
G1 X48.91 Y41.284 F254
G1 X49.097 Y41.43 F254
G1 X49.21 Y41.532 F254
G1 X49.313 Y41.644 F254
G1 X49.403 Y41.767 F254
G1 X49.476 Y41.901 F254
G1 X49.53 Y42.044 F254
G1 X49.563 Y42.193 F254
G1 X49.576 Y42.345 F254
G1 X49.572 Y42.497 F254
G1 X49.552 Y42.666 F254
G1 X49.513 Y42.869 F254
G1 X49.45 Y43.104 F254
G1 X49.348 Y43.394 F254
G1 X49.017 Y44.254 F254
G1 X48.912 Y44.542 F254
G1 X48.828 Y44.838 F254
G1 X48.651 Y45.426 F254
G1 X48.571 Y45.722 F254
G1 X48.529 Y46.026 F254
G1 X48.521 Y46.18 F254
G1 X48.56 Y46.328 F254
G1 X48.647 Y46.455 F254
G1 X48.86 Y46.676 F254
G1 X48.979 Y46.774 F254
G1 X49.099 Y46.887 F254
G1 X49.155 Y46.948 F254
G1 X49.175 Y46.978 F254
G1 X49.186 Y47.012 F254
G1 Y47.048 F254
G1 X49.177 Y47.122 F254
G1 X49.169 Y47.192 F254
G1 X49.171 Y47.262 F254
G1 X49.174 Y47.306 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X49.125 Y47.359 I-0.05 J0.003 F254
G1 X49.124 F254
G3 X49.1 Y47.352 J-0.05 F254
G1 X49.09 Y47.336 Z-8.092 F254
G1 X49.082 Y47.323 Z-8.081 F254
G1 X49.076 Y47.314 Z-8.065 F254
G1 X49.074 Y47.311 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X47.34 Y50.068 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X47.338 Y50.065 Z-8.065 F254
G1 X47.334 Y50.055 Z-8.081 F254
G1 X47.328 Y50.04 Z-8.092 F254
G1 X47.32 Y50.022 Z-8.096 F254
G3 X46.414 Y47.014 I13.428 J-5.688 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X46.409 Y46.983 F254
G1 X46.388 Y46.913 F254
G1 X46.363 Y46.843 F254
G1 X46.34 Y46.77 F254
G1 X46.369 Y46.621 F254
G1 X46.458 Y46.497 F254
G1 X46.569 Y46.39 F254
G1 X46.603 Y46.321 F254
G1 X46.625 Y46.248 F254
G1 X46.642 Y46.095 F254
G1 X46.622 Y45.943 F254
G1 X46.512 Y45.656 F254
G1 X46.355 Y45.392 F254
G1 X46.214 Y45.12 F254
G1 X46.058 Y44.855 F254
G1 X45.734 Y44.334 F254
G1 X45.567 Y44.076 F254
G1 X45.39 Y43.825 F254
G1 X45.212 Y43.575 F254
G1 X45.03 Y43.327 F254
G1 X44.838 Y43.088 F254
G1 X44.644 Y42.85 F254
G1 X44.44 Y42.621 F254
G1 X44.227 Y42.399 F254
G1 X44.004 Y42.188 F254
G1 X43.9 Y42.076 F254
G1 X43.806 Y41.957 F254
G1 X43.728 Y41.826 F254
G1 X43.673 Y41.684 F254
G1 X43.641 Y41.535 F254
G1 X43.633 Y41.383 F254
G1 X43.653 Y41.232 F254
G1 X43.703 Y41.088 F254
G1 X43.776 Y40.954 F254
G1 X43.868 Y40.833 F254
G1 X43.976 Y40.725 F254
G1 X44.097 Y40.633 F254
G1 X44.228 Y40.555 F254
G1 X44.366 Y40.49 F254
G1 X44.558 Y40.417 F254
G1 X44.803 Y40.344 F254
G1 X45.1 Y40.279 F254
G1 X45.404 Y40.236 F254
G1 X45.653 Y40.188 F254
G1 X45.958 Y40.152 F254
G1 X46.108 Y40.144 F254
G1 X46.365 Y40.139 F254
G1 X46.638 Y40.154 F254
G1 X46.904 Y40.188 F254
G1 X47.195 Y40.248 F254
G1 X47.491 Y40.332 F254
G1 X47.78 Y40.436 F254
G1 X48.061 Y40.559 F254
G1 X48.334 Y40.699 F254
G1 X48.602 Y40.85 F254
G1 X48.864 Y41.01 F254
G1 X49.085 Y41.166 F254
G1 X49.237 Y41.291 F254
G1 X49.347 Y41.397 F254
G1 X49.449 Y41.51 F254
G1 X49.54 Y41.632 F254
G1 X49.618 Y41.764 F254
G1 X49.681 Y41.902 F254
G1 X49.726 Y42.048 F254
G1 X49.753 Y42.198 F254
G1 X49.765 Y42.35 F254
G1 X49.762 Y42.502 F254
G1 X49.745 Y42.682 F254
G1 X49.711 Y42.882 F254
G1 X49.657 Y43.1 F254
G1 X49.562 Y43.391 F254
G1 X49.453 Y43.679 F254
G1 X49.232 Y44.251 F254
G1 X49.126 Y44.54 F254
G1 X49.036 Y44.833 F254
G1 X48.95 Y45.128 F254
G1 X48.861 Y45.422 F254
G1 X48.779 Y45.718 F254
G1 X48.73 Y46.021 F254
G1 X48.75 Y46.173 F254
G1 X48.821 Y46.309 F254
G1 X49.008 Y46.552 F254
G1 X49.127 Y46.649 F254
G1 X49.18 Y46.7 F254
G1 X49.204 Y46.731 F254
G1 X49.217 Y46.767 F254
G1 X49.218 Y46.806 F254
G1 X49.186 Y47.048 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X49.137 Y47.09 I-0.049 J-0.008 F254
G3 X49.104 Y47.077 J-0.05 F254
G1 X49.097 Y47.063 Z-8.093 F254
G1 X49.091 Y47.05 Z-8.085 F254
G1 X49.087 Y47.04 Z-8.073 F254
G1 X49.088 Y47.034 Z-8.06 F254
G1 Y47.032 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X47.453 Y49.843 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X47.452 Y49.839 Z-8.065 F254
G1 X47.449 Y49.829 Z-8.081 F254
G1 X47.444 Y49.813 Z-8.092 F254
G1 X47.438 Y49.795 Z-8.096 F254
G2 X46.363 Y46.843 I-42.806 J13.914 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X46.301 Y46.675 F254
G1 X46.278 Y46.603 F254
G1 X46.299 Y46.452 F254
G1 X46.374 Y46.318 F254
G1 X46.413 Y46.169 F254
G1 X46.405 Y46.016 F254
G1 X46.33 Y45.718 F254
G1 X46.221 Y45.553 F254
G1 X46.072 Y45.284 F254
G1 X45.922 Y45.016 F254
G1 X45.598 Y44.495 F254
G1 X45.433 Y44.236 F254
G1 X45.258 Y43.984 F254
G1 X45.08 Y43.734 F254
G1 X44.899 Y43.486 F254
G1 X44.708 Y43.245 F254
G1 X44.514 Y43.007 F254
G1 X44.311 Y42.776 F254
G1 X44.099 Y42.555 F254
G1 X43.988 Y42.449 F254
G1 X43.836 Y42.298 F254
G1 X43.736 Y42.183 F254
G1 X43.646 Y42.06 F254
G1 X43.57 Y41.928 F254
G1 X43.511 Y41.787 F254
G1 X43.469 Y41.641 F254
G1 X43.448 Y41.49 F254
G1 X43.45 Y41.337 F254
G1 X43.476 Y41.187 F254
G1 X43.522 Y41.042 F254
G1 X43.589 Y40.905 F254
G1 X43.672 Y40.777 F254
G1 X43.771 Y40.661 F254
G1 X43.883 Y40.558 F254
G1 X44.005 Y40.467 F254
G1 X44.136 Y40.389 F254
G1 X44.293 Y40.312 F254
G1 X44.489 Y40.233 F254
G1 X44.702 Y40.166 F254
G1 X44.984 Y40.099 F254
G1 X45.288 Y40.05 F254
G1 X45.59 Y39.998 F254
G1 X45.889 Y39.958 F254
G1 X46.195 Y39.94 F254
G1 X46.49 Y39.944 F254
G1 X46.775 Y39.969 F254
G1 X47.074 Y40.017 F254
G1 X47.373 Y40.089 F254
G1 X47.666 Y40.18 F254
G1 X47.952 Y40.291 F254
G1 X48.231 Y40.42 F254
G1 X48.503 Y40.563 F254
G1 X48.769 Y40.716 F254
G1 X49.023 Y40.875 F254
G1 X49.224 Y41.023 F254
G1 X49.376 Y41.153 F254
G1 X49.494 Y41.269 F254
G1 X49.594 Y41.384 F254
G1 X49.685 Y41.507 F254
G1 X49.765 Y41.636 F254
G1 X49.832 Y41.773 F254
G1 X49.886 Y41.916 F254
G1 X49.924 Y42.063 F254
G1 X49.947 Y42.214 F254
G1 X49.956 Y42.366 F254
G1 X49.953 Y42.536 F254
G1 X49.935 Y42.727 F254
G1 X49.899 Y42.94 F254
G1 X49.838 Y43.19 F254
G1 X49.743 Y43.483 F254
G1 X49.411 Y44.342 F254
G1 X49.305 Y44.63 F254
G1 X49.218 Y44.924 F254
G1 X49.132 Y45.219 F254
G1 X49.042 Y45.513 F254
G1 X48.961 Y45.809 F254
G1 X48.946 Y45.962 F254
G1 X48.976 Y46.112 F254
G1 X49.047 Y46.249 F254
G1 X49.224 Y46.485 F254
G1 X49.24 Y46.513 F254
G1 X49.248 Y46.544 F254
G1 Y46.576 F254
G1 X49.218 Y46.806 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X49.169 Y46.848 I-0.049 J-0.008 F254
G1 X49.168 F254
G3 X49.135 Y46.835 J-0.05 F254
G1 X49.129 Y46.821 Z-8.093 F254
G1 X49.123 Y46.808 Z-8.085 F254
G1 X49.118 Y46.798 Z-8.073 F254
G1 X49.119 Y46.792 Z-8.06 F254
G1 Y46.79 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X47.411 Y49.668 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X47.409 Y49.664 Z-8.065 F254
G1 X47.406 Y49.654 Z-8.081 F254
G1 X47.401 Y49.638 Z-8.092 F254
G1 X47.395 Y49.62 Z-8.096 F254
G2 X46.301 Y46.675 I-42.716 J14.189 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X46.234 Y46.494 F254
G1 X46.188 Y46.349 F254
G1 X46.201 Y46.196 F254
G1 X46.189 Y46.043 F254
G1 X46.161 Y45.892 F254
G1 X46.033 Y45.613 F254
G1 X45.878 Y45.348 F254
G1 X45.729 Y45.079 F254
G1 X45.565 Y44.82 F254
G1 X45.403 Y44.559 F254
G1 X45.237 Y44.301 F254
G1 X45.06 Y44.05 F254
G1 X44.881 Y43.8 F254
G1 X44.699 Y43.552 F254
G1 X44.507 Y43.313 F254
G1 X44.311 Y43.077 F254
G1 X44.106 Y42.848 F254
G1 X43.89 Y42.629 F254
G1 X43.737 Y42.481 F254
G1 X43.624 Y42.353 F254
G1 X43.531 Y42.232 F254
G1 X43.448 Y42.104 F254
G1 X43.379 Y41.968 F254
G1 X43.324 Y41.826 F254
G1 X43.286 Y41.679 F254
G1 X43.264 Y41.528 F254
G1 X43.261 Y41.375 F254
G1 X43.277 Y41.224 F254
G1 X43.311 Y41.075 F254
G1 X43.364 Y40.933 F254
G1 X43.434 Y40.797 F254
G1 X43.518 Y40.67 F254
G1 X43.615 Y40.552 F254
G1 X43.724 Y40.445 F254
G1 X43.842 Y40.35 F254
G1 X43.969 Y40.265 F254
G1 X44.107 Y40.187 F254
G1 X44.285 Y40.104 F254
G1 X44.49 Y40.026 F254
G1 X44.748 Y39.949 F254
G1 X45.048 Y39.883 F254
G1 X45.351 Y39.837 F254
G1 X45.654 Y39.786 F254
G1 X45.959 Y39.751 F254
G1 X46.266 Y39.739 F254
G1 X46.569 Y39.748 F254
G1 X46.874 Y39.78 F254
G1 X47.176 Y39.833 F254
G1 X47.474 Y39.908 F254
G1 X47.766 Y40.003 F254
G1 X48.052 Y40.116 F254
G1 X48.33 Y40.245 F254
G1 X48.602 Y40.389 F254
G1 X48.868 Y40.542 F254
G1 X49.128 Y40.705 F254
G1 X49.326 Y40.849 F254
G1 X49.484 Y40.984 F254
G1 X49.617 Y41.115 F254
G1 X49.728 Y41.242 F254
G1 X49.821 Y41.366 F254
G1 X49.904 Y41.494 F254
G1 X49.976 Y41.628 F254
G1 X50.037 Y41.768 F254
G1 X50.084 Y41.913 F254
G1 X50.118 Y42.062 F254
G1 X50.139 Y42.213 F254
G1 X50.148 Y42.376 F254
G1 X50.145 Y42.56 F254
G1 X50.127 Y42.766 F254
G1 X50.088 Y43.002 F254
G1 X50.029 Y43.247 F254
G1 X49.935 Y43.539 F254
G1 X49.825 Y43.826 F254
G1 X49.604 Y44.399 F254
G1 X49.498 Y44.687 F254
G1 X49.409 Y44.981 F254
G1 X49.324 Y45.276 F254
G1 X49.234 Y45.569 F254
G1 X49.193 Y45.717 F254
G1 X49.167 Y45.869 F254
G1 X49.189 Y46.021 F254
G1 X49.276 Y46.207 F254
G1 X49.284 Y46.229 F254
G1 X49.288 Y46.252 F254
G1 X49.287 Y46.276 F254
G1 X49.248 Y46.576 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X49.199 Y46.618 I-0.049 J-0.008 F254
G1 X49.198 F254
G3 X49.165 Y46.605 J-0.05 F254
G1 X49.158 Y46.591 Z-8.093 F254
G1 X49.153 Y46.578 Z-8.085 F254
G1 X49.148 Y46.568 Z-8.073 F254
G1 X49.149 Y46.562 Z-8.06 F254
G1 Y46.56 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X46.885 Y43.379 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X46.886 Y43.382 Z-8.065 F254
G1 X46.891 Y43.392 Z-8.081 F254
G1 X46.897 Y43.407 Z-8.092 F254
G1 X46.904 Y43.425 Z-8.096 F254
G3 X46.234 Y46.494 I-2.552 J1.051 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X46.182 Y46.355 F254
G1 X46.125 Y46.215 F254
G1 X46.092 Y46.136 F254
G1 X46.062 Y46.076 F254
G1 X45.731 Y45.447 F254
G1 X45.692 Y45.378 F254
G1 X45.567 Y45.168 F254
G1 X45.177 Y44.54 F254
G1 X45.132 Y44.471 F254
G1 X44.69 Y43.842 F254
G1 X44.626 Y43.756 F254
G1 X44.557 Y43.666 F254
G1 X44.208 Y43.234 F254
G1 X44.13 Y43.145 F254
G1 X44.066 Y43.075 F254
G1 X43.789 Y42.782 F254
G1 X43.733 Y42.726 F254
G1 X43.655 Y42.656 F254
G1 X43.586 Y42.587 F254
G1 X43.481 Y42.477 F254
G1 X43.386 Y42.357 F254
G1 X43.302 Y42.23 F254
G1 X43.229 Y42.097 F254
G1 X43.169 Y41.957 F254
G1 X43.121 Y41.812 F254
G1 X43.089 Y41.663 F254
G1 X43.073 Y41.511 F254
G1 Y41.359 F254
G1 X43.089 Y41.207 F254
G1 X43.121 Y41.058 F254
G1 X43.168 Y40.913 F254
G1 X43.23 Y40.774 F254
G1 X43.306 Y40.642 F254
G1 X43.394 Y40.518 F254
G1 X43.494 Y40.403 F254
G1 X43.604 Y40.297 F254
G1 X43.722 Y40.201 F254
G1 X43.851 Y40.113 F254
G1 X44.006 Y40.022 F254
G1 X44.19 Y39.932 F254
G1 X44.385 Y39.854 F254
G1 X44.626 Y39.777 F254
G1 X44.632 Y39.776 F254
G1 X45.533 Y39.616 F254
G1 X45.743 Y39.586 F254
G1 X45.952 Y39.564 F254
G1 X46.161 Y39.543 F254
G1 X46.231 Y39.538 F254
G1 X46.371 Y39.539 F254
G1 X46.894 Y39.571 F254
G1 X46.929 Y39.577 F254
G1 X47.487 Y39.714 F254
G1 X47.627 Y39.749 F254
G1 X47.766 Y39.803 F254
G1 X48.115 Y39.94 F254
G1 X48.274 Y40.004 F254
G1 X48.325 Y40.03 F254
G1 X49.232 Y40.528 F254
G1 X49.255 Y40.544 F254
G1 X49.511 Y40.755 F254
G1 X49.624 Y40.859 F254
G1 X49.737 Y40.965 F254
G1 X49.846 Y41.083 F254
G1 X49.947 Y41.211 F254
G1 X50.038 Y41.343 F254
G1 X50.116 Y41.478 F254
G1 X50.182 Y41.616 F254
G1 X50.237 Y41.758 F254
G1 X50.28 Y41.904 F254
G1 X50.311 Y42.053 F254
G1 X50.332 Y42.215 F254
G1 X50.342 Y42.396 F254
G1 X50.338 Y42.598 F254
G1 X50.317 Y42.825 F254
G1 X50.276 Y43.07 F254
G1 X50.233 Y43.243 F254
G1 X50.232 Y43.247 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X50.139 Y43.211 I-0.046 J-0.018 F254
G1 X50.146 Y43.193 Z-8.092 F254
G1 X50.152 Y43.178 Z-8.081 F254
G1 X50.156 Y43.168 Z-8.065 F254
G1 X50.157 Y43.164 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X46.502 Y41.755 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X46.503 Y41.751 Z-8.065 F254
G1 X46.506 Y41.741 Z-8.081 F254
G1 X46.511 Y41.725 Z-8.092 F254
G1 X46.517 Y41.707 Z-8.096 F254
G3 X49.511 Y40.755 I1.827 J0.561 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X50.036 Y41.191 F254
G1 X50.054 Y41.209 F254
G1 X50.255 Y41.47 F254
G1 X50.278 Y41.51 F254
G1 X50.366 Y41.679 F254
G1 X50.374 Y41.697 F254
G1 X50.379 Y41.714 F254
G1 X50.472 Y42.22 F254
G1 Y42.237 F254
G1 X50.379 Y42.796 F254
G1 X50.367 Y42.865 F254
G1 X50.318 Y43.005 F254
G1 X50.119 Y43.563 F254
G1 X50.041 Y43.773 F254
G1 X49.771 Y44.471 F254
G1 X49.72 Y44.61 F254
G1 X49.694 Y44.68 F254
G1 X49.671 Y44.75 F254
G1 X49.398 Y45.657 F254
G1 X49.341 Y45.866 F254
G1 X49.331 Y45.936 F254
G1 X49.287 Y46.276 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X49.238 Y46.318 I-0.049 J-0.008 F254
G1 X49.237 F254
G3 X49.204 Y46.305 J-0.05 F254
G1 X49.197 Y46.29 Z-8.093 F254
G1 X49.192 Y46.278 Z-8.085 F254
G1 X49.187 Y46.268 Z-8.073 F254
G1 X49.188 Y46.262 Z-8.06 F254
G1 Y46.26 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X46.804 Y43.134 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X46.8 Y43.136 Z-8.065 F254
G1 X46.79 Y43.14 Z-8.081 F254
G1 X46.775 Y43.146 Z-8.092 F254
G1 X46.757 Y43.153 Z-8.096 F254
G3 X43.655 Y42.656 I-1.133 J-2.857 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X43.192 Y42.274 F254
G1 X43.08 Y42.171 F254
G1 X43.006 Y42.038 F254
G1 X42.952 Y41.895 F254
G1 X42.913 Y41.748 F254
G1 X42.89 Y41.597 F254
G1 X42.881 Y41.445 F254
G1 X42.887 Y41.293 F254
G1 X42.907 Y41.142 F254
G1 X42.942 Y40.993 F254
G1 X42.99 Y40.849 F254
G1 X43.051 Y40.709 F254
G1 X43.124 Y40.575 F254
G1 X43.208 Y40.448 F254
G1 X43.303 Y40.329 F254
G1 X43.407 Y40.218 F254
G1 X43.52 Y40.116 F254
G1 X43.646 Y40.018 F254
G1 X43.795 Y39.919 F254
G1 X43.844 Y39.892 F254
G1 X43.859 Y39.884 F254
G1 X43.876 Y39.879 F254
G1 X43.893 Y39.876 F254
G1 X44.138 Y39.853 F254
G1 X44.347 Y39.827 F254
G1 X44.632 Y39.776 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X44.688 Y39.819 I0.007 J0.05 F254
G3 X44.646 Y39.875 I-0.05 J0.007 F254
G1 X44.627 Y39.878 Z-8.092 F254
G1 X44.611 Y39.88 Z-8.081 F254
G1 X44.6 Y39.882 Z-8.065 F254
G1 X44.596 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X46.358 Y42.624 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X46.354 Y42.626 Z-8.065 F254
G1 X46.344 Y42.63 Z-8.081 F254
G1 X46.329 Y42.637 Z-8.092 F254
G1 X46.312 Y42.645 Z-8.096 F254
G3 X43.192 Y42.274 I-1.248 J-2.809 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X43.091 Y42.19 F254
G1 X42.952 Y42.091 F254
G1 X42.827 Y42.002 F254
G1 X42.76 Y41.866 F254
G1 X42.719 Y41.719 F254
G1 X42.697 Y41.568 F254
G1 X42.691 Y41.416 F254
G1 X42.698 Y41.263 F254
G1 X42.719 Y41.112 F254
G1 X42.753 Y40.964 F254
G1 X42.798 Y40.818 F254
G1 X42.855 Y40.677 F254
G1 X42.923 Y40.541 F254
G1 X43.001 Y40.41 F254
G1 X43.09 Y40.286 F254
G1 X43.188 Y40.169 F254
G1 X43.296 Y40.058 F254
G1 X43.419 Y39.949 F254
G1 X43.433 Y39.939 F254
G1 X43.452 Y39.926 F254
G1 X43.474 Y39.918 F254
G1 X43.497 Y39.914 F254
G1 X43.893 Y39.876 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X43.913 Y39.879 Z-8.045 F254
G1 X43.929 Y39.889 Z-7.994 F254
G1 X43.941 Y39.904 Z-7.944 F254
G1 X43.946 Y39.923 Z-7.893 F254
G3 X43.942 Y39.946 I-0.05 J0.003 F254
G1 X43.726 Y40.445 F254
; MOVEMENT_LINK_DIRECT
G1 X43.246 Y41.552 F254
; MOVEMENT_LEAD_IN
G1 X43.023 Y42.067 F254
G1 X43.02 Y42.073 F254
G1 X43.007 Y42.087 Z-7.944 F254
G1 X42.989 Y42.096 Z-7.994 F254
G1 X42.97 Y42.097 Z-8.045 F254
G1 X42.952 Y42.091 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X42.812 Y42.003 F254
G1 X42.742 Y41.96 F254
G1 X42.617 Y41.873 F254
G1 X42.551 Y41.736 F254
G1 X42.517 Y41.587 F254
G1 X42.504 Y41.435 F254
G1 X42.507 Y41.283 F254
G1 X42.523 Y41.131 F254
G1 X42.551 Y40.981 F254
G1 X42.59 Y40.834 F254
G1 X42.64 Y40.69 F254
G1 X42.701 Y40.55 F254
G1 X42.773 Y40.413 F254
G1 X42.857 Y40.28 F254
G1 X42.951 Y40.151 F254
G1 X43.057 Y40.026 F254
G1 X43.102 Y39.98 F254
G1 X43.125 Y39.962 F254
G1 X43.151 Y39.95 F254
G1 X43.18 Y39.944 F254
G1 X43.497 Y39.914 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X43.516 Y39.916 Z-8.045 F254
G1 X43.533 Y39.926 Z-7.994 F254
G1 X43.544 Y39.942 Z-7.944 F254
G1 X43.549 Y39.961 Z-7.893 F254
G3 X43.546 Y39.981 I-0.05 J0.003 F254
G1 X43.354 Y40.493 F254
; MOVEMENT_LINK_DIRECT
G1 X43.01 Y41.41 F254
; MOVEMENT_LEAD_IN
G1 X42.814 Y41.934 F254
G1 X42.81 Y41.941 F254
G1 X42.798 Y41.956 Z-7.944 F254
G1 X42.78 Y41.964 Z-7.994 F254
G1 X42.761 Y41.966 Z-8.045 F254
G1 X42.742 Y41.96 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X42.533 Y41.83 F254
G1 X42.47 Y41.786 F254
G1 X42.374 Y41.668 F254
G1 X42.332 Y41.521 F254
G1 X42.318 Y41.37 F254
G1 X42.322 Y41.217 F254
G1 X42.339 Y41.066 F254
G1 X42.37 Y40.913 F254
G1 X42.412 Y40.758 F254
G1 X42.467 Y40.604 F254
G1 X42.534 Y40.452 F254
G1 X42.614 Y40.303 F254
G1 X42.705 Y40.158 F254
G1 X42.806 Y40.022 F254
G1 X42.82 Y40.006 F254
G1 X42.848 Y39.982 F254
G1 X42.881 Y39.967 F254
G1 X42.918 Y39.962 F254
G1 X42.952 Y39.963 F254
G1 X43.021 Y39.958 F254
G1 X43.18 Y39.944 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X43.199 Y39.946 Z-8.045 F254
G1 X43.216 Y39.956 Z-7.994 F254
G1 X43.228 Y39.972 Z-7.944 F254
G1 X43.232 Y39.991 Z-7.893 F254
G3 X43.23 Y40.01 I-0.05 J0.003 F254
G1 X43.049 Y40.527 F254
; MOVEMENT_LINK_DIRECT
G1 X42.789 Y41.276 F254
; MOVEMENT_LEAD_IN
G1 X42.605 Y41.803 F254
G1 X42.601 Y41.811 F254
G1 X42.588 Y41.826 Z-7.944 F254
G1 X42.571 Y41.835 Z-7.994 F254
G1 X42.551 Y41.836 Z-8.045 F254
G1 X42.533 Y41.83 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X42.463 Y41.787 F254
G1 X42.355 Y41.723 F254
G1 X42.324 Y41.705 F254
G1 X42.259 Y41.664 F254
G1 X42.177 Y41.536 F254
G1 X42.143 Y41.388 F254
G1 X42.136 Y41.235 F254
G1 X42.146 Y41.083 F254
G1 X42.17 Y40.931 F254
G1 X42.207 Y40.772 F254
G1 X42.257 Y40.612 F254
G1 X42.32 Y40.452 F254
G1 X42.398 Y40.291 F254
G1 X42.489 Y40.132 F254
G1 X42.575 Y40.006 F254
G1 X42.58 Y40.001 F254
G1 X42.607 Y39.977 F254
G1 X42.641 Y39.962 F254
G1 X42.677 Y39.957 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.696 Y39.962 Z-8.045 F254
G1 X42.712 Y39.974 Z-7.994 F254
G1 X42.721 Y39.991 Z-7.944 F254
G1 X42.724 Y40.01 Z-7.893 F254
G1 X42.723 Y40.017 F254
G1 X42.614 Y40.567 F254
; MOVEMENT_LINK_DIRECT
G1 X42.503 Y41.127 F254
; MOVEMENT_LEAD_IN
G1 X42.395 Y41.67 F254
G3 X42.391 Y41.683 I-0.049 J-0.01 F254
G1 X42.379 Y41.698 Z-7.944 F254
G1 X42.362 Y41.708 Z-7.994 F254
G1 X42.342 Y41.71 Z-8.045 F254
G1 X42.324 Y41.705 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X42.153 Y41.609 F254
G1 X42.088 Y41.569 F254
G1 X41.996 Y41.447 F254
G1 X41.961 Y41.299 F254
G1 X41.955 Y41.147 F254
G1 X41.967 Y40.995 F254
G1 X41.992 Y40.845 F254
G1 X42.032 Y40.681 F254
G1 X42.087 Y40.512 F254
G1 X42.157 Y40.34 F254
G1 X42.243 Y40.167 F254
G1 X42.321 Y40.036 F254
G1 X42.345 Y40.003 F254
G1 X42.374 Y39.975 F254
G1 X42.409 Y39.957 F254
G1 X42.449 Y39.952 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.468 Y39.957 Z-8.045 F254
G1 X42.483 Y39.968 Z-7.994 F254
G1 X42.493 Y39.985 Z-7.944 F254
G1 X42.496 Y40.005 Z-7.893 F254
G1 X42.495 Y40.01 F254
G1 X42.4 Y40.564 F254
; MOVEMENT_LINK_DIRECT
G1 X42.319 Y41.029 F254
; MOVEMENT_LEAD_IN
G1 X42.225 Y41.573 F254
G3 X42.22 Y41.588 I-0.049 J-0.009 F254
G1 X42.208 Y41.603 Z-7.944 F254
G1 X42.191 Y41.613 Z-7.994 F254
G1 X42.172 Y41.615 Z-8.045 F254
G1 X42.153 Y41.609 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.975 Y41.51 F254
G1 X41.91 Y41.469 F254
G1 X41.815 Y41.35 F254
G1 X41.781 Y41.202 F254
G1 X41.776 Y41.049 F254
G1 X41.79 Y40.898 F254
G1 X41.817 Y40.748 F254
G1 X41.86 Y40.58 F254
G1 X41.921 Y40.402 F254
G1 X41.998 Y40.219 F254
G1 X42.069 Y40.082 F254
G1 X42.115 Y40.006 F254
G1 X42.144 Y39.974 F254
G1 X42.182 Y39.953 F254
G1 X42.225 Y39.946 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.244 Y39.951 Z-8.045 F254
G1 X42.259 Y39.963 Z-7.994 F254
G1 X42.269 Y39.98 Z-7.944 F254
G1 X42.272 Y39.999 Z-7.893 F254
G1 X42.271 Y40.004 F254
G1 X42.186 Y40.56 F254
; MOVEMENT_LINK_DIRECT
G1 X42.13 Y40.928 F254
; MOVEMENT_LEAD_IN
G1 X42.047 Y41.473 F254
G3 X42.042 Y41.488 I-0.049 J-0.008 F254
G1 X42.03 Y41.504 Z-7.944 F254
G1 X42.013 Y41.513 Z-7.994 F254
G1 X41.993 Y41.515 Z-8.045 F254
G1 X41.975 Y41.51 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.778 Y41.4 F254
G1 X41.714 Y41.359 F254
G1 X41.63 Y41.232 F254
G1 X41.601 Y41.082 F254
G1 X41.6 Y40.93 F254
G1 X41.618 Y40.778 F254
G1 X41.648 Y40.629 F254
G1 X41.696 Y40.457 F254
G1 X41.763 Y40.27 F254
G1 X41.834 Y40.113 F254
G1 X41.891 Y40.007 F254
G1 X41.919 Y39.971 F254
G1 X41.959 Y39.948 F254
G1 X42.004 Y39.941 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X42.023 Y39.946 Z-8.045 F254
G1 X42.038 Y39.958 Z-7.994 F254
G1 X42.048 Y39.975 Z-7.944 F254
G1 X42.051 Y39.994 Z-7.893 F254
G1 X42.05 Y39.998 F254
G1 X41.969 Y40.556 F254
; MOVEMENT_LINK_DIRECT
G1 X41.93 Y40.818 F254
; MOVEMENT_LEAD_IN
G1 X41.85 Y41.363 F254
G3 X41.845 Y41.378 I-0.049 J-0.007 F254
G1 X41.833 Y41.394 Z-7.944 F254
G1 X41.816 Y41.403 Z-7.994 F254
G1 X41.797 Y41.405 Z-8.045 F254
G1 X41.778 Y41.4 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.587 Y41.29 F254
G1 X41.523 Y41.249 F254
G1 X41.447 Y41.117 F254
G1 X41.423 Y40.966 F254
G1 X41.426 Y40.814 F254
G1 X41.446 Y40.663 F254
G1 X41.479 Y40.513 F254
G1 X41.532 Y40.334 F254
G1 X41.599 Y40.159 F254
G1 X41.663 Y40.021 F254
G1 X41.682 Y39.992 F254
G1 X41.711 Y39.962 F254
G1 X41.748 Y39.942 F254
G1 X41.789 Y39.936 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.808 Y39.941 Z-8.045 F254
G1 X41.824 Y39.953 Z-7.994 F254
G1 X41.834 Y39.97 Z-7.944 F254
G1 X41.836 Y39.989 Z-7.893 F254
G1 Y39.993 F254
G1 X41.758 Y40.551 F254
; MOVEMENT_LINK_DIRECT
G1 X41.736 Y40.708 F254
; MOVEMENT_LEAD_IN
G1 X41.66 Y41.253 F254
G3 X41.655 Y41.269 I-0.05 J-0.007 F254
G1 X41.643 Y41.285 Z-7.944 F254
G1 X41.626 Y41.294 Z-7.994 F254
G1 X41.606 Y41.296 Z-8.045 F254
G1 X41.587 Y41.29 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.417 Y41.191 F254
G1 X41.353 Y41.149 F254
G1 X41.272 Y41.02 F254
G1 X41.247 Y40.87 F254
G1 X41.25 Y40.717 F254
G1 X41.271 Y40.566 F254
G1 X41.309 Y40.405 F254
G1 X41.363 Y40.229 F254
G1 X41.419 Y40.087 F254
G1 X41.463 Y39.999 F254
G1 X41.492 Y39.962 F254
G1 X41.533 Y39.938 F254
G1 X41.579 Y39.93 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.598 Y39.936 Z-8.045 F254
G1 X41.613 Y39.948 Z-7.994 F254
G1 X41.623 Y39.964 Z-7.944 F254
G1 X41.626 Y39.984 Z-7.893 F254
G1 X41.625 Y39.986 F254
G1 X41.56 Y40.548 F254
; MOVEMENT_LINK_DIRECT
G1 X41.553 Y40.607 F254
; MOVEMENT_LEAD_IN
G1 X41.49 Y41.152 F254
G3 X41.485 Y41.17 I-0.05 J-0.006 F254
G1 X41.472 Y41.185 Z-7.944 F254
G1 X41.455 Y41.195 Z-7.994 F254
G1 X41.435 Y41.196 Z-8.045 F254
G1 X41.417 Y41.191 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.239 Y41.087 F254
G1 X41.175 Y41.045 F254
G1 X41.095 Y40.915 F254
G1 X41.072 Y40.764 F254
G1 X41.077 Y40.612 F254
G1 X41.099 Y40.461 F254
G1 X41.138 Y40.3 F254
G1 X41.186 Y40.153 F254
G1 X41.243 Y40.012 F254
G1 X41.266 Y39.976 F254
G1 X41.296 Y39.943 F254
G1 X41.336 Y39.922 F254
G1 X41.38 Y39.917 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.399 Y39.923 Z-8.045 F254
G1 X41.414 Y39.936 Z-7.994 F254
G1 X41.423 Y39.953 Z-7.944 F254
G1 X41.425 Y39.972 Z-7.893 F254
G1 X41.369 Y40.503 F254
; MOVEMENT_LEAD_IN
G1 X41.312 Y41.048 F254
G3 X41.306 Y41.066 I-0.05 J-0.005 F254
G1 X41.294 Y41.081 Z-7.944 F254
G1 X41.277 Y41.09 Z-7.994 F254
G1 X41.257 Y41.092 Z-8.045 F254
G1 X41.239 Y41.087 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X41.068 Y40.987 F254
G1 X41.004 Y40.945 F254
G1 X40.921 Y40.817 F254
G1 X40.897 Y40.666 F254
G1 X40.903 Y40.514 F254
G1 X40.926 Y40.364 F254
G1 X40.963 Y40.216 F254
G1 X41.011 Y40.071 F254
G1 X41.056 Y39.974 F254
G1 X41.086 Y39.933 F254
G1 X41.13 Y39.908 F254
G1 X41.18 Y39.902 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X41.198 Y39.908 Z-8.046 F254
G1 X41.213 Y39.92 Z-7.996 F254
G1 X41.222 Y39.937 Z-7.947 F254
G1 X41.224 Y39.956 Z-7.897 F254
G1 Y39.957 Z-7.893 F254
G1 X41.187 Y40.402 F254
; MOVEMENT_LEAD_IN
G1 X41.141 Y40.947 F254
G3 X41.135 Y40.966 I-0.05 J-0.004 F254
G1 X41.123 Y40.981 Z-7.944 F254
G1 X41.106 Y40.99 Z-7.994 F254
G1 X41.086 Y40.992 Z-8.045 F254
G1 X41.068 Y40.987 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.89 Y40.883 F254
G1 X40.826 Y40.841 F254
G1 X40.746 Y40.711 F254
G1 X40.724 Y40.56 F254
G1 X40.731 Y40.408 F254
G1 X40.756 Y40.258 F254
G1 X40.795 Y40.111 F254
G1 X40.849 Y39.968 F254
G1 X40.866 Y39.942 F254
G1 X40.897 Y39.91 F254
G1 X40.936 Y39.89 F254
G1 X40.98 Y39.886 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.998 Y39.892 Z-8.047 F254
G1 X41.013 Y39.904 Z-7.997 F254
G1 X41.022 Y39.92 Z-7.948 F254
G1 X41.025 Y39.939 Z-7.899 F254
G1 X41.024 Y39.941 Z-7.893 F254
G1 X41 Y40.297 F254
; MOVEMENT_LEAD_IN
G1 X40.963 Y40.842 F254
G3 X40.957 Y40.862 I-0.05 J-0.003 F254
G1 X40.945 Y40.877 Z-7.944 F254
G1 X40.928 Y40.886 Z-7.994 F254
G1 X40.908 Y40.888 Z-8.045 F254
G1 X40.89 Y40.883 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.719 Y40.783 F254
G1 X40.655 Y40.741 F254
G1 X40.573 Y40.613 F254
G1 X40.551 Y40.462 F254
G1 X40.558 Y40.31 F254
G1 X40.585 Y40.16 F254
G1 X40.627 Y40.013 F254
G1 X40.663 Y39.94 F254
G1 X40.693 Y39.901 F254
G1 X40.736 Y39.876 F254
G1 X40.785 Y39.871 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.803 Y39.876 Z-8.047 F254
G1 X40.818 Y39.888 Z-7.999 F254
G1 X40.827 Y39.904 Z-7.95 F254
G1 X40.829 Y39.922 Z-7.902 F254
G1 Y39.926 Z-7.893 F254
G1 X40.817 Y40.196 F254
; MOVEMENT_LEAD_IN
G1 X40.792 Y40.741 F254
G3 X40.786 Y40.762 I-0.05 J-0.002 F254
G1 X40.774 Y40.777 Z-7.944 F254
G1 X40.757 Y40.787 Z-7.994 F254
G1 X40.737 Y40.788 Z-8.045 F254
G1 X40.719 Y40.783 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.541 Y40.679 F254
G1 X40.477 Y40.637 F254
G1 X40.398 Y40.506 F254
G1 X40.378 Y40.355 F254
G1 X40.388 Y40.203 F254
G1 X40.417 Y40.054 F254
G1 X40.471 Y39.911 F254
G1 X40.476 Y39.904 F254
G1 X40.506 Y39.875 F254
G1 X40.544 Y39.858 F254
G1 X40.586 Y39.855 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.603 Y39.86 Z-8.048 F254
G1 X40.618 Y39.871 Z-8 F254
G1 X40.627 Y39.887 Z-7.953 F254
G1 X40.63 Y39.905 Z-7.905 F254
G1 Y39.91 Z-7.893 F254
G1 X40.626 Y40.092 F254
; MOVEMENT_LEAD_IN
G1 X40.614 Y40.636 F254
G3 X40.608 Y40.658 I-0.05 J-0.001 F254
G1 X40.596 Y40.673 Z-7.944 F254
G1 X40.579 Y40.683 Z-7.994 F254
G1 X40.559 Y40.684 Z-8.045 F254
G1 X40.541 Y40.679 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.37 Y40.579 F254
G1 X40.306 Y40.537 F254
G1 X40.226 Y40.407 F254
G1 X40.206 Y40.256 F254
G1 X40.217 Y40.104 F254
G1 X40.254 Y39.956 F254
G1 X40.278 Y39.908 F254
G1 X40.309 Y39.87 F254
G1 X40.351 Y39.846 F254
G1 X40.4 Y39.84 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.417 Y39.845 Z-8.049 F254
G1 X40.431 Y39.856 Z-8.002 F254
G1 X40.441 Y39.872 Z-7.955 F254
G1 X40.444 Y39.89 Z-7.907 F254
G1 Y39.895 Z-7.893 F254
G1 Y39.992 F254
; MOVEMENT_LEAD_IN
G1 Y40.535 F254
G3 X40.438 Y40.559 I-0.05 F254
G1 X40.425 Y40.574 Z-7.944 F254
G1 X40.408 Y40.583 Z-7.994 F254
G1 X40.388 Y40.585 Z-8.045 F254
G1 X40.37 Y40.579 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.189 Y40.473 F254
G1 X40.148 Y40.446 F254
G1 X40.059 Y40.323 F254
G1 X40.036 Y40.172 F254
G1 X40.049 Y40.02 F254
G1 X40.096 Y39.874 F254
G1 X40.126 Y39.845 F254
G1 X40.164 Y39.828 F254
G1 X40.205 Y39.824 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.223 Y39.83 Z-8.05 F254
G1 X40.237 Y39.84 Z-8.003 F254
G1 X40.246 Y39.856 Z-7.957 F254
G1 X40.25 Y39.873 Z-7.91 F254
G1 Y39.88 Z-7.893 F254
G1 Y39.886 F254
; MOVEMENT_LEAD_IN
G1 X40.262 Y40.428 F254
G3 X40.256 Y40.453 I-0.05 J0.001 F254
G1 X40.244 Y40.468 Z-7.944 F254
G1 X40.227 Y40.477 Z-7.994 F254
G1 X40.207 Y40.479 Z-8.045 F254
G1 X40.189 Y40.473 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X40.16 Y40.456 F254
G1 X40.091 Y40.408 F254
G1 X40.021 Y40.357 F254
G1 X39.961 Y40.31 F254
G1 X39.886 Y40.178 F254
G1 X39.876 Y40.025 F254
G1 X39.903 Y39.876 F254
G1 X39.908 Y39.868 F254
G1 X39.939 Y39.835 F254
G1 X39.979 Y39.815 F254
G1 X40.024 Y39.81 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X40.04 Y39.815 Z-8.051 F254
G1 X40.054 Y39.825 Z-8.006 F254
G1 X40.064 Y39.84 Z-7.961 F254
G1 X40.068 Y39.856 Z-7.916 F254
; MOVEMENT_LEAD_IN
G1 Y39.865 Z-7.893 F254
G1 X40.099 Y40.313 F254
G3 X40.09 Y40.344 I-0.05 J0.003 F254
G1 X40.076 Y40.358 Z-7.944 F254
G1 X40.058 Y40.365 Z-7.994 F254
G1 X40.039 Z-8.045 F254
G1 X40.021 Y40.357 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.85 Y40.232 F254
G1 X39.791 Y40.184 F254
G1 X39.722 Y40.048 F254
G1 X39.72 Y39.896 F254
G1 X39.732 Y39.871 F254
G1 X39.761 Y39.83 F254
G1 X39.804 Y39.805 F254
G1 X39.854 Y39.798 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X39.861 Y39.799 Z-8.077 F254
; MOVEMENT_LEAD_IN
G1 X39.875 Y39.805 Z-8.037 F254
G1 X39.887 Y39.815 Z-7.997 F254
G1 X39.895 Y39.828 Z-7.957 F254
G1 X39.899 Y39.843 Z-7.917 F254
G1 Y39.853 Z-7.893 F254
G1 X39.928 Y40.187 F254
G3 X39.92 Y40.219 I-0.05 J0.004 F254
G1 X39.906 Y40.233 Z-7.944 F254
G1 X39.888 Y40.24 Z-7.994 F254
G1 X39.868 Z-8.045 F254
G1 X39.85 Y40.232 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.698 Y40.12 F254
G1 X39.639 Y40.072 F254
G1 X39.603 Y40.005 F254
G1 X39.589 Y39.93 F254
G1 X39.593 Y39.899 F254
G1 X39.615 Y39.842 F254
G1 X39.663 Y39.802 F254
G1 X39.723 Y39.79 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X39.741 Y39.795 Z-8.049 F254
G1 X39.755 Y39.805 Z-8.002 F254
G1 X39.765 Y39.82 Z-7.955 F254
G1 X39.769 Y39.838 Z-7.908 F254
G1 Y39.844 Z-7.893 F254
G1 X39.776 Y40.078 F254
G3 X39.768 Y40.107 I-0.05 J0.002 F254
G1 X39.754 Y40.121 Z-7.944 F254
G1 X39.736 Y40.128 Z-7.994 F254
G1 X39.716 Z-8.045 F254
G1 X39.698 Y40.12 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.568 Y40.025 F254
G1 X39.541 Y40.004 F254
G1 X39.532 Y39.998 F254
G1 X39.503 Y39.974 F254
G1 X39.483 Y39.901 F254
G1 X39.484 Y39.894 F254
G1 X39.506 Y39.837 F254
G1 X39.553 Y39.797 F254
G1 X39.613 Y39.785 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X39.632 Y39.79 Z-8.045 F254
G1 X39.647 Y39.802 Z-7.994 F254
G1 X39.657 Y39.819 Z-7.944 F254
G1 X39.659 Y39.838 Z-7.893 F254
G3 X39.656 Y39.853 I-0.05 J-0.004 F254
G1 X39.607 Y39.975 F254
G3 X39.602 Y39.985 I-0.046 J-0.018 F254
G1 X39.588 Y39.999 Z-7.944 F254
G1 X39.57 Y40.006 Z-7.994 F254
G1 X39.55 Z-8.045 F254
G1 X39.532 Y39.998 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.463 Y39.947 F254
G1 X39.446 Y39.935 F254
G1 X39.417 Y39.913 F254
G1 X39.393 Y39.894 F254
G1 X39.412 Y39.835 F254
G1 X39.457 Y39.794 F254
G1 X39.517 Y39.781 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X39.534 Y39.786 Z-8.05 F254
G1 X39.548 Y39.797 Z-8.003 F254
G1 X39.556 Y39.813 Z-7.957 F254
G1 X39.559 Y39.837 Z-7.893 F254
G3 X39.492 Y39.926 I-0.091 J0.001 F254
G1 X39.466 Y39.929 Z-7.961 F254
G1 X39.44 Y39.925 Z-8.028 F254
G1 X39.417 Y39.913 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X39.373 Y39.88 F254
G1 X39.363 Y39.865 F254
G1 X39.359 Y39.847 F254
G1 X39.361 Y39.83 F254
G1 X39.371 Y39.812 F254
G1 X39.382 Y39.795 F254
G1 X39.393 Y39.785 F254
G1 X39.41 Y39.778 F254
G1 X39.428 Y39.777 F254
G1 X39.742 Y39.791 F254
G1 X39.951 Y39.804 F254
G1 X41.347 Y39.915 F254
G1 X41.556 Y39.93 F254
G1 X41.73 Y39.935 F254
G1 X42.882 Y39.962 F254
G1 X42.918 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X42.965 Y40.015 I-0.003 J0.05 F254
G3 X42.912 Y40.062 I-0.05 J-0.003 F254
G1 X42.893 Y40.061 Z-8.092 F254
G1 X42.877 Y40.06 Z-8.081 F254
G1 X42.866 Z-8.065 F254
G1 X42.862 Y40.059 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X93.538 Y48.638 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X93.535 Y48.636 Z-8.065 F254
G1 X93.526 Y48.629 Z-8.081 F254
G1 X93.513 Y48.62 Z-8.092 F254
G1 X93.498 Y48.608 Z-8.096 F254
G3 X91.517 Y46.169 I3.77 J-5.085 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X91.476 Y46.076 F254
G1 X91.378 Y45.866 F254
G1 X91.24 Y45.587 F254
G1 X91.18 Y45.447 F254
G1 X91.157 Y45.296 F254
G1 X91.161 Y45.144 F254
G1 X91.183 Y44.993 F254
G1 X91.22 Y44.846 F254
G1 X91.274 Y44.703 F254
G1 X91.343 Y44.567 F254
G1 X91.425 Y44.438 F254
G1 X91.519 Y44.319 F254
G1 X91.623 Y44.208 F254
G1 X91.738 Y44.107 F254
G1 X91.861 Y44.017 F254
G1 X91.991 Y43.938 F254
G1 X92.128 Y43.872 F254
G1 X92.271 Y43.819 F254
G1 X92.418 Y43.779 F254
G1 X92.569 Y43.75 F254
G1 X92.74 Y43.731 F254
G1 X92.928 Y43.724 F254
G1 X93.06 Y43.729 F254
G1 X93.079 Y43.731 F254
G1 X93.098 Y43.736 F254
G1 X93.115 Y43.744 F254
G1 X93.471 Y43.937 F254
G1 X93.558 Y43.982 F254
G1 X93.6 Y44.003 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X93.551 Y44.091 I-0.024 J0.044 F254
G1 X93.535 Y44.082 Z-8.092 F254
G1 X93.521 Y44.074 Z-8.081 F254
G1 X93.511 Y44.069 Z-8.065 F254
G1 X93.508 Y44.067 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X91.434 Y45.985 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X91.433 Y45.982 Z-8.065 F254
G1 X91.428 Y45.972 Z-8.081 F254
G1 X91.421 Y45.957 Z-8.092 F254
G1 X91.414 Y45.939 Z-8.096 F254
G2 X91.24 Y45.587 I-5.133 J2.305 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X91.168 Y45.441 F254
G1 X91.079 Y45.268 F254
G1 X91.016 Y45.13 F254
G1 X91.01 Y44.977 F254
G1 X91.035 Y44.827 F254
G1 X91.081 Y44.682 F254
G1 X91.141 Y44.542 F254
G1 X91.215 Y44.409 F254
G1 X91.302 Y44.283 F254
G1 X91.399 Y44.165 F254
G1 X91.505 Y44.056 F254
G1 X91.62 Y43.956 F254
G1 X91.743 Y43.866 F254
G1 X91.873 Y43.786 F254
G1 X92.008 Y43.717 F254
G1 X92.149 Y43.659 F254
G1 X92.294 Y43.612 F254
G1 X92.445 Y43.576 F254
G1 X92.612 Y43.549 F254
G1 X92.699 Y43.541 F254
G1 X92.725 Y43.542 F254
G1 X92.75 Y43.548 F254
G1 X92.773 Y43.559 F254
G1 X93.115 Y43.744 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X93.112 Y43.832 I-0.025 J0.043 F254
G1 X93.101 Y43.834 Z-8.095 F254
G1 X93.09 Y43.837 Z-8.09 F254
G1 X93.076 Y43.833 Z-8.079 F254
G1 X93.068 Y43.831 Z-8.064 F254
G1 X93.064 Y43.83 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z5.08 F254
G1 X93.855 Y46.83 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X93.851 Z-8.065 F254
G1 X93.84 Y46.831 Z-8.081 F254
G1 X93.824 Z-8.092 F254
G1 X93.805 Z-8.096 F254
G3 X91.079 Y45.268 I-0.049 J-3.073 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.935 Y44.99 F254
G1 X90.903 Y44.921 F254
G1 X90.885 Y44.77 F254
G1 X90.914 Y44.62 F254
G1 X90.967 Y44.477 F254
G1 X91.036 Y44.341 F254
G1 X91.118 Y44.213 F254
G1 X91.21 Y44.091 F254
G1 X91.312 Y43.978 F254
G1 X91.421 Y43.872 F254
G1 X91.539 Y43.775 F254
G1 X91.664 Y43.688 F254
G1 X91.795 Y43.609 F254
G1 X91.933 Y43.54 F254
G1 X92.078 Y43.481 F254
G1 X92.231 Y43.43 F254
G1 X92.399 Y43.389 F254
G1 X92.477 Y43.375 F254
G1 X92.515 F254
G1 X92.552 Y43.386 F254
G1 X92.583 Y43.407 F254
G1 X92.675 Y43.494 F254
G1 X92.704 Y43.516 F254
G1 X92.773 Y43.559 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X92.787 Y43.573 Z-8.045 F254
G1 X92.795 Y43.591 Z-7.994 F254
G1 Y43.61 Z-7.944 F254
G1 X92.787 Y43.628 Z-7.893 F254
G3 X92.776 Y43.64 I-0.042 J-0.028 F254
G1 X92.34 Y43.977 F254
; MOVEMENT_LINK_DIRECT
G1 X91.453 Y44.663 F254
; MOVEMENT_LEAD_IN
G1 X91.009 Y45.005 F254
G1 X91.003 Y45.009 F254
G1 X90.985 Y45.015 Z-7.944 F254
G1 X90.965 Y45.014 Z-7.994 F254
G1 X90.948 Y45.005 Z-8.045 F254
G1 X90.935 Y44.99 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.82 Y44.768 F254
G1 X90.788 Y44.698 F254
G1 X90.773 Y44.547 F254
G1 X90.809 Y44.399 F254
G1 X90.871 Y44.259 F254
G1 X90.948 Y44.128 F254
G1 X91.036 Y44.004 F254
G1 X91.135 Y43.886 F254
G1 X91.244 Y43.774 F254
G1 X91.363 Y43.669 F254
G1 X91.492 Y43.57 F254
G1 X91.63 Y43.481 F254
G1 X91.776 Y43.4 F254
G1 X91.93 Y43.329 F254
G1 X92.092 Y43.269 F254
G1 X92.239 Y43.227 F254
G1 X92.301 Y43.214 F254
G1 X92.341 Y43.212 F254
G1 X92.379 Y43.223 F254
G1 X92.412 Y43.246 F254
G1 X92.583 Y43.407 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X92.594 Y43.423 Z-8.045 F254
G1 X92.598 Y43.443 Z-7.994 F254
G1 X92.594 Y43.462 Z-7.944 F254
G1 X92.583 Y43.478 Z-7.893 F254
G1 X92.578 Y43.482 F254
G1 X92.134 Y43.825 F254
; MOVEMENT_LINK_DIRECT
G1 X91.337 Y44.44 F254
; MOVEMENT_LEAD_IN
G1 X90.894 Y44.783 F254
G1 X90.888 Y44.787 F254
G1 X90.869 Y44.793 Z-7.944 F254
G1 X90.85 Y44.791 Z-7.994 F254
G1 X90.832 Y44.783 Z-8.045 F254
G1 X90.82 Y44.768 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.719 Y44.572 F254
G1 X90.688 Y44.502 F254
G1 X90.665 Y44.351 F254
G1 X90.704 Y44.204 F254
G1 X90.769 Y44.066 F254
G1 X90.85 Y43.937 F254
G1 X90.942 Y43.816 F254
G1 X91.047 Y43.698 F254
G1 X91.163 Y43.585 F254
G1 X91.293 Y43.476 F254
G1 X91.436 Y43.374 F254
G1 X91.588 Y43.28 F254
G1 X91.75 Y43.196 F254
G1 X91.92 Y43.124 F254
G1 X92.064 Y43.075 F254
G1 X92.131 Y43.058 F254
G1 X92.172 Y43.055 F254
G1 X92.212 Y43.066 F254
G1 X92.246 Y43.089 F254
G1 X92.412 Y43.246 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X92.423 Y43.262 Z-8.045 F254
G1 X92.426 Y43.281 Z-7.994 F254
G1 X92.422 Y43.3 Z-7.944 F254
G1 X92.411 Y43.316 Z-7.893 F254
G1 X92.407 Y43.32 F254
G1 X91.965 Y43.667 F254
; MOVEMENT_LINK_DIRECT
G1 X91.234 Y44.241 F254
; MOVEMENT_LEAD_IN
G1 X90.794 Y44.587 F254
G1 X90.787 Y44.591 F254
G1 X90.769 Y44.597 Z-7.944 F254
G1 X90.749 Y44.596 Z-7.994 F254
G1 X90.732 Y44.587 Z-8.045 F254
G1 X90.719 Y44.572 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.61 Y44.358 F254
G1 X90.579 Y44.288 F254
G1 X90.566 Y44.137 F254
G1 X90.611 Y43.991 F254
G1 X90.683 Y43.856 F254
G1 X90.769 Y43.731 F254
G1 X90.867 Y43.611 F254
G1 X90.982 Y43.49 F254
G1 X91.109 Y43.375 F254
G1 X91.25 Y43.265 F254
G1 X91.407 Y43.16 F254
G1 X91.575 Y43.065 F254
G1 X91.754 Y42.98 F254
G1 X91.896 Y42.925 F254
G1 X91.966 Y42.906 F254
G1 X92.008 Y42.902 F254
G1 X92.05 Y42.912 F254
G1 X92.085 Y42.936 F254
G1 X92.246 Y43.089 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X92.257 Y43.105 Z-8.045 F254
G1 X92.261 Y43.124 Z-7.994 F254
G1 X92.257 Y43.144 Z-7.944 F254
G1 X92.246 Y43.16 Z-7.893 F254
G1 X92.241 Y43.164 F254
G1 X91.798 Y43.508 F254
; MOVEMENT_LINK_DIRECT
G1 X91.127 Y44.03 F254
; MOVEMENT_LEAD_IN
G1 X90.685 Y44.373 F254
G1 X90.678 Y44.378 F254
G1 X90.66 Y44.383 Z-7.944 F254
G1 X90.64 Y44.382 Z-7.994 F254
G1 X90.623 Y44.373 Z-8.045 F254
G1 X90.61 Y44.358 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.506 Y44.153 F254
G1 X90.474 Y44.083 F254
G1 X90.469 Y43.931 F254
G1 X90.52 Y43.787 F254
G1 X90.595 Y43.655 F254
G1 X90.685 Y43.532 F254
G1 X90.788 Y43.413 F254
G1 X90.903 Y43.298 F254
G1 X91.041 Y43.179 F254
G1 X91.197 Y43.063 F254
G1 X91.369 Y42.955 F254
G1 X91.553 Y42.857 F254
G1 X91.692 Y42.795 F254
G1 X91.836 Y42.744 F254
G1 X91.851 Y42.742 F254
G1 X91.893 Y42.745 F254
G1 X91.931 Y42.761 F254
G1 X91.963 Y42.789 F254
G1 X92.053 Y42.899 F254
G1 X92.076 Y42.927 F254
G1 X92.085 Y42.936 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X92.096 Y42.952 Z-8.045 F254
G1 X92.099 Y42.972 Z-7.994 F254
G1 X92.096 Y42.991 Z-7.944 F254
G1 X92.085 Y43.007 Z-7.893 F254
G1 X92.08 Y43.011 F254
G1 X91.635 Y43.354 F254
; MOVEMENT_LINK_DIRECT
G1 X91.023 Y43.826 F254
; MOVEMENT_LEAD_IN
G1 X90.58 Y44.168 F254
G1 X90.574 Y44.172 F254
G1 X90.555 Y44.178 Z-7.944 F254
G1 X90.536 Y44.177 Z-7.994 F254
G1 X90.518 Y44.168 Z-8.045 F254
G1 X90.506 Y44.153 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.401 Y43.948 F254
G1 X90.37 Y43.878 F254
G1 X90.375 Y43.726 F254
G1 X90.432 Y43.584 F254
G1 X90.511 Y43.454 F254
G1 X90.604 Y43.334 F254
G1 X90.71 Y43.218 F254
G1 X90.834 Y43.1 F254
G1 X90.984 Y42.977 F254
G1 X91.154 Y42.858 F254
G1 X91.34 Y42.746 F254
G1 X91.507 Y42.663 F254
G1 X91.648 Y42.605 F254
G1 X91.712 Y42.589 F254
G1 X91.759 Y42.587 F254
G1 X91.803 Y42.602 F254
G1 X91.839 Y42.633 F254
G1 X91.963 Y42.789 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X91.971 Y42.807 Z-8.045 F254
G1 X91.972 Y42.826 Z-7.995 F254
G1 X91.966 Y42.844 Z-7.944 F254
G1 X91.953 Y42.859 Z-7.893 F254
G1 X91.952 F254
G1 X91.498 Y43.199 F254
; MOVEMENT_LINK_DIRECT
G1 X90.924 Y43.628 F254
; MOVEMENT_LEAD_IN
G1 X90.474 Y43.963 F254
G1 X90.469 Y43.967 F254
G1 X90.45 Y43.973 Z-7.944 F254
G1 X90.431 Y43.971 Z-7.994 F254
G1 X90.413 Y43.962 Z-8.045 F254
G1 X90.401 Y43.948 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.312 Y43.773 F254
G1 X90.28 Y43.703 F254
G1 X90.276 Y43.551 F254
G1 X90.331 Y43.409 F254
G1 X90.411 Y43.279 F254
G1 X90.504 Y43.159 F254
G1 X90.612 Y43.044 F254
G1 X90.748 Y42.918 F254
G1 X90.909 Y42.79 F254
G1 X91.09 Y42.666 F254
G1 X91.271 Y42.561 F254
G1 X91.409 Y42.494 F254
G1 X91.55 Y42.438 F254
G1 X91.592 Y42.43 F254
G1 X91.638 F254
G1 X91.68 Y42.445 F254
G1 X91.714 Y42.475 F254
G1 X91.839 Y42.633 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X91.847 Y42.65 Z-8.045 F254
G1 X91.848 Y42.67 Z-7.995 F254
G1 X91.842 Y42.688 Z-7.944 F254
G1 X91.829 Y42.703 Z-7.894 F254
G1 Z-7.893 F254
G1 X91.375 Y43.044 F254
; MOVEMENT_LINK_DIRECT
G1 X90.833 Y43.451 F254
; MOVEMENT_LEAD_IN
G1 X90.385 Y43.788 F254
G1 X90.38 Y43.792 F254
G1 X90.361 Y43.798 Z-7.944 F254
G1 X90.342 Y43.796 Z-7.994 F254
G1 X90.324 Y43.788 Z-8.045 F254
G1 X90.312 Y43.773 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.221 Y43.595 F254
G1 X90.19 Y43.525 F254
G1 X90.179 Y43.373 F254
G1 X90.233 Y43.231 F254
G1 X90.313 Y43.101 F254
G1 X90.408 Y42.982 F254
G1 X90.521 Y42.864 F254
G1 X90.665 Y42.734 F254
G1 X90.835 Y42.601 F254
G1 X91.019 Y42.479 F254
G1 X91.185 Y42.385 F254
G1 X91.323 Y42.32 F254
G1 X91.466 Y42.268 F254
G1 X91.476 Y42.267 F254
G1 X91.517 Y42.27 F254
G1 X91.555 Y42.286 F254
G1 X91.586 Y42.314 F254
G1 X91.714 Y42.475 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X91.722 Y42.493 Z-8.046 F254
G1 X91.723 Y42.512 Z-7.995 F254
G1 X91.717 Y42.53 Z-7.945 F254
G1 X91.704 Y42.545 Z-7.894 F254
G1 X91.703 Z-7.893 F254
G1 X91.251 Y42.887 F254
; MOVEMENT_LINK_DIRECT
G1 X90.742 Y43.272 F254
; MOVEMENT_LEAD_IN
G1 X90.295 Y43.61 F254
G1 X90.289 Y43.614 F254
G1 X90.27 Y43.62 Z-7.944 F254
G1 X90.251 Y43.619 Z-7.994 F254
G1 X90.233 Y43.61 Z-8.045 F254
G1 X90.221 Y43.595 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.122 Y43.4 F254
G1 X90.091 Y43.331 F254
G1 X90.088 Y43.178 F254
G1 X90.145 Y43.037 F254
G1 X90.228 Y42.909 F254
G1 X90.325 Y42.792 F254
G1 X90.441 Y42.674 F254
G1 X90.593 Y42.541 F254
G1 X90.768 Y42.409 F254
G1 X90.946 Y42.294 F254
G1 X91.101 Y42.21 F254
G1 X91.24 Y42.147 F254
G1 X91.326 Y42.118 F254
G1 X91.376 Y42.112 F254
G1 X91.425 Y42.127 F254
G1 X91.463 Y42.159 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X91.471 Y42.175 Z-8.049 F254
G1 X91.473 Y42.193 Z-8.002 F254
G1 X91.468 Y42.211 Z-7.955 F254
G1 X91.457 Y42.225 Z-7.908 F254
G1 X91.453 Y42.229 Z-7.893 F254
G1 X91.04 Y42.619 F254
; MOVEMENT_LINK_DIRECT
G1 X90.603 Y43.031 F254
; MOVEMENT_LEAD_IN
G1 X90.2 Y43.412 F254
G3 X90.19 Y43.42 I-0.034 J-0.036 F254
G1 X90.171 Y43.426 Z-7.944 F254
G1 X90.152 Y43.424 Z-7.994 F254
G1 X90.134 Y43.415 Z-8.045 F254
G1 X90.122 Y43.4 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X90.028 Y43.214 F254
G1 X89.997 Y43.145 F254
G1 X89.996 Y42.992 F254
G1 X90.055 Y42.852 F254
G1 X90.139 Y42.725 F254
G1 X90.237 Y42.608 F254
G1 X90.361 Y42.486 F254
G1 X90.518 Y42.351 F254
G1 X90.693 Y42.223 F254
G1 X90.865 Y42.115 F254
G1 X91.01 Y42.038 F254
G1 X91.149 Y41.977 F254
G1 X91.211 Y41.961 F254
G1 X91.259 Y41.958 F254
G1 X91.304 Y41.973 F254
G1 X91.34 Y42.004 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X91.348 Y42.02 Z-8.049 F254
G1 X91.35 Y42.038 Z-8.002 F254
G1 X91.345 Y42.056 Z-7.955 F254
G1 X91.334 Y42.07 Z-7.908 F254
G1 X91.33 Y42.074 Z-7.893 F254
G1 X90.917 Y42.463 F254
; MOVEMENT_LINK_DIRECT
G1 X90.51 Y42.847 F254
; MOVEMENT_LEAD_IN
G1 X90.106 Y43.227 F254
G3 X90.096 Y43.234 I-0.034 J-0.036 F254
G1 X90.077 Y43.24 Z-7.944 F254
G1 X90.058 Y43.238 Z-7.994 F254
G1 X90.04 Y43.229 Z-8.045 F254
G1 X90.028 Y43.214 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.982 Y43.124 F254
G1 X89.959 Y43.075 F254
G1 X89.93 Y43.005 F254
G1 X89.903 Y42.934 F254
G1 X89.916 Y42.782 F254
G1 X89.981 Y42.644 F254
G1 X90.069 Y42.52 F254
G1 X90.17 Y42.406 F254
G1 X90.296 Y42.285 F254
G1 X90.455 Y42.154 F254
G1 X90.628 Y42.031 F254
G1 X90.794 Y41.931 F254
G1 X90.93 Y41.862 F254
G1 X91.071 Y41.805 F254
G1 X91.098 Y41.801 F254
G1 X91.142 Y41.802 F254
G1 X91.183 Y41.818 F254
G1 X91.215 Y41.847 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X91.223 Y41.863 Z-8.049 F254
G1 X91.225 Y41.881 Z-8.001 F254
G1 X91.22 Y41.899 Z-7.954 F254
G1 X91.209 Y41.913 Z-7.907 F254
G1 X91.205 Y41.917 Z-7.893 F254
G1 X90.788 Y42.302 F254
; MOVEMENT_LINK_DIRECT
G1 X90.415 Y42.646 F254
; MOVEMENT_LEAD_IN
G1 X90.009 Y43.021 F254
G3 X89.996 Y43.029 I-0.034 J-0.037 F254
G1 X89.977 Y43.034 Z-7.944 F254
G1 X89.958 Y43.031 Z-7.994 F254
G1 X89.941 Y43.021 Z-8.045 F254
G1 X89.93 Y43.005 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.855 Y42.83 F254
G1 X89.829 Y42.759 F254
G1 X89.827 Y42.606 F254
G1 X89.889 Y42.467 F254
G1 X89.976 Y42.343 F254
G1 X90.078 Y42.229 F254
G1 X90.209 Y42.105 F254
G1 X90.367 Y41.975 F254
G1 X90.536 Y41.857 F254
G1 X90.689 Y41.766 F254
G1 X90.826 Y41.698 F254
G1 X90.967 Y41.642 F254
G1 X90.973 Y41.641 F254
G1 X91.013 Y41.644 F254
G1 X91.051 Y41.658 F254
G1 X91.081 Y41.684 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X91.09 Y41.7 Z-8.048 F254
G1 X91.092 Y41.719 Z-8 F254
G1 X91.088 Y41.737 Z-7.952 F254
G1 X91.077 Y41.751 Z-7.904 F254
G1 X91.074 Y41.754 Z-7.893 F254
G1 X90.664 Y42.147 F254
; MOVEMENT_LINK_DIRECT
G1 X90.333 Y42.464 F254
; MOVEMENT_LEAD_IN
G1 X89.935 Y42.845 F254
G3 X89.921 Y42.854 I-0.035 J-0.036 F254
G1 X89.902 Y42.859 Z-7.944 F254
G1 X89.883 Y42.856 Z-7.994 F254
G1 X89.867 Y42.846 Z-8.045 F254
G1 X89.855 Y42.83 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.773 Y42.638 F254
G1 X89.746 Y42.566 F254
G1 X89.745 Y42.414 F254
G1 X89.809 Y42.275 F254
G1 X89.898 Y42.152 F254
G1 X90 Y42.039 F254
G1 X90.131 Y41.917 F254
G1 X90.288 Y41.792 F254
G1 X90.45 Y41.681 F254
G1 X90.597 Y41.595 F254
G1 X90.734 Y41.528 F254
G1 X90.808 Y41.501 F254
G1 X90.855 Y41.494 F254
G1 X90.902 Y41.505 F254
G1 X90.941 Y41.533 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X90.951 Y41.549 Z-8.047 F254
G1 X90.954 Y41.568 Z-7.997 F254
G1 X90.949 Y41.586 Z-7.948 F254
G1 X90.938 Y41.602 Z-7.898 F254
G1 X90.937 Y41.603 Z-7.893 F254
G1 X90.529 Y41.998 F254
; MOVEMENT_LINK_DIRECT
G1 X90.249 Y42.269 F254
; MOVEMENT_LEAD_IN
G1 X89.853 Y42.652 F254
G3 X89.839 Y42.662 I-0.035 J-0.036 F254
G1 X89.82 Y42.667 Z-7.944 F254
G1 X89.801 Y42.664 Z-7.994 F254
G1 X89.784 Y42.653 Z-8.045 F254
G1 X89.773 Y42.638 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.691 Y42.447 F254
G1 X89.665 Y42.375 F254
G1 X89.664 Y42.223 F254
G1 X89.729 Y42.085 F254
G1 X89.819 Y41.962 F254
G1 X89.922 Y41.85 F254
G1 X90.052 Y41.731 F254
G1 X90.205 Y41.611 F254
G1 X90.363 Y41.506 F254
G1 X90.501 Y41.427 F254
G1 X90.639 Y41.361 F254
G1 X90.678 Y41.351 F254
G1 X90.722 Y41.347 F254
G1 X90.765 Y41.359 F254
G1 X90.801 Y41.385 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X90.81 Y41.402 Z-8.047 F254
G1 X90.813 Y41.42 Z-7.998 F254
G1 X90.809 Y41.439 Z-7.948 F254
G1 X90.798 Y41.454 Z-7.899 F254
G1 X90.797 Y41.456 Z-7.893 F254
G1 X90.391 Y41.853 F254
; MOVEMENT_LINK_DIRECT
G1 X90.165 Y42.076 F254
; MOVEMENT_LEAD_IN
G1 X89.772 Y42.461 F254
G3 X89.758 Y42.471 I-0.035 J-0.036 F254
G1 X89.739 Y42.476 Z-7.944 F254
G1 X89.72 Y42.473 Z-7.994 F254
G1 X89.703 Y42.462 Z-8.045 F254
G1 X89.691 Y42.447 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.602 Y42.237 F254
G1 X89.576 Y42.166 F254
G1 X89.591 Y42.014 F254
G1 X89.661 Y41.879 F254
G1 X89.754 Y41.758 F254
G1 X89.859 Y41.648 F254
G1 X89.986 Y41.536 F254
G1 X90.136 Y41.422 F254
G1 X90.288 Y41.324 F254
G1 X90.421 Y41.25 F254
G1 X90.522 Y41.208 F254
G1 X90.571 Y41.199 F254
G1 X90.62 Y41.209 F254
G1 X90.661 Y41.238 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X90.67 Y41.254 Z-8.047 F254
G1 X90.673 Y41.273 Z-7.997 F254
G1 X90.669 Y41.291 Z-7.948 F254
G1 X90.658 Y41.307 Z-7.898 F254
G1 X90.656 Y41.308 Z-7.893 F254
G1 X90.249 Y41.703 F254
; MOVEMENT_LINK_DIRECT
G1 X90.078 Y41.869 F254
; MOVEMENT_LEAD_IN
G1 X89.682 Y42.252 F254
G3 X89.668 Y42.262 I-0.035 J-0.036 F254
G1 X89.649 Y42.266 Z-7.944 F254
G1 X89.63 Y42.263 Z-7.994 F254
G1 X89.614 Y42.253 Z-8.045 F254
G1 X89.602 Y42.237 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.526 Y42.059 F254
G1 X89.5 Y41.988 F254
G1 X89.506 Y41.836 F254
G1 X89.575 Y41.699 F254
G1 X89.667 Y41.578 F254
G1 X89.773 Y41.469 F254
G1 X89.901 Y41.357 F254
G1 X90.048 Y41.247 F254
G1 X90.18 Y41.162 F254
G1 X90.315 Y41.09 F254
G1 X90.388 Y41.062 F254
G1 X90.436 Y41.054 F254
G1 X90.484 Y41.065 F254
G1 X90.523 Y41.093 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X90.533 Y41.109 Z-8.047 F254
G1 X90.536 Y41.128 Z-7.998 F254
G1 X90.532 Y41.146 Z-7.949 F254
G1 X90.521 Y41.162 Z-7.9 F254
G1 X90.519 Y41.164 Z-7.893 F254
G1 X90.117 Y41.564 F254
; MOVEMENT_LINK_DIRECT
G1 X89.996 Y41.685 F254
; MOVEMENT_LEAD_IN
G1 X89.607 Y42.074 F254
G3 X89.592 Y42.084 I-0.035 J-0.035 F254
G1 X89.574 Y42.088 Z-7.944 F254
G1 X89.554 Y42.085 Z-7.994 F254
G1 X89.538 Y42.075 Z-8.045 F254
G1 X89.526 Y42.059 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.437 Y41.851 F254
G1 X89.411 Y41.78 F254
G1 X89.434 Y41.629 F254
G1 X89.507 Y41.495 F254
G1 X89.603 Y41.377 F254
G1 X89.711 Y41.269 F254
G1 X89.835 Y41.164 F254
G1 X89.971 Y41.066 F254
G1 X90.101 Y40.986 F254
G1 X90.237 Y40.918 F254
G1 X90.264 Y40.911 F254
G1 X90.307 Y40.908 F254
G1 X90.349 Y40.921 F254
G1 X90.384 Y40.947 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X90.394 Y40.963 Z-8.047 F254
G1 X90.397 Y40.981 Z-7.998 F254
G1 X90.392 Y41 Z-7.949 F254
G1 X90.382 Y41.015 Z-7.899 F254
G1 X90.38 Y41.017 Z-7.893 F254
G1 X89.975 Y41.415 F254
; MOVEMENT_LINK_DIRECT
G1 X89.91 Y41.479 F254
; MOVEMENT_LEAD_IN
G1 X89.517 Y41.865 F254
G3 X89.503 Y41.875 I-0.035 J-0.036 F254
G1 X89.485 Y41.88 Z-7.944 F254
G1 X89.465 Y41.877 Z-7.994 F254
G1 X89.449 Y41.867 Z-8.045 F254
G1 X89.437 Y41.851 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.364 Y41.679 F254
G1 X89.337 Y41.608 F254
G1 X89.348 Y41.456 F254
G1 X89.419 Y41.321 F254
G1 X89.514 Y41.201 F254
G1 X89.622 Y41.094 F254
G1 X89.744 Y40.992 F254
G1 X89.868 Y40.903 F254
G1 X89.998 Y40.824 F254
G1 X90.102 Y40.775 F254
G1 X90.153 Y40.763 F254
G1 X90.204 Y40.772 F254
G1 X90.246 Y40.801 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X90.256 Y40.817 Z-8.048 F254
G1 X90.259 Y40.836 Z-7.999 F254
G1 X90.255 Y40.854 Z-7.951 F254
G1 X90.245 Y40.869 Z-7.902 F254
G1 X90.242 Y40.872 Z-7.893 F254
G1 X89.847 Y41.279 F254
; MOVEMENT_LINK_DIRECT
G1 X89.828 Y41.299 F254
; MOVEMENT_LEAD_IN
G1 X89.445 Y41.693 F254
G3 X89.43 Y41.703 I-0.036 J-0.035 F254
G1 X89.411 Y41.708 Z-7.944 F254
G1 X89.392 Y41.705 Z-7.994 F254
G1 X89.375 Y41.695 Z-8.045 F254
G1 X89.364 Y41.679 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.284 Y41.493 F254
G1 X89.274 Y41.47 F254
G1 X89.255 Y41.396 F254
G1 X89.28 Y41.246 F254
G1 X89.357 Y41.114 F254
G1 X89.455 Y40.997 F254
G1 X89.565 Y40.892 F254
G1 X89.684 Y40.797 F254
G1 X89.81 Y40.711 F254
G1 X89.943 Y40.637 F254
G1 X89.984 Y40.625 F254
G1 X90.029 Y40.62 F254
G1 X90.074 Y40.632 F254
G1 X90.111 Y40.659 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X90.12 Y40.675 Z-8.047 F254
G1 X90.123 Y40.693 Z-7.998 F254
G1 X90.119 Y40.712 Z-7.95 F254
G1 X90.109 Y40.727 Z-7.901 F254
G1 X90.107 Y40.729 Z-7.893 F254
G1 X89.743 Y41.094 F254
; MOVEMENT_LEAD_IN
G1 X89.355 Y41.484 F254
G3 X89.341 Y41.494 I-0.035 J-0.035 F254
G1 X89.322 Y41.499 Z-7.944 F254
G1 X89.303 Y41.496 Z-7.994 F254
G1 X89.286 Y41.486 Z-8.045 F254
G1 X89.274 Y41.47 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.215 Y41.283 F254
G1 X89.195 Y41.209 F254
G1 X89.209 Y41.057 F254
G1 X89.284 Y40.925 F254
G1 X89.383 Y40.808 F254
G1 X89.494 Y40.704 F254
G1 X89.615 Y40.611 F254
G1 X89.743 Y40.528 F254
G1 X89.834 Y40.488 F254
G1 X89.883 Y40.477 F254
G1 X89.933 Y40.487 F254
G1 X89.975 Y40.516 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X89.985 Y40.532 Z-8.048 F254
G1 X89.988 Y40.55 Z-8 F254
G1 X89.984 Y40.568 Z-7.952 F254
G1 X89.974 Y40.583 Z-7.904 F254
G1 X89.971 Y40.587 Z-7.893 F254
G1 X89.671 Y40.905 F254
; MOVEMENT_LEAD_IN
G1 X89.298 Y41.3 F254
G3 X89.278 Y41.313 I-0.036 J-0.034 F254
G1 X89.259 Y41.316 Z-7.944 F254
G1 X89.24 Y41.311 Z-7.994 F254
G1 X89.225 Y41.3 Z-8.045 F254
G1 X89.215 Y41.283 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.188 Y41.191 F254
G1 X89.151 Y41.051 F254
G1 X89.135 Y40.977 F254
G1 X89.165 Y40.827 F254
G1 X89.246 Y40.698 F254
G1 X89.349 Y40.586 F254
G1 X89.465 Y40.487 F254
G1 X89.59 Y40.4 F254
G1 X89.683 Y40.354 F254
G1 X89.726 Y40.341 F254
G1 X89.771 Y40.345 F254
G1 X89.811 Y40.364 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X89.824 Y40.379 Z-8.045 F254
G1 X89.83 Y40.397 Z-7.994 F254
G1 X89.829 Y40.417 Z-7.944 F254
G1 X89.82 Y40.434 Z-7.893 F254
G1 X89.817 Y40.438 F254
G1 X89.601 Y40.672 F254
; MOVEMENT_LEAD_IN
G1 X89.236 Y41.071 F254
G3 X89.213 Y41.085 I-0.037 J-0.034 F254
G1 X89.194 Y41.086 Z-7.944 F254
G1 X89.175 Y41.081 Z-7.994 F254
G1 X89.16 Y41.068 Z-8.045 F254
G1 X89.151 Y41.051 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.096 Y40.842 F254
G1 X89.08 Y40.767 F254
G1 X89.112 Y40.618 F254
G1 X89.196 Y40.491 F254
G1 X89.302 Y40.382 F254
G1 X89.421 Y40.286 F254
G1 X89.506 Y40.236 F254
G1 X89.551 Y40.221 F254
G1 X89.598 Y40.223 F254
G1 X89.641 Y40.243 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X89.654 Y40.258 Z-8.045 F254
G1 X89.66 Y40.276 Z-7.994 F254
G1 X89.659 Y40.295 Z-7.944 F254
G1 X89.65 Y40.313 Z-7.893 F254
G1 X89.649 Y40.315 F254
G1 X89.532 Y40.451 F254
; MOVEMENT_LEAD_IN
G1 X89.182 Y40.86 F254
G3 X89.158 Y40.875 I-0.038 J-0.033 F254
G1 X89.139 Y40.877 Z-7.944 F254
G1 X89.12 Y40.871 Z-7.994 F254
G1 X89.105 Y40.859 Z-8.045 F254
G1 X89.096 Y40.842 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X89.049 Y40.664 F254
G1 X89.033 Y40.589 F254
G1 X89.047 Y40.437 F254
G1 X89.128 Y40.308 F254
G1 X89.233 Y40.198 F254
G1 X89.356 Y40.108 F254
G1 X89.398 Y40.1 F254
G1 X89.438 Y40.106 F254
G1 X89.474 Y40.123 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X89.486 Y40.138 Z-8.046 F254
G1 X89.493 Y40.156 Z-7.997 F254
G1 X89.492 Y40.175 Z-7.947 F254
G1 X89.484 Y40.192 Z-7.897 F254
G1 X89.483 Y40.194 Z-7.893 F254
G1 X89.448 Y40.243 F254
; MOVEMENT_LEAD_IN
G1 X89.138 Y40.678 F254
G3 X89.111 Y40.697 I-0.041 J-0.029 F254
G1 X89.092 Y40.699 Z-7.944 F254
G1 X89.073 Y40.693 Z-7.994 F254
G1 X89.058 Y40.681 Z-8.045 F254
G1 X89.049 Y40.664 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X88.994 Y40.454 F254
G1 X88.98 Y40.389 F254
G1 X88.994 Y40.237 F254
G1 X89.077 Y40.109 F254
G1 X89.15 Y40.039 F254
G1 X89.187 Y40.015 F254
G1 X89.23 Y40.005 F254
G1 X89.274 Y40.01 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X89.29 Y40.02 Z-8.045 F254
G1 X89.302 Y40.036 Z-7.994 F254
G1 X89.307 Y40.055 Z-7.944 F254
G1 X89.304 Y40.074 Z-7.893 F254
; MOVEMENT_LEAD_IN
G1 X89.301 Y40.082 F254
G1 X89.085 Y40.465 F254
G3 X89.056 Y40.488 I-0.044 J-0.025 F254
G1 X89.037 Y40.49 Z-7.944 F254
G1 X89.018 Y40.484 Z-7.994 F254
G1 X89.003 Y40.472 Z-8.045 F254
G1 X88.994 Y40.454 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X88.968 Y40.353 F254
G1 X88.966 Y40.318 F254
G1 Y40.144 F254
G1 Y40.106 F254
G1 Y40.074 F254
G1 X88.968 Y40.025 F254
G1 X88.982 Y40.006 F254
G1 X89.02 Y39.973 F254
G1 X89.069 Y39.957 F254
G1 X89.119 Y39.962 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_IN
G1 X89.136 Y39.972 Z-8.045 F254
G1 X89.148 Y39.987 Z-7.994 F254
G1 X89.153 Y40.006 Z-7.944 F254
G1 X89.15 Y40.026 Z-7.893 F254
G3 X89.132 Y40.05 I-0.047 J-0.017 F254
G1 X89.045 Y40.113 F254
G3 X89.018 Y40.122 I-0.029 J-0.04 F254
G1 X88.998 Y40.119 Z-7.944 F254
G1 X88.982 Y40.109 Z-7.994 F254
G1 X88.97 Y40.093 Z-8.045 F254
G1 X88.966 Y40.074 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 Y39.989 F254
G1 X88.971 Y39.974 F254
G1 X88.988 Y39.955 F254
G1 X89.005 Y39.943 F254
G1 X89.023 Y39.937 F254
G1 X89.04 F254
G1 X89.337 Y40.03 F254
G1 X89.354 Y40.039 F254
G1 X89.502 Y40.144 F254
G1 X89.865 Y40.402 F254
G1 X89.887 Y40.423 F254
G1 X91.029 Y41.625 F254
G1 X91.099 Y41.704 F254
G1 X91.137 Y41.749 F254
G1 X91.586 Y42.314 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X91.546 Y42.394 I-0.04 J0.03 F254
G3 X91.506 Y42.373 J-0.05 F254
G1 X91.494 Y42.358 Z-8.092 F254
G1 X91.485 Y42.345 Z-8.081 F254
G1 X91.478 Y42.336 Z-8.065 F254
G1 X91.476 Y42.333 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z15.24 F254
; *** SECTION end ***
;
; *** STOP begin ***
M400
; COMMAND_COOLANT_OFF
; ---- Coolant: Off cur: Off A: Off B: Off
G0 X0 Y0 F4470
; COMMAND_STOP_SPINDLE
M300 S300 P3000
M0 Turn OFF spindle
M117 Job end
; *** STOP end ***
