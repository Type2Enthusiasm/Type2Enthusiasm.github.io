; parseSafeZProperty: safeZMode = 'Retract'
; parseSafeZProperty: safeZHeightDefault = 15
; param: product-id = fusion360
;Fusion CAM 2602.1.25
; Posts processor: MPCNC v3.0 Beta 1.cps
; Gcode generated: Sun Aug 24 01:07:21 2025 GMT
; param: hostname = Harrisons-MacBook-Air.local
; param: username = harrisonesterly
; Document: Untitled
; param: document-id = 7bda1355-3d5a-424c-bc0a-d581edb924e9
; param: model-version = 7ae6c002-2794-4fba-bdc6-08f0071d789a
; param: leads-supported = 1
; Setup: Setup1
; param: stock-type = box
; param: stock = 0, 0, -26.416, 195.707, 306.832, 0
; param: stock-lower-x = 0
; param: stock-lower-y = 0
; param: stock-lower-z = -26.415999999999997
; param: stock-upper-x = 195.707
; param: stock-upper-y = 306.83200000000005
; param: stock-upper-z = 0
; param: part-lower-x = 1.016
; param: part-lower-y = 1.016
; param: part-lower-z = -26.415999999999997
; param: part-upper-x = 194.691
; param: part-upper-y = 305.81600000000003
; param: part-upper-z = -1.0159999999999982
; param: areBothSpindlesGrabbed = 0
; param: notes = 
; param: operation-strategy = adaptive2d
; param: autodeskcam:operation-id = 3
; param: leads-supported = 1
; param: autodeskcam:path = Setups\Setup1\2D Adaptive1
; param: operation:is2DStrategy = 1
; param: operation:is3DStrategy = 0
; param: operation:isRoughingStrategy = 1
; param: operation:isFinishingStrategy = 0
; param: operation:isMillingStrategy = 1
; param: operation:isTurningStrategy = 0
; param: operation:isJetStrategy = 0
; param: operation:isAdditiveStrategy = 0
; param: operation:isProbingStrategy = 0
; param: operation:isInspectionStrategy = 0
; param: operation:isDrillingStrategy = 0
; param: operation:isHoleMillingStrategy = 0
; param: operation:isThreadStrategy = 0
; param: operation:isSamplingStrategy = 0
; param: operation:isRotaryStrategy = 1
; param: operation:isSubspindleStrategy = 0
; param: operation:isSurfaceStrategy = 0
; param: operation:isCheckSurfaceStrategy = 0
; param: operation:isMultiAxisStrategy = 0
; param: operation:advancedMode = 0
; param: operation:betaMode = 0
; param: operation:alphaMode = 0
; param: operation:isXpress = 0
; param: operation:licenseMultiaxis = 1
; param: operation:license3D = 1
; param: operation:metric = 0
; param: operation:isAssemblyDocument = 1
; param: operation:context = operation
; param: operation:strategy = adaptive2d
; param: operation:operation_description = 2D Adaptive
; param: operation:tool_type = flat end mill
; param: operation:undercut = 0
; param: operation:tool_isTurning = 0
; param: operation:tool_isMill = 1
; param: operation:tool_isDrill = 0
; param: operation:tool_isJet = 0
; param: operation:tool_isDepositing = 0
; param: operation:tool_taperedType = tapered_bull_nose
; param: operation:tool_unit = inches
; param: operation:tool_number = 1
; param: operation:tool_diameterOffset = 1
; param: operation:tool_lengthOffset = 1
; param: operation:tool_compensationOffset = 1
; param: operation:tool_turret = 0
; param: operation:tool_manualToolChange = 0
; param: operation:tool_breakControl = 0
; param: operation:tool_live = 1
; param: operation:tool_material = unspecified
; param: operation:tool_description = 1/4" Flat Endmill
; param: operation:tool_comment = 
; param: operation:tool_vendor = 
; param: operation:tool_productId = 
; param: operation:tool_productLink = 
; param: operation:tool_diameter = 6.35
; param: operation:tool_maximumCuttingDiameter = 0
; param: operation:tool_tipDiameter = 6.35
; param: operation:tool_tipOffset = 0
; param: operation:tool_cornerRadius = 0
; param: operation:tool_inclusiveAngle = 0
; param: operation:tool_taperAngle = 0
; param: operation:tool_tipAngle = 0
; param: operation:tool_threadTipType = point
; param: operation:tool_threadTipWidth = 0
; param: operation:tool_threadTipRadius = 0
; param: operation:tool_threadProfileAngle = 0
; param: operation:tool_tipLength = 0
; param: operation:tool_fluteLength = 19.049999999999997
; param: operation:tool_shoulderLength = 19.049999999999997
; param: operation:tool_bodyLength = 21.59
; param: operation:tool_overallLength = 63.5
; param: operation:tool_shaftDiameter = 6.35
; param: operation:tool_segmentHeight = 3.175
; param: operation:tool_segmentDiameterLower = 12.7
; param: operation:tool_segmentDiameterUpper = 12.7
; param: operation:tool_shaftSegmentHeight = 1.2700000000000014
; param: operation:tool_shaftSegmentDiameterLower = 6.35
; param: operation:tool_shaftSegmentDiameterUpper = 6.35
; param: operation:tool_threadPitch = 0
; param: operation:tool_maximumThreadPitch = 0
; param: operation:tool_minimumThreadPitch = 0
; param: operation:tool_numberOfTeeth = 0
; param: operation:tool_numberOfFlutes = 3
; param: operation:tool_shoulderDiameter = 6.35
; param: operation:tool_upperRadius = 1.016
; param: operation:tool_profileRadius = 101.6
; param: operation:tool_lowerRadius = 1.016
; param: operation:tool_axialDistance = 1.016
; param: operation:tool_chamferWidth = 1.016
; param: operation:tool_chamferAngle = 45
; param: operation:holder_attached = 1
; param: operation:holder_description = Maritool CAT40-ER32-2.35
; param: operation:holder_comment = 
; param: operation:holder_vendor = Maritool
; param: operation:holder_productId = CAT40-ER32-2.35
; param: operation:holder_productLink = 
; param: operation:holder_libraryName = 
; param: operation:tool_holderGaugeLength = 62.83959999999999
; param: operation:tool_assemblyGaugeLength = 84.4296
; param: operation:tool_spindleSpeed = 5000
; param: operation:tool_stockDiameter = 6.35
; param: operation:tool_surfaceSpeed = 99745.56675147593
; param: operation:tool_rampSpindleSpeed = 5000
; param: operation:tool_feedCutting = 1000
; param: operation:tool_feedPerTooth = 0.06666666666666667
; param: operation:tool_feedEntry = 1000
; param: operation:tool_feedExit = 1000
; param: operation:tool_feedTransition = 1000
; param: operation:tool_feedRamp = 333.3333333333333
; param: operation:tool_feedPlunge = 333.3333333333333
; param: operation:tool_feedPerRevolution = 0.06666666666666667
; param: operation:tool_feedRetract = 333.3333333333333
; param: operation:tool_clockwise = 1
; param: operation:tool_coolant = disabled
; param: operation:featureOperationId = none
; param: operation:surfaceZHigh = -1.016
; param: operation:surfaceZLow = -26.416
; param: operation:surfaceXLow = 1.016
; param: operation:surfaceXHigh = 194.691
; param: operation:surfaceYLow = 1.016
; param: operation:surfaceYHigh = 305.81600000000003
; param: operation:stockZHigh = 0
; param: operation:stockZLow = -26.416
; param: operation:stockXLow = 0
; param: operation:stockXHigh = 195.707
; param: operation:stockYLow = 0
; param: operation:stockYHigh = 306.83200000000005
; param: operation:multiAxisMachiningType = three_axis
; param: operation:view_orientation_mode = useWCS
; param: operation:view_orientation_flipZ = 0
; param: operation:view_orientation_axesZX_unselected_default = wcs
; param: operation:view_orientation_axesZY_unselected_default = wcs
; param: operation:view_orientation_axesXY_unselected_default = wcs
; param: operation:view_select_angles = turn_and_tilt
; param: operation:view_turn_from_recipe = 0
; param: operation:view_tilt_from_recipe = 0
; param: operation:view_orientation_flipX = 0
; param: operation:view_orientation_flipY = 0
; param: operation:view_origin_mode = jobOrigin
; param: operation:view_origin_boxPoint = top center
; param: operation:show_machine = 0
; param: operation:unwrap = 1
; param: operation:wrap_cylinder_radius = 0
; param: operation:wrap_nominalRadius_offset = 0
; param: operation:wrap_nominalRadius_value = 0
; param: operation:usePolarWhenNecessary = 0
; param: operation:polarMode = automatic
; param: operation:polarLineAngle = 0
; param: operation:pockets_detectOpenPockets = 1
; param: operation:pockets_connectOpenPockets = 1
; param: operation:pockets_errorCheck = 1
; param: operation:pockets_detectOverlaps = 0
; param: operation:restMaterialCutterDiameter = 12.7
; param: operation:restMaterialCornerRadius = 0
; param: operation:restMaterialTaperAngle = 0
; param: operation:restMaterialShoulderLength = 0
; param: operation:restMaterialTool = 
; param: operation:isClearanceAreaEnabled = 0
; param: operation:clearanceHeight_mode = from retract height
; param: operation:clearanceHeightFromHighest_checkStock = top
; param: operation:clearanceHeightFromLowest_checkStock = bottom
; param: operation:clearanceHeightFromHighest_checkModel = top
; param: operation:clearanceHeightFromLowest_checkModel = bottom
; param: operation:clearanceHeightFromHighest_checkFixture = top
; param: operation:clearanceHeightFromLowest_checkFixture = bottom
; param: operation:clearanceHeight_offset = 10.16
; param: operation:clearanceHeight_value = 15.239999999999998
; param: operation:clearanceHeight_absolute = 1
; param: operation:retractHeight_mode = from stock top
; param: operation:retractHeightFromHighest_checkStock = top
; param: operation:retractHeightFromLowest_checkStock = bottom
; param: operation:retractHeightFromHighest_checkModel = top
; param: operation:retractHeightFromLowest_checkModel = bottom
; param: operation:retractHeightFromHighest_checkFixture = top
; param: operation:retractHeightFromLowest_checkFixture = bottom
; param: operation:retractHeight_offset = 5.08
; param: operation:retractHeight_value = 5.08
; param: operation:retractHeight_absolute = 1
; param: operation:topHeight_mode = from stock top
; param: operation:topHeightFromHighest_checkStock = top
; param: operation:topHeightFromLowest_checkStock = bottom
; param: operation:topHeightFromHighest_checkModel = ignore
; param: operation:topHeightFromLowest_checkModel = ignore
; param: operation:topHeightFromHighest_checkFixture = ignore
; param: operation:topHeightFromLowest_checkFixture = ignore
; param: operation:topHeight_offset = 0
; param: operation:topHeight_value = 0
; param: operation:topHeight_absolute = 1
; param: operation:bottomHeight_mode = from contour
; param: operation:bottomHeightFromHighest_checkStock = bottom
; param: operation:bottomHeightFromLowest_checkStock = ignore
; param: operation:bottomHeightFromHighest_checkModel = bottom
; param: operation:bottomHeightFromLowest_checkModel = bottom
; param: operation:bottomHeightFromHighest_checkFixture = ignore
; param: operation:bottomHeightFromLowest_checkFixture = ignore
; param: operation:bottomHeight_offset = 0
; param: operation:bottomHeight_value = 0
; param: operation:bottomHeight_absolute = 0
; param: operation:tolerance = 0.1016
; param: operation:contourTolerance = 0.0508
; param: operation:totalSurfaceTolerance = 0.0508
; param: operation:surfaceTriangulationTolerance = 0.0508
; param: operation:calculationTolerance = 0.0508
; param: operation:thinningTolerance = 0.000508
; param: operation:chainingTolerance = 0.01016
; param: operation:gougingTolerance = 0.0508
; param: operation:optimalLoad = 2.54
; param: operation:optimalLoadWeight = 0
; param: operation:speedWeight = 0
; param: operation:feedWeight = 0
; param: operation:loadDeviation = 0.254
; param: operation:maximumLoad = 2.794
; param: operation:bothWays = 0
; param: operation:optimalLoadOtherWay = 2.54
; param: operation:loadDeviationOtherWay = 0.254
; param: operation:maximumLoadOtherWay = 2.794
; param: operation:otherWayFeedrate = 900
; param: operation:maximumCuspHeight = 0
; param: operation:minimumCuttingRadius = 0.635
; param: operation:minimumCuttingRadiusJl = 0.635
; param: operation:machineCavities = 1
; param: operation:useSlotClearing = 0
; param: operation:slotClearingWidth = 7.9375
; param: operation:direction = climb
; param: operation:maximumStepdown = 0
; param: operation:maximumStepdownJl = 2000000
; param: operation:slopeAngle = 0
; param: operation:useEvenStepdowns = 0
; param: operation:curveInRadius = 1.4816666666666665
; param: operation:fineStepdown = 0
; param: operation:fineStepdownJl = 1000000
; param: operation:minimumStepdownJobline = 0
; param: operation:useSilhouetteAsStockBoundary = 0
; param: operation:orderByDepth = 0
; param: operation:orderByArea = 0
; param: operation:orderByAreaBufferSize = 400
; param: operation:stockToLeave = 0
; param: operation:verticalStockToLeave = 0
; param: operation:simpleStockToLeave = 0
; param: operation:useCombinedFilter = 1
; param: operation:useDMKSmoothing = 0
; param: operation:smoothingFilterMode = redistribute
; param: operation:smoothingFilterMaxSpacing = 0.508
; param: operation:smoothingFilterMaxAngle = 3
; param: operation:smoothingFilterToleranceForEvenlySpacedPoints = 0.0508
; param: operation:smoothingFilterToleranceFactor = 0.5
; param: operation:smoothingFilterTolerance = 0
; param: operation:reducedFeedChange = 25
; param: operation:reducedFeedRadius = 0
; param: operation:reducedFeedDistance = 0
; param: operation:reducedFeedrate = 900
; param: operation:reduceOnlyInnerCorners = 1
; param: operation:surfaceSpeedOnArcs = 0
; param: operation:maximumReducedFeedrateInternalArcFinishing = 100
; param: operation:maximumIncreasedFeedrateExternalArcFinishing = 100
; param: operation:maximumReducedFeedrateInternalArc = 100
; param: operation:maximumIncreasedFeedrateExternalArc = 100
; param: operation:retractionPolicy = full
; param: operation:highFeedrateMode = disabled
; param: operation:highFeedrate = 1000
; param: operation:allowRapidRetract = 1
; param: operation:stayDownDistance = 31.75
; param: operation:minimumStayDownClearance = 2
; param: operation:stayDownLevel = level0
; param: operation:astarSpeedRatioJl = 0
; param: operation:liftHeight = 0.2032
; param: operation:noEngagementFeedrate = 1000
; param: operation:leadRadius = 0.635
; param: operation:verticalLeadRadius = 0.635
; param: operation:leadInRadius = 0.635
; param: operation:leadInVerticalRadius = 0.635
; param: operation:leadOutRadius = 0.635
; param: operation:leadOutVerticalRadius = 0.635
; param: operation:rampType = helix
; param: operation:allowPlungingOutsideStockJl = 0
; param: operation:rampAngle = 2
; param: operation:rampTaperAngle = 1
; param: operation:rampClearanceHeight = 2.54
; param: operation:helicalRampDiameter = 6.0325
; param: operation:minimumRampDiameter = 3.175
; param: operation:allowPlunging = 0
; param: operation:allowHelicalRamps = 1
; param: operation:isOperationTemplate = 0
; param: operation:use_tool_stepdown = 0
; param: operation:tool_stepdown = 17.145
; param: operation:tool_finishingStepdown = 0.2032
; param: operation:use_tool_stepover = 0
; param: operation:tool_stepover = 1.9049999999999998
; param: operation:tool_finishingStepover = 0.635
; param: operation:tool_rampType = helix
; param: operation:tool_rampAngle = 2
;When using Fusion for Personal Use, the feedrate of rapid
;moves is reduced to match the feedrate of cutting moves,
;which can increase machining time. Unrestricted rapid moves
;are available with a Fusion Subscription.
; param: movement:lead_in = 1000
; param: movement:cutting = 1000
; param: movement:lead_out = 1000
; param: movement:transition = 1000
; param: movement:direct = 1000
; param: movement:helix_ramp = 333.33333333333326
; param: movement:profile_ramp = 333.33333333333326
; param: movement:zigzag_ramp = 333.33333333333326
; param: movement:ramp = 333.33333333333326
; param: movement:plunge = 333.3333333333333
; param: movement:predrill = 1000
; param: movement:extended = 1000
; param: movement:reduced = 1000
; param: movement:finish_cutting = 1000
; param: movement:high_feed = 1000
; param: movement:depositing = 0
; param: movement:connection = 0
; param: movement:drill_breakthrough = 0
; param: movement:gun_drill_positioning = 0
; 
; Ranges Table:
;   X: Min=21.971 Max=173.736 Size=151.765
;   Y: Min=-6.238 Max=313.1 Size=319.338
;   Z: Min=-3.016 Max=15.24 Size=18.256
; 
; Tools Table:
;  T1 D=6.35 CR=0 - ZMIN=-3.016 - flat end mill 
; 
; Feedrate and Scaling Properties:
;   Feed: Travel speed X/Y = 4470
;   Feed: Travel Speed Z = 2235
;   Feed: Enforce Feedrate = true
;   Feed: Scale Feedrate = false
;   Feed: Max XY Cut Speed = 1000
;   Feed: Max Z Cut Speed = 400
;   Feed: Max Toolpath Speed = 1000
; 
; G1->G0 Mapping Properties:
;   Map: First G1 -> G0 Rapid = false
;   Map: G1s -> G0 Rapids = false
;   Map: SafeZ Mode = Retract : default = 15
;   Map: Allow Rapid Z = false
; 
; *** START begin ***
;   Set Absolute Positioning
;   Units = mm
G90
G21
;   Disable stepper timeout
M84 S0
;   Set current position to 0,0,0
G92 X0 Y0 Z0
; *** START end ***
; 
; *** SECTION begin ***
;   X Min: 21.971 - X Max: 173.736
;   Y Min: -6.238 - Y Max: 313.1
;   Z Min: -3.016 - Z Max: 15.24
; 2D Adaptive1 - Milling - Tool: 1 -  flat end mill
; COMMAND_START_SPINDLE
; COMMAND_SPINDLE_CLOCKWISE
; >>> Spindle Speed: Manual
M0 Turn ON 5000RPM
; COMMAND_COOLANT_ON
;   tool.coolant = 0 strCoolant = Off
; ---- Coolant: Off cur: Off A: Off B: Off
M117  2D Adaptive1
; MOVEMENT_CUTTING
G1 X98.404 Y313.1 Z15.24 F1000
G1 Z5.08 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X98.403 Y313.096 Z-2.452 F1000
G1 X98.4 Y313.085 Z-2.522 F1000
G1 X98.395 Y313.066 Z-2.591 F1000
G1 X98.388 Y313.039 Z-2.657 F1000
G1 X98.38 Y313.006 Z-2.719 F1000
G1 X98.369 Y312.966 Z-2.777 F1000
G1 X98.358 Y312.92 Z-2.83 F1000
G1 X98.344 Y312.869 Z-2.877 F1000
G1 X98.33 Y312.812 Z-2.919 F1000
G1 X98.315 Y312.752 Z-2.953 F1000
G1 X98.298 Y312.688 Z-2.98 F1000
G1 X98.281 Y312.622 Z-3 F1000
G1 X98.264 Y312.554 Z-3.012 F1000
G1 X98.246 Y312.485 Z-3.016 F1000
G3 X97.749 Y309.028 I15.704 J-4.023 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y308.876 F1000
G1 X97.818 Y308.74 F1000
G1 X97.905 Y308.614 F1000
G1 X98.012 Y308.485 F1000
G1 X98.155 Y308.338 F1000
G1 X98.342 Y308.176 F1000
G1 X98.583 Y307.997 F1000
G1 X98.893 Y307.805 F1000
G1 X99.291 Y307.6 F1000
G1 X99.809 Y307.384 F1000
G1 X100.505 Y307.157 F1000
G1 X101.399 Y306.943 F1000
G1 X102.306 Y306.795 F1000
G1 X103.219 Y306.692 F1000
G1 X104.135 Y306.621 F1000
G1 X105.053 Y306.57 F1000
G1 X105.971 Y306.535 F1000
G1 X106.89 Y306.51 F1000
G1 X107.809 Y306.493 F1000
G1 X108.728 Y306.48 F1000
G1 X109.647 Y306.472 F1000
G1 X110.566 Y306.466 F1000
G1 X111.485 Y306.461 F1000
G1 X113.323 Y306.456 F1000
G1 X116.08 Y306.453 F1000
G1 X122.513 Y306.451 F1000
G1 X147.326 F1000
G1 X172.254 F1000
G1 X172.584 Y306.488 F1000
G1 X172.897 Y306.598 F1000
G1 X173.178 Y306.774 F1000
G1 X173.413 Y307.009 F1000
G1 X173.589 Y307.29 F1000
G1 X173.699 Y307.603 F1000
G1 X173.736 Y307.933 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y308.517 I-0.635 J-0.022 F1000
G1 X173.221 Y308.538 Z-3.012 F1000
G1 X173.153 Y308.559 Z-3 F1000
G1 X173.088 Y308.579 Z-2.98 F1000
G1 X173.025 Y308.599 Z-2.953 F1000
G1 X172.966 Y308.617 Z-2.919 F1000
G1 X172.91 Y308.634 Z-2.877 F1000
G1 X172.859 Y308.65 Z-2.83 F1000
G1 X172.814 Y308.664 Z-2.777 F1000
G1 X172.775 Y308.676 Z-2.719 F1000
G1 X172.742 Y308.686 Z-2.657 F1000
G1 X172.716 Y308.694 Z-2.591 F1000
G1 X172.697 Y308.7 Z-2.522 F1000
G1 X172.685 Y308.703 Z-2.452 F1000
G1 X172.682 Y308.704 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.626 Y313.07 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.625 Y313.066 Z-2.452 F1000
G1 X22.622 Y313.054 Z-2.522 F1000
G1 X22.617 Y313.035 Z-2.591 F1000
G1 X22.61 Y313.009 Z-2.657 F1000
G1 X22.602 Y312.976 Z-2.719 F1000
G1 X22.591 Y312.936 Z-2.777 F1000
G1 X22.58 Y312.89 Z-2.83 F1000
G1 X22.566 Y312.838 Z-2.877 F1000
G1 X22.552 Y312.782 Z-2.919 F1000
G1 X22.537 Y312.722 Z-2.953 F1000
G1 X22.52 Y312.658 Z-2.98 F1000
G1 X22.503 Y312.592 Z-3 F1000
G1 X22.486 Y312.524 Z-3.012 F1000
G1 X22.468 Y312.455 Z-3.016 F1000
G3 X21.971 Y308.998 I15.704 J-4.023 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y308.674 F1000
G1 X21.973 Y308.636 F1000
G1 X22.075 Y308.51 F1000
G1 X22.211 Y308.366 F1000
G1 X22.389 Y308.206 F1000
G1 X22.619 Y308.031 F1000
G1 X22.915 Y307.841 F1000
G1 X23.295 Y307.638 F1000
G1 X23.788 Y307.424 F1000
G1 X24.446 Y307.199 F1000
G1 X25.336 Y306.972 F1000
G1 X26.242 Y306.815 F1000
G1 X27.154 Y306.706 F1000
G1 X28.07 Y306.63 F1000
G1 X28.988 Y306.577 F1000
G1 X29.906 Y306.54 F1000
G1 X30.825 Y306.513 F1000
G1 X31.743 Y306.495 F1000
G1 X32.662 Y306.482 F1000
G1 X33.581 Y306.473 F1000
G1 X34.5 Y306.466 F1000
G1 X35.419 Y306.462 F1000
G1 X37.257 Y306.456 F1000
G1 X40.014 Y306.453 F1000
G1 X46.448 Y306.451 F1000
G1 X72.18 F1000
G1 X93.318 F1000
G1 X94.236 Y306.407 F1000
G1 X95.135 Y306.219 F1000
G1 X96.016 Y305.958 F1000
G1 X96.889 Y305.671 F1000
G1 X97.763 Y305.385 F1000
G1 X98.643 Y305.12 F1000
G1 X99.531 Y304.885 F1000
G1 X100.428 Y304.685 F1000
G1 X101.332 Y304.518 F1000
G1 X102.241 Y304.382 F1000
G1 X103.153 Y304.274 F1000
G1 X104.069 Y304.189 F1000
G1 X104.985 Y304.122 F1000
G1 X105.903 Y304.071 F1000
G1 X106.821 Y304.031 F1000
G1 X107.739 Y304.001 F1000
G1 X108.658 Y303.978 F1000
G1 X109.577 Y303.961 F1000
G1 X110.496 Y303.948 F1000
G1 X111.415 Y303.939 F1000
G1 X112.334 Y303.931 F1000
G1 X113.253 Y303.926 F1000
G1 X114.172 Y303.922 F1000
G1 X116.01 Y303.917 F1000
G1 X118.767 Y303.913 F1000
G1 X122.443 Y303.912 F1000
G1 X169.313 Y303.911 F1000
G1 X170.232 Y303.912 F1000
G1 X171.026 Y303.946 F1000
G1 X171.593 Y304.017 F1000
G1 X172.104 Y304.122 F1000
G1 X172.519 Y304.243 F1000
G1 X172.91 Y304.392 F1000
G1 X173.187 Y304.565 F1000
G1 X173.418 Y304.794 F1000
G1 X173.591 Y305.07 F1000
G1 X173.699 Y305.377 F1000
G1 X173.736 Y305.7 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y306.285 I-0.635 J-0.022 F1000
G1 X173.221 Y306.306 Z-3.012 F1000
G1 X173.153 Y306.327 Z-3 F1000
G1 X173.088 Y306.347 Z-2.98 F1000
G1 X173.025 Y306.366 Z-2.953 F1000
G1 X172.966 Y306.385 Z-2.919 F1000
G1 X172.91 Y306.402 Z-2.877 F1000
G1 X172.859 Y306.417 Z-2.83 F1000
G1 X172.814 Y306.431 Z-2.777 F1000
G1 X172.775 Y306.443 Z-2.719 F1000
G1 X172.742 Y306.454 Z-2.657 F1000
G1 X172.716 Y306.462 Z-2.591 F1000
G1 X172.697 Y306.467 Z-2.522 F1000
G1 X172.685 Y306.471 Z-2.452 F1000
G1 X172.682 Y306.472 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y309.973 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y309.97 Z-2.452 F1000
G1 X22.509 Y309.96 Z-2.522 F1000
G1 X22.499 Y309.943 Z-2.591 F1000
G1 X22.485 Y309.919 Z-2.657 F1000
G1 X22.467 Y309.89 Z-2.719 F1000
G1 X22.446 Y309.854 Z-2.777 F1000
G1 X22.422 Y309.814 Z-2.83 F1000
G1 X22.395 Y309.768 Z-2.877 F1000
G1 X22.365 Y309.718 Z-2.919 F1000
G1 X22.333 Y309.664 Z-2.953 F1000
G1 X22.3 Y309.608 Z-2.98 F1000
G1 X22.265 Y309.549 Z-3 F1000
G1 X22.229 Y309.489 Z-3.012 F1000
G1 X22.192 Y309.428 Z-3.016 F1000
G3 X21.971 Y308.674 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y307.839 F1000
G1 X21.979 Y307.687 F1000
G1 X22.041 Y307.514 F1000
G1 X22.124 Y307.334 F1000
G1 X22.24 Y307.125 F1000
G1 X22.38 Y306.916 F1000
G1 X22.56 Y306.689 F1000
G1 X22.797 Y306.436 F1000
G1 X23.061 Y306.194 F1000
G1 X23.403 Y305.929 F1000
G1 X23.806 Y305.665 F1000
G1 X24.317 Y305.386 F1000
G1 X24.939 Y305.11 F1000
G1 X25.741 Y304.828 F1000
G1 X26.629 Y304.593 F1000
G1 X27.531 Y304.418 F1000
G1 X28.441 Y304.287 F1000
G1 X29.355 Y304.189 F1000
G1 X30.271 Y304.116 F1000
G1 X31.188 Y304.063 F1000
G1 X32.107 Y304.023 F1000
G1 X33.025 Y303.993 F1000
G1 X33.944 Y303.971 F1000
G1 X34.863 Y303.955 F1000
G1 X35.782 Y303.943 F1000
G1 X36.701 Y303.935 F1000
G1 X37.62 Y303.928 F1000
G1 X38.539 Y303.924 F1000
G1 X40.377 Y303.918 F1000
G1 X43.134 Y303.914 F1000
G1 X48.648 Y303.911 F1000
G1 X70.704 F1000
G1 X90.923 F1000
G1 X91.842 Y303.891 F1000
G1 X92.757 Y303.81 F1000
G1 X93.665 Y303.67 F1000
G1 X94.566 Y303.487 F1000
G1 X95.461 Y303.279 F1000
G1 X97.246 Y302.84 F1000
G1 X98.141 Y302.63 F1000
G1 X99.039 Y302.435 F1000
G1 X99.941 Y302.26 F1000
G1 X100.847 Y302.104 F1000
G1 X101.756 Y301.97 F1000
G1 X102.668 Y301.857 F1000
G1 X103.582 Y301.761 F1000
G1 X104.498 Y301.682 F1000
G1 X105.414 Y301.618 F1000
G1 X106.332 Y301.565 F1000
G1 X107.25 Y301.523 F1000
G1 X108.168 Y301.49 F1000
G1 X109.087 Y301.463 F1000
G1 X110.006 Y301.442 F1000
G1 X110.925 Y301.426 F1000
G1 X111.844 Y301.413 F1000
G1 X112.763 Y301.403 F1000
G1 X113.682 Y301.396 F1000
G1 X114.601 Y301.39 F1000
G1 X115.52 Y301.385 F1000
G1 X117.358 Y301.379 F1000
G1 X120.115 Y301.374 F1000
G1 X121.034 F1000
G1 X126.548 Y301.371 F1000
G1 X167.904 F1000
G1 X168.823 Y301.381 F1000
G1 X169.741 Y301.415 F1000
G1 X170.657 Y301.493 F1000
G1 X171.459 Y301.618 F1000
G1 X172.062 Y301.762 F1000
G1 X172.524 Y301.913 F1000
G1 X172.825 Y302.039 F1000
G1 X173.08 Y302.176 F1000
G1 X173.304 Y302.36 F1000
G1 X173.487 Y302.585 F1000
G1 X173.624 Y302.84 F1000
G1 X173.708 Y303.118 F1000
G1 X173.736 Y303.406 F1000
G1 Y305.7 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y306.285 I-0.635 J-0.022 F1000
G1 X173.221 Y306.306 Z-3.012 F1000
G1 X173.153 Y306.327 Z-3 F1000
G1 X173.088 Y306.347 Z-2.98 F1000
G1 X173.025 Y306.366 Z-2.953 F1000
G1 X172.966 Y306.385 Z-2.919 F1000
G1 X172.91 Y306.402 Z-2.877 F1000
G1 X172.859 Y306.417 Z-2.83 F1000
G1 X172.814 Y306.431 Z-2.777 F1000
G1 X172.775 Y306.443 Z-2.719 F1000
G1 X172.742 Y306.454 Z-2.657 F1000
G1 X172.716 Y306.462 Z-2.591 F1000
G1 X172.697 Y306.467 Z-2.522 F1000
G1 X172.685 Y306.471 Z-2.452 F1000
G1 X172.682 Y306.472 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y309.138 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y309.135 Z-2.452 F1000
G1 X22.509 Y309.124 Z-2.522 F1000
G1 X22.499 Y309.108 Z-2.591 F1000
G1 X22.485 Y309.084 Z-2.657 F1000
G1 X22.467 Y309.054 Z-2.719 F1000
G1 X22.446 Y309.019 Z-2.777 F1000
G1 X22.422 Y308.978 Z-2.83 F1000
G1 X22.395 Y308.933 Z-2.877 F1000
G1 X22.365 Y308.883 Z-2.919 F1000
G1 X22.333 Y308.829 Z-2.953 F1000
G1 X22.3 Y308.773 Z-2.98 F1000
G1 X22.265 Y308.714 Z-3 F1000
G1 X22.229 Y308.653 Z-3.012 F1000
G1 X22.192 Y308.592 Z-3.016 F1000
G3 X21.971 Y307.839 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y306.492 F1000
G1 X21.979 Y306.34 F1000
G1 X22.007 Y306.157 F1000
G1 X22.051 Y305.968 F1000
G1 X22.121 Y305.754 F1000
G1 X22.216 Y305.524 F1000
G1 X22.34 Y305.283 F1000
G1 X22.506 Y305.014 F1000
G1 X22.701 Y304.749 F1000
G1 X22.964 Y304.446 F1000
G1 X23.259 Y304.157 F1000
G1 X23.641 Y303.838 F1000
G1 X24.078 Y303.529 F1000
G1 X24.631 Y303.201 F1000
G1 X25.297 Y302.876 F1000
G1 X26.125 Y302.551 F1000
G1 X27.005 Y302.285 F1000
G1 X27.9 Y302.077 F1000
G1 X28.804 Y301.914 F1000
G1 X29.715 Y301.788 F1000
G1 X30.628 Y301.69 F1000
G1 X31.544 Y301.615 F1000
G1 X32.461 Y301.557 F1000
G1 X33.379 Y301.512 F1000
G1 X34.298 Y301.478 F1000
G1 X35.216 Y301.452 F1000
G1 X36.135 Y301.432 F1000
G1 X37.054 Y301.417 F1000
G1 X37.973 Y301.405 F1000
G1 X38.892 Y301.397 F1000
G1 X39.811 Y301.39 F1000
G1 X40.73 Y301.385 F1000
G1 X42.568 Y301.379 F1000
G1 X45.325 Y301.374 F1000
G1 X49.92 Y301.372 F1000
G1 X70.139 Y301.371 F1000
G1 X88.519 F1000
G1 X89.438 Y301.366 F1000
G1 X90.357 Y301.337 F1000
G1 X91.273 Y301.271 F1000
G1 X92.187 Y301.168 F1000
G1 X93.095 Y301.032 F1000
G1 X94 Y300.872 F1000
G1 X94.902 Y300.696 F1000
G1 X95.803 Y300.512 F1000
G1 X96.703 Y300.326 F1000
G1 X97.604 Y300.146 F1000
G1 X98.507 Y299.974 F1000
G1 X99.412 Y299.814 F1000
G1 X100.319 Y299.668 F1000
G1 X101.229 Y299.538 F1000
G1 X102.141 Y299.423 F1000
G1 X103.054 Y299.323 F1000
G1 X103.969 Y299.237 F1000
G1 X104.885 Y299.163 F1000
G1 X105.802 Y299.102 F1000
G1 X106.72 Y299.05 F1000
G1 X107.638 Y299.007 F1000
G1 X108.556 Y298.972 F1000
G1 X109.475 Y298.944 F1000
G1 X110.394 Y298.92 F1000
G1 X111.312 Y298.902 F1000
G1 X112.231 Y298.887 F1000
G1 X113.15 Y298.875 F1000
G1 X114.069 Y298.865 F1000
G1 X114.988 Y298.858 F1000
G1 X115.907 Y298.852 F1000
G1 X116.826 Y298.847 F1000
G1 X118.664 Y298.84 F1000
G1 X120.502 Y298.837 F1000
G1 X124.178 Y298.833 F1000
G1 X132.45 Y298.831 F1000
G1 X165.534 F1000
G1 X166.453 Y298.833 F1000
G1 X167.372 Y298.843 F1000
G1 X168.291 Y298.868 F1000
G1 X169.209 Y298.917 F1000
G1 X170.124 Y299.002 F1000
G1 X171.033 Y299.135 F1000
G1 X171.772 Y299.297 F1000
G1 X172.32 Y299.464 F1000
G1 X172.765 Y299.64 F1000
G1 X172.908 Y299.71 F1000
G1 X173.186 Y299.888 F1000
G1 X173.417 Y300.122 F1000
G1 X173.591 Y300.401 F1000
G1 X173.699 Y300.713 F1000
G1 X173.736 Y301.04 F1000
G1 Y303.406 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y303.991 I-0.635 J-0.022 F1000
G1 X173.221 Y304.012 Z-3.012 F1000
G1 X173.153 Y304.032 Z-3 F1000
G1 X173.088 Y304.053 Z-2.98 F1000
G1 X173.025 Y304.072 Z-2.953 F1000
G1 X172.966 Y304.09 Z-2.919 F1000
G1 X172.91 Y304.107 Z-2.877 F1000
G1 X172.859 Y304.123 Z-2.83 F1000
G1 X172.814 Y304.137 Z-2.777 F1000
G1 X172.775 Y304.149 Z-2.719 F1000
G1 X172.742 Y304.159 Z-2.657 F1000
G1 X172.716 Y304.167 Z-2.591 F1000
G1 X172.697 Y304.173 Z-2.522 F1000
G1 X172.685 Y304.177 Z-2.452 F1000
G1 X172.682 Y304.178 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y307.791 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y307.788 Z-2.452 F1000
G1 X22.509 Y307.777 Z-2.522 F1000
G1 X22.499 Y307.761 Z-2.591 F1000
G1 X22.485 Y307.737 Z-2.657 F1000
G1 X22.467 Y307.708 Z-2.719 F1000
G1 X22.446 Y307.672 Z-2.777 F1000
G1 X22.422 Y307.631 Z-2.83 F1000
G1 X22.395 Y307.586 Z-2.877 F1000
G1 X22.365 Y307.536 Z-2.919 F1000
G1 X22.333 Y307.482 Z-2.953 F1000
G1 X22.3 Y307.426 Z-2.98 F1000
G1 X22.265 Y307.367 Z-3 F1000
G1 X22.229 Y307.306 Z-3.012 F1000
G1 X22.192 Y307.245 Z-3.016 F1000
G3 X21.971 Y306.492 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y304.612 F1000
G1 X21.979 Y304.452 F1000
G1 X22.004 Y304.261 F1000
G1 X22.052 Y304.037 F1000
G1 X22.12 Y303.81 F1000
G1 X22.222 Y303.548 F1000
G1 X22.352 Y303.281 F1000
G1 X22.524 Y302.988 F1000
G1 X22.74 Y302.68 F1000
G1 X23.006 Y302.36 F1000
G1 X23.341 Y302.017 F1000
G1 X23.731 Y301.677 F1000
G1 X24.211 Y301.322 F1000
G1 X24.8 Y300.955 F1000
G1 X25.492 Y300.598 F1000
G1 X26.34 Y300.243 F1000
G1 X27.213 Y299.956 F1000
G1 X28.103 Y299.725 F1000
G1 X29.003 Y299.538 F1000
G1 X29.909 Y299.389 F1000
G1 X30.821 Y299.27 F1000
G1 X31.735 Y299.175 F1000
G1 X32.651 Y299.1 F1000
G1 X33.568 Y299.04 F1000
G1 X34.486 Y298.994 F1000
G1 X35.404 Y298.957 F1000
G1 X36.323 Y298.928 F1000
G1 X37.241 Y298.906 F1000
G1 X38.16 Y298.889 F1000
G1 X39.079 Y298.875 F1000
G1 X39.998 Y298.865 F1000
G1 X40.917 Y298.857 F1000
G1 X41.836 Y298.851 F1000
G1 X42.755 Y298.846 F1000
G1 X44.593 Y298.84 F1000
G1 X47.35 Y298.835 F1000
G1 X51.945 Y298.832 F1000
G1 X70.326 Y298.831 F1000
G1 X85.949 F1000
G1 X86.868 Y298.83 F1000
G1 X87.787 Y298.823 F1000
G1 X88.706 Y298.802 F1000
G1 X89.624 Y298.758 F1000
G1 X90.54 Y298.686 F1000
G1 X91.454 Y298.588 F1000
G1 X92.365 Y298.466 F1000
G1 X93.273 Y298.326 F1000
G1 X94.179 Y298.173 F1000
G1 X95.084 Y298.012 F1000
G1 X95.988 Y297.849 F1000
G1 X96.893 Y297.686 F1000
G1 X97.798 Y297.529 F1000
G1 X98.705 Y297.38 F1000
G1 X99.613 Y297.24 F1000
G1 X100.524 Y297.112 F1000
G1 X101.435 Y296.996 F1000
G1 X102.348 Y296.892 F1000
G1 X103.263 Y296.8 F1000
G1 X104.178 Y296.719 F1000
G1 X105.094 Y296.648 F1000
G1 X106.011 Y296.588 F1000
G1 X106.929 Y296.536 F1000
G1 X107.847 Y296.493 F1000
G1 X108.765 Y296.456 F1000
G1 X109.684 Y296.425 F1000
G1 X110.602 Y296.4 F1000
G1 X111.521 Y296.379 F1000
G1 X112.44 Y296.361 F1000
G1 X113.359 Y296.347 F1000
G1 X114.278 Y296.336 F1000
G1 X115.197 Y296.327 F1000
G1 X116.116 Y296.319 F1000
G1 X117.035 Y296.313 F1000
G1 X118.873 Y296.305 F1000
G1 X120.711 Y296.299 F1000
G1 X123.468 Y296.295 F1000
G1 X128.063 Y296.292 F1000
G1 X144.605 Y296.291 F1000
G1 X163.905 F1000
G1 X164.824 Y296.294 F1000
G1 X165.743 Y296.301 F1000
G1 X166.662 Y296.317 F1000
G1 X167.58 Y296.346 F1000
G1 X168.498 Y296.396 F1000
G1 X169.414 Y296.472 F1000
G1 X170.326 Y296.586 F1000
G1 X171.23 Y296.75 F1000
G1 X171.938 Y296.931 F1000
G1 X172.456 Y297.11 F1000
G1 X172.921 Y297.313 F1000
G1 X172.955 Y297.331 F1000
G1 X173.218 Y297.511 F1000
G1 X173.436 Y297.744 F1000
G1 X173.6 Y298.017 F1000
G1 X173.702 Y298.32 F1000
G1 X173.736 Y298.637 F1000
G1 Y301.04 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y301.625 I-0.635 J-0.022 F1000
G1 X173.221 Y301.646 Z-3.012 F1000
G1 X173.153 Y301.666 Z-3 F1000
G1 X173.088 Y301.686 Z-2.98 F1000
G1 X173.025 Y301.706 Z-2.953 F1000
G1 X172.966 Y301.724 Z-2.919 F1000
G1 X172.91 Y301.741 Z-2.877 F1000
G1 X172.859 Y301.757 Z-2.83 F1000
G1 X172.814 Y301.771 Z-2.777 F1000
G1 X172.775 Y301.783 Z-2.719 F1000
G1 X172.742 Y301.793 Z-2.657 F1000
G1 X172.716 Y301.801 Z-2.591 F1000
G1 X172.697 Y301.807 Z-2.522 F1000
G1 X172.685 Y301.811 Z-2.452 F1000
G1 X172.682 Y301.812 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y305.912 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y305.908 Z-2.452 F1000
G1 X22.509 Y305.898 Z-2.522 F1000
G1 X22.499 Y305.881 Z-2.591 F1000
G1 X22.485 Y305.858 Z-2.657 F1000
G1 X22.467 Y305.828 Z-2.719 F1000
G1 X22.446 Y305.793 Z-2.777 F1000
G1 X22.422 Y305.752 Z-2.83 F1000
G1 X22.395 Y305.706 Z-2.877 F1000
G1 X22.365 Y305.656 Z-2.919 F1000
G1 X22.333 Y305.603 Z-2.953 F1000
G1 X22.3 Y305.546 Z-2.98 F1000
G1 X22.265 Y305.487 Z-3 F1000
G1 X22.229 Y305.427 Z-3.012 F1000
G1 X22.192 Y305.366 Z-3.016 F1000
G3 X21.971 Y304.612 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y302.524 F1000
G1 X21.979 Y302.359 F1000
G1 X22.006 Y302.156 F1000
G1 X22.057 Y301.918 F1000
G1 X22.131 Y301.671 F1000
G1 X22.238 Y301.396 F1000
G1 X22.381 Y301.101 F1000
G1 X22.563 Y300.792 F1000
G1 X22.8 Y300.455 F1000
G1 X23.081 Y300.116 F1000
G1 X23.445 Y299.743 F1000
G1 X23.863 Y299.378 F1000
G1 X24.381 Y298.995 F1000
G1 X25.016 Y298.6 F1000
G1 X25.78 Y298.206 F1000
G1 X26.628 Y297.851 F1000
G1 X27.499 Y297.559 F1000
G1 X28.386 Y297.318 F1000
G1 X29.284 Y297.121 F1000
G1 X30.188 Y296.959 F1000
G1 X31.098 Y296.827 F1000
G1 X32.011 Y296.72 F1000
G1 X32.926 Y296.633 F1000
G1 X33.842 Y296.563 F1000
G1 X34.759 Y296.507 F1000
G1 X35.677 Y296.461 F1000
G1 X36.595 Y296.425 F1000
G1 X37.514 Y296.396 F1000
G1 X38.433 Y296.374 F1000
G1 X39.352 Y296.356 F1000
G1 X40.271 Y296.341 F1000
G1 X41.189 Y296.33 F1000
G1 X42.108 Y296.321 F1000
G1 X43.027 Y296.315 F1000
G1 X43.946 Y296.309 F1000
G1 X45.785 Y296.302 F1000
G1 X47.623 Y296.297 F1000
G1 X50.38 Y296.294 F1000
G1 X55.894 Y296.292 F1000
G1 X69.679 Y296.291 F1000
G1 X84.383 F1000
G1 X85.302 Y296.289 F1000
G1 X86.221 Y296.283 F1000
G1 X87.14 Y296.267 F1000
G1 X88.059 Y296.236 F1000
G1 X88.976 Y296.184 F1000
G1 X89.892 Y296.112 F1000
G1 X90.807 Y296.019 F1000
G1 X91.719 Y295.908 F1000
G1 X92.629 Y295.782 F1000
G1 X93.538 Y295.645 F1000
G1 X94.446 Y295.501 F1000
G1 X96.26 Y295.206 F1000
G1 X97.168 Y295.061 F1000
G1 X98.076 Y294.921 F1000
G1 X98.985 Y294.788 F1000
G1 X99.896 Y294.664 F1000
G1 X100.808 Y294.549 F1000
G1 X101.721 Y294.444 F1000
G1 X102.635 Y294.349 F1000
G1 X103.55 Y294.264 F1000
G1 X104.466 Y294.188 F1000
G1 X105.382 Y294.122 F1000
G1 X106.299 Y294.063 F1000
G1 X107.217 Y294.013 F1000
G1 X108.135 Y293.97 F1000
G1 X109.053 Y293.933 F1000
G1 X109.972 Y293.901 F1000
G1 X110.891 Y293.875 F1000
G1 X111.809 Y293.852 F1000
G1 X112.728 Y293.834 F1000
G1 X113.647 Y293.818 F1000
G1 X114.566 Y293.805 F1000
G1 X115.485 Y293.795 F1000
G1 X116.404 Y293.786 F1000
G1 X117.323 Y293.779 F1000
G1 X118.242 Y293.774 F1000
G1 X120.08 Y293.765 F1000
G1 X121.918 Y293.76 F1000
G1 X124.675 Y293.755 F1000
G1 X129.27 Y293.752 F1000
G1 X143.055 Y293.751 F1000
G1 X161.436 F1000
G1 X162.355 Y293.752 F1000
G1 X163.274 Y293.754 F1000
G1 X164.193 Y293.759 F1000
G1 X165.112 Y293.77 F1000
G1 X166.031 Y293.79 F1000
G1 X166.949 Y293.822 F1000
G1 X167.867 Y293.872 F1000
G1 X168.783 Y293.944 F1000
G1 X169.696 Y294.046 F1000
G1 X170.604 Y294.187 F1000
G1 X171.503 Y294.381 F1000
G1 X172.157 Y294.575 F1000
G1 X172.647 Y294.764 F1000
G1 X172.897 Y294.885 F1000
G1 X173.178 Y295.062 F1000
G1 X173.413 Y295.296 F1000
G1 X173.589 Y295.577 F1000
G1 X173.699 Y295.89 F1000
G1 X173.736 Y296.22 F1000
G1 Y298.637 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y299.222 I-0.635 J-0.022 F1000
G1 X173.221 Y299.243 Z-3.012 F1000
G1 X173.153 Y299.263 Z-3 F1000
G1 X173.088 Y299.283 Z-2.98 F1000
G1 X173.025 Y299.303 Z-2.953 F1000
G1 X172.966 Y299.321 Z-2.919 F1000
G1 X172.91 Y299.338 Z-2.877 F1000
G1 X172.859 Y299.354 Z-2.83 F1000
G1 X172.814 Y299.368 Z-2.777 F1000
G1 X172.775 Y299.38 Z-2.719 F1000
G1 X172.742 Y299.39 Z-2.657 F1000
G1 X172.716 Y299.398 Z-2.591 F1000
G1 X172.697 Y299.404 Z-2.522 F1000
G1 X172.685 Y299.407 Z-2.452 F1000
G1 X172.682 Y299.409 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y303.823 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y303.82 Z-2.452 F1000
G1 X22.509 Y303.81 Z-2.522 F1000
G1 X22.499 Y303.793 Z-2.591 F1000
G1 X22.485 Y303.769 Z-2.657 F1000
G1 X22.467 Y303.74 Z-2.719 F1000
G1 X22.446 Y303.704 Z-2.777 F1000
G1 X22.422 Y303.663 Z-2.83 F1000
G1 X22.395 Y303.618 Z-2.877 F1000
G1 X22.365 Y303.568 Z-2.919 F1000
G1 X22.333 Y303.514 Z-2.953 F1000
G1 X22.3 Y303.458 Z-2.98 F1000
G1 X22.265 Y303.399 Z-3 F1000
G1 X22.229 Y303.339 Z-3.012 F1000
G1 X22.192 Y303.277 Z-3.016 F1000
G3 X21.971 Y302.524 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y300.436 F1000
G1 X21.984 Y300.167 F1000
G1 X22.013 Y299.951 F1000
G1 X22.064 Y299.712 F1000
G1 X22.145 Y299.442 F1000
G1 X22.252 Y299.167 F1000
G1 X22.407 Y298.848 F1000
G1 X22.591 Y298.534 F1000
G1 X22.844 Y298.174 F1000
G1 X23.137 Y297.821 F1000
G1 X23.522 Y297.427 F1000
G1 X23.958 Y297.046 F1000
G1 X24.512 Y296.637 F1000
G1 X25.184 Y296.219 F1000
G1 X25.99 Y295.802 F1000
G1 X26.838 Y295.448 F1000
G1 X27.708 Y295.151 F1000
G1 X28.593 Y294.903 F1000
G1 X29.489 Y294.697 F1000
G1 X30.391 Y294.525 F1000
G1 X31.299 Y294.382 F1000
G1 X32.211 Y294.264 F1000
G1 X33.125 Y294.167 F1000
G1 X34.04 Y294.088 F1000
G1 X34.957 Y294.022 F1000
G1 X35.874 Y293.969 F1000
G1 X36.792 Y293.926 F1000
G1 X37.711 Y293.89 F1000
G1 X38.629 Y293.862 F1000
G1 X39.548 Y293.839 F1000
G1 X40.467 Y293.821 F1000
G1 X41.386 Y293.806 F1000
G1 X42.305 Y293.795 F1000
G1 X43.224 Y293.785 F1000
G1 X44.143 Y293.778 F1000
G1 X45.062 Y293.772 F1000
G1 X46.9 Y293.764 F1000
G1 X48.738 Y293.759 F1000
G1 X51.495 Y293.755 F1000
G1 X56.09 Y293.752 F1000
G1 X69.875 Y293.751 F1000
G1 X82.741 F1000
G1 X83.66 Y293.749 F1000
G1 X84.579 Y293.744 F1000
G1 X85.498 Y293.733 F1000
G1 X86.417 Y293.712 F1000
G1 X87.335 Y293.676 F1000
G1 X88.253 Y293.625 F1000
G1 X89.17 Y293.556 F1000
G1 X90.085 Y293.471 F1000
G1 X90.998 Y293.37 F1000
G1 X91.91 Y293.257 F1000
G1 X92.821 Y293.133 F1000
G1 X93.73 Y293.002 F1000
G1 X94.639 Y292.868 F1000
G1 X95.548 Y292.731 F1000
G1 X96.457 Y292.596 F1000
G1 X97.367 Y292.464 F1000
G1 X98.277 Y292.337 F1000
G1 X99.188 Y292.216 F1000
G1 X100.1 Y292.103 F1000
G1 X101.013 Y291.997 F1000
G1 X101.927 Y291.9 F1000
G1 X102.842 Y291.812 F1000
G1 X103.757 Y291.732 F1000
G1 X104.673 Y291.66 F1000
G1 X105.59 Y291.596 F1000
G1 X106.507 Y291.54 F1000
G1 X107.425 Y291.49 F1000
G1 X108.343 Y291.447 F1000
G1 X109.261 Y291.409 F1000
G1 X110.18 Y291.377 F1000
G1 X111.098 Y291.35 F1000
G1 X112.017 Y291.326 F1000
G1 X112.936 Y291.306 F1000
G1 X113.855 Y291.29 F1000
G1 X114.774 Y291.276 F1000
G1 X115.693 Y291.264 F1000
G1 X116.612 Y291.254 F1000
G1 X117.531 Y291.246 F1000
G1 X118.45 Y291.239 F1000
G1 X120.288 Y291.229 F1000
G1 X122.126 Y291.223 F1000
G1 X124.883 Y291.217 F1000
G1 X128.559 Y291.213 F1000
G1 X135.911 Y291.211 F1000
G1 X159.806 F1000
G1 X161.644 Y291.213 F1000
G1 X162.563 Y291.217 F1000
G1 X163.482 Y291.224 F1000
G1 X164.401 Y291.237 F1000
G1 X165.319 Y291.258 F1000
G1 X166.238 Y291.291 F1000
G1 X167.156 Y291.338 F1000
G1 X168.072 Y291.403 F1000
G1 X168.987 Y291.493 F1000
G1 X169.898 Y291.614 F1000
G1 X170.803 Y291.775 F1000
G1 X171.66 Y291.98 F1000
G1 X172.288 Y292.185 F1000
G1 X172.787 Y292.393 F1000
G1 X172.933 Y292.468 F1000
G1 X173.203 Y292.647 F1000
G1 X173.427 Y292.88 F1000
G1 X173.596 Y293.157 F1000
G1 X173.701 Y293.463 F1000
G1 X173.736 Y293.785 F1000
G1 Y296.22 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y296.804 I-0.635 J-0.022 F1000
G1 X173.221 Y296.825 Z-3.012 F1000
G1 X173.153 Y296.846 Z-3 F1000
G1 X173.088 Y296.866 Z-2.98 F1000
G1 X173.025 Y296.886 Z-2.953 F1000
G1 X172.966 Y296.904 Z-2.919 F1000
G1 X172.91 Y296.921 Z-2.877 F1000
G1 X172.859 Y296.937 Z-2.83 F1000
G1 X172.814 Y296.951 Z-2.777 F1000
G1 X172.775 Y296.963 Z-2.719 F1000
G1 X172.742 Y296.973 Z-2.657 F1000
G1 X172.716 Y296.981 Z-2.591 F1000
G1 X172.697 Y296.987 Z-2.522 F1000
G1 X172.685 Y296.99 Z-2.452 F1000
G1 X172.682 Y296.992 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y301.735 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y301.732 Z-2.452 F1000
G1 X22.509 Y301.721 Z-2.522 F1000
G1 X22.499 Y301.704 Z-2.591 F1000
G1 X22.485 Y301.681 Z-2.657 F1000
G1 X22.467 Y301.651 Z-2.719 F1000
G1 X22.446 Y301.616 Z-2.777 F1000
G1 X22.422 Y301.575 Z-2.83 F1000
G1 X22.395 Y301.529 Z-2.877 F1000
G1 X22.365 Y301.48 Z-2.919 F1000
G1 X22.333 Y301.426 Z-2.953 F1000
G1 X22.3 Y301.369 Z-2.98 F1000
G1 X22.265 Y301.311 Z-3 F1000
G1 X22.229 Y301.25 Z-3.012 F1000
G1 X22.192 Y301.189 Z-3.016 F1000
G3 X21.971 Y300.436 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y298.138 F1000
G1 X21.982 Y297.921 F1000
G1 X22.012 Y297.69 F1000
G1 X22.063 Y297.451 F1000
G1 X22.148 Y297.169 F1000
G1 X22.258 Y296.886 F1000
G1 X22.414 Y296.564 F1000
G1 X22.611 Y296.229 F1000
G1 X22.864 Y295.869 F1000
G1 X23.181 Y295.487 F1000
G1 X23.566 Y295.093 F1000
G1 X24.03 Y294.688 F1000
G1 X24.61 Y294.259 F1000
G1 X25.308 Y293.825 F1000
G1 X26.124 Y293.403 F1000
G1 X26.971 Y293.046 F1000
G1 X27.839 Y292.744 F1000
G1 X28.722 Y292.489 F1000
G1 X29.615 Y292.274 F1000
G1 X30.516 Y292.092 F1000
G1 X31.423 Y291.94 F1000
G1 X32.333 Y291.812 F1000
G1 X33.245 Y291.705 F1000
G1 X34.16 Y291.616 F1000
G1 X35.076 Y291.542 F1000
G1 X35.993 Y291.48 F1000
G1 X36.911 Y291.43 F1000
G1 X37.829 Y291.388 F1000
G1 X38.747 Y291.354 F1000
G1 X39.666 Y291.326 F1000
G1 X40.585 Y291.304 F1000
G1 X41.503 Y291.285 F1000
G1 X42.422 Y291.27 F1000
G1 X43.341 Y291.258 F1000
G1 X44.26 Y291.249 F1000
G1 X45.179 Y291.241 F1000
G1 X46.098 Y291.235 F1000
G1 X47.936 Y291.226 F1000
G1 X49.774 Y291.22 F1000
G1 X52.531 Y291.215 F1000
G1 X57.126 Y291.212 F1000
G1 X69.993 Y291.211 F1000
G1 X81.021 F1000
G1 X81.94 Y291.209 F1000
G1 X82.859 Y291.206 F1000
G1 X83.778 Y291.199 F1000
G1 X84.697 Y291.185 F1000
G1 X85.616 Y291.161 F1000
G1 X86.534 Y291.126 F1000
G1 X87.452 Y291.077 F1000
G1 X88.368 Y291.014 F1000
G1 X89.284 Y290.936 F1000
G1 X90.199 Y290.846 F1000
G1 X91.112 Y290.743 F1000
G1 X92.024 Y290.632 F1000
G1 X92.936 Y290.513 F1000
G1 X93.846 Y290.389 F1000
G1 X95.667 Y290.136 F1000
G1 X96.577 Y290.011 F1000
G1 X97.488 Y289.889 F1000
G1 X98.4 Y289.771 F1000
G1 X99.312 Y289.659 F1000
G1 X100.225 Y289.554 F1000
G1 X101.138 Y289.455 F1000
G1 X102.053 Y289.364 F1000
G1 X102.968 Y289.28 F1000
G1 X103.884 Y289.204 F1000
G1 X104.8 Y289.135 F1000
G1 X105.717 Y289.073 F1000
G1 X106.635 Y289.017 F1000
G1 X107.552 Y288.968 F1000
G1 X108.47 Y288.925 F1000
G1 X109.389 Y288.887 F1000
G1 X110.307 Y288.854 F1000
G1 X111.226 Y288.825 F1000
G1 X112.144 Y288.801 F1000
G1 X113.063 Y288.78 F1000
G1 X113.982 Y288.762 F1000
G1 X114.901 Y288.746 F1000
G1 X115.82 Y288.733 F1000
G1 X116.739 Y288.722 F1000
G1 X117.658 Y288.713 F1000
G1 X118.577 Y288.706 F1000
G1 X119.496 Y288.699 F1000
G1 X120.415 Y288.694 F1000
G1 X122.253 Y288.686 F1000
G1 X125.01 Y288.679 F1000
G1 X128.686 Y288.674 F1000
G1 X135.119 Y288.672 F1000
G1 X158.094 Y288.671 F1000
G1 X159.932 Y288.673 F1000
G1 X160.851 Y288.675 F1000
G1 X161.77 Y288.68 F1000
G1 X162.689 Y288.688 F1000
G1 X163.608 Y288.701 F1000
G1 X164.527 Y288.722 F1000
G1 X165.446 Y288.753 F1000
G1 X166.364 Y288.795 F1000
G1 X167.281 Y288.854 F1000
G1 X168.197 Y288.932 F1000
G1 X169.11 Y289.035 F1000
G1 X170.019 Y289.17 F1000
G1 X170.921 Y289.345 F1000
G1 X171.755 Y289.558 F1000
G1 X172.366 Y289.767 F1000
G1 X172.855 Y289.98 F1000
G1 X172.953 Y290.032 F1000
G1 X173.216 Y290.212 F1000
G1 X173.436 Y290.445 F1000
G1 X173.6 Y290.719 F1000
G1 X173.702 Y291.021 F1000
G1 X173.736 Y291.339 F1000
G1 Y293.785 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y294.37 I-0.635 J-0.022 F1000
G1 X173.221 Y294.391 Z-3.012 F1000
G1 X173.153 Y294.412 Z-3 F1000
G1 X173.088 Y294.432 Z-2.98 F1000
G1 X173.025 Y294.451 Z-2.953 F1000
G1 X172.966 Y294.469 Z-2.919 F1000
G1 X172.91 Y294.487 Z-2.877 F1000
G1 X172.859 Y294.502 Z-2.83 F1000
G1 X172.814 Y294.516 Z-2.777 F1000
G1 X172.775 Y294.528 Z-2.719 F1000
G1 X172.742 Y294.539 Z-2.657 F1000
G1 X172.716 Y294.547 Z-2.591 F1000
G1 X172.697 Y294.552 Z-2.522 F1000
G1 X172.685 Y294.556 Z-2.452 F1000
G1 X172.682 Y294.557 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y299.438 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y299.434 Z-2.452 F1000
G1 X22.509 Y299.424 Z-2.522 F1000
G1 X22.499 Y299.407 Z-2.591 F1000
G1 X22.485 Y299.384 Z-2.657 F1000
G1 X22.467 Y299.354 Z-2.719 F1000
G1 X22.446 Y299.319 Z-2.777 F1000
G1 X22.422 Y299.278 Z-2.83 F1000
G1 X22.395 Y299.232 Z-2.877 F1000
G1 X22.365 Y299.182 Z-2.919 F1000
G1 X22.333 Y299.129 Z-2.953 F1000
G1 X22.3 Y299.072 Z-2.98 F1000
G1 X22.265 Y299.013 Z-3 F1000
G1 X22.229 Y298.953 Z-3.012 F1000
G1 X22.192 Y298.892 Z-3.016 F1000
G3 X21.971 Y298.138 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y295.841 F1000
G1 X21.982 Y295.625 F1000
G1 X22.013 Y295.387 F1000
G1 X22.065 Y295.144 F1000
G1 X22.15 Y294.861 F1000
G1 X22.265 Y294.565 F1000
G1 X22.422 Y294.242 F1000
G1 X22.629 Y293.89 F1000
G1 X22.882 Y293.53 F1000
G1 X23.213 Y293.131 F1000
G1 X23.602 Y292.732 F1000
G1 X24.085 Y292.311 F1000
G1 X24.684 Y291.868 F1000
G1 X25.406 Y291.419 F1000
G1 X26.222 Y290.997 F1000
G1 X27.068 Y290.638 F1000
G1 X27.934 Y290.331 F1000
G1 X28.815 Y290.069 F1000
G1 X29.707 Y289.846 F1000
G1 X30.606 Y289.656 F1000
G1 X31.511 Y289.494 F1000
G1 X32.419 Y289.358 F1000
G1 X33.331 Y289.242 F1000
G1 X34.245 Y289.144 F1000
G1 X35.16 Y289.062 F1000
G1 X36.077 Y288.994 F1000
G1 X36.994 Y288.936 F1000
G1 X37.912 Y288.889 F1000
G1 X38.83 Y288.849 F1000
G1 X39.748 Y288.816 F1000
G1 X40.667 Y288.789 F1000
G1 X41.586 Y288.767 F1000
G1 X42.505 Y288.748 F1000
G1 X43.423 Y288.733 F1000
G1 X44.342 Y288.721 F1000
G1 X45.261 Y288.711 F1000
G1 X46.18 Y288.703 F1000
G1 X47.099 Y288.697 F1000
G1 X48.018 Y288.692 F1000
G1 X49.856 Y288.684 F1000
G1 X51.694 Y288.679 F1000
G1 X54.451 Y288.675 F1000
G1 X59.047 Y288.672 F1000
G1 X70.075 Y288.671 F1000
G1 X79.265 F1000
G1 X80.184 Y288.67 F1000
G1 X81.103 Y288.668 F1000
G1 X82.022 Y288.663 F1000
G1 X82.941 Y288.654 F1000
G1 X83.86 Y288.639 F1000
G1 X84.779 Y288.615 F1000
G1 X85.697 Y288.582 F1000
G1 X86.615 Y288.536 F1000
G1 X87.532 Y288.478 F1000
G1 X88.448 Y288.408 F1000
G1 X89.364 Y288.326 F1000
G1 X90.278 Y288.234 F1000
G1 X91.192 Y288.132 F1000
G1 X92.104 Y288.023 F1000
G1 X93.016 Y287.909 F1000
G1 X93.928 Y287.792 F1000
G1 X95.75 Y287.555 F1000
G1 X96.662 Y287.438 F1000
G1 X97.574 Y287.324 F1000
G1 X98.486 Y287.214 F1000
G1 X99.399 Y287.109 F1000
G1 X100.313 Y287.01 F1000
G1 X101.227 Y286.917 F1000
G1 X102.142 Y286.83 F1000
G1 X103.058 Y286.75 F1000
G1 X103.974 Y286.677 F1000
G1 X104.89 Y286.61 F1000
G1 X105.807 Y286.549 F1000
G1 X106.725 Y286.494 F1000
G1 X107.642 Y286.446 F1000
G1 X108.56 Y286.402 F1000
G1 X109.479 Y286.364 F1000
G1 X110.397 Y286.33 F1000
G1 X111.315 Y286.301 F1000
G1 X112.234 Y286.275 F1000
G1 X113.153 Y286.253 F1000
G1 X114.072 Y286.234 F1000
G1 X114.991 Y286.217 F1000
G1 X115.91 Y286.203 F1000
G1 X116.828 Y286.191 F1000
G1 X117.747 Y286.181 F1000
G1 X118.666 Y286.172 F1000
G1 X119.585 Y286.165 F1000
G1 X120.504 Y286.159 F1000
G1 X122.342 Y286.15 F1000
G1 X124.18 Y286.144 F1000
G1 X126.937 Y286.138 F1000
G1 X130.614 Y286.134 F1000
G1 X137.966 Y286.131 F1000
G1 X157.265 F1000
G1 X159.103 Y286.134 F1000
G1 X160.022 Y286.136 F1000
G1 X160.941 Y286.142 F1000
G1 X161.86 Y286.15 F1000
G1 X162.779 Y286.163 F1000
G1 X163.698 Y286.183 F1000
G1 X164.617 Y286.211 F1000
G1 X165.535 Y286.25 F1000
G1 X166.452 Y286.301 F1000
G1 X167.369 Y286.369 F1000
G1 X168.284 Y286.457 F1000
G1 X169.196 Y286.572 F1000
G1 X170.103 Y286.717 F1000
G1 X171.003 Y286.903 F1000
G1 X171.825 Y287.122 F1000
G1 X172.421 Y287.334 F1000
G1 X172.905 Y287.551 F1000
G1 X172.967 Y287.585 F1000
G1 X173.226 Y287.765 F1000
G1 X173.442 Y287.997 F1000
G1 X173.603 Y288.269 F1000
G1 X173.702 Y288.569 F1000
G1 X173.736 Y288.884 F1000
G1 Y291.339 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y291.924 I-0.635 J-0.022 F1000
G1 X173.221 Y291.945 Z-3.012 F1000
G1 X173.153 Y291.965 Z-3 F1000
G1 X173.088 Y291.985 Z-2.98 F1000
G1 X173.025 Y292.005 Z-2.953 F1000
G1 X172.966 Y292.023 Z-2.919 F1000
G1 X172.91 Y292.04 Z-2.877 F1000
G1 X172.859 Y292.056 Z-2.83 F1000
G1 X172.814 Y292.07 Z-2.777 F1000
G1 X172.775 Y292.082 Z-2.719 F1000
G1 X172.742 Y292.092 Z-2.657 F1000
G1 X172.716 Y292.1 Z-2.591 F1000
G1 X172.697 Y292.106 Z-2.522 F1000
G1 X172.685 Y292.11 Z-2.452 F1000
G1 X172.682 Y292.111 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y297.141 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y297.137 Z-2.452 F1000
G1 X22.509 Y297.127 Z-2.522 F1000
G1 X22.499 Y297.11 Z-2.591 F1000
G1 X22.485 Y297.087 Z-2.657 F1000
G1 X22.467 Y297.057 Z-2.719 F1000
G1 X22.446 Y297.022 Z-2.777 F1000
G1 X22.422 Y296.981 Z-2.83 F1000
G1 X22.395 Y296.935 Z-2.877 F1000
G1 X22.365 Y296.885 Z-2.919 F1000
G1 X22.333 Y296.832 Z-2.953 F1000
G1 X22.3 Y296.775 Z-2.98 F1000
G1 X22.265 Y296.716 Z-3 F1000
G1 X22.229 Y296.656 Z-3.012 F1000
G1 X22.192 Y296.595 Z-3.016 F1000
G3 X21.971 Y295.841 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y293.544 F1000
G1 X21.983 Y293.294 F1000
G1 X22.015 Y293.053 F1000
G1 X22.068 Y292.806 F1000
G1 X22.153 Y292.523 F1000
G1 X22.273 Y292.215 F1000
G1 X22.429 Y291.893 F1000
G1 X22.644 Y291.527 F1000
G1 X22.898 Y291.166 F1000
G1 X23.239 Y290.756 F1000
G1 X23.631 Y290.353 F1000
G1 X24.129 Y289.919 F1000
G1 X24.744 Y289.464 F1000
G1 X25.487 Y289.002 F1000
G1 X26.304 Y288.58 F1000
G1 X27.148 Y288.218 F1000
G1 X28.013 Y287.907 F1000
G1 X28.892 Y287.64 F1000
G1 X29.782 Y287.411 F1000
G1 X30.68 Y287.214 F1000
G1 X31.583 Y287.045 F1000
G1 X32.491 Y286.9 F1000
G1 X33.402 Y286.777 F1000
G1 X34.315 Y286.672 F1000
G1 X35.229 Y286.583 F1000
G1 X36.145 Y286.508 F1000
G1 X37.062 Y286.444 F1000
G1 X37.979 Y286.39 F1000
G1 X38.897 Y286.345 F1000
G1 X39.816 Y286.308 F1000
G1 X40.734 Y286.276 F1000
G1 X41.653 Y286.25 F1000
G1 X42.572 Y286.228 F1000
G1 X43.49 Y286.21 F1000
G1 X44.409 Y286.196 F1000
G1 X45.328 Y286.183 F1000
G1 X46.247 Y286.173 F1000
G1 X47.166 Y286.165 F1000
G1 X48.085 Y286.159 F1000
G1 X49.004 Y286.153 F1000
G1 X50.842 Y286.145 F1000
G1 X52.68 Y286.14 F1000
G1 X55.437 Y286.136 F1000
G1 X60.032 Y286.132 F1000
G1 X69.223 Y286.131 F1000
G1 X77.494 F1000
G1 X79.332 Y286.129 F1000
G1 X80.251 Y286.126 F1000
G1 X81.17 Y286.12 F1000
G1 X82.089 Y286.111 F1000
G1 X83.008 Y286.095 F1000
G1 X83.926 Y286.072 F1000
G1 X84.845 Y286.04 F1000
G1 X85.763 Y285.998 F1000
G1 X86.68 Y285.946 F1000
G1 X87.597 Y285.882 F1000
G1 X88.513 Y285.808 F1000
G1 X89.429 Y285.724 F1000
G1 X90.343 Y285.632 F1000
G1 X91.256 Y285.532 F1000
G1 X92.169 Y285.427 F1000
G1 X93.082 Y285.318 F1000
G1 X95.818 Y284.982 F1000
G1 X96.731 Y284.872 F1000
G1 X97.644 Y284.764 F1000
G1 X98.557 Y284.661 F1000
G1 X99.47 Y284.562 F1000
G1 X100.385 Y284.468 F1000
G1 X101.299 Y284.379 F1000
G1 X102.215 Y284.296 F1000
G1 X103.13 Y284.219 F1000
G1 X104.047 Y284.148 F1000
G1 X104.963 Y284.083 F1000
G1 X105.881 Y284.024 F1000
G1 X106.798 Y283.97 F1000
G1 X107.716 Y283.922 F1000
G1 X108.634 Y283.879 F1000
G1 X109.552 Y283.84 F1000
G1 X110.47 Y283.806 F1000
G1 X111.389 Y283.775 F1000
G1 X112.308 Y283.749 F1000
G1 X113.226 Y283.726 F1000
G1 X114.145 Y283.705 F1000
G1 X115.064 Y283.688 F1000
G1 X115.983 Y283.673 F1000
G1 X116.902 Y283.66 F1000
G1 X117.821 Y283.649 F1000
G1 X118.74 Y283.639 F1000
G1 X119.659 Y283.631 F1000
G1 X120.578 Y283.625 F1000
G1 X122.416 Y283.614 F1000
G1 X124.254 Y283.607 F1000
G1 X127.011 Y283.6 F1000
G1 X130.687 Y283.595 F1000
G1 X136.201 Y283.592 F1000
G1 X154.581 Y283.591 F1000
G1 X157.338 Y283.593 F1000
G1 X158.257 Y283.594 F1000
G1 X159.176 Y283.598 F1000
G1 X160.095 Y283.603 F1000
G1 X161.014 Y283.612 F1000
G1 X161.933 Y283.624 F1000
G1 X162.852 Y283.643 F1000
G1 X163.771 Y283.668 F1000
G1 X164.689 Y283.703 F1000
G1 X165.607 Y283.749 F1000
G1 X166.524 Y283.808 F1000
G1 X167.44 Y283.884 F1000
G1 X168.354 Y283.981 F1000
G1 X169.265 Y284.104 F1000
G1 X170.171 Y284.258 F1000
G1 X171.069 Y284.452 F1000
G1 X171.881 Y284.676 F1000
G1 X172.466 Y284.89 F1000
G1 X172.945 Y285.11 F1000
G1 X172.978 Y285.128 F1000
G1 X173.234 Y285.31 F1000
G1 X173.446 Y285.541 F1000
G1 X173.605 Y285.811 F1000
G1 X173.703 Y286.109 F1000
G1 X173.736 Y286.421 F1000
G1 Y288.884 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y289.468 I-0.635 J-0.022 F1000
G1 X173.221 Y289.489 Z-3.012 F1000
G1 X173.153 Y289.51 Z-3 F1000
G1 X173.088 Y289.53 Z-2.98 F1000
G1 X173.025 Y289.549 Z-2.953 F1000
G1 X172.966 Y289.568 Z-2.919 F1000
G1 X172.91 Y289.585 Z-2.877 F1000
G1 X172.859 Y289.601 Z-2.83 F1000
G1 X172.814 Y289.615 Z-2.777 F1000
G1 X172.775 Y289.627 Z-2.719 F1000
G1 X172.742 Y289.637 Z-2.657 F1000
G1 X172.716 Y289.645 Z-2.591 F1000
G1 X172.697 Y289.651 Z-2.522 F1000
G1 X172.685 Y289.654 Z-2.452 F1000
G1 X172.682 Y289.655 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y294.843 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y294.84 Z-2.452 F1000
G1 X22.509 Y294.83 Z-2.522 F1000
G1 X22.499 Y294.813 Z-2.591 F1000
G1 X22.485 Y294.789 Z-2.657 F1000
G1 X22.467 Y294.76 Z-2.719 F1000
G1 X22.446 Y294.724 Z-2.777 F1000
G1 X22.422 Y294.684 Z-2.83 F1000
G1 X22.395 Y294.638 Z-2.877 F1000
G1 X22.365 Y294.588 Z-2.919 F1000
G1 X22.333 Y294.534 Z-2.953 F1000
G1 X22.3 Y294.478 Z-2.98 F1000
G1 X22.265 Y294.419 Z-3 F1000
G1 X22.229 Y294.359 Z-3.012 F1000
G1 X22.192 Y294.298 Z-3.016 F1000
G3 X21.971 Y293.544 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y291.247 F1000
G1 X21.986 Y290.938 F1000
G1 X22.018 Y290.696 F1000
G1 X22.072 Y290.443 F1000
G1 X22.157 Y290.16 F1000
G1 X22.28 Y289.844 F1000
G1 X22.437 Y289.522 F1000
G1 X22.657 Y289.148 F1000
G1 X22.913 Y288.784 F1000
G1 X23.26 Y288.366 F1000
G1 X23.657 Y287.958 F1000
G1 X24.166 Y287.514 F1000
G1 X24.794 Y287.049 F1000
G1 X25.556 Y286.575 F1000
G1 X26.373 Y286.154 F1000
G1 X27.216 Y285.79 F1000
G1 X28.08 Y285.476 F1000
G1 X28.958 Y285.204 F1000
G1 X29.846 Y284.969 F1000
G1 X30.743 Y284.766 F1000
G1 X31.645 Y284.591 F1000
G1 X32.551 Y284.44 F1000
G1 X33.461 Y284.31 F1000
G1 X34.374 Y284.199 F1000
G1 X35.288 Y284.103 F1000
G1 X36.203 Y284.021 F1000
G1 X37.119 Y283.952 F1000
G1 X38.036 Y283.893 F1000
G1 X38.954 Y283.843 F1000
G1 X39.872 Y283.8 F1000
G1 X40.79 Y283.765 F1000
G1 X41.709 Y283.735 F1000
G1 X42.628 Y283.71 F1000
G1 X43.546 Y283.689 F1000
G1 X44.465 Y283.671 F1000
G1 X45.384 Y283.657 F1000
G1 X46.303 Y283.645 F1000
G1 X47.222 Y283.635 F1000
G1 X48.141 Y283.627 F1000
G1 X49.06 Y283.62 F1000
G1 X50.898 Y283.61 F1000
G1 X52.736 Y283.603 F1000
G1 X55.493 Y283.597 F1000
G1 X59.169 Y283.594 F1000
G1 X66.521 Y283.591 F1000
G1 X69.279 F1000
G1 X76.631 Y283.59 F1000
G1 X78.469 Y283.588 F1000
G1 X79.388 Y283.584 F1000
G1 X80.307 Y283.578 F1000
G1 X81.226 Y283.568 F1000
G1 X82.145 Y283.553 F1000
G1 X83.063 Y283.531 F1000
G1 X83.982 Y283.501 F1000
G1 X84.9 Y283.463 F1000
G1 X85.818 Y283.415 F1000
G1 X86.735 Y283.357 F1000
G1 X87.652 Y283.29 F1000
G1 X88.567 Y283.214 F1000
G1 X89.483 Y283.129 F1000
G1 X90.397 Y283.038 F1000
G1 X91.311 Y282.94 F1000
G1 X92.224 Y282.839 F1000
G1 X93.137 Y282.734 F1000
G1 X95.876 Y282.415 F1000
G1 X96.789 Y282.31 F1000
G1 X97.702 Y282.209 F1000
G1 X98.616 Y282.11 F1000
G1 X99.53 Y282.016 F1000
G1 X100.445 Y281.926 F1000
G1 X101.36 Y281.842 F1000
G1 X102.276 Y281.762 F1000
G1 X103.192 Y281.688 F1000
G1 X104.108 Y281.619 F1000
G1 X105.025 Y281.556 F1000
G1 X105.942 Y281.498 F1000
G1 X106.86 Y281.445 F1000
G1 X107.777 Y281.397 F1000
G1 X108.695 Y281.354 F1000
G1 X109.614 Y281.315 F1000
G1 X110.532 Y281.28 F1000
G1 X111.45 Y281.249 F1000
G1 X112.369 Y281.222 F1000
G1 X113.288 Y281.198 F1000
G1 X114.206 Y281.177 F1000
G1 X115.125 Y281.159 F1000
G1 X116.044 Y281.143 F1000
G1 X116.963 Y281.129 F1000
G1 X117.882 Y281.117 F1000
G1 X118.801 Y281.106 F1000
G1 X119.72 Y281.098 F1000
G1 X120.639 Y281.09 F1000
G1 X122.477 Y281.078 F1000
G1 X124.315 Y281.07 F1000
G1 X127.072 Y281.062 F1000
G1 X129.829 Y281.057 F1000
G1 X134.424 Y281.053 F1000
G1 X143.614 Y281.051 F1000
G1 X154.643 F1000
G1 X156.481 Y281.053 F1000
G1 X157.4 Y281.055 F1000
G1 X158.319 Y281.059 F1000
G1 X159.238 Y281.064 F1000
G1 X160.157 Y281.072 F1000
G1 X161.076 Y281.085 F1000
G1 X161.995 Y281.102 F1000
G1 X162.913 Y281.125 F1000
G1 X163.832 Y281.156 F1000
G1 X164.75 Y281.197 F1000
G1 X165.667 Y281.249 F1000
G1 X166.584 Y281.315 F1000
G1 X167.499 Y281.399 F1000
G1 X168.412 Y281.503 F1000
G1 X169.322 Y281.633 F1000
G1 X170.227 Y281.794 F1000
G1 X171.124 Y281.994 F1000
G1 X171.928 Y282.222 F1000
G1 X172.502 Y282.437 F1000
G1 X172.978 Y282.659 F1000
G1 X172.988 Y282.665 F1000
G1 X173.241 Y282.847 F1000
G1 X173.45 Y283.077 F1000
G1 X173.607 Y283.347 F1000
G1 X173.703 Y283.643 F1000
G1 X173.736 Y283.952 F1000
G1 Y286.421 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y287.006 I-0.635 J-0.022 F1000
G1 X173.221 Y287.027 Z-3.012 F1000
G1 X173.153 Y287.047 Z-3 F1000
G1 X173.088 Y287.067 Z-2.98 F1000
G1 X173.025 Y287.087 Z-2.953 F1000
G1 X172.966 Y287.105 Z-2.919 F1000
G1 X172.91 Y287.122 Z-2.877 F1000
G1 X172.859 Y287.138 Z-2.83 F1000
G1 X172.814 Y287.152 Z-2.777 F1000
G1 X172.775 Y287.164 Z-2.719 F1000
G1 X172.742 Y287.174 Z-2.657 F1000
G1 X172.716 Y287.182 Z-2.591 F1000
G1 X172.697 Y287.188 Z-2.522 F1000
G1 X172.685 Y287.192 Z-2.452 F1000
G1 X172.682 Y287.193 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y292.546 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y292.543 Z-2.452 F1000
G1 X22.509 Y292.533 Z-2.522 F1000
G1 X22.499 Y292.516 Z-2.591 F1000
G1 X22.485 Y292.492 Z-2.657 F1000
G1 X22.467 Y292.463 Z-2.719 F1000
G1 X22.446 Y292.427 Z-2.777 F1000
G1 X22.422 Y292.386 Z-2.83 F1000
G1 X22.395 Y292.341 Z-2.877 F1000
G1 X22.365 Y292.291 Z-2.919 F1000
G1 X22.333 Y292.237 Z-2.953 F1000
G1 X22.3 Y292.181 Z-2.98 F1000
G1 X22.265 Y292.122 Z-3 F1000
G1 X22.229 Y292.062 Z-3.012 F1000
G1 X22.192 Y292 Z-3.016 F1000
G3 X21.971 Y291.247 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y288.741 F1000
G1 X21.979 Y288.572 F1000
G1 X22.011 Y288.329 F1000
G1 X22.067 Y288.069 F1000
G1 X22.152 Y287.787 F1000
G1 X22.278 Y287.463 F1000
G1 X22.435 Y287.139 F1000
G1 X22.657 Y286.761 F1000
G1 X22.918 Y286.39 F1000
G1 X23.269 Y285.967 F1000
G1 X23.673 Y285.553 F1000
G1 X24.192 Y285.1 F1000
G1 X24.833 Y284.626 F1000
G1 X25.61 Y284.142 F1000
G1 X26.427 Y283.721 F1000
G1 X27.27 Y283.355 F1000
G1 X28.133 Y283.038 F1000
G1 X29.009 Y282.762 F1000
G1 X29.897 Y282.523 F1000
G1 X30.792 Y282.315 F1000
G1 X31.693 Y282.134 F1000
G1 X32.598 Y281.977 F1000
G1 X33.507 Y281.841 F1000
G1 X34.419 Y281.724 F1000
G1 X35.332 Y281.622 F1000
G1 X36.247 Y281.535 F1000
G1 X37.163 Y281.46 F1000
G1 X38.08 Y281.396 F1000
G1 X38.997 Y281.341 F1000
G1 X39.915 Y281.294 F1000
G1 X40.833 Y281.255 F1000
G1 X41.752 Y281.221 F1000
G1 X42.67 Y281.193 F1000
G1 X43.589 Y281.169 F1000
G1 X44.508 Y281.148 F1000
G1 X45.427 Y281.132 F1000
G1 X46.346 Y281.117 F1000
G1 X47.264 Y281.106 F1000
G1 X48.183 Y281.096 F1000
G1 X49.102 Y281.088 F1000
G1 X50.021 Y281.081 F1000
G1 X51.859 Y281.071 F1000
G1 X53.697 Y281.064 F1000
G1 X56.455 Y281.058 F1000
G1 X60.131 Y281.054 F1000
G1 X67.483 Y281.051 F1000
G1 X69.321 F1000
G1 X75.754 Y281.05 F1000
G1 X76.673 Y281.049 F1000
G1 X77.592 Y281.047 F1000
G1 X78.511 Y281.043 F1000
G1 X79.43 Y281.036 F1000
G1 X80.349 Y281.026 F1000
G1 X81.268 Y281.012 F1000
G1 X82.187 Y280.991 F1000
G1 X83.105 Y280.964 F1000
G1 X84.024 Y280.929 F1000
G1 X84.942 Y280.885 F1000
G1 X85.859 Y280.833 F1000
G1 X86.776 Y280.772 F1000
G1 X87.693 Y280.702 F1000
G1 X88.608 Y280.625 F1000
G1 X89.523 Y280.541 F1000
G1 X90.438 Y280.451 F1000
G1 X91.352 Y280.357 F1000
G1 X92.266 Y280.258 F1000
G1 X93.179 Y280.158 F1000
G1 X95.92 Y279.853 F1000
G1 X96.833 Y279.753 F1000
G1 X97.747 Y279.656 F1000
G1 X98.661 Y279.563 F1000
G1 X99.576 Y279.472 F1000
G1 X100.491 Y279.387 F1000
G1 X101.406 Y279.305 F1000
G1 X102.322 Y279.228 F1000
G1 X103.238 Y279.157 F1000
G1 X104.155 Y279.09 F1000
G1 X105.072 Y279.028 F1000
G1 X105.989 Y278.971 F1000
G1 X106.907 Y278.919 F1000
G1 X107.824 Y278.871 F1000
G1 X108.742 Y278.828 F1000
G1 X109.661 Y278.789 F1000
G1 X110.579 Y278.754 F1000
G1 X111.498 Y278.723 F1000
G1 X112.416 Y278.695 F1000
G1 X113.335 Y278.67 F1000
G1 X114.254 Y278.648 F1000
G1 X115.172 Y278.629 F1000
G1 X116.091 Y278.612 F1000
G1 X117.01 Y278.598 F1000
G1 X117.929 Y278.585 F1000
G1 X118.848 Y278.574 F1000
G1 X119.767 Y278.564 F1000
G1 X120.686 Y278.556 F1000
G1 X121.605 Y278.549 F1000
G1 X123.443 Y278.538 F1000
G1 X125.281 Y278.53 F1000
G1 X128.038 Y278.522 F1000
G1 X130.795 Y278.517 F1000
G1 X135.39 Y278.513 F1000
G1 X144.58 Y278.511 F1000
G1 X153.771 Y278.512 F1000
G1 X155.609 Y278.514 F1000
G1 X156.528 Y278.516 F1000
G1 X157.447 Y278.519 F1000
G1 X158.366 Y278.525 F1000
G1 X159.285 Y278.533 F1000
G1 X160.204 Y278.544 F1000
G1 X161.123 Y278.56 F1000
G1 X162.041 Y278.581 F1000
G1 X162.96 Y278.609 F1000
G1 X163.878 Y278.645 F1000
G1 X164.796 Y278.691 F1000
G1 X165.713 Y278.749 F1000
G1 X166.629 Y278.821 F1000
G1 X167.544 Y278.911 F1000
G1 X168.456 Y279.021 F1000
G1 X169.365 Y279.157 F1000
G1 X170.269 Y279.323 F1000
G1 X171.165 Y279.529 F1000
G1 X171.964 Y279.761 F1000
G1 X172.531 Y279.976 F1000
G1 X172.89 Y280.146 F1000
G1 X173.173 Y280.322 F1000
G1 X173.41 Y280.557 F1000
G1 X173.588 Y280.839 F1000
G1 X173.698 Y281.154 F1000
G1 X173.736 Y281.485 F1000
G1 Y283.952 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y284.537 I-0.635 J-0.022 F1000
G1 X173.221 Y284.558 Z-3.012 F1000
G1 X173.153 Y284.579 Z-3 F1000
G1 X173.088 Y284.599 Z-2.98 F1000
G1 X173.025 Y284.618 Z-2.953 F1000
G1 X172.966 Y284.637 Z-2.919 F1000
G1 X172.91 Y284.654 Z-2.877 F1000
G1 X172.859 Y284.669 Z-2.83 F1000
G1 X172.814 Y284.683 Z-2.777 F1000
G1 X172.775 Y284.695 Z-2.719 F1000
G1 X172.742 Y284.706 Z-2.657 F1000
G1 X172.716 Y284.714 Z-2.591 F1000
G1 X172.697 Y284.719 Z-2.522 F1000
G1 X172.685 Y284.723 Z-2.452 F1000
G1 X172.682 Y284.724 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y290.04 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y290.037 Z-2.452 F1000
G1 X22.509 Y290.027 Z-2.522 F1000
G1 X22.499 Y290.01 Z-2.591 F1000
G1 X22.485 Y289.986 Z-2.657 F1000
G1 X22.467 Y289.957 Z-2.719 F1000
G1 X22.446 Y289.921 Z-2.777 F1000
G1 X22.422 Y289.88 Z-2.83 F1000
G1 X22.395 Y289.835 Z-2.877 F1000
G1 X22.365 Y289.785 Z-2.919 F1000
G1 X22.333 Y289.731 Z-2.953 F1000
G1 X22.3 Y289.675 Z-2.98 F1000
G1 X22.265 Y289.616 Z-3 F1000
G1 X22.229 Y289.556 Z-3.012 F1000
G1 X22.192 Y289.494 Z-3.016 F1000
G3 X21.971 Y288.741 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y286.444 F1000
G1 X21.984 Y286.176 F1000
G1 X22.016 Y285.934 F1000
G1 X22.072 Y285.671 F1000
G1 X22.157 Y285.388 F1000
G1 X22.285 Y285.061 F1000
G1 X22.442 Y284.736 F1000
G1 X22.666 Y284.356 F1000
G1 X22.931 Y283.978 F1000
G1 X23.283 Y283.554 F1000
G1 X23.693 Y283.134 F1000
G1 X24.22 Y282.674 F1000
G1 X24.87 Y282.194 F1000
G1 X25.65 Y281.708 F1000
G1 X26.466 Y281.286 F1000
G1 X27.308 Y280.918 F1000
G1 X28.17 Y280.598 F1000
G1 X29.045 Y280.318 F1000
G1 X29.931 Y280.074 F1000
G1 X30.825 Y279.861 F1000
G1 X31.725 Y279.675 F1000
G1 X32.63 Y279.513 F1000
G1 X33.538 Y279.371 F1000
G1 X34.449 Y279.249 F1000
G1 X35.361 Y279.142 F1000
G1 X36.276 Y279.049 F1000
G1 X37.191 Y278.969 F1000
G1 X38.108 Y278.9 F1000
G1 X39.025 Y278.841 F1000
G1 X39.942 Y278.79 F1000
G1 X40.86 Y278.746 F1000
G1 X41.779 Y278.708 F1000
G1 X42.697 Y278.677 F1000
G1 X43.616 Y278.65 F1000
G1 X44.534 Y278.627 F1000
G1 X45.453 Y278.608 F1000
G1 X46.372 Y278.591 F1000
G1 X47.291 Y278.578 F1000
G1 X48.21 Y278.566 F1000
G1 X49.129 Y278.556 F1000
G1 X50.048 Y278.548 F1000
G1 X50.967 Y278.542 F1000
G1 X52.805 Y278.532 F1000
G1 X54.643 Y278.525 F1000
G1 X57.4 Y278.518 F1000
G1 X61.076 Y278.514 F1000
G1 X67.509 Y278.512 F1000
G1 X69.347 Y278.511 F1000
G1 X73.942 F1000
G1 X75.78 Y278.508 F1000
G1 X76.699 Y278.506 F1000
G1 X77.618 Y278.502 F1000
G1 X78.537 Y278.495 F1000
G1 X79.456 Y278.486 F1000
G1 X80.375 Y278.472 F1000
G1 X81.294 Y278.453 F1000
G1 X82.213 Y278.428 F1000
G1 X83.131 Y278.395 F1000
G1 X84.049 Y278.356 F1000
G1 X84.967 Y278.308 F1000
G1 X85.885 Y278.253 F1000
G1 X86.801 Y278.19 F1000
G1 X87.718 Y278.119 F1000
G1 X88.634 Y278.042 F1000
G1 X89.549 Y277.959 F1000
G1 X90.464 Y277.871 F1000
G1 X91.378 Y277.779 F1000
G1 X92.292 Y277.684 F1000
G1 X94.12 Y277.49 F1000
G1 X95.947 Y277.295 F1000
G1 X96.862 Y277.2 F1000
G1 X97.776 Y277.107 F1000
G1 X98.691 Y277.017 F1000
G1 X99.605 Y276.931 F1000
G1 X100.521 Y276.848 F1000
G1 X101.436 Y276.769 F1000
G1 X102.352 Y276.695 F1000
G1 X103.269 Y276.626 F1000
G1 X104.186 Y276.56 F1000
G1 X105.103 Y276.5 F1000
G1 X106.02 Y276.444 F1000
G1 X106.937 Y276.392 F1000
G1 X107.855 Y276.345 F1000
G1 X108.773 Y276.302 F1000
G1 X109.691 Y276.263 F1000
G1 X110.61 Y276.228 F1000
G1 X111.528 Y276.196 F1000
G1 X112.447 Y276.168 F1000
G1 X113.366 Y276.142 F1000
G1 X114.284 Y276.12 F1000
G1 X115.203 Y276.1 F1000
G1 X116.122 Y276.082 F1000
G1 X117.041 Y276.066 F1000
G1 X117.96 Y276.053 F1000
G1 X118.879 Y276.041 F1000
G1 X119.798 Y276.031 F1000
G1 X120.717 Y276.022 F1000
G1 X121.636 Y276.014 F1000
G1 X123.474 Y276.002 F1000
G1 X125.312 Y275.993 F1000
G1 X127.15 Y275.986 F1000
G1 X129.907 Y275.98 F1000
G1 X133.583 Y275.975 F1000
G1 X140.016 Y275.972 F1000
G1 X151.963 Y275.971 F1000
G1 X154.72 Y275.974 F1000
G1 X155.639 Y275.976 F1000
G1 X156.558 Y275.98 F1000
G1 X157.477 Y275.985 F1000
G1 X158.396 Y275.992 F1000
G1 X159.315 Y276.003 F1000
G1 X160.234 Y276.017 F1000
G1 X161.153 Y276.036 F1000
G1 X162.072 Y276.061 F1000
G1 X162.99 Y276.093 F1000
G1 X163.908 Y276.134 F1000
G1 X164.826 Y276.185 F1000
G1 X165.743 Y276.248 F1000
G1 X166.658 Y276.325 F1000
G1 X167.573 Y276.42 F1000
G1 X168.484 Y276.536 F1000
G1 X169.392 Y276.676 F1000
G1 X170.296 Y276.847 F1000
G1 X171.19 Y277.056 F1000
G1 X171.996 Y277.294 F1000
G1 X172.545 Y277.505 F1000
G1 X172.896 Y277.674 F1000
G1 X173.178 Y277.851 F1000
G1 X173.412 Y278.086 F1000
G1 X173.589 Y278.367 F1000
G1 X173.699 Y278.68 F1000
G1 X173.736 Y279.01 F1000
G1 Y281.485 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y282.069 I-0.635 J-0.022 F1000
G1 X173.221 Y282.09 Z-3.012 F1000
G1 X173.153 Y282.111 Z-3 F1000
G1 X173.088 Y282.131 Z-2.98 F1000
G1 X173.025 Y282.151 Z-2.953 F1000
G1 X172.966 Y282.169 Z-2.919 F1000
G1 X172.91 Y282.186 Z-2.877 F1000
G1 X172.859 Y282.202 Z-2.83 F1000
G1 X172.814 Y282.216 Z-2.777 F1000
G1 X172.775 Y282.228 Z-2.719 F1000
G1 X172.742 Y282.238 Z-2.657 F1000
G1 X172.716 Y282.246 Z-2.591 F1000
G1 X172.697 Y282.252 Z-2.522 F1000
G1 X172.685 Y282.255 Z-2.452 F1000
G1 X172.682 Y282.257 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y287.743 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y287.74 Z-2.452 F1000
G1 X22.509 Y287.729 Z-2.522 F1000
G1 X22.499 Y287.712 Z-2.591 F1000
G1 X22.485 Y287.689 Z-2.657 F1000
G1 X22.467 Y287.659 Z-2.719 F1000
G1 X22.446 Y287.624 Z-2.777 F1000
G1 X22.422 Y287.583 Z-2.83 F1000
G1 X22.395 Y287.538 Z-2.877 F1000
G1 X22.365 Y287.488 Z-2.919 F1000
G1 X22.333 Y287.434 Z-2.953 F1000
G1 X22.3 Y287.378 Z-2.98 F1000
G1 X22.265 Y287.319 Z-3 F1000
G1 X22.229 Y287.258 Z-3.012 F1000
G1 X22.192 Y287.197 Z-3.016 F1000
G3 X21.971 Y286.444 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y283.938 F1000
G1 X21.979 Y283.78 F1000
G1 X22.011 Y283.537 F1000
G1 X22.068 Y283.269 F1000
G1 X22.153 Y282.986 F1000
G1 X22.282 Y282.655 F1000
G1 X22.441 Y282.327 F1000
G1 X22.664 Y281.948 F1000
G1 X22.935 Y281.562 F1000
G1 X23.289 Y281.136 F1000
G1 X23.705 Y280.709 F1000
G1 X24.239 Y280.243 F1000
G1 X24.898 Y279.756 F1000
G1 X25.678 Y279.271 F1000
G1 X26.493 Y278.847 F1000
G1 X27.335 Y278.477 F1000
G1 X28.195 Y278.154 F1000
G1 X29.069 Y277.871 F1000
G1 X29.954 Y277.623 F1000
G1 X30.847 Y277.405 F1000
G1 X31.746 Y277.214 F1000
G1 X32.65 Y277.047 F1000
G1 X33.557 Y276.9 F1000
G1 X34.467 Y276.772 F1000
G1 X35.379 Y276.661 F1000
G1 X36.293 Y276.563 F1000
G1 X37.208 Y276.478 F1000
G1 X38.124 Y276.405 F1000
G1 X39.041 Y276.341 F1000
G1 X39.958 Y276.286 F1000
G1 X40.876 Y276.238 F1000
G1 X41.794 Y276.197 F1000
G1 X42.713 Y276.162 F1000
G1 X43.631 Y276.132 F1000
G1 X44.55 Y276.106 F1000
G1 X45.469 Y276.085 F1000
G1 X46.387 Y276.066 F1000
G1 X47.306 Y276.051 F1000
G1 X48.225 Y276.037 F1000
G1 X49.144 Y276.026 F1000
G1 X50.063 Y276.017 F1000
G1 X50.982 Y276.009 F1000
G1 X51.901 Y276.002 F1000
G1 X53.739 Y275.992 F1000
G1 X55.577 Y275.985 F1000
G1 X58.334 Y275.979 F1000
G1 X62.01 Y275.974 F1000
G1 X68.443 Y275.972 F1000
G1 X69.362 F1000
G1 X73.039 Y275.97 F1000
G1 X74.877 Y275.968 F1000
G1 X75.796 Y275.965 F1000
G1 X76.715 Y275.961 F1000
G1 X77.634 Y275.955 F1000
G1 X78.553 Y275.946 F1000
G1 X79.472 Y275.933 F1000
G1 X80.39 Y275.915 F1000
G1 X81.309 Y275.892 F1000
G1 X82.228 Y275.863 F1000
G1 X83.146 Y275.827 F1000
G1 X84.064 Y275.784 F1000
G1 X84.982 Y275.734 F1000
G1 X85.899 Y275.676 F1000
G1 X86.816 Y275.612 F1000
G1 X87.732 Y275.541 F1000
G1 X88.648 Y275.464 F1000
G1 X89.563 Y275.382 F1000
G1 X90.478 Y275.296 F1000
G1 X91.393 Y275.207 F1000
G1 X92.307 Y275.115 F1000
G1 X95.05 Y274.833 F1000
G1 X95.964 Y274.74 F1000
G1 X96.879 Y274.649 F1000
G1 X97.793 Y274.56 F1000
G1 X98.708 Y274.473 F1000
G1 X99.623 Y274.39 F1000
G1 X100.539 Y274.31 F1000
G1 X101.455 Y274.234 F1000
G1 X102.371 Y274.162 F1000
G1 X103.288 Y274.094 F1000
G1 X104.204 Y274.031 F1000
G1 X105.121 Y273.971 F1000
G1 X106.039 Y273.916 F1000
G1 X106.956 Y273.865 F1000
G1 X107.874 Y273.819 F1000
G1 X108.792 Y273.776 F1000
G1 X109.71 Y273.737 F1000
G1 X110.629 Y273.701 F1000
G1 X111.547 Y273.669 F1000
G1 X112.466 Y273.64 F1000
G1 X113.384 Y273.614 F1000
G1 X114.303 Y273.591 F1000
G1 X115.222 Y273.57 F1000
G1 X116.141 Y273.552 F1000
G1 X117.06 Y273.535 F1000
G1 X117.979 Y273.521 F1000
G1 X118.898 Y273.509 F1000
G1 X119.816 Y273.498 F1000
G1 X120.735 Y273.488 F1000
G1 X121.654 Y273.48 F1000
G1 X123.492 Y273.466 F1000
G1 X125.33 Y273.456 F1000
G1 X127.168 Y273.449 F1000
G1 X129.926 Y273.442 F1000
G1 X133.602 Y273.436 F1000
G1 X139.116 Y273.433 F1000
G1 X149.225 Y273.431 F1000
G1 X152.901 Y273.433 F1000
G1 X154.739 Y273.437 F1000
G1 X155.658 Y273.44 F1000
G1 X156.577 Y273.445 F1000
G1 X157.496 Y273.452 F1000
G1 X158.415 Y273.461 F1000
G1 X159.334 Y273.474 F1000
G1 X160.253 Y273.491 F1000
G1 X161.172 Y273.514 F1000
G1 X162.09 Y273.542 F1000
G1 X163.008 Y273.578 F1000
G1 X163.926 Y273.623 F1000
G1 X164.844 Y273.678 F1000
G1 X165.76 Y273.746 F1000
G1 X166.676 Y273.827 F1000
G1 X167.589 Y273.927 F1000
G1 X168.501 Y274.046 F1000
G1 X169.408 Y274.191 F1000
G1 X170.311 Y274.365 F1000
G1 X171.205 Y274.577 F1000
G1 X172.01 Y274.818 F1000
G1 X172.558 Y275.031 F1000
G1 X172.901 Y275.198 F1000
G1 X173.181 Y275.374 F1000
G1 X173.414 Y275.609 F1000
G1 X173.59 Y275.889 F1000
G1 X173.699 Y276.202 F1000
G1 X173.736 Y276.531 F1000
G1 Y279.01 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y279.594 I-0.635 J-0.022 F1000
G1 X173.221 Y279.615 Z-3.012 F1000
G1 X173.153 Y279.636 Z-3 F1000
G1 X173.088 Y279.656 Z-2.98 F1000
G1 X173.025 Y279.676 Z-2.953 F1000
G1 X172.966 Y279.694 Z-2.919 F1000
G1 X172.91 Y279.711 Z-2.877 F1000
G1 X172.859 Y279.727 Z-2.83 F1000
G1 X172.814 Y279.741 Z-2.777 F1000
G1 X172.775 Y279.753 Z-2.719 F1000
G1 X172.742 Y279.763 Z-2.657 F1000
G1 X172.716 Y279.771 Z-2.591 F1000
G1 X172.697 Y279.777 Z-2.522 F1000
G1 X172.685 Y279.78 Z-2.452 F1000
G1 X172.682 Y279.782 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y285.237 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y285.234 Z-2.452 F1000
G1 X22.509 Y285.223 Z-2.522 F1000
G1 X22.499 Y285.206 Z-2.591 F1000
G1 X22.485 Y285.183 Z-2.657 F1000
G1 X22.467 Y285.153 Z-2.719 F1000
G1 X22.446 Y285.118 Z-2.777 F1000
G1 X22.422 Y285.077 Z-2.83 F1000
G1 X22.395 Y285.032 Z-2.877 F1000
G1 X22.365 Y284.982 Z-2.919 F1000
G1 X22.333 Y284.928 Z-2.953 F1000
G1 X22.3 Y284.871 Z-2.98 F1000
G1 X22.265 Y284.813 Z-3 F1000
G1 X22.229 Y284.752 Z-3.012 F1000
G1 X22.192 Y284.691 Z-3.016 F1000
G3 X21.971 Y283.938 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y281.64 F1000
G1 X21.985 Y281.36 F1000
G1 X22.017 Y281.118 F1000
G1 X22.075 Y280.847 F1000
G1 X22.159 Y280.564 F1000
G1 X22.289 Y280.232 F1000
G1 X22.449 Y279.902 F1000
G1 X22.672 Y279.522 F1000
G1 X22.946 Y279.133 F1000
G1 X23.301 Y278.705 F1000
G1 X23.722 Y278.274 F1000
G1 X24.261 Y277.803 F1000
G1 X24.926 Y277.311 F1000
G1 X25.707 Y276.826 F1000
G1 X26.522 Y276.401 F1000
G1 X27.362 Y276.029 F1000
G1 X28.221 Y275.703 F1000
G1 X29.095 Y275.417 F1000
G1 X29.979 Y275.165 F1000
G1 X30.871 Y274.944 F1000
G1 X31.769 Y274.749 F1000
G1 X32.672 Y274.577 F1000
G1 X33.578 Y274.426 F1000
G1 X34.488 Y274.294 F1000
G1 X35.399 Y274.177 F1000
G1 X36.313 Y274.076 F1000
G1 X37.227 Y273.986 F1000
G1 X38.143 Y273.908 F1000
G1 X39.059 Y273.841 F1000
G1 X39.977 Y273.782 F1000
G1 X40.894 Y273.73 F1000
G1 X41.812 Y273.686 F1000
G1 X42.73 Y273.648 F1000
G1 X43.649 Y273.615 F1000
G1 X44.567 Y273.587 F1000
G1 X45.486 Y273.563 F1000
G1 X46.405 Y273.542 F1000
G1 X47.324 Y273.524 F1000
G1 X48.243 Y273.509 F1000
G1 X49.162 Y273.497 F1000
G1 X50.08 Y273.486 F1000
G1 X50.999 Y273.477 F1000
G1 X51.918 Y273.469 F1000
G1 X52.837 Y273.463 F1000
G1 X54.675 Y273.453 F1000
G1 X56.513 Y273.446 F1000
G1 X59.271 Y273.439 F1000
G1 X62.947 Y273.435 F1000
G1 X69.38 Y273.432 F1000
G1 X73.056 Y273.429 F1000
G1 X74.894 Y273.425 F1000
G1 X75.813 Y273.421 F1000
G1 X76.732 Y273.415 F1000
G1 X77.651 Y273.406 F1000
G1 X78.57 Y273.394 F1000
G1 X79.489 Y273.378 F1000
G1 X80.407 Y273.357 F1000
G1 X81.326 Y273.33 F1000
G1 X82.245 Y273.297 F1000
G1 X83.163 Y273.258 F1000
G1 X84.081 Y273.213 F1000
G1 X84.998 Y273.16 F1000
G1 X85.915 Y273.101 F1000
G1 X86.832 Y273.036 F1000
G1 X87.748 Y272.965 F1000
G1 X88.664 Y272.889 F1000
G1 X89.58 Y272.809 F1000
G1 X90.495 Y272.725 F1000
G1 X91.41 Y272.637 F1000
G1 X92.324 Y272.548 F1000
G1 X95.068 Y272.277 F1000
G1 X95.983 Y272.187 F1000
G1 X96.897 Y272.099 F1000
G1 X97.812 Y272.013 F1000
G1 X98.728 Y271.93 F1000
G1 X99.643 Y271.849 F1000
G1 X100.559 Y271.772 F1000
G1 X101.475 Y271.698 F1000
G1 X102.391 Y271.628 F1000
G1 X103.308 Y271.562 F1000
G1 X104.225 Y271.5 F1000
G1 X105.142 Y271.442 F1000
G1 X106.059 Y271.388 F1000
G1 X106.977 Y271.337 F1000
G1 X107.895 Y271.291 F1000
G1 X108.813 Y271.248 F1000
G1 X109.731 Y271.209 F1000
G1 X110.649 Y271.173 F1000
G1 X111.568 Y271.141 F1000
G1 X112.486 Y271.112 F1000
G1 X113.405 Y271.085 F1000
G1 X114.324 Y271.061 F1000
G1 X115.243 Y271.04 F1000
G1 X116.161 Y271.021 F1000
G1 X117.08 Y271.004 F1000
G1 X117.999 Y270.989 F1000
G1 X118.918 Y270.976 F1000
G1 X119.837 Y270.964 F1000
G1 X120.756 Y270.954 F1000
G1 X121.675 Y270.945 F1000
G1 X122.594 Y270.938 F1000
G1 X124.432 Y270.925 F1000
G1 X126.27 Y270.915 F1000
G1 X128.108 Y270.908 F1000
G1 X130.865 Y270.901 F1000
G1 X134.541 Y270.896 F1000
G1 X140.055 Y270.893 F1000
G1 X149.245 Y270.892 F1000
G1 X152.003 Y270.893 F1000
G1 X153.841 Y270.897 F1000
G1 X154.76 Y270.9 F1000
G1 X155.679 Y270.904 F1000
G1 X156.598 Y270.911 F1000
G1 X157.517 Y270.92 F1000
G1 X158.436 Y270.932 F1000
G1 X159.354 Y270.947 F1000
G1 X160.273 Y270.967 F1000
G1 X161.192 Y270.993 F1000
G1 X162.11 Y271.025 F1000
G1 X163.029 Y271.064 F1000
G1 X163.946 Y271.113 F1000
G1 X164.863 Y271.172 F1000
G1 X165.78 Y271.243 F1000
G1 X166.695 Y271.329 F1000
G1 X167.608 Y271.432 F1000
G1 X168.518 Y271.556 F1000
G1 X169.426 Y271.703 F1000
G1 X170.327 Y271.881 F1000
G1 X171.221 Y272.096 F1000
G1 X172.024 Y272.339 F1000
G1 X172.571 Y272.554 F1000
G1 X172.905 Y272.717 F1000
G1 X173.184 Y272.894 F1000
G1 X173.416 Y273.128 F1000
G1 X173.591 Y273.408 F1000
G1 X173.699 Y273.72 F1000
G1 X173.736 Y274.048 F1000
G1 Y276.531 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y277.115 I-0.635 J-0.022 F1000
G1 X173.221 Y277.136 Z-3.012 F1000
G1 X173.153 Y277.157 Z-3 F1000
G1 X173.088 Y277.177 Z-2.98 F1000
G1 X173.025 Y277.197 Z-2.953 F1000
G1 X172.966 Y277.215 Z-2.919 F1000
G1 X172.91 Y277.232 Z-2.877 F1000
G1 X172.859 Y277.248 Z-2.83 F1000
G1 X172.814 Y277.262 Z-2.777 F1000
G1 X172.775 Y277.274 Z-2.719 F1000
G1 X172.742 Y277.284 Z-2.657 F1000
G1 X172.716 Y277.292 Z-2.591 F1000
G1 X172.697 Y277.298 Z-2.522 F1000
G1 X172.685 Y277.301 Z-2.452 F1000
G1 X172.682 Y277.302 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y282.94 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y282.936 Z-2.452 F1000
G1 X22.509 Y282.926 Z-2.522 F1000
G1 X22.499 Y282.909 Z-2.591 F1000
G1 X22.485 Y282.886 Z-2.657 F1000
G1 X22.467 Y282.856 Z-2.719 F1000
G1 X22.446 Y282.821 Z-2.777 F1000
G1 X22.422 Y282.78 Z-2.83 F1000
G1 X22.395 Y282.734 Z-2.877 F1000
G1 X22.365 Y282.684 Z-2.919 F1000
G1 X22.333 Y282.631 Z-2.953 F1000
G1 X22.3 Y282.574 Z-2.98 F1000
G1 X22.265 Y282.515 Z-3 F1000
G1 X22.229 Y282.455 Z-3.012 F1000
G1 X22.192 Y282.394 Z-3.016 F1000
G3 X21.971 Y281.64 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y279.134 F1000
G1 X21.981 Y278.943 F1000
G1 X22.012 Y278.701 F1000
G1 X22.071 Y278.426 F1000
G1 X22.156 Y278.143 F1000
G1 X22.286 Y277.81 F1000
G1 X22.448 Y277.475 F1000
G1 X22.671 Y277.096 F1000
G1 X22.949 Y276.701 F1000
G1 X23.305 Y276.272 F1000
G1 X23.731 Y275.835 F1000
G1 X24.276 Y275.36 F1000
G1 X24.949 Y274.862 F1000
G1 X25.729 Y274.376 F1000
G1 X26.544 Y273.951 F1000
G1 X27.383 Y273.577 F1000
G1 X28.242 Y273.249 F1000
G1 X29.114 Y272.96 F1000
G1 X29.997 Y272.705 F1000
G1 X30.888 Y272.48 F1000
G1 X31.785 Y272.281 F1000
G1 X32.688 Y272.106 F1000
G1 X33.593 Y271.951 F1000
G1 X34.502 Y271.814 F1000
G1 X35.413 Y271.693 F1000
G1 X36.326 Y271.587 F1000
G1 X37.24 Y271.494 F1000
G1 X38.156 Y271.412 F1000
G1 X39.072 Y271.341 F1000
G1 X39.989 Y271.278 F1000
G1 X40.906 Y271.223 F1000
G1 X41.824 Y271.176 F1000
G1 X42.742 Y271.135 F1000
G1 X43.66 Y271.099 F1000
G1 X44.579 Y271.068 F1000
G1 X45.498 Y271.041 F1000
G1 X46.416 Y271.018 F1000
G1 X47.335 Y270.999 F1000
G1 X48.254 Y270.982 F1000
G1 X49.173 Y270.968 F1000
G1 X50.092 Y270.956 F1000
G1 X51.011 Y270.945 F1000
G1 X51.93 Y270.936 F1000
G1 X52.849 Y270.929 F1000
G1 X54.687 Y270.917 F1000
G1 X56.525 Y270.909 F1000
G1 X59.282 Y270.901 F1000
G1 X62.039 Y270.897 F1000
G1 X66.634 Y270.893 F1000
G1 X69.391 Y270.892 F1000
G1 X72.148 Y270.889 F1000
G1 X73.986 Y270.885 F1000
G1 X74.905 Y270.881 F1000
G1 X75.824 Y270.875 F1000
G1 X76.743 Y270.867 F1000
G1 X77.662 Y270.855 F1000
G1 X78.581 Y270.84 F1000
G1 X79.5 Y270.821 F1000
G1 X80.419 Y270.797 F1000
G1 X81.337 Y270.768 F1000
G1 X82.255 Y270.732 F1000
G1 X83.174 Y270.691 F1000
G1 X84.091 Y270.643 F1000
G1 X85.009 Y270.589 F1000
G1 X85.926 Y270.529 F1000
G1 X86.842 Y270.464 F1000
G1 X87.759 Y270.393 F1000
G1 X88.675 Y270.318 F1000
G1 X89.59 Y270.239 F1000
G1 X90.506 Y270.156 F1000
G1 X91.421 Y270.072 F1000
G1 X92.336 Y269.985 F1000
G1 X95.08 Y269.722 F1000
G1 X95.995 Y269.636 F1000
G1 X96.91 Y269.551 F1000
G1 X97.825 Y269.467 F1000
G1 X98.741 Y269.387 F1000
G1 X99.657 Y269.309 F1000
G1 X100.573 Y269.234 F1000
G1 X101.489 Y269.162 F1000
G1 X102.405 Y269.094 F1000
G1 X103.322 Y269.03 F1000
G1 X104.239 Y268.969 F1000
G1 X105.156 Y268.912 F1000
G1 X106.074 Y268.858 F1000
G1 X106.991 Y268.809 F1000
G1 X107.909 Y268.763 F1000
G1 X108.827 Y268.72 F1000
G1 X109.746 Y268.681 F1000
G1 X110.664 Y268.645 F1000
G1 X111.582 Y268.613 F1000
G1 X112.501 Y268.583 F1000
G1 X113.42 Y268.556 F1000
G1 X114.338 Y268.532 F1000
G1 X115.257 Y268.51 F1000
G1 X116.176 Y268.49 F1000
G1 X117.095 Y268.473 F1000
G1 X118.014 Y268.457 F1000
G1 X118.932 Y268.443 F1000
G1 X119.851 Y268.431 F1000
G1 X120.77 Y268.42 F1000
G1 X121.689 Y268.411 F1000
G1 X122.608 Y268.403 F1000
G1 X124.446 Y268.389 F1000
G1 X126.284 Y268.379 F1000
G1 X128.122 Y268.371 F1000
G1 X130.879 Y268.363 F1000
G1 X134.555 Y268.357 F1000
G1 X139.151 Y268.353 F1000
G1 X147.422 Y268.352 F1000
G1 X151.098 Y268.353 F1000
G1 X152.936 Y268.357 F1000
G1 X153.855 Y268.36 F1000
G1 X154.774 Y268.364 F1000
G1 X155.693 Y268.37 F1000
G1 X156.612 Y268.378 F1000
G1 X157.531 Y268.389 F1000
G1 X158.45 Y268.403 F1000
G1 X159.369 Y268.421 F1000
G1 X160.287 Y268.444 F1000
G1 X161.206 Y268.472 F1000
G1 X162.124 Y268.507 F1000
G1 X163.042 Y268.55 F1000
G1 X163.96 Y268.602 F1000
G1 X164.877 Y268.665 F1000
G1 X165.793 Y268.74 F1000
G1 X166.707 Y268.829 F1000
G1 X167.62 Y268.936 F1000
G1 X168.53 Y269.062 F1000
G1 X169.437 Y269.213 F1000
G1 X170.338 Y269.393 F1000
G1 X171.231 Y269.61 F1000
G1 X172.034 Y269.856 F1000
G1 X172.581 Y270.072 F1000
G1 X172.908 Y270.233 F1000
G1 X173.186 Y270.41 F1000
G1 X173.417 Y270.644 F1000
G1 X173.591 Y270.924 F1000
G1 X173.699 Y271.235 F1000
G1 X173.736 Y271.562 F1000
G1 Y274.048 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y274.633 I-0.635 J-0.022 F1000
G1 X173.221 Y274.654 Z-3.012 F1000
G1 X173.153 Y274.674 Z-3 F1000
G1 X173.088 Y274.695 Z-2.98 F1000
G1 X173.025 Y274.714 Z-2.953 F1000
G1 X172.966 Y274.732 Z-2.919 F1000
G1 X172.91 Y274.749 Z-2.877 F1000
G1 X172.859 Y274.765 Z-2.83 F1000
G1 X172.814 Y274.779 Z-2.777 F1000
G1 X172.775 Y274.791 Z-2.719 F1000
G1 X172.742 Y274.801 Z-2.657 F1000
G1 X172.716 Y274.809 Z-2.591 F1000
G1 X172.697 Y274.815 Z-2.522 F1000
G1 X172.685 Y274.819 Z-2.452 F1000
G1 X172.682 Y274.82 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y280.434 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y280.43 Z-2.452 F1000
G1 X22.509 Y280.42 Z-2.522 F1000
G1 X22.499 Y280.403 Z-2.591 F1000
G1 X22.485 Y280.38 Z-2.657 F1000
G1 X22.467 Y280.35 Z-2.719 F1000
G1 X22.446 Y280.315 Z-2.777 F1000
G1 X22.422 Y280.274 Z-2.83 F1000
G1 X22.395 Y280.228 Z-2.877 F1000
G1 X22.365 Y280.178 Z-2.919 F1000
G1 X22.333 Y280.125 Z-2.953 F1000
G1 X22.3 Y280.068 Z-2.98 F1000
G1 X22.265 Y280.009 Z-3 F1000
G1 X22.229 Y279.949 Z-3.012 F1000
G1 X22.192 Y279.888 Z-3.016 F1000
G3 X21.971 Y279.134 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y276.837 F1000
G1 X21.988 Y276.506 F1000
G1 X22.019 Y276.264 F1000
G1 X22.078 Y275.988 F1000
G1 X22.163 Y275.705 F1000
G1 X22.293 Y275.371 F1000
G1 X22.456 Y275.035 F1000
G1 X22.68 Y274.655 F1000
G1 X22.959 Y274.258 F1000
G1 X23.317 Y273.827 F1000
G1 X23.746 Y273.387 F1000
G1 X24.295 Y272.908 F1000
G1 X24.973 Y272.406 F1000
G1 X25.753 Y271.921 F1000
G1 X26.568 Y271.494 F1000
G1 X27.407 Y271.119 F1000
G1 X28.264 Y270.789 F1000
G1 X29.136 Y270.498 F1000
G1 X30.018 Y270.24 F1000
G1 X30.908 Y270.012 F1000
G1 X31.805 Y269.81 F1000
G1 X32.706 Y269.631 F1000
G1 X33.611 Y269.472 F1000
G1 X34.52 Y269.332 F1000
G1 X35.43 Y269.207 F1000
G1 X36.343 Y269.098 F1000
G1 X37.257 Y269.001 F1000
G1 X38.172 Y268.915 F1000
G1 X39.088 Y268.84 F1000
G1 X40.004 Y268.774 F1000
G1 X40.921 Y268.716 F1000
G1 X41.839 Y268.666 F1000
G1 X42.757 Y268.621 F1000
G1 X43.675 Y268.583 F1000
G1 X44.594 Y268.55 F1000
G1 X45.512 Y268.521 F1000
G1 X46.431 Y268.496 F1000
G1 X47.35 Y268.474 F1000
G1 X48.268 Y268.455 F1000
G1 X49.187 Y268.44 F1000
G1 X50.106 Y268.426 F1000
G1 X51.025 Y268.414 F1000
G1 X51.944 Y268.404 F1000
G1 X52.863 Y268.396 F1000
G1 X53.782 Y268.388 F1000
G1 X55.62 Y268.377 F1000
G1 X57.458 Y268.369 F1000
G1 X60.215 Y268.361 F1000
G1 X63.891 Y268.356 F1000
G1 X69.405 Y268.352 F1000
G1 X71.243 Y268.35 F1000
G1 X73.082 Y268.345 F1000
G1 X74.001 Y268.341 F1000
G1 X74.92 Y268.335 F1000
G1 X75.839 Y268.328 F1000
G1 X76.757 Y268.317 F1000
G1 X77.676 Y268.303 F1000
G1 X78.595 Y268.286 F1000
G1 X79.514 Y268.264 F1000
G1 X80.433 Y268.237 F1000
G1 X81.351 Y268.205 F1000
G1 X82.269 Y268.167 F1000
G1 X83.187 Y268.123 F1000
G1 X84.105 Y268.074 F1000
G1 X85.022 Y268.019 F1000
G1 X85.939 Y267.958 F1000
G1 X86.856 Y267.893 F1000
G1 X87.772 Y267.823 F1000
G1 X88.688 Y267.748 F1000
G1 X89.604 Y267.671 F1000
G1 X90.52 Y267.59 F1000
G1 X91.435 Y267.508 F1000
G1 X93.265 Y267.339 F1000
G1 X95.095 Y267.169 F1000
G1 X96.011 Y267.085 F1000
G1 X96.926 Y267.003 F1000
G1 X97.841 Y266.922 F1000
G1 X98.757 Y266.844 F1000
G1 X99.673 Y266.768 F1000
G1 X100.589 Y266.695 F1000
G1 X101.505 Y266.626 F1000
G1 X102.422 Y266.559 F1000
G1 X103.339 Y266.496 F1000
G1 X104.256 Y266.437 F1000
G1 X105.173 Y266.381 F1000
G1 X106.091 Y266.328 F1000
G1 X107.009 Y266.279 F1000
G1 X107.926 Y266.233 F1000
G1 X108.845 Y266.191 F1000
G1 X109.763 Y266.152 F1000
G1 X110.681 Y266.116 F1000
G1 X111.599 Y266.084 F1000
G1 X112.518 Y266.054 F1000
G1 X113.437 Y266.026 F1000
G1 X114.355 Y266.002 F1000
G1 X115.274 Y265.979 F1000
G1 X116.193 Y265.959 F1000
G1 X117.112 Y265.941 F1000
G1 X118.031 Y265.925 F1000
G1 X118.949 Y265.911 F1000
G1 X119.868 Y265.898 F1000
G1 X120.787 Y265.887 F1000
G1 X121.706 Y265.877 F1000
G1 X122.625 Y265.868 F1000
G1 X124.463 Y265.853 F1000
G1 X126.301 Y265.842 F1000
G1 X128.139 Y265.834 F1000
G1 X130.896 Y265.825 F1000
G1 X133.653 Y265.819 F1000
G1 X138.249 Y265.815 F1000
G1 X144.682 Y265.812 F1000
G1 X149.277 Y265.813 F1000
G1 X151.115 Y265.815 F1000
G1 X152.953 Y265.82 F1000
G1 X153.872 Y265.824 F1000
G1 X154.791 Y265.829 F1000
G1 X155.71 Y265.837 F1000
G1 X156.629 Y265.846 F1000
G1 X157.548 Y265.859 F1000
G1 X158.467 Y265.875 F1000
G1 X159.385 Y265.896 F1000
G1 X160.304 Y265.921 F1000
G1 X161.223 Y265.952 F1000
G1 X162.141 Y265.99 F1000
G1 X163.059 Y266.036 F1000
G1 X163.976 Y266.092 F1000
G1 X164.893 Y266.157 F1000
G1 X165.808 Y266.236 F1000
G1 X166.723 Y266.328 F1000
G1 X167.635 Y266.438 F1000
G1 X168.545 Y266.568 F1000
G1 X169.451 Y266.721 F1000
G1 X170.352 Y266.904 F1000
G1 X171.244 Y267.123 F1000
G1 X172.045 Y267.37 F1000
G1 X172.592 Y267.588 F1000
G1 X172.911 Y267.746 F1000
G1 X173.188 Y267.924 F1000
G1 X173.419 Y268.158 F1000
G1 X173.592 Y268.437 F1000
G1 X173.7 Y268.747 F1000
G1 X173.736 Y269.074 F1000
G1 Y271.562 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y272.147 I-0.635 J-0.022 F1000
G1 X173.221 Y272.168 Z-3.012 F1000
G1 X173.153 Y272.189 Z-3 F1000
G1 X173.088 Y272.209 Z-2.98 F1000
G1 X173.025 Y272.228 Z-2.953 F1000
G1 X172.966 Y272.247 Z-2.919 F1000
G1 X172.91 Y272.264 Z-2.877 F1000
G1 X172.859 Y272.279 Z-2.83 F1000
G1 X172.814 Y272.293 Z-2.777 F1000
G1 X172.775 Y272.305 Z-2.719 F1000
G1 X172.742 Y272.316 Z-2.657 F1000
G1 X172.716 Y272.324 Z-2.591 F1000
G1 X172.697 Y272.329 Z-2.522 F1000
G1 X172.685 Y272.333 Z-2.452 F1000
G1 X172.682 Y272.334 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y278.137 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y278.133 Z-2.452 F1000
G1 X22.509 Y278.123 Z-2.522 F1000
G1 X22.499 Y278.106 Z-2.591 F1000
G1 X22.485 Y278.083 Z-2.657 F1000
G1 X22.467 Y278.053 Z-2.719 F1000
G1 X22.446 Y278.018 Z-2.777 F1000
G1 X22.422 Y277.977 Z-2.83 F1000
G1 X22.395 Y277.931 Z-2.877 F1000
G1 X22.365 Y277.881 Z-2.919 F1000
G1 X22.333 Y277.828 Z-2.953 F1000
G1 X22.3 Y277.771 Z-2.98 F1000
G1 X22.265 Y277.712 Z-3 F1000
G1 X22.229 Y277.652 Z-3.012 F1000
G1 X22.192 Y277.591 Z-3.016 F1000
G3 X21.971 Y276.837 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y274.331 F1000
G1 X21.984 Y274.074 F1000
G1 X22.016 Y273.832 F1000
G1 X22.075 Y273.553 F1000
G1 X22.16 Y273.27 F1000
G1 X22.29 Y272.936 F1000
G1 X22.456 Y272.595 F1000
G1 X22.679 Y272.215 F1000
G1 X22.961 Y271.814 F1000
G1 X23.32 Y271.381 F1000
G1 X23.754 Y270.937 F1000
G1 X24.307 Y270.454 F1000
G1 X24.992 Y269.948 F1000
G1 X25.772 Y269.462 F1000
G1 X26.586 Y269.035 F1000
G1 X27.424 Y268.659 F1000
G1 X28.281 Y268.327 F1000
G1 X29.152 Y268.033 F1000
G1 X30.033 Y267.773 F1000
G1 X30.923 Y267.542 F1000
G1 X31.819 Y267.336 F1000
G1 X32.719 Y267.154 F1000
G1 X33.624 Y266.992 F1000
G1 X34.532 Y266.848 F1000
G1 X35.442 Y266.72 F1000
G1 X36.354 Y266.607 F1000
G1 X37.267 Y266.507 F1000
G1 X38.182 Y266.418 F1000
G1 X39.098 Y266.339 F1000
G1 X40.014 Y266.27 F1000
G1 X40.931 Y266.209 F1000
G1 X41.849 Y266.156 F1000
G1 X42.766 Y266.109 F1000
G1 X43.685 Y266.068 F1000
G1 X44.603 Y266.032 F1000
G1 X45.521 Y266.001 F1000
G1 X46.44 Y265.973 F1000
G1 X47.359 Y265.95 F1000
G1 X48.277 Y265.93 F1000
G1 X49.196 Y265.912 F1000
G1 X50.115 Y265.897 F1000
G1 X51.034 Y265.884 F1000
G1 X51.953 Y265.873 F1000
G1 X52.872 Y265.863 F1000
G1 X53.791 Y265.855 F1000
G1 X54.71 Y265.848 F1000
G1 X56.548 Y265.837 F1000
G1 X58.386 Y265.829 F1000
G1 X61.143 Y265.822 F1000
G1 X64.819 Y265.816 F1000
G1 X69.414 Y265.811 F1000
G1 X71.252 Y265.808 F1000
G1 X72.171 Y265.805 F1000
G1 X73.09 Y265.801 F1000
G1 X74.009 Y265.796 F1000
G1 X74.928 Y265.789 F1000
G1 X75.847 Y265.779 F1000
G1 X76.766 Y265.766 F1000
G1 X77.685 Y265.75 F1000
G1 X78.604 Y265.73 F1000
G1 X79.523 Y265.706 F1000
G1 X80.441 Y265.677 F1000
G1 X81.36 Y265.642 F1000
G1 X82.278 Y265.602 F1000
G1 X83.196 Y265.557 F1000
G1 X84.113 Y265.507 F1000
G1 X85.031 Y265.451 F1000
G1 X85.948 Y265.39 F1000
G1 X86.864 Y265.324 F1000
G1 X87.781 Y265.255 F1000
G1 X88.697 Y265.182 F1000
G1 X89.613 Y265.105 F1000
G1 X90.528 Y265.027 F1000
G1 X91.444 Y264.946 F1000
G1 X95.105 Y264.617 F1000
G1 X96.02 Y264.536 F1000
G1 X96.936 Y264.456 F1000
G1 X97.852 Y264.378 F1000
G1 X98.768 Y264.302 F1000
G1 X99.684 Y264.228 F1000
G1 X100.6 Y264.157 F1000
G1 X101.516 Y264.089 F1000
G1 X102.433 Y264.024 F1000
G1 X103.35 Y263.963 F1000
G1 X104.267 Y263.904 F1000
G1 X105.185 Y263.849 F1000
G1 X106.102 Y263.797 F1000
G1 X107.02 Y263.749 F1000
G1 X107.938 Y263.704 F1000
G1 X108.856 Y263.662 F1000
G1 X109.774 Y263.623 F1000
G1 X110.692 Y263.587 F1000
G1 X111.611 Y263.554 F1000
G1 X112.529 Y263.524 F1000
G1 X113.448 Y263.496 F1000
G1 X114.367 Y263.471 F1000
G1 X115.285 Y263.449 F1000
G1 X116.204 Y263.428 F1000
G1 X117.123 Y263.41 F1000
G1 X118.042 Y263.393 F1000
G1 X118.961 Y263.378 F1000
G1 X119.88 Y263.365 F1000
G1 X120.799 Y263.353 F1000
G1 X121.718 Y263.342 F1000
G1 X122.637 Y263.333 F1000
G1 X124.475 Y263.318 F1000
G1 X126.313 Y263.306 F1000
G1 X128.151 Y263.297 F1000
G1 X130.908 Y263.287 F1000
G1 X133.665 Y263.281 F1000
G1 X137.341 Y263.276 F1000
G1 X142.855 Y263.273 F1000
G1 X147.45 F1000
G1 X150.207 Y263.275 F1000
G1 X152.045 Y263.279 F1000
G1 X152.964 Y263.283 F1000
G1 X153.883 Y263.288 F1000
G1 X154.802 Y263.295 F1000
G1 X155.721 Y263.304 F1000
G1 X156.64 Y263.315 F1000
G1 X157.559 Y263.33 F1000
G1 X158.478 Y263.348 F1000
G1 X159.396 Y263.371 F1000
G1 X160.315 Y263.399 F1000
G1 X161.233 Y263.433 F1000
G1 X162.152 Y263.474 F1000
G1 X163.069 Y263.523 F1000
G1 X163.987 Y263.581 F1000
G1 X164.903 Y263.649 F1000
G1 X165.818 Y263.73 F1000
G1 X166.732 Y263.826 F1000
G1 X167.645 Y263.939 F1000
G1 X168.554 Y264.071 F1000
G1 X169.46 Y264.227 F1000
G1 X170.36 Y264.411 F1000
G1 X171.252 Y264.633 F1000
G1 X172.053 Y264.881 F1000
G1 X172.599 Y265.1 F1000
G1 X172.914 Y265.257 F1000
G1 X173.19 Y265.434 F1000
G1 X173.42 Y265.668 F1000
G1 X173.592 Y265.947 F1000
G1 X173.7 Y266.257 F1000
G1 X173.736 Y266.583 F1000
G1 Y269.074 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y269.659 I-0.635 J-0.022 F1000
G1 X173.221 Y269.68 Z-3.012 F1000
G1 X173.153 Y269.7 Z-3 F1000
G1 X173.088 Y269.721 Z-2.98 F1000
G1 X173.025 Y269.74 Z-2.953 F1000
G1 X172.966 Y269.758 Z-2.919 F1000
G1 X172.91 Y269.775 Z-2.877 F1000
G1 X172.859 Y269.791 Z-2.83 F1000
G1 X172.814 Y269.805 Z-2.777 F1000
G1 X172.775 Y269.817 Z-2.719 F1000
G1 X172.742 Y269.827 Z-2.657 F1000
G1 X172.716 Y269.835 Z-2.591 F1000
G1 X172.697 Y269.841 Z-2.522 F1000
G1 X172.685 Y269.845 Z-2.452 F1000
G1 X172.682 Y269.846 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y275.631 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y275.627 Z-2.452 F1000
G1 X22.509 Y275.617 Z-2.522 F1000
G1 X22.499 Y275.6 Z-2.591 F1000
G1 X22.485 Y275.577 Z-2.657 F1000
G1 X22.467 Y275.547 Z-2.719 F1000
G1 X22.446 Y275.512 Z-2.777 F1000
G1 X22.422 Y275.471 Z-2.83 F1000
G1 X22.395 Y275.425 Z-2.877 F1000
G1 X22.365 Y275.375 Z-2.919 F1000
G1 X22.333 Y275.322 Z-2.953 F1000
G1 X22.3 Y275.265 Z-2.98 F1000
G1 X22.265 Y275.206 Z-3 F1000
G1 X22.229 Y275.146 Z-3.012 F1000
G1 X22.192 Y275.085 Z-3.016 F1000
G3 X21.971 Y274.331 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y271.825 F1000
G1 X21.981 Y271.634 F1000
G1 X22.012 Y271.392 F1000
G1 X22.072 Y271.111 F1000
G1 X22.158 Y270.827 F1000
G1 X22.288 Y270.493 F1000
G1 X22.455 Y270.148 F1000
G1 X22.678 Y269.769 F1000
G1 X22.963 Y269.364 F1000
G1 X23.322 Y268.93 F1000
G1 X23.76 Y268.482 F1000
G1 X24.317 Y267.996 F1000
G1 X25.007 Y267.485 F1000
G1 X25.787 Y267 F1000
G1 X26.601 Y266.572 F1000
G1 X27.439 Y266.195 F1000
G1 X28.295 Y265.861 F1000
G1 X29.165 Y265.565 F1000
G1 X30.046 Y265.302 F1000
G1 X30.935 Y265.069 F1000
G1 X31.83 Y264.861 F1000
G1 X32.73 Y264.676 F1000
G1 X33.634 Y264.51 F1000
G1 X34.541 Y264.363 F1000
G1 X35.451 Y264.232 F1000
G1 X36.362 Y264.116 F1000
G1 X37.275 Y264.012 F1000
G1 X38.19 Y263.92 F1000
G1 X39.105 Y263.838 F1000
G1 X40.021 Y263.766 F1000
G1 X40.938 Y263.702 F1000
G1 X41.856 Y263.646 F1000
G1 X42.773 Y263.596 F1000
G1 X43.691 Y263.553 F1000
G1 X44.609 Y263.515 F1000
G1 X45.528 Y263.481 F1000
G1 X46.446 Y263.452 F1000
G1 X47.365 Y263.426 F1000
G1 X48.284 Y263.404 F1000
G1 X49.203 Y263.385 F1000
G1 X50.121 Y263.368 F1000
G1 X51.04 Y263.354 F1000
G1 X51.959 Y263.342 F1000
G1 X52.878 Y263.331 F1000
G1 X53.797 Y263.322 F1000
G1 X54.716 Y263.314 F1000
G1 X56.554 Y263.302 F1000
G1 X58.392 Y263.293 F1000
G1 X60.23 Y263.286 F1000
G1 X62.987 Y263.28 F1000
G1 X69.42 Y263.271 F1000
G1 X71.259 Y263.266 F1000
G1 X72.178 Y263.262 F1000
G1 X73.097 Y263.257 F1000
G1 X74.016 Y263.25 F1000
G1 X74.935 Y263.241 F1000
G1 X75.853 Y263.23 F1000
G1 X76.772 Y263.215 F1000
G1 X77.691 Y263.197 F1000
G1 X78.61 Y263.174 F1000
G1 X79.529 Y263.148 F1000
G1 X80.447 Y263.116 F1000
G1 X81.365 Y263.08 F1000
G1 X82.283 Y263.039 F1000
G1 X83.201 Y262.992 F1000
G1 X84.119 Y262.941 F1000
G1 X85.036 Y262.884 F1000
G1 X85.953 Y262.823 F1000
G1 X86.87 Y262.758 F1000
G1 X87.786 Y262.689 F1000
G1 X88.702 Y262.617 F1000
G1 X89.618 Y262.542 F1000
G1 X90.534 Y262.465 F1000
G1 X91.45 Y262.387 F1000
G1 X95.112 Y262.066 F1000
G1 X96.028 Y261.987 F1000
G1 X96.943 Y261.91 F1000
G1 X97.859 Y261.834 F1000
G1 X98.775 Y261.76 F1000
G1 X99.691 Y261.688 F1000
G1 X100.608 Y261.619 F1000
G1 X101.525 Y261.553 F1000
G1 X102.441 Y261.489 F1000
G1 X103.358 Y261.429 F1000
G1 X104.276 Y261.372 F1000
G1 X105.193 Y261.317 F1000
G1 X106.111 Y261.266 F1000
G1 X107.028 Y261.218 F1000
G1 X107.946 Y261.174 F1000
G1 X108.864 Y261.132 F1000
G1 X109.783 Y261.093 F1000
G1 X110.701 Y261.057 F1000
G1 X111.619 Y261.024 F1000
G1 X112.538 Y260.994 F1000
G1 X113.456 Y260.966 F1000
G1 X114.375 Y260.941 F1000
G1 X115.294 Y260.918 F1000
G1 X116.213 Y260.897 F1000
G1 X117.132 Y260.878 F1000
G1 X118.05 Y260.861 F1000
G1 X118.969 Y260.845 F1000
G1 X119.888 Y260.831 F1000
G1 X120.807 Y260.819 F1000
G1 X121.726 Y260.808 F1000
G1 X122.645 Y260.798 F1000
G1 X124.483 Y260.782 F1000
G1 X126.321 Y260.769 F1000
G1 X128.159 Y260.76 F1000
G1 X130.916 Y260.749 F1000
G1 X133.673 Y260.742 F1000
G1 X137.349 Y260.737 F1000
G1 X142.863 Y260.733 F1000
G1 X147.458 F1000
G1 X149.296 Y260.735 F1000
G1 X151.134 Y260.739 F1000
G1 X152.053 Y260.743 F1000
G1 X152.973 Y260.747 F1000
G1 X153.891 Y260.754 F1000
G1 X154.81 Y260.762 F1000
G1 X155.729 Y260.772 F1000
G1 X156.648 Y260.785 F1000
G1 X157.567 Y260.802 F1000
G1 X158.486 Y260.822 F1000
G1 X159.405 Y260.847 F1000
G1 X160.323 Y260.877 F1000
G1 X161.242 Y260.913 F1000
G1 X162.16 Y260.957 F1000
G1 X163.077 Y261.008 F1000
G1 X163.994 Y261.069 F1000
G1 X164.91 Y261.141 F1000
G1 X165.826 Y261.224 F1000
G1 X166.739 Y261.323 F1000
G1 X167.651 Y261.437 F1000
G1 X168.56 Y261.572 F1000
G1 X169.466 Y261.73 F1000
G1 X170.365 Y261.916 F1000
G1 X171.257 Y262.14 F1000
G1 X172.058 Y262.389 F1000
G1 X172.605 Y262.609 F1000
G1 X172.916 Y262.765 F1000
G1 X173.191 Y262.942 F1000
G1 X173.421 Y263.176 F1000
G1 X173.593 Y263.455 F1000
G1 X173.7 Y263.765 F1000
G1 X173.736 Y264.09 F1000
G1 Y266.583 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y267.168 I-0.635 J-0.022 F1000
G1 X173.221 Y267.189 Z-3.012 F1000
G1 X173.153 Y267.21 Z-3 F1000
G1 X173.088 Y267.23 Z-2.98 F1000
G1 X173.025 Y267.249 Z-2.953 F1000
G1 X172.966 Y267.267 Z-2.919 F1000
G1 X172.91 Y267.285 Z-2.877 F1000
G1 X172.859 Y267.3 Z-2.83 F1000
G1 X172.814 Y267.314 Z-2.777 F1000
G1 X172.775 Y267.326 Z-2.719 F1000
G1 X172.742 Y267.336 Z-2.657 F1000
G1 X172.716 Y267.345 Z-2.591 F1000
G1 X172.697 Y267.35 Z-2.522 F1000
G1 X172.685 Y267.354 Z-2.452 F1000
G1 X172.682 Y267.355 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y273.125 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y273.121 Z-2.452 F1000
G1 X22.509 Y273.111 Z-2.522 F1000
G1 X22.499 Y273.094 Z-2.591 F1000
G1 X22.485 Y273.071 Z-2.657 F1000
G1 X22.467 Y273.041 Z-2.719 F1000
G1 X22.446 Y273.006 Z-2.777 F1000
G1 X22.422 Y272.965 Z-2.83 F1000
G1 X22.395 Y272.919 Z-2.877 F1000
G1 X22.365 Y272.869 Z-2.919 F1000
G1 X22.333 Y272.816 Z-2.953 F1000
G1 X22.3 Y272.759 Z-2.98 F1000
G1 X22.265 Y272.7 Z-3 F1000
G1 X22.229 Y272.64 Z-3.012 F1000
G1 X22.192 Y272.579 Z-3.016 F1000
G3 X21.971 Y271.825 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y269.528 F1000
G1 X21.989 Y269.177 F1000
G1 X22.02 Y268.935 F1000
G1 X22.08 Y268.654 F1000
G1 X22.166 Y268.37 F1000
G1 X22.296 Y268.036 F1000
G1 X22.463 Y267.69 F1000
G1 X22.687 Y267.311 F1000
G1 X22.972 Y266.904 F1000
G1 X23.333 Y266.47 F1000
G1 X23.772 Y266.02 F1000
G1 X24.332 Y265.531 F1000
G1 X25.026 Y265.018 F1000
G1 X25.806 Y264.532 F1000
G1 X26.619 Y264.104 F1000
G1 X27.457 Y263.725 F1000
G1 X28.313 Y263.39 F1000
G1 X29.182 Y263.093 F1000
G1 X30.062 Y262.828 F1000
G1 X30.95 Y262.592 F1000
G1 X31.845 Y262.382 F1000
G1 X32.745 Y262.194 F1000
G1 X33.648 Y262.026 F1000
G1 X34.555 Y261.876 F1000
G1 X35.464 Y261.742 F1000
G1 X36.375 Y261.622 F1000
G1 X37.288 Y261.516 F1000
G1 X38.202 Y261.421 F1000
G1 X39.117 Y261.336 F1000
G1 X40.033 Y261.261 F1000
G1 X40.95 Y261.195 F1000
G1 X41.867 Y261.136 F1000
G1 X42.785 Y261.084 F1000
G1 X43.703 Y261.038 F1000
G1 X44.621 Y260.997 F1000
G1 X45.539 Y260.962 F1000
G1 X46.457 Y260.93 F1000
G1 X47.376 Y260.903 F1000
G1 X48.295 Y260.879 F1000
G1 X49.214 Y260.858 F1000
G1 X50.132 Y260.84 F1000
G1 X51.051 Y260.825 F1000
G1 X51.97 Y260.811 F1000
G1 X52.889 Y260.799 F1000
G1 X53.808 Y260.789 F1000
G1 X54.727 Y260.78 F1000
G1 X55.646 Y260.773 F1000
G1 X57.484 Y260.761 F1000
G1 X59.322 Y260.752 F1000
G1 X62.079 Y260.744 F1000
G1 X65.755 Y260.737 F1000
G1 X69.431 Y260.73 F1000
G1 X71.269 Y260.723 F1000
G1 X72.188 Y260.718 F1000
G1 X73.107 Y260.712 F1000
G1 X74.026 Y260.703 F1000
G1 X74.945 Y260.693 F1000
G1 X75.864 Y260.679 F1000
G1 X76.783 Y260.662 F1000
G1 X77.702 Y260.642 F1000
G1 X78.621 Y260.618 F1000
G1 X79.539 Y260.589 F1000
G1 X80.458 Y260.556 F1000
G1 X81.376 Y260.518 F1000
G1 X82.294 Y260.475 F1000
G1 X83.212 Y260.428 F1000
G1 X84.129 Y260.376 F1000
G1 X85.046 Y260.319 F1000
G1 X85.963 Y260.258 F1000
G1 X86.88 Y260.193 F1000
G1 X87.797 Y260.125 F1000
G1 X88.713 Y260.054 F1000
G1 X89.629 Y259.981 F1000
G1 X90.545 Y259.905 F1000
G1 X92.376 Y259.75 F1000
G1 X95.124 Y259.516 F1000
G1 X96.039 Y259.439 F1000
G1 X96.955 Y259.364 F1000
G1 X97.871 Y259.29 F1000
G1 X98.787 Y259.218 F1000
G1 X99.704 Y259.148 F1000
G1 X100.62 Y259.081 F1000
G1 X101.537 Y259.016 F1000
G1 X102.454 Y258.954 F1000
G1 X103.371 Y258.894 F1000
G1 X104.288 Y258.838 F1000
G1 X105.206 Y258.785 F1000
G1 X106.124 Y258.734 F1000
G1 X107.041 Y258.687 F1000
G1 X107.959 Y258.643 F1000
G1 X108.877 Y258.601 F1000
G1 X109.796 Y258.563 F1000
G1 X110.714 Y258.527 F1000
G1 X111.632 Y258.494 F1000
G1 X112.551 Y258.464 F1000
G1 X113.469 Y258.436 F1000
G1 X114.388 Y258.41 F1000
G1 X115.307 Y258.386 F1000
G1 X116.226 Y258.365 F1000
G1 X117.144 Y258.346 F1000
G1 X118.063 Y258.328 F1000
G1 X118.982 Y258.312 F1000
G1 X119.901 Y258.298 F1000
G1 X120.82 Y258.285 F1000
G1 X121.739 Y258.274 F1000
G1 X122.658 Y258.264 F1000
G1 X123.577 Y258.255 F1000
G1 X125.415 Y258.239 F1000
G1 X127.253 Y258.227 F1000
G1 X129.091 Y258.218 F1000
G1 X131.848 Y258.208 F1000
G1 X134.605 Y258.202 F1000
G1 X138.281 Y258.197 F1000
G1 X142.876 Y258.194 F1000
G1 X146.552 F1000
G1 X149.309 Y258.197 F1000
G1 X151.147 Y258.202 F1000
G1 X152.066 Y258.207 F1000
G1 X152.985 Y258.212 F1000
G1 X153.904 Y258.219 F1000
G1 X154.823 Y258.229 F1000
G1 X155.742 Y258.241 F1000
G1 X156.661 Y258.256 F1000
G1 X157.58 Y258.274 F1000
G1 X158.499 Y258.296 F1000
G1 X159.417 Y258.323 F1000
G1 X160.336 Y258.356 F1000
G1 X161.254 Y258.395 F1000
G1 X162.172 Y258.44 F1000
G1 X163.089 Y258.494 F1000
G1 X164.006 Y258.558 F1000
G1 X164.922 Y258.632 F1000
G1 X165.837 Y258.718 F1000
G1 X166.751 Y258.819 F1000
G1 X167.662 Y258.936 F1000
G1 X168.571 Y259.073 F1000
G1 X169.476 Y259.233 F1000
G1 X170.375 Y259.421 F1000
G1 X171.267 Y259.646 F1000
G1 X172.067 Y259.897 F1000
G1 X172.613 Y260.118 F1000
G1 X172.918 Y260.271 F1000
G1 X173.193 Y260.449 F1000
G1 X173.422 Y260.683 F1000
G1 X173.593 Y260.961 F1000
G1 X173.7 Y261.27 F1000
G1 X173.736 Y261.595 F1000
G1 Y264.09 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y264.675 I-0.635 J-0.022 F1000
G1 X173.221 Y264.696 Z-3.012 F1000
G1 X173.153 Y264.717 Z-3 F1000
G1 X173.088 Y264.737 Z-2.98 F1000
G1 X173.025 Y264.756 Z-2.953 F1000
G1 X172.966 Y264.774 Z-2.919 F1000
G1 X172.91 Y264.792 Z-2.877 F1000
G1 X172.859 Y264.807 Z-2.83 F1000
G1 X172.814 Y264.821 Z-2.777 F1000
G1 X172.775 Y264.833 Z-2.719 F1000
G1 X172.742 Y264.843 Z-2.657 F1000
G1 X172.716 Y264.852 Z-2.591 F1000
G1 X172.697 Y264.857 Z-2.522 F1000
G1 X172.685 Y264.861 Z-2.452 F1000
G1 X172.682 Y264.862 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y270.827 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y270.824 Z-2.452 F1000
G1 X22.509 Y270.814 Z-2.522 F1000
G1 X22.499 Y270.797 Z-2.591 F1000
G1 X22.485 Y270.773 Z-2.657 F1000
G1 X22.467 Y270.744 Z-2.719 F1000
G1 X22.446 Y270.708 Z-2.777 F1000
G1 X22.422 Y270.668 Z-2.83 F1000
G1 X22.395 Y270.622 Z-2.877 F1000
G1 X22.365 Y270.572 Z-2.919 F1000
G1 X22.333 Y270.518 Z-2.953 F1000
G1 X22.3 Y270.462 Z-2.98 F1000
G1 X22.265 Y270.403 Z-3 F1000
G1 X22.229 Y270.343 Z-3.012 F1000
G1 X22.192 Y270.282 Z-3.016 F1000
G3 X21.971 Y269.528 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y267.022 F1000
G1 X21.986 Y266.728 F1000
G1 X22.017 Y266.486 F1000
G1 X22.078 Y266.203 F1000
G1 X22.163 Y265.918 F1000
G1 X22.294 Y265.584 F1000
G1 X22.463 Y265.234 F1000
G1 X22.686 Y264.855 F1000
G1 X22.974 Y264.446 F1000
G1 X23.335 Y264.01 F1000
G1 X23.778 Y263.557 F1000
G1 X24.341 Y263.065 F1000
G1 X25.04 Y262.548 F1000
G1 X25.82 Y262.063 F1000
G1 X26.633 Y261.634 F1000
G1 X27.47 Y261.254 F1000
G1 X28.326 Y260.918 F1000
G1 X29.194 Y260.619 F1000
G1 X30.074 Y260.352 F1000
G1 X30.962 Y260.114 F1000
G1 X31.856 Y259.901 F1000
G1 X32.755 Y259.711 F1000
G1 X33.658 Y259.54 F1000
G1 X34.564 Y259.388 F1000
G1 X35.473 Y259.251 F1000
G1 X36.384 Y259.129 F1000
G1 X37.296 Y259.019 F1000
G1 X38.21 Y258.922 F1000
G1 X39.125 Y258.834 F1000
G1 X40.041 Y258.757 F1000
G1 X40.957 Y258.687 F1000
G1 X41.874 Y258.626 F1000
G1 X42.791 Y258.571 F1000
G1 X43.709 Y258.523 F1000
G1 X44.627 Y258.48 F1000
G1 X45.545 Y258.443 F1000
G1 X46.464 Y258.41 F1000
G1 X47.382 Y258.38 F1000
G1 X48.301 Y258.355 F1000
G1 X49.22 Y258.332 F1000
G1 X50.139 Y258.313 F1000
G1 X51.057 Y258.296 F1000
G1 X51.976 Y258.281 F1000
G1 X52.895 Y258.268 F1000
G1 X53.814 Y258.257 F1000
G1 X54.733 Y258.247 F1000
G1 X55.652 Y258.239 F1000
G1 X57.49 Y258.226 F1000
G1 X59.328 Y258.216 F1000
G1 X61.166 Y258.209 F1000
G1 X63.923 Y258.201 F1000
G1 X68.518 Y258.191 F1000
G1 X69.437 Y258.188 F1000
G1 X70.356 Y258.184 F1000
G1 X71.275 Y258.18 F1000
G1 X72.194 Y258.174 F1000
G1 X73.113 Y258.166 F1000
G1 X74.032 Y258.156 F1000
G1 X74.951 Y258.143 F1000
G1 X75.87 Y258.128 F1000
G1 X76.789 Y258.11 F1000
G1 X77.708 Y258.087 F1000
G1 X78.626 Y258.061 F1000
G1 X79.545 Y258.031 F1000
G1 X80.463 Y257.996 F1000
G1 X81.382 Y257.957 F1000
G1 X82.299 Y257.913 F1000
G1 X83.217 Y257.865 F1000
G1 X84.135 Y257.812 F1000
G1 X85.052 Y257.755 F1000
G1 X85.969 Y257.694 F1000
G1 X86.886 Y257.63 F1000
G1 X87.802 Y257.563 F1000
G1 X88.719 Y257.493 F1000
G1 X89.635 Y257.421 F1000
G1 X90.551 Y257.347 F1000
G1 X92.383 Y257.196 F1000
G1 X95.13 Y256.967 F1000
G1 X96.046 Y256.892 F1000
G1 X96.962 Y256.819 F1000
G1 X97.879 Y256.747 F1000
G1 X98.795 Y256.676 F1000
G1 X99.711 Y256.608 F1000
G1 X100.628 Y256.542 F1000
G1 X101.545 Y256.479 F1000
G1 X102.462 Y256.418 F1000
G1 X103.379 Y256.36 F1000
G1 X104.296 Y256.304 F1000
G1 X105.214 Y256.252 F1000
G1 X106.132 Y256.202 F1000
G1 X107.049 Y256.156 F1000
G1 X107.967 Y256.112 F1000
G1 X108.885 Y256.07 F1000
G1 X109.804 Y256.032 F1000
G1 X110.722 Y255.996 F1000
G1 X111.64 Y255.963 F1000
G1 X112.559 Y255.933 F1000
G1 X113.478 Y255.905 F1000
G1 X114.396 Y255.879 F1000
G1 X115.315 Y255.855 F1000
G1 X116.234 Y255.833 F1000
G1 X117.152 Y255.813 F1000
G1 X118.071 Y255.796 F1000
G1 X118.99 Y255.779 F1000
G1 X119.909 Y255.765 F1000
G1 X120.828 Y255.751 F1000
G1 X121.747 Y255.74 F1000
G1 X122.666 Y255.729 F1000
G1 X123.585 Y255.719 F1000
G1 X125.423 Y255.703 F1000
G1 X127.261 Y255.691 F1000
G1 X129.099 Y255.681 F1000
G1 X131.856 Y255.67 F1000
G1 X134.613 Y255.663 F1000
G1 X138.289 Y255.658 F1000
G1 X142.884 Y255.654 F1000
G1 X146.56 Y255.655 F1000
G1 X148.398 Y255.657 F1000
G1 X150.236 Y255.662 F1000
G1 X151.155 Y255.666 F1000
G1 X152.074 Y255.671 F1000
G1 X152.993 Y255.677 F1000
G1 X153.912 Y255.686 F1000
G1 X154.831 Y255.697 F1000
G1 X155.75 Y255.71 F1000
G1 X156.669 Y255.726 F1000
G1 X157.588 Y255.747 F1000
G1 X158.507 Y255.771 F1000
G1 X159.425 Y255.8 F1000
G1 X160.343 Y255.835 F1000
G1 X161.262 Y255.875 F1000
G1 X162.179 Y255.924 F1000
G1 X163.097 Y255.98 F1000
G1 X164.013 Y256.046 F1000
G1 X164.929 Y256.122 F1000
G1 X165.844 Y256.21 F1000
G1 X166.757 Y256.313 F1000
G1 X167.668 Y256.432 F1000
G1 X168.577 Y256.571 F1000
G1 X169.482 Y256.733 F1000
G1 X170.381 Y256.923 F1000
G1 X171.272 Y257.149 F1000
G1 X172.072 Y257.401 F1000
G1 X172.618 Y257.623 F1000
G1 X172.92 Y257.775 F1000
G1 X173.194 Y257.953 F1000
G1 X173.422 Y258.187 F1000
G1 X173.594 Y258.465 F1000
G1 X173.7 Y258.774 F1000
G1 X173.736 Y259.098 F1000
G1 Y261.595 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y262.18 I-0.635 J-0.022 F1000
G1 X173.221 Y262.201 Z-3.012 F1000
G1 X173.153 Y262.222 Z-3 F1000
G1 X173.088 Y262.242 Z-2.98 F1000
G1 X173.025 Y262.261 Z-2.953 F1000
G1 X172.966 Y262.279 Z-2.919 F1000
G1 X172.91 Y262.297 Z-2.877 F1000
G1 X172.859 Y262.312 Z-2.83 F1000
G1 X172.814 Y262.326 Z-2.777 F1000
G1 X172.775 Y262.338 Z-2.719 F1000
G1 X172.742 Y262.348 Z-2.657 F1000
G1 X172.716 Y262.357 Z-2.591 F1000
G1 X172.697 Y262.362 Z-2.522 F1000
G1 X172.685 Y262.366 Z-2.452 F1000
G1 X172.682 Y262.367 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y268.321 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y268.318 Z-2.452 F1000
G1 X22.509 Y268.308 Z-2.522 F1000
G1 X22.499 Y268.291 Z-2.591 F1000
G1 X22.485 Y268.267 Z-2.657 F1000
G1 X22.467 Y268.238 Z-2.719 F1000
G1 X22.446 Y268.202 Z-2.777 F1000
G1 X22.422 Y268.162 Z-2.83 F1000
G1 X22.395 Y268.116 Z-2.877 F1000
G1 X22.365 Y268.066 Z-2.919 F1000
G1 X22.333 Y268.012 Z-2.953 F1000
G1 X22.3 Y267.956 Z-2.98 F1000
G1 X22.265 Y267.897 Z-3 F1000
G1 X22.229 Y267.837 Z-3.012 F1000
G1 X22.192 Y267.776 Z-3.016 F1000
G3 X21.971 Y267.022 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y264.516 F1000
G1 X21.983 Y264.273 F1000
G1 X22.015 Y264.03 F1000
G1 X22.076 Y263.747 F1000
G1 X22.161 Y263.46 F1000
G1 X22.291 Y263.126 F1000
G1 X22.462 Y262.774 F1000
G1 X22.686 Y262.395 F1000
G1 X22.975 Y261.983 F1000
G1 X23.337 Y261.547 F1000
G1 X23.782 Y261.09 F1000
G1 X24.349 Y260.596 F1000
G1 X25.052 Y260.076 F1000
G1 X25.832 Y259.59 F1000
G1 X26.645 Y259.161 F1000
G1 X27.481 Y258.781 F1000
G1 X28.336 Y258.443 F1000
G1 X29.204 Y258.142 F1000
G1 X30.083 Y257.874 F1000
G1 X30.971 Y257.634 F1000
G1 X31.864 Y257.419 F1000
G1 X32.763 Y257.226 F1000
G1 X33.665 Y257.053 F1000
G1 X34.571 Y256.898 F1000
G1 X35.479 Y256.759 F1000
G1 X36.39 Y256.634 F1000
G1 X37.302 Y256.522 F1000
G1 X38.216 Y256.422 F1000
G1 X39.13 Y256.332 F1000
G1 X40.046 Y256.251 F1000
G1 X40.962 Y256.18 F1000
G1 X41.879 Y256.116 F1000
G1 X42.796 Y256.059 F1000
G1 X43.714 Y256.009 F1000
G1 X44.632 Y255.964 F1000
G1 X45.55 Y255.924 F1000
G1 X46.468 Y255.889 F1000
G1 X47.387 Y255.858 F1000
G1 X48.305 Y255.831 F1000
G1 X49.224 Y255.807 F1000
G1 X50.143 Y255.786 F1000
G1 X51.062 Y255.767 F1000
G1 X51.98 Y255.751 F1000
G1 X52.899 Y255.737 F1000
G1 X53.818 Y255.725 F1000
G1 X54.737 Y255.715 F1000
G1 X55.656 Y255.705 F1000
G1 X56.575 Y255.698 F1000
G1 X58.413 Y255.685 F1000
G1 X60.251 Y255.675 F1000
G1 X63.008 Y255.665 F1000
G1 X67.603 Y255.653 F1000
G1 X69.441 Y255.646 F1000
G1 X70.36 Y255.641 F1000
G1 X71.279 Y255.636 F1000
G1 X72.198 Y255.628 F1000
G1 X73.117 Y255.619 F1000
G1 X74.036 Y255.608 F1000
G1 X74.955 Y255.594 F1000
G1 X75.874 Y255.577 F1000
G1 X76.793 Y255.556 F1000
G1 X77.712 Y255.532 F1000
G1 X78.63 Y255.505 F1000
G1 X79.549 Y255.473 F1000
G1 X80.467 Y255.437 F1000
G1 X81.385 Y255.396 F1000
G1 X82.303 Y255.352 F1000
G1 X83.221 Y255.303 F1000
G1 X84.138 Y255.25 F1000
G1 X85.056 Y255.193 F1000
G1 X85.973 Y255.132 F1000
G1 X86.889 Y255.069 F1000
G1 X87.806 Y255.002 F1000
G1 X88.722 Y254.933 F1000
G1 X89.639 Y254.862 F1000
G1 X90.555 Y254.79 F1000
G1 X92.387 Y254.642 F1000
G1 X95.135 Y254.419 F1000
G1 X96.051 Y254.346 F1000
G1 X96.967 Y254.274 F1000
G1 X97.884 Y254.204 F1000
G1 X98.8 Y254.135 F1000
G1 X99.717 Y254.068 F1000
G1 X100.633 Y254.004 F1000
G1 X101.55 Y253.942 F1000
G1 X102.467 Y253.882 F1000
G1 X103.385 Y253.825 F1000
G1 X104.302 Y253.771 F1000
G1 X105.22 Y253.719 F1000
G1 X106.137 Y253.67 F1000
G1 X107.055 Y253.624 F1000
G1 X107.973 Y253.58 F1000
G1 X108.891 Y253.539 F1000
G1 X109.81 Y253.501 F1000
G1 X110.728 Y253.465 F1000
G1 X111.646 Y253.432 F1000
G1 X112.565 Y253.402 F1000
G1 X113.483 Y253.373 F1000
G1 X114.402 Y253.347 F1000
G1 X115.321 Y253.323 F1000
G1 X116.239 Y253.301 F1000
G1 X117.158 Y253.281 F1000
G1 X118.077 Y253.263 F1000
G1 X118.996 Y253.246 F1000
G1 X119.915 Y253.231 F1000
G1 X120.834 Y253.218 F1000
G1 X121.753 Y253.205 F1000
G1 X122.672 Y253.194 F1000
G1 X123.591 Y253.184 F1000
G1 X125.429 Y253.168 F1000
G1 X127.267 Y253.154 F1000
G1 X129.105 Y253.144 F1000
G1 X131.862 Y253.132 F1000
G1 X134.619 Y253.125 F1000
G1 X138.295 Y253.118 F1000
G1 X141.971 Y253.115 F1000
G1 X145.647 F1000
G1 X147.485 Y253.117 F1000
G1 X149.323 Y253.122 F1000
G1 X150.242 Y253.125 F1000
G1 X151.161 Y253.13 F1000
G1 X152.08 Y253.136 F1000
G1 X152.999 Y253.143 F1000
G1 X153.918 Y253.153 F1000
G1 X154.837 Y253.165 F1000
G1 X155.756 Y253.18 F1000
G1 X156.675 Y253.198 F1000
G1 X157.593 Y253.22 F1000
G1 X158.512 Y253.246 F1000
G1 X159.431 Y253.277 F1000
G1 X160.349 Y253.313 F1000
G1 X161.267 Y253.356 F1000
G1 X162.185 Y253.407 F1000
G1 X163.102 Y253.465 F1000
G1 X164.018 Y253.533 F1000
G1 X164.934 Y253.611 F1000
G1 X165.848 Y253.702 F1000
G1 X166.761 Y253.807 F1000
G1 X167.672 Y253.928 F1000
G1 X168.581 Y254.068 F1000
G1 X169.485 Y254.231 F1000
G1 X170.384 Y254.423 F1000
G1 X171.274 Y254.65 F1000
G1 X172.075 Y254.903 F1000
G1 X172.622 Y255.126 F1000
G1 X172.922 Y255.277 F1000
G1 X173.195 Y255.455 F1000
G1 X173.423 Y255.689 F1000
G1 X173.594 Y255.967 F1000
G1 X173.7 Y256.276 F1000
G1 X173.736 Y256.6 F1000
G1 Y259.098 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y259.683 I-0.635 J-0.022 F1000
G1 X173.221 Y259.704 Z-3.012 F1000
G1 X173.153 Y259.725 Z-3 F1000
G1 X173.088 Y259.745 Z-2.98 F1000
G1 X173.025 Y259.764 Z-2.953 F1000
G1 X172.966 Y259.783 Z-2.919 F1000
G1 X172.91 Y259.8 Z-2.877 F1000
G1 X172.859 Y259.815 Z-2.83 F1000
G1 X172.814 Y259.829 Z-2.777 F1000
G1 X172.775 Y259.842 Z-2.719 F1000
G1 X172.742 Y259.852 Z-2.657 F1000
G1 X172.716 Y259.86 Z-2.591 F1000
G1 X172.697 Y259.865 Z-2.522 F1000
G1 X172.685 Y259.869 Z-2.452 F1000
G1 X172.682 Y259.87 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y265.815 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y265.812 Z-2.452 F1000
G1 X22.509 Y265.802 Z-2.522 F1000
G1 X22.499 Y265.785 Z-2.591 F1000
G1 X22.485 Y265.761 Z-2.657 F1000
G1 X22.467 Y265.732 Z-2.719 F1000
G1 X22.446 Y265.696 Z-2.777 F1000
G1 X22.422 Y265.656 Z-2.83 F1000
G1 X22.395 Y265.61 Z-2.877 F1000
G1 X22.365 Y265.56 Z-2.919 F1000
G1 X22.333 Y265.506 Z-2.953 F1000
G1 X22.3 Y265.45 Z-2.98 F1000
G1 X22.265 Y265.391 Z-3 F1000
G1 X22.229 Y265.331 Z-3.012 F1000
G1 X22.192 Y265.27 Z-3.016 F1000
G3 X21.971 Y264.516 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y262.01 F1000
G1 X21.981 Y261.812 F1000
G1 X22.013 Y261.57 F1000
G1 X22.074 Y261.285 F1000
G1 X22.16 Y260.998 F1000
G1 X22.29 Y260.664 F1000
G1 X22.462 Y260.31 F1000
G1 X22.685 Y259.93 F1000
G1 X22.976 Y259.517 F1000
G1 X23.338 Y259.08 F1000
G1 X23.786 Y258.621 F1000
G1 X24.355 Y258.124 F1000
G1 X25.062 Y257.601 F1000
G1 X25.842 Y257.116 F1000
G1 X26.655 Y256.686 F1000
G1 X27.491 Y256.305 F1000
G1 X28.345 Y255.966 F1000
G1 X29.213 Y255.664 F1000
G1 X30.092 Y255.394 F1000
G1 X30.978 Y255.152 F1000
G1 X31.871 Y254.935 F1000
G1 X32.769 Y254.74 F1000
G1 X33.671 Y254.565 F1000
G1 X34.577 Y254.407 F1000
G1 X35.485 Y254.265 F1000
G1 X36.395 Y254.138 F1000
G1 X37.307 Y254.024 F1000
G1 X38.22 Y253.921 F1000
G1 X39.135 Y253.829 F1000
G1 X40.05 Y253.746 F1000
G1 X40.966 Y253.672 F1000
G1 X41.883 Y253.606 F1000
G1 X42.8 Y253.547 F1000
G1 X43.717 Y253.494 F1000
G1 X44.635 Y253.447 F1000
G1 X45.553 Y253.406 F1000
G1 X46.471 Y253.369 F1000
G1 X47.39 Y253.336 F1000
G1 X48.308 Y253.307 F1000
G1 X49.227 Y253.282 F1000
G1 X50.146 Y253.259 F1000
G1 X51.065 Y253.239 F1000
G1 X51.983 Y253.222 F1000
G1 X52.902 Y253.207 F1000
G1 X53.821 Y253.194 F1000
G1 X54.74 Y253.182 F1000
G1 X55.659 Y253.172 F1000
G1 X56.578 Y253.164 F1000
G1 X58.416 Y253.149 F1000
G1 X60.254 Y253.139 F1000
G1 X63.011 Y253.127 F1000
G1 X67.606 Y253.112 F1000
G1 X69.444 Y253.104 F1000
G1 X70.363 Y253.098 F1000
G1 X71.282 Y253.091 F1000
G1 X72.201 Y253.082 F1000
G1 X73.12 Y253.072 F1000
G1 X74.039 Y253.059 F1000
G1 X74.958 Y253.043 F1000
G1 X75.877 Y253.025 F1000
G1 X76.796 Y253.003 F1000
G1 X77.714 Y252.977 F1000
G1 X78.633 Y252.948 F1000
G1 X79.551 Y252.915 F1000
G1 X80.47 Y252.878 F1000
G1 X81.388 Y252.836 F1000
G1 X82.306 Y252.791 F1000
G1 X83.223 Y252.742 F1000
G1 X84.141 Y252.688 F1000
G1 X85.058 Y252.632 F1000
G1 X85.975 Y252.571 F1000
G1 X86.892 Y252.508 F1000
G1 X87.809 Y252.443 F1000
G1 X88.725 Y252.375 F1000
G1 X89.641 Y252.305 F1000
G1 X91.474 Y252.162 F1000
G1 X95.138 Y251.872 F1000
G1 X96.055 Y251.8 F1000
G1 X96.971 Y251.73 F1000
G1 X97.888 Y251.661 F1000
G1 X98.804 Y251.594 F1000
G1 X99.721 Y251.529 F1000
G1 X100.638 Y251.466 F1000
G1 X101.555 Y251.405 F1000
G1 X102.472 Y251.346 F1000
G1 X103.389 Y251.29 F1000
G1 X104.307 Y251.236 F1000
G1 X105.224 Y251.185 F1000
G1 X106.142 Y251.137 F1000
G1 X107.06 Y251.091 F1000
G1 X107.978 Y251.048 F1000
G1 X108.896 Y251.008 F1000
G1 X109.814 Y250.97 F1000
G1 X110.732 Y250.934 F1000
G1 X111.651 Y250.901 F1000
G1 X112.569 Y250.87 F1000
G1 X113.488 Y250.842 F1000
G1 X114.407 Y250.815 F1000
G1 X115.325 Y250.791 F1000
G1 X116.244 Y250.769 F1000
G1 X117.163 Y250.749 F1000
G1 X118.082 Y250.73 F1000
G1 X119.001 Y250.713 F1000
G1 X119.919 Y250.698 F1000
G1 X120.838 Y250.684 F1000
G1 X121.757 Y250.671 F1000
G1 X122.676 Y250.66 F1000
G1 X123.595 Y250.649 F1000
G1 X125.433 Y250.632 F1000
G1 X127.271 Y250.618 F1000
G1 X129.109 Y250.607 F1000
G1 X130.947 Y250.598 F1000
G1 X133.704 Y250.589 F1000
G1 X136.461 Y250.582 F1000
G1 X140.137 Y250.577 F1000
G1 X143.813 Y250.576 F1000
G1 X146.571 Y250.578 F1000
G1 X148.409 Y250.581 F1000
G1 X149.328 Y250.585 F1000
G1 X150.247 Y250.589 F1000
G1 X151.166 Y250.594 F1000
G1 X152.085 Y250.601 F1000
G1 X153.004 Y250.61 F1000
G1 X153.923 Y250.621 F1000
G1 X154.841 Y250.634 F1000
G1 X155.76 Y250.65 F1000
G1 X156.679 Y250.67 F1000
G1 X157.598 Y250.693 F1000
G1 X158.516 Y250.721 F1000
G1 X159.435 Y250.754 F1000
G1 X160.353 Y250.792 F1000
G1 X161.271 Y250.837 F1000
G1 X162.189 Y250.889 F1000
G1 X163.106 Y250.95 F1000
G1 X164.022 Y251.02 F1000
G1 X164.937 Y251.1 F1000
G1 X165.852 Y251.192 F1000
G1 X166.765 Y251.299 F1000
G1 X167.675 Y251.422 F1000
G1 X168.583 Y251.564 F1000
G1 X169.488 Y251.729 F1000
G1 X170.386 Y251.921 F1000
G1 X171.276 Y252.149 F1000
G1 X172.078 Y252.404 F1000
G1 X172.625 Y252.627 F1000
G1 X172.923 Y252.778 F1000
G1 X173.196 Y252.956 F1000
G1 X173.423 Y253.19 F1000
G1 X173.594 Y253.467 F1000
G1 X173.7 Y253.776 F1000
G1 X173.736 Y254.1 F1000
G1 Y256.6 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y257.185 I-0.635 J-0.022 F1000
G1 X173.221 Y257.206 Z-3.012 F1000
G1 X173.153 Y257.226 Z-3 F1000
G1 X173.088 Y257.246 Z-2.98 F1000
G1 X173.025 Y257.266 Z-2.953 F1000
G1 X172.966 Y257.284 Z-2.919 F1000
G1 X172.91 Y257.301 Z-2.877 F1000
G1 X172.859 Y257.317 Z-2.83 F1000
G1 X172.814 Y257.331 Z-2.777 F1000
G1 X172.775 Y257.343 Z-2.719 F1000
G1 X172.742 Y257.353 Z-2.657 F1000
G1 X172.716 Y257.361 Z-2.591 F1000
G1 X172.697 Y257.367 Z-2.522 F1000
G1 X172.685 Y257.37 Z-2.452 F1000
G1 X172.682 Y257.372 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y263.309 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y263.306 Z-2.452 F1000
G1 X22.509 Y263.296 Z-2.522 F1000
G1 X22.499 Y263.279 Z-2.591 F1000
G1 X22.485 Y263.255 Z-2.657 F1000
G1 X22.467 Y263.226 Z-2.719 F1000
G1 X22.446 Y263.19 Z-2.777 F1000
G1 X22.422 Y263.15 Z-2.83 F1000
G1 X22.395 Y263.104 Z-2.877 F1000
G1 X22.365 Y263.054 Z-2.919 F1000
G1 X22.333 Y263 Z-2.953 F1000
G1 X22.3 Y262.944 Z-2.98 F1000
G1 X22.265 Y262.885 Z-3 F1000
G1 X22.229 Y262.825 Z-3.012 F1000
G1 X22.192 Y262.764 Z-3.016 F1000
G3 X21.971 Y262.01 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y259.504 F1000
G1 X21.979 Y259.347 F1000
G1 X22.011 Y259.105 F1000
G1 X22.072 Y258.82 F1000
G1 X22.158 Y258.532 F1000
G1 X22.288 Y258.198 F1000
G1 X22.461 Y257.842 F1000
G1 X22.684 Y257.462 F1000
G1 X22.976 Y257.047 F1000
G1 X23.339 Y256.609 F1000
G1 X23.789 Y256.148 F1000
G1 X24.361 Y255.649 F1000
G1 X25.071 Y255.124 F1000
G1 X25.852 Y254.638 F1000
G1 X26.664 Y254.208 F1000
G1 X27.5 Y253.826 F1000
G1 X28.353 Y253.486 F1000
G1 X29.221 Y253.183 F1000
G1 X30.099 Y252.911 F1000
G1 X30.985 Y252.668 F1000
G1 X31.878 Y252.449 F1000
G1 X32.775 Y252.252 F1000
G1 X33.677 Y252.075 F1000
G1 X34.582 Y251.915 F1000
G1 X35.49 Y251.771 F1000
G1 X36.4 Y251.641 F1000
G1 X37.311 Y251.525 F1000
G1 X38.224 Y251.42 F1000
G1 X39.138 Y251.325 F1000
G1 X40.053 Y251.24 F1000
G1 X40.969 Y251.164 F1000
G1 X41.886 Y251.096 F1000
G1 X42.803 Y251.034 F1000
G1 X43.72 Y250.98 F1000
G1 X44.638 Y250.931 F1000
G1 X45.556 Y250.887 F1000
G1 X46.474 Y250.849 F1000
G1 X47.392 Y250.814 F1000
G1 X48.311 Y250.784 F1000
G1 X49.23 Y250.757 F1000
G1 X50.148 Y250.733 F1000
G1 X51.067 Y250.712 F1000
G1 X51.986 Y250.693 F1000
G1 X52.905 Y250.677 F1000
G1 X53.824 Y250.663 F1000
G1 X54.743 Y250.65 F1000
G1 X55.662 Y250.639 F1000
G1 X56.58 Y250.63 F1000
G1 X57.499 Y250.622 F1000
G1 X59.337 Y250.608 F1000
G1 X61.175 Y250.598 F1000
G1 X63.933 Y250.586 F1000
G1 X67.609 Y250.571 F1000
G1 X69.447 Y250.561 F1000
G1 X70.366 Y250.554 F1000
G1 X71.285 Y250.546 F1000
G1 X72.204 Y250.536 F1000
G1 X73.122 Y250.524 F1000
G1 X74.041 Y250.51 F1000
G1 X74.96 Y250.493 F1000
G1 X75.879 Y250.473 F1000
G1 X76.798 Y250.449 F1000
G1 X77.716 Y250.423 F1000
G1 X78.635 Y250.392 F1000
G1 X79.553 Y250.358 F1000
G1 X80.471 Y250.319 F1000
G1 X81.39 Y250.277 F1000
G1 X82.307 Y250.231 F1000
G1 X83.225 Y250.181 F1000
G1 X84.143 Y250.128 F1000
G1 X85.06 Y250.071 F1000
G1 X85.977 Y250.012 F1000
G1 X86.894 Y249.949 F1000
G1 X87.811 Y249.885 F1000
G1 X88.727 Y249.818 F1000
G1 X89.644 Y249.749 F1000
G1 X91.476 Y249.609 F1000
G1 X95.141 Y249.325 F1000
G1 X96.058 Y249.255 F1000
G1 X96.974 Y249.186 F1000
G1 X97.891 Y249.119 F1000
G1 X98.807 Y249.053 F1000
G1 X99.724 Y248.989 F1000
G1 X100.641 Y248.927 F1000
G1 X101.558 Y248.867 F1000
G1 X102.475 Y248.81 F1000
G1 X103.393 Y248.755 F1000
G1 X104.31 Y248.702 F1000
G1 X105.228 Y248.652 F1000
G1 X106.146 Y248.604 F1000
G1 X107.064 Y248.559 F1000
G1 X107.982 Y248.516 F1000
G1 X108.9 Y248.476 F1000
G1 X109.818 Y248.438 F1000
G1 X110.736 Y248.402 F1000
G1 X111.655 Y248.369 F1000
G1 X112.573 Y248.339 F1000
G1 X113.492 Y248.31 F1000
G1 X114.41 Y248.284 F1000
G1 X115.329 Y248.259 F1000
G1 X116.248 Y248.237 F1000
G1 X117.167 Y248.216 F1000
G1 X118.086 Y248.197 F1000
G1 X119.004 Y248.18 F1000
G1 X119.923 Y248.164 F1000
G1 X120.842 Y248.15 F1000
G1 X121.761 Y248.137 F1000
G1 X122.68 Y248.125 F1000
G1 X123.599 Y248.114 F1000
G1 X125.437 Y248.096 F1000
G1 X127.275 Y248.081 F1000
G1 X129.113 Y248.07 F1000
G1 X130.951 Y248.061 F1000
G1 X133.708 Y248.051 F1000
G1 X136.465 Y248.044 F1000
G1 X140.141 Y248.038 F1000
G1 X142.898 Y248.037 F1000
G1 X145.655 Y248.038 F1000
G1 X147.493 Y248.041 F1000
G1 X149.331 Y248.048 F1000
G1 X150.25 Y248.053 F1000
G1 X151.169 Y248.059 F1000
G1 X152.088 Y248.067 F1000
G1 X153.007 Y248.076 F1000
G1 X153.926 Y248.088 F1000
G1 X154.845 Y248.103 F1000
G1 X155.764 Y248.121 F1000
G1 X156.683 Y248.142 F1000
G1 X157.601 Y248.167 F1000
G1 X158.52 Y248.196 F1000
G1 X159.438 Y248.231 F1000
G1 X160.357 Y248.271 F1000
G1 X161.274 Y248.318 F1000
G1 X162.192 Y248.372 F1000
G1 X163.109 Y248.434 F1000
G1 X164.025 Y248.506 F1000
G1 X164.94 Y248.588 F1000
G1 X165.854 Y248.682 F1000
G1 X166.767 Y248.791 F1000
G1 X167.678 Y248.915 F1000
G1 X168.585 Y249.058 F1000
G1 X169.489 Y249.224 F1000
G1 X170.388 Y249.418 F1000
G1 X171.278 Y249.647 F1000
G1 X172.081 Y249.903 F1000
G1 X172.628 Y250.126 F1000
G1 X172.924 Y250.277 F1000
G1 X173.197 Y250.455 F1000
G1 X173.424 Y250.689 F1000
G1 X173.594 Y250.966 F1000
G1 X173.7 Y251.274 F1000
G1 X173.736 Y251.598 F1000
G1 Y254.1 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y254.685 I-0.635 J-0.022 F1000
G1 X173.221 Y254.705 Z-3.012 F1000
G1 X173.153 Y254.726 Z-3 F1000
G1 X173.088 Y254.746 Z-2.98 F1000
G1 X173.025 Y254.766 Z-2.953 F1000
G1 X172.966 Y254.784 Z-2.919 F1000
G1 X172.91 Y254.801 Z-2.877 F1000
G1 X172.859 Y254.817 Z-2.83 F1000
G1 X172.814 Y254.831 Z-2.777 F1000
G1 X172.775 Y254.843 Z-2.719 F1000
G1 X172.742 Y254.853 Z-2.657 F1000
G1 X172.716 Y254.861 Z-2.591 F1000
G1 X172.697 Y254.867 Z-2.522 F1000
G1 X172.685 Y254.87 Z-2.452 F1000
G1 X172.682 Y254.872 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y260.803 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y260.8 Z-2.452 F1000
G1 X22.509 Y260.79 Z-2.522 F1000
G1 X22.499 Y260.773 Z-2.591 F1000
G1 X22.485 Y260.749 Z-2.657 F1000
G1 X22.467 Y260.72 Z-2.719 F1000
G1 X22.446 Y260.684 Z-2.777 F1000
G1 X22.422 Y260.644 Z-2.83 F1000
G1 X22.395 Y260.598 Z-2.877 F1000
G1 X22.365 Y260.548 Z-2.919 F1000
G1 X22.333 Y260.494 Z-2.953 F1000
G1 X22.3 Y260.438 Z-2.98 F1000
G1 X22.265 Y260.379 Z-3 F1000
G1 X22.229 Y260.319 Z-3.012 F1000
G1 X22.192 Y260.258 Z-3.016 F1000
G3 X21.971 Y259.504 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y257.207 F1000
G1 X21.988 Y256.87 F1000
G1 X22.02 Y256.628 F1000
G1 X22.081 Y256.342 F1000
G1 X22.167 Y256.055 F1000
G1 X22.297 Y255.721 F1000
G1 X22.47 Y255.365 F1000
G1 X22.693 Y254.985 F1000
G1 X22.985 Y254.569 F1000
G1 X23.349 Y254.131 F1000
G1 X23.799 Y253.67 F1000
G1 X24.373 Y253.169 F1000
G1 X25.085 Y252.642 F1000
G1 X25.866 Y252.156 F1000
G1 X26.678 Y251.726 F1000
G1 X27.513 Y251.344 F1000
G1 X28.367 Y251.003 F1000
G1 X29.234 Y250.698 F1000
G1 X30.111 Y250.425 F1000
G1 X30.997 Y250.18 F1000
G1 X31.889 Y249.96 F1000
G1 X32.787 Y249.761 F1000
G1 X33.688 Y249.582 F1000
G1 X34.593 Y249.42 F1000
G1 X35.5 Y249.274 F1000
G1 X36.41 Y249.143 F1000
G1 X37.321 Y249.024 F1000
G1 X38.234 Y248.917 F1000
G1 X39.148 Y248.82 F1000
G1 X40.063 Y248.733 F1000
G1 X40.978 Y248.655 F1000
G1 X41.895 Y248.585 F1000
G1 X42.811 Y248.521 F1000
G1 X43.729 Y248.465 F1000
G1 X44.646 Y248.414 F1000
G1 X45.564 Y248.369 F1000
G1 X46.482 Y248.328 F1000
G1 X47.401 Y248.292 F1000
G1 X48.319 Y248.26 F1000
G1 X49.238 Y248.232 F1000
G1 X50.156 Y248.207 F1000
G1 X51.075 Y248.184 F1000
G1 X51.994 Y248.165 F1000
G1 X52.913 Y248.147 F1000
G1 X53.832 Y248.132 F1000
G1 X54.751 Y248.119 F1000
G1 X55.67 Y248.107 F1000
G1 X56.588 Y248.096 F1000
G1 X57.507 Y248.087 F1000
G1 X59.345 Y248.073 F1000
G1 X61.183 Y248.061 F1000
G1 X63.94 Y248.048 F1000
G1 X66.698 Y248.035 F1000
G1 X68.536 Y248.024 F1000
G1 X69.455 Y248.018 F1000
G1 X70.373 Y248.01 F1000
G1 X71.292 Y248.001 F1000
G1 X72.211 Y247.989 F1000
G1 X73.13 Y247.976 F1000
G1 X74.049 Y247.96 F1000
G1 X74.968 Y247.942 F1000
G1 X75.887 Y247.92 F1000
G1 X76.806 Y247.896 F1000
G1 X77.724 Y247.867 F1000
G1 X78.643 Y247.836 F1000
G1 X79.561 Y247.8 F1000
G1 X80.479 Y247.761 F1000
G1 X81.397 Y247.718 F1000
G1 X82.315 Y247.672 F1000
G1 X83.233 Y247.622 F1000
G1 X84.15 Y247.568 F1000
G1 X85.067 Y247.512 F1000
G1 X85.984 Y247.453 F1000
G1 X86.901 Y247.391 F1000
G1 X87.818 Y247.327 F1000
G1 X88.735 Y247.261 F1000
G1 X89.651 Y247.194 F1000
G1 X91.484 Y247.056 F1000
G1 X95.15 Y246.778 F1000
G1 X96.066 Y246.709 F1000
G1 X96.983 Y246.642 F1000
G1 X97.9 Y246.576 F1000
G1 X98.816 Y246.512 F1000
G1 X99.733 Y246.449 F1000
G1 X100.65 Y246.388 F1000
G1 X101.567 Y246.33 F1000
G1 X102.485 Y246.273 F1000
G1 X103.402 Y246.219 F1000
G1 X104.32 Y246.167 F1000
G1 X105.237 Y246.117 F1000
G1 X106.155 Y246.07 F1000
G1 X107.073 Y246.025 F1000
G1 X107.991 Y245.983 F1000
G1 X108.909 Y245.943 F1000
G1 X109.827 Y245.905 F1000
G1 X110.746 Y245.87 F1000
G1 X111.664 Y245.837 F1000
G1 X112.583 Y245.806 F1000
G1 X113.501 Y245.778 F1000
G1 X114.42 Y245.751 F1000
G1 X115.339 Y245.727 F1000
G1 X116.257 Y245.704 F1000
G1 X117.176 Y245.683 F1000
G1 X118.095 Y245.664 F1000
G1 X119.014 Y245.646 F1000
G1 X119.933 Y245.63 F1000
G1 X120.852 Y245.615 F1000
G1 X121.771 Y245.602 F1000
G1 X122.689 Y245.59 F1000
G1 X123.608 Y245.579 F1000
G1 X125.446 Y245.56 F1000
G1 X127.284 Y245.545 F1000
G1 X129.122 Y245.533 F1000
G1 X130.96 Y245.523 F1000
G1 X133.717 Y245.512 F1000
G1 X136.474 Y245.505 F1000
G1 X139.231 Y245.5 F1000
G1 X141.989 Y245.498 F1000
G1 X144.746 Y245.499 F1000
G1 X146.584 Y245.502 F1000
G1 X148.422 Y245.507 F1000
G1 X149.341 Y245.512 F1000
G1 X150.26 Y245.517 F1000
G1 X151.179 Y245.524 F1000
G1 X152.098 Y245.533 F1000
G1 X153.017 Y245.544 F1000
G1 X153.936 Y245.557 F1000
G1 X154.854 Y245.573 F1000
G1 X155.773 Y245.592 F1000
G1 X156.692 Y245.614 F1000
G1 X157.611 Y245.641 F1000
G1 X158.529 Y245.672 F1000
G1 X159.447 Y245.708 F1000
G1 X160.365 Y245.75 F1000
G1 X161.283 Y245.799 F1000
G1 X162.201 Y245.855 F1000
G1 X163.117 Y245.919 F1000
G1 X164.033 Y245.992 F1000
G1 X164.949 Y246.076 F1000
G1 X165.863 Y246.172 F1000
G1 X166.775 Y246.282 F1000
G1 X167.685 Y246.408 F1000
G1 X168.593 Y246.553 F1000
G1 X169.497 Y246.72 F1000
G1 X170.395 Y246.915 F1000
G1 X171.284 Y247.145 F1000
G1 X172.086 Y247.402 F1000
G1 X172.633 Y247.626 F1000
G1 X172.925 Y247.775 F1000
G1 X173.198 Y247.953 F1000
G1 X173.424 Y248.187 F1000
G1 X173.595 Y248.464 F1000
G1 X173.7 Y248.772 F1000
G1 X173.736 Y249.096 F1000
G1 Y251.598 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y252.183 I-0.635 J-0.022 F1000
G1 X173.221 Y252.204 Z-3.012 F1000
G1 X173.153 Y252.225 Z-3 F1000
G1 X173.088 Y252.245 Z-2.98 F1000
G1 X173.025 Y252.264 Z-2.953 F1000
G1 X172.966 Y252.283 Z-2.919 F1000
G1 X172.91 Y252.3 Z-2.877 F1000
G1 X172.859 Y252.315 Z-2.83 F1000
G1 X172.814 Y252.329 Z-2.777 F1000
G1 X172.775 Y252.341 Z-2.719 F1000
G1 X172.742 Y252.352 Z-2.657 F1000
G1 X172.716 Y252.36 Z-2.591 F1000
G1 X172.697 Y252.365 Z-2.522 F1000
G1 X172.685 Y252.369 Z-2.452 F1000
G1 X172.682 Y252.37 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y258.506 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y258.503 Z-2.452 F1000
G1 X22.509 Y258.493 Z-2.522 F1000
G1 X22.499 Y258.476 Z-2.591 F1000
G1 X22.485 Y258.452 Z-2.657 F1000
G1 X22.467 Y258.423 Z-2.719 F1000
G1 X22.446 Y258.387 Z-2.777 F1000
G1 X22.422 Y258.346 Z-2.83 F1000
G1 X22.395 Y258.301 Z-2.877 F1000
G1 X22.365 Y258.251 Z-2.919 F1000
G1 X22.333 Y258.197 Z-2.953 F1000
G1 X22.3 Y258.141 Z-2.98 F1000
G1 X22.265 Y258.082 Z-3 F1000
G1 X22.229 Y258.021 Z-3.012 F1000
G1 X22.192 Y257.96 Z-3.016 F1000
G3 X21.971 Y257.207 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y254.701 F1000
G1 X21.986 Y254.402 F1000
G1 X22.018 Y254.159 F1000
G1 X22.079 Y253.873 F1000
G1 X22.165 Y253.585 F1000
G1 X22.295 Y253.251 F1000
G1 X22.47 Y252.892 F1000
G1 X22.693 Y252.512 F1000
G1 X22.987 Y252.094 F1000
G1 X23.351 Y251.656 F1000
G1 X23.803 Y251.192 F1000
G1 X24.379 Y250.689 F1000
G1 X25.095 Y250.16 F1000
G1 X25.876 Y249.674 F1000
G1 X26.687 Y249.243 F1000
G1 X27.523 Y248.86 F1000
G1 X28.376 Y248.518 F1000
G1 X29.242 Y248.213 F1000
G1 X30.12 Y247.938 F1000
G1 X31.005 Y247.692 F1000
G1 X31.897 Y247.47 F1000
G1 X32.794 Y247.27 F1000
G1 X33.695 Y247.089 F1000
G1 X34.599 Y246.925 F1000
G1 X35.506 Y246.777 F1000
G1 X36.415 Y246.644 F1000
G1 X37.326 Y246.523 F1000
G1 X38.239 Y246.414 F1000
G1 X39.153 Y246.315 F1000
G1 X40.067 Y246.226 F1000
G1 X40.983 Y246.146 F1000
G1 X41.899 Y246.074 F1000
G1 X42.816 Y246.008 F1000
G1 X43.733 Y245.95 F1000
G1 X44.65 Y245.897 F1000
G1 X45.568 Y245.85 F1000
G1 X46.486 Y245.808 F1000
G1 X47.405 Y245.771 F1000
G1 X48.323 Y245.737 F1000
G1 X49.242 Y245.707 F1000
G1 X50.16 Y245.681 F1000
G1 X51.079 Y245.657 F1000
G1 X51.998 Y245.636 F1000
G1 X52.917 Y245.618 F1000
G1 X53.835 Y245.601 F1000
G1 X54.754 Y245.587 F1000
G1 X55.673 Y245.574 F1000
G1 X56.592 Y245.563 F1000
G1 X57.511 Y245.553 F1000
G1 X59.349 Y245.537 F1000
G1 X61.187 Y245.525 F1000
G1 X64.863 Y245.504 F1000
G1 X67.62 Y245.488 F1000
G1 X68.539 Y245.482 F1000
G1 X69.458 Y245.474 F1000
G1 X70.377 Y245.465 F1000
G1 X71.296 Y245.455 F1000
G1 X72.215 Y245.442 F1000
G1 X73.134 Y245.428 F1000
G1 X74.053 Y245.411 F1000
G1 X74.972 Y245.391 F1000
G1 X75.89 Y245.368 F1000
G1 X76.809 Y245.342 F1000
G1 X77.728 Y245.313 F1000
G1 X78.646 Y245.28 F1000
G1 X79.564 Y245.243 F1000
G1 X80.482 Y245.204 F1000
G1 X81.4 Y245.16 F1000
G1 X82.318 Y245.113 F1000
G1 X83.236 Y245.063 F1000
G1 X84.153 Y245.01 F1000
G1 X85.071 Y244.954 F1000
G1 X85.988 Y244.895 F1000
G1 X86.905 Y244.834 F1000
G1 X87.822 Y244.771 F1000
G1 X88.738 Y244.706 F1000
G1 X89.655 Y244.639 F1000
G1 X91.488 Y244.504 F1000
G1 X95.154 Y244.231 F1000
G1 X96.071 Y244.164 F1000
G1 X96.987 Y244.098 F1000
G1 X97.904 Y244.034 F1000
G1 X98.821 Y243.971 F1000
G1 X99.738 Y243.909 F1000
G1 X100.655 Y243.85 F1000
G1 X101.572 Y243.792 F1000
G1 X102.489 Y243.736 F1000
G1 X103.407 Y243.683 F1000
G1 X104.324 Y243.632 F1000
G1 X105.242 Y243.583 F1000
G1 X106.16 Y243.536 F1000
G1 X107.078 Y243.492 F1000
G1 X107.996 Y243.45 F1000
G1 X108.914 Y243.41 F1000
G1 X109.832 Y243.373 F1000
G1 X110.751 Y243.338 F1000
G1 X111.669 Y243.305 F1000
G1 X112.588 Y243.274 F1000
G1 X113.506 Y243.245 F1000
G1 X114.425 Y243.219 F1000
G1 X115.344 Y243.194 F1000
G1 X116.262 Y243.171 F1000
G1 X117.181 Y243.15 F1000
G1 X118.1 Y243.13 F1000
G1 X119.019 Y243.113 F1000
G1 X119.938 Y243.096 F1000
G1 X120.857 Y243.081 F1000
G1 X121.776 Y243.068 F1000
G1 X122.694 Y243.055 F1000
G1 X123.613 Y243.044 F1000
G1 X125.451 Y243.024 F1000
G1 X127.289 Y243.009 F1000
G1 X129.127 Y242.996 F1000
G1 X130.965 Y242.986 F1000
G1 X133.722 Y242.974 F1000
G1 X136.479 Y242.967 F1000
G1 X139.236 Y242.962 F1000
G1 X141.994 Y242.959 F1000
G1 X144.751 Y242.961 F1000
G1 X146.589 Y242.964 F1000
G1 X148.427 Y242.971 F1000
G1 X149.346 Y242.976 F1000
G1 X150.265 Y242.982 F1000
G1 X151.184 Y242.99 F1000
G1 X152.103 Y243 F1000
G1 X153.022 Y243.011 F1000
G1 X153.94 Y243.026 F1000
G1 X154.859 Y243.043 F1000
G1 X155.778 Y243.063 F1000
G1 X156.697 Y243.087 F1000
G1 X157.615 Y243.115 F1000
G1 X158.534 Y243.148 F1000
G1 X159.452 Y243.186 F1000
G1 X160.37 Y243.229 F1000
G1 X161.288 Y243.28 F1000
G1 X162.205 Y243.337 F1000
G1 X163.122 Y243.403 F1000
G1 X164.038 Y243.478 F1000
G1 X164.953 Y243.563 F1000
G1 X165.866 Y243.661 F1000
G1 X166.779 Y243.772 F1000
G1 X167.689 Y243.9 F1000
G1 X168.596 Y244.046 F1000
G1 X169.5 Y244.214 F1000
G1 X170.398 Y244.41 F1000
G1 X171.287 Y244.641 F1000
G1 X172.089 Y244.898 F1000
G1 X172.636 Y245.123 F1000
G1 X172.927 Y245.271 F1000
G1 X173.198 Y245.45 F1000
G1 X173.425 Y245.683 F1000
G1 X173.595 Y245.961 F1000
G1 X173.7 Y246.268 F1000
G1 X173.736 Y246.592 F1000
G1 Y249.096 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y249.68 I-0.635 J-0.022 F1000
G1 X173.221 Y249.701 Z-3.012 F1000
G1 X173.153 Y249.722 Z-3 F1000
G1 X173.088 Y249.742 Z-2.98 F1000
G1 X173.025 Y249.761 Z-2.953 F1000
G1 X172.966 Y249.78 Z-2.919 F1000
G1 X172.91 Y249.797 Z-2.877 F1000
G1 X172.859 Y249.813 Z-2.83 F1000
G1 X172.814 Y249.826 Z-2.777 F1000
G1 X172.775 Y249.839 Z-2.719 F1000
G1 X172.742 Y249.849 Z-2.657 F1000
G1 X172.716 Y249.857 Z-2.591 F1000
G1 X172.697 Y249.863 Z-2.522 F1000
G1 X172.685 Y249.866 Z-2.452 F1000
G1 X172.682 Y249.867 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y256 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y255.997 Z-2.452 F1000
G1 X22.509 Y255.986 Z-2.522 F1000
G1 X22.499 Y255.97 Z-2.591 F1000
G1 X22.485 Y255.946 Z-2.657 F1000
G1 X22.467 Y255.917 Z-2.719 F1000
G1 X22.446 Y255.881 Z-2.777 F1000
G1 X22.422 Y255.84 Z-2.83 F1000
G1 X22.395 Y255.795 Z-2.877 F1000
G1 X22.365 Y255.745 Z-2.919 F1000
G1 X22.333 Y255.691 Z-2.953 F1000
G1 X22.3 Y255.635 Z-2.98 F1000
G1 X22.265 Y255.576 Z-3 F1000
G1 X22.229 Y255.515 Z-3.012 F1000
G1 X22.192 Y255.454 Z-3.016 F1000
G3 X21.971 Y254.701 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y252.195 F1000
G1 X21.984 Y251.929 F1000
G1 X22.016 Y251.687 F1000
G1 X22.077 Y251.4 F1000
G1 X22.164 Y251.11 F1000
G1 X22.294 Y250.776 F1000
G1 X22.469 Y250.415 F1000
G1 X22.693 Y250.036 F1000
G1 X22.987 Y249.617 F1000
G1 X23.352 Y249.177 F1000
G1 X23.806 Y248.712 F1000
G1 X24.384 Y248.207 F1000
G1 X25.103 Y247.675 F1000
G1 X25.884 Y247.19 F1000
G1 X26.695 Y246.759 F1000
G1 X27.53 Y246.375 F1000
G1 X28.383 Y246.032 F1000
G1 X29.249 Y245.726 F1000
G1 X30.126 Y245.45 F1000
G1 X31.011 Y245.202 F1000
G1 X31.903 Y244.979 F1000
G1 X32.799 Y244.777 F1000
G1 X33.7 Y244.594 F1000
G1 X34.604 Y244.429 F1000
G1 X35.511 Y244.28 F1000
G1 X36.42 Y244.144 F1000
G1 X37.33 Y244.021 F1000
G1 X38.243 Y243.91 F1000
G1 X39.156 Y243.81 F1000
G1 X40.071 Y243.719 F1000
G1 X40.986 Y243.637 F1000
G1 X41.902 Y243.562 F1000
G1 X42.819 Y243.495 F1000
G1 X43.736 Y243.435 F1000
G1 X44.653 Y243.381 F1000
G1 X45.571 Y243.332 F1000
G1 X46.489 Y243.288 F1000
G1 X47.407 Y243.249 F1000
G1 X48.325 Y243.214 F1000
G1 X49.244 Y243.183 F1000
G1 X50.162 Y243.155 F1000
G1 X51.081 Y243.13 F1000
G1 X52 Y243.108 F1000
G1 X52.919 Y243.089 F1000
G1 X53.838 Y243.071 F1000
G1 X54.756 Y243.056 F1000
G1 X55.675 Y243.042 F1000
G1 X56.594 Y243.03 F1000
G1 X57.513 Y243.02 F1000
G1 X58.432 Y243.01 F1000
G1 X60.27 Y242.995 F1000
G1 X63.027 Y242.976 F1000
G1 X66.703 Y242.953 F1000
G1 X68.541 Y242.939 F1000
G1 X69.46 Y242.93 F1000
G1 X70.379 Y242.92 F1000
G1 X71.298 Y242.909 F1000
G1 X72.217 Y242.895 F1000
G1 X73.136 Y242.879 F1000
G1 X74.055 Y242.861 F1000
G1 X74.974 Y242.84 F1000
G1 X75.892 Y242.816 F1000
G1 X76.811 Y242.788 F1000
G1 X77.729 Y242.758 F1000
G1 X78.648 Y242.724 F1000
G1 X79.566 Y242.687 F1000
G1 X80.484 Y242.647 F1000
G1 X81.402 Y242.603 F1000
G1 X82.32 Y242.556 F1000
G1 X83.238 Y242.506 F1000
G1 X84.155 Y242.452 F1000
G1 X85.072 Y242.397 F1000
G1 X85.99 Y242.338 F1000
G1 X86.907 Y242.278 F1000
G1 X87.824 Y242.215 F1000
G1 X88.74 Y242.151 F1000
G1 X90.574 Y242.02 F1000
G1 X95.157 Y241.685 F1000
G1 X96.073 Y241.62 F1000
G1 X96.99 Y241.555 F1000
G1 X97.907 Y241.492 F1000
G1 X98.824 Y241.43 F1000
G1 X99.741 Y241.37 F1000
G1 X100.658 Y241.311 F1000
G1 X101.575 Y241.254 F1000
G1 X102.493 Y241.2 F1000
G1 X103.41 Y241.147 F1000
G1 X104.328 Y241.096 F1000
G1 X105.245 Y241.048 F1000
G1 X106.163 Y241.002 F1000
G1 X107.081 Y240.958 F1000
G1 X107.999 Y240.917 F1000
G1 X108.918 Y240.877 F1000
G1 X109.836 Y240.84 F1000
G1 X110.754 Y240.805 F1000
G1 X111.673 Y240.772 F1000
G1 X112.591 Y240.741 F1000
G1 X113.51 Y240.713 F1000
G1 X114.428 Y240.686 F1000
G1 X115.347 Y240.661 F1000
G1 X116.266 Y240.638 F1000
G1 X117.185 Y240.617 F1000
G1 X118.103 Y240.597 F1000
G1 X119.022 Y240.579 F1000
G1 X119.941 Y240.562 F1000
G1 X120.86 Y240.547 F1000
G1 X121.779 Y240.533 F1000
G1 X122.698 Y240.52 F1000
G1 X123.617 Y240.509 F1000
G1 X125.455 Y240.489 F1000
G1 X127.293 Y240.472 F1000
G1 X129.131 Y240.459 F1000
G1 X130.969 Y240.448 F1000
G1 X133.726 Y240.436 F1000
G1 X136.483 Y240.428 F1000
G1 X139.24 Y240.423 F1000
G1 X141.997 Y240.421 F1000
G1 X143.835 F1000
G1 X145.673 Y240.424 F1000
G1 X147.511 Y240.43 F1000
G1 X148.43 Y240.434 F1000
G1 X149.349 Y240.44 F1000
G1 X150.268 Y240.447 F1000
G1 X151.187 Y240.456 F1000
G1 X152.106 Y240.467 F1000
G1 X153.025 Y240.479 F1000
G1 X153.944 Y240.495 F1000
G1 X154.863 Y240.513 F1000
G1 X155.781 Y240.535 F1000
G1 X156.7 Y240.56 F1000
G1 X157.619 Y240.589 F1000
G1 X158.537 Y240.624 F1000
G1 X159.455 Y240.663 F1000
G1 X160.373 Y240.708 F1000
G1 X161.291 Y240.76 F1000
G1 X162.208 Y240.819 F1000
G1 X163.124 Y240.886 F1000
G1 X164.04 Y240.963 F1000
G1 X164.955 Y241.05 F1000
G1 X165.869 Y241.149 F1000
G1 X166.781 Y241.261 F1000
G1 X167.691 Y241.39 F1000
G1 X168.598 Y241.537 F1000
G1 X169.501 Y241.707 F1000
G1 X170.399 Y241.903 F1000
G1 X171.288 Y242.135 F1000
G1 X172.091 Y242.393 F1000
G1 X172.638 Y242.619 F1000
G1 X172.927 Y242.766 F1000
G1 X173.199 Y242.945 F1000
G1 X173.425 Y243.178 F1000
G1 X173.595 Y243.456 F1000
G1 X173.7 Y243.763 F1000
G1 X173.736 Y244.086 F1000
G1 Y246.592 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y247.176 I-0.635 J-0.022 F1000
G1 X173.221 Y247.197 Z-3.012 F1000
G1 X173.153 Y247.218 Z-3 F1000
G1 X173.088 Y247.238 Z-2.98 F1000
G1 X173.025 Y247.257 Z-2.953 F1000
G1 X172.966 Y247.276 Z-2.919 F1000
G1 X172.91 Y247.293 Z-2.877 F1000
G1 X172.859 Y247.308 Z-2.83 F1000
G1 X172.814 Y247.322 Z-2.777 F1000
G1 X172.775 Y247.335 Z-2.719 F1000
G1 X172.742 Y247.345 Z-2.657 F1000
G1 X172.716 Y247.353 Z-2.591 F1000
G1 X172.697 Y247.359 Z-2.522 F1000
G1 X172.685 Y247.362 Z-2.452 F1000
G1 X172.682 Y247.363 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y253.494 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y253.491 Z-2.452 F1000
G1 X22.509 Y253.48 Z-2.522 F1000
G1 X22.499 Y253.464 Z-2.591 F1000
G1 X22.485 Y253.44 Z-2.657 F1000
G1 X22.467 Y253.411 Z-2.719 F1000
G1 X22.446 Y253.375 Z-2.777 F1000
G1 X22.422 Y253.334 Z-2.83 F1000
G1 X22.395 Y253.289 Z-2.877 F1000
G1 X22.365 Y253.239 Z-2.919 F1000
G1 X22.333 Y253.185 Z-2.953 F1000
G1 X22.3 Y253.129 Z-2.98 F1000
G1 X22.265 Y253.07 Z-3 F1000
G1 X22.229 Y253.009 Z-3.012 F1000
G1 X22.192 Y252.948 Z-3.016 F1000
G3 X21.971 Y252.195 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y249.689 F1000
G1 X21.983 Y249.453 F1000
G1 X22.015 Y249.21 F1000
G1 X22.076 Y248.923 F1000
G1 X22.163 Y248.633 F1000
G1 X22.293 Y248.299 F1000
G1 X22.469 Y247.937 F1000
G1 X22.692 Y247.557 F1000
G1 X22.988 Y247.136 F1000
G1 X23.353 Y246.697 F1000
G1 X23.809 Y246.229 F1000
G1 X24.389 Y245.723 F1000
G1 X25.11 Y245.189 F1000
G1 X25.891 Y244.704 F1000
G1 X26.702 Y244.273 F1000
G1 X27.537 Y243.888 F1000
G1 X28.389 Y243.545 F1000
G1 X29.255 Y243.237 F1000
G1 X30.132 Y242.961 F1000
G1 X31.016 Y242.711 F1000
G1 X31.908 Y242.487 F1000
G1 X32.804 Y242.283 F1000
G1 X33.704 Y242.099 F1000
G1 X34.608 Y241.932 F1000
G1 X35.514 Y241.781 F1000
G1 X36.423 Y241.644 F1000
G1 X37.334 Y241.519 F1000
G1 X38.246 Y241.406 F1000
G1 X39.159 Y241.304 F1000
G1 X40.073 Y241.211 F1000
G1 X40.988 Y241.127 F1000
G1 X41.904 Y241.051 F1000
G1 X42.821 Y240.982 F1000
G1 X43.738 Y240.92 F1000
G1 X44.655 Y240.864 F1000
G1 X45.573 Y240.814 F1000
G1 X46.491 Y240.769 F1000
G1 X47.409 Y240.728 F1000
G1 X48.327 Y240.692 F1000
G1 X49.245 Y240.659 F1000
G1 X50.164 Y240.63 F1000
G1 X51.083 Y240.604 F1000
G1 X52.001 Y240.58 F1000
G1 X52.92 Y240.56 F1000
G1 X53.839 Y240.541 F1000
G1 X54.758 Y240.525 F1000
G1 X55.677 Y240.511 F1000
G1 X56.596 Y240.498 F1000
G1 X57.515 Y240.486 F1000
G1 X58.434 Y240.476 F1000
G1 X60.272 Y240.459 F1000
G1 X63.029 Y240.438 F1000
G1 X66.705 Y240.412 F1000
G1 X68.543 Y240.396 F1000
G1 X69.461 Y240.386 F1000
G1 X70.38 Y240.375 F1000
G1 X71.299 Y240.362 F1000
G1 X72.218 Y240.347 F1000
G1 X73.137 Y240.33 F1000
G1 X74.056 Y240.311 F1000
G1 X74.975 Y240.288 F1000
G1 X75.893 Y240.263 F1000
G1 X76.812 Y240.235 F1000
G1 X77.73 Y240.204 F1000
G1 X78.649 Y240.169 F1000
G1 X79.567 Y240.131 F1000
G1 X80.485 Y240.09 F1000
G1 X81.403 Y240.046 F1000
G1 X82.321 Y239.999 F1000
G1 X83.239 Y239.949 F1000
G1 X84.156 Y239.896 F1000
G1 X85.073 Y239.84 F1000
G1 X85.991 Y239.782 F1000
G1 X86.908 Y239.722 F1000
G1 X87.825 Y239.661 F1000
G1 X88.741 Y239.598 F1000
G1 X90.575 Y239.468 F1000
G1 X94.242 Y239.205 F1000
G1 X96.075 Y239.076 F1000
G1 X96.992 Y239.012 F1000
G1 X97.909 Y238.95 F1000
G1 X98.826 Y238.889 F1000
G1 X99.743 Y238.83 F1000
G1 X100.66 Y238.772 F1000
G1 X101.577 Y238.717 F1000
G1 X102.495 Y238.663 F1000
G1 X103.412 Y238.611 F1000
G1 X104.33 Y238.561 F1000
G1 X105.248 Y238.513 F1000
G1 X106.166 Y238.468 F1000
G1 X107.084 Y238.424 F1000
G1 X108.002 Y238.383 F1000
G1 X108.92 Y238.344 F1000
G1 X109.838 Y238.307 F1000
G1 X110.757 Y238.272 F1000
G1 X111.675 Y238.239 F1000
G1 X112.594 Y238.209 F1000
G1 X113.512 Y238.18 F1000
G1 X114.431 Y238.153 F1000
G1 X115.35 Y238.128 F1000
G1 X116.268 Y238.105 F1000
G1 X117.187 Y238.083 F1000
G1 X118.106 Y238.063 F1000
G1 X119.025 Y238.045 F1000
G1 X119.944 Y238.028 F1000
G1 X120.862 Y238.013 F1000
G1 X121.781 Y237.998 F1000
G1 X122.7 Y237.985 F1000
G1 X123.619 Y237.973 F1000
G1 X125.457 Y237.953 F1000
G1 X127.295 Y237.936 F1000
G1 X129.133 Y237.922 F1000
G1 X130.971 Y237.911 F1000
G1 X133.728 Y237.898 F1000
G1 X136.485 Y237.89 F1000
G1 X139.242 Y237.884 F1000
G1 X141.999 Y237.882 F1000
G1 X143.837 Y237.883 F1000
G1 X145.675 Y237.887 F1000
G1 X147.513 Y237.894 F1000
G1 X148.432 Y237.899 F1000
G1 X149.351 Y237.905 F1000
G1 X150.27 Y237.913 F1000
G1 X151.189 Y237.922 F1000
G1 X152.108 Y237.934 F1000
G1 X153.027 Y237.948 F1000
G1 X153.946 Y237.964 F1000
G1 X154.865 Y237.984 F1000
G1 X155.784 Y238.006 F1000
G1 X156.702 Y238.033 F1000
G1 X157.621 Y238.064 F1000
G1 X158.539 Y238.099 F1000
G1 X159.457 Y238.14 F1000
G1 X160.375 Y238.187 F1000
G1 X161.293 Y238.24 F1000
G1 X162.21 Y238.301 F1000
G1 X163.126 Y238.369 F1000
G1 X164.042 Y238.447 F1000
G1 X164.956 Y238.536 F1000
G1 X165.87 Y238.636 F1000
G1 X166.782 Y238.75 F1000
G1 X167.692 Y238.88 F1000
G1 X168.599 Y239.028 F1000
G1 X169.502 Y239.198 F1000
G1 X170.399 Y239.396 F1000
G1 X171.288 Y239.628 F1000
G1 X172.093 Y239.887 F1000
G1 X172.64 Y240.113 F1000
G1 X172.928 Y240.261 F1000
G1 X173.2 Y240.439 F1000
G1 X173.426 Y240.673 F1000
G1 X173.595 Y240.95 F1000
G1 X173.7 Y241.257 F1000
G1 X173.736 Y241.58 F1000
G1 Y244.086 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y244.671 I-0.635 J-0.022 F1000
G1 X173.221 Y244.692 Z-3.012 F1000
G1 X173.153 Y244.713 Z-3 F1000
G1 X173.088 Y244.733 Z-2.98 F1000
G1 X173.025 Y244.752 Z-2.953 F1000
G1 X172.966 Y244.771 Z-2.919 F1000
G1 X172.91 Y244.788 Z-2.877 F1000
G1 X172.859 Y244.803 Z-2.83 F1000
G1 X172.814 Y244.817 Z-2.777 F1000
G1 X172.775 Y244.829 Z-2.719 F1000
G1 X172.742 Y244.84 Z-2.657 F1000
G1 X172.716 Y244.848 Z-2.591 F1000
G1 X172.697 Y244.853 Z-2.522 F1000
G1 X172.685 Y244.857 Z-2.452 F1000
G1 X172.682 Y244.858 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y250.988 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y250.985 Z-2.452 F1000
G1 X22.509 Y250.974 Z-2.522 F1000
G1 X22.499 Y250.958 Z-2.591 F1000
G1 X22.485 Y250.934 Z-2.657 F1000
G1 X22.467 Y250.904 Z-2.719 F1000
G1 X22.446 Y250.869 Z-2.777 F1000
G1 X22.422 Y250.828 Z-2.83 F1000
G1 X22.395 Y250.783 Z-2.877 F1000
G1 X22.365 Y250.733 Z-2.919 F1000
G1 X22.333 Y250.679 Z-2.953 F1000
G1 X22.3 Y250.623 Z-2.98 F1000
G1 X22.265 Y250.564 Z-3 F1000
G1 X22.229 Y250.503 Z-3.012 F1000
G1 X22.192 Y250.442 Z-3.016 F1000
G3 X21.971 Y249.689 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y247.183 F1000
G1 X21.981 Y246.974 F1000
G1 X22.013 Y246.731 F1000
G1 X22.075 Y246.444 F1000
G1 X22.162 Y246.153 F1000
G1 X22.292 Y245.819 F1000
G1 X22.468 Y245.455 F1000
G1 X22.692 Y245.076 F1000
G1 X22.988 Y244.654 F1000
G1 X23.354 Y244.214 F1000
G1 X23.811 Y243.745 F1000
G1 X24.393 Y243.238 F1000
G1 X25.117 Y242.702 F1000
G1 X25.897 Y242.216 F1000
G1 X26.709 Y241.785 F1000
G1 X27.543 Y241.4 F1000
G1 X28.395 Y241.056 F1000
G1 X29.261 Y240.747 F1000
G1 X30.137 Y240.469 F1000
G1 X31.021 Y240.219 F1000
G1 X31.912 Y239.993 F1000
G1 X32.808 Y239.788 F1000
G1 X33.708 Y239.602 F1000
G1 X34.611 Y239.434 F1000
G1 X35.518 Y239.281 F1000
G1 X36.426 Y239.142 F1000
G1 X37.336 Y239.016 F1000
G1 X38.248 Y238.901 F1000
G1 X39.161 Y238.797 F1000
G1 X40.075 Y238.703 F1000
G1 X40.99 Y238.617 F1000
G1 X41.906 Y238.539 F1000
G1 X42.823 Y238.469 F1000
G1 X43.739 Y238.405 F1000
G1 X44.657 Y238.348 F1000
G1 X45.574 Y238.296 F1000
G1 X46.492 Y238.249 F1000
G1 X47.41 Y238.207 F1000
G1 X48.328 Y238.169 F1000
G1 X49.247 Y238.135 F1000
G1 X50.165 Y238.104 F1000
G1 X51.084 Y238.077 F1000
G1 X52.002 Y238.053 F1000
G1 X52.921 Y238.031 F1000
G1 X53.84 Y238.012 F1000
G1 X54.759 Y237.994 F1000
G1 X55.678 Y237.979 F1000
G1 X56.597 Y237.965 F1000
G1 X57.516 Y237.953 F1000
G1 X58.435 Y237.942 F1000
G1 X60.273 Y237.923 F1000
G1 X63.029 Y237.9 F1000
G1 X65.786 Y237.879 F1000
G1 X67.624 Y237.862 F1000
G1 X68.543 Y237.853 F1000
G1 X69.462 Y237.842 F1000
G1 X70.381 Y237.83 F1000
G1 X71.3 Y237.815 F1000
G1 X72.219 Y237.799 F1000
G1 X73.138 Y237.781 F1000
G1 X74.057 Y237.76 F1000
G1 X74.975 Y237.737 F1000
G1 X75.894 Y237.711 F1000
G1 X76.813 Y237.682 F1000
G1 X77.731 Y237.65 F1000
G1 X78.649 Y237.614 F1000
G1 X79.568 Y237.576 F1000
G1 X80.486 Y237.535 F1000
G1 X81.404 Y237.49 F1000
G1 X82.321 Y237.443 F1000
G1 X83.239 Y237.392 F1000
G1 X84.157 Y237.34 F1000
G1 X85.074 Y237.284 F1000
G1 X85.991 Y237.227 F1000
G1 X86.908 Y237.168 F1000
G1 X87.825 Y237.107 F1000
G1 X88.742 Y237.045 F1000
G1 X90.576 Y236.918 F1000
G1 X94.243 Y236.659 F1000
G1 X96.077 Y236.532 F1000
G1 X96.993 Y236.47 F1000
G1 X97.91 Y236.408 F1000
G1 X98.827 Y236.349 F1000
G1 X99.745 Y236.29 F1000
G1 X100.662 Y236.234 F1000
G1 X101.579 Y236.179 F1000
G1 X102.497 Y236.126 F1000
G1 X103.414 Y236.075 F1000
G1 X104.332 Y236.025 F1000
G1 X105.25 Y235.978 F1000
G1 X106.168 Y235.933 F1000
G1 X107.086 Y235.89 F1000
G1 X108.004 Y235.849 F1000
G1 X108.922 Y235.81 F1000
G1 X109.84 Y235.774 F1000
G1 X110.759 Y235.739 F1000
G1 X111.677 Y235.706 F1000
G1 X112.596 Y235.676 F1000
G1 X113.514 Y235.647 F1000
G1 X114.433 Y235.62 F1000
G1 X115.352 Y235.595 F1000
G1 X116.27 Y235.571 F1000
G1 X117.189 Y235.55 F1000
G1 X118.108 Y235.53 F1000
G1 X119.027 Y235.511 F1000
G1 X119.946 Y235.494 F1000
G1 X120.864 Y235.478 F1000
G1 X121.783 Y235.464 F1000
G1 X122.702 Y235.45 F1000
G1 X123.621 Y235.438 F1000
G1 X125.459 Y235.417 F1000
G1 X127.297 Y235.4 F1000
G1 X129.135 Y235.385 F1000
G1 X130.973 Y235.374 F1000
G1 X132.811 Y235.365 F1000
G1 X135.568 Y235.354 F1000
G1 X138.325 Y235.348 F1000
G1 X141.082 Y235.344 F1000
G1 X142.92 Y235.345 F1000
G1 X144.758 Y235.347 F1000
G1 X146.596 Y235.353 F1000
G1 X147.515 Y235.357 F1000
G1 X148.434 Y235.363 F1000
G1 X149.353 Y235.37 F1000
G1 X150.272 Y235.378 F1000
G1 X151.191 Y235.389 F1000
G1 X152.11 Y235.401 F1000
G1 X153.029 Y235.416 F1000
G1 X153.948 Y235.434 F1000
G1 X154.867 Y235.454 F1000
G1 X155.786 Y235.478 F1000
G1 X156.704 Y235.506 F1000
G1 X157.623 Y235.538 F1000
G1 X158.541 Y235.575 F1000
G1 X159.459 Y235.617 F1000
G1 X160.377 Y235.665 F1000
G1 X161.294 Y235.72 F1000
G1 X162.211 Y235.782 F1000
G1 X163.127 Y235.852 F1000
G1 X164.043 Y235.931 F1000
G1 X164.958 Y236.021 F1000
G1 X165.871 Y236.122 F1000
G1 X166.783 Y236.238 F1000
G1 X167.692 Y236.369 F1000
G1 X168.599 Y236.518 F1000
G1 X169.502 Y236.689 F1000
G1 X170.4 Y236.887 F1000
G1 X171.288 Y237.12 F1000
G1 X172.094 Y237.38 F1000
G1 X172.641 Y237.607 F1000
G1 X172.929 Y237.754 F1000
G1 X173.2 Y237.932 F1000
G1 X173.426 Y238.166 F1000
G1 X173.595 Y238.443 F1000
G1 X173.7 Y238.75 F1000
G1 X173.736 Y239.073 F1000
G1 Y241.58 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y242.165 I-0.635 J-0.022 F1000
G1 X173.221 Y242.186 Z-3.012 F1000
G1 X173.153 Y242.206 Z-3 F1000
G1 X173.088 Y242.227 Z-2.98 F1000
G1 X173.025 Y242.246 Z-2.953 F1000
G1 X172.966 Y242.264 Z-2.919 F1000
G1 X172.91 Y242.281 Z-2.877 F1000
G1 X172.859 Y242.297 Z-2.83 F1000
G1 X172.814 Y242.311 Z-2.777 F1000
G1 X172.775 Y242.323 Z-2.719 F1000
G1 X172.742 Y242.333 Z-2.657 F1000
G1 X172.716 Y242.341 Z-2.591 F1000
G1 X172.697 Y242.347 Z-2.522 F1000
G1 X172.685 Y242.351 Z-2.452 F1000
G1 X172.682 Y242.352 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y248.482 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y248.479 Z-2.452 F1000
G1 X22.509 Y248.468 Z-2.522 F1000
G1 X22.499 Y248.452 Z-2.591 F1000
G1 X22.485 Y248.428 Z-2.657 F1000
G1 X22.467 Y248.398 Z-2.719 F1000
G1 X22.446 Y248.363 Z-2.777 F1000
G1 X22.422 Y248.322 Z-2.83 F1000
G1 X22.395 Y248.277 Z-2.877 F1000
G1 X22.365 Y248.227 Z-2.919 F1000
G1 X22.333 Y248.173 Z-2.953 F1000
G1 X22.3 Y248.117 Z-2.98 F1000
G1 X22.265 Y248.058 Z-3 F1000
G1 X22.229 Y247.997 Z-3.012 F1000
G1 X22.192 Y247.936 Z-3.016 F1000
G3 X21.971 Y247.183 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y244.677 F1000
G1 X21.98 Y244.492 F1000
G1 X22.012 Y244.25 F1000
G1 X22.073 Y243.963 F1000
G1 X22.161 Y243.671 F1000
G1 X22.291 Y243.337 F1000
G1 X22.468 Y242.972 F1000
G1 X22.691 Y242.593 F1000
G1 X22.989 Y242.169 F1000
G1 X23.354 Y241.729 F1000
G1 X23.813 Y241.259 F1000
G1 X24.396 Y240.75 F1000
G1 X25.123 Y240.212 F1000
G1 X25.903 Y239.727 F1000
G1 X26.714 Y239.295 F1000
G1 X27.549 Y238.91 F1000
G1 X28.401 Y238.565 F1000
G1 X29.266 Y238.255 F1000
G1 X30.142 Y237.977 F1000
G1 X31.026 Y237.725 F1000
G1 X31.916 Y237.498 F1000
G1 X32.812 Y237.292 F1000
G1 X33.711 Y237.105 F1000
G1 X34.615 Y236.935 F1000
G1 X35.521 Y236.78 F1000
G1 X36.429 Y236.64 F1000
G1 X37.339 Y236.512 F1000
G1 X38.25 Y236.396 F1000
G1 X39.163 Y236.29 F1000
G1 X40.077 Y236.194 F1000
G1 X40.992 Y236.106 F1000
G1 X41.908 Y236.027 F1000
G1 X42.824 Y235.955 F1000
G1 X43.741 Y235.89 F1000
G1 X44.658 Y235.831 F1000
G1 X45.575 Y235.777 F1000
G1 X46.493 Y235.729 F1000
G1 X47.411 Y235.686 F1000
G1 X48.329 Y235.646 F1000
G1 X49.248 Y235.611 F1000
G1 X50.166 Y235.579 F1000
G1 X51.085 Y235.551 F1000
G1 X52.003 Y235.525 F1000
G1 X52.922 Y235.502 F1000
G1 X53.841 Y235.482 F1000
G1 X54.76 Y235.464 F1000
G1 X55.679 Y235.448 F1000
G1 X56.597 Y235.433 F1000
G1 X57.516 Y235.42 F1000
G1 X58.435 Y235.408 F1000
G1 X60.273 Y235.388 F1000
G1 X63.03 Y235.362 F1000
G1 X65.787 Y235.338 F1000
G1 X67.625 Y235.32 F1000
G1 X68.544 Y235.309 F1000
G1 X69.463 Y235.297 F1000
G1 X70.382 Y235.284 F1000
G1 X71.301 Y235.269 F1000
G1 X72.22 Y235.252 F1000
G1 X73.138 Y235.232 F1000
G1 X74.057 Y235.21 F1000
G1 X74.976 Y235.186 F1000
G1 X75.895 Y235.159 F1000
G1 X76.813 Y235.129 F1000
G1 X77.732 Y235.096 F1000
G1 X78.65 Y235.06 F1000
G1 X79.568 Y235.021 F1000
G1 X80.486 Y234.979 F1000
G1 X81.404 Y234.935 F1000
G1 X82.322 Y234.887 F1000
G1 X83.239 Y234.837 F1000
G1 X84.157 Y234.784 F1000
G1 X85.074 Y234.73 F1000
G1 X85.992 Y234.673 F1000
G1 X86.909 Y234.614 F1000
G1 X87.826 Y234.554 F1000
G1 X89.66 Y234.43 F1000
G1 X94.244 Y234.113 F1000
G1 X96.078 Y233.988 F1000
G1 X96.995 Y233.927 F1000
G1 X97.912 Y233.867 F1000
G1 X98.829 Y233.808 F1000
G1 X99.746 Y233.751 F1000
G1 X100.663 Y233.695 F1000
G1 X101.581 Y233.641 F1000
G1 X102.498 Y233.589 F1000
G1 X103.416 Y233.538 F1000
G1 X104.334 Y233.49 F1000
G1 X105.252 Y233.443 F1000
G1 X106.169 Y233.398 F1000
G1 X107.088 Y233.356 F1000
G1 X108.006 Y233.315 F1000
G1 X108.924 Y233.277 F1000
G1 X109.842 Y233.24 F1000
G1 X110.761 Y233.206 F1000
G1 X111.679 Y233.173 F1000
G1 X112.597 Y233.142 F1000
G1 X113.516 Y233.114 F1000
G1 X114.435 Y233.087 F1000
G1 X115.353 Y233.061 F1000
G1 X116.272 Y233.038 F1000
G1 X117.191 Y233.016 F1000
G1 X118.11 Y232.996 F1000
G1 X119.028 Y232.977 F1000
G1 X119.947 Y232.96 F1000
G1 X120.866 Y232.944 F1000
G1 X121.785 Y232.929 F1000
G1 X122.704 Y232.915 F1000
G1 X123.623 Y232.903 F1000
G1 X125.461 Y232.881 F1000
G1 X127.299 Y232.863 F1000
G1 X129.137 Y232.849 F1000
G1 X130.975 Y232.837 F1000
G1 X132.813 Y232.827 F1000
G1 X135.57 Y232.816 F1000
G1 X138.327 Y232.809 F1000
G1 X141.084 Y232.806 F1000
G1 X142.922 Y232.807 F1000
G1 X144.76 Y232.81 F1000
G1 X146.598 Y232.817 F1000
G1 X147.517 Y232.821 F1000
G1 X148.436 Y232.828 F1000
G1 X149.355 Y232.835 F1000
G1 X150.274 Y232.845 F1000
G1 X151.193 Y232.856 F1000
G1 X152.112 Y232.869 F1000
G1 X153.031 Y232.885 F1000
G1 X153.95 Y232.904 F1000
G1 X154.868 Y232.925 F1000
G1 X155.787 Y232.95 F1000
G1 X156.706 Y232.98 F1000
G1 X157.624 Y233.013 F1000
G1 X158.542 Y233.051 F1000
G1 X159.46 Y233.094 F1000
G1 X160.378 Y233.144 F1000
G1 X161.295 Y233.2 F1000
G1 X162.212 Y233.263 F1000
G1 X163.128 Y233.334 F1000
G1 X164.044 Y233.415 F1000
G1 X164.958 Y233.506 F1000
G1 X165.872 Y233.608 F1000
G1 X166.783 Y233.725 F1000
G1 X167.693 Y233.857 F1000
G1 X168.599 Y234.007 F1000
G1 X169.502 Y234.179 F1000
G1 X170.399 Y234.378 F1000
G1 X171.288 Y234.611 F1000
G1 X172.095 Y234.872 F1000
G1 X172.642 Y235.099 F1000
G1 X172.929 Y235.246 F1000
G1 X173.2 Y235.424 F1000
G1 X173.426 Y235.658 F1000
G1 X173.595 Y235.935 F1000
G1 X173.7 Y236.242 F1000
G1 X173.736 Y236.565 F1000
G1 Y239.073 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y239.658 I-0.635 J-0.022 F1000
G1 X173.221 Y239.678 Z-3.012 F1000
G1 X173.153 Y239.699 Z-3 F1000
G1 X173.088 Y239.719 Z-2.98 F1000
G1 X173.025 Y239.739 Z-2.953 F1000
G1 X172.966 Y239.757 Z-2.919 F1000
G1 X172.91 Y239.774 Z-2.877 F1000
G1 X172.859 Y239.79 Z-2.83 F1000
G1 X172.814 Y239.804 Z-2.777 F1000
G1 X172.775 Y239.816 Z-2.719 F1000
G1 X172.742 Y239.826 Z-2.657 F1000
G1 X172.716 Y239.834 Z-2.591 F1000
G1 X172.697 Y239.84 Z-2.522 F1000
G1 X172.685 Y239.843 Z-2.452 F1000
G1 X172.682 Y239.845 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y245.976 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y245.973 Z-2.452 F1000
G1 X22.509 Y245.962 Z-2.522 F1000
G1 X22.499 Y245.945 Z-2.591 F1000
G1 X22.485 Y245.922 Z-2.657 F1000
G1 X22.467 Y245.892 Z-2.719 F1000
G1 X22.446 Y245.857 Z-2.777 F1000
G1 X22.422 Y245.816 Z-2.83 F1000
G1 X22.395 Y245.771 Z-2.877 F1000
G1 X22.365 Y245.721 Z-2.919 F1000
G1 X22.333 Y245.667 Z-2.953 F1000
G1 X22.3 Y245.611 Z-2.98 F1000
G1 X22.265 Y245.552 Z-3 F1000
G1 X22.229 Y245.491 Z-3.012 F1000
G1 X22.192 Y245.43 Z-3.016 F1000
G3 X21.971 Y244.677 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y242.171 F1000
G1 X21.979 Y242.009 F1000
G1 X22.011 Y241.766 F1000
G1 X22.072 Y241.479 F1000
G1 X22.16 Y241.187 F1000
G1 X22.29 Y240.853 F1000
G1 X22.468 Y240.486 F1000
G1 X22.691 Y240.107 F1000
G1 X22.989 Y239.683 F1000
G1 X23.355 Y239.242 F1000
G1 X23.815 Y238.771 F1000
G1 X24.399 Y238.261 F1000
G1 X25.128 Y237.721 F1000
G1 X25.909 Y237.236 F1000
G1 X26.72 Y236.804 F1000
G1 X27.554 Y236.418 F1000
G1 X28.405 Y236.073 F1000
G1 X29.271 Y235.762 F1000
G1 X30.146 Y235.483 F1000
G1 X31.03 Y235.23 F1000
G1 X31.92 Y235.002 F1000
G1 X32.815 Y234.794 F1000
G1 X33.715 Y234.606 F1000
G1 X34.618 Y234.435 F1000
G1 X35.523 Y234.279 F1000
G1 X36.431 Y234.137 F1000
G1 X37.341 Y234.007 F1000
G1 X38.253 Y233.89 F1000
G1 X39.165 Y233.782 F1000
G1 X40.079 Y233.685 F1000
G1 X40.994 Y233.596 F1000
G1 X41.909 Y233.515 F1000
G1 X42.825 Y233.441 F1000
G1 X43.742 Y233.374 F1000
G1 X44.659 Y233.314 F1000
G1 X45.576 Y233.259 F1000
G1 X46.494 Y233.209 F1000
G1 X47.412 Y233.164 F1000
G1 X48.33 Y233.124 F1000
G1 X49.248 Y233.087 F1000
G1 X50.167 Y233.054 F1000
G1 X51.085 Y233.025 F1000
G1 X52.004 Y232.998 F1000
G1 X52.923 Y232.974 F1000
G1 X53.841 Y232.953 F1000
G1 X54.76 Y232.933 F1000
G1 X55.679 Y232.916 F1000
G1 X56.598 Y232.901 F1000
G1 X57.517 Y232.887 F1000
G1 X58.436 Y232.874 F1000
G1 X60.274 Y232.852 F1000
G1 X63.031 Y232.824 F1000
G1 X65.788 Y232.798 F1000
G1 X67.626 Y232.777 F1000
G1 X68.544 Y232.765 F1000
G1 X69.463 Y232.753 F1000
G1 X70.382 Y232.738 F1000
G1 X71.301 Y232.722 F1000
G1 X72.22 Y232.704 F1000
G1 X73.139 Y232.683 F1000
G1 X74.058 Y232.66 F1000
G1 X74.976 Y232.635 F1000
G1 X75.895 Y232.607 F1000
G1 X76.813 Y232.576 F1000
G1 X77.732 Y232.543 F1000
G1 X78.65 Y232.506 F1000
G1 X79.568 Y232.467 F1000
G1 X80.486 Y232.424 F1000
G1 X81.404 Y232.38 F1000
G1 X82.322 Y232.332 F1000
G1 X83.24 Y232.282 F1000
G1 X84.157 Y232.23 F1000
G1 X85.075 Y232.175 F1000
G1 X85.992 Y232.119 F1000
G1 X86.909 Y232.061 F1000
G1 X87.826 Y232.002 F1000
G1 X89.66 Y231.88 F1000
G1 X94.245 Y231.567 F1000
G1 X96.079 Y231.445 F1000
G1 X96.996 Y231.384 F1000
G1 X97.913 Y231.325 F1000
G1 X98.83 Y231.268 F1000
G1 X99.747 Y231.211 F1000
G1 X100.665 Y231.156 F1000
G1 X101.582 Y231.103 F1000
G1 X102.5 Y231.051 F1000
G1 X103.417 Y231.002 F1000
G1 X104.335 Y230.954 F1000
G1 X105.253 Y230.907 F1000
G1 X106.171 Y230.863 F1000
G1 X107.089 Y230.821 F1000
G1 X108.007 Y230.781 F1000
G1 X108.925 Y230.743 F1000
G1 X109.844 Y230.706 F1000
G1 X110.762 Y230.672 F1000
G1 X111.68 Y230.64 F1000
G1 X112.599 Y230.609 F1000
G1 X113.517 Y230.58 F1000
G1 X114.436 Y230.553 F1000
G1 X115.355 Y230.528 F1000
G1 X116.274 Y230.504 F1000
G1 X117.192 Y230.482 F1000
G1 X118.111 Y230.462 F1000
G1 X119.03 Y230.443 F1000
G1 X119.949 Y230.425 F1000
G1 X120.868 Y230.409 F1000
G1 X121.787 Y230.394 F1000
G1 X122.705 Y230.38 F1000
G1 X123.624 Y230.368 F1000
G1 X125.462 Y230.346 F1000
G1 X127.3 Y230.327 F1000
G1 X129.138 Y230.312 F1000
G1 X130.976 Y230.299 F1000
G1 X132.814 Y230.289 F1000
G1 X135.571 Y230.278 F1000
G1 X138.328 Y230.271 F1000
G1 X141.085 Y230.268 F1000
G1 X142.923 Y230.269 F1000
G1 X144.761 Y230.273 F1000
G1 X145.68 Y230.276 F1000
G1 X146.599 Y230.28 F1000
G1 X147.518 Y230.286 F1000
G1 X148.437 Y230.293 F1000
G1 X149.356 Y230.301 F1000
G1 X150.275 Y230.311 F1000
G1 X151.194 Y230.323 F1000
G1 X152.113 Y230.337 F1000
G1 X153.032 Y230.354 F1000
G1 X153.951 Y230.374 F1000
G1 X154.87 Y230.396 F1000
G1 X155.788 Y230.423 F1000
G1 X156.707 Y230.453 F1000
G1 X157.625 Y230.487 F1000
G1 X158.543 Y230.527 F1000
G1 X159.461 Y230.571 F1000
G1 X160.379 Y230.622 F1000
G1 X161.296 Y230.679 F1000
G1 X162.213 Y230.744 F1000
G1 X163.129 Y230.816 F1000
G1 X164.044 Y230.898 F1000
G1 X164.959 Y230.99 F1000
G1 X165.872 Y231.094 F1000
G1 X166.784 Y231.211 F1000
G1 X167.693 Y231.344 F1000
G1 X168.599 Y231.495 F1000
G1 X169.502 Y231.668 F1000
G1 X170.399 Y231.867 F1000
G1 X171.288 Y232.102 F1000
G1 X172.095 Y232.363 F1000
G1 X172.643 Y232.59 F1000
G1 X172.93 Y232.737 F1000
G1 X173.201 Y232.916 F1000
G1 X173.426 Y233.149 F1000
G1 X173.596 Y233.426 F1000
G1 X173.7 Y233.733 F1000
G1 X173.736 Y234.056 F1000
G1 Y236.565 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y237.149 I-0.635 J-0.022 F1000
G1 X173.221 Y237.17 Z-3.012 F1000
G1 X173.153 Y237.191 Z-3 F1000
G1 X173.088 Y237.211 Z-2.98 F1000
G1 X173.025 Y237.231 Z-2.953 F1000
G1 X172.966 Y237.249 Z-2.919 F1000
G1 X172.91 Y237.266 Z-2.877 F1000
G1 X172.859 Y237.282 Z-2.83 F1000
G1 X172.814 Y237.296 Z-2.777 F1000
G1 X172.775 Y237.308 Z-2.719 F1000
G1 X172.742 Y237.318 Z-2.657 F1000
G1 X172.716 Y237.326 Z-2.591 F1000
G1 X172.697 Y237.332 Z-2.522 F1000
G1 X172.685 Y237.335 Z-2.452 F1000
G1 X172.682 Y237.336 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y243.47 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y243.467 Z-2.452 F1000
G1 X22.509 Y243.456 Z-2.522 F1000
G1 X22.499 Y243.439 Z-2.591 F1000
G1 X22.485 Y243.416 Z-2.657 F1000
G1 X22.467 Y243.386 Z-2.719 F1000
G1 X22.446 Y243.351 Z-2.777 F1000
G1 X22.422 Y243.31 Z-2.83 F1000
G1 X22.395 Y243.265 Z-2.877 F1000
G1 X22.365 Y243.215 Z-2.919 F1000
G1 X22.333 Y243.161 Z-2.953 F1000
G1 X22.3 Y243.105 Z-2.98 F1000
G1 X22.265 Y243.046 Z-3 F1000
G1 X22.229 Y242.985 Z-3.012 F1000
G1 X22.192 Y242.924 Z-3.016 F1000
G3 X21.971 Y242.171 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y239.874 F1000
G1 X21.989 Y239.514 F1000
G1 X22.021 Y239.271 F1000
G1 X22.082 Y238.984 F1000
G1 X22.17 Y238.693 F1000
G1 X22.3 Y238.359 F1000
G1 X22.477 Y237.993 F1000
G1 X22.7 Y237.614 F1000
G1 X22.998 Y237.19 F1000
G1 X23.364 Y236.749 F1000
G1 X23.824 Y236.277 F1000
G1 X24.409 Y235.767 F1000
G1 X25.139 Y235.227 F1000
G1 X25.92 Y234.741 F1000
G1 X26.731 Y234.309 F1000
G1 X27.565 Y233.923 F1000
G1 X28.416 Y233.577 F1000
G1 X29.281 Y233.266 F1000
G1 X30.156 Y232.986 F1000
G1 X31.039 Y232.732 F1000
G1 X31.929 Y232.503 F1000
G1 X32.824 Y232.294 F1000
G1 X33.724 Y232.105 F1000
G1 X34.626 Y231.932 F1000
G1 X35.532 Y231.775 F1000
G1 X36.44 Y231.632 F1000
G1 X37.349 Y231.501 F1000
G1 X38.261 Y231.382 F1000
G1 X39.173 Y231.273 F1000
G1 X40.087 Y231.174 F1000
G1 X41.001 Y231.084 F1000
G1 X41.917 Y231.001 F1000
G1 X42.833 Y230.926 F1000
G1 X43.749 Y230.858 F1000
G1 X44.666 Y230.796 F1000
G1 X45.583 Y230.74 F1000
G1 X46.501 Y230.689 F1000
G1 X47.419 Y230.643 F1000
G1 X48.337 Y230.601 F1000
G1 X49.255 Y230.563 F1000
G1 X50.174 Y230.529 F1000
G1 X51.092 Y230.498 F1000
G1 X52.011 Y230.471 F1000
G1 X52.929 Y230.446 F1000
G1 X53.848 Y230.423 F1000
G1 X54.767 Y230.403 F1000
G1 X55.686 Y230.385 F1000
G1 X56.605 Y230.369 F1000
G1 X57.523 Y230.354 F1000
G1 X58.442 Y230.34 F1000
G1 X60.28 Y230.317 F1000
G1 X63.037 Y230.286 F1000
G1 X65.794 Y230.257 F1000
G1 X67.632 Y230.234 F1000
G1 X68.551 Y230.222 F1000
G1 X69.47 Y230.208 F1000
G1 X70.389 Y230.192 F1000
G1 X71.308 Y230.175 F1000
G1 X72.226 Y230.155 F1000
G1 X73.145 Y230.134 F1000
G1 X74.064 Y230.11 F1000
G1 X74.983 Y230.084 F1000
G1 X75.901 Y230.055 F1000
G1 X76.82 Y230.023 F1000
G1 X77.738 Y229.989 F1000
G1 X78.656 Y229.952 F1000
G1 X79.574 Y229.912 F1000
G1 X80.492 Y229.87 F1000
G1 X81.41 Y229.825 F1000
G1 X82.328 Y229.777 F1000
G1 X83.246 Y229.727 F1000
G1 X84.163 Y229.675 F1000
G1 X85.081 Y229.621 F1000
G1 X85.998 Y229.565 F1000
G1 X86.915 Y229.508 F1000
G1 X87.832 Y229.449 F1000
G1 X89.667 Y229.329 F1000
G1 X94.251 Y229.022 F1000
G1 X96.085 Y228.901 F1000
G1 X97.003 Y228.842 F1000
G1 X97.92 Y228.784 F1000
G1 X98.837 Y228.727 F1000
G1 X99.754 Y228.671 F1000
G1 X100.672 Y228.617 F1000
G1 X101.589 Y228.565 F1000
G1 X102.507 Y228.514 F1000
G1 X103.425 Y228.464 F1000
G1 X104.342 Y228.417 F1000
G1 X105.26 Y228.372 F1000
G1 X106.178 Y228.328 F1000
G1 X107.096 Y228.286 F1000
G1 X108.014 Y228.246 F1000
G1 X108.933 Y228.208 F1000
G1 X109.851 Y228.172 F1000
G1 X110.769 Y228.138 F1000
G1 X111.688 Y228.106 F1000
G1 X112.606 Y228.075 F1000
G1 X113.525 Y228.046 F1000
G1 X114.444 Y228.019 F1000
G1 X115.362 Y227.994 F1000
G1 X116.281 Y227.97 F1000
G1 X117.2 Y227.948 F1000
G1 X118.119 Y227.928 F1000
G1 X119.037 Y227.909 F1000
G1 X119.956 Y227.891 F1000
G1 X120.875 Y227.874 F1000
G1 X121.794 Y227.859 F1000
G1 X122.713 Y227.845 F1000
G1 X123.632 Y227.832 F1000
G1 X125.47 Y227.81 F1000
G1 X127.308 Y227.791 F1000
G1 X129.146 Y227.775 F1000
G1 X130.984 Y227.762 F1000
G1 X132.822 Y227.752 F1000
G1 X134.66 Y227.744 F1000
G1 X137.417 Y227.735 F1000
G1 X139.255 Y227.732 F1000
G1 X141.093 Y227.731 F1000
G1 X142.931 Y227.732 F1000
G1 X144.769 Y227.736 F1000
G1 X145.688 Y227.74 F1000
G1 X146.607 Y227.745 F1000
G1 X147.526 Y227.75 F1000
G1 X148.445 Y227.758 F1000
G1 X149.364 Y227.767 F1000
G1 X150.283 Y227.778 F1000
G1 X151.202 Y227.79 F1000
G1 X152.121 Y227.806 F1000
G1 X153.039 Y227.823 F1000
G1 X153.958 Y227.844 F1000
G1 X154.877 Y227.868 F1000
G1 X155.796 Y227.895 F1000
G1 X156.714 Y227.927 F1000
G1 X157.632 Y227.962 F1000
G1 X158.551 Y228.003 F1000
G1 X159.468 Y228.049 F1000
G1 X160.386 Y228.101 F1000
G1 X161.303 Y228.159 F1000
G1 X162.22 Y228.225 F1000
G1 X163.136 Y228.298 F1000
G1 X164.051 Y228.381 F1000
G1 X164.965 Y228.475 F1000
G1 X165.878 Y228.58 F1000
G1 X166.79 Y228.698 F1000
G1 X167.699 Y228.832 F1000
G1 X168.605 Y228.984 F1000
G1 X169.508 Y229.157 F1000
G1 X170.405 Y229.358 F1000
G1 X171.293 Y229.593 F1000
G1 X172.1 Y229.854 F1000
G1 X172.647 Y230.082 F1000
G1 X172.931 Y230.228 F1000
G1 X173.202 Y230.406 F1000
G1 X173.427 Y230.64 F1000
G1 X173.596 Y230.917 F1000
G1 X173.701 Y231.223 F1000
G1 X173.736 Y231.546 F1000
G1 Y234.056 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y234.64 I-0.635 J-0.022 F1000
G1 X173.221 Y234.661 Z-3.012 F1000
G1 X173.153 Y234.682 Z-3 F1000
G1 X173.088 Y234.702 Z-2.98 F1000
G1 X173.025 Y234.721 Z-2.953 F1000
G1 X172.966 Y234.74 Z-2.919 F1000
G1 X172.91 Y234.757 Z-2.877 F1000
G1 X172.859 Y234.773 Z-2.83 F1000
G1 X172.814 Y234.787 Z-2.777 F1000
G1 X172.775 Y234.799 Z-2.719 F1000
G1 X172.742 Y234.809 Z-2.657 F1000
G1 X172.716 Y234.817 Z-2.591 F1000
G1 X172.697 Y234.823 Z-2.522 F1000
G1 X172.685 Y234.826 Z-2.452 F1000
G1 X172.682 Y234.827 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y241.173 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y241.169 Z-2.452 F1000
G1 X22.509 Y241.159 Z-2.522 F1000
G1 X22.499 Y241.142 Z-2.591 F1000
G1 X22.485 Y241.119 Z-2.657 F1000
G1 X22.467 Y241.089 Z-2.719 F1000
G1 X22.446 Y241.054 Z-2.777 F1000
G1 X22.422 Y241.013 Z-2.83 F1000
G1 X22.395 Y240.967 Z-2.877 F1000
G1 X22.365 Y240.917 Z-2.919 F1000
G1 X22.333 Y240.864 Z-2.953 F1000
G1 X22.3 Y240.807 Z-2.98 F1000
G1 X22.265 Y240.749 Z-3 F1000
G1 X22.229 Y240.688 Z-3.012 F1000
G1 X22.192 Y240.627 Z-3.016 F1000
G3 X21.971 Y239.874 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y237.368 F1000
G1 X21.988 Y237.029 F1000
G1 X22.02 Y236.787 F1000
G1 X22.081 Y236.499 F1000
G1 X22.169 Y236.207 F1000
G1 X22.299 Y235.873 F1000
G1 X22.477 Y235.505 F1000
G1 X22.701 Y235.126 F1000
G1 X22.999 Y234.701 F1000
G1 X23.366 Y234.259 F1000
G1 X23.827 Y233.786 F1000
G1 X24.414 Y233.274 F1000
G1 X25.146 Y232.732 F1000
G1 X25.927 Y232.247 F1000
G1 X26.738 Y231.814 F1000
G1 X27.571 Y231.428 F1000
G1 X28.423 Y231.081 F1000
G1 X29.287 Y230.77 F1000
G1 X30.162 Y230.489 F1000
G1 X31.045 Y230.234 F1000
G1 X31.935 Y230.004 F1000
G1 X32.83 Y229.794 F1000
G1 X33.729 Y229.604 F1000
G1 X34.631 Y229.43 F1000
G1 X35.536 Y229.272 F1000
G1 X36.444 Y229.127 F1000
G1 X37.353 Y228.995 F1000
G1 X38.265 Y228.874 F1000
G1 X39.177 Y228.764 F1000
G1 X40.09 Y228.664 F1000
G1 X41.005 Y228.572 F1000
G1 X41.92 Y228.488 F1000
G1 X42.836 Y228.412 F1000
G1 X43.752 Y228.342 F1000
G1 X44.669 Y228.279 F1000
G1 X45.586 Y228.221 F1000
G1 X46.504 Y228.169 F1000
G1 X47.422 Y228.121 F1000
G1 X48.34 Y228.078 F1000
G1 X49.258 Y228.039 F1000
G1 X50.176 Y228.004 F1000
G1 X51.095 Y227.972 F1000
G1 X52.013 Y227.943 F1000
G1 X52.932 Y227.917 F1000
G1 X53.851 Y227.894 F1000
G1 X54.769 Y227.873 F1000
G1 X55.688 Y227.854 F1000
G1 X56.607 Y227.837 F1000
G1 X57.526 Y227.821 F1000
G1 X58.445 Y227.807 F1000
G1 X60.283 Y227.781 F1000
G1 X63.04 Y227.748 F1000
G1 X65.796 Y227.716 F1000
G1 X67.634 Y227.691 F1000
G1 X68.553 Y227.678 F1000
G1 X69.472 Y227.663 F1000
G1 X70.391 Y227.646 F1000
G1 X71.31 Y227.628 F1000
G1 X72.229 Y227.607 F1000
G1 X73.147 Y227.585 F1000
G1 X74.066 Y227.56 F1000
G1 X74.985 Y227.533 F1000
G1 X75.903 Y227.503 F1000
G1 X76.822 Y227.471 F1000
G1 X77.74 Y227.436 F1000
G1 X78.658 Y227.399 F1000
G1 X79.576 Y227.359 F1000
G1 X80.494 Y227.316 F1000
G1 X81.412 Y227.271 F1000
G1 X82.33 Y227.223 F1000
G1 X83.248 Y227.174 F1000
G1 X84.165 Y227.122 F1000
G1 X85.083 Y227.068 F1000
G1 X86 Y227.013 F1000
G1 X86.917 Y226.956 F1000
G1 X88.752 Y226.839 F1000
G1 X91.503 Y226.658 F1000
G1 X94.254 Y226.477 F1000
G1 X96.088 Y226.358 F1000
G1 X97.005 Y226.299 F1000
G1 X97.923 Y226.242 F1000
G1 X98.84 Y226.186 F1000
G1 X99.757 Y226.131 F1000
G1 X100.675 Y226.078 F1000
G1 X101.592 Y226.026 F1000
G1 X102.51 Y225.976 F1000
G1 X103.428 Y225.928 F1000
G1 X104.346 Y225.881 F1000
G1 X105.263 Y225.836 F1000
G1 X106.181 Y225.792 F1000
G1 X107.1 Y225.751 F1000
G1 X108.018 Y225.711 F1000
G1 X108.936 Y225.674 F1000
G1 X109.854 Y225.638 F1000
G1 X110.773 Y225.604 F1000
G1 X111.691 Y225.572 F1000
G1 X112.61 Y225.541 F1000
G1 X113.528 Y225.512 F1000
G1 X114.447 Y225.485 F1000
G1 X115.366 Y225.46 F1000
G1 X116.284 Y225.436 F1000
G1 X117.203 Y225.414 F1000
G1 X118.122 Y225.393 F1000
G1 X119.041 Y225.374 F1000
G1 X119.959 Y225.356 F1000
G1 X120.878 Y225.34 F1000
G1 X121.797 Y225.324 F1000
G1 X122.716 Y225.31 F1000
G1 X123.635 Y225.297 F1000
G1 X125.473 Y225.274 F1000
G1 X127.311 Y225.254 F1000
G1 X129.149 Y225.238 F1000
G1 X130.987 Y225.225 F1000
G1 X132.825 Y225.214 F1000
G1 X134.663 Y225.206 F1000
G1 X136.501 Y225.2 F1000
G1 X138.339 Y225.195 F1000
G1 X140.177 Y225.193 F1000
G1 X142.015 F1000
G1 X143.853 Y225.197 F1000
G1 X144.772 Y225.2 F1000
G1 X145.691 Y225.204 F1000
G1 X146.61 Y225.209 F1000
G1 X147.529 Y225.215 F1000
G1 X148.448 Y225.223 F1000
G1 X149.367 Y225.233 F1000
G1 X150.286 Y225.245 F1000
G1 X151.205 Y225.258 F1000
G1 X152.124 Y225.274 F1000
G1 X153.043 Y225.293 F1000
G1 X153.961 Y225.314 F1000
G1 X154.88 Y225.339 F1000
G1 X155.799 Y225.368 F1000
G1 X156.717 Y225.4 F1000
G1 X157.635 Y225.437 F1000
G1 X158.553 Y225.479 F1000
G1 X159.471 Y225.526 F1000
G1 X160.389 Y225.579 F1000
G1 X161.306 Y225.638 F1000
G1 X162.222 Y225.705 F1000
G1 X163.138 Y225.78 F1000
G1 X164.054 Y225.864 F1000
G1 X164.968 Y225.958 F1000
G1 X165.881 Y226.064 F1000
G1 X166.792 Y226.184 F1000
G1 X167.701 Y226.318 F1000
G1 X168.607 Y226.471 F1000
G1 X169.509 Y226.645 F1000
G1 X170.406 Y226.846 F1000
G1 X171.295 Y227.082 F1000
G1 X172.101 Y227.344 F1000
G1 X172.649 Y227.572 F1000
G1 X172.932 Y227.717 F1000
G1 X173.202 Y227.896 F1000
G1 X173.427 Y228.129 F1000
G1 X173.596 Y228.406 F1000
G1 X173.701 Y228.713 F1000
G1 X173.736 Y229.035 F1000
G1 Y231.546 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y232.13 I-0.635 J-0.022 F1000
G1 X173.221 Y232.151 Z-3.012 F1000
G1 X173.153 Y232.172 Z-3 F1000
G1 X173.088 Y232.192 Z-2.98 F1000
G1 X173.025 Y232.212 Z-2.953 F1000
G1 X172.966 Y232.23 Z-2.919 F1000
G1 X172.91 Y232.247 Z-2.877 F1000
G1 X172.859 Y232.263 Z-2.83 F1000
G1 X172.814 Y232.277 Z-2.777 F1000
G1 X172.775 Y232.289 Z-2.719 F1000
G1 X172.742 Y232.299 Z-2.657 F1000
G1 X172.716 Y232.307 Z-2.591 F1000
G1 X172.697 Y232.313 Z-2.522 F1000
G1 X172.685 Y232.316 Z-2.452 F1000
G1 X172.682 Y232.317 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y238.667 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y238.663 Z-2.452 F1000
G1 X22.509 Y238.653 Z-2.522 F1000
G1 X22.499 Y238.636 Z-2.591 F1000
G1 X22.485 Y238.613 Z-2.657 F1000
G1 X22.467 Y238.583 Z-2.719 F1000
G1 X22.446 Y238.548 Z-2.777 F1000
G1 X22.422 Y238.507 Z-2.83 F1000
G1 X22.395 Y238.461 Z-2.877 F1000
G1 X22.365 Y238.411 Z-2.919 F1000
G1 X22.333 Y238.358 Z-2.953 F1000
G1 X22.3 Y238.301 Z-2.98 F1000
G1 X22.265 Y238.243 Z-3 F1000
G1 X22.229 Y238.182 Z-3.012 F1000
G1 X22.192 Y238.121 Z-3.016 F1000
G3 X21.971 Y237.368 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y234.862 F1000
G1 X21.987 Y234.542 F1000
G1 X22.019 Y234.299 F1000
G1 X22.08 Y234.011 F1000
G1 X22.168 Y233.718 F1000
G1 X22.298 Y233.384 F1000
G1 X22.477 Y233.015 F1000
G1 X22.701 Y232.636 F1000
G1 X23 Y232.21 F1000
G1 X23.367 Y231.768 F1000
G1 X23.83 Y231.293 F1000
G1 X24.418 Y230.78 F1000
G1 X25.152 Y230.237 F1000
G1 X25.932 Y229.752 F1000
G1 X26.743 Y229.319 F1000
G1 X27.577 Y228.932 F1000
G1 X28.428 Y228.585 F1000
G1 X29.292 Y228.273 F1000
G1 X30.167 Y227.991 F1000
G1 X31.05 Y227.736 F1000
G1 X31.939 Y227.504 F1000
G1 X32.834 Y227.294 F1000
G1 X33.732 Y227.102 F1000
G1 X34.635 Y226.927 F1000
G1 X35.54 Y226.767 F1000
G1 X36.447 Y226.622 F1000
G1 X37.356 Y226.488 F1000
G1 X38.267 Y226.366 F1000
G1 X39.179 Y226.255 F1000
G1 X40.093 Y226.153 F1000
G1 X41.007 Y226.06 F1000
G1 X41.922 Y225.975 F1000
G1 X42.838 Y225.897 F1000
G1 X43.754 Y225.826 F1000
G1 X44.671 Y225.761 F1000
G1 X45.588 Y225.702 F1000
G1 X46.505 Y225.649 F1000
G1 X47.423 Y225.6 F1000
G1 X48.341 Y225.556 F1000
G1 X49.259 Y225.516 F1000
G1 X50.178 Y225.479 F1000
G1 X51.096 Y225.446 F1000
G1 X52.015 Y225.416 F1000
G1 X52.933 Y225.389 F1000
G1 X53.852 Y225.365 F1000
G1 X54.771 Y225.343 F1000
G1 X55.689 Y225.323 F1000
G1 X56.608 Y225.305 F1000
G1 X57.527 Y225.288 F1000
G1 X58.446 Y225.273 F1000
G1 X60.284 Y225.246 F1000
G1 X63.041 Y225.21 F1000
G1 X65.798 Y225.175 F1000
G1 X67.635 Y225.148 F1000
G1 X68.554 Y225.133 F1000
G1 X69.473 Y225.117 F1000
G1 X70.392 Y225.1 F1000
G1 X71.311 Y225.081 F1000
G1 X72.23 Y225.059 F1000
G1 X73.148 Y225.036 F1000
G1 X74.067 Y225.01 F1000
G1 X74.986 Y224.982 F1000
G1 X75.904 Y224.952 F1000
G1 X76.823 Y224.919 F1000
G1 X77.741 Y224.884 F1000
G1 X78.659 Y224.846 F1000
G1 X79.577 Y224.805 F1000
G1 X80.495 Y224.763 F1000
G1 X81.413 Y224.717 F1000
G1 X82.331 Y224.67 F1000
G1 X83.249 Y224.62 F1000
G1 X84.166 Y224.569 F1000
G1 X85.084 Y224.516 F1000
G1 X86.001 Y224.461 F1000
G1 X86.918 Y224.405 F1000
G1 X88.753 Y224.289 F1000
G1 X91.504 Y224.111 F1000
G1 X94.255 Y223.932 F1000
G1 X96.09 Y223.815 F1000
G1 X97.924 Y223.701 F1000
G1 X98.841 Y223.646 F1000
G1 X99.759 Y223.592 F1000
G1 X100.676 Y223.539 F1000
G1 X101.594 Y223.488 F1000
G1 X102.512 Y223.438 F1000
G1 X103.429 Y223.39 F1000
G1 X104.347 Y223.344 F1000
G1 X105.265 Y223.3 F1000
G1 X106.183 Y223.257 F1000
G1 X107.101 Y223.216 F1000
G1 X108.02 Y223.177 F1000
G1 X108.938 Y223.139 F1000
G1 X109.856 Y223.103 F1000
G1 X110.775 Y223.07 F1000
G1 X111.693 Y223.037 F1000
G1 X112.612 Y223.007 F1000
G1 X113.53 Y222.978 F1000
G1 X114.449 Y222.951 F1000
G1 X115.367 Y222.926 F1000
G1 X116.286 Y222.902 F1000
G1 X117.205 Y222.88 F1000
G1 X118.124 Y222.859 F1000
G1 X119.042 Y222.84 F1000
G1 X119.961 Y222.822 F1000
G1 X120.88 Y222.805 F1000
G1 X121.799 Y222.789 F1000
G1 X122.718 Y222.775 F1000
G1 X123.637 Y222.761 F1000
G1 X125.475 Y222.738 F1000
G1 X127.313 Y222.718 F1000
G1 X129.151 Y222.702 F1000
G1 X130.989 Y222.688 F1000
G1 X132.827 Y222.677 F1000
G1 X134.665 Y222.668 F1000
G1 X136.503 Y222.662 F1000
G1 X138.341 Y222.657 F1000
G1 X140.179 Y222.656 F1000
G1 X142.017 F1000
G1 X143.855 Y222.66 F1000
G1 X144.774 Y222.663 F1000
G1 X145.693 Y222.668 F1000
G1 X146.612 Y222.673 F1000
G1 X147.531 Y222.68 F1000
G1 X148.45 Y222.689 F1000
G1 X149.369 Y222.699 F1000
G1 X150.288 Y222.712 F1000
G1 X151.207 Y222.726 F1000
G1 X152.126 Y222.743 F1000
G1 X153.044 Y222.762 F1000
G1 X153.963 Y222.785 F1000
G1 X154.882 Y222.811 F1000
G1 X155.8 Y222.84 F1000
G1 X156.719 Y222.874 F1000
G1 X157.637 Y222.912 F1000
G1 X158.555 Y222.954 F1000
G1 X159.473 Y223.002 F1000
G1 X160.39 Y223.056 F1000
G1 X161.307 Y223.117 F1000
G1 X162.224 Y223.185 F1000
G1 X163.14 Y223.261 F1000
G1 X164.055 Y223.346 F1000
G1 X164.969 Y223.441 F1000
G1 X165.882 Y223.548 F1000
G1 X166.793 Y223.668 F1000
G1 X167.702 Y223.804 F1000
G1 X168.608 Y223.958 F1000
G1 X169.51 Y224.133 F1000
G1 X170.407 Y224.334 F1000
G1 X171.295 Y224.57 F1000
G1 X172.102 Y224.833 F1000
G1 X172.65 Y225.061 F1000
G1 X172.932 Y225.206 F1000
G1 X173.202 Y225.385 F1000
G1 X173.427 Y225.618 F1000
G1 X173.596 Y225.895 F1000
G1 X173.701 Y226.202 F1000
G1 X173.736 Y226.524 F1000
G1 Y229.035 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y229.62 I-0.635 J-0.022 F1000
G1 X173.221 Y229.641 Z-3.012 F1000
G1 X173.153 Y229.661 Z-3 F1000
G1 X173.088 Y229.681 Z-2.98 F1000
G1 X173.025 Y229.701 Z-2.953 F1000
G1 X172.966 Y229.719 Z-2.919 F1000
G1 X172.91 Y229.736 Z-2.877 F1000
G1 X172.859 Y229.752 Z-2.83 F1000
G1 X172.814 Y229.766 Z-2.777 F1000
G1 X172.775 Y229.778 Z-2.719 F1000
G1 X172.742 Y229.788 Z-2.657 F1000
G1 X172.716 Y229.796 Z-2.591 F1000
G1 X172.697 Y229.802 Z-2.522 F1000
G1 X172.685 Y229.806 Z-2.452 F1000
G1 X172.682 Y229.807 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y236.161 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y236.157 Z-2.452 F1000
G1 X22.509 Y236.147 Z-2.522 F1000
G1 X22.499 Y236.13 Z-2.591 F1000
G1 X22.485 Y236.107 Z-2.657 F1000
G1 X22.467 Y236.077 Z-2.719 F1000
G1 X22.446 Y236.042 Z-2.777 F1000
G1 X22.422 Y236.001 Z-2.83 F1000
G1 X22.395 Y235.955 Z-2.877 F1000
G1 X22.365 Y235.905 Z-2.919 F1000
G1 X22.333 Y235.852 Z-2.953 F1000
G1 X22.3 Y235.795 Z-2.98 F1000
G1 X22.265 Y235.737 Z-3 F1000
G1 X22.229 Y235.676 Z-3.012 F1000
G1 X22.192 Y235.615 Z-3.016 F1000
G3 X21.971 Y234.862 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y232.355 F1000
G1 X21.986 Y232.052 F1000
G1 X22.018 Y231.809 F1000
G1 X22.08 Y231.521 F1000
G1 X22.168 Y231.227 F1000
G1 X22.298 Y230.893 F1000
G1 X22.477 Y230.523 F1000
G1 X22.701 Y230.144 F1000
G1 X23.001 Y229.717 F1000
G1 X23.368 Y229.275 F1000
G1 X23.831 Y228.799 F1000
G1 X24.421 Y228.285 F1000
G1 X25.157 Y227.741 F1000
G1 X25.937 Y227.255 F1000
G1 X26.748 Y226.822 F1000
G1 X27.581 Y226.435 F1000
G1 X28.432 Y226.088 F1000
G1 X29.296 Y225.775 F1000
G1 X30.171 Y225.492 F1000
G1 X31.053 Y225.236 F1000
G1 X31.942 Y225.004 F1000
G1 X32.837 Y224.792 F1000
G1 X33.735 Y224.599 F1000
G1 X34.637 Y224.423 F1000
G1 X35.542 Y224.262 F1000
G1 X36.449 Y224.115 F1000
G1 X37.358 Y223.981 F1000
G1 X38.269 Y223.858 F1000
G1 X39.181 Y223.745 F1000
G1 X40.094 Y223.642 F1000
G1 X41.009 Y223.547 F1000
G1 X41.924 Y223.461 F1000
G1 X42.839 Y223.382 F1000
G1 X43.755 Y223.31 F1000
G1 X44.672 Y223.244 F1000
G1 X45.589 Y223.184 F1000
G1 X46.506 Y223.129 F1000
G1 X47.424 Y223.079 F1000
G1 X48.342 Y223.033 F1000
G1 X49.26 Y222.992 F1000
G1 X50.178 Y222.954 F1000
G1 X51.097 Y222.92 F1000
G1 X52.015 Y222.889 F1000
G1 X52.934 Y222.861 F1000
G1 X53.852 Y222.836 F1000
G1 X54.771 Y222.813 F1000
G1 X55.69 Y222.792 F1000
G1 X56.609 Y222.773 F1000
G1 X57.528 Y222.755 F1000
G1 X58.447 Y222.739 F1000
G1 X60.284 Y222.71 F1000
G1 X63.041 Y222.672 F1000
G1 X65.798 Y222.633 F1000
G1 X67.636 Y222.605 F1000
G1 X68.555 Y222.589 F1000
G1 X69.474 Y222.572 F1000
G1 X70.392 Y222.554 F1000
G1 X71.311 Y222.533 F1000
G1 X72.23 Y222.511 F1000
G1 X73.149 Y222.487 F1000
G1 X74.067 Y222.461 F1000
G1 X74.986 Y222.432 F1000
G1 X75.904 Y222.401 F1000
G1 X76.823 Y222.368 F1000
G1 X77.741 Y222.332 F1000
G1 X78.659 Y222.293 F1000
G1 X79.577 Y222.253 F1000
G1 X80.495 Y222.21 F1000
G1 X81.413 Y222.164 F1000
G1 X82.331 Y222.117 F1000
G1 X83.249 Y222.068 F1000
G1 X84.166 Y222.016 F1000
G1 X85.084 Y221.964 F1000
G1 X86.001 Y221.909 F1000
G1 X86.919 Y221.854 F1000
G1 X88.753 Y221.739 F1000
G1 X92.422 Y221.504 F1000
G1 X95.173 Y221.329 F1000
G1 X97.008 Y221.215 F1000
G1 X97.925 Y221.16 F1000
G1 X98.842 Y221.105 F1000
G1 X99.76 Y221.052 F1000
G1 X100.677 Y221 F1000
G1 X101.595 Y220.95 F1000
G1 X102.513 Y220.901 F1000
G1 X103.431 Y220.853 F1000
G1 X104.348 Y220.808 F1000
G1 X105.266 Y220.764 F1000
G1 X106.184 Y220.721 F1000
G1 X107.103 Y220.68 F1000
G1 X108.021 Y220.641 F1000
G1 X108.939 Y220.604 F1000
G1 X109.857 Y220.569 F1000
G1 X110.776 Y220.535 F1000
G1 X111.694 Y220.503 F1000
G1 X112.613 Y220.473 F1000
G1 X113.531 Y220.444 F1000
G1 X114.45 Y220.417 F1000
G1 X115.369 Y220.392 F1000
G1 X116.287 Y220.368 F1000
G1 X117.206 Y220.346 F1000
G1 X118.125 Y220.325 F1000
G1 X119.044 Y220.305 F1000
G1 X119.963 Y220.287 F1000
G1 X120.881 Y220.27 F1000
G1 X121.8 Y220.254 F1000
G1 X122.719 Y220.239 F1000
G1 X123.638 Y220.226 F1000
G1 X125.476 Y220.202 F1000
G1 X127.314 Y220.182 F1000
G1 X129.152 Y220.165 F1000
G1 X130.99 Y220.151 F1000
G1 X132.828 Y220.14 F1000
G1 X134.666 Y220.131 F1000
G1 X136.504 Y220.124 F1000
G1 X138.342 Y220.12 F1000
G1 X140.18 Y220.118 F1000
G1 X142.018 Y220.119 F1000
G1 X143.856 Y220.124 F1000
G1 X144.775 Y220.127 F1000
G1 X145.694 Y220.132 F1000
G1 X146.613 Y220.138 F1000
G1 X147.532 Y220.146 F1000
G1 X148.451 Y220.155 F1000
G1 X149.37 Y220.166 F1000
G1 X150.289 Y220.179 F1000
G1 X151.208 Y220.194 F1000
G1 X152.127 Y220.212 F1000
G1 X153.045 Y220.232 F1000
G1 X153.964 Y220.256 F1000
G1 X154.883 Y220.282 F1000
G1 X155.801 Y220.313 F1000
G1 X156.72 Y220.347 F1000
G1 X157.638 Y220.386 F1000
G1 X158.556 Y220.43 F1000
G1 X159.474 Y220.479 F1000
G1 X160.391 Y220.534 F1000
G1 X161.308 Y220.596 F1000
G1 X162.224 Y220.665 F1000
G1 X163.14 Y220.742 F1000
G1 X164.055 Y220.828 F1000
G1 X164.969 Y220.924 F1000
G1 X165.882 Y221.032 F1000
G1 X166.793 Y221.153 F1000
G1 X167.702 Y221.289 F1000
G1 X168.608 Y221.443 F1000
G1 X169.51 Y221.619 F1000
G1 X170.406 Y221.821 F1000
G1 X171.294 Y222.057 F1000
G1 X172.103 Y222.321 F1000
G1 X172.651 Y222.549 F1000
G1 X172.933 Y222.694 F1000
G1 X173.203 Y222.873 F1000
G1 X173.427 Y223.106 F1000
G1 X173.596 Y223.383 F1000
G1 X173.701 Y223.69 F1000
G1 X173.736 Y224.011 F1000
G1 Y226.524 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y227.108 I-0.635 J-0.022 F1000
G1 X173.221 Y227.129 Z-3.012 F1000
G1 X173.153 Y227.15 Z-3 F1000
G1 X173.088 Y227.17 Z-2.98 F1000
G1 X173.025 Y227.189 Z-2.953 F1000
G1 X172.966 Y227.208 Z-2.919 F1000
G1 X172.91 Y227.225 Z-2.877 F1000
G1 X172.859 Y227.241 Z-2.83 F1000
G1 X172.814 Y227.255 Z-2.777 F1000
G1 X172.775 Y227.267 Z-2.719 F1000
G1 X172.742 Y227.277 Z-2.657 F1000
G1 X172.716 Y227.285 Z-2.591 F1000
G1 X172.697 Y227.291 Z-2.522 F1000
G1 X172.685 Y227.294 Z-2.452 F1000
G1 X172.682 Y227.295 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y233.655 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y233.651 Z-2.452 F1000
G1 X22.509 Y233.641 Z-2.522 F1000
G1 X22.499 Y233.624 Z-2.591 F1000
G1 X22.485 Y233.601 Z-2.657 F1000
G1 X22.467 Y233.571 Z-2.719 F1000
G1 X22.446 Y233.536 Z-2.777 F1000
G1 X22.422 Y233.495 Z-2.83 F1000
G1 X22.395 Y233.449 Z-2.877 F1000
G1 X22.365 Y233.399 Z-2.919 F1000
G1 X22.333 Y233.346 Z-2.953 F1000
G1 X22.3 Y233.289 Z-2.98 F1000
G1 X22.265 Y233.231 Z-3 F1000
G1 X22.229 Y233.17 Z-3.012 F1000
G1 X22.192 Y233.109 Z-3.016 F1000
G3 X21.971 Y232.355 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y229.849 F1000
G1 X21.986 Y229.56 F1000
G1 X22.017 Y229.318 F1000
G1 X22.079 Y229.029 F1000
G1 X22.167 Y228.735 F1000
G1 X22.297 Y228.401 F1000
G1 X22.477 Y228.03 F1000
G1 X22.7 Y227.651 F1000
G1 X23.001 Y227.223 F1000
G1 X23.368 Y226.78 F1000
G1 X23.833 Y226.304 F1000
G1 X24.423 Y225.789 F1000
G1 X25.161 Y225.243 F1000
G1 X25.941 Y224.758 F1000
G1 X26.752 Y224.325 F1000
G1 X27.585 Y223.937 F1000
G1 X28.436 Y223.589 F1000
G1 X29.3 Y223.275 F1000
G1 X30.174 Y222.992 F1000
G1 X31.057 Y222.735 F1000
G1 X31.945 Y222.502 F1000
G1 X32.84 Y222.29 F1000
G1 X33.738 Y222.096 F1000
G1 X34.64 Y221.919 F1000
G1 X35.544 Y221.757 F1000
G1 X36.451 Y221.609 F1000
G1 X37.36 Y221.473 F1000
G1 X38.271 Y221.348 F1000
G1 X39.183 Y221.234 F1000
G1 X40.096 Y221.13 F1000
G1 X41.01 Y221.034 F1000
G1 X41.925 Y220.947 F1000
G1 X42.84 Y220.866 F1000
G1 X43.756 Y220.793 F1000
G1 X44.673 Y220.726 F1000
G1 X45.59 Y220.664 F1000
G1 X46.507 Y220.608 F1000
G1 X47.425 Y220.557 F1000
G1 X48.343 Y220.511 F1000
G1 X49.261 Y220.468 F1000
G1 X50.179 Y220.43 F1000
G1 X51.097 Y220.394 F1000
G1 X52.016 Y220.362 F1000
G1 X52.934 Y220.333 F1000
G1 X53.853 Y220.307 F1000
G1 X54.772 Y220.283 F1000
G1 X55.69 Y220.261 F1000
G1 X56.609 Y220.241 F1000
G1 X57.528 Y220.222 F1000
G1 X58.447 Y220.205 F1000
G1 X60.285 Y220.175 F1000
G1 X63.041 Y220.133 F1000
G1 X65.798 Y220.092 F1000
G1 X67.636 Y220.062 F1000
G1 X68.555 Y220.045 F1000
G1 X69.474 Y220.027 F1000
G1 X70.392 Y220.008 F1000
G1 X71.311 Y219.986 F1000
G1 X72.23 Y219.963 F1000
G1 X73.149 Y219.938 F1000
G1 X74.067 Y219.911 F1000
G1 X74.986 Y219.882 F1000
G1 X75.904 Y219.85 F1000
G1 X76.823 Y219.816 F1000
G1 X77.741 Y219.78 F1000
G1 X78.659 Y219.741 F1000
G1 X79.577 Y219.7 F1000
G1 X80.495 Y219.657 F1000
G1 X81.413 Y219.612 F1000
G1 X82.331 Y219.565 F1000
G1 X83.249 Y219.515 F1000
G1 X84.166 Y219.465 F1000
G1 X85.084 Y219.412 F1000
G1 X86.001 Y219.358 F1000
G1 X87.836 Y219.247 F1000
G1 X89.67 Y219.133 F1000
G1 X94.256 Y218.843 F1000
G1 X96.091 Y218.729 F1000
G1 X97.926 Y218.619 F1000
G1 X98.843 Y218.565 F1000
G1 X99.761 Y218.512 F1000
G1 X100.678 Y218.461 F1000
G1 X101.596 Y218.411 F1000
G1 X102.514 Y218.363 F1000
G1 X103.431 Y218.316 F1000
G1 X104.349 Y218.271 F1000
G1 X105.267 Y218.227 F1000
G1 X106.185 Y218.185 F1000
G1 X107.103 Y218.145 F1000
G1 X108.022 Y218.106 F1000
G1 X108.94 Y218.069 F1000
G1 X109.858 Y218.034 F1000
G1 X110.777 Y218.001 F1000
G1 X111.695 Y217.969 F1000
G1 X112.614 Y217.939 F1000
G1 X113.532 Y217.91 F1000
G1 X114.451 Y217.883 F1000
G1 X115.37 Y217.857 F1000
G1 X116.288 Y217.834 F1000
G1 X117.207 Y217.811 F1000
G1 X118.126 Y217.79 F1000
G1 X119.045 Y217.77 F1000
G1 X119.963 Y217.752 F1000
G1 X120.882 Y217.735 F1000
G1 X121.801 Y217.719 F1000
G1 X122.72 Y217.704 F1000
G1 X123.639 Y217.69 F1000
G1 X125.477 Y217.666 F1000
G1 X127.315 Y217.646 F1000
G1 X129.153 Y217.628 F1000
G1 X130.991 Y217.614 F1000
G1 X132.829 Y217.602 F1000
G1 X134.667 Y217.593 F1000
G1 X136.505 Y217.587 F1000
G1 X138.343 Y217.582 F1000
G1 X140.181 Y217.581 F1000
G1 X142.019 Y217.582 F1000
G1 X143.857 Y217.587 F1000
G1 X144.776 Y217.591 F1000
G1 X145.695 Y217.597 F1000
G1 X146.614 Y217.603 F1000
G1 X147.533 Y217.611 F1000
G1 X148.452 Y217.621 F1000
G1 X149.371 Y217.633 F1000
G1 X150.29 Y217.646 F1000
G1 X151.209 Y217.662 F1000
G1 X152.128 Y217.681 F1000
G1 X153.046 Y217.702 F1000
G1 X153.965 Y217.726 F1000
G1 X154.884 Y217.754 F1000
G1 X155.802 Y217.785 F1000
G1 X156.72 Y217.821 F1000
G1 X157.639 Y217.861 F1000
G1 X158.557 Y217.905 F1000
G1 X159.474 Y217.956 F1000
G1 X160.391 Y218.012 F1000
G1 X161.308 Y218.074 F1000
G1 X162.225 Y218.144 F1000
G1 X163.14 Y218.222 F1000
G1 X164.055 Y218.309 F1000
G1 X164.969 Y218.406 F1000
G1 X165.882 Y218.515 F1000
G1 X166.793 Y218.637 F1000
G1 X167.701 Y218.774 F1000
G1 X168.607 Y218.928 F1000
G1 X169.509 Y219.105 F1000
G1 X170.406 Y219.307 F1000
G1 X171.294 Y219.544 F1000
G1 X172.103 Y219.808 F1000
G1 X172.652 Y220.037 F1000
G1 X172.933 Y220.182 F1000
G1 X173.203 Y220.361 F1000
G1 X173.428 Y220.594 F1000
G1 X173.596 Y220.87 F1000
G1 X173.701 Y221.177 F1000
G1 X173.736 Y221.499 F1000
G1 Y224.011 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y224.596 I-0.635 J-0.022 F1000
G1 X173.221 Y224.617 Z-3.012 F1000
G1 X173.153 Y224.638 Z-3 F1000
G1 X173.088 Y224.658 Z-2.98 F1000
G1 X173.025 Y224.677 Z-2.953 F1000
G1 X172.966 Y224.696 Z-2.919 F1000
G1 X172.91 Y224.713 Z-2.877 F1000
G1 X172.859 Y224.728 Z-2.83 F1000
G1 X172.814 Y224.742 Z-2.777 F1000
G1 X172.775 Y224.755 Z-2.719 F1000
G1 X172.742 Y224.765 Z-2.657 F1000
G1 X172.716 Y224.773 Z-2.591 F1000
G1 X172.697 Y224.779 Z-2.522 F1000
G1 X172.685 Y224.782 Z-2.452 F1000
G1 X172.682 Y224.783 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y231.149 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y231.145 Z-2.452 F1000
G1 X22.509 Y231.135 Z-2.522 F1000
G1 X22.499 Y231.118 Z-2.591 F1000
G1 X22.485 Y231.095 Z-2.657 F1000
G1 X22.467 Y231.065 Z-2.719 F1000
G1 X22.446 Y231.03 Z-2.777 F1000
G1 X22.422 Y230.989 Z-2.83 F1000
G1 X22.395 Y230.943 Z-2.877 F1000
G1 X22.365 Y230.893 Z-2.919 F1000
G1 X22.333 Y230.84 Z-2.953 F1000
G1 X22.3 Y230.783 Z-2.98 F1000
G1 X22.265 Y230.724 Z-3 F1000
G1 X22.229 Y230.664 Z-3.012 F1000
G1 X22.192 Y230.603 Z-3.016 F1000
G3 X21.971 Y229.849 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y227.343 F1000
G1 X21.985 Y227.066 F1000
G1 X22.017 Y226.824 F1000
G1 X22.078 Y226.536 F1000
G1 X22.167 Y226.241 F1000
G1 X22.297 Y225.907 F1000
G1 X22.477 Y225.535 F1000
G1 X22.7 Y225.156 F1000
G1 X23.001 Y224.727 F1000
G1 X23.369 Y224.284 F1000
G1 X23.834 Y223.807 F1000
G1 X24.426 Y223.291 F1000
G1 X25.165 Y222.745 F1000
G1 X25.945 Y222.259 F1000
G1 X26.756 Y221.826 F1000
G1 X27.589 Y221.438 F1000
G1 X28.439 Y221.09 F1000
G1 X29.303 Y220.776 F1000
G1 X30.177 Y220.492 F1000
G1 X31.059 Y220.234 F1000
G1 X31.948 Y220 F1000
G1 X32.842 Y219.786 F1000
G1 X33.74 Y219.592 F1000
G1 X34.641 Y219.414 F1000
G1 X35.546 Y219.251 F1000
G1 X36.453 Y219.101 F1000
G1 X37.361 Y218.964 F1000
G1 X38.272 Y218.839 F1000
G1 X39.184 Y218.724 F1000
G1 X40.096 Y218.618 F1000
G1 X41.01 Y218.521 F1000
G1 X41.925 Y218.432 F1000
G1 X42.84 Y218.351 F1000
G1 X43.756 Y218.276 F1000
G1 X44.673 Y218.208 F1000
G1 X45.59 Y218.145 F1000
G1 X46.507 Y218.088 F1000
G1 X47.425 Y218.036 F1000
G1 X48.342 Y217.988 F1000
G1 X49.26 Y217.944 F1000
G1 X50.178 Y217.905 F1000
G1 X51.097 Y217.869 F1000
G1 X52.015 Y217.836 F1000
G1 X52.934 Y217.805 F1000
G1 X53.852 Y217.778 F1000
G1 X54.771 Y217.753 F1000
G1 X55.69 Y217.73 F1000
G1 X56.609 Y217.709 F1000
G1 X57.527 Y217.69 F1000
G1 X58.446 Y217.672 F1000
G1 X60.284 Y217.639 F1000
G1 X63.96 Y217.581 F1000
G1 X65.797 Y217.551 F1000
G1 X67.635 Y217.519 F1000
G1 X68.554 Y217.501 F1000
G1 X69.473 Y217.482 F1000
G1 X70.392 Y217.462 F1000
G1 X71.31 Y217.439 F1000
G1 X72.229 Y217.416 F1000
G1 X73.148 Y217.39 F1000
G1 X74.066 Y217.362 F1000
G1 X74.985 Y217.332 F1000
G1 X75.903 Y217.3 F1000
G1 X76.822 Y217.265 F1000
G1 X77.74 Y217.228 F1000
G1 X78.658 Y217.19 F1000
G1 X79.576 Y217.148 F1000
G1 X80.494 Y217.105 F1000
G1 X81.412 Y217.06 F1000
G1 X82.33 Y217.013 F1000
G1 X83.248 Y216.964 F1000
G1 X84.165 Y216.913 F1000
G1 X85.083 Y216.861 F1000
G1 X86 Y216.808 F1000
G1 X87.835 Y216.698 F1000
G1 X90.587 Y216.527 F1000
G1 X94.256 Y216.299 F1000
G1 X96.09 Y216.186 F1000
G1 X97.925 Y216.078 F1000
G1 X98.843 Y216.025 F1000
G1 X99.76 Y215.973 F1000
G1 X100.678 Y215.922 F1000
G1 X101.596 Y215.873 F1000
G1 X102.513 Y215.825 F1000
G1 X103.431 Y215.779 F1000
G1 X104.349 Y215.734 F1000
G1 X105.267 Y215.691 F1000
G1 X106.185 Y215.649 F1000
G1 X107.103 Y215.609 F1000
G1 X108.022 Y215.571 F1000
G1 X108.94 Y215.534 F1000
G1 X109.858 Y215.499 F1000
G1 X110.777 Y215.466 F1000
G1 X111.695 Y215.434 F1000
G1 X112.614 Y215.404 F1000
G1 X113.532 Y215.375 F1000
G1 X114.451 Y215.348 F1000
G1 X115.37 Y215.323 F1000
G1 X116.288 Y215.299 F1000
G1 X117.207 Y215.276 F1000
G1 X118.126 Y215.255 F1000
G1 X119.045 Y215.236 F1000
G1 X119.963 Y215.217 F1000
G1 X120.882 Y215.2 F1000
G1 X121.801 Y215.184 F1000
G1 X122.72 Y215.169 F1000
G1 X123.639 Y215.155 F1000
G1 X125.477 Y215.13 F1000
G1 X127.315 Y215.109 F1000
G1 X129.153 Y215.092 F1000
G1 X130.991 Y215.077 F1000
G1 X132.829 Y215.065 F1000
G1 X134.667 Y215.056 F1000
G1 X136.505 Y215.049 F1000
G1 X138.343 Y215.045 F1000
G1 X140.181 Y215.044 F1000
G1 X142.019 Y215.046 F1000
G1 X142.938 Y215.048 F1000
G1 X143.857 Y215.051 F1000
G1 X144.776 Y215.056 F1000
G1 X145.695 Y215.061 F1000
G1 X146.614 Y215.068 F1000
G1 X147.533 Y215.077 F1000
G1 X148.452 Y215.087 F1000
G1 X149.371 Y215.1 F1000
G1 X150.29 Y215.114 F1000
G1 X151.209 Y215.131 F1000
G1 X152.127 Y215.15 F1000
G1 X153.046 Y215.172 F1000
G1 X153.965 Y215.197 F1000
G1 X154.883 Y215.226 F1000
G1 X155.802 Y215.258 F1000
G1 X156.72 Y215.294 F1000
G1 X157.638 Y215.335 F1000
G1 X158.556 Y215.381 F1000
G1 X159.474 Y215.432 F1000
G1 X160.391 Y215.489 F1000
G1 X161.308 Y215.552 F1000
G1 X162.224 Y215.623 F1000
G1 X163.14 Y215.702 F1000
G1 X164.055 Y215.79 F1000
G1 X164.968 Y215.888 F1000
G1 X165.881 Y215.997 F1000
G1 X166.792 Y216.12 F1000
G1 X167.7 Y216.257 F1000
G1 X168.606 Y216.413 F1000
G1 X169.508 Y216.59 F1000
G1 X170.404 Y216.792 F1000
G1 X171.292 Y217.029 F1000
G1 X172.103 Y217.294 F1000
G1 X172.652 Y217.523 F1000
G1 X172.933 Y217.668 F1000
G1 X173.203 Y217.847 F1000
G1 X173.428 Y218.08 F1000
G1 X173.596 Y218.357 F1000
G1 X173.701 Y218.663 F1000
G1 X173.736 Y218.985 F1000
G1 Y221.499 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y222.083 I-0.635 J-0.022 F1000
G1 X173.221 Y222.104 Z-3.012 F1000
G1 X173.153 Y222.125 Z-3 F1000
G1 X173.088 Y222.145 Z-2.98 F1000
G1 X173.025 Y222.164 Z-2.953 F1000
G1 X172.966 Y222.183 Z-2.919 F1000
G1 X172.91 Y222.2 Z-2.877 F1000
G1 X172.859 Y222.216 Z-2.83 F1000
G1 X172.814 Y222.23 Z-2.777 F1000
G1 X172.775 Y222.242 Z-2.719 F1000
G1 X172.742 Y222.252 Z-2.657 F1000
G1 X172.716 Y222.26 Z-2.591 F1000
G1 X172.697 Y222.266 Z-2.522 F1000
G1 X172.685 Y222.269 Z-2.452 F1000
G1 X172.682 Y222.27 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y228.643 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y228.639 Z-2.452 F1000
G1 X22.509 Y228.629 Z-2.522 F1000
G1 X22.499 Y228.612 Z-2.591 F1000
G1 X22.485 Y228.589 Z-2.657 F1000
G1 X22.467 Y228.559 Z-2.719 F1000
G1 X22.446 Y228.524 Z-2.777 F1000
G1 X22.422 Y228.483 Z-2.83 F1000
G1 X22.395 Y228.437 Z-2.877 F1000
G1 X22.365 Y228.387 Z-2.919 F1000
G1 X22.333 Y228.334 Z-2.953 F1000
G1 X22.3 Y228.277 Z-2.98 F1000
G1 X22.265 Y228.218 Z-3 F1000
G1 X22.229 Y228.158 Z-3.012 F1000
G1 X22.192 Y228.097 Z-3.016 F1000
G3 X21.971 Y227.343 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y224.837 F1000
G1 X21.984 Y224.572 F1000
G1 X22.016 Y224.329 F1000
G1 X22.078 Y224.041 F1000
G1 X22.166 Y223.745 F1000
G1 X22.296 Y223.411 F1000
G1 X22.477 Y223.039 F1000
G1 X22.7 Y222.66 F1000
G1 X23.002 Y222.231 F1000
G1 X23.37 Y221.787 F1000
G1 X23.836 Y221.31 F1000
G1 X24.428 Y220.793 F1000
G1 X25.167 Y220.246 F1000
G1 X25.947 Y219.76 F1000
G1 X26.758 Y219.327 F1000
G1 X27.591 Y218.939 F1000
G1 X28.441 Y218.59 F1000
G1 X29.304 Y218.275 F1000
G1 X30.178 Y217.99 F1000
G1 X31.06 Y217.732 F1000
G1 X31.949 Y217.497 F1000
G1 X32.842 Y217.283 F1000
G1 X33.74 Y217.087 F1000
G1 X34.642 Y216.908 F1000
G1 X35.546 Y216.744 F1000
G1 X36.452 Y216.594 F1000
G1 X37.361 Y216.456 F1000
G1 X38.271 Y216.329 F1000
G1 X39.183 Y216.213 F1000
G1 X40.096 Y216.106 F1000
G1 X41.01 Y216.008 F1000
G1 X41.924 Y215.918 F1000
G1 X42.839 Y215.835 F1000
G1 X43.755 Y215.759 F1000
G1 X44.672 Y215.69 F1000
G1 X45.589 Y215.626 F1000
G1 X46.506 Y215.568 F1000
G1 X47.423 Y215.514 F1000
G1 X48.341 Y215.465 F1000
G1 X49.259 Y215.421 F1000
G1 X50.177 Y215.38 F1000
G1 X51.095 Y215.343 F1000
G1 X52.014 Y215.309 F1000
G1 X52.932 Y215.278 F1000
G1 X53.851 Y215.249 F1000
G1 X54.769 Y215.223 F1000
G1 X55.688 Y215.199 F1000
G1 X56.607 Y215.177 F1000
G1 X57.526 Y215.157 F1000
G1 X58.444 Y215.138 F1000
G1 X60.282 Y215.104 F1000
G1 X65.795 Y215.01 F1000
G1 X67.633 Y214.975 F1000
G1 X68.552 Y214.957 F1000
G1 X69.471 Y214.937 F1000
G1 X70.39 Y214.916 F1000
G1 X71.308 Y214.893 F1000
G1 X72.227 Y214.868 F1000
G1 X73.146 Y214.841 F1000
G1 X74.064 Y214.813 F1000
G1 X74.983 Y214.782 F1000
G1 X75.901 Y214.749 F1000
G1 X76.819 Y214.714 F1000
G1 X77.738 Y214.677 F1000
G1 X78.656 Y214.638 F1000
G1 X79.574 Y214.597 F1000
G1 X80.492 Y214.554 F1000
G1 X81.41 Y214.508 F1000
G1 X82.328 Y214.461 F1000
G1 X83.245 Y214.413 F1000
G1 X84.163 Y214.362 F1000
G1 X85.081 Y214.311 F1000
G1 X85.998 Y214.258 F1000
G1 X87.833 Y214.149 F1000
G1 X90.585 Y213.98 F1000
G1 X94.254 Y213.755 F1000
G1 X96.089 Y213.644 F1000
G1 X97.924 Y213.537 F1000
G1 X98.841 Y213.484 F1000
G1 X99.759 Y213.433 F1000
G1 X100.676 Y213.383 F1000
G1 X101.594 Y213.335 F1000
G1 X102.512 Y213.287 F1000
G1 X103.43 Y213.242 F1000
G1 X104.348 Y213.197 F1000
G1 X105.266 Y213.154 F1000
G1 X106.184 Y213.113 F1000
G1 X107.102 Y213.074 F1000
G1 X108.02 Y213.036 F1000
G1 X108.939 Y212.999 F1000
G1 X109.857 Y212.964 F1000
G1 X110.775 Y212.931 F1000
G1 X111.694 Y212.899 F1000
G1 X112.612 Y212.869 F1000
G1 X113.531 Y212.841 F1000
G1 X114.45 Y212.814 F1000
G1 X115.368 Y212.788 F1000
G1 X116.287 Y212.764 F1000
G1 X117.206 Y212.742 F1000
G1 X118.125 Y212.721 F1000
G1 X119.043 Y212.701 F1000
G1 X119.962 Y212.682 F1000
G1 X120.881 Y212.665 F1000
G1 X121.8 Y212.648 F1000
G1 X122.719 Y212.633 F1000
G1 X123.638 Y212.619 F1000
G1 X125.476 Y212.594 F1000
G1 X127.313 Y212.573 F1000
G1 X129.151 Y212.555 F1000
G1 X130.989 Y212.54 F1000
G1 X132.827 Y212.528 F1000
G1 X134.665 Y212.519 F1000
G1 X136.503 Y212.512 F1000
G1 X138.341 Y212.508 F1000
G1 X140.18 Y212.507 F1000
G1 X142.018 Y212.509 F1000
G1 X142.937 Y212.512 F1000
G1 X143.856 Y212.515 F1000
G1 X144.775 Y212.52 F1000
G1 X145.694 Y212.526 F1000
G1 X146.613 Y212.534 F1000
G1 X147.532 Y212.543 F1000
G1 X148.451 Y212.554 F1000
G1 X149.369 Y212.567 F1000
G1 X150.288 Y212.582 F1000
G1 X151.207 Y212.599 F1000
G1 X152.126 Y212.619 F1000
G1 X153.045 Y212.642 F1000
G1 X153.963 Y212.668 F1000
G1 X154.882 Y212.697 F1000
G1 X155.8 Y212.73 F1000
G1 X156.719 Y212.768 F1000
G1 X157.637 Y212.809 F1000
G1 X158.555 Y212.856 F1000
G1 X159.472 Y212.908 F1000
G1 X160.389 Y212.966 F1000
G1 X161.306 Y213.03 F1000
G1 X162.222 Y213.102 F1000
G1 X163.138 Y213.182 F1000
G1 X164.053 Y213.27 F1000
G1 X164.966 Y213.369 F1000
G1 X165.879 Y213.479 F1000
G1 X166.789 Y213.602 F1000
G1 X167.698 Y213.741 F1000
G1 X168.604 Y213.897 F1000
G1 X169.505 Y214.074 F1000
G1 X170.402 Y214.277 F1000
G1 X171.29 Y214.514 F1000
G1 X172.102 Y214.779 F1000
G1 X172.651 Y215.009 F1000
G1 X172.934 Y215.154 F1000
G1 X173.203 Y215.333 F1000
G1 X173.428 Y215.567 F1000
G1 X173.596 Y215.843 F1000
G1 X173.701 Y216.149 F1000
G1 X173.736 Y216.471 F1000
G1 Y218.985 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y219.57 I-0.635 J-0.022 F1000
G1 X173.221 Y219.591 Z-3.012 F1000
G1 X173.153 Y219.612 Z-3 F1000
G1 X173.088 Y219.632 Z-2.98 F1000
G1 X173.025 Y219.651 Z-2.953 F1000
G1 X172.966 Y219.669 Z-2.919 F1000
G1 X172.91 Y219.687 Z-2.877 F1000
G1 X172.859 Y219.702 Z-2.83 F1000
G1 X172.814 Y219.716 Z-2.777 F1000
G1 X172.775 Y219.728 Z-2.719 F1000
G1 X172.742 Y219.738 Z-2.657 F1000
G1 X172.716 Y219.746 Z-2.591 F1000
G1 X172.697 Y219.752 Z-2.522 F1000
G1 X172.685 Y219.756 Z-2.452 F1000
G1 X172.682 Y219.757 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y226.137 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y226.133 Z-2.452 F1000
G1 X22.509 Y226.123 Z-2.522 F1000
G1 X22.499 Y226.106 Z-2.591 F1000
G1 X22.485 Y226.083 Z-2.657 F1000
G1 X22.467 Y226.053 Z-2.719 F1000
G1 X22.446 Y226.018 Z-2.777 F1000
G1 X22.422 Y225.977 Z-2.83 F1000
G1 X22.395 Y225.931 Z-2.877 F1000
G1 X22.365 Y225.881 Z-2.919 F1000
G1 X22.333 Y225.828 Z-2.953 F1000
G1 X22.3 Y225.771 Z-2.98 F1000
G1 X22.265 Y225.712 Z-3 F1000
G1 X22.229 Y225.652 Z-3.012 F1000
G1 X22.192 Y225.591 Z-3.016 F1000
G3 X21.971 Y224.837 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y222.331 F1000
G1 X21.984 Y222.075 F1000
G1 X22.016 Y221.833 F1000
G1 X22.077 Y221.545 F1000
G1 X22.166 Y221.249 F1000
G1 X22.296 Y220.915 F1000
G1 X22.477 Y220.542 F1000
G1 X22.7 Y220.163 F1000
G1 X23.002 Y219.733 F1000
G1 X23.37 Y219.289 F1000
G1 X23.837 Y218.811 F1000
G1 X24.431 Y218.293 F1000
G1 X25.169 Y217.746 F1000
G1 X25.949 Y217.261 F1000
G1 X26.76 Y216.827 F1000
G1 X27.593 Y216.438 F1000
G1 X28.443 Y216.089 F1000
G1 X29.306 Y215.773 F1000
G1 X30.179 Y215.488 F1000
G1 X31.061 Y215.229 F1000
G1 X31.949 Y214.993 F1000
G1 X32.843 Y214.778 F1000
G1 X33.741 Y214.582 F1000
G1 X34.642 Y214.402 F1000
G1 X35.546 Y214.237 F1000
G1 X36.452 Y214.085 F1000
G1 X37.361 Y213.946 F1000
G1 X38.271 Y213.818 F1000
G1 X39.182 Y213.701 F1000
G1 X40.095 Y213.593 F1000
G1 X41.009 Y213.494 F1000
G1 X41.923 Y213.403 F1000
G1 X42.838 Y213.319 F1000
G1 X43.754 Y213.242 F1000
G1 X44.671 Y213.171 F1000
G1 X45.587 Y213.106 F1000
G1 X46.504 Y213.047 F1000
G1 X47.422 Y212.992 F1000
G1 X48.339 Y212.943 F1000
G1 X49.257 Y212.897 F1000
G1 X50.175 Y212.855 F1000
G1 X51.094 Y212.817 F1000
G1 X52.012 Y212.782 F1000
G1 X52.93 Y212.75 F1000
G1 X53.849 Y212.72 F1000
G1 X54.768 Y212.693 F1000
G1 X55.686 Y212.668 F1000
G1 X56.605 Y212.645 F1000
G1 X57.524 Y212.624 F1000
G1 X58.443 Y212.604 F1000
G1 X60.28 Y212.568 F1000
G1 X65.793 Y212.468 F1000
G1 X67.631 Y212.432 F1000
G1 X68.55 Y212.413 F1000
G1 X69.469 Y212.392 F1000
G1 X70.388 Y212.37 F1000
G1 X71.306 Y212.346 F1000
G1 X72.225 Y212.32 F1000
G1 X73.144 Y212.293 F1000
G1 X74.062 Y212.264 F1000
G1 X74.981 Y212.233 F1000
G1 X75.899 Y212.199 F1000
G1 X76.817 Y212.164 F1000
G1 X77.736 Y212.127 F1000
G1 X78.654 Y212.087 F1000
G1 X79.572 Y212.046 F1000
G1 X80.49 Y212.002 F1000
G1 X81.408 Y211.957 F1000
G1 X82.326 Y211.91 F1000
G1 X83.243 Y211.862 F1000
G1 X84.161 Y211.812 F1000
G1 X85.079 Y211.76 F1000
G1 X86.914 Y211.654 F1000
G1 X88.748 Y211.545 F1000
G1 X94.252 Y211.211 F1000
G1 X96.087 Y211.102 F1000
G1 X97.922 Y210.996 F1000
G1 X98.84 Y210.944 F1000
G1 X99.757 Y210.894 F1000
G1 X100.675 Y210.844 F1000
G1 X101.593 Y210.796 F1000
G1 X102.511 Y210.75 F1000
G1 X103.428 Y210.704 F1000
G1 X104.346 Y210.66 F1000
G1 X105.264 Y210.618 F1000
G1 X106.183 Y210.577 F1000
G1 X107.101 Y210.538 F1000
G1 X108.019 Y210.5 F1000
G1 X108.937 Y210.464 F1000
G1 X109.856 Y210.429 F1000
G1 X110.774 Y210.396 F1000
G1 X111.693 Y210.365 F1000
G1 X112.611 Y210.335 F1000
G1 X113.53 Y210.306 F1000
G1 X114.448 Y210.279 F1000
G1 X115.367 Y210.254 F1000
G1 X116.286 Y210.23 F1000
G1 X117.204 Y210.207 F1000
G1 X118.123 Y210.186 F1000
G1 X119.042 Y210.166 F1000
G1 X119.961 Y210.147 F1000
G1 X120.88 Y210.129 F1000
G1 X121.799 Y210.113 F1000
G1 X122.717 Y210.098 F1000
G1 X123.636 Y210.084 F1000
G1 X125.474 Y210.058 F1000
G1 X127.312 Y210.037 F1000
G1 X129.15 Y210.018 F1000
G1 X130.988 Y210.003 F1000
G1 X132.826 Y209.991 F1000
G1 X134.664 Y209.982 F1000
G1 X136.502 Y209.975 F1000
G1 X138.34 Y209.971 F1000
G1 X140.178 Y209.97 F1000
G1 X142.016 Y209.973 F1000
G1 X142.935 Y209.976 F1000
G1 X143.854 Y209.98 F1000
G1 X144.773 Y209.985 F1000
G1 X145.692 Y209.991 F1000
G1 X146.611 Y209.999 F1000
G1 X147.53 Y210.009 F1000
G1 X148.449 Y210.021 F1000
G1 X149.368 Y210.034 F1000
G1 X150.287 Y210.05 F1000
G1 X151.206 Y210.068 F1000
G1 X152.125 Y210.089 F1000
G1 X153.043 Y210.112 F1000
G1 X153.962 Y210.139 F1000
G1 X154.88 Y210.169 F1000
G1 X155.799 Y210.203 F1000
G1 X156.717 Y210.241 F1000
G1 X157.635 Y210.284 F1000
G1 X158.553 Y210.331 F1000
G1 X159.47 Y210.384 F1000
G1 X160.388 Y210.443 F1000
G1 X161.304 Y210.508 F1000
G1 X162.22 Y210.58 F1000
G1 X163.136 Y210.661 F1000
G1 X164.051 Y210.75 F1000
G1 X164.964 Y210.85 F1000
G1 X165.877 Y210.961 F1000
G1 X166.787 Y211.084 F1000
G1 X167.696 Y211.223 F1000
G1 X168.601 Y211.38 F1000
G1 X169.503 Y211.557 F1000
G1 X170.399 Y211.761 F1000
G1 X171.287 Y211.998 F1000
G1 X172.101 Y212.264 F1000
G1 X172.651 Y212.494 F1000
G1 X172.934 Y212.64 F1000
G1 X173.203 Y212.819 F1000
G1 X173.428 Y213.052 F1000
G1 X173.596 Y213.328 F1000
G1 X173.701 Y213.635 F1000
G1 X173.736 Y213.957 F1000
G1 Y216.471 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y217.056 I-0.635 J-0.022 F1000
G1 X173.221 Y217.077 Z-3.012 F1000
G1 X173.153 Y217.097 Z-3 F1000
G1 X173.088 Y217.118 Z-2.98 F1000
G1 X173.025 Y217.137 Z-2.953 F1000
G1 X172.966 Y217.155 Z-2.919 F1000
G1 X172.91 Y217.172 Z-2.877 F1000
G1 X172.859 Y217.188 Z-2.83 F1000
G1 X172.814 Y217.202 Z-2.777 F1000
G1 X172.775 Y217.214 Z-2.719 F1000
G1 X172.742 Y217.224 Z-2.657 F1000
G1 X172.716 Y217.232 Z-2.591 F1000
G1 X172.697 Y217.238 Z-2.522 F1000
G1 X172.685 Y217.242 Z-2.452 F1000
G1 X172.682 Y217.243 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y223.631 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y223.627 Z-2.452 F1000
G1 X22.509 Y223.617 Z-2.522 F1000
G1 X22.499 Y223.6 Z-2.591 F1000
G1 X22.485 Y223.577 Z-2.657 F1000
G1 X22.467 Y223.547 Z-2.719 F1000
G1 X22.446 Y223.512 Z-2.777 F1000
G1 X22.422 Y223.471 Z-2.83 F1000
G1 X22.395 Y223.425 Z-2.877 F1000
G1 X22.365 Y223.375 Z-2.919 F1000
G1 X22.333 Y223.322 Z-2.953 F1000
G1 X22.3 Y223.265 Z-2.98 F1000
G1 X22.265 Y223.206 Z-3 F1000
G1 X22.229 Y223.146 Z-3.012 F1000
G1 X22.192 Y223.085 Z-3.016 F1000
G3 X21.971 Y222.331 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y219.825 F1000
G1 X21.983 Y219.578 F1000
G1 X22.015 Y219.336 F1000
G1 X22.077 Y219.047 F1000
G1 X22.166 Y218.751 F1000
G1 X22.296 Y218.417 F1000
G1 X22.477 Y218.044 F1000
G1 X22.7 Y217.664 F1000
G1 X23.002 Y217.234 F1000
G1 X23.371 Y216.79 F1000
G1 X23.839 Y216.311 F1000
G1 X24.433 Y215.792 F1000
G1 X25.172 Y215.246 F1000
G1 X25.952 Y214.76 F1000
G1 X26.762 Y214.326 F1000
G1 X27.594 Y213.937 F1000
G1 X28.444 Y213.587 F1000
G1 X29.307 Y213.271 F1000
G1 X30.181 Y212.985 F1000
G1 X31.062 Y212.725 F1000
G1 X31.95 Y212.489 F1000
G1 X32.844 Y212.273 F1000
G1 X33.741 Y212.075 F1000
G1 X34.642 Y211.895 F1000
G1 X35.546 Y211.729 F1000
G1 X36.452 Y211.576 F1000
G1 X37.361 Y211.436 F1000
G1 X38.271 Y211.307 F1000
G1 X39.182 Y211.189 F1000
G1 X40.094 Y211.08 F1000
G1 X41.008 Y210.98 F1000
G1 X41.922 Y210.887 F1000
G1 X42.837 Y210.803 F1000
G1 X43.753 Y210.724 F1000
G1 X44.669 Y210.653 F1000
G1 X45.586 Y210.587 F1000
G1 X46.503 Y210.526 F1000
G1 X47.42 Y210.471 F1000
G1 X48.338 Y210.42 F1000
G1 X49.256 Y210.373 F1000
G1 X50.174 Y210.33 F1000
G1 X51.092 Y210.291 F1000
G1 X52.01 Y210.255 F1000
G1 X52.929 Y210.222 F1000
G1 X53.847 Y210.191 F1000
G1 X54.766 Y210.163 F1000
G1 X55.685 Y210.138 F1000
G1 X56.603 Y210.114 F1000
G1 X57.522 Y210.091 F1000
G1 X58.441 Y210.071 F1000
G1 X60.278 Y210.032 F1000
G1 X65.792 Y209.927 F1000
G1 X67.629 Y209.889 F1000
G1 X68.548 Y209.868 F1000
G1 X69.467 Y209.847 F1000
G1 X70.385 Y209.824 F1000
G1 X71.304 Y209.799 F1000
G1 X72.223 Y209.773 F1000
G1 X73.141 Y209.745 F1000
G1 X74.06 Y209.715 F1000
G1 X74.978 Y209.683 F1000
G1 X75.897 Y209.65 F1000
G1 X76.815 Y209.614 F1000
G1 X77.733 Y209.576 F1000
G1 X78.652 Y209.537 F1000
G1 X79.57 Y209.495 F1000
G1 X80.488 Y209.452 F1000
G1 X81.406 Y209.407 F1000
G1 X82.323 Y209.36 F1000
G1 X83.241 Y209.311 F1000
G1 X84.159 Y209.262 F1000
G1 X85.076 Y209.211 F1000
G1 X86.911 Y209.106 F1000
G1 X88.746 Y208.997 F1000
G1 X94.251 Y208.667 F1000
G1 X96.085 Y208.56 F1000
G1 X97.92 Y208.455 F1000
G1 X98.838 Y208.404 F1000
G1 X99.756 Y208.354 F1000
G1 X100.673 Y208.305 F1000
G1 X101.591 Y208.258 F1000
G1 X102.509 Y208.212 F1000
G1 X103.427 Y208.167 F1000
G1 X104.345 Y208.123 F1000
G1 X105.263 Y208.081 F1000
G1 X106.181 Y208.041 F1000
G1 X107.099 Y208.002 F1000
G1 X108.018 Y207.964 F1000
G1 X108.936 Y207.928 F1000
G1 X109.854 Y207.894 F1000
G1 X110.773 Y207.861 F1000
G1 X111.691 Y207.83 F1000
G1 X112.61 Y207.8 F1000
G1 X113.528 Y207.771 F1000
G1 X114.447 Y207.744 F1000
G1 X115.366 Y207.719 F1000
G1 X116.284 Y207.695 F1000
G1 X117.203 Y207.672 F1000
G1 X118.122 Y207.651 F1000
G1 X119.041 Y207.631 F1000
G1 X119.96 Y207.612 F1000
G1 X120.878 Y207.594 F1000
G1 X121.797 Y207.578 F1000
G1 X122.716 Y207.562 F1000
G1 X123.635 Y207.548 F1000
G1 X125.473 Y207.522 F1000
G1 X127.311 Y207.5 F1000
G1 X129.149 Y207.482 F1000
G1 X130.987 Y207.466 F1000
G1 X132.825 Y207.454 F1000
G1 X134.663 Y207.444 F1000
G1 X136.501 Y207.438 F1000
G1 X138.339 Y207.434 F1000
G1 X140.177 Y207.433 F1000
G1 X142.015 Y207.437 F1000
G1 X142.934 Y207.44 F1000
G1 X143.853 Y207.444 F1000
G1 X144.772 Y207.45 F1000
G1 X145.691 Y207.457 F1000
G1 X146.61 Y207.465 F1000
G1 X147.529 Y207.475 F1000
G1 X148.448 Y207.487 F1000
G1 X149.367 Y207.502 F1000
G1 X150.286 Y207.518 F1000
G1 X151.204 Y207.537 F1000
G1 X152.123 Y207.558 F1000
G1 X153.042 Y207.582 F1000
G1 X153.961 Y207.61 F1000
G1 X154.879 Y207.641 F1000
G1 X155.797 Y207.675 F1000
G1 X156.716 Y207.714 F1000
G1 X157.634 Y207.758 F1000
G1 X158.551 Y207.806 F1000
G1 X159.469 Y207.86 F1000
G1 X160.386 Y207.919 F1000
G1 X161.303 Y207.985 F1000
G1 X162.219 Y208.059 F1000
G1 X163.134 Y208.14 F1000
G1 X164.049 Y208.23 F1000
G1 X164.962 Y208.33 F1000
G1 X165.874 Y208.442 F1000
G1 X166.785 Y208.566 F1000
G1 X167.693 Y208.706 F1000
G1 X168.599 Y208.863 F1000
G1 X169.5 Y209.041 F1000
G1 X170.397 Y209.244 F1000
G1 X171.284 Y209.482 F1000
G1 X172.1 Y209.748 F1000
G1 X172.65 Y209.979 F1000
G1 X172.934 Y210.125 F1000
G1 X173.203 Y210.304 F1000
G1 X173.428 Y210.537 F1000
G1 X173.596 Y210.813 F1000
G1 X173.701 Y211.12 F1000
G1 X173.736 Y211.441 F1000
G1 Y213.957 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y214.541 I-0.635 J-0.022 F1000
G1 X173.221 Y214.562 Z-3.012 F1000
G1 X173.153 Y214.583 Z-3 F1000
G1 X173.088 Y214.603 Z-2.98 F1000
G1 X173.025 Y214.622 Z-2.953 F1000
G1 X172.966 Y214.641 Z-2.919 F1000
G1 X172.91 Y214.658 Z-2.877 F1000
G1 X172.859 Y214.673 Z-2.83 F1000
G1 X172.814 Y214.687 Z-2.777 F1000
G1 X172.775 Y214.7 Z-2.719 F1000
G1 X172.742 Y214.71 Z-2.657 F1000
G1 X172.716 Y214.718 Z-2.591 F1000
G1 X172.697 Y214.724 Z-2.522 F1000
G1 X172.685 Y214.727 Z-2.452 F1000
G1 X172.682 Y214.728 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y221.125 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y221.121 Z-2.452 F1000
G1 X22.509 Y221.111 Z-2.522 F1000
G1 X22.499 Y221.094 Z-2.591 F1000
G1 X22.485 Y221.071 Z-2.657 F1000
G1 X22.467 Y221.041 Z-2.719 F1000
G1 X22.446 Y221.006 Z-2.777 F1000
G1 X22.422 Y220.965 Z-2.83 F1000
G1 X22.395 Y220.919 Z-2.877 F1000
G1 X22.365 Y220.869 Z-2.919 F1000
G1 X22.333 Y220.816 Z-2.953 F1000
G1 X22.3 Y220.759 Z-2.98 F1000
G1 X22.265 Y220.7 Z-3 F1000
G1 X22.229 Y220.64 Z-3.012 F1000
G1 X22.192 Y220.579 Z-3.016 F1000
G3 X21.971 Y219.825 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y217.319 F1000
G1 X21.983 Y217.08 F1000
G1 X22.015 Y216.837 F1000
G1 X22.076 Y216.549 F1000
G1 X22.165 Y216.252 F1000
G1 X22.295 Y215.918 F1000
G1 X22.477 Y215.545 F1000
G1 X22.7 Y215.165 F1000
G1 X23.003 Y214.734 F1000
G1 X23.372 Y214.29 F1000
G1 X23.84 Y213.81 F1000
G1 X24.435 Y213.291 F1000
G1 X25.174 Y212.744 F1000
G1 X25.954 Y212.258 F1000
G1 X26.764 Y211.824 F1000
G1 X27.596 Y211.434 F1000
G1 X28.446 Y211.084 F1000
G1 X29.309 Y210.768 F1000
G1 X30.182 Y210.481 F1000
G1 X31.063 Y210.221 F1000
G1 X31.951 Y209.983 F1000
G1 X32.844 Y209.767 F1000
G1 X33.742 Y209.569 F1000
G1 X34.642 Y209.387 F1000
G1 X35.546 Y209.22 F1000
G1 X36.452 Y209.067 F1000
G1 X37.36 Y208.926 F1000
G1 X38.27 Y208.796 F1000
G1 X39.182 Y208.676 F1000
G1 X40.094 Y208.566 F1000
G1 X41.007 Y208.465 F1000
G1 X41.922 Y208.372 F1000
G1 X42.837 Y208.286 F1000
G1 X43.752 Y208.207 F1000
G1 X44.668 Y208.134 F1000
G1 X45.585 Y208.067 F1000
G1 X46.502 Y208.005 F1000
G1 X47.419 Y207.949 F1000
G1 X48.337 Y207.897 F1000
G1 X49.254 Y207.849 F1000
G1 X50.172 Y207.805 F1000
G1 X51.091 Y207.765 F1000
G1 X52.009 Y207.728 F1000
G1 X52.927 Y207.694 F1000
G1 X53.846 Y207.662 F1000
G1 X54.764 Y207.633 F1000
G1 X55.683 Y207.607 F1000
G1 X56.602 Y207.582 F1000
G1 X57.52 Y207.559 F1000
G1 X58.439 Y207.537 F1000
G1 X60.277 Y207.497 F1000
G1 X65.79 Y207.385 F1000
G1 X67.627 Y207.346 F1000
G1 X68.546 Y207.324 F1000
G1 X69.465 Y207.302 F1000
G1 X70.384 Y207.278 F1000
G1 X71.302 Y207.253 F1000
G1 X72.221 Y207.226 F1000
G1 X73.139 Y207.197 F1000
G1 X74.058 Y207.167 F1000
G1 X74.976 Y207.134 F1000
G1 X75.895 Y207.1 F1000
G1 X76.813 Y207.064 F1000
G1 X77.731 Y207.026 F1000
G1 X78.649 Y206.986 F1000
G1 X79.568 Y206.945 F1000
G1 X80.486 Y206.901 F1000
G1 X81.403 Y206.856 F1000
G1 X82.321 Y206.809 F1000
G1 X83.239 Y206.761 F1000
G1 X84.157 Y206.712 F1000
G1 X85.074 Y206.661 F1000
G1 X86.909 Y206.557 F1000
G1 X88.744 Y206.45 F1000
G1 X94.249 Y206.124 F1000
G1 X96.084 Y206.018 F1000
G1 X97.919 Y205.914 F1000
G1 X98.837 Y205.864 F1000
G1 X99.754 Y205.815 F1000
G1 X100.672 Y205.766 F1000
G1 X101.59 Y205.719 F1000
G1 X102.508 Y205.674 F1000
G1 X103.426 Y205.629 F1000
G1 X104.344 Y205.586 F1000
G1 X105.262 Y205.545 F1000
G1 X106.18 Y205.504 F1000
G1 X107.098 Y205.466 F1000
G1 X108.016 Y205.428 F1000
G1 X108.935 Y205.393 F1000
G1 X109.853 Y205.358 F1000
G1 X110.772 Y205.326 F1000
G1 X111.69 Y205.294 F1000
G1 X112.609 Y205.265 F1000
G1 X113.527 Y205.236 F1000
G1 X114.446 Y205.209 F1000
G1 X115.364 Y205.184 F1000
G1 X116.283 Y205.16 F1000
G1 X117.202 Y205.137 F1000
G1 X118.121 Y205.116 F1000
G1 X119.039 Y205.096 F1000
G1 X119.958 Y205.077 F1000
G1 X120.877 Y205.059 F1000
G1 X121.796 Y205.042 F1000
G1 X122.715 Y205.027 F1000
G1 X124.553 Y204.999 F1000
G1 X126.391 Y204.975 F1000
G1 X128.229 Y204.954 F1000
G1 X130.066 Y204.937 F1000
G1 X131.904 Y204.923 F1000
G1 X133.742 Y204.912 F1000
G1 X135.58 Y204.904 F1000
G1 X137.419 Y204.899 F1000
G1 X139.257 Y204.897 F1000
G1 X141.095 Y204.898 F1000
G1 X142.014 Y204.901 F1000
G1 X142.933 Y204.904 F1000
G1 X143.852 Y204.909 F1000
G1 X144.771 Y204.915 F1000
G1 X145.69 Y204.922 F1000
G1 X146.609 Y204.931 F1000
G1 X147.528 Y204.942 F1000
G1 X148.446 Y204.954 F1000
G1 X149.365 Y204.969 F1000
G1 X150.284 Y204.986 F1000
G1 X151.203 Y205.005 F1000
G1 X152.122 Y205.027 F1000
G1 X153.041 Y205.052 F1000
G1 X153.959 Y205.081 F1000
G1 X154.878 Y205.112 F1000
G1 X155.796 Y205.148 F1000
G1 X156.714 Y205.188 F1000
G1 X157.632 Y205.232 F1000
G1 X158.55 Y205.281 F1000
G1 X159.467 Y205.335 F1000
G1 X160.384 Y205.396 F1000
G1 X161.301 Y205.463 F1000
G1 X162.217 Y205.537 F1000
G1 X163.132 Y205.619 F1000
G1 X164.047 Y205.709 F1000
G1 X164.96 Y205.81 F1000
G1 X165.872 Y205.922 F1000
G1 X166.783 Y206.048 F1000
G1 X167.691 Y206.188 F1000
G1 X168.596 Y206.345 F1000
G1 X169.498 Y206.523 F1000
G1 X170.394 Y206.727 F1000
G1 X171.282 Y206.965 F1000
G1 X172.099 Y207.232 F1000
G1 X172.65 Y207.463 F1000
G1 X172.934 Y207.609 F1000
G1 X173.204 Y207.788 F1000
G1 X173.428 Y208.021 F1000
G1 X173.596 Y208.298 F1000
G1 X173.701 Y208.604 F1000
G1 X173.736 Y208.926 F1000
G1 Y211.441 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y212.026 I-0.635 J-0.022 F1000
G1 X173.221 Y212.047 Z-3.012 F1000
G1 X173.153 Y212.068 Z-3 F1000
G1 X173.088 Y212.088 Z-2.98 F1000
G1 X173.025 Y212.107 Z-2.953 F1000
G1 X172.966 Y212.126 Z-2.919 F1000
G1 X172.91 Y212.143 Z-2.877 F1000
G1 X172.859 Y212.158 Z-2.83 F1000
G1 X172.814 Y212.172 Z-2.777 F1000
G1 X172.775 Y212.184 Z-2.719 F1000
G1 X172.742 Y212.195 Z-2.657 F1000
G1 X172.716 Y212.203 Z-2.591 F1000
G1 X172.697 Y212.208 Z-2.522 F1000
G1 X172.685 Y212.212 Z-2.452 F1000
G1 X172.682 Y212.213 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y218.619 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y218.615 Z-2.452 F1000
G1 X22.509 Y218.605 Z-2.522 F1000
G1 X22.499 Y218.588 Z-2.591 F1000
G1 X22.485 Y218.565 Z-2.657 F1000
G1 X22.467 Y218.535 Z-2.719 F1000
G1 X22.446 Y218.5 Z-2.777 F1000
G1 X22.422 Y218.459 Z-2.83 F1000
G1 X22.395 Y218.413 Z-2.877 F1000
G1 X22.365 Y218.363 Z-2.919 F1000
G1 X22.333 Y218.31 Z-2.953 F1000
G1 X22.3 Y218.253 Z-2.98 F1000
G1 X22.265 Y218.194 Z-3 F1000
G1 X22.229 Y218.134 Z-3.012 F1000
G1 X22.192 Y218.073 Z-3.016 F1000
G3 X21.971 Y217.319 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y214.813 F1000
G1 X21.983 Y214.58 F1000
G1 X22.014 Y214.338 F1000
G1 X22.076 Y214.049 F1000
G1 X22.165 Y213.752 F1000
G1 X22.295 Y213.418 F1000
G1 X22.477 Y213.044 F1000
G1 X22.7 Y212.664 F1000
G1 X23.003 Y212.233 F1000
G1 X23.373 Y211.788 F1000
G1 X23.841 Y211.308 F1000
G1 X24.437 Y210.788 F1000
G1 X25.176 Y210.241 F1000
G1 X25.956 Y209.755 F1000
G1 X26.766 Y209.321 F1000
G1 X27.598 Y208.931 F1000
G1 X28.447 Y208.58 F1000
G1 X29.31 Y208.263 F1000
G1 X30.183 Y207.976 F1000
G1 X31.064 Y207.715 F1000
G1 X31.952 Y207.477 F1000
G1 X32.845 Y207.26 F1000
G1 X33.742 Y207.061 F1000
G1 X34.643 Y206.878 F1000
G1 X35.546 Y206.711 F1000
G1 X36.452 Y206.556 F1000
G1 X37.36 Y206.415 F1000
G1 X38.27 Y206.284 F1000
G1 X39.181 Y206.163 F1000
G1 X40.093 Y206.052 F1000
G1 X41.007 Y205.95 F1000
G1 X41.921 Y205.856 F1000
G1 X42.836 Y205.769 F1000
G1 X43.751 Y205.689 F1000
G1 X44.667 Y205.615 F1000
G1 X45.584 Y205.547 F1000
G1 X46.501 Y205.484 F1000
G1 X47.418 Y205.427 F1000
G1 X48.335 Y205.374 F1000
G1 X49.253 Y205.325 F1000
G1 X50.171 Y205.28 F1000
G1 X51.089 Y205.239 F1000
G1 X52.007 Y205.201 F1000
G1 X52.926 Y205.166 F1000
G1 X53.844 Y205.133 F1000
G1 X54.763 Y205.103 F1000
G1 X55.681 Y205.076 F1000
G1 X56.6 Y205.05 F1000
G1 X57.519 Y205.026 F1000
G1 X58.437 Y205.003 F1000
G1 X60.275 Y204.961 F1000
G1 X63.95 Y204.883 F1000
G1 X65.788 Y204.844 F1000
G1 X67.625 Y204.802 F1000
G1 X68.544 Y204.78 F1000
G1 X69.463 Y204.757 F1000
G1 X70.382 Y204.732 F1000
G1 X71.3 Y204.706 F1000
G1 X72.219 Y204.678 F1000
G1 X73.137 Y204.649 F1000
G1 X74.056 Y204.618 F1000
G1 X74.974 Y204.586 F1000
G1 X75.893 Y204.551 F1000
G1 X76.811 Y204.515 F1000
G1 X77.729 Y204.476 F1000
G1 X78.647 Y204.436 F1000
G1 X79.565 Y204.395 F1000
G1 X80.483 Y204.351 F1000
G1 X81.401 Y204.306 F1000
G1 X82.319 Y204.26 F1000
G1 X83.237 Y204.212 F1000
G1 X84.155 Y204.163 F1000
G1 X85.99 Y204.061 F1000
G1 X87.825 Y203.956 F1000
G1 X91.495 Y203.742 F1000
G1 X94.247 Y203.581 F1000
G1 X96.082 Y203.476 F1000
G1 X97.917 Y203.373 F1000
G1 X99.753 Y203.275 F1000
G1 X100.671 Y203.227 F1000
G1 X101.588 Y203.181 F1000
G1 X102.506 Y203.136 F1000
G1 X103.424 Y203.092 F1000
G1 X104.342 Y203.049 F1000
G1 X105.26 Y203.008 F1000
G1 X106.179 Y202.968 F1000
G1 X107.097 Y202.929 F1000
G1 X108.015 Y202.892 F1000
G1 X108.933 Y202.857 F1000
G1 X109.852 Y202.823 F1000
G1 X110.77 Y202.79 F1000
G1 X111.689 Y202.759 F1000
G1 X112.607 Y202.73 F1000
G1 X113.526 Y202.701 F1000
G1 X114.444 Y202.674 F1000
G1 X115.363 Y202.649 F1000
G1 X116.282 Y202.625 F1000
G1 X117.201 Y202.602 F1000
G1 X118.119 Y202.581 F1000
G1 X119.038 Y202.56 F1000
G1 X119.957 Y202.541 F1000
G1 X120.876 Y202.523 F1000
G1 X121.795 Y202.507 F1000
G1 X122.714 Y202.491 F1000
G1 X124.551 Y202.463 F1000
G1 X126.389 Y202.439 F1000
G1 X128.227 Y202.418 F1000
G1 X130.065 Y202.4 F1000
G1 X131.903 Y202.386 F1000
G1 X133.741 Y202.375 F1000
G1 X135.579 Y202.367 F1000
G1 X137.417 Y202.362 F1000
G1 X139.255 Y202.36 F1000
G1 X141.093 Y202.362 F1000
G1 X142.012 Y202.365 F1000
G1 X142.931 Y202.369 F1000
G1 X143.85 Y202.374 F1000
G1 X144.769 Y202.38 F1000
G1 X145.688 Y202.388 F1000
G1 X146.607 Y202.397 F1000
G1 X147.526 Y202.408 F1000
G1 X148.445 Y202.422 F1000
G1 X149.364 Y202.437 F1000
G1 X150.283 Y202.454 F1000
G1 X151.202 Y202.474 F1000
G1 X152.12 Y202.497 F1000
G1 X153.039 Y202.523 F1000
G1 X153.958 Y202.552 F1000
G1 X154.876 Y202.584 F1000
G1 X155.794 Y202.62 F1000
G1 X156.713 Y202.661 F1000
G1 X157.63 Y202.706 F1000
G1 X158.548 Y202.756 F1000
G1 X159.466 Y202.811 F1000
G1 X160.383 Y202.872 F1000
G1 X161.299 Y202.94 F1000
G1 X162.215 Y203.014 F1000
G1 X163.13 Y203.097 F1000
G1 X164.045 Y203.189 F1000
G1 X164.958 Y203.29 F1000
G1 X165.87 Y203.403 F1000
G1 X166.781 Y203.529 F1000
G1 X167.689 Y203.669 F1000
G1 X168.594 Y203.827 F1000
G1 X169.496 Y204.006 F1000
G1 X170.392 Y204.21 F1000
G1 X171.279 Y204.448 F1000
G1 X172.099 Y204.716 F1000
G1 X172.65 Y204.946 F1000
G1 X172.934 Y205.093 F1000
G1 X173.204 Y205.272 F1000
G1 X173.428 Y205.505 F1000
G1 X173.596 Y205.781 F1000
G1 X173.701 Y206.088 F1000
G1 X173.736 Y206.409 F1000
G1 Y208.926 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y209.51 I-0.635 J-0.022 F1000
G1 X173.221 Y209.531 Z-3.012 F1000
G1 X173.153 Y209.552 Z-3 F1000
G1 X173.088 Y209.572 Z-2.98 F1000
G1 X173.025 Y209.592 Z-2.953 F1000
G1 X172.966 Y209.61 Z-2.919 F1000
G1 X172.91 Y209.627 Z-2.877 F1000
G1 X172.859 Y209.643 Z-2.83 F1000
G1 X172.814 Y209.657 Z-2.777 F1000
G1 X172.775 Y209.669 Z-2.719 F1000
G1 X172.742 Y209.679 Z-2.657 F1000
G1 X172.716 Y209.687 Z-2.591 F1000
G1 X172.697 Y209.693 Z-2.522 F1000
G1 X172.685 Y209.696 Z-2.452 F1000
G1 X172.682 Y209.697 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y216.113 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y216.109 Z-2.452 F1000
G1 X22.509 Y216.099 Z-2.522 F1000
G1 X22.499 Y216.082 Z-2.591 F1000
G1 X22.485 Y216.059 Z-2.657 F1000
G1 X22.467 Y216.029 Z-2.719 F1000
G1 X22.446 Y215.994 Z-2.777 F1000
G1 X22.422 Y215.953 Z-2.83 F1000
G1 X22.395 Y215.907 Z-2.877 F1000
G1 X22.365 Y215.857 Z-2.919 F1000
G1 X22.333 Y215.804 Z-2.953 F1000
G1 X22.3 Y215.747 Z-2.98 F1000
G1 X22.265 Y215.688 Z-3 F1000
G1 X22.229 Y215.628 Z-3.012 F1000
G1 X22.192 Y215.567 Z-3.016 F1000
G3 X21.971 Y214.813 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y212.307 F1000
G1 X21.982 Y212.08 F1000
G1 X22.014 Y211.837 F1000
G1 X22.076 Y211.549 F1000
G1 X22.165 Y211.251 F1000
G1 X22.295 Y210.917 F1000
G1 X22.477 Y210.543 F1000
G1 X22.701 Y210.163 F1000
G1 X23.003 Y209.732 F1000
G1 X23.373 Y209.286 F1000
G1 X23.842 Y208.805 F1000
G1 X24.439 Y208.285 F1000
G1 X25.178 Y207.738 F1000
G1 X25.958 Y207.252 F1000
G1 X26.767 Y206.817 F1000
G1 X27.6 Y206.427 F1000
G1 X28.449 Y206.076 F1000
G1 X29.311 Y205.758 F1000
G1 X30.184 Y205.471 F1000
G1 X31.065 Y205.209 F1000
G1 X31.953 Y204.971 F1000
G1 X32.846 Y204.753 F1000
G1 X33.743 Y204.553 F1000
G1 X34.643 Y204.369 F1000
G1 X35.547 Y204.201 F1000
G1 X36.452 Y204.046 F1000
G1 X37.36 Y203.903 F1000
G1 X38.27 Y203.771 F1000
G1 X39.181 Y203.65 F1000
G1 X40.093 Y203.538 F1000
G1 X41.006 Y203.435 F1000
G1 X41.92 Y203.339 F1000
G1 X42.835 Y203.252 F1000
G1 X43.75 Y203.17 F1000
G1 X44.666 Y203.096 F1000
G1 X45.583 Y203.027 F1000
G1 X46.5 Y202.963 F1000
G1 X47.417 Y202.904 F1000
G1 X48.334 Y202.85 F1000
G1 X49.252 Y202.801 F1000
G1 X50.17 Y202.755 F1000
G1 X51.088 Y202.712 F1000
G1 X52.006 Y202.673 F1000
G1 X52.924 Y202.637 F1000
G1 X53.843 Y202.604 F1000
G1 X54.761 Y202.573 F1000
G1 X55.68 Y202.545 F1000
G1 X56.598 Y202.518 F1000
G1 X57.517 Y202.493 F1000
G1 X58.436 Y202.469 F1000
G1 X60.273 Y202.425 F1000
G1 X63.949 Y202.343 F1000
G1 X65.786 Y202.302 F1000
G1 X67.624 Y202.259 F1000
G1 X68.542 Y202.236 F1000
G1 X69.461 Y202.212 F1000
G1 X70.38 Y202.187 F1000
G1 X71.298 Y202.16 F1000
G1 X72.217 Y202.132 F1000
G1 X73.136 Y202.102 F1000
G1 X74.054 Y202.07 F1000
G1 X74.972 Y202.037 F1000
G1 X75.891 Y202.002 F1000
G1 X76.809 Y201.965 F1000
G1 X77.727 Y201.927 F1000
G1 X78.645 Y201.887 F1000
G1 X79.563 Y201.845 F1000
G1 X80.481 Y201.801 F1000
G1 X81.399 Y201.756 F1000
G1 X82.317 Y201.71 F1000
G1 X83.235 Y201.662 F1000
G1 X84.153 Y201.614 F1000
G1 X85.988 Y201.513 F1000
G1 X87.823 Y201.409 F1000
G1 X94.246 Y201.038 F1000
G1 X96.081 Y200.934 F1000
G1 X97.916 Y200.833 F1000
G1 X99.751 Y200.735 F1000
G1 X100.669 Y200.688 F1000
G1 X101.587 Y200.642 F1000
G1 X102.505 Y200.597 F1000
G1 X103.423 Y200.554 F1000
G1 X104.341 Y200.512 F1000
G1 X105.259 Y200.471 F1000
G1 X106.177 Y200.431 F1000
G1 X107.096 Y200.393 F1000
G1 X108.014 Y200.356 F1000
G1 X108.932 Y200.321 F1000
G1 X109.851 Y200.287 F1000
G1 X110.769 Y200.255 F1000
G1 X111.687 Y200.224 F1000
G1 X112.606 Y200.194 F1000
G1 X113.525 Y200.166 F1000
G1 X114.443 Y200.139 F1000
G1 X115.362 Y200.114 F1000
G1 X116.281 Y200.09 F1000
G1 X117.199 Y200.067 F1000
G1 X118.118 Y200.045 F1000
G1 X119.037 Y200.025 F1000
G1 X119.956 Y200.006 F1000
G1 X120.875 Y199.988 F1000
G1 X121.793 Y199.971 F1000
G1 X122.712 Y199.955 F1000
G1 X124.55 Y199.927 F1000
G1 X126.388 Y199.902 F1000
G1 X128.226 Y199.881 F1000
G1 X130.064 Y199.864 F1000
G1 X131.902 Y199.85 F1000
G1 X133.74 Y199.838 F1000
G1 X135.578 Y199.83 F1000
G1 X137.416 Y199.825 F1000
G1 X139.254 Y199.824 F1000
G1 X140.173 F1000
G1 X141.092 Y199.826 F1000
G1 X142.011 Y199.829 F1000
G1 X142.93 Y199.833 F1000
G1 X143.849 Y199.838 F1000
G1 X144.768 Y199.845 F1000
G1 X145.687 Y199.853 F1000
G1 X146.606 Y199.863 F1000
G1 X147.525 Y199.875 F1000
G1 X148.444 Y199.889 F1000
G1 X149.363 Y199.905 F1000
G1 X150.282 Y199.923 F1000
G1 X151.2 Y199.943 F1000
G1 X152.119 Y199.967 F1000
G1 X153.038 Y199.993 F1000
G1 X153.956 Y200.023 F1000
G1 X154.875 Y200.056 F1000
G1 X155.793 Y200.093 F1000
G1 X156.711 Y200.134 F1000
G1 X157.629 Y200.18 F1000
G1 X158.547 Y200.23 F1000
G1 X159.464 Y200.286 F1000
G1 X160.381 Y200.348 F1000
G1 X161.297 Y200.417 F1000
G1 X162.213 Y200.492 F1000
G1 X163.128 Y200.575 F1000
G1 X164.043 Y200.667 F1000
G1 X164.956 Y200.77 F1000
G1 X165.868 Y200.883 F1000
G1 X166.779 Y201.009 F1000
G1 X167.687 Y201.15 F1000
G1 X168.592 Y201.308 F1000
G1 X169.493 Y201.487 F1000
G1 X170.389 Y201.692 F1000
G1 X171.277 Y201.93 F1000
G1 X172.098 Y202.198 F1000
G1 X172.649 Y202.429 F1000
G1 X172.934 Y202.576 F1000
G1 X173.204 Y202.755 F1000
G1 X173.428 Y202.988 F1000
G1 X173.596 Y203.265 F1000
G1 X173.701 Y203.571 F1000
G1 X173.736 Y203.893 F1000
G1 Y206.409 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y206.994 I-0.635 J-0.022 F1000
G1 X173.221 Y207.015 Z-3.012 F1000
G1 X173.153 Y207.036 Z-3 F1000
G1 X173.088 Y207.056 Z-2.98 F1000
G1 X173.025 Y207.075 Z-2.953 F1000
G1 X172.966 Y207.094 Z-2.919 F1000
G1 X172.91 Y207.111 Z-2.877 F1000
G1 X172.859 Y207.126 Z-2.83 F1000
G1 X172.814 Y207.14 Z-2.777 F1000
G1 X172.775 Y207.153 Z-2.719 F1000
G1 X172.742 Y207.163 Z-2.657 F1000
G1 X172.716 Y207.171 Z-2.591 F1000
G1 X172.697 Y207.177 Z-2.522 F1000
G1 X172.685 Y207.18 Z-2.452 F1000
G1 X172.682 Y207.181 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y213.607 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y213.603 Z-2.452 F1000
G1 X22.509 Y213.593 Z-2.522 F1000
G1 X22.499 Y213.576 Z-2.591 F1000
G1 X22.485 Y213.553 Z-2.657 F1000
G1 X22.467 Y213.523 Z-2.719 F1000
G1 X22.446 Y213.488 Z-2.777 F1000
G1 X22.422 Y213.447 Z-2.83 F1000
G1 X22.395 Y213.401 Z-2.877 F1000
G1 X22.365 Y213.351 Z-2.919 F1000
G1 X22.333 Y213.298 Z-2.953 F1000
G1 X22.3 Y213.241 Z-2.98 F1000
G1 X22.265 Y213.182 Z-3 F1000
G1 X22.229 Y213.122 Z-3.012 F1000
G1 X22.192 Y213.061 Z-3.016 F1000
G3 X21.971 Y212.307 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y209.801 F1000
G1 X21.982 Y209.578 F1000
G1 X22.014 Y209.336 F1000
G1 X22.076 Y209.047 F1000
G1 X22.165 Y208.749 F1000
G1 X22.295 Y208.415 F1000
G1 X22.477 Y208.041 F1000
G1 X22.701 Y207.66 F1000
G1 X23.004 Y207.229 F1000
G1 X23.374 Y206.783 F1000
G1 X23.844 Y206.301 F1000
G1 X24.441 Y205.78 F1000
G1 X25.18 Y205.234 F1000
G1 X25.96 Y204.747 F1000
G1 X26.769 Y204.312 F1000
G1 X27.601 Y203.922 F1000
G1 X28.45 Y203.571 F1000
G1 X29.313 Y203.253 F1000
G1 X30.185 Y202.965 F1000
G1 X31.066 Y202.702 F1000
G1 X31.954 Y202.463 F1000
G1 X32.846 Y202.244 F1000
G1 X33.743 Y202.044 F1000
G1 X34.643 Y201.86 F1000
G1 X35.547 Y201.69 F1000
G1 X36.452 Y201.535 F1000
G1 X37.36 Y201.391 F1000
G1 X38.27 Y201.258 F1000
G1 X39.18 Y201.136 F1000
G1 X40.093 Y201.023 F1000
G1 X41.006 Y200.919 F1000
G1 X41.92 Y200.823 F1000
G1 X42.834 Y200.734 F1000
G1 X43.75 Y200.652 F1000
G1 X44.666 Y200.576 F1000
G1 X45.582 Y200.506 F1000
G1 X46.499 Y200.442 F1000
G1 X47.416 Y200.382 F1000
G1 X48.333 Y200.327 F1000
G1 X49.251 Y200.276 F1000
G1 X50.169 Y200.229 F1000
G1 X51.087 Y200.186 F1000
G1 X52.005 Y200.146 F1000
G1 X52.923 Y200.109 F1000
G1 X53.841 Y200.075 F1000
G1 X54.76 Y200.043 F1000
G1 X55.678 Y200.013 F1000
G1 X56.597 Y199.986 F1000
G1 X57.516 Y199.96 F1000
G1 X58.434 Y199.935 F1000
G1 X60.272 Y199.889 F1000
G1 X63.028 Y199.825 F1000
G1 X65.784 Y199.761 F1000
G1 X67.622 Y199.716 F1000
G1 X68.541 Y199.692 F1000
G1 X69.459 Y199.667 F1000
G1 X70.378 Y199.641 F1000
G1 X71.297 Y199.614 F1000
G1 X72.215 Y199.585 F1000
G1 X73.134 Y199.554 F1000
G1 X74.052 Y199.522 F1000
G1 X74.97 Y199.489 F1000
G1 X75.889 Y199.453 F1000
G1 X76.807 Y199.416 F1000
G1 X77.725 Y199.378 F1000
G1 X78.643 Y199.337 F1000
G1 X79.562 Y199.295 F1000
G1 X80.479 Y199.252 F1000
G1 X81.397 Y199.207 F1000
G1 X82.315 Y199.161 F1000
G1 X83.233 Y199.113 F1000
G1 X85.068 Y199.015 F1000
G1 X86.904 Y198.914 F1000
G1 X89.656 Y198.757 F1000
G1 X93.326 Y198.547 F1000
G1 X95.161 Y198.443 F1000
G1 X96.997 Y198.342 F1000
G1 X98.832 Y198.243 F1000
G1 X99.75 Y198.196 F1000
G1 X100.668 Y198.149 F1000
G1 X101.586 Y198.104 F1000
G1 X102.504 Y198.059 F1000
G1 X103.422 Y198.016 F1000
G1 X104.34 Y197.974 F1000
G1 X105.258 Y197.934 F1000
G1 X106.176 Y197.894 F1000
G1 X107.094 Y197.857 F1000
G1 X108.013 Y197.82 F1000
G1 X108.931 Y197.785 F1000
G1 X109.849 Y197.751 F1000
G1 X110.768 Y197.719 F1000
G1 X111.686 Y197.688 F1000
G1 X112.605 Y197.659 F1000
G1 X113.523 Y197.631 F1000
G1 X114.442 Y197.604 F1000
G1 X115.361 Y197.579 F1000
G1 X116.279 Y197.554 F1000
G1 X117.198 Y197.532 F1000
G1 X118.117 Y197.51 F1000
G1 X119.036 Y197.49 F1000
G1 X119.955 Y197.47 F1000
G1 X120.873 Y197.452 F1000
G1 X121.792 Y197.435 F1000
G1 X122.711 Y197.42 F1000
G1 X124.549 Y197.391 F1000
G1 X126.387 Y197.366 F1000
G1 X128.225 Y197.345 F1000
G1 X130.063 Y197.327 F1000
G1 X131.901 Y197.313 F1000
G1 X133.739 Y197.302 F1000
G1 X135.577 Y197.293 F1000
G1 X137.415 Y197.289 F1000
G1 X139.253 Y197.288 F1000
G1 X140.172 F1000
G1 X141.091 Y197.29 F1000
G1 X142.01 Y197.294 F1000
G1 X142.929 Y197.298 F1000
G1 X143.848 Y197.304 F1000
G1 X144.767 Y197.311 F1000
G1 X145.686 Y197.319 F1000
G1 X146.605 Y197.33 F1000
G1 X147.524 Y197.342 F1000
G1 X148.443 Y197.356 F1000
G1 X149.361 Y197.372 F1000
G1 X150.28 Y197.391 F1000
G1 X151.199 Y197.412 F1000
G1 X152.118 Y197.436 F1000
G1 X153.036 Y197.464 F1000
G1 X153.955 Y197.494 F1000
G1 X154.873 Y197.528 F1000
G1 X155.792 Y197.565 F1000
G1 X156.71 Y197.607 F1000
G1 X157.627 Y197.654 F1000
G1 X158.545 Y197.705 F1000
G1 X159.462 Y197.762 F1000
G1 X160.379 Y197.824 F1000
G1 X161.296 Y197.893 F1000
G1 X162.212 Y197.969 F1000
G1 X163.127 Y198.053 F1000
G1 X164.041 Y198.146 F1000
G1 X164.954 Y198.249 F1000
G1 X165.866 Y198.363 F1000
G1 X166.776 Y198.489 F1000
G1 X167.685 Y198.631 F1000
G1 X168.59 Y198.789 F1000
G1 X169.491 Y198.969 F1000
G1 X170.387 Y199.174 F1000
G1 X171.275 Y199.412 F1000
G1 X172.097 Y199.681 F1000
G1 X172.649 Y199.912 F1000
G1 X172.934 Y200.059 F1000
G1 X173.204 Y200.238 F1000
G1 X173.428 Y200.471 F1000
G1 X173.596 Y200.748 F1000
G1 X173.701 Y201.054 F1000
G1 X173.736 Y201.376 F1000
G1 Y203.893 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y204.477 I-0.635 J-0.022 F1000
G1 X173.221 Y204.498 Z-3.012 F1000
G1 X173.153 Y204.519 Z-3 F1000
G1 X173.088 Y204.539 Z-2.98 F1000
G1 X173.025 Y204.559 Z-2.953 F1000
G1 X172.966 Y204.577 Z-2.919 F1000
G1 X172.91 Y204.594 Z-2.877 F1000
G1 X172.859 Y204.61 Z-2.83 F1000
G1 X172.814 Y204.624 Z-2.777 F1000
G1 X172.775 Y204.636 Z-2.719 F1000
G1 X172.742 Y204.646 Z-2.657 F1000
G1 X172.716 Y204.654 Z-2.591 F1000
G1 X172.697 Y204.66 Z-2.522 F1000
G1 X172.685 Y204.663 Z-2.452 F1000
G1 X172.682 Y204.665 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y211.101 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y211.097 Z-2.452 F1000
G1 X22.509 Y211.087 Z-2.522 F1000
G1 X22.499 Y211.07 Z-2.591 F1000
G1 X22.485 Y211.047 Z-2.657 F1000
G1 X22.467 Y211.017 Z-2.719 F1000
G1 X22.446 Y210.982 Z-2.777 F1000
G1 X22.422 Y210.941 Z-2.83 F1000
G1 X22.395 Y210.895 Z-2.877 F1000
G1 X22.365 Y210.845 Z-2.919 F1000
G1 X22.333 Y210.792 Z-2.953 F1000
G1 X22.3 Y210.735 Z-2.98 F1000
G1 X22.265 Y210.676 Z-3 F1000
G1 X22.229 Y210.616 Z-3.012 F1000
G1 X22.192 Y210.555 Z-3.016 F1000
G3 X21.971 Y209.801 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y207.295 F1000
G1 X21.982 Y207.076 F1000
G1 X22.014 Y206.833 F1000
G1 X22.075 Y206.545 F1000
G1 X22.165 Y206.247 F1000
G1 X22.295 Y205.913 F1000
G1 X22.477 Y205.537 F1000
G1 X22.701 Y205.157 F1000
G1 X23.004 Y204.725 F1000
G1 X23.375 Y204.279 F1000
G1 X23.845 Y203.797 F1000
G1 X24.443 Y203.275 F1000
G1 X25.182 Y202.729 F1000
G1 X25.961 Y202.242 F1000
G1 X26.771 Y201.807 F1000
G1 X27.603 Y201.416 F1000
G1 X28.452 Y201.064 F1000
G1 X29.314 Y200.746 F1000
G1 X30.187 Y200.458 F1000
G1 X31.067 Y200.195 F1000
G1 X31.954 Y199.955 F1000
G1 X32.847 Y199.736 F1000
G1 X33.744 Y199.534 F1000
G1 X34.644 Y199.35 F1000
G1 X35.547 Y199.18 F1000
G1 X36.453 Y199.023 F1000
G1 X37.36 Y198.878 F1000
G1 X38.269 Y198.745 F1000
G1 X39.18 Y198.622 F1000
G1 X40.092 Y198.508 F1000
G1 X41.005 Y198.403 F1000
G1 X41.919 Y198.306 F1000
G1 X42.834 Y198.216 F1000
G1 X43.749 Y198.133 F1000
G1 X44.665 Y198.056 F1000
G1 X45.581 Y197.985 F1000
G1 X46.498 Y197.92 F1000
G1 X47.415 Y197.859 F1000
G1 X48.332 Y197.803 F1000
G1 X49.25 Y197.752 F1000
G1 X50.167 Y197.704 F1000
G1 X51.085 Y197.66 F1000
G1 X52.003 Y197.619 F1000
G1 X52.922 Y197.581 F1000
G1 X53.84 Y197.546 F1000
G1 X54.758 Y197.513 F1000
G1 X55.677 Y197.482 F1000
G1 X56.595 Y197.454 F1000
G1 X57.514 Y197.427 F1000
G1 X58.433 Y197.401 F1000
G1 X60.27 Y197.353 F1000
G1 X63.026 Y197.286 F1000
G1 X65.783 Y197.219 F1000
G1 X67.62 Y197.173 F1000
G1 X68.539 Y197.148 F1000
G1 X69.457 Y197.122 F1000
G1 X70.376 Y197.096 F1000
G1 X71.295 Y197.067 F1000
G1 X72.213 Y197.038 F1000
G1 X73.132 Y197.007 F1000
G1 X74.05 Y196.975 F1000
G1 X74.969 Y196.94 F1000
G1 X75.887 Y196.905 F1000
G1 X76.805 Y196.867 F1000
G1 X77.723 Y196.829 F1000
G1 X78.642 Y196.788 F1000
G1 X79.56 Y196.746 F1000
G1 X80.478 Y196.703 F1000
G1 X81.396 Y196.658 F1000
G1 X82.313 Y196.612 F1000
G1 X83.231 Y196.565 F1000
G1 X85.067 Y196.467 F1000
G1 X86.902 Y196.366 F1000
G1 X89.655 Y196.211 F1000
G1 X93.325 Y196.003 F1000
G1 X95.16 Y195.901 F1000
G1 X96.995 Y195.8 F1000
G1 X98.831 Y195.703 F1000
G1 X99.749 Y195.656 F1000
G1 X100.666 Y195.61 F1000
G1 X101.584 Y195.565 F1000
G1 X102.502 Y195.521 F1000
G1 X103.42 Y195.478 F1000
G1 X104.338 Y195.437 F1000
G1 X105.257 Y195.397 F1000
G1 X106.175 Y195.358 F1000
G1 X107.093 Y195.32 F1000
G1 X108.011 Y195.284 F1000
G1 X108.93 Y195.249 F1000
G1 X109.848 Y195.216 F1000
G1 X110.767 Y195.183 F1000
G1 X111.685 Y195.153 F1000
G1 X112.604 Y195.123 F1000
G1 X113.522 Y195.095 F1000
G1 X114.441 Y195.069 F1000
G1 X115.359 Y195.043 F1000
G1 X116.278 Y195.019 F1000
G1 X117.197 Y194.996 F1000
G1 X118.116 Y194.975 F1000
G1 X119.034 Y194.954 F1000
G1 X119.953 Y194.935 F1000
G1 X120.872 Y194.917 F1000
G1 X121.791 Y194.9 F1000
G1 X122.71 Y194.884 F1000
G1 X124.548 Y194.855 F1000
G1 X126.386 Y194.83 F1000
G1 X128.223 Y194.809 F1000
G1 X130.061 Y194.791 F1000
G1 X131.899 Y194.776 F1000
G1 X133.737 Y194.765 F1000
G1 X135.575 Y194.757 F1000
G1 X137.413 Y194.752 F1000
G1 X139.252 Y194.751 F1000
G1 X140.171 Y194.753 F1000
G1 X141.09 Y194.755 F1000
G1 X142.009 Y194.758 F1000
G1 X142.928 Y194.763 F1000
G1 X143.847 Y194.769 F1000
G1 X144.766 Y194.776 F1000
G1 X145.685 Y194.785 F1000
G1 X146.604 Y194.796 F1000
G1 X147.522 Y194.809 F1000
G1 X148.441 Y194.824 F1000
G1 X149.36 Y194.84 F1000
G1 X150.279 Y194.86 F1000
G1 X151.198 Y194.882 F1000
G1 X152.116 Y194.906 F1000
G1 X153.035 Y194.934 F1000
G1 X153.954 Y194.965 F1000
G1 X154.872 Y194.999 F1000
G1 X155.79 Y195.038 F1000
G1 X156.708 Y195.08 F1000
G1 X157.626 Y195.127 F1000
G1 X158.544 Y195.179 F1000
G1 X159.461 Y195.237 F1000
G1 X160.378 Y195.3 F1000
G1 X161.294 Y195.37 F1000
G1 X162.21 Y195.446 F1000
G1 X163.125 Y195.531 F1000
G1 X164.039 Y195.624 F1000
G1 X164.952 Y195.728 F1000
G1 X165.864 Y195.842 F1000
G1 X166.774 Y195.969 F1000
G1 X167.682 Y196.111 F1000
G1 X168.588 Y196.27 F1000
G1 X169.489 Y196.45 F1000
G1 X170.385 Y196.655 F1000
G1 X171.272 Y196.893 F1000
G1 X172.096 Y197.163 F1000
G1 X172.648 Y197.394 F1000
G1 X172.934 Y197.542 F1000
G1 X173.204 Y197.721 F1000
G1 X173.428 Y197.954 F1000
G1 X173.596 Y198.23 F1000
G1 X173.701 Y198.536 F1000
G1 X173.736 Y198.858 F1000
G1 Y201.376 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y201.96 I-0.635 J-0.022 F1000
G1 X173.221 Y201.981 Z-3.012 F1000
G1 X173.153 Y202.002 Z-3 F1000
G1 X173.088 Y202.022 Z-2.98 F1000
G1 X173.025 Y202.041 Z-2.953 F1000
G1 X172.966 Y202.06 Z-2.919 F1000
G1 X172.91 Y202.077 Z-2.877 F1000
G1 X172.859 Y202.093 Z-2.83 F1000
G1 X172.814 Y202.107 Z-2.777 F1000
G1 X172.775 Y202.119 Z-2.719 F1000
G1 X172.742 Y202.129 Z-2.657 F1000
G1 X172.716 Y202.137 Z-2.591 F1000
G1 X172.697 Y202.143 Z-2.522 F1000
G1 X172.685 Y202.146 Z-2.452 F1000
G1 X172.682 Y202.147 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y208.595 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y208.591 Z-2.452 F1000
G1 X22.509 Y208.581 Z-2.522 F1000
G1 X22.499 Y208.564 Z-2.591 F1000
G1 X22.485 Y208.541 Z-2.657 F1000
G1 X22.467 Y208.511 Z-2.719 F1000
G1 X22.446 Y208.476 Z-2.777 F1000
G1 X22.422 Y208.435 Z-2.83 F1000
G1 X22.395 Y208.389 Z-2.877 F1000
G1 X22.365 Y208.339 Z-2.919 F1000
G1 X22.333 Y208.286 Z-2.953 F1000
G1 X22.3 Y208.229 Z-2.98 F1000
G1 X22.265 Y208.17 Z-3 F1000
G1 X22.229 Y208.11 Z-3.012 F1000
G1 X22.192 Y208.049 Z-3.016 F1000
G3 X21.971 Y207.295 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y204.789 F1000
G1 X21.982 Y204.572 F1000
G1 X22.014 Y204.33 F1000
G1 X22.075 Y204.041 F1000
G1 X22.165 Y203.743 F1000
G1 X22.295 Y203.409 F1000
G1 X22.477 Y203.033 F1000
G1 X22.701 Y202.653 F1000
G1 X23.005 Y202.221 F1000
G1 X23.375 Y201.774 F1000
G1 X23.846 Y201.292 F1000
G1 X24.445 Y200.769 F1000
G1 X25.184 Y200.223 F1000
G1 X25.963 Y199.736 F1000
G1 X26.773 Y199.301 F1000
G1 X27.605 Y198.91 F1000
G1 X28.453 Y198.558 F1000
G1 X29.315 Y198.239 F1000
G1 X30.188 Y197.95 F1000
G1 X31.068 Y197.687 F1000
G1 X31.955 Y197.446 F1000
G1 X32.848 Y197.226 F1000
G1 X33.744 Y197.024 F1000
G1 X34.644 Y196.839 F1000
G1 X35.547 Y196.668 F1000
G1 X36.453 Y196.511 F1000
G1 X37.36 Y196.365 F1000
G1 X38.269 Y196.231 F1000
G1 X39.18 Y196.107 F1000
G1 X40.092 Y195.993 F1000
G1 X41.005 Y195.887 F1000
G1 X41.918 Y195.789 F1000
G1 X42.833 Y195.698 F1000
G1 X43.748 Y195.614 F1000
G1 X44.664 Y195.536 F1000
G1 X45.58 Y195.464 F1000
G1 X46.497 Y195.398 F1000
G1 X47.414 Y195.336 F1000
G1 X48.331 Y195.28 F1000
G1 X49.248 Y195.227 F1000
G1 X50.166 Y195.178 F1000
G1 X51.084 Y195.133 F1000
G1 X52.002 Y195.091 F1000
G1 X52.92 Y195.052 F1000
G1 X53.839 Y195.016 F1000
G1 X54.757 Y194.983 F1000
G1 X55.676 Y194.951 F1000
G1 X56.594 Y194.921 F1000
G1 X57.513 Y194.893 F1000
G1 X58.431 Y194.867 F1000
G1 X60.269 Y194.817 F1000
G1 X63.025 Y194.747 F1000
G1 X65.781 Y194.678 F1000
G1 X67.618 Y194.63 F1000
G1 X69.456 Y194.578 F1000
G1 X70.374 Y194.55 F1000
G1 X71.293 Y194.522 F1000
G1 X72.211 Y194.491 F1000
G1 X73.13 Y194.46 F1000
G1 X74.048 Y194.427 F1000
G1 X74.967 Y194.393 F1000
G1 X75.885 Y194.356 F1000
G1 X76.803 Y194.319 F1000
G1 X77.722 Y194.28 F1000
G1 X78.64 Y194.239 F1000
G1 X79.558 Y194.197 F1000
G1 X80.476 Y194.154 F1000
G1 X81.394 Y194.109 F1000
G1 X82.312 Y194.063 F1000
G1 X84.147 Y193.968 F1000
G1 X85.982 Y193.87 F1000
G1 X88.735 Y193.717 F1000
G1 X93.323 Y193.46 F1000
G1 X95.158 Y193.358 F1000
G1 X96.994 Y193.259 F1000
G1 X98.829 Y193.163 F1000
G1 X100.665 Y193.071 F1000
G1 X101.583 Y193.026 F1000
G1 X102.501 Y192.983 F1000
G1 X103.419 Y192.94 F1000
G1 X104.337 Y192.899 F1000
G1 X105.255 Y192.859 F1000
G1 X106.173 Y192.821 F1000
G1 X107.092 Y192.783 F1000
G1 X108.01 Y192.747 F1000
G1 X108.928 Y192.713 F1000
G1 X109.847 Y192.68 F1000
G1 X110.765 Y192.648 F1000
G1 X111.684 Y192.617 F1000
G1 X112.602 Y192.588 F1000
G1 X113.521 Y192.56 F1000
G1 X114.44 Y192.533 F1000
G1 X115.358 Y192.508 F1000
G1 X116.277 Y192.484 F1000
G1 X117.196 Y192.461 F1000
G1 X118.114 Y192.439 F1000
G1 X119.033 Y192.419 F1000
G1 X119.952 Y192.399 F1000
G1 X120.871 Y192.381 F1000
G1 X121.79 Y192.364 F1000
G1 X122.709 Y192.348 F1000
G1 X124.546 Y192.319 F1000
G1 X126.384 Y192.294 F1000
G1 X128.222 Y192.272 F1000
G1 X130.06 Y192.254 F1000
G1 X131.898 Y192.24 F1000
G1 X133.736 Y192.228 F1000
G1 X135.574 Y192.22 F1000
G1 X137.412 Y192.216 F1000
G1 X139.25 Y192.215 F1000
G1 X140.169 Y192.217 F1000
G1 X141.088 Y192.219 F1000
G1 X142.007 Y192.223 F1000
G1 X142.926 Y192.228 F1000
G1 X143.845 Y192.234 F1000
G1 X144.764 Y192.242 F1000
G1 X145.683 Y192.252 F1000
G1 X146.602 Y192.263 F1000
G1 X147.521 Y192.276 F1000
G1 X148.44 Y192.291 F1000
G1 X149.359 Y192.309 F1000
G1 X150.278 Y192.328 F1000
G1 X151.197 Y192.351 F1000
G1 X152.115 Y192.376 F1000
G1 X153.034 Y192.404 F1000
G1 X153.952 Y192.436 F1000
G1 X154.871 Y192.471 F1000
G1 X155.789 Y192.51 F1000
G1 X156.707 Y192.553 F1000
G1 X157.625 Y192.601 F1000
G1 X158.542 Y192.654 F1000
G1 X159.459 Y192.712 F1000
G1 X160.376 Y192.776 F1000
G1 X161.292 Y192.846 F1000
G1 X162.208 Y192.923 F1000
G1 X163.123 Y193.009 F1000
G1 X164.037 Y193.102 F1000
G1 X164.951 Y193.206 F1000
G1 X165.862 Y193.321 F1000
G1 X166.772 Y193.449 F1000
G1 X167.68 Y193.591 F1000
G1 X168.585 Y193.751 F1000
G1 X169.487 Y193.931 F1000
G1 X170.382 Y194.136 F1000
G1 X171.27 Y194.375 F1000
G1 X172.095 Y194.644 F1000
G1 X172.648 Y194.876 F1000
G1 X172.934 Y195.024 F1000
G1 X173.204 Y195.203 F1000
G1 X173.428 Y195.436 F1000
G1 X173.596 Y195.712 F1000
G1 X173.701 Y196.018 F1000
G1 X173.736 Y196.34 F1000
G1 Y198.858 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y199.443 I-0.635 J-0.022 F1000
G1 X173.221 Y199.464 Z-3.012 F1000
G1 X173.153 Y199.484 Z-3 F1000
G1 X173.088 Y199.505 Z-2.98 F1000
G1 X173.025 Y199.524 Z-2.953 F1000
G1 X172.966 Y199.542 Z-2.919 F1000
G1 X172.91 Y199.559 Z-2.877 F1000
G1 X172.859 Y199.575 Z-2.83 F1000
G1 X172.814 Y199.589 Z-2.777 F1000
G1 X172.775 Y199.601 Z-2.719 F1000
G1 X172.742 Y199.611 Z-2.657 F1000
G1 X172.716 Y199.619 Z-2.591 F1000
G1 X172.697 Y199.625 Z-2.522 F1000
G1 X172.685 Y199.629 Z-2.452 F1000
G1 X172.682 Y199.63 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y206.089 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y206.085 Z-2.452 F1000
G1 X22.509 Y206.075 Z-2.522 F1000
G1 X22.499 Y206.058 Z-2.591 F1000
G1 X22.485 Y206.035 Z-2.657 F1000
G1 X22.467 Y206.005 Z-2.719 F1000
G1 X22.446 Y205.97 Z-2.777 F1000
G1 X22.422 Y205.929 Z-2.83 F1000
G1 X22.395 Y205.883 Z-2.877 F1000
G1 X22.365 Y205.833 Z-2.919 F1000
G1 X22.333 Y205.78 Z-2.953 F1000
G1 X22.3 Y205.723 Z-2.98 F1000
G1 X22.265 Y205.664 Z-3 F1000
G1 X22.229 Y205.604 Z-3.012 F1000
G1 X22.192 Y205.543 Z-3.016 F1000
G3 X21.971 Y204.789 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y202.283 F1000
G1 X21.982 Y202.068 F1000
G1 X22.014 Y201.826 F1000
G1 X22.075 Y201.537 F1000
G1 X22.165 Y201.238 F1000
G1 X22.295 Y200.904 F1000
G1 X22.477 Y200.529 F1000
G1 X22.701 Y200.148 F1000
G1 X23.005 Y199.715 F1000
G1 X23.376 Y199.268 F1000
G1 X23.847 Y198.786 F1000
G1 X24.447 Y198.263 F1000
G1 X25.186 Y197.716 F1000
G1 X25.965 Y197.229 F1000
G1 X26.774 Y196.794 F1000
G1 X27.606 Y196.403 F1000
G1 X28.455 Y196.05 F1000
G1 X29.317 Y195.731 F1000
G1 X30.189 Y195.441 F1000
G1 X31.069 Y195.178 F1000
G1 X31.956 Y194.937 F1000
G1 X32.848 Y194.716 F1000
G1 X33.745 Y194.514 F1000
G1 X34.645 Y194.328 F1000
G1 X35.548 Y194.156 F1000
G1 X36.453 Y193.998 F1000
G1 X37.36 Y193.852 F1000
G1 X38.269 Y193.717 F1000
G1 X39.18 Y193.592 F1000
G1 X40.091 Y193.477 F1000
G1 X41.004 Y193.37 F1000
G1 X41.918 Y193.271 F1000
G1 X42.832 Y193.179 F1000
G1 X43.747 Y193.095 F1000
G1 X44.663 Y193.016 F1000
G1 X45.579 Y192.943 F1000
G1 X46.496 Y192.876 F1000
G1 X47.413 Y192.813 F1000
G1 X48.33 Y192.756 F1000
G1 X49.247 Y192.702 F1000
G1 X50.165 Y192.652 F1000
G1 X51.083 Y192.606 F1000
G1 X52.001 Y192.564 F1000
G1 X52.919 Y192.524 F1000
G1 X53.837 Y192.487 F1000
G1 X54.756 Y192.452 F1000
G1 X55.674 Y192.42 F1000
G1 X56.593 Y192.389 F1000
G1 X57.511 Y192.36 F1000
G1 X58.43 Y192.333 F1000
G1 X60.267 Y192.281 F1000
G1 X63.023 Y192.208 F1000
G1 X65.779 Y192.137 F1000
G1 X67.617 Y192.087 F1000
G1 X69.454 Y192.033 F1000
G1 X70.373 Y192.005 F1000
G1 X71.291 Y191.976 F1000
G1 X72.21 Y191.945 F1000
G1 X73.128 Y191.913 F1000
G1 X74.047 Y191.88 F1000
G1 X74.965 Y191.845 F1000
G1 X75.883 Y191.808 F1000
G1 X76.801 Y191.771 F1000
G1 X77.72 Y191.731 F1000
G1 X78.638 Y191.691 F1000
G1 X79.556 Y191.649 F1000
G1 X80.474 Y191.605 F1000
G1 X81.392 Y191.561 F1000
G1 X82.31 Y191.515 F1000
G1 X84.145 Y191.421 F1000
G1 X85.981 Y191.323 F1000
G1 X88.734 Y191.171 F1000
G1 X93.322 Y190.916 F1000
G1 X95.157 Y190.816 F1000
G1 X96.992 Y190.718 F1000
G1 X98.828 Y190.623 F1000
G1 X100.664 Y190.532 F1000
G1 X101.582 Y190.487 F1000
G1 X102.5 Y190.444 F1000
G1 X103.418 Y190.402 F1000
G1 X104.336 Y190.362 F1000
G1 X105.254 Y190.322 F1000
G1 X106.172 Y190.284 F1000
G1 X107.091 Y190.247 F1000
G1 X108.009 Y190.211 F1000
G1 X108.927 Y190.177 F1000
G1 X109.846 Y190.143 F1000
G1 X110.764 Y190.112 F1000
G1 X111.683 Y190.081 F1000
G1 X112.601 Y190.052 F1000
G1 X113.52 Y190.024 F1000
G1 X114.438 Y189.997 F1000
G1 X115.357 Y189.972 F1000
G1 X116.276 Y189.948 F1000
G1 X117.195 Y189.925 F1000
G1 X118.113 Y189.904 F1000
G1 X119.032 Y189.883 F1000
G1 X119.951 Y189.864 F1000
G1 X120.87 Y189.845 F1000
G1 X121.789 Y189.828 F1000
G1 X122.707 Y189.812 F1000
G1 X124.545 Y189.783 F1000
G1 X126.383 Y189.758 F1000
G1 X128.221 Y189.736 F1000
G1 X130.059 Y189.718 F1000
G1 X131.897 Y189.703 F1000
G1 X133.735 Y189.692 F1000
G1 X135.573 Y189.684 F1000
G1 X137.411 Y189.68 F1000
G1 X138.33 Y189.679 F1000
G1 X139.249 Y189.68 F1000
G1 X140.168 Y189.681 F1000
G1 X141.087 Y189.684 F1000
G1 X142.006 Y189.688 F1000
G1 X142.925 Y189.693 F1000
G1 X143.844 Y189.7 F1000
G1 X144.763 Y189.708 F1000
G1 X145.682 Y189.718 F1000
G1 X146.601 Y189.729 F1000
G1 X147.52 Y189.743 F1000
G1 X148.439 Y189.759 F1000
G1 X149.358 Y189.777 F1000
G1 X150.277 Y189.797 F1000
G1 X151.195 Y189.82 F1000
G1 X152.114 Y189.846 F1000
G1 X153.032 Y189.875 F1000
G1 X153.951 Y189.907 F1000
G1 X154.869 Y189.943 F1000
G1 X155.787 Y189.983 F1000
G1 X156.705 Y190.026 F1000
G1 X157.623 Y190.075 F1000
G1 X158.541 Y190.128 F1000
G1 X159.458 Y190.187 F1000
G1 X160.374 Y190.251 F1000
G1 X161.291 Y190.322 F1000
G1 X162.206 Y190.4 F1000
G1 X163.121 Y190.486 F1000
G1 X164.036 Y190.58 F1000
G1 X164.949 Y190.685 F1000
G1 X165.86 Y190.8 F1000
G1 X166.771 Y190.928 F1000
G1 X167.678 Y191.071 F1000
G1 X168.583 Y191.231 F1000
G1 X169.485 Y191.411 F1000
G1 X170.38 Y191.617 F1000
G1 X171.268 Y191.855 F1000
G1 X172.094 Y192.126 F1000
G1 X172.647 Y192.357 F1000
G1 X172.934 Y192.505 F1000
G1 X173.204 Y192.684 F1000
G1 X173.428 Y192.918 F1000
G1 X173.596 Y193.194 F1000
G1 X173.701 Y193.5 F1000
G1 X173.736 Y193.822 F1000
G1 Y196.34 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y196.925 I-0.635 J-0.022 F1000
G1 X173.221 Y196.946 Z-3.012 F1000
G1 X173.153 Y196.966 Z-3 F1000
G1 X173.088 Y196.987 Z-2.98 F1000
G1 X173.025 Y197.006 Z-2.953 F1000
G1 X172.966 Y197.024 Z-2.919 F1000
G1 X172.91 Y197.041 Z-2.877 F1000
G1 X172.859 Y197.057 Z-2.83 F1000
G1 X172.814 Y197.071 Z-2.777 F1000
G1 X172.775 Y197.083 Z-2.719 F1000
G1 X172.742 Y197.093 Z-2.657 F1000
G1 X172.716 Y197.101 Z-2.591 F1000
G1 X172.697 Y197.107 Z-2.522 F1000
G1 X172.685 Y197.111 Z-2.452 F1000
G1 X172.682 Y197.112 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y203.583 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y203.579 Z-2.452 F1000
G1 X22.509 Y203.569 Z-2.522 F1000
G1 X22.499 Y203.552 Z-2.591 F1000
G1 X22.485 Y203.529 Z-2.657 F1000
G1 X22.467 Y203.499 Z-2.719 F1000
G1 X22.446 Y203.464 Z-2.777 F1000
G1 X22.422 Y203.423 Z-2.83 F1000
G1 X22.395 Y203.377 Z-2.877 F1000
G1 X22.365 Y203.327 Z-2.919 F1000
G1 X22.333 Y203.274 Z-2.953 F1000
G1 X22.3 Y203.217 Z-2.98 F1000
G1 X22.265 Y203.158 Z-3 F1000
G1 X22.229 Y203.098 Z-3.012 F1000
G1 X22.192 Y203.037 Z-3.016 F1000
G3 X21.971 Y202.283 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y199.777 F1000
G1 X21.982 Y199.563 F1000
G1 X22.013 Y199.321 F1000
G1 X22.075 Y199.032 F1000
G1 X22.165 Y198.733 F1000
G1 X22.295 Y198.399 F1000
G1 X22.477 Y198.023 F1000
G1 X22.702 Y197.642 F1000
G1 X23.006 Y197.209 F1000
G1 X23.377 Y196.762 F1000
G1 X23.849 Y196.279 F1000
G1 X24.449 Y195.755 F1000
G1 X25.187 Y195.209 F1000
G1 X25.967 Y194.722 F1000
G1 X26.776 Y194.286 F1000
G1 X27.608 Y193.895 F1000
G1 X28.456 Y193.542 F1000
G1 X29.318 Y193.223 F1000
G1 X30.19 Y192.932 F1000
G1 X31.07 Y192.668 F1000
G1 X31.957 Y192.427 F1000
G1 X32.849 Y192.206 F1000
G1 X33.745 Y192.003 F1000
G1 X34.645 Y191.816 F1000
G1 X35.548 Y191.644 F1000
G1 X36.453 Y191.485 F1000
G1 X37.36 Y191.338 F1000
G1 X38.269 Y191.202 F1000
G1 X39.18 Y191.077 F1000
G1 X40.091 Y190.96 F1000
G1 X41.004 Y190.853 F1000
G1 X41.917 Y190.753 F1000
G1 X42.832 Y190.661 F1000
G1 X43.747 Y190.575 F1000
G1 X44.662 Y190.495 F1000
G1 X45.579 Y190.422 F1000
G1 X46.495 Y190.354 F1000
G1 X47.412 Y190.29 F1000
G1 X48.329 Y190.232 F1000
G1 X49.246 Y190.177 F1000
G1 X50.164 Y190.127 F1000
G1 X51.082 Y190.08 F1000
G1 X52 Y190.036 F1000
G1 X52.918 Y189.995 F1000
G1 X53.836 Y189.957 F1000
G1 X54.754 Y189.922 F1000
G1 X55.673 Y189.888 F1000
G1 X56.591 Y189.857 F1000
G1 X57.51 Y189.827 F1000
G1 X58.429 Y189.798 F1000
G1 X60.266 Y189.745 F1000
G1 X63.022 Y189.67 F1000
G1 X65.778 Y189.595 F1000
G1 X67.615 Y189.544 F1000
G1 X69.452 Y189.489 F1000
G1 X70.371 Y189.46 F1000
G1 X71.289 Y189.43 F1000
G1 X72.208 Y189.399 F1000
G1 X73.126 Y189.366 F1000
G1 X74.045 Y189.333 F1000
G1 X74.963 Y189.297 F1000
G1 X75.881 Y189.261 F1000
G1 X76.8 Y189.223 F1000
G1 X77.718 Y189.183 F1000
G1 X78.636 Y189.143 F1000
G1 X79.554 Y189.1 F1000
G1 X80.472 Y189.057 F1000
G1 X81.39 Y189.013 F1000
G1 X83.226 Y188.921 F1000
G1 X85.061 Y188.825 F1000
G1 X86.897 Y188.726 F1000
G1 X90.567 Y188.525 F1000
G1 X94.238 Y188.324 F1000
G1 X96.073 Y188.225 F1000
G1 X97.909 Y188.13 F1000
G1 X99.744 Y188.037 F1000
G1 X100.662 Y187.992 F1000
G1 X101.58 Y187.949 F1000
G1 X102.498 Y187.906 F1000
G1 X103.416 Y187.864 F1000
G1 X104.335 Y187.824 F1000
G1 X105.253 Y187.785 F1000
G1 X106.171 Y187.747 F1000
G1 X107.089 Y187.71 F1000
G1 X108.008 Y187.674 F1000
G1 X108.926 Y187.64 F1000
G1 X109.844 Y187.607 F1000
G1 X110.763 Y187.576 F1000
G1 X111.681 Y187.545 F1000
G1 X112.6 Y187.516 F1000
G1 X113.519 Y187.488 F1000
G1 X114.437 Y187.462 F1000
G1 X115.356 Y187.436 F1000
G1 X116.275 Y187.412 F1000
G1 X117.193 Y187.39 F1000
G1 X118.112 Y187.368 F1000
G1 X119.031 Y187.347 F1000
G1 X119.95 Y187.328 F1000
G1 X120.869 Y187.31 F1000
G1 X121.787 Y187.292 F1000
G1 X122.706 Y187.276 F1000
G1 X124.544 Y187.247 F1000
G1 X126.382 Y187.221 F1000
G1 X128.22 Y187.2 F1000
G1 X130.058 Y187.181 F1000
G1 X131.896 Y187.167 F1000
G1 X133.734 Y187.155 F1000
G1 X135.572 Y187.148 F1000
G1 X137.41 Y187.144 F1000
G1 X138.329 Y187.143 F1000
G1 X139.248 Y187.144 F1000
G1 X140.167 Y187.146 F1000
G1 X141.086 Y187.148 F1000
G1 X142.005 Y187.153 F1000
G1 X142.924 Y187.158 F1000
G1 X143.843 Y187.165 F1000
G1 X144.762 Y187.174 F1000
G1 X145.681 Y187.184 F1000
G1 X146.6 Y187.196 F1000
G1 X147.519 Y187.21 F1000
G1 X148.438 Y187.227 F1000
G1 X149.356 Y187.245 F1000
G1 X150.275 Y187.266 F1000
G1 X151.194 Y187.289 F1000
G1 X152.113 Y187.316 F1000
G1 X153.031 Y187.345 F1000
G1 X153.95 Y187.378 F1000
G1 X154.868 Y187.415 F1000
G1 X155.786 Y187.455 F1000
G1 X156.704 Y187.499 F1000
G1 X157.622 Y187.548 F1000
G1 X158.539 Y187.602 F1000
G1 X159.456 Y187.661 F1000
G1 X160.373 Y187.727 F1000
G1 X161.289 Y187.798 F1000
G1 X162.205 Y187.877 F1000
G1 X163.12 Y187.963 F1000
G1 X164.034 Y188.058 F1000
G1 X164.947 Y188.163 F1000
G1 X165.859 Y188.279 F1000
G1 X166.769 Y188.407 F1000
G1 X167.676 Y188.55 F1000
G1 X168.581 Y188.71 F1000
G1 X169.482 Y188.891 F1000
G1 X170.378 Y189.097 F1000
G1 X171.266 Y189.336 F1000
G1 X172.094 Y189.606 F1000
G1 X172.647 Y189.838 F1000
G1 X172.934 Y189.987 F1000
G1 X173.204 Y190.166 F1000
G1 X173.428 Y190.399 F1000
G1 X173.596 Y190.675 F1000
G1 X173.701 Y190.981 F1000
G1 X173.736 Y191.303 F1000
G1 Y193.822 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y194.406 I-0.635 J-0.022 F1000
G1 X173.221 Y194.427 Z-3.012 F1000
G1 X173.153 Y194.448 Z-3 F1000
G1 X173.088 Y194.468 Z-2.98 F1000
G1 X173.025 Y194.488 Z-2.953 F1000
G1 X172.966 Y194.506 Z-2.919 F1000
G1 X172.91 Y194.523 Z-2.877 F1000
G1 X172.859 Y194.539 Z-2.83 F1000
G1 X172.814 Y194.553 Z-2.777 F1000
G1 X172.775 Y194.565 Z-2.719 F1000
G1 X172.742 Y194.575 Z-2.657 F1000
G1 X172.716 Y194.583 Z-2.591 F1000
G1 X172.697 Y194.589 Z-2.522 F1000
G1 X172.685 Y194.592 Z-2.452 F1000
G1 X172.682 Y194.593 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y201.077 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y201.073 Z-2.452 F1000
G1 X22.509 Y201.063 Z-2.522 F1000
G1 X22.499 Y201.046 Z-2.591 F1000
G1 X22.485 Y201.023 Z-2.657 F1000
G1 X22.467 Y200.993 Z-2.719 F1000
G1 X22.446 Y200.958 Z-2.777 F1000
G1 X22.422 Y200.917 Z-2.83 F1000
G1 X22.395 Y200.871 Z-2.877 F1000
G1 X22.365 Y200.821 Z-2.919 F1000
G1 X22.333 Y200.768 Z-2.953 F1000
G1 X22.3 Y200.711 Z-2.98 F1000
G1 X22.265 Y200.652 Z-3 F1000
G1 X22.229 Y200.592 Z-3.012 F1000
G1 X22.192 Y200.531 Z-3.016 F1000
G3 X21.971 Y199.777 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y197.271 F1000
G1 X21.982 Y197.057 F1000
G1 X22.013 Y196.815 F1000
G1 X22.075 Y196.526 F1000
G1 X22.165 Y196.227 F1000
G1 X22.295 Y195.893 F1000
G1 X22.478 Y195.517 F1000
G1 X22.702 Y195.136 F1000
G1 X23.006 Y194.702 F1000
G1 X23.378 Y194.255 F1000
G1 X23.85 Y193.771 F1000
G1 X24.45 Y193.247 F1000
G1 X25.189 Y192.701 F1000
G1 X25.969 Y192.214 F1000
G1 X26.778 Y191.778 F1000
G1 X27.609 Y191.386 F1000
G1 X28.458 Y191.033 F1000
G1 X29.319 Y190.713 F1000
G1 X30.191 Y190.423 F1000
G1 X31.071 Y190.158 F1000
G1 X31.958 Y189.916 F1000
G1 X32.85 Y189.695 F1000
G1 X33.746 Y189.491 F1000
G1 X34.645 Y189.303 F1000
G1 X35.548 Y189.131 F1000
G1 X36.453 Y188.971 F1000
G1 X37.36 Y188.824 F1000
G1 X38.269 Y188.687 F1000
G1 X39.179 Y188.561 F1000
G1 X40.091 Y188.444 F1000
G1 X41.004 Y188.335 F1000
G1 X41.917 Y188.235 F1000
G1 X42.831 Y188.142 F1000
G1 X43.746 Y188.055 F1000
G1 X44.662 Y187.975 F1000
G1 X45.578 Y187.9 F1000
G1 X46.494 Y187.831 F1000
G1 X47.411 Y187.767 F1000
G1 X48.328 Y187.707 F1000
G1 X49.245 Y187.652 F1000
G1 X50.163 Y187.6 F1000
G1 X51.081 Y187.553 F1000
G1 X51.999 Y187.508 F1000
G1 X52.917 Y187.466 F1000
G1 X53.835 Y187.427 F1000
G1 X54.753 Y187.391 F1000
G1 X55.672 Y187.357 F1000
G1 X56.59 Y187.324 F1000
G1 X57.509 Y187.293 F1000
G1 X58.427 Y187.264 F1000
G1 X60.264 Y187.209 F1000
G1 X63.02 Y187.131 F1000
G1 X65.776 Y187.054 F1000
G1 X67.614 Y187.001 F1000
G1 X69.451 Y186.945 F1000
G1 X70.369 Y186.915 F1000
G1 X71.288 Y186.885 F1000
G1 X72.206 Y186.853 F1000
G1 X73.125 Y186.82 F1000
G1 X74.043 Y186.786 F1000
G1 X74.961 Y186.75 F1000
G1 X75.88 Y186.713 F1000
G1 X76.798 Y186.675 F1000
G1 X77.716 Y186.635 F1000
G1 X78.634 Y186.595 F1000
G1 X79.552 Y186.552 F1000
G1 X80.47 Y186.509 F1000
G1 X81.388 Y186.465 F1000
G1 X83.224 Y186.373 F1000
G1 X85.06 Y186.278 F1000
G1 X87.813 Y186.13 F1000
G1 X93.319 Y185.83 F1000
G1 X95.154 Y185.732 F1000
G1 X96.99 Y185.636 F1000
G1 X98.825 Y185.543 F1000
G1 X100.661 Y185.453 F1000
G1 X101.579 Y185.41 F1000
G1 X102.497 Y185.367 F1000
G1 X103.415 Y185.326 F1000
G1 X104.333 Y185.286 F1000
G1 X105.252 Y185.247 F1000
G1 X106.17 Y185.209 F1000
G1 X107.088 Y185.173 F1000
G1 X108.006 Y185.138 F1000
G1 X108.925 Y185.104 F1000
G1 X109.843 Y185.071 F1000
G1 X110.762 Y185.039 F1000
G1 X111.68 Y185.009 F1000
G1 X112.599 Y184.98 F1000
G1 X113.517 Y184.952 F1000
G1 X114.436 Y184.926 F1000
G1 X115.355 Y184.901 F1000
G1 X116.273 Y184.877 F1000
G1 X117.192 Y184.854 F1000
G1 X118.111 Y184.832 F1000
G1 X119.03 Y184.812 F1000
G1 X119.949 Y184.792 F1000
G1 X120.867 Y184.774 F1000
G1 X121.786 Y184.757 F1000
G1 X123.624 Y184.725 F1000
G1 X125.462 Y184.698 F1000
G1 X127.3 Y184.674 F1000
G1 X129.138 Y184.654 F1000
G1 X130.976 Y184.637 F1000
G1 X132.814 Y184.624 F1000
G1 X134.652 Y184.615 F1000
G1 X136.49 Y184.609 F1000
G1 X137.409 Y184.608 F1000
G1 X138.328 Y184.607 F1000
G1 X139.247 Y184.608 F1000
G1 X140.166 Y184.61 F1000
G1 X141.085 Y184.613 F1000
G1 X142.004 Y184.618 F1000
G1 X142.923 Y184.624 F1000
G1 X143.842 Y184.631 F1000
G1 X144.761 Y184.64 F1000
G1 X145.68 Y184.651 F1000
G1 X146.599 Y184.663 F1000
G1 X147.518 Y184.678 F1000
G1 X148.436 Y184.694 F1000
G1 X149.355 Y184.713 F1000
G1 X150.274 Y184.735 F1000
G1 X151.193 Y184.759 F1000
G1 X152.111 Y184.786 F1000
G1 X153.03 Y184.816 F1000
G1 X153.948 Y184.849 F1000
G1 X154.867 Y184.886 F1000
G1 X155.785 Y184.927 F1000
G1 X156.703 Y184.972 F1000
G1 X157.62 Y185.022 F1000
G1 X158.538 Y185.076 F1000
G1 X159.455 Y185.136 F1000
G1 X160.371 Y185.202 F1000
G1 X161.288 Y185.274 F1000
G1 X162.203 Y185.353 F1000
G1 X163.118 Y185.44 F1000
G1 X164.032 Y185.535 F1000
G1 X164.945 Y185.641 F1000
G1 X165.857 Y185.757 F1000
G1 X166.767 Y185.886 F1000
G1 X167.674 Y186.029 F1000
G1 X168.579 Y186.19 F1000
G1 X169.48 Y186.371 F1000
G1 X170.376 Y186.577 F1000
G1 X171.263 Y186.815 F1000
G1 X172.093 Y187.087 F1000
G1 X172.646 Y187.319 F1000
G1 X172.934 Y187.467 F1000
G1 X173.204 Y187.646 F1000
G1 X173.428 Y187.88 F1000
G1 X173.596 Y188.156 F1000
G1 X173.701 Y188.462 F1000
G1 X173.736 Y188.784 F1000
G1 Y191.303 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y191.888 I-0.635 J-0.022 F1000
G1 X173.221 Y191.909 Z-3.012 F1000
G1 X173.153 Y191.929 Z-3 F1000
G1 X173.088 Y191.949 Z-2.98 F1000
G1 X173.025 Y191.969 Z-2.953 F1000
G1 X172.966 Y191.987 Z-2.919 F1000
G1 X172.91 Y192.004 Z-2.877 F1000
G1 X172.859 Y192.02 Z-2.83 F1000
G1 X172.814 Y192.034 Z-2.777 F1000
G1 X172.775 Y192.046 Z-2.719 F1000
G1 X172.742 Y192.056 Z-2.657 F1000
G1 X172.716 Y192.064 Z-2.591 F1000
G1 X172.697 Y192.07 Z-2.522 F1000
G1 X172.685 Y192.074 Z-2.452 F1000
G1 X172.682 Y192.075 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y198.571 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y198.567 Z-2.452 F1000
G1 X22.509 Y198.557 Z-2.522 F1000
G1 X22.499 Y198.54 Z-2.591 F1000
G1 X22.485 Y198.517 Z-2.657 F1000
G1 X22.467 Y198.487 Z-2.719 F1000
G1 X22.446 Y198.452 Z-2.777 F1000
G1 X22.422 Y198.411 Z-2.83 F1000
G1 X22.395 Y198.365 Z-2.877 F1000
G1 X22.365 Y198.315 Z-2.919 F1000
G1 X22.333 Y198.262 Z-2.953 F1000
G1 X22.3 Y198.205 Z-2.98 F1000
G1 X22.265 Y198.146 Z-3 F1000
G1 X22.229 Y198.086 Z-3.012 F1000
G1 X22.192 Y198.025 Z-3.016 F1000
G3 X21.971 Y197.271 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y194.765 F1000
G1 X21.982 Y194.551 F1000
G1 X22.013 Y194.309 F1000
G1 X22.075 Y194.02 F1000
G1 X22.165 Y193.72 F1000
G1 X22.295 Y193.386 F1000
G1 X22.478 Y193.01 F1000
G1 X22.702 Y192.628 F1000
G1 X23.007 Y192.195 F1000
G1 X23.378 Y191.747 F1000
G1 X23.851 Y191.263 F1000
G1 X24.452 Y190.738 F1000
G1 X25.191 Y190.192 F1000
G1 X25.97 Y189.705 F1000
G1 X26.779 Y189.269 F1000
G1 X27.611 Y188.877 F1000
G1 X28.459 Y188.524 F1000
G1 X29.32 Y188.204 F1000
G1 X30.192 Y187.913 F1000
G1 X31.072 Y187.648 F1000
G1 X31.959 Y187.405 F1000
G1 X32.85 Y187.183 F1000
G1 X33.746 Y186.979 F1000
G1 X34.646 Y186.791 F1000
G1 X35.548 Y186.617 F1000
G1 X36.453 Y186.457 F1000
G1 X37.36 Y186.309 F1000
G1 X38.269 Y186.172 F1000
G1 X39.179 Y186.045 F1000
G1 X40.091 Y185.927 F1000
G1 X41.003 Y185.818 F1000
G1 X41.917 Y185.716 F1000
G1 X42.831 Y185.622 F1000
G1 X43.746 Y185.535 F1000
G1 X44.661 Y185.454 F1000
G1 X45.577 Y185.378 F1000
G1 X46.493 Y185.308 F1000
G1 X47.41 Y185.243 F1000
G1 X48.327 Y185.183 F1000
G1 X49.244 Y185.127 F1000
G1 X50.162 Y185.074 F1000
G1 X51.08 Y185.025 F1000
G1 X51.998 Y184.98 F1000
G1 X52.916 Y184.937 F1000
G1 X53.834 Y184.898 F1000
G1 X54.752 Y184.86 F1000
G1 X55.67 Y184.825 F1000
G1 X56.589 Y184.792 F1000
G1 X57.507 Y184.76 F1000
G1 X58.426 Y184.73 F1000
G1 X60.263 Y184.673 F1000
G1 X63.019 Y184.592 F1000
G1 X66.693 Y184.485 F1000
G1 X68.531 Y184.43 F1000
G1 X69.449 Y184.4 F1000
G1 X70.368 Y184.37 F1000
G1 X71.286 Y184.339 F1000
G1 X72.205 Y184.307 F1000
G1 X73.123 Y184.274 F1000
G1 X74.041 Y184.239 F1000
G1 X74.96 Y184.203 F1000
G1 X75.878 Y184.166 F1000
G1 X76.796 Y184.127 F1000
G1 X77.714 Y184.088 F1000
G1 X78.633 Y184.047 F1000
G1 X79.551 Y184.005 F1000
G1 X80.469 Y183.961 F1000
G1 X82.304 Y183.872 F1000
G1 X84.14 Y183.779 F1000
G1 X85.976 Y183.683 F1000
G1 X88.729 Y183.535 F1000
G1 X93.317 Y183.287 F1000
G1 X95.153 Y183.19 F1000
G1 X96.988 Y183.095 F1000
G1 X98.824 Y183.003 F1000
G1 X100.66 Y182.914 F1000
G1 X101.578 Y182.871 F1000
G1 X102.496 Y182.829 F1000
G1 X103.414 Y182.788 F1000
G1 X104.332 Y182.748 F1000
G1 X105.25 Y182.71 F1000
G1 X106.169 Y182.672 F1000
G1 X107.087 Y182.636 F1000
G1 X108.005 Y182.601 F1000
G1 X108.924 Y182.567 F1000
G1 X109.842 Y182.535 F1000
G1 X110.761 Y182.503 F1000
G1 X111.679 Y182.473 F1000
G1 X112.598 Y182.444 F1000
G1 X113.516 Y182.417 F1000
G1 X114.435 Y182.39 F1000
G1 X115.354 Y182.365 F1000
G1 X116.272 Y182.341 F1000
G1 X117.191 Y182.318 F1000
G1 X118.11 Y182.296 F1000
G1 X119.029 Y182.276 F1000
G1 X119.947 Y182.256 F1000
G1 X120.866 Y182.238 F1000
G1 X121.785 Y182.221 F1000
G1 X123.623 Y182.189 F1000
G1 X125.461 Y182.161 F1000
G1 X127.299 Y182.138 F1000
G1 X129.137 Y182.117 F1000
G1 X130.975 Y182.101 F1000
G1 X132.813 Y182.088 F1000
G1 X134.651 Y182.079 F1000
G1 X136.489 Y182.073 F1000
G1 X137.408 Y182.072 F1000
G1 X138.327 F1000
G1 X139.246 Y182.073 F1000
G1 X140.165 Y182.075 F1000
G1 X141.084 Y182.078 F1000
G1 X142.003 Y182.083 F1000
G1 X142.922 Y182.089 F1000
G1 X143.841 Y182.097 F1000
G1 X144.76 Y182.106 F1000
G1 X145.679 Y182.117 F1000
G1 X146.598 Y182.13 F1000
G1 X147.516 Y182.145 F1000
G1 X148.435 Y182.162 F1000
G1 X149.354 Y182.182 F1000
G1 X150.273 Y182.204 F1000
G1 X151.192 Y182.228 F1000
G1 X152.11 Y182.256 F1000
G1 X153.029 Y182.286 F1000
G1 X153.947 Y182.32 F1000
G1 X154.865 Y182.358 F1000
G1 X155.783 Y182.399 F1000
G1 X156.701 Y182.445 F1000
G1 X157.619 Y182.495 F1000
G1 X158.536 Y182.55 F1000
G1 X159.453 Y182.611 F1000
G1 X160.37 Y182.677 F1000
G1 X161.286 Y182.749 F1000
G1 X162.202 Y182.829 F1000
G1 X163.117 Y182.916 F1000
G1 X164.031 Y183.012 F1000
G1 X164.943 Y183.118 F1000
G1 X165.855 Y183.235 F1000
G1 X166.765 Y183.364 F1000
G1 X167.673 Y183.508 F1000
G1 X168.577 Y183.669 F1000
G1 X169.478 Y183.85 F1000
G1 X170.374 Y184.056 F1000
G1 X171.261 Y184.295 F1000
G1 X172.092 Y184.567 F1000
G1 X172.646 Y184.799 F1000
G1 X172.934 Y184.948 F1000
G1 X173.204 Y185.127 F1000
G1 X173.428 Y185.36 F1000
G1 X173.596 Y185.636 F1000
G1 X173.701 Y185.943 F1000
G1 X173.736 Y186.264 F1000
G1 Y188.784 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y189.368 I-0.635 J-0.022 F1000
G1 X173.221 Y189.389 Z-3.012 F1000
G1 X173.153 Y189.41 Z-3 F1000
G1 X173.088 Y189.43 Z-2.98 F1000
G1 X173.025 Y189.45 Z-2.953 F1000
G1 X172.966 Y189.468 Z-2.919 F1000
G1 X172.91 Y189.485 Z-2.877 F1000
G1 X172.859 Y189.501 Z-2.83 F1000
G1 X172.814 Y189.515 Z-2.777 F1000
G1 X172.775 Y189.527 Z-2.719 F1000
G1 X172.742 Y189.537 Z-2.657 F1000
G1 X172.716 Y189.545 Z-2.591 F1000
G1 X172.697 Y189.551 Z-2.522 F1000
G1 X172.685 Y189.554 Z-2.452 F1000
G1 X172.682 Y189.556 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y196.065 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y196.061 Z-2.452 F1000
G1 X22.509 Y196.051 Z-2.522 F1000
G1 X22.499 Y196.034 Z-2.591 F1000
G1 X22.485 Y196.011 Z-2.657 F1000
G1 X22.467 Y195.981 Z-2.719 F1000
G1 X22.446 Y195.946 Z-2.777 F1000
G1 X22.422 Y195.905 Z-2.83 F1000
G1 X22.395 Y195.859 Z-2.877 F1000
G1 X22.365 Y195.809 Z-2.919 F1000
G1 X22.333 Y195.756 Z-2.953 F1000
G1 X22.3 Y195.699 Z-2.98 F1000
G1 X22.265 Y195.64 Z-3 F1000
G1 X22.229 Y195.58 Z-3.012 F1000
G1 X22.192 Y195.519 Z-3.016 F1000
G3 X21.971 Y194.765 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y192.259 F1000
G1 X21.982 Y192.044 F1000
G1 X22.014 Y191.801 F1000
G1 X22.075 Y191.513 F1000
G1 X22.165 Y191.213 F1000
G1 X22.295 Y190.879 F1000
G1 X22.478 Y190.502 F1000
G1 X22.703 Y190.121 F1000
G1 X23.007 Y189.687 F1000
G1 X23.379 Y189.239 F1000
G1 X23.852 Y188.754 F1000
G1 X24.454 Y188.229 F1000
G1 X25.193 Y187.683 F1000
G1 X25.972 Y187.195 F1000
G1 X26.781 Y186.759 F1000
G1 X27.612 Y186.367 F1000
G1 X28.46 Y186.014 F1000
G1 X29.322 Y185.693 F1000
G1 X30.193 Y185.402 F1000
G1 X31.073 Y185.136 F1000
G1 X31.959 Y184.893 F1000
G1 X32.851 Y184.671 F1000
G1 X33.747 Y184.466 F1000
G1 X34.646 Y184.277 F1000
G1 X35.549 Y184.103 F1000
G1 X36.454 Y183.942 F1000
G1 X37.361 Y183.794 F1000
G1 X38.269 Y183.656 F1000
G1 X39.179 Y183.528 F1000
G1 X40.091 Y183.409 F1000
G1 X41.003 Y183.299 F1000
G1 X41.916 Y183.197 F1000
G1 X42.83 Y183.102 F1000
G1 X43.745 Y183.014 F1000
G1 X44.661 Y182.932 F1000
G1 X45.576 Y182.856 F1000
G1 X46.493 Y182.785 F1000
G1 X47.409 Y182.72 F1000
G1 X48.326 Y182.658 F1000
G1 X49.244 Y182.601 F1000
G1 X50.161 Y182.548 F1000
G1 X51.079 Y182.498 F1000
G1 X51.997 Y182.452 F1000
G1 X52.915 Y182.408 F1000
G1 X53.833 Y182.368 F1000
G1 X54.751 Y182.329 F1000
G1 X55.669 Y182.293 F1000
G1 X56.588 Y182.259 F1000
G1 X57.506 Y182.226 F1000
G1 X58.425 Y182.195 F1000
G1 X60.262 Y182.136 F1000
G1 X63.017 Y182.053 F1000
G1 X66.692 Y181.943 F1000
G1 X68.529 Y181.886 F1000
G1 X69.448 Y181.856 F1000
G1 X71.285 Y181.794 F1000
G1 X72.203 Y181.761 F1000
G1 X73.121 Y181.727 F1000
G1 X74.04 Y181.692 F1000
G1 X74.958 Y181.656 F1000
G1 X75.876 Y181.619 F1000
G1 X76.795 Y181.58 F1000
G1 X77.713 Y181.54 F1000
G1 X78.631 Y181.499 F1000
G1 X79.549 Y181.457 F1000
G1 X81.385 Y181.37 F1000
G1 X83.221 Y181.279 F1000
G1 X85.056 Y181.184 F1000
G1 X87.809 Y181.039 F1000
G1 X93.316 Y180.745 F1000
G1 X95.151 Y180.648 F1000
G1 X96.987 Y180.554 F1000
G1 X98.823 Y180.463 F1000
G1 X100.659 Y180.375 F1000
G1 X102.495 Y180.29 F1000
G1 X103.413 Y180.25 F1000
G1 X104.331 Y180.21 F1000
G1 X105.249 Y180.172 F1000
G1 X106.167 Y180.135 F1000
G1 X107.086 Y180.099 F1000
G1 X108.004 Y180.064 F1000
G1 X108.923 Y180.03 F1000
G1 X109.841 Y179.998 F1000
G1 X110.759 Y179.967 F1000
G1 X111.678 Y179.937 F1000
G1 X112.597 Y179.908 F1000
G1 X113.515 Y179.881 F1000
G1 X114.434 Y179.854 F1000
G1 X115.352 Y179.829 F1000
G1 X116.271 Y179.805 F1000
G1 X117.19 Y179.782 F1000
G1 X118.109 Y179.761 F1000
G1 X119.027 Y179.74 F1000
G1 X119.946 Y179.72 F1000
G1 X120.865 Y179.702 F1000
G1 X121.784 Y179.685 F1000
G1 X123.622 Y179.653 F1000
G1 X125.46 Y179.625 F1000
G1 X127.297 Y179.601 F1000
G1 X129.135 Y179.581 F1000
G1 X130.973 Y179.565 F1000
G1 X132.811 Y179.552 F1000
G1 X134.649 Y179.542 F1000
G1 X136.487 Y179.537 F1000
G1 X137.406 Y179.536 F1000
G1 X138.325 F1000
G1 X139.244 Y179.537 F1000
G1 X140.163 Y179.54 F1000
G1 X141.083 Y179.543 F1000
G1 X142.002 Y179.548 F1000
G1 X142.921 Y179.555 F1000
G1 X143.84 Y179.563 F1000
G1 X144.758 Y179.573 F1000
G1 X145.677 Y179.584 F1000
G1 X146.596 Y179.597 F1000
G1 X147.515 Y179.613 F1000
G1 X148.434 Y179.63 F1000
G1 X149.353 Y179.65 F1000
G1 X150.272 Y179.673 F1000
G1 X151.19 Y179.698 F1000
G1 X152.109 Y179.726 F1000
G1 X153.027 Y179.757 F1000
G1 X153.946 Y179.791 F1000
G1 X154.864 Y179.83 F1000
G1 X155.782 Y179.872 F1000
G1 X156.7 Y179.918 F1000
G1 X157.618 Y179.968 F1000
G1 X158.535 Y180.024 F1000
G1 X159.452 Y180.085 F1000
G1 X160.368 Y180.152 F1000
G1 X161.285 Y180.225 F1000
G1 X162.2 Y180.305 F1000
G1 X163.115 Y180.393 F1000
G1 X164.029 Y180.489 F1000
G1 X164.942 Y180.596 F1000
G1 X165.853 Y180.713 F1000
G1 X166.763 Y180.842 F1000
G1 X167.671 Y180.987 F1000
G1 X168.576 Y181.148 F1000
G1 X169.476 Y181.329 F1000
G1 X170.372 Y181.535 F1000
G1 X171.259 Y181.774 F1000
G1 X172.091 Y182.047 F1000
G1 X172.645 Y182.279 F1000
G1 X172.935 Y182.428 F1000
G1 X173.204 Y182.607 F1000
G1 X173.428 Y182.84 F1000
G1 X173.596 Y183.117 F1000
G1 X173.701 Y183.423 F1000
G1 X173.736 Y183.744 F1000
G1 Y186.264 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y186.849 I-0.635 J-0.022 F1000
G1 X173.221 Y186.87 Z-3.012 F1000
G1 X173.153 Y186.891 Z-3 F1000
G1 X173.088 Y186.911 Z-2.98 F1000
G1 X173.025 Y186.93 Z-2.953 F1000
G1 X172.966 Y186.948 Z-2.919 F1000
G1 X172.91 Y186.966 Z-2.877 F1000
G1 X172.859 Y186.981 Z-2.83 F1000
G1 X172.814 Y186.995 Z-2.777 F1000
G1 X172.775 Y187.007 Z-2.719 F1000
G1 X172.742 Y187.018 Z-2.657 F1000
G1 X172.716 Y187.026 Z-2.591 F1000
G1 X172.697 Y187.031 Z-2.522 F1000
G1 X172.685 Y187.035 Z-2.452 F1000
G1 X172.682 Y187.036 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y193.559 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y193.555 Z-2.452 F1000
G1 X22.509 Y193.545 Z-2.522 F1000
G1 X22.499 Y193.528 Z-2.591 F1000
G1 X22.485 Y193.505 Z-2.657 F1000
G1 X22.467 Y193.475 Z-2.719 F1000
G1 X22.446 Y193.44 Z-2.777 F1000
G1 X22.422 Y193.399 Z-2.83 F1000
G1 X22.395 Y193.353 Z-2.877 F1000
G1 X22.365 Y193.303 Z-2.919 F1000
G1 X22.333 Y193.25 Z-2.953 F1000
G1 X22.3 Y193.193 Z-2.98 F1000
G1 X22.265 Y193.134 Z-3 F1000
G1 X22.229 Y193.074 Z-3.012 F1000
G1 X22.192 Y193.013 Z-3.016 F1000
G3 X21.971 Y192.259 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y189.753 F1000
G1 X21.982 Y189.536 F1000
G1 X22.014 Y189.294 F1000
G1 X22.075 Y189.005 F1000
G1 X22.165 Y188.704 F1000
G1 X22.295 Y188.37 F1000
G1 X22.478 Y187.993 F1000
G1 X22.703 Y187.612 F1000
G1 X23.008 Y187.178 F1000
G1 X23.38 Y186.73 F1000
G1 X23.853 Y186.245 F1000
G1 X24.455 Y185.719 F1000
G1 X25.194 Y185.173 F1000
G1 X25.973 Y184.685 F1000
G1 X26.782 Y184.249 F1000
G1 X27.614 Y183.857 F1000
G1 X28.462 Y183.503 F1000
G1 X29.323 Y183.182 F1000
G1 X30.194 Y182.891 F1000
G1 X31.074 Y182.625 F1000
G1 X31.96 Y182.381 F1000
G1 X32.852 Y182.158 F1000
G1 X33.748 Y181.953 F1000
G1 X34.647 Y181.763 F1000
G1 X35.549 Y181.589 F1000
G1 X36.454 Y181.427 F1000
G1 X37.361 Y181.278 F1000
G1 X38.269 Y181.139 F1000
G1 X39.179 Y181.011 F1000
G1 X40.09 Y180.892 F1000
G1 X41.003 Y180.781 F1000
G1 X41.916 Y180.678 F1000
G1 X42.83 Y180.583 F1000
G1 X43.745 Y180.494 F1000
G1 X44.66 Y180.411 F1000
G1 X45.576 Y180.334 F1000
G1 X46.492 Y180.262 F1000
G1 X47.409 Y180.196 F1000
G1 X48.326 Y180.133 F1000
G1 X49.243 Y180.075 F1000
G1 X50.16 Y180.021 F1000
G1 X51.078 Y179.971 F1000
G1 X51.996 Y179.923 F1000
G1 X52.914 Y179.879 F1000
G1 X53.832 Y179.838 F1000
G1 X54.75 Y179.798 F1000
G1 X55.668 Y179.761 F1000
G1 X56.586 Y179.726 F1000
G1 X57.505 Y179.693 F1000
G1 X58.423 Y179.661 F1000
G1 X60.26 Y179.6 F1000
G1 X63.016 Y179.514 F1000
G1 X66.69 Y179.401 F1000
G1 X68.528 Y179.343 F1000
G1 X69.446 Y179.312 F1000
G1 X71.283 Y179.249 F1000
G1 X72.201 Y179.216 F1000
G1 X73.12 Y179.181 F1000
G1 X74.038 Y179.146 F1000
G1 X74.956 Y179.11 F1000
G1 X75.875 Y179.072 F1000
G1 X76.793 Y179.033 F1000
G1 X77.711 Y178.993 F1000
G1 X78.629 Y178.952 F1000
G1 X79.547 Y178.91 F1000
G1 X81.383 Y178.823 F1000
G1 X83.219 Y178.732 F1000
G1 X85.055 Y178.638 F1000
G1 X87.808 Y178.494 F1000
G1 X93.314 Y178.202 F1000
G1 X95.15 Y178.107 F1000
G1 X96.986 Y178.013 F1000
G1 X98.821 Y177.923 F1000
G1 X100.657 Y177.835 F1000
G1 X102.493 Y177.752 F1000
G1 X103.412 Y177.712 F1000
G1 X104.33 Y177.673 F1000
G1 X105.248 Y177.634 F1000
G1 X106.166 Y177.598 F1000
G1 X107.085 Y177.562 F1000
G1 X108.003 Y177.527 F1000
G1 X108.921 Y177.494 F1000
G1 X109.84 Y177.461 F1000
G1 X110.758 Y177.43 F1000
G1 X111.677 Y177.401 F1000
G1 X112.595 Y177.372 F1000
G1 X113.514 Y177.344 F1000
G1 X114.433 Y177.318 F1000
G1 X115.351 Y177.293 F1000
G1 X116.27 Y177.269 F1000
G1 X117.189 Y177.246 F1000
G1 X118.108 Y177.225 F1000
G1 X119.026 Y177.204 F1000
G1 X119.945 Y177.185 F1000
G1 X120.864 Y177.166 F1000
G1 X121.783 Y177.149 F1000
G1 X123.621 Y177.117 F1000
G1 X125.458 Y177.089 F1000
G1 X127.296 Y177.065 F1000
G1 X129.134 Y177.045 F1000
G1 X130.972 Y177.028 F1000
G1 X132.81 Y177.015 F1000
G1 X134.648 Y177.006 F1000
G1 X135.567 Y177.003 F1000
G1 X136.486 Y177.001 F1000
G1 X137.405 Y177 F1000
G1 X138.324 Y177.001 F1000
G1 X139.243 Y177.002 F1000
G1 X140.162 Y177.005 F1000
G1 X141.081 Y177.008 F1000
G1 X142 Y177.014 F1000
G1 X142.919 Y177.021 F1000
G1 X143.838 Y177.029 F1000
G1 X144.757 Y177.039 F1000
G1 X145.676 Y177.051 F1000
G1 X146.595 Y177.065 F1000
G1 X147.514 Y177.08 F1000
G1 X148.433 Y177.098 F1000
G1 X149.352 Y177.119 F1000
G1 X150.27 Y177.142 F1000
G1 X151.189 Y177.167 F1000
G1 X152.108 Y177.196 F1000
G1 X153.026 Y177.227 F1000
G1 X153.945 Y177.262 F1000
G1 X154.863 Y177.301 F1000
G1 X155.781 Y177.344 F1000
G1 X156.699 Y177.39 F1000
G1 X157.616 Y177.442 F1000
G1 X158.533 Y177.498 F1000
G1 X159.45 Y177.559 F1000
G1 X160.367 Y177.627 F1000
G1 X161.283 Y177.7 F1000
G1 X162.199 Y177.781 F1000
G1 X163.113 Y177.869 F1000
G1 X164.027 Y177.966 F1000
G1 X164.94 Y178.073 F1000
G1 X165.852 Y178.19 F1000
G1 X166.761 Y178.32 F1000
G1 X167.669 Y178.465 F1000
G1 X168.574 Y178.626 F1000
G1 X169.475 Y178.808 F1000
G1 X170.37 Y179.014 F1000
G1 X171.257 Y179.253 F1000
G1 X172.09 Y179.526 F1000
G1 X172.645 Y179.758 F1000
G1 X172.935 Y179.908 F1000
G1 X173.204 Y180.087 F1000
G1 X173.428 Y180.32 F1000
G1 X173.596 Y180.596 F1000
G1 X173.701 Y180.903 F1000
G1 X173.736 Y181.224 F1000
G1 Y183.744 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y184.329 I-0.635 J-0.022 F1000
G1 X173.221 Y184.35 Z-3.012 F1000
G1 X173.153 Y184.371 Z-3 F1000
G1 X173.088 Y184.391 Z-2.98 F1000
G1 X173.025 Y184.41 Z-2.953 F1000
G1 X172.966 Y184.429 Z-2.919 F1000
G1 X172.91 Y184.446 Z-2.877 F1000
G1 X172.859 Y184.461 Z-2.83 F1000
G1 X172.814 Y184.475 Z-2.777 F1000
G1 X172.775 Y184.488 Z-2.719 F1000
G1 X172.742 Y184.498 Z-2.657 F1000
G1 X172.716 Y184.506 Z-2.591 F1000
G1 X172.697 Y184.511 Z-2.522 F1000
G1 X172.685 Y184.515 Z-2.452 F1000
G1 X172.682 Y184.516 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y191.053 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y191.049 Z-2.452 F1000
G1 X22.509 Y191.039 Z-2.522 F1000
G1 X22.499 Y191.022 Z-2.591 F1000
G1 X22.485 Y190.999 Z-2.657 F1000
G1 X22.467 Y190.969 Z-2.719 F1000
G1 X22.446 Y190.934 Z-2.777 F1000
G1 X22.422 Y190.893 Z-2.83 F1000
G1 X22.395 Y190.847 Z-2.877 F1000
G1 X22.365 Y190.797 Z-2.919 F1000
G1 X22.333 Y190.744 Z-2.953 F1000
G1 X22.3 Y190.687 Z-2.98 F1000
G1 X22.265 Y190.628 Z-3 F1000
G1 X22.229 Y190.568 Z-3.012 F1000
G1 X22.192 Y190.507 Z-3.016 F1000
G3 X21.971 Y189.753 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y187.247 F1000
G1 X21.982 Y187.027 F1000
G1 X22.014 Y186.785 F1000
G1 X22.076 Y186.496 F1000
G1 X22.166 Y186.196 F1000
G1 X22.296 Y185.862 F1000
G1 X22.479 Y185.484 F1000
G1 X22.703 Y185.103 F1000
G1 X23.008 Y184.669 F1000
G1 X23.381 Y184.22 F1000
G1 X23.854 Y183.735 F1000
G1 X24.457 Y183.209 F1000
G1 X25.196 Y182.662 F1000
G1 X25.975 Y182.175 F1000
G1 X26.784 Y181.739 F1000
G1 X27.615 Y181.346 F1000
G1 X28.463 Y180.992 F1000
G1 X29.324 Y180.671 F1000
G1 X30.195 Y180.379 F1000
G1 X31.075 Y180.112 F1000
G1 X31.961 Y179.869 F1000
G1 X32.852 Y179.645 F1000
G1 X33.748 Y179.439 F1000
G1 X34.647 Y179.249 F1000
G1 X35.55 Y179.074 F1000
G1 X36.454 Y178.912 F1000
G1 X37.361 Y178.762 F1000
G1 X38.269 Y178.623 F1000
G1 X39.179 Y178.494 F1000
G1 X40.09 Y178.374 F1000
G1 X41.003 Y178.262 F1000
G1 X41.916 Y178.159 F1000
G1 X42.83 Y178.062 F1000
G1 X43.744 Y177.973 F1000
G1 X44.66 Y177.889 F1000
G1 X45.575 Y177.811 F1000
G1 X46.491 Y177.739 F1000
G1 X47.408 Y177.671 F1000
G1 X48.325 Y177.608 F1000
G1 X49.242 Y177.549 F1000
G1 X50.159 Y177.495 F1000
G1 X51.077 Y177.443 F1000
G1 X51.995 Y177.395 F1000
G1 X52.913 Y177.35 F1000
G1 X53.831 Y177.307 F1000
G1 X54.749 Y177.267 F1000
G1 X55.667 Y177.229 F1000
G1 X56.585 Y177.193 F1000
G1 X57.504 Y177.159 F1000
G1 X58.422 Y177.126 F1000
G1 X60.259 Y177.064 F1000
G1 X63.015 Y176.975 F1000
G1 X66.689 Y176.86 F1000
G1 X68.526 Y176.799 F1000
G1 X69.445 Y176.768 F1000
G1 X71.281 Y176.704 F1000
G1 X72.2 Y176.67 F1000
G1 X73.118 Y176.636 F1000
G1 X74.037 Y176.6 F1000
G1 X74.955 Y176.563 F1000
G1 X75.873 Y176.525 F1000
G1 X76.791 Y176.486 F1000
G1 X77.709 Y176.446 F1000
G1 X79.546 Y176.363 F1000
G1 X81.382 Y176.276 F1000
G1 X83.217 Y176.185 F1000
G1 X85.053 Y176.092 F1000
G1 X87.806 Y175.949 F1000
G1 X93.313 Y175.659 F1000
G1 X96.066 Y175.518 F1000
G1 X97.902 Y175.427 F1000
G1 X99.738 Y175.339 F1000
G1 X101.574 Y175.254 F1000
G1 X103.41 Y175.173 F1000
G1 X104.329 Y175.135 F1000
G1 X105.247 Y175.097 F1000
G1 X106.165 Y175.06 F1000
G1 X107.083 Y175.025 F1000
G1 X108.002 Y174.99 F1000
G1 X108.92 Y174.957 F1000
G1 X109.839 Y174.925 F1000
G1 X110.757 Y174.894 F1000
G1 X111.676 Y174.864 F1000
G1 X112.594 Y174.836 F1000
G1 X113.513 Y174.808 F1000
G1 X114.432 Y174.782 F1000
G1 X115.35 Y174.757 F1000
G1 X116.269 Y174.733 F1000
G1 X117.188 Y174.71 F1000
G1 X118.106 Y174.689 F1000
G1 X119.025 Y174.668 F1000
G1 X119.944 Y174.649 F1000
G1 X120.863 Y174.63 F1000
G1 X121.782 Y174.613 F1000
G1 X123.62 Y174.581 F1000
G1 X125.457 Y174.553 F1000
G1 X127.295 Y174.529 F1000
G1 X129.133 Y174.509 F1000
G1 X130.971 Y174.492 F1000
G1 X132.809 Y174.479 F1000
G1 X134.647 Y174.47 F1000
G1 X135.566 Y174.467 F1000
G1 X136.485 Y174.466 F1000
G1 X137.404 Y174.465 F1000
G1 X138.323 F1000
G1 X139.242 Y174.467 F1000
G1 X140.161 Y174.47 F1000
G1 X141.08 Y174.474 F1000
G1 X141.999 Y174.479 F1000
G1 X142.918 Y174.486 F1000
G1 X143.837 Y174.495 F1000
G1 X144.756 Y174.505 F1000
G1 X145.675 Y174.518 F1000
G1 X146.594 Y174.532 F1000
G1 X147.513 Y174.548 F1000
G1 X148.432 Y174.566 F1000
G1 X149.351 Y174.587 F1000
G1 X150.269 Y174.611 F1000
G1 X151.188 Y174.637 F1000
G1 X152.107 Y174.666 F1000
G1 X153.025 Y174.698 F1000
G1 X153.943 Y174.734 F1000
G1 X154.861 Y174.773 F1000
G1 X155.78 Y174.816 F1000
G1 X156.697 Y174.863 F1000
G1 X157.615 Y174.915 F1000
G1 X158.532 Y174.971 F1000
G1 X159.449 Y175.033 F1000
G1 X160.366 Y175.101 F1000
G1 X161.282 Y175.175 F1000
G1 X162.197 Y175.256 F1000
G1 X163.112 Y175.345 F1000
G1 X164.026 Y175.443 F1000
G1 X164.938 Y175.55 F1000
G1 X165.85 Y175.668 F1000
G1 X166.76 Y175.798 F1000
G1 X167.667 Y175.943 F1000
G1 X168.572 Y176.104 F1000
G1 X169.473 Y176.286 F1000
G1 X170.368 Y176.493 F1000
G1 X171.255 Y176.732 F1000
G1 X172.09 Y177.005 F1000
G1 X172.645 Y177.238 F1000
G1 X172.935 Y177.388 F1000
G1 X173.204 Y177.567 F1000
G1 X173.428 Y177.8 F1000
G1 X173.596 Y178.076 F1000
G1 X173.701 Y178.382 F1000
G1 X173.736 Y178.704 F1000
G1 Y181.224 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y181.809 I-0.635 J-0.022 F1000
G1 X173.221 Y181.83 Z-3.012 F1000
G1 X173.153 Y181.851 Z-3 F1000
G1 X173.088 Y181.871 Z-2.98 F1000
G1 X173.025 Y181.89 Z-2.953 F1000
G1 X172.966 Y181.908 Z-2.919 F1000
G1 X172.91 Y181.926 Z-2.877 F1000
G1 X172.859 Y181.941 Z-2.83 F1000
G1 X172.814 Y181.955 Z-2.777 F1000
G1 X172.775 Y181.967 Z-2.719 F1000
G1 X172.742 Y181.977 Z-2.657 F1000
G1 X172.716 Y181.986 Z-2.591 F1000
G1 X172.697 Y181.991 Z-2.522 F1000
G1 X172.685 Y181.995 Z-2.452 F1000
G1 X172.682 Y181.996 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y188.547 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y188.543 Z-2.452 F1000
G1 X22.509 Y188.533 Z-2.522 F1000
G1 X22.499 Y188.516 Z-2.591 F1000
G1 X22.485 Y188.493 Z-2.657 F1000
G1 X22.467 Y188.463 Z-2.719 F1000
G1 X22.446 Y188.428 Z-2.777 F1000
G1 X22.422 Y188.387 Z-2.83 F1000
G1 X22.395 Y188.341 Z-2.877 F1000
G1 X22.365 Y188.291 Z-2.919 F1000
G1 X22.333 Y188.238 Z-2.953 F1000
G1 X22.3 Y188.181 Z-2.98 F1000
G1 X22.265 Y188.122 Z-3 F1000
G1 X22.229 Y188.062 Z-3.012 F1000
G1 X22.192 Y188.001 Z-3.016 F1000
G3 X21.971 Y187.247 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y184.741 F1000
G1 X21.982 Y184.518 F1000
G1 X22.014 Y184.276 F1000
G1 X22.076 Y183.987 F1000
G1 X22.166 Y183.686 F1000
G1 X22.296 Y183.352 F1000
G1 X22.479 Y182.975 F1000
G1 X22.704 Y182.593 F1000
G1 X23.009 Y182.159 F1000
G1 X23.381 Y181.71 F1000
G1 X23.855 Y181.224 F1000
G1 X24.459 Y180.698 F1000
G1 X25.198 Y180.151 F1000
G1 X25.977 Y179.664 F1000
G1 X26.785 Y179.227 F1000
G1 X27.616 Y178.835 F1000
G1 X28.464 Y178.48 F1000
G1 X29.325 Y178.159 F1000
G1 X30.197 Y177.866 F1000
G1 X31.076 Y177.6 F1000
G1 X31.962 Y177.355 F1000
G1 X32.853 Y177.131 F1000
G1 X33.749 Y176.925 F1000
G1 X34.648 Y176.735 F1000
G1 X35.55 Y176.559 F1000
G1 X36.454 Y176.396 F1000
G1 X37.361 Y176.245 F1000
G1 X38.269 Y176.106 F1000
G1 X39.179 Y175.976 F1000
G1 X40.09 Y175.855 F1000
G1 X41.002 Y175.743 F1000
G1 X41.916 Y175.639 F1000
G1 X42.829 Y175.542 F1000
G1 X43.744 Y175.451 F1000
G1 X44.659 Y175.367 F1000
G1 X45.575 Y175.288 F1000
G1 X46.491 Y175.215 F1000
G1 X47.407 Y175.147 F1000
G1 X48.324 Y175.083 F1000
G1 X49.241 Y175.023 F1000
G1 X50.159 Y174.968 F1000
G1 X51.076 Y174.915 F1000
G1 X51.994 Y174.866 F1000
G1 X52.912 Y174.82 F1000
G1 X53.83 Y174.777 F1000
G1 X54.748 Y174.736 F1000
G1 X55.666 Y174.697 F1000
G1 X56.584 Y174.66 F1000
G1 X57.503 Y174.625 F1000
G1 X58.421 Y174.591 F1000
G1 X60.258 Y174.527 F1000
G1 X62.095 Y174.466 F1000
G1 X66.688 Y174.318 F1000
G1 X68.525 Y174.256 F1000
G1 X69.443 Y174.225 F1000
G1 X71.28 Y174.159 F1000
G1 X73.117 Y174.09 F1000
G1 X74.035 Y174.054 F1000
G1 X74.953 Y174.017 F1000
G1 X75.872 Y173.979 F1000
G1 X76.79 Y173.94 F1000
G1 X78.626 Y173.858 F1000
G1 X80.462 Y173.773 F1000
G1 X82.298 Y173.684 F1000
G1 X84.134 Y173.593 F1000
G1 X86.887 Y173.452 F1000
G1 X93.312 Y173.117 F1000
G1 X96.065 Y172.977 F1000
G1 X97.901 Y172.887 F1000
G1 X99.737 Y172.799 F1000
G1 X101.573 Y172.715 F1000
G1 X103.409 Y172.635 F1000
G1 X104.327 Y172.597 F1000
G1 X105.246 Y172.559 F1000
G1 X106.164 Y172.523 F1000
G1 X107.082 Y172.487 F1000
G1 X108.001 Y172.453 F1000
G1 X108.919 Y172.42 F1000
G1 X109.838 Y172.388 F1000
G1 X110.756 Y172.357 F1000
G1 X111.675 Y172.328 F1000
G1 X112.593 Y172.299 F1000
G1 X113.512 Y172.272 F1000
G1 X114.431 Y172.246 F1000
G1 X115.349 Y172.221 F1000
G1 X116.268 Y172.197 F1000
G1 X117.187 Y172.174 F1000
G1 X118.105 Y172.153 F1000
G1 X119.024 Y172.132 F1000
G1 X119.943 Y172.113 F1000
G1 X120.862 Y172.094 F1000
G1 X122.7 Y172.06 F1000
G1 X124.537 Y172.03 F1000
G1 X126.375 Y172.004 F1000
G1 X128.213 Y171.982 F1000
G1 X130.051 Y171.964 F1000
G1 X131.889 Y171.949 F1000
G1 X133.727 Y171.938 F1000
G1 X134.646 Y171.935 F1000
G1 X135.565 Y171.932 F1000
G1 X136.484 Y171.93 F1000
G1 X137.403 Y171.929 F1000
G1 X138.322 Y171.93 F1000
G1 X139.241 Y171.932 F1000
G1 X140.16 Y171.935 F1000
G1 X141.079 Y171.939 F1000
G1 X141.998 Y171.945 F1000
G1 X142.917 Y171.952 F1000
G1 X143.836 Y171.961 F1000
G1 X144.755 Y171.972 F1000
G1 X145.674 Y171.985 F1000
G1 X146.593 Y171.999 F1000
G1 X147.512 Y172.016 F1000
G1 X148.431 Y172.035 F1000
G1 X149.349 Y172.056 F1000
G1 X150.268 Y172.08 F1000
G1 X151.187 Y172.106 F1000
G1 X152.105 Y172.136 F1000
G1 X153.024 Y172.169 F1000
G1 X153.942 Y172.205 F1000
G1 X154.86 Y172.244 F1000
G1 X155.778 Y172.288 F1000
G1 X156.696 Y172.336 F1000
G1 X157.614 Y172.388 F1000
G1 X158.531 Y172.445 F1000
G1 X159.448 Y172.508 F1000
G1 X160.364 Y172.576 F1000
G1 X161.28 Y172.65 F1000
G1 X162.196 Y172.732 F1000
G1 X163.11 Y172.821 F1000
G1 X164.024 Y172.919 F1000
G1 X164.937 Y173.026 F1000
G1 X165.848 Y173.145 F1000
G1 X166.758 Y173.275 F1000
G1 X167.665 Y173.42 F1000
G1 X168.57 Y173.582 F1000
G1 X169.471 Y173.764 F1000
G1 X170.366 Y173.971 F1000
G1 X171.254 Y174.211 F1000
G1 X172.089 Y174.484 F1000
G1 X172.644 Y174.717 F1000
G1 X172.935 Y174.867 F1000
G1 X173.204 Y175.046 F1000
G1 X173.428 Y175.279 F1000
G1 X173.596 Y175.555 F1000
G1 X173.701 Y175.861 F1000
G1 X173.736 Y176.183 F1000
G1 Y178.704 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y179.288 I-0.635 J-0.022 F1000
G1 X173.221 Y179.309 Z-3.012 F1000
G1 X173.153 Y179.33 Z-3 F1000
G1 X173.088 Y179.35 Z-2.98 F1000
G1 X173.025 Y179.37 Z-2.953 F1000
G1 X172.966 Y179.388 Z-2.919 F1000
G1 X172.91 Y179.405 Z-2.877 F1000
G1 X172.859 Y179.421 Z-2.83 F1000
G1 X172.814 Y179.435 Z-2.777 F1000
G1 X172.775 Y179.447 Z-2.719 F1000
G1 X172.742 Y179.457 Z-2.657 F1000
G1 X172.716 Y179.465 Z-2.591 F1000
G1 X172.697 Y179.471 Z-2.522 F1000
G1 X172.685 Y179.474 Z-2.452 F1000
G1 X172.682 Y179.476 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y186.041 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y186.037 Z-2.452 F1000
G1 X22.509 Y186.027 Z-2.522 F1000
G1 X22.499 Y186.01 Z-2.591 F1000
G1 X22.485 Y185.987 Z-2.657 F1000
G1 X22.467 Y185.957 Z-2.719 F1000
G1 X22.446 Y185.921 Z-2.777 F1000
G1 X22.422 Y185.881 Z-2.83 F1000
G1 X22.395 Y185.835 Z-2.877 F1000
G1 X22.365 Y185.785 Z-2.919 F1000
G1 X22.333 Y185.732 Z-2.953 F1000
G1 X22.3 Y185.675 Z-2.98 F1000
G1 X22.265 Y185.616 Z-3 F1000
G1 X22.229 Y185.556 Z-3.012 F1000
G1 X22.192 Y185.495 Z-3.016 F1000
G3 X21.971 Y184.741 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y182.235 F1000
G1 X21.982 Y182.008 F1000
G1 X22.014 Y181.766 F1000
G1 X22.076 Y181.477 F1000
G1 X22.166 Y181.176 F1000
G1 X22.296 Y180.842 F1000
G1 X22.479 Y180.464 F1000
G1 X22.704 Y180.083 F1000
G1 X23.01 Y179.648 F1000
G1 X23.382 Y179.199 F1000
G1 X23.857 Y178.713 F1000
G1 X24.46 Y178.186 F1000
G1 X25.199 Y177.639 F1000
G1 X25.978 Y177.152 F1000
G1 X26.787 Y176.715 F1000
G1 X27.618 Y176.323 F1000
G1 X28.466 Y175.968 F1000
G1 X29.326 Y175.646 F1000
G1 X30.198 Y175.353 F1000
G1 X31.077 Y175.086 F1000
G1 X31.963 Y174.842 F1000
G1 X32.854 Y174.617 F1000
G1 X33.749 Y174.41 F1000
G1 X34.648 Y174.219 F1000
G1 X35.55 Y174.043 F1000
G1 X36.455 Y173.88 F1000
G1 X37.361 Y173.729 F1000
G1 X38.27 Y173.588 F1000
G1 X39.179 Y173.458 F1000
G1 X40.09 Y173.337 F1000
G1 X41.002 Y173.224 F1000
G1 X41.915 Y173.119 F1000
G1 X42.829 Y173.021 F1000
G1 X43.744 Y172.93 F1000
G1 X44.659 Y172.845 F1000
G1 X45.574 Y172.765 F1000
G1 X46.49 Y172.691 F1000
G1 X47.407 Y172.622 F1000
G1 X48.323 Y172.558 F1000
G1 X49.24 Y172.497 F1000
G1 X50.158 Y172.441 F1000
G1 X51.075 Y172.387 F1000
G1 X51.993 Y172.338 F1000
G1 X52.911 Y172.291 F1000
G1 X53.829 Y172.246 F1000
G1 X54.747 Y172.205 F1000
G1 X55.665 Y172.165 F1000
G1 X56.583 Y172.127 F1000
G1 X57.501 Y172.091 F1000
G1 X58.42 Y172.057 F1000
G1 X60.257 Y171.991 F1000
G1 X62.094 Y171.928 F1000
G1 X66.686 Y171.776 F1000
G1 X68.523 Y171.713 F1000
G1 X69.442 Y171.681 F1000
G1 X71.279 Y171.615 F1000
G1 X73.115 Y171.545 F1000
G1 X74.952 Y171.471 F1000
G1 X76.788 Y171.393 F1000
G1 X78.624 Y171.312 F1000
G1 X80.46 Y171.226 F1000
G1 X82.296 Y171.138 F1000
G1 X84.132 Y171.047 F1000
G1 X86.886 Y170.907 F1000
G1 X92.392 Y170.621 F1000
G1 X95.146 Y170.482 F1000
G1 X96.982 Y170.391 F1000
G1 X98.818 Y170.303 F1000
G1 X100.654 Y170.218 F1000
G1 X102.49 Y170.136 F1000
G1 X104.326 Y170.059 F1000
G1 X105.245 Y170.021 F1000
G1 X106.163 Y169.985 F1000
G1 X107.081 Y169.95 F1000
G1 X108 Y169.916 F1000
G1 X108.918 Y169.883 F1000
G1 X109.837 Y169.851 F1000
G1 X110.755 Y169.821 F1000
G1 X111.674 Y169.791 F1000
G1 X112.592 Y169.763 F1000
G1 X113.511 Y169.736 F1000
G1 X114.429 Y169.71 F1000
G1 X115.348 Y169.685 F1000
G1 X116.267 Y169.661 F1000
G1 X117.186 Y169.638 F1000
G1 X118.104 Y169.617 F1000
G1 X119.023 Y169.596 F1000
G1 X119.942 Y169.576 F1000
G1 X120.861 Y169.558 F1000
G1 X122.699 Y169.524 F1000
G1 X124.536 Y169.494 F1000
G1 X126.374 Y169.468 F1000
G1 X128.212 Y169.446 F1000
G1 X130.05 Y169.428 F1000
G1 X131.888 Y169.413 F1000
G1 X133.726 Y169.402 F1000
G1 X134.645 Y169.399 F1000
G1 X135.564 Y169.396 F1000
G1 X136.483 Y169.394 F1000
G1 X137.402 F1000
G1 X138.321 Y169.395 F1000
G1 X139.24 Y169.397 F1000
G1 X140.159 Y169.4 F1000
G1 X141.078 Y169.405 F1000
G1 X141.997 Y169.411 F1000
G1 X142.916 Y169.418 F1000
G1 X143.835 Y169.428 F1000
G1 X144.754 Y169.439 F1000
G1 X145.673 Y169.452 F1000
G1 X146.592 Y169.467 F1000
G1 X147.511 Y169.484 F1000
G1 X148.43 Y169.503 F1000
G1 X149.348 Y169.525 F1000
G1 X150.267 Y169.549 F1000
G1 X151.186 Y169.576 F1000
G1 X152.104 Y169.606 F1000
G1 X153.023 Y169.639 F1000
G1 X153.941 Y169.676 F1000
G1 X154.859 Y169.716 F1000
G1 X155.777 Y169.76 F1000
G1 X156.695 Y169.808 F1000
G1 X157.612 Y169.861 F1000
G1 X158.529 Y169.918 F1000
G1 X159.446 Y169.981 F1000
G1 X160.363 Y170.05 F1000
G1 X161.279 Y170.125 F1000
G1 X162.194 Y170.207 F1000
G1 X163.109 Y170.297 F1000
G1 X164.023 Y170.395 F1000
G1 X164.935 Y170.503 F1000
G1 X165.846 Y170.622 F1000
G1 X166.756 Y170.753 F1000
G1 X167.664 Y170.898 F1000
G1 X168.568 Y171.06 F1000
G1 X169.469 Y171.242 F1000
G1 X170.364 Y171.449 F1000
G1 X171.252 Y171.689 F1000
G1 X172.088 Y171.963 F1000
G1 X172.644 Y172.195 F1000
G1 X172.935 Y172.346 F1000
G1 X173.204 Y172.525 F1000
G1 X173.428 Y172.758 F1000
G1 X173.596 Y173.034 F1000
G1 X173.701 Y173.34 F1000
G1 X173.736 Y173.662 F1000
G1 Y176.183 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y176.768 I-0.635 J-0.022 F1000
G1 X173.221 Y176.789 Z-3.012 F1000
G1 X173.153 Y176.809 Z-3 F1000
G1 X173.088 Y176.829 Z-2.98 F1000
G1 X173.025 Y176.849 Z-2.953 F1000
G1 X172.966 Y176.867 Z-2.919 F1000
G1 X172.91 Y176.884 Z-2.877 F1000
G1 X172.859 Y176.9 Z-2.83 F1000
G1 X172.814 Y176.914 Z-2.777 F1000
G1 X172.775 Y176.926 Z-2.719 F1000
G1 X172.742 Y176.936 Z-2.657 F1000
G1 X172.716 Y176.944 Z-2.591 F1000
G1 X172.697 Y176.95 Z-2.522 F1000
G1 X172.685 Y176.954 Z-2.452 F1000
G1 X172.682 Y176.955 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y183.535 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y183.531 Z-2.452 F1000
G1 X22.509 Y183.521 Z-2.522 F1000
G1 X22.499 Y183.504 Z-2.591 F1000
G1 X22.485 Y183.481 Z-2.657 F1000
G1 X22.467 Y183.451 Z-2.719 F1000
G1 X22.446 Y183.415 Z-2.777 F1000
G1 X22.422 Y183.375 Z-2.83 F1000
G1 X22.395 Y183.329 Z-2.877 F1000
G1 X22.365 Y183.279 Z-2.919 F1000
G1 X22.333 Y183.226 Z-2.953 F1000
G1 X22.3 Y183.169 Z-2.98 F1000
G1 X22.265 Y183.11 Z-3 F1000
G1 X22.229 Y183.05 Z-3.012 F1000
G1 X22.192 Y182.989 Z-3.016 F1000
G3 X21.971 Y182.235 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y179.729 F1000
G1 X21.983 Y179.498 F1000
G1 X22.014 Y179.255 F1000
G1 X22.076 Y178.967 F1000
G1 X22.166 Y178.665 F1000
G1 X22.296 Y178.331 F1000
G1 X22.48 Y177.953 F1000
G1 X22.705 Y177.572 F1000
G1 X23.01 Y177.137 F1000
G1 X23.383 Y176.688 F1000
G1 X23.858 Y176.201 F1000
G1 X24.462 Y175.674 F1000
G1 X25.201 Y175.127 F1000
G1 X25.98 Y174.64 F1000
G1 X26.788 Y174.203 F1000
G1 X27.619 Y173.81 F1000
G1 X28.467 Y173.455 F1000
G1 X29.328 Y173.133 F1000
G1 X30.199 Y172.84 F1000
G1 X31.078 Y172.573 F1000
G1 X31.964 Y172.328 F1000
G1 X32.855 Y172.102 F1000
G1 X33.75 Y171.895 F1000
G1 X34.649 Y171.704 F1000
G1 X35.551 Y171.527 F1000
G1 X36.455 Y171.363 F1000
G1 X37.362 Y171.211 F1000
G1 X38.27 Y171.07 F1000
G1 X39.179 Y170.939 F1000
G1 X40.09 Y170.818 F1000
G1 X41.002 Y170.704 F1000
G1 X41.915 Y170.598 F1000
G1 X42.829 Y170.5 F1000
G1 X43.743 Y170.408 F1000
G1 X44.658 Y170.322 F1000
G1 X45.574 Y170.242 F1000
G1 X46.49 Y170.167 F1000
G1 X47.406 Y170.097 F1000
G1 X48.323 Y170.032 F1000
G1 X49.24 Y169.971 F1000
G1 X50.157 Y169.913 F1000
G1 X51.074 Y169.859 F1000
G1 X51.992 Y169.809 F1000
G1 X52.91 Y169.761 F1000
G1 X53.828 Y169.716 F1000
G1 X54.746 Y169.673 F1000
G1 X55.664 Y169.633 F1000
G1 X56.582 Y169.594 F1000
G1 X57.5 Y169.557 F1000
G1 X58.419 Y169.522 F1000
G1 X60.256 Y169.454 F1000
G1 X62.092 Y169.39 F1000
G1 X67.603 Y169.202 F1000
G1 X69.44 Y169.138 F1000
G1 X71.277 Y169.07 F1000
G1 X73.114 Y168.999 F1000
G1 X74.95 Y168.925 F1000
G1 X76.787 Y168.847 F1000
G1 X78.623 Y168.765 F1000
G1 X80.459 Y168.68 F1000
G1 X82.295 Y168.592 F1000
G1 X84.131 Y168.501 F1000
G1 X86.884 Y168.362 F1000
G1 X92.391 Y168.079 F1000
G1 X95.145 Y167.94 F1000
G1 X96.98 Y167.85 F1000
G1 X98.816 Y167.763 F1000
G1 X100.653 Y167.678 F1000
G1 X102.489 Y167.597 F1000
G1 X104.325 Y167.52 F1000
G1 X105.243 Y167.483 F1000
G1 X106.162 Y167.447 F1000
G1 X107.08 Y167.413 F1000
G1 X107.999 Y167.379 F1000
G1 X108.917 Y167.346 F1000
G1 X109.835 Y167.315 F1000
G1 X110.754 Y167.284 F1000
G1 X111.673 Y167.255 F1000
G1 X112.591 Y167.227 F1000
G1 X113.51 Y167.199 F1000
G1 X114.428 Y167.173 F1000
G1 X115.347 Y167.149 F1000
G1 X116.266 Y167.125 F1000
G1 X117.185 Y167.102 F1000
G1 X118.103 Y167.08 F1000
G1 X119.022 Y167.06 F1000
G1 X119.941 Y167.04 F1000
G1 X120.86 Y167.022 F1000
G1 X122.697 Y166.988 F1000
G1 X124.535 Y166.958 F1000
G1 X126.373 Y166.932 F1000
G1 X128.211 Y166.91 F1000
G1 X130.049 Y166.892 F1000
G1 X131.887 Y166.877 F1000
G1 X132.806 Y166.871 F1000
G1 X133.725 Y166.867 F1000
G1 X134.644 Y166.863 F1000
G1 X135.563 Y166.86 F1000
G1 X136.482 Y166.859 F1000
G1 X137.401 F1000
G1 X138.32 F1000
G1 X139.239 Y166.862 F1000
G1 X140.158 Y166.865 F1000
G1 X141.077 Y166.87 F1000
G1 X141.996 Y166.876 F1000
G1 X142.915 Y166.884 F1000
G1 X143.834 Y166.894 F1000
G1 X144.753 Y166.905 F1000
G1 X145.672 Y166.919 F1000
G1 X146.591 Y166.934 F1000
G1 X147.51 Y166.951 F1000
G1 X148.428 Y166.971 F1000
G1 X149.347 Y166.993 F1000
G1 X150.266 Y167.018 F1000
G1 X151.185 Y167.045 F1000
G1 X152.103 Y167.076 F1000
G1 X153.021 Y167.11 F1000
G1 X153.94 Y167.146 F1000
G1 X154.858 Y167.187 F1000
G1 X155.776 Y167.232 F1000
G1 X156.694 Y167.28 F1000
G1 X157.611 Y167.334 F1000
G1 X158.528 Y167.392 F1000
G1 X159.445 Y167.455 F1000
G1 X160.361 Y167.524 F1000
G1 X161.277 Y167.6 F1000
G1 X162.193 Y167.682 F1000
G1 X163.107 Y167.772 F1000
G1 X164.021 Y167.871 F1000
G1 X164.934 Y167.979 F1000
G1 X165.845 Y168.098 F1000
G1 X166.754 Y168.23 F1000
G1 X167.662 Y168.375 F1000
G1 X168.566 Y168.537 F1000
G1 X169.467 Y168.72 F1000
G1 X170.363 Y168.927 F1000
G1 X171.25 Y169.167 F1000
G1 X172.088 Y169.441 F1000
G1 X172.643 Y169.674 F1000
G1 X172.935 Y169.824 F1000
G1 X173.204 Y170.003 F1000
G1 X173.428 Y170.237 F1000
G1 X173.596 Y170.513 F1000
G1 X173.701 Y170.819 F1000
G1 X173.736 Y171.141 F1000
G1 Y173.662 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y174.247 I-0.635 J-0.022 F1000
G1 X173.221 Y174.268 Z-3.012 F1000
G1 X173.153 Y174.288 Z-3 F1000
G1 X173.088 Y174.308 Z-2.98 F1000
G1 X173.025 Y174.328 Z-2.953 F1000
G1 X172.966 Y174.346 Z-2.919 F1000
G1 X172.91 Y174.363 Z-2.877 F1000
G1 X172.859 Y174.379 Z-2.83 F1000
G1 X172.814 Y174.393 Z-2.777 F1000
G1 X172.775 Y174.405 Z-2.719 F1000
G1 X172.742 Y174.415 Z-2.657 F1000
G1 X172.716 Y174.423 Z-2.591 F1000
G1 X172.697 Y174.429 Z-2.522 F1000
G1 X172.685 Y174.432 Z-2.452 F1000
G1 X172.682 Y174.434 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y181.029 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y181.025 Z-2.452 F1000
G1 X22.509 Y181.015 Z-2.522 F1000
G1 X22.499 Y180.998 Z-2.591 F1000
G1 X22.485 Y180.974 Z-2.657 F1000
G1 X22.467 Y180.945 Z-2.719 F1000
G1 X22.446 Y180.909 Z-2.777 F1000
G1 X22.422 Y180.869 Z-2.83 F1000
G1 X22.395 Y180.823 Z-2.877 F1000
G1 X22.365 Y180.773 Z-2.919 F1000
G1 X22.333 Y180.72 Z-2.953 F1000
G1 X22.3 Y180.663 Z-2.98 F1000
G1 X22.265 Y180.604 Z-3 F1000
G1 X22.229 Y180.544 Z-3.012 F1000
G1 X22.192 Y180.483 Z-3.016 F1000
G3 X21.971 Y179.729 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y177.223 F1000
G1 X21.983 Y176.987 F1000
G1 X22.015 Y176.745 F1000
G1 X22.076 Y176.456 F1000
G1 X22.167 Y176.154 F1000
G1 X22.297 Y175.82 F1000
G1 X22.48 Y175.442 F1000
G1 X22.705 Y175.06 F1000
G1 X23.011 Y174.625 F1000
G1 X23.384 Y174.176 F1000
G1 X23.859 Y173.689 F1000
G1 X24.464 Y173.161 F1000
G1 X25.202 Y172.615 F1000
G1 X25.981 Y172.127 F1000
G1 X26.79 Y171.69 F1000
G1 X27.621 Y171.297 F1000
G1 X28.468 Y170.942 F1000
G1 X29.329 Y170.62 F1000
G1 X30.2 Y170.326 F1000
G1 X31.079 Y170.058 F1000
G1 X31.965 Y169.813 F1000
G1 X32.855 Y169.587 F1000
G1 X33.751 Y169.38 F1000
G1 X34.65 Y169.188 F1000
G1 X35.551 Y169.011 F1000
G1 X36.455 Y168.846 F1000
G1 X37.362 Y168.694 F1000
G1 X38.27 Y168.552 F1000
G1 X39.179 Y168.421 F1000
G1 X40.09 Y168.298 F1000
G1 X41.002 Y168.184 F1000
G1 X41.915 Y168.078 F1000
G1 X42.829 Y167.978 F1000
G1 X43.743 Y167.886 F1000
G1 X44.658 Y167.799 F1000
G1 X45.573 Y167.719 F1000
G1 X46.489 Y167.643 F1000
G1 X47.406 Y167.572 F1000
G1 X48.322 Y167.506 F1000
G1 X49.239 Y167.444 F1000
G1 X50.156 Y167.386 F1000
G1 X51.074 Y167.331 F1000
G1 X51.991 Y167.28 F1000
G1 X52.909 Y167.231 F1000
G1 X53.827 Y167.185 F1000
G1 X54.745 Y167.142 F1000
G1 X55.663 Y167.1 F1000
G1 X56.581 Y167.061 F1000
G1 X57.499 Y167.023 F1000
G1 X58.418 Y166.987 F1000
G1 X59.336 Y166.952 F1000
G1 X61.173 Y166.884 F1000
G1 X63.928 Y166.788 F1000
G1 X67.602 Y166.66 F1000
G1 X69.439 Y166.594 F1000
G1 X71.276 Y166.526 F1000
G1 X73.112 Y166.454 F1000
G1 X74.949 Y166.379 F1000
G1 X76.785 Y166.301 F1000
G1 X78.621 Y166.219 F1000
G1 X80.457 Y166.134 F1000
G1 X82.293 Y166.046 F1000
G1 X85.047 Y165.91 F1000
G1 X88.718 Y165.723 F1000
G1 X92.39 Y165.536 F1000
G1 X95.143 Y165.399 F1000
G1 X96.979 Y165.309 F1000
G1 X98.815 Y165.223 F1000
G1 X100.651 Y165.139 F1000
G1 X102.488 Y165.059 F1000
G1 X104.324 Y164.982 F1000
G1 X105.242 Y164.946 F1000
G1 X106.161 Y164.91 F1000
G1 X107.079 Y164.875 F1000
G1 X107.998 Y164.842 F1000
G1 X108.916 Y164.809 F1000
G1 X109.834 Y164.778 F1000
G1 X110.753 Y164.747 F1000
G1 X111.672 Y164.718 F1000
G1 X112.59 Y164.69 F1000
G1 X113.509 Y164.663 F1000
G1 X114.427 Y164.637 F1000
G1 X115.346 Y164.612 F1000
G1 X116.265 Y164.589 F1000
G1 X117.184 Y164.566 F1000
G1 X118.102 Y164.544 F1000
G1 X119.021 Y164.524 F1000
G1 X119.94 Y164.504 F1000
G1 X120.859 Y164.486 F1000
G1 X122.696 Y164.452 F1000
G1 X124.534 Y164.422 F1000
G1 X126.372 Y164.396 F1000
G1 X128.21 Y164.374 F1000
G1 X130.048 Y164.355 F1000
G1 X131.886 Y164.341 F1000
G1 X132.805 Y164.335 F1000
G1 X133.724 Y164.331 F1000
G1 X134.643 Y164.327 F1000
G1 X135.562 Y164.325 F1000
G1 X136.481 Y164.323 F1000
G1 X137.4 F1000
G1 X138.319 Y164.324 F1000
G1 X139.238 Y164.327 F1000
G1 X140.157 Y164.33 F1000
G1 X141.076 Y164.336 F1000
G1 X141.995 Y164.342 F1000
G1 X142.914 Y164.351 F1000
G1 X143.833 Y164.361 F1000
G1 X144.752 Y164.372 F1000
G1 X145.671 Y164.386 F1000
G1 X146.59 Y164.402 F1000
G1 X147.509 Y164.419 F1000
G1 X148.427 Y164.439 F1000
G1 X149.346 Y164.462 F1000
G1 X150.265 Y164.487 F1000
G1 X151.183 Y164.515 F1000
G1 X152.102 Y164.546 F1000
G1 X153.02 Y164.58 F1000
G1 X153.939 Y164.617 F1000
G1 X154.857 Y164.659 F1000
G1 X155.775 Y164.704 F1000
G1 X156.692 Y164.753 F1000
G1 X157.61 Y164.806 F1000
G1 X158.527 Y164.865 F1000
G1 X159.444 Y164.929 F1000
G1 X160.36 Y164.999 F1000
G1 X161.276 Y165.074 F1000
G1 X162.191 Y165.157 F1000
G1 X163.106 Y165.248 F1000
G1 X164.02 Y165.347 F1000
G1 X164.932 Y165.455 F1000
G1 X165.843 Y165.575 F1000
G1 X166.753 Y165.706 F1000
G1 X167.66 Y165.852 F1000
G1 X168.565 Y166.015 F1000
G1 X169.465 Y166.197 F1000
G1 X170.361 Y166.405 F1000
G1 X171.248 Y166.644 F1000
G1 X172.087 Y166.919 F1000
G1 X172.643 Y167.152 F1000
G1 X172.935 Y167.303 F1000
G1 X173.204 Y167.482 F1000
G1 X173.428 Y167.715 F1000
G1 X173.596 Y167.991 F1000
G1 X173.701 Y168.297 F1000
G1 X173.736 Y168.619 F1000
G1 Y171.141 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y171.725 I-0.635 J-0.022 F1000
G1 X173.221 Y171.746 Z-3.012 F1000
G1 X173.153 Y171.767 Z-3 F1000
G1 X173.088 Y171.787 Z-2.98 F1000
G1 X173.025 Y171.806 Z-2.953 F1000
G1 X172.966 Y171.825 Z-2.919 F1000
G1 X172.91 Y171.842 Z-2.877 F1000
G1 X172.859 Y171.857 Z-2.83 F1000
G1 X172.814 Y171.871 Z-2.777 F1000
G1 X172.775 Y171.884 Z-2.719 F1000
G1 X172.742 Y171.894 Z-2.657 F1000
G1 X172.716 Y171.902 Z-2.591 F1000
G1 X172.697 Y171.908 Z-2.522 F1000
G1 X172.685 Y171.911 Z-2.452 F1000
G1 X172.682 Y171.912 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y178.523 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y178.519 Z-2.452 F1000
G1 X22.509 Y178.509 Z-2.522 F1000
G1 X22.499 Y178.492 Z-2.591 F1000
G1 X22.485 Y178.468 Z-2.657 F1000
G1 X22.467 Y178.439 Z-2.719 F1000
G1 X22.446 Y178.403 Z-2.777 F1000
G1 X22.422 Y178.363 Z-2.83 F1000
G1 X22.395 Y178.317 Z-2.877 F1000
G1 X22.365 Y178.267 Z-2.919 F1000
G1 X22.333 Y178.214 Z-2.953 F1000
G1 X22.3 Y178.157 Z-2.98 F1000
G1 X22.265 Y178.098 Z-3 F1000
G1 X22.229 Y178.038 Z-3.012 F1000
G1 X22.192 Y177.977 Z-3.016 F1000
G3 X21.971 Y177.223 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y174.717 F1000
G1 X21.983 Y174.475 F1000
G1 X22.015 Y174.233 F1000
G1 X22.077 Y173.944 F1000
G1 X22.167 Y173.643 F1000
G1 X22.297 Y173.309 F1000
G1 X22.481 Y172.93 F1000
G1 X22.706 Y172.548 F1000
G1 X23.011 Y172.113 F1000
G1 X23.385 Y171.663 F1000
G1 X23.86 Y171.176 F1000
G1 X24.465 Y170.648 F1000
G1 X25.204 Y170.101 F1000
G1 X25.983 Y169.614 F1000
G1 X26.791 Y169.177 F1000
G1 X27.622 Y168.784 F1000
G1 X28.47 Y168.428 F1000
G1 X29.33 Y168.106 F1000
G1 X30.201 Y167.812 F1000
G1 X31.08 Y167.544 F1000
G1 X31.965 Y167.298 F1000
G1 X32.856 Y167.072 F1000
G1 X33.751 Y166.864 F1000
G1 X34.65 Y166.672 F1000
G1 X35.552 Y166.494 F1000
G1 X36.456 Y166.329 F1000
G1 X37.362 Y166.176 F1000
G1 X38.27 Y166.034 F1000
G1 X39.179 Y165.902 F1000
G1 X40.09 Y165.778 F1000
G1 X41.002 Y165.664 F1000
G1 X41.915 Y165.557 F1000
G1 X42.828 Y165.457 F1000
G1 X43.743 Y165.363 F1000
G1 X44.658 Y165.276 F1000
G1 X45.573 Y165.195 F1000
G1 X46.489 Y165.118 F1000
G1 X47.405 Y165.047 F1000
G1 X48.322 Y164.98 F1000
G1 X49.238 Y164.917 F1000
G1 X50.156 Y164.858 F1000
G1 X51.073 Y164.803 F1000
G1 X51.99 Y164.75 F1000
G1 X52.908 Y164.701 F1000
G1 X53.826 Y164.654 F1000
G1 X54.744 Y164.61 F1000
G1 X55.662 Y164.568 F1000
G1 X56.58 Y164.528 F1000
G1 X57.498 Y164.489 F1000
G1 X58.417 Y164.452 F1000
G1 X59.335 Y164.416 F1000
G1 X61.172 Y164.347 F1000
G1 X63.927 Y164.248 F1000
G1 X67.601 Y164.118 F1000
G1 X69.438 Y164.051 F1000
G1 X71.274 Y163.981 F1000
G1 X73.111 Y163.909 F1000
G1 X74.947 Y163.834 F1000
G1 X76.784 Y163.755 F1000
G1 X78.62 Y163.673 F1000
G1 X80.456 Y163.588 F1000
G1 X82.292 Y163.5 F1000
G1 X85.046 Y163.365 F1000
G1 X89.635 Y163.133 F1000
G1 X93.306 Y162.948 F1000
G1 X96.06 Y162.813 F1000
G1 X97.896 Y162.725 F1000
G1 X99.732 Y162.641 F1000
G1 X101.568 Y162.559 F1000
G1 X103.405 Y162.482 F1000
G1 X105.241 Y162.408 F1000
G1 X106.16 Y162.372 F1000
G1 X107.078 Y162.338 F1000
G1 X107.996 Y162.304 F1000
G1 X108.915 Y162.272 F1000
G1 X109.833 Y162.241 F1000
G1 X110.752 Y162.21 F1000
G1 X111.67 Y162.181 F1000
G1 X112.589 Y162.153 F1000
G1 X113.508 Y162.126 F1000
G1 X114.426 Y162.101 F1000
G1 X115.345 Y162.076 F1000
G1 X116.264 Y162.052 F1000
G1 X117.183 Y162.03 F1000
G1 X118.101 Y162.008 F1000
G1 X119.02 Y161.988 F1000
G1 X119.939 Y161.968 F1000
G1 X121.777 Y161.932 F1000
G1 X123.614 Y161.9 F1000
G1 X125.452 Y161.872 F1000
G1 X127.29 Y161.848 F1000
G1 X129.128 Y161.828 F1000
G1 X130.966 Y161.812 F1000
G1 X131.885 Y161.805 F1000
G1 X132.804 Y161.8 F1000
G1 X133.723 Y161.795 F1000
G1 X134.642 Y161.792 F1000
G1 X135.561 Y161.789 F1000
G1 X136.48 Y161.788 F1000
G1 X137.399 F1000
G1 X138.318 Y161.789 F1000
G1 X139.237 Y161.792 F1000
G1 X140.156 Y161.796 F1000
G1 X141.075 Y161.801 F1000
G1 X141.994 Y161.808 F1000
G1 X142.913 Y161.817 F1000
G1 X143.832 Y161.827 F1000
G1 X144.751 Y161.839 F1000
G1 X145.67 Y161.853 F1000
G1 X146.589 Y161.869 F1000
G1 X147.508 Y161.887 F1000
G1 X148.426 Y161.908 F1000
G1 X149.345 Y161.931 F1000
G1 X150.264 Y161.956 F1000
G1 X151.182 Y161.985 F1000
G1 X152.101 Y162.016 F1000
G1 X153.019 Y162.05 F1000
G1 X153.937 Y162.088 F1000
G1 X154.856 Y162.13 F1000
G1 X155.773 Y162.175 F1000
G1 X156.691 Y162.225 F1000
G1 X157.609 Y162.279 F1000
G1 X158.526 Y162.338 F1000
G1 X159.442 Y162.402 F1000
G1 X160.359 Y162.473 F1000
G1 X161.275 Y162.549 F1000
G1 X162.19 Y162.632 F1000
G1 X163.104 Y162.723 F1000
G1 X164.018 Y162.822 F1000
G1 X164.931 Y162.931 F1000
G1 X165.842 Y163.051 F1000
G1 X166.751 Y163.183 F1000
G1 X167.659 Y163.329 F1000
G1 X168.563 Y163.492 F1000
G1 X169.464 Y163.674 F1000
G1 X170.359 Y163.882 F1000
G1 X171.246 Y164.122 F1000
G1 X172.086 Y164.397 F1000
G1 X172.643 Y164.63 F1000
G1 X172.935 Y164.781 F1000
G1 X173.204 Y164.96 F1000
G1 X173.428 Y165.193 F1000
G1 X173.596 Y165.469 F1000
G1 X173.701 Y165.775 F1000
G1 X173.736 Y166.097 F1000
G1 Y168.619 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y169.204 I-0.635 J-0.022 F1000
G1 X173.221 Y169.224 Z-3.012 F1000
G1 X173.153 Y169.245 Z-3 F1000
G1 X173.088 Y169.265 Z-2.98 F1000
G1 X173.025 Y169.285 Z-2.953 F1000
G1 X172.966 Y169.303 Z-2.919 F1000
G1 X172.91 Y169.32 Z-2.877 F1000
G1 X172.859 Y169.336 Z-2.83 F1000
G1 X172.814 Y169.35 Z-2.777 F1000
G1 X172.775 Y169.362 Z-2.719 F1000
G1 X172.742 Y169.372 Z-2.657 F1000
G1 X172.716 Y169.38 Z-2.591 F1000
G1 X172.697 Y169.386 Z-2.522 F1000
G1 X172.685 Y169.389 Z-2.452 F1000
G1 X172.682 Y169.391 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y176.017 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y176.013 Z-2.452 F1000
G1 X22.509 Y176.003 Z-2.522 F1000
G1 X22.499 Y175.986 Z-2.591 F1000
G1 X22.485 Y175.962 Z-2.657 F1000
G1 X22.467 Y175.933 Z-2.719 F1000
G1 X22.446 Y175.897 Z-2.777 F1000
G1 X22.422 Y175.857 Z-2.83 F1000
G1 X22.395 Y175.811 Z-2.877 F1000
G1 X22.365 Y175.761 Z-2.919 F1000
G1 X22.333 Y175.708 Z-2.953 F1000
G1 X22.3 Y175.651 Z-2.98 F1000
G1 X22.265 Y175.592 Z-3 F1000
G1 X22.229 Y175.532 Z-3.012 F1000
G1 X22.192 Y175.471 Z-3.016 F1000
G3 X21.971 Y174.717 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y172.211 F1000
G1 X21.983 Y171.963 F1000
G1 X22.015 Y171.721 F1000
G1 X22.077 Y171.432 F1000
G1 X22.167 Y171.13 F1000
G1 X22.297 Y170.796 F1000
G1 X22.481 Y170.418 F1000
G1 X22.706 Y170.036 F1000
G1 X23.012 Y169.6 F1000
G1 X23.385 Y169.15 F1000
G1 X23.861 Y168.663 F1000
G1 X24.467 Y168.134 F1000
G1 X25.205 Y167.588 F1000
G1 X25.984 Y167.1 F1000
G1 X26.793 Y166.663 F1000
G1 X27.623 Y166.27 F1000
G1 X28.471 Y165.914 F1000
G1 X29.331 Y165.591 F1000
G1 X30.202 Y165.297 F1000
G1 X31.081 Y165.029 F1000
G1 X31.966 Y164.782 F1000
G1 X32.857 Y164.556 F1000
G1 X33.752 Y164.348 F1000
G1 X34.651 Y164.155 F1000
G1 X35.552 Y163.977 F1000
G1 X36.456 Y163.811 F1000
G1 X37.362 Y163.658 F1000
G1 X38.27 Y163.515 F1000
G1 X39.18 Y163.382 F1000
G1 X40.09 Y163.258 F1000
G1 X41.002 Y163.143 F1000
G1 X41.915 Y163.035 F1000
G1 X42.828 Y162.935 F1000
G1 X43.742 Y162.841 F1000
G1 X44.657 Y162.753 F1000
G1 X45.573 Y162.671 F1000
G1 X46.488 Y162.594 F1000
G1 X47.405 Y162.521 F1000
G1 X48.321 Y162.454 F1000
G1 X49.238 Y162.39 F1000
G1 X50.155 Y162.33 F1000
G1 X51.072 Y162.274 F1000
G1 X51.99 Y162.221 F1000
G1 X52.907 Y162.171 F1000
G1 X53.825 Y162.123 F1000
G1 X54.743 Y162.078 F1000
G1 X55.661 Y162.035 F1000
G1 X56.579 Y161.994 F1000
G1 X57.497 Y161.955 F1000
G1 X58.416 Y161.917 F1000
G1 X59.334 Y161.88 F1000
G1 X61.171 Y161.81 F1000
G1 X63.926 Y161.709 F1000
G1 X67.599 Y161.576 F1000
G1 X69.436 Y161.508 F1000
G1 X71.273 Y161.437 F1000
G1 X73.11 Y161.364 F1000
G1 X74.946 Y161.288 F1000
G1 X76.782 Y161.209 F1000
G1 X78.619 Y161.127 F1000
G1 X80.455 Y161.042 F1000
G1 X82.291 Y160.955 F1000
G1 X85.044 Y160.82 F1000
G1 X92.387 Y160.451 F1000
G1 X95.141 Y160.316 F1000
G1 X96.977 Y160.228 F1000
G1 X98.813 Y160.143 F1000
G1 X100.649 Y160.06 F1000
G1 X102.486 Y159.981 F1000
G1 X104.322 Y159.906 F1000
G1 X106.159 Y159.834 F1000
G1 X107.077 Y159.8 F1000
G1 X107.995 Y159.767 F1000
G1 X108.914 Y159.735 F1000
G1 X109.832 Y159.704 F1000
G1 X110.751 Y159.674 F1000
G1 X111.669 Y159.645 F1000
G1 X112.588 Y159.617 F1000
G1 X113.507 Y159.59 F1000
G1 X114.425 Y159.564 F1000
G1 X115.344 Y159.539 F1000
G1 X116.263 Y159.516 F1000
G1 X117.182 Y159.493 F1000
G1 X118.1 Y159.472 F1000
G1 X119.019 Y159.451 F1000
G1 X119.938 Y159.432 F1000
G1 X121.776 Y159.396 F1000
G1 X123.613 Y159.364 F1000
G1 X125.451 Y159.336 F1000
G1 X127.289 Y159.312 F1000
G1 X129.127 Y159.292 F1000
G1 X130.965 Y159.276 F1000
G1 X131.884 Y159.269 F1000
G1 X132.803 Y159.264 F1000
G1 X133.722 Y159.259 F1000
G1 X134.641 Y159.256 F1000
G1 X135.56 Y159.254 F1000
G1 X136.479 Y159.253 F1000
G1 X137.398 F1000
G1 X138.317 Y159.254 F1000
G1 X139.236 Y159.257 F1000
G1 X140.155 Y159.261 F1000
G1 X141.074 Y159.267 F1000
G1 X141.993 Y159.274 F1000
G1 X142.912 Y159.283 F1000
G1 X143.831 Y159.294 F1000
G1 X144.75 Y159.306 F1000
G1 X145.669 Y159.32 F1000
G1 X146.588 Y159.337 F1000
G1 X147.507 Y159.355 F1000
G1 X148.425 Y159.376 F1000
G1 X149.344 Y159.4 F1000
G1 X150.263 Y159.425 F1000
G1 X151.181 Y159.454 F1000
G1 X152.1 Y159.486 F1000
G1 X153.018 Y159.521 F1000
G1 X153.936 Y159.559 F1000
G1 X154.854 Y159.601 F1000
G1 X155.772 Y159.647 F1000
G1 X156.69 Y159.697 F1000
G1 X157.607 Y159.752 F1000
G1 X158.524 Y159.811 F1000
G1 X159.441 Y159.876 F1000
G1 X160.357 Y159.946 F1000
G1 X161.273 Y160.023 F1000
G1 X162.189 Y160.107 F1000
G1 X163.103 Y160.198 F1000
G1 X164.017 Y160.298 F1000
G1 X164.929 Y160.407 F1000
G1 X165.84 Y160.527 F1000
G1 X166.75 Y160.659 F1000
G1 X167.657 Y160.805 F1000
G1 X168.561 Y160.968 F1000
G1 X169.462 Y161.151 F1000
G1 X170.357 Y161.359 F1000
G1 X171.245 Y161.599 F1000
G1 X172.086 Y161.874 F1000
G1 X172.642 Y162.107 F1000
G1 X172.935 Y162.259 F1000
G1 X173.204 Y162.438 F1000
G1 X173.428 Y162.671 F1000
G1 X173.596 Y162.947 F1000
G1 X173.701 Y163.253 F1000
G1 X173.736 Y163.575 F1000
G1 Y166.097 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y166.682 I-0.635 J-0.022 F1000
G1 X173.221 Y166.703 Z-3.012 F1000
G1 X173.153 Y166.723 Z-3 F1000
G1 X173.088 Y166.743 Z-2.98 F1000
G1 X173.025 Y166.763 Z-2.953 F1000
G1 X172.966 Y166.781 Z-2.919 F1000
G1 X172.91 Y166.798 Z-2.877 F1000
G1 X172.859 Y166.814 Z-2.83 F1000
G1 X172.814 Y166.828 Z-2.777 F1000
G1 X172.775 Y166.84 Z-2.719 F1000
G1 X172.742 Y166.85 Z-2.657 F1000
G1 X172.716 Y166.858 Z-2.591 F1000
G1 X172.697 Y166.864 Z-2.522 F1000
G1 X172.685 Y166.868 Z-2.452 F1000
G1 X172.682 Y166.869 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y173.51 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y173.507 Z-2.452 F1000
G1 X22.509 Y173.497 Z-2.522 F1000
G1 X22.499 Y173.48 Z-2.591 F1000
G1 X22.485 Y173.456 Z-2.657 F1000
G1 X22.467 Y173.427 Z-2.719 F1000
G1 X22.446 Y173.391 Z-2.777 F1000
G1 X22.422 Y173.351 Z-2.83 F1000
G1 X22.395 Y173.305 Z-2.877 F1000
G1 X22.365 Y173.255 Z-2.919 F1000
G1 X22.333 Y173.202 Z-2.953 F1000
G1 X22.3 Y173.145 Z-2.98 F1000
G1 X22.265 Y173.086 Z-3 F1000
G1 X22.229 Y173.026 Z-3.012 F1000
G1 X22.192 Y172.965 Z-3.016 F1000
G3 X21.971 Y172.211 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y169.705 F1000
G1 X21.984 Y169.451 F1000
G1 X22.016 Y169.208 F1000
G1 X22.077 Y168.92 F1000
G1 X22.168 Y168.617 F1000
G1 X22.298 Y168.283 F1000
G1 X22.482 Y167.905 F1000
G1 X22.707 Y167.523 F1000
G1 X23.013 Y167.087 F1000
G1 X23.386 Y166.637 F1000
G1 X23.862 Y166.149 F1000
G1 X24.468 Y165.62 F1000
G1 X25.207 Y165.074 F1000
G1 X25.986 Y164.586 F1000
G1 X26.794 Y164.149 F1000
G1 X27.625 Y163.755 F1000
G1 X28.472 Y163.399 F1000
G1 X29.332 Y163.076 F1000
G1 X30.203 Y162.782 F1000
G1 X31.082 Y162.513 F1000
G1 X31.967 Y162.267 F1000
G1 X32.858 Y162.04 F1000
G1 X33.753 Y161.831 F1000
G1 X34.651 Y161.638 F1000
G1 X35.553 Y161.459 F1000
G1 X36.457 Y161.293 F1000
G1 X37.363 Y161.139 F1000
G1 X38.27 Y160.996 F1000
G1 X39.18 Y160.862 F1000
G1 X40.09 Y160.738 F1000
G1 X41.002 Y160.622 F1000
G1 X41.915 Y160.514 F1000
G1 X42.828 Y160.413 F1000
G1 X43.742 Y160.318 F1000
G1 X44.657 Y160.229 F1000
G1 X45.572 Y160.146 F1000
G1 X46.488 Y160.069 F1000
G1 X47.404 Y159.996 F1000
G1 X48.321 Y159.927 F1000
G1 X49.237 Y159.863 F1000
G1 X50.154 Y159.802 F1000
G1 X51.072 Y159.745 F1000
G1 X51.989 Y159.691 F1000
G1 X52.907 Y159.64 F1000
G1 X53.824 Y159.592 F1000
G1 X54.742 Y159.546 F1000
G1 X55.66 Y159.502 F1000
G1 X56.578 Y159.46 F1000
G1 X57.496 Y159.42 F1000
G1 X58.415 Y159.382 F1000
G1 X59.333 Y159.344 F1000
G1 X61.169 Y159.272 F1000
G1 X63.925 Y159.169 F1000
G1 X68.517 Y158.999 F1000
G1 X69.435 Y158.964 F1000
G1 X71.272 Y158.893 F1000
G1 X73.108 Y158.82 F1000
G1 X74.945 Y158.743 F1000
G1 X76.781 Y158.664 F1000
G1 X78.617 Y158.582 F1000
G1 X80.453 Y158.497 F1000
G1 X82.289 Y158.409 F1000
G1 X85.043 Y158.275 F1000
G1 X92.386 Y157.909 F1000
G1 X95.14 Y157.774 F1000
G1 X96.976 Y157.687 F1000
G1 X98.812 Y157.603 F1000
G1 X100.648 Y157.521 F1000
G1 X102.484 Y157.443 F1000
G1 X104.321 Y157.368 F1000
G1 X106.158 Y157.297 F1000
G1 X107.076 Y157.263 F1000
G1 X107.994 Y157.23 F1000
G1 X108.913 Y157.198 F1000
G1 X109.831 Y157.167 F1000
G1 X110.75 Y157.137 F1000
G1 X111.669 Y157.108 F1000
G1 X112.587 Y157.08 F1000
G1 X113.506 Y157.053 F1000
G1 X114.424 Y157.028 F1000
G1 X115.343 Y157.003 F1000
G1 X116.262 Y156.979 F1000
G1 X117.181 Y156.957 F1000
G1 X118.099 Y156.935 F1000
G1 X119.018 Y156.915 F1000
G1 X119.937 Y156.896 F1000
G1 X121.775 Y156.86 F1000
G1 X123.612 Y156.828 F1000
G1 X125.45 Y156.8 F1000
G1 X127.288 Y156.776 F1000
G1 X129.126 Y156.756 F1000
G1 X130.045 Y156.747 F1000
G1 X130.964 Y156.74 F1000
G1 X131.883 Y156.733 F1000
G1 X132.802 Y156.728 F1000
G1 X133.721 Y156.724 F1000
G1 X134.64 Y156.721 F1000
G1 X135.559 Y156.718 F1000
G1 X136.478 F1000
G1 X137.397 F1000
G1 X138.316 Y156.72 F1000
G1 X139.235 Y156.723 F1000
G1 X140.154 Y156.727 F1000
G1 X141.073 Y156.733 F1000
G1 X141.992 Y156.74 F1000
G1 X142.911 Y156.75 F1000
G1 X143.83 Y156.76 F1000
G1 X144.749 Y156.773 F1000
G1 X145.668 Y156.788 F1000
G1 X146.587 Y156.804 F1000
G1 X147.506 Y156.823 F1000
G1 X148.424 Y156.845 F1000
G1 X149.343 Y156.868 F1000
G1 X150.262 Y156.895 F1000
G1 X151.18 Y156.924 F1000
G1 X152.099 Y156.956 F1000
G1 X153.017 Y156.991 F1000
G1 X153.935 Y157.03 F1000
G1 X154.853 Y157.073 F1000
G1 X155.771 Y157.119 F1000
G1 X156.689 Y157.169 F1000
G1 X157.606 Y157.224 F1000
G1 X158.523 Y157.284 F1000
G1 X159.44 Y157.349 F1000
G1 X160.356 Y157.42 F1000
G1 X161.272 Y157.497 F1000
G1 X162.187 Y157.581 F1000
G1 X163.102 Y157.673 F1000
G1 X164.015 Y157.773 F1000
G1 X164.928 Y157.882 F1000
G1 X165.839 Y158.003 F1000
G1 X166.748 Y158.135 F1000
G1 X167.655 Y158.282 F1000
G1 X168.56 Y158.445 F1000
G1 X169.46 Y158.628 F1000
G1 X170.356 Y158.836 F1000
G1 X171.243 Y159.076 F1000
G1 X172.085 Y159.351 F1000
G1 X172.642 Y159.585 F1000
G1 X172.935 Y159.736 F1000
G1 X173.204 Y159.915 F1000
G1 X173.428 Y160.148 F1000
G1 X173.596 Y160.425 F1000
G1 X173.701 Y160.731 F1000
G1 X173.736 Y161.052 F1000
G1 Y163.575 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y164.159 I-0.635 J-0.022 F1000
G1 X173.221 Y164.18 Z-3.012 F1000
G1 X173.153 Y164.201 Z-3 F1000
G1 X173.088 Y164.221 Z-2.98 F1000
G1 X173.025 Y164.241 Z-2.953 F1000
G1 X172.966 Y164.259 Z-2.919 F1000
G1 X172.91 Y164.276 Z-2.877 F1000
G1 X172.859 Y164.292 Z-2.83 F1000
G1 X172.814 Y164.306 Z-2.777 F1000
G1 X172.775 Y164.318 Z-2.719 F1000
G1 X172.742 Y164.328 Z-2.657 F1000
G1 X172.716 Y164.336 Z-2.591 F1000
G1 X172.697 Y164.342 Z-2.522 F1000
G1 X172.685 Y164.345 Z-2.452 F1000
G1 X172.682 Y164.347 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y171.004 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y171.001 Z-2.452 F1000
G1 X22.509 Y170.991 Z-2.522 F1000
G1 X22.499 Y170.974 Z-2.591 F1000
G1 X22.485 Y170.95 Z-2.657 F1000
G1 X22.467 Y170.921 Z-2.719 F1000
G1 X22.446 Y170.885 Z-2.777 F1000
G1 X22.422 Y170.845 Z-2.83 F1000
G1 X22.395 Y170.799 Z-2.877 F1000
G1 X22.365 Y170.749 Z-2.919 F1000
G1 X22.333 Y170.695 Z-2.953 F1000
G1 X22.3 Y170.639 Z-2.98 F1000
G1 X22.265 Y170.58 Z-3 F1000
G1 X22.229 Y170.52 Z-3.012 F1000
G1 X22.192 Y170.459 Z-3.016 F1000
G3 X21.971 Y169.705 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y167.199 F1000
G1 X21.984 Y166.938 F1000
G1 X22.016 Y166.695 F1000
G1 X22.078 Y166.407 F1000
G1 X22.168 Y166.104 F1000
G1 X22.298 Y165.77 F1000
G1 X22.482 Y165.391 F1000
G1 X22.707 Y165.009 F1000
G1 X23.013 Y164.573 F1000
G1 X23.387 Y164.123 F1000
G1 X23.863 Y163.635 F1000
G1 X24.47 Y163.106 F1000
G1 X25.209 Y162.559 F1000
G1 X25.987 Y162.071 F1000
G1 X26.796 Y161.634 F1000
G1 X27.626 Y161.24 F1000
G1 X28.473 Y160.884 F1000
G1 X29.334 Y160.561 F1000
G1 X30.204 Y160.266 F1000
G1 X31.083 Y159.997 F1000
G1 X31.968 Y159.75 F1000
G1 X32.859 Y159.523 F1000
G1 X33.753 Y159.314 F1000
G1 X34.652 Y159.12 F1000
G1 X35.553 Y158.941 F1000
G1 X36.457 Y158.775 F1000
G1 X37.363 Y158.62 F1000
G1 X38.271 Y158.476 F1000
G1 X39.18 Y158.342 F1000
G1 X40.09 Y158.217 F1000
G1 X41.002 Y158.101 F1000
G1 X41.915 Y157.992 F1000
G1 X42.828 Y157.89 F1000
G1 X43.742 Y157.795 F1000
G1 X44.657 Y157.705 F1000
G1 X45.572 Y157.622 F1000
G1 X46.488 Y157.543 F1000
G1 X47.404 Y157.47 F1000
G1 X48.32 Y157.4 F1000
G1 X49.237 Y157.335 F1000
G1 X50.154 Y157.274 F1000
G1 X51.071 Y157.216 F1000
G1 X51.988 Y157.162 F1000
G1 X52.906 Y157.11 F1000
G1 X53.824 Y157.061 F1000
G1 X54.741 Y157.014 F1000
G1 X55.659 Y156.969 F1000
G1 X56.577 Y156.927 F1000
G1 X57.495 Y156.886 F1000
G1 X58.414 Y156.846 F1000
G1 X59.332 Y156.808 F1000
G1 X61.168 Y156.735 F1000
G1 X63.923 Y156.629 F1000
G1 X68.515 Y156.457 F1000
G1 X69.434 Y156.421 F1000
G1 X71.27 Y156.349 F1000
G1 X73.107 Y156.275 F1000
G1 X74.943 Y156.198 F1000
G1 X76.78 Y156.119 F1000
G1 X78.616 Y156.036 F1000
G1 X80.452 Y155.951 F1000
G1 X83.206 Y155.82 F1000
G1 X85.96 Y155.685 F1000
G1 X92.385 Y155.366 F1000
G1 X95.139 Y155.233 F1000
G1 X96.975 Y155.147 F1000
G1 X98.811 Y155.063 F1000
G1 X100.647 Y154.982 F1000
G1 X102.483 Y154.904 F1000
G1 X104.32 Y154.829 F1000
G1 X106.157 Y154.759 F1000
G1 X107.993 Y154.692 F1000
G1 X108.912 Y154.66 F1000
G1 X109.83 Y154.629 F1000
G1 X110.749 Y154.6 F1000
G1 X111.668 Y154.571 F1000
G1 X112.586 Y154.543 F1000
G1 X113.505 Y154.517 F1000
G1 X114.423 Y154.491 F1000
G1 X115.342 Y154.467 F1000
G1 X116.261 Y154.443 F1000
G1 X117.18 Y154.421 F1000
G1 X118.098 Y154.399 F1000
G1 X119.936 Y154.359 F1000
G1 X121.774 Y154.323 F1000
G1 X123.611 Y154.292 F1000
G1 X125.449 Y154.264 F1000
G1 X127.287 Y154.24 F1000
G1 X129.125 Y154.22 F1000
G1 X130.044 Y154.212 F1000
G1 X130.963 Y154.204 F1000
G1 X131.882 Y154.198 F1000
G1 X132.801 Y154.192 F1000
G1 X133.72 Y154.188 F1000
G1 X134.639 Y154.185 F1000
G1 X135.558 Y154.183 F1000
G1 X136.477 Y154.182 F1000
G1 X137.396 Y154.183 F1000
G1 X138.315 Y154.185 F1000
G1 X139.234 Y154.188 F1000
G1 X140.153 Y154.193 F1000
G1 X141.072 Y154.199 F1000
G1 X141.991 Y154.207 F1000
G1 X142.91 Y154.216 F1000
G1 X143.829 Y154.227 F1000
G1 X144.748 Y154.24 F1000
G1 X145.667 Y154.255 F1000
G1 X146.586 Y154.272 F1000
G1 X147.505 Y154.291 F1000
G1 X148.423 Y154.313 F1000
G1 X149.342 Y154.337 F1000
G1 X150.261 Y154.364 F1000
G1 X151.179 Y154.393 F1000
G1 X152.098 Y154.426 F1000
G1 X153.016 Y154.462 F1000
G1 X153.934 Y154.501 F1000
G1 X154.852 Y154.544 F1000
G1 X155.77 Y154.59 F1000
G1 X156.688 Y154.641 F1000
G1 X157.605 Y154.697 F1000
G1 X158.522 Y154.757 F1000
G1 X159.439 Y154.823 F1000
G1 X160.355 Y154.894 F1000
G1 X161.271 Y154.971 F1000
G1 X162.186 Y155.056 F1000
G1 X163.1 Y155.148 F1000
G1 X164.014 Y155.248 F1000
G1 X164.926 Y155.358 F1000
G1 X165.837 Y155.478 F1000
G1 X166.747 Y155.611 F1000
G1 X167.654 Y155.758 F1000
G1 X168.558 Y155.921 F1000
G1 X169.459 Y156.105 F1000
G1 X170.354 Y156.313 F1000
G1 X171.241 Y156.552 F1000
G1 X172.084 Y156.829 F1000
G1 X172.641 Y157.062 F1000
G1 X172.935 Y157.214 F1000
G1 X173.204 Y157.393 F1000
G1 X173.428 Y157.626 F1000
G1 X173.596 Y157.902 F1000
G1 X173.701 Y158.208 F1000
G1 X173.736 Y158.53 F1000
G1 Y161.052 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y161.637 I-0.635 J-0.022 F1000
G1 X173.221 Y161.658 Z-3.012 F1000
G1 X173.153 Y161.679 Z-3 F1000
G1 X173.088 Y161.699 Z-2.98 F1000
G1 X173.025 Y161.718 Z-2.953 F1000
G1 X172.966 Y161.737 Z-2.919 F1000
G1 X172.91 Y161.754 Z-2.877 F1000
G1 X172.859 Y161.769 Z-2.83 F1000
G1 X172.814 Y161.783 Z-2.777 F1000
G1 X172.775 Y161.795 Z-2.719 F1000
G1 X172.742 Y161.806 Z-2.657 F1000
G1 X172.716 Y161.814 Z-2.591 F1000
G1 X172.697 Y161.819 Z-2.522 F1000
G1 X172.685 Y161.823 Z-2.452 F1000
G1 X172.682 Y161.824 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y168.498 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y168.495 Z-2.452 F1000
G1 X22.509 Y168.485 Z-2.522 F1000
G1 X22.499 Y168.468 Z-2.591 F1000
G1 X22.485 Y168.444 Z-2.657 F1000
G1 X22.467 Y168.415 Z-2.719 F1000
G1 X22.446 Y168.379 Z-2.777 F1000
G1 X22.422 Y168.339 Z-2.83 F1000
G1 X22.395 Y168.293 Z-2.877 F1000
G1 X22.365 Y168.243 Z-2.919 F1000
G1 X22.333 Y168.189 Z-2.953 F1000
G1 X22.3 Y168.133 Z-2.98 F1000
G1 X22.265 Y168.074 Z-3 F1000
G1 X22.229 Y168.014 Z-3.012 F1000
G1 X22.192 Y167.953 Z-3.016 F1000
G3 X21.971 Y167.199 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y164.693 F1000
G1 X21.984 Y164.424 F1000
G1 X22.016 Y164.182 F1000
G1 X22.078 Y163.893 F1000
G1 X22.169 Y163.59 F1000
G1 X22.299 Y163.256 F1000
G1 X22.483 Y162.877 F1000
G1 X22.708 Y162.495 F1000
G1 X23.014 Y162.059 F1000
G1 X23.388 Y161.608 F1000
G1 X23.864 Y161.12 F1000
G1 X24.471 Y160.591 F1000
G1 X25.21 Y160.044 F1000
G1 X25.989 Y159.556 F1000
G1 X26.797 Y159.119 F1000
G1 X27.627 Y158.725 F1000
G1 X28.475 Y158.369 F1000
G1 X29.335 Y158.045 F1000
G1 X30.205 Y157.75 F1000
G1 X31.084 Y157.481 F1000
G1 X31.969 Y157.234 F1000
G1 X32.859 Y157.006 F1000
G1 X33.754 Y156.796 F1000
G1 X34.653 Y156.602 F1000
G1 X35.554 Y156.423 F1000
G1 X36.458 Y156.256 F1000
G1 X37.363 Y156.101 F1000
G1 X38.271 Y155.957 F1000
G1 X39.18 Y155.822 F1000
G1 X40.091 Y155.697 F1000
G1 X41.002 Y155.579 F1000
G1 X41.915 Y155.47 F1000
G1 X42.828 Y155.367 F1000
G1 X43.742 Y155.271 F1000
G1 X44.656 Y155.181 F1000
G1 X45.572 Y155.097 F1000
G1 X46.487 Y155.018 F1000
G1 X47.403 Y154.944 F1000
G1 X48.32 Y154.874 F1000
G1 X49.236 Y154.808 F1000
G1 X50.153 Y154.746 F1000
G1 X51.07 Y154.687 F1000
G1 X51.988 Y154.632 F1000
G1 X52.905 Y154.579 F1000
G1 X53.823 Y154.529 F1000
G1 X54.741 Y154.482 F1000
G1 X55.659 Y154.436 F1000
G1 X56.576 Y154.393 F1000
G1 X57.495 Y154.351 F1000
G1 X58.413 Y154.311 F1000
G1 X59.331 Y154.272 F1000
G1 X61.167 Y154.197 F1000
G1 X63.922 Y154.09 F1000
G1 X68.514 Y153.914 F1000
G1 X69.432 Y153.878 F1000
G1 X71.269 Y153.806 F1000
G1 X73.106 Y153.731 F1000
G1 X74.942 Y153.653 F1000
G1 X76.778 Y153.573 F1000
G1 X78.614 Y153.491 F1000
G1 X80.451 Y153.406 F1000
G1 X83.204 Y153.275 F1000
G1 X86.876 Y153.095 F1000
G1 X91.466 Y152.869 F1000
G1 X94.22 Y152.736 F1000
G1 X96.056 Y152.649 F1000
G1 X97.892 Y152.564 F1000
G1 X99.728 Y152.482 F1000
G1 X101.564 Y152.403 F1000
G1 X103.401 Y152.328 F1000
G1 X105.237 Y152.256 F1000
G1 X107.074 Y152.187 F1000
G1 X108.911 Y152.123 F1000
G1 X109.829 Y152.092 F1000
G1 X110.748 Y152.063 F1000
G1 X111.667 Y152.034 F1000
G1 X112.585 Y152.007 F1000
G1 X113.504 Y151.98 F1000
G1 X114.423 Y151.954 F1000
G1 X115.341 Y151.93 F1000
G1 X116.26 Y151.907 F1000
G1 X117.179 Y151.884 F1000
G1 X119.016 Y151.842 F1000
G1 X119.935 Y151.823 F1000
G1 X121.773 Y151.787 F1000
G1 X123.611 Y151.755 F1000
G1 X125.448 Y151.728 F1000
G1 X127.286 Y151.704 F1000
G1 X129.124 Y151.684 F1000
G1 X130.043 Y151.676 F1000
G1 X130.962 Y151.668 F1000
G1 X131.881 Y151.662 F1000
G1 X132.8 Y151.657 F1000
G1 X133.719 Y151.653 F1000
G1 X134.638 Y151.65 F1000
G1 X135.557 Y151.648 F1000
G1 X136.476 Y151.647 F1000
G1 X137.395 Y151.648 F1000
G1 X138.314 Y151.65 F1000
G1 X139.233 Y151.654 F1000
G1 X140.152 Y151.658 F1000
G1 X141.071 Y151.665 F1000
G1 X141.99 Y151.673 F1000
G1 X142.909 Y151.682 F1000
G1 X143.828 Y151.694 F1000
G1 X144.747 Y151.707 F1000
G1 X145.666 Y151.723 F1000
G1 X146.585 Y151.74 F1000
G1 X147.504 Y151.76 F1000
G1 X148.422 Y151.781 F1000
G1 X149.341 Y151.806 F1000
G1 X150.26 Y151.833 F1000
G1 X151.178 Y151.863 F1000
G1 X152.097 Y151.896 F1000
G1 X153.015 Y151.932 F1000
G1 X153.933 Y151.972 F1000
G1 X154.851 Y152.015 F1000
G1 X155.769 Y152.062 F1000
G1 X156.687 Y152.113 F1000
G1 X157.604 Y152.169 F1000
G1 X158.521 Y152.23 F1000
G1 X159.438 Y152.296 F1000
G1 X160.354 Y152.367 F1000
G1 X161.27 Y152.445 F1000
G1 X162.185 Y152.53 F1000
G1 X163.099 Y152.622 F1000
G1 X164.012 Y152.723 F1000
G1 X164.925 Y152.833 F1000
G1 X165.836 Y152.954 F1000
G1 X166.745 Y153.087 F1000
G1 X167.652 Y153.234 F1000
G1 X168.557 Y153.398 F1000
G1 X169.457 Y153.581 F1000
G1 X170.352 Y153.789 F1000
G1 X171.24 Y154.029 F1000
G1 X172.084 Y154.305 F1000
G1 X172.641 Y154.539 F1000
G1 X172.935 Y154.691 F1000
G1 X173.204 Y154.87 F1000
G1 X173.428 Y155.103 F1000
G1 X173.596 Y155.379 F1000
G1 X173.701 Y155.685 F1000
G1 X173.736 Y156.007 F1000
G1 Y158.53 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y159.114 I-0.635 J-0.022 F1000
G1 X173.221 Y159.135 Z-3.012 F1000
G1 X173.153 Y159.156 Z-3 F1000
G1 X173.088 Y159.176 Z-2.98 F1000
G1 X173.025 Y159.196 Z-2.953 F1000
G1 X172.966 Y159.214 Z-2.919 F1000
G1 X172.91 Y159.231 Z-2.877 F1000
G1 X172.859 Y159.247 Z-2.83 F1000
G1 X172.814 Y159.261 Z-2.777 F1000
G1 X172.775 Y159.273 Z-2.719 F1000
G1 X172.742 Y159.283 Z-2.657 F1000
G1 X172.716 Y159.291 Z-2.591 F1000
G1 X172.697 Y159.297 Z-2.522 F1000
G1 X172.685 Y159.3 Z-2.452 F1000
G1 X172.682 Y159.301 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y165.992 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y165.989 Z-2.452 F1000
G1 X22.509 Y165.979 Z-2.522 F1000
G1 X22.499 Y165.962 Z-2.591 F1000
G1 X22.485 Y165.938 Z-2.657 F1000
G1 X22.467 Y165.909 Z-2.719 F1000
G1 X22.446 Y165.873 Z-2.777 F1000
G1 X22.422 Y165.833 Z-2.83 F1000
G1 X22.395 Y165.787 Z-2.877 F1000
G1 X22.365 Y165.737 Z-2.919 F1000
G1 X22.333 Y165.683 Z-2.953 F1000
G1 X22.3 Y165.627 Z-2.98 F1000
G1 X22.265 Y165.568 Z-3 F1000
G1 X22.229 Y165.508 Z-3.012 F1000
G1 X22.192 Y165.447 Z-3.016 F1000
G3 X21.971 Y164.693 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y162.187 F1000
G1 X21.985 Y161.91 F1000
G1 X22.017 Y161.668 F1000
G1 X22.078 Y161.379 F1000
G1 X22.169 Y161.076 F1000
G1 X22.299 Y160.742 F1000
G1 X22.483 Y160.363 F1000
G1 X22.708 Y159.981 F1000
G1 X23.015 Y159.544 F1000
G1 X23.389 Y159.094 F1000
G1 X23.866 Y158.605 F1000
G1 X24.473 Y158.075 F1000
G1 X25.212 Y157.529 F1000
G1 X25.99 Y157.041 F1000
G1 X26.799 Y156.603 F1000
G1 X27.629 Y156.209 F1000
G1 X28.476 Y155.853 F1000
G1 X29.336 Y155.529 F1000
G1 X30.206 Y155.234 F1000
G1 X31.085 Y154.964 F1000
G1 X31.97 Y154.717 F1000
G1 X32.86 Y154.489 F1000
G1 X33.755 Y154.279 F1000
G1 X34.653 Y154.084 F1000
G1 X35.554 Y153.904 F1000
G1 X36.458 Y153.737 F1000
G1 X37.364 Y153.581 F1000
G1 X38.271 Y153.436 F1000
G1 X39.18 Y153.301 F1000
G1 X40.091 Y153.175 F1000
G1 X41.002 Y153.057 F1000
G1 X41.915 Y152.947 F1000
G1 X42.828 Y152.844 F1000
G1 X43.742 Y152.748 F1000
G1 X44.656 Y152.657 F1000
G1 X45.571 Y152.572 F1000
G1 X46.487 Y152.492 F1000
G1 X47.403 Y152.417 F1000
G1 X48.319 Y152.346 F1000
G1 X49.236 Y152.28 F1000
G1 X50.153 Y152.217 F1000
G1 X51.07 Y152.158 F1000
G1 X51.987 Y152.102 F1000
G1 X52.904 Y152.048 F1000
G1 X53.822 Y151.998 F1000
G1 X54.74 Y151.949 F1000
G1 X55.658 Y151.903 F1000
G1 X56.576 Y151.859 F1000
G1 X57.494 Y151.817 F1000
G1 X58.412 Y151.776 F1000
G1 X59.33 Y151.736 F1000
G1 X61.166 Y151.66 F1000
G1 X63.003 Y151.586 F1000
G1 X69.431 Y151.336 F1000
G1 X72.186 Y151.225 F1000
G1 X74.023 Y151.148 F1000
G1 X75.859 Y151.069 F1000
G1 X77.695 Y150.987 F1000
G1 X79.531 Y150.904 F1000
G1 X82.285 Y150.774 F1000
G1 X85.039 Y150.641 F1000
G1 X91.465 Y150.327 F1000
G1 X94.218 Y150.194 F1000
G1 X96.054 Y150.108 F1000
G1 X97.891 Y150.024 F1000
G1 X99.727 Y149.943 F1000
G1 X101.563 Y149.864 F1000
G1 X103.4 Y149.789 F1000
G1 X105.236 Y149.717 F1000
G1 X107.073 Y149.65 F1000
G1 X108.91 Y149.586 F1000
G1 X110.747 Y149.526 F1000
G1 X111.666 Y149.497 F1000
G1 X112.584 Y149.47 F1000
G1 X113.503 Y149.443 F1000
G1 X114.422 Y149.418 F1000
G1 X115.34 Y149.393 F1000
G1 X116.259 Y149.37 F1000
G1 X118.097 Y149.326 F1000
G1 X119.934 Y149.287 F1000
G1 X121.772 Y149.251 F1000
G1 X123.61 Y149.219 F1000
G1 X125.447 Y149.192 F1000
G1 X127.285 Y149.168 F1000
G1 X128.204 Y149.157 F1000
G1 X129.123 Y149.148 F1000
G1 X130.042 Y149.14 F1000
G1 X130.961 Y149.133 F1000
G1 X131.88 Y149.126 F1000
G1 X132.799 Y149.121 F1000
G1 X133.718 Y149.117 F1000
G1 X134.637 Y149.114 F1000
G1 X135.556 Y149.113 F1000
G1 X136.475 Y149.112 F1000
G1 X137.394 Y149.113 F1000
G1 X138.313 Y149.115 F1000
G1 X139.232 Y149.119 F1000
G1 X140.151 Y149.124 F1000
G1 X141.07 Y149.131 F1000
G1 X141.989 Y149.139 F1000
G1 X142.908 Y149.149 F1000
G1 X143.827 Y149.161 F1000
G1 X144.746 Y149.174 F1000
G1 X145.665 Y149.19 F1000
G1 X146.584 Y149.208 F1000
G1 X147.503 Y149.228 F1000
G1 X148.421 Y149.25 F1000
G1 X149.34 Y149.275 F1000
G1 X150.259 Y149.302 F1000
G1 X151.177 Y149.333 F1000
G1 X152.096 Y149.366 F1000
G1 X153.014 Y149.403 F1000
G1 X153.932 Y149.442 F1000
G1 X154.85 Y149.486 F1000
G1 X155.768 Y149.534 F1000
G1 X156.685 Y149.585 F1000
G1 X157.603 Y149.641 F1000
G1 X158.52 Y149.703 F1000
G1 X159.436 Y149.769 F1000
G1 X160.353 Y149.841 F1000
G1 X161.268 Y149.919 F1000
G1 X162.183 Y150.004 F1000
G1 X163.098 Y150.097 F1000
G1 X164.011 Y150.198 F1000
G1 X164.924 Y150.308 F1000
G1 X165.835 Y150.429 F1000
G1 X166.744 Y150.562 F1000
G1 X167.651 Y150.71 F1000
G1 X168.555 Y150.873 F1000
G1 X169.456 Y151.057 F1000
G1 X170.351 Y151.265 F1000
G1 X171.238 Y151.505 F1000
G1 X172.083 Y151.782 F1000
G1 X172.641 Y152.016 F1000
G1 X172.935 Y152.168 F1000
G1 X173.204 Y152.347 F1000
G1 X173.428 Y152.58 F1000
G1 X173.596 Y152.856 F1000
G1 X173.701 Y153.162 F1000
G1 X173.736 Y153.484 F1000
G1 Y156.007 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y156.592 I-0.635 J-0.022 F1000
G1 X173.221 Y156.612 Z-3.012 F1000
G1 X173.153 Y156.633 Z-3 F1000
G1 X173.088 Y156.653 Z-2.98 F1000
G1 X173.025 Y156.673 Z-2.953 F1000
G1 X172.966 Y156.691 Z-2.919 F1000
G1 X172.91 Y156.708 Z-2.877 F1000
G1 X172.859 Y156.724 Z-2.83 F1000
G1 X172.814 Y156.738 Z-2.777 F1000
G1 X172.775 Y156.75 Z-2.719 F1000
G1 X172.742 Y156.76 Z-2.657 F1000
G1 X172.716 Y156.768 Z-2.591 F1000
G1 X172.697 Y156.774 Z-2.522 F1000
G1 X172.685 Y156.777 Z-2.452 F1000
G1 X172.682 Y156.779 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y163.486 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y163.483 Z-2.452 F1000
G1 X22.509 Y163.473 Z-2.522 F1000
G1 X22.499 Y163.456 Z-2.591 F1000
G1 X22.485 Y163.432 Z-2.657 F1000
G1 X22.467 Y163.403 Z-2.719 F1000
G1 X22.446 Y163.367 Z-2.777 F1000
G1 X22.422 Y163.327 Z-2.83 F1000
G1 X22.395 Y163.281 Z-2.877 F1000
G1 X22.365 Y163.231 Z-2.919 F1000
G1 X22.333 Y163.177 Z-2.953 F1000
G1 X22.3 Y163.121 Z-2.98 F1000
G1 X22.265 Y163.062 Z-3 F1000
G1 X22.229 Y163.002 Z-3.012 F1000
G1 X22.192 Y162.941 Z-3.016 F1000
G3 X21.971 Y162.187 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y159.681 F1000
G1 X21.985 Y159.396 F1000
G1 X22.017 Y159.153 F1000
G1 X22.079 Y158.865 F1000
G1 X22.17 Y158.562 F1000
G1 X22.3 Y158.228 F1000
G1 X22.484 Y157.848 F1000
G1 X22.709 Y157.466 F1000
G1 X23.016 Y157.029 F1000
G1 X23.39 Y156.578 F1000
G1 X23.867 Y156.089 F1000
G1 X24.474 Y155.559 F1000
G1 X25.213 Y155.013 F1000
G1 X25.992 Y154.525 F1000
G1 X26.8 Y154.087 F1000
G1 X27.63 Y153.693 F1000
G1 X28.477 Y153.336 F1000
G1 X29.337 Y153.012 F1000
G1 X30.207 Y152.717 F1000
G1 X31.086 Y152.447 F1000
G1 X31.971 Y152.199 F1000
G1 X32.861 Y151.971 F1000
G1 X33.756 Y151.76 F1000
G1 X34.654 Y151.566 F1000
G1 X35.555 Y151.385 F1000
G1 X36.459 Y151.217 F1000
G1 X37.364 Y151.061 F1000
G1 X38.272 Y150.916 F1000
G1 X39.181 Y150.78 F1000
G1 X40.091 Y150.654 F1000
G1 X41.002 Y150.535 F1000
G1 X41.915 Y150.425 F1000
G1 X42.828 Y150.321 F1000
G1 X43.742 Y150.224 F1000
G1 X44.656 Y150.132 F1000
G1 X45.571 Y150.047 F1000
G1 X46.487 Y149.966 F1000
G1 X47.402 Y149.891 F1000
G1 X48.319 Y149.819 F1000
G1 X49.235 Y149.752 F1000
G1 X50.152 Y149.688 F1000
G1 X51.069 Y149.628 F1000
G1 X51.986 Y149.571 F1000
G1 X52.904 Y149.517 F1000
G1 X53.821 Y149.466 F1000
G1 X54.739 Y149.417 F1000
G1 X55.657 Y149.37 F1000
G1 X56.575 Y149.325 F1000
G1 X57.493 Y149.282 F1000
G1 X58.411 Y149.24 F1000
G1 X59.329 Y149.2 F1000
G1 X61.165 Y149.122 F1000
G1 X63.002 Y149.047 F1000
G1 X68.512 Y148.83 F1000
G1 X71.267 Y148.719 F1000
G1 X73.103 Y148.642 F1000
G1 X74.939 Y148.564 F1000
G1 X76.776 Y148.484 F1000
G1 X78.612 Y148.401 F1000
G1 X81.366 Y148.273 F1000
G1 X84.12 Y148.141 F1000
G1 X91.463 Y147.784 F1000
G1 X94.217 Y147.653 F1000
G1 X96.053 Y147.567 F1000
G1 X97.89 Y147.484 F1000
G1 X99.726 Y147.403 F1000
G1 X101.562 Y147.325 F1000
G1 X103.399 Y147.25 F1000
G1 X105.235 Y147.179 F1000
G1 X107.072 Y147.112 F1000
G1 X108.909 Y147.048 F1000
G1 X110.746 Y146.988 F1000
G1 X112.583 Y146.933 F1000
G1 X114.421 Y146.881 F1000
G1 X116.258 Y146.833 F1000
G1 X118.096 Y146.79 F1000
G1 X119.014 Y146.77 F1000
G1 X120.852 Y146.732 F1000
G1 X122.69 Y146.698 F1000
G1 X124.528 Y146.669 F1000
G1 X126.365 Y146.643 F1000
G1 X128.203 Y146.622 F1000
G1 X129.122 Y146.612 F1000
G1 X130.041 Y146.604 F1000
G1 X130.96 Y146.597 F1000
G1 X131.879 Y146.591 F1000
G1 X132.798 Y146.586 F1000
G1 X133.717 Y146.582 F1000
G1 X134.636 Y146.579 F1000
G1 X135.555 Y146.578 F1000
G1 X136.474 Y146.577 F1000
G1 X137.393 Y146.578 F1000
G1 X138.312 Y146.581 F1000
G1 X139.231 Y146.585 F1000
G1 X140.15 Y146.59 F1000
G1 X141.069 Y146.597 F1000
G1 X141.988 Y146.605 F1000
G1 X142.907 Y146.616 F1000
G1 X143.826 Y146.628 F1000
G1 X144.745 Y146.642 F1000
G1 X145.664 Y146.658 F1000
G1 X146.583 Y146.676 F1000
G1 X147.502 Y146.696 F1000
G1 X148.421 Y146.719 F1000
G1 X149.339 Y146.744 F1000
G1 X150.258 Y146.772 F1000
G1 X151.176 Y146.802 F1000
G1 X152.095 Y146.836 F1000
G1 X153.013 Y146.873 F1000
G1 X153.931 Y146.913 F1000
G1 X154.849 Y146.957 F1000
G1 X155.767 Y147.005 F1000
G1 X156.684 Y147.057 F1000
G1 X157.602 Y147.114 F1000
G1 X158.519 Y147.175 F1000
G1 X159.435 Y147.242 F1000
G1 X160.351 Y147.314 F1000
G1 X161.267 Y147.393 F1000
G1 X162.182 Y147.478 F1000
G1 X163.096 Y147.571 F1000
G1 X164.01 Y147.672 F1000
G1 X164.922 Y147.783 F1000
G1 X165.833 Y147.904 F1000
G1 X166.742 Y148.038 F1000
G1 X167.65 Y148.185 F1000
G1 X168.554 Y148.349 F1000
G1 X169.454 Y148.533 F1000
G1 X170.349 Y148.741 F1000
G1 X171.237 Y148.981 F1000
G1 X172.083 Y149.258 F1000
G1 X172.64 Y149.492 F1000
G1 X172.935 Y149.644 F1000
G1 X173.204 Y149.823 F1000
G1 X173.428 Y150.057 F1000
G1 X173.596 Y150.333 F1000
G1 X173.701 Y150.639 F1000
G1 X173.736 Y150.96 F1000
G1 Y153.484 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y154.068 I-0.635 J-0.022 F1000
G1 X173.221 Y154.089 Z-3.012 F1000
G1 X173.153 Y154.11 Z-3 F1000
G1 X173.088 Y154.13 Z-2.98 F1000
G1 X173.025 Y154.15 Z-2.953 F1000
G1 X172.966 Y154.168 Z-2.919 F1000
G1 X172.91 Y154.185 Z-2.877 F1000
G1 X172.859 Y154.201 Z-2.83 F1000
G1 X172.814 Y154.215 Z-2.777 F1000
G1 X172.775 Y154.227 Z-2.719 F1000
G1 X172.742 Y154.237 Z-2.657 F1000
G1 X172.716 Y154.245 Z-2.591 F1000
G1 X172.697 Y154.251 Z-2.522 F1000
G1 X172.685 Y154.254 Z-2.452 F1000
G1 X172.682 Y154.256 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y160.98 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y160.977 Z-2.452 F1000
G1 X22.509 Y160.967 Z-2.522 F1000
G1 X22.499 Y160.95 Z-2.591 F1000
G1 X22.485 Y160.926 Z-2.657 F1000
G1 X22.467 Y160.897 Z-2.719 F1000
G1 X22.446 Y160.861 Z-2.777 F1000
G1 X22.422 Y160.821 Z-2.83 F1000
G1 X22.395 Y160.775 Z-2.877 F1000
G1 X22.365 Y160.725 Z-2.919 F1000
G1 X22.333 Y160.671 Z-2.953 F1000
G1 X22.3 Y160.615 Z-2.98 F1000
G1 X22.265 Y160.556 Z-3 F1000
G1 X22.229 Y160.496 Z-3.012 F1000
G1 X22.192 Y160.435 Z-3.016 F1000
G3 X21.971 Y159.681 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y157.175 F1000
G1 X21.986 Y156.881 F1000
G1 X22.018 Y156.638 F1000
G1 X22.079 Y156.35 F1000
G1 X22.17 Y156.046 F1000
G1 X22.3 Y155.712 F1000
G1 X22.484 Y155.333 F1000
G1 X22.71 Y154.95 F1000
G1 X23.016 Y154.514 F1000
G1 X23.391 Y154.063 F1000
G1 X23.868 Y153.573 F1000
G1 X24.476 Y153.043 F1000
G1 X25.215 Y152.497 F1000
G1 X25.993 Y152.009 F1000
G1 X26.801 Y151.571 F1000
G1 X27.632 Y151.177 F1000
G1 X28.478 Y150.82 F1000
G1 X29.338 Y150.495 F1000
G1 X30.209 Y150.2 F1000
G1 X31.087 Y149.929 F1000
G1 X31.972 Y149.681 F1000
G1 X32.862 Y149.453 F1000
G1 X33.756 Y149.242 F1000
G1 X34.654 Y149.047 F1000
G1 X35.556 Y148.866 F1000
G1 X36.459 Y148.697 F1000
G1 X37.365 Y148.541 F1000
G1 X38.272 Y148.395 F1000
G1 X39.181 Y148.259 F1000
G1 X40.091 Y148.132 F1000
G1 X41.002 Y148.013 F1000
G1 X41.915 Y147.902 F1000
G1 X42.828 Y147.797 F1000
G1 X43.741 Y147.699 F1000
G1 X44.656 Y147.608 F1000
G1 X45.571 Y147.521 F1000
G1 X46.486 Y147.44 F1000
G1 X47.402 Y147.364 F1000
G1 X48.318 Y147.292 F1000
G1 X49.235 Y147.224 F1000
G1 X50.152 Y147.159 F1000
G1 X51.069 Y147.099 F1000
G1 X51.986 Y147.041 F1000
G1 X52.903 Y146.986 F1000
G1 X53.821 Y146.934 F1000
G1 X54.738 Y146.884 F1000
G1 X55.656 Y146.837 F1000
G1 X56.574 Y146.791 F1000
G1 X57.492 Y146.747 F1000
G1 X58.41 Y146.705 F1000
G1 X59.328 Y146.664 F1000
G1 X61.165 Y146.585 F1000
G1 X63.001 Y146.509 F1000
G1 X68.511 Y146.287 F1000
G1 X71.265 Y146.175 F1000
G1 X74.02 Y146.059 F1000
G1 X75.856 Y145.98 F1000
G1 X77.693 Y145.898 F1000
G1 X80.447 Y145.771 F1000
G1 X83.201 Y145.641 F1000
G1 X87.791 Y145.419 F1000
G1 X91.462 Y145.242 F1000
G1 X94.216 Y145.111 F1000
G1 X96.052 Y145.026 F1000
G1 X97.889 Y144.943 F1000
G1 X99.725 Y144.863 F1000
G1 X101.561 Y144.786 F1000
G1 X103.398 Y144.712 F1000
G1 X105.234 Y144.641 F1000
G1 X107.071 Y144.574 F1000
G1 X108.908 Y144.511 F1000
G1 X110.745 Y144.451 F1000
G1 X112.583 Y144.396 F1000
G1 X114.42 Y144.344 F1000
G1 X116.257 Y144.297 F1000
G1 X118.095 Y144.253 F1000
G1 X119.014 Y144.233 F1000
G1 X120.851 Y144.196 F1000
G1 X122.689 Y144.162 F1000
G1 X124.527 Y144.133 F1000
G1 X126.365 Y144.107 F1000
G1 X127.284 Y144.096 F1000
G1 X128.203 Y144.086 F1000
G1 X129.122 Y144.076 F1000
G1 X130.04 Y144.068 F1000
G1 X130.96 Y144.061 F1000
G1 X131.878 Y144.055 F1000
G1 X132.798 Y144.05 F1000
G1 X133.717 Y144.046 F1000
G1 X134.636 Y144.044 F1000
G1 X135.555 Y144.043 F1000
G1 X136.474 F1000
G1 X137.393 Y144.044 F1000
G1 X138.312 Y144.046 F1000
G1 X139.231 Y144.05 F1000
G1 X140.15 Y144.056 F1000
G1 X141.069 Y144.063 F1000
G1 X141.988 Y144.072 F1000
G1 X142.907 Y144.082 F1000
G1 X143.826 Y144.095 F1000
G1 X144.744 Y144.109 F1000
G1 X145.663 Y144.125 F1000
G1 X146.582 Y144.143 F1000
G1 X147.501 Y144.164 F1000
G1 X148.42 Y144.187 F1000
G1 X149.338 Y144.213 F1000
G1 X150.257 Y144.241 F1000
G1 X151.175 Y144.272 F1000
G1 X152.094 Y144.306 F1000
G1 X153.012 Y144.343 F1000
G1 X153.93 Y144.384 F1000
G1 X154.848 Y144.428 F1000
G1 X155.766 Y144.477 F1000
G1 X156.683 Y144.529 F1000
G1 X157.601 Y144.586 F1000
G1 X158.518 Y144.648 F1000
G1 X159.434 Y144.715 F1000
G1 X160.35 Y144.787 F1000
G1 X161.266 Y144.866 F1000
G1 X162.181 Y144.952 F1000
G1 X163.095 Y145.045 F1000
G1 X164.009 Y145.147 F1000
G1 X164.921 Y145.258 F1000
G1 X165.832 Y145.379 F1000
G1 X166.741 Y145.513 F1000
G1 X167.648 Y145.661 F1000
G1 X168.552 Y145.825 F1000
G1 X169.453 Y146.009 F1000
G1 X170.348 Y146.217 F1000
G1 X171.235 Y146.457 F1000
G1 X172.082 Y146.735 F1000
G1 X172.64 Y146.968 F1000
G1 X172.935 Y147.121 F1000
G1 X173.204 Y147.3 F1000
G1 X173.428 Y147.533 F1000
G1 X173.596 Y147.809 F1000
G1 X173.701 Y148.115 F1000
G1 X173.736 Y148.437 F1000
G1 Y150.96 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y151.545 I-0.635 J-0.022 F1000
G1 X173.221 Y151.566 Z-3.012 F1000
G1 X173.153 Y151.587 Z-3 F1000
G1 X173.088 Y151.607 Z-2.98 F1000
G1 X173.025 Y151.626 Z-2.953 F1000
G1 X172.966 Y151.645 Z-2.919 F1000
G1 X172.91 Y151.662 Z-2.877 F1000
G1 X172.859 Y151.677 Z-2.83 F1000
G1 X172.814 Y151.691 Z-2.777 F1000
G1 X172.775 Y151.704 Z-2.719 F1000
G1 X172.742 Y151.714 Z-2.657 F1000
G1 X172.716 Y151.722 Z-2.591 F1000
G1 X172.697 Y151.728 Z-2.522 F1000
G1 X172.685 Y151.731 Z-2.452 F1000
G1 X172.682 Y151.732 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y158.474 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y158.471 Z-2.452 F1000
G1 X22.509 Y158.461 Z-2.522 F1000
G1 X22.499 Y158.444 Z-2.591 F1000
G1 X22.485 Y158.42 Z-2.657 F1000
G1 X22.467 Y158.391 Z-2.719 F1000
G1 X22.446 Y158.355 Z-2.777 F1000
G1 X22.422 Y158.315 Z-2.83 F1000
G1 X22.395 Y158.269 Z-2.877 F1000
G1 X22.365 Y158.219 Z-2.919 F1000
G1 X22.333 Y158.165 Z-2.953 F1000
G1 X22.3 Y158.109 Z-2.98 F1000
G1 X22.265 Y158.05 Z-3 F1000
G1 X22.229 Y157.99 Z-3.012 F1000
G1 X22.192 Y157.929 Z-3.016 F1000
G3 X21.971 Y157.175 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y154.669 F1000
G1 X21.986 Y154.365 F1000
G1 X22.018 Y154.123 F1000
G1 X22.08 Y153.834 F1000
G1 X22.171 Y153.531 F1000
G1 X22.301 Y153.197 F1000
G1 X22.485 Y152.817 F1000
G1 X22.71 Y152.435 F1000
G1 X23.017 Y151.998 F1000
G1 X23.392 Y151.546 F1000
G1 X23.869 Y151.057 F1000
G1 X24.477 Y150.526 F1000
G1 X25.216 Y149.98 F1000
G1 X25.995 Y149.492 F1000
G1 X26.803 Y149.054 F1000
G1 X27.633 Y148.66 F1000
G1 X28.48 Y148.303 F1000
G1 X29.34 Y147.978 F1000
G1 X30.21 Y147.682 F1000
G1 X31.088 Y147.412 F1000
G1 X31.973 Y147.163 F1000
G1 X32.863 Y146.934 F1000
G1 X33.757 Y146.723 F1000
G1 X34.655 Y146.527 F1000
G1 X35.556 Y146.346 F1000
G1 X36.46 Y146.177 F1000
G1 X37.365 Y146.02 F1000
G1 X38.272 Y145.874 F1000
G1 X39.181 Y145.737 F1000
G1 X40.091 Y145.61 F1000
G1 X41.002 Y145.49 F1000
G1 X41.915 Y145.378 F1000
G1 X42.828 Y145.273 F1000
G1 X43.741 Y145.175 F1000
G1 X44.656 Y145.083 F1000
G1 X45.571 Y144.996 F1000
G1 X46.486 Y144.914 F1000
G1 X47.402 Y144.837 F1000
G1 X48.318 Y144.764 F1000
G1 X49.234 Y144.695 F1000
G1 X50.151 Y144.63 F1000
G1 X51.068 Y144.569 F1000
G1 X51.985 Y144.51 F1000
G1 X52.903 Y144.455 F1000
G1 X53.82 Y144.402 F1000
G1 X54.738 Y144.352 F1000
G1 X55.656 Y144.303 F1000
G1 X56.573 Y144.257 F1000
G1 X57.491 Y144.212 F1000
G1 X58.409 Y144.169 F1000
G1 X59.327 Y144.127 F1000
G1 X61.164 Y144.047 F1000
G1 X63 Y143.97 F1000
G1 X66.673 Y143.82 F1000
G1 X68.51 Y143.745 F1000
G1 X71.264 Y143.632 F1000
G1 X74.019 Y143.515 F1000
G1 X76.773 Y143.395 F1000
G1 X79.528 Y143.269 F1000
G1 X82.282 Y143.141 F1000
G1 X85.953 Y142.965 F1000
G1 X91.461 Y142.7 F1000
G1 X94.215 Y142.57 F1000
G1 X96.051 Y142.486 F1000
G1 X97.888 Y142.403 F1000
G1 X99.724 Y142.324 F1000
G1 X101.56 Y142.247 F1000
G1 X103.397 Y142.173 F1000
G1 X105.234 Y142.103 F1000
G1 X107.07 Y142.036 F1000
G1 X108.907 Y141.973 F1000
G1 X110.744 Y141.914 F1000
G1 X112.582 Y141.859 F1000
G1 X114.419 Y141.808 F1000
G1 X116.256 Y141.76 F1000
G1 X118.094 Y141.717 F1000
G1 X119.013 Y141.697 F1000
G1 X120.85 Y141.659 F1000
G1 X122.688 Y141.626 F1000
G1 X124.526 Y141.597 F1000
G1 X126.364 Y141.571 F1000
G1 X127.283 Y141.56 F1000
G1 X128.202 Y141.55 F1000
G1 X129.121 Y141.541 F1000
G1 X130.04 Y141.532 F1000
G1 X130.959 Y141.525 F1000
G1 X131.878 Y141.52 F1000
G1 X132.797 Y141.515 F1000
G1 X133.716 Y141.511 F1000
G1 X134.635 Y141.509 F1000
G1 X135.554 Y141.508 F1000
G1 X136.473 F1000
G1 X137.392 Y141.509 F1000
G1 X138.311 Y141.512 F1000
G1 X139.23 Y141.516 F1000
G1 X140.149 Y141.522 F1000
G1 X141.068 Y141.529 F1000
G1 X141.987 Y141.538 F1000
G1 X142.906 Y141.549 F1000
G1 X143.825 Y141.562 F1000
G1 X144.744 Y141.576 F1000
G1 X145.662 Y141.593 F1000
G1 X146.581 Y141.611 F1000
G1 X147.5 Y141.632 F1000
G1 X148.419 Y141.656 F1000
G1 X149.337 Y141.681 F1000
G1 X150.256 Y141.71 F1000
G1 X151.174 Y141.741 F1000
G1 X152.093 Y141.776 F1000
G1 X153.011 Y141.813 F1000
G1 X153.929 Y141.855 F1000
G1 X154.847 Y141.899 F1000
G1 X155.765 Y141.948 F1000
G1 X156.682 Y142.001 F1000
G1 X157.6 Y142.058 F1000
G1 X158.517 Y142.12 F1000
G1 X159.433 Y142.187 F1000
G1 X160.349 Y142.26 F1000
G1 X161.265 Y142.34 F1000
G1 X162.18 Y142.426 F1000
G1 X163.094 Y142.519 F1000
G1 X164.007 Y142.621 F1000
G1 X164.92 Y142.732 F1000
G1 X165.831 Y142.854 F1000
G1 X166.74 Y142.988 F1000
G1 X167.647 Y143.136 F1000
G1 X168.551 Y143.3 F1000
G1 X169.451 Y143.484 F1000
G1 X170.346 Y143.693 F1000
G1 X171.234 Y143.933 F1000
G1 X172.081 Y144.211 F1000
G1 X172.64 Y144.444 F1000
G1 X172.935 Y144.597 F1000
G1 X173.204 Y144.776 F1000
G1 X173.428 Y145.009 F1000
G1 X173.596 Y145.286 F1000
G1 X173.701 Y145.592 F1000
G1 X173.736 Y145.913 F1000
G1 Y148.437 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y149.022 I-0.635 J-0.022 F1000
G1 X173.221 Y149.043 Z-3.012 F1000
G1 X173.153 Y149.063 Z-3 F1000
G1 X173.088 Y149.083 Z-2.98 F1000
G1 X173.025 Y149.103 Z-2.953 F1000
G1 X172.966 Y149.121 Z-2.919 F1000
G1 X172.91 Y149.138 Z-2.877 F1000
G1 X172.859 Y149.154 Z-2.83 F1000
G1 X172.814 Y149.168 Z-2.777 F1000
G1 X172.775 Y149.18 Z-2.719 F1000
G1 X172.742 Y149.19 Z-2.657 F1000
G1 X172.716 Y149.198 Z-2.591 F1000
G1 X172.697 Y149.204 Z-2.522 F1000
G1 X172.685 Y149.207 Z-2.452 F1000
G1 X172.682 Y149.209 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y155.968 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y155.965 Z-2.452 F1000
G1 X22.509 Y155.955 Z-2.522 F1000
G1 X22.499 Y155.938 Z-2.591 F1000
G1 X22.485 Y155.914 Z-2.657 F1000
G1 X22.467 Y155.885 Z-2.719 F1000
G1 X22.446 Y155.849 Z-2.777 F1000
G1 X22.422 Y155.809 Z-2.83 F1000
G1 X22.395 Y155.763 Z-2.877 F1000
G1 X22.365 Y155.713 Z-2.919 F1000
G1 X22.333 Y155.659 Z-2.953 F1000
G1 X22.3 Y155.603 Z-2.98 F1000
G1 X22.265 Y155.544 Z-3 F1000
G1 X22.229 Y155.484 Z-3.012 F1000
G1 X22.192 Y155.423 Z-3.016 F1000
G3 X21.971 Y154.669 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y152.163 F1000
G1 X21.987 Y151.849 F1000
G1 X22.018 Y151.607 F1000
G1 X22.08 Y151.318 F1000
G1 X22.171 Y151.015 F1000
G1 X22.301 Y150.681 F1000
G1 X22.486 Y150.301 F1000
G1 X22.711 Y149.918 F1000
G1 X23.018 Y149.481 F1000
G1 X23.392 Y149.03 F1000
G1 X23.87 Y148.54 F1000
G1 X24.479 Y148.009 F1000
G1 X25.218 Y147.463 F1000
G1 X25.996 Y146.975 F1000
G1 X26.804 Y146.537 F1000
G1 X27.634 Y146.142 F1000
G1 X28.481 Y145.785 F1000
G1 X29.341 Y145.46 F1000
G1 X30.211 Y145.164 F1000
G1 X31.089 Y144.893 F1000
G1 X31.974 Y144.644 F1000
G1 X32.864 Y144.415 F1000
G1 X33.758 Y144.204 F1000
G1 X34.656 Y144.008 F1000
G1 X35.557 Y143.826 F1000
G1 X36.46 Y143.657 F1000
G1 X37.366 Y143.499 F1000
G1 X38.273 Y143.353 F1000
G1 X39.181 Y143.215 F1000
G1 X40.092 Y143.087 F1000
G1 X41.003 Y142.967 F1000
G1 X41.915 Y142.855 F1000
G1 X42.828 Y142.749 F1000
G1 X43.741 Y142.65 F1000
G1 X44.656 Y142.557 F1000
G1 X45.571 Y142.47 F1000
G1 X46.486 Y142.387 F1000
G1 X47.402 Y142.309 F1000
G1 X48.318 Y142.236 F1000
G1 X49.234 Y142.167 F1000
G1 X50.151 Y142.101 F1000
G1 X51.068 Y142.039 F1000
G1 X51.985 Y141.98 F1000
G1 X52.902 Y141.924 F1000
G1 X53.82 Y141.87 F1000
G1 X54.737 Y141.819 F1000
G1 X55.655 Y141.77 F1000
G1 X56.573 Y141.723 F1000
G1 X57.491 Y141.678 F1000
G1 X58.409 Y141.634 F1000
G1 X59.327 Y141.591 F1000
G1 X61.163 Y141.509 F1000
G1 X62.999 Y141.431 F1000
G1 X66.672 Y141.279 F1000
G1 X68.509 Y141.203 F1000
G1 X71.263 Y141.089 F1000
G1 X74.018 Y140.971 F1000
G1 X76.772 Y140.85 F1000
G1 X79.526 Y140.725 F1000
G1 X82.28 Y140.596 F1000
G1 X86.87 Y140.377 F1000
G1 X91.46 Y140.158 F1000
G1 X94.214 Y140.029 F1000
G1 X96.05 Y139.945 F1000
G1 X97.887 Y139.863 F1000
G1 X99.723 Y139.784 F1000
G1 X101.559 Y139.708 F1000
G1 X103.396 Y139.635 F1000
G1 X105.233 Y139.565 F1000
G1 X107.07 Y139.498 F1000
G1 X108.906 Y139.436 F1000
G1 X110.744 Y139.377 F1000
G1 X112.581 Y139.322 F1000
G1 X114.418 Y139.271 F1000
G1 X116.256 Y139.224 F1000
G1 X118.093 Y139.18 F1000
G1 X119.012 Y139.16 F1000
G1 X120.85 Y139.123 F1000
G1 X122.687 Y139.09 F1000
G1 X124.525 Y139.06 F1000
G1 X126.363 Y139.035 F1000
G1 X127.282 Y139.024 F1000
G1 X128.201 Y139.014 F1000
G1 X129.12 Y139.005 F1000
G1 X130.039 Y138.997 F1000
G1 X130.958 Y138.99 F1000
G1 X131.877 Y138.984 F1000
G1 X132.796 Y138.979 F1000
G1 X133.715 Y138.976 F1000
G1 X134.634 Y138.974 F1000
G1 X135.553 Y138.973 F1000
G1 X136.472 F1000
G1 X137.391 Y138.974 F1000
G1 X138.31 Y138.977 F1000
G1 X139.229 Y138.982 F1000
G1 X140.148 Y138.988 F1000
G1 X141.067 Y138.996 F1000
G1 X141.986 Y139.005 F1000
G1 X142.905 Y139.016 F1000
G1 X143.824 Y139.029 F1000
G1 X144.743 Y139.043 F1000
G1 X145.662 Y139.06 F1000
G1 X146.58 Y139.079 F1000
G1 X147.499 Y139.1 F1000
G1 X148.418 Y139.124 F1000
G1 X149.337 Y139.15 F1000
G1 X150.255 Y139.179 F1000
G1 X151.174 Y139.211 F1000
G1 X152.092 Y139.246 F1000
G1 X153.01 Y139.284 F1000
G1 X153.928 Y139.325 F1000
G1 X154.846 Y139.37 F1000
G1 X155.764 Y139.419 F1000
G1 X156.681 Y139.472 F1000
G1 X157.599 Y139.53 F1000
G1 X158.516 Y139.592 F1000
G1 X159.432 Y139.66 F1000
G1 X160.348 Y139.733 F1000
G1 X161.264 Y139.813 F1000
G1 X162.179 Y139.899 F1000
G1 X163.093 Y139.993 F1000
G1 X164.006 Y140.095 F1000
G1 X164.918 Y140.207 F1000
G1 X165.829 Y140.329 F1000
G1 X166.738 Y140.463 F1000
G1 X167.645 Y140.611 F1000
G1 X168.55 Y140.775 F1000
G1 X169.45 Y140.96 F1000
G1 X170.345 Y141.168 F1000
G1 X171.232 Y141.408 F1000
G1 X172.081 Y141.686 F1000
G1 X172.639 Y141.92 F1000
G1 X172.935 Y142.073 F1000
G1 X173.204 Y142.252 F1000
G1 X173.428 Y142.485 F1000
G1 X173.596 Y142.762 F1000
G1 X173.701 Y143.068 F1000
G1 X173.736 Y143.389 F1000
G1 Y145.913 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y146.498 I-0.635 J-0.022 F1000
G1 X173.221 Y146.519 Z-3.012 F1000
G1 X173.153 Y146.539 Z-3 F1000
G1 X173.088 Y146.56 Z-2.98 F1000
G1 X173.025 Y146.579 Z-2.953 F1000
G1 X172.966 Y146.597 Z-2.919 F1000
G1 X172.91 Y146.615 Z-2.877 F1000
G1 X172.859 Y146.63 Z-2.83 F1000
G1 X172.814 Y146.644 Z-2.777 F1000
G1 X172.775 Y146.656 Z-2.719 F1000
G1 X172.742 Y146.666 Z-2.657 F1000
G1 X172.716 Y146.674 Z-2.591 F1000
G1 X172.697 Y146.68 Z-2.522 F1000
G1 X172.685 Y146.684 Z-2.452 F1000
G1 X172.682 Y146.685 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y153.462 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y153.459 Z-2.452 F1000
G1 X22.509 Y153.449 Z-2.522 F1000
G1 X22.499 Y153.432 Z-2.591 F1000
G1 X22.485 Y153.408 Z-2.657 F1000
G1 X22.467 Y153.379 Z-2.719 F1000
G1 X22.446 Y153.343 Z-2.777 F1000
G1 X22.422 Y153.303 Z-2.83 F1000
G1 X22.395 Y153.257 Z-2.877 F1000
G1 X22.365 Y153.207 Z-2.919 F1000
G1 X22.333 Y153.153 Z-2.953 F1000
G1 X22.3 Y153.097 Z-2.98 F1000
G1 X22.265 Y153.038 Z-3 F1000
G1 X22.229 Y152.978 Z-3.012 F1000
G1 X22.192 Y152.917 Z-3.016 F1000
G3 X21.971 Y152.163 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y149.657 F1000
G1 X21.987 Y149.333 F1000
G1 X22.019 Y149.091 F1000
G1 X22.081 Y148.802 F1000
G1 X22.172 Y148.498 F1000
G1 X22.302 Y148.165 F1000
G1 X22.486 Y147.784 F1000
G1 X22.711 Y147.402 F1000
G1 X23.019 Y146.964 F1000
G1 X23.393 Y146.513 F1000
G1 X23.871 Y146.023 F1000
G1 X24.48 Y145.492 F1000
G1 X25.219 Y144.945 F1000
G1 X25.998 Y144.457 F1000
G1 X26.806 Y144.019 F1000
G1 X27.636 Y143.624 F1000
G1 X28.482 Y143.267 F1000
G1 X29.342 Y142.942 F1000
G1 X30.212 Y142.646 F1000
G1 X31.09 Y142.375 F1000
G1 X31.975 Y142.126 F1000
G1 X32.865 Y141.896 F1000
G1 X33.759 Y141.684 F1000
G1 X34.657 Y141.488 F1000
G1 X35.557 Y141.305 F1000
G1 X36.461 Y141.136 F1000
G1 X37.366 Y140.978 F1000
G1 X38.273 Y140.831 F1000
G1 X39.182 Y140.693 F1000
G1 X40.092 Y140.565 F1000
G1 X41.003 Y140.444 F1000
G1 X41.915 Y140.331 F1000
G1 X42.828 Y140.225 F1000
G1 X43.741 Y140.125 F1000
G1 X44.656 Y140.032 F1000
G1 X45.57 Y139.943 F1000
G1 X46.486 Y139.86 F1000
G1 X47.401 Y139.782 F1000
G1 X48.317 Y139.708 F1000
G1 X49.234 Y139.638 F1000
G1 X50.15 Y139.572 F1000
G1 X51.067 Y139.509 F1000
G1 X51.984 Y139.449 F1000
G1 X52.902 Y139.392 F1000
G1 X53.819 Y139.338 F1000
G1 X54.737 Y139.286 F1000
G1 X55.654 Y139.236 F1000
G1 X56.572 Y139.189 F1000
G1 X57.49 Y139.143 F1000
G1 X58.408 Y139.098 F1000
G1 X59.326 Y139.055 F1000
G1 X61.162 Y138.972 F1000
G1 X62.998 Y138.892 F1000
G1 X65.753 Y138.776 F1000
G1 X68.508 Y138.661 F1000
G1 X72.18 Y138.507 F1000
G1 X74.935 Y138.388 F1000
G1 X77.689 Y138.265 F1000
G1 X80.443 Y138.138 F1000
G1 X84.115 Y137.965 F1000
G1 X90.541 Y137.659 F1000
G1 X93.295 Y137.53 F1000
G1 X96.049 Y137.404 F1000
G1 X97.886 Y137.323 F1000
G1 X99.722 Y137.244 F1000
G1 X101.558 Y137.169 F1000
G1 X103.395 Y137.096 F1000
G1 X105.232 Y137.026 F1000
G1 X107.069 Y136.96 F1000
G1 X108.906 Y136.898 F1000
G1 X110.743 Y136.84 F1000
G1 X112.58 Y136.785 F1000
G1 X114.417 Y136.734 F1000
G1 X116.255 Y136.687 F1000
G1 X118.092 Y136.644 F1000
G1 X119.011 Y136.624 F1000
G1 X120.849 Y136.587 F1000
G1 X122.687 Y136.553 F1000
G1 X124.524 Y136.524 F1000
G1 X126.362 Y136.499 F1000
G1 X127.281 Y136.488 F1000
G1 X128.2 Y136.478 F1000
G1 X129.119 Y136.469 F1000
G1 X130.038 Y136.461 F1000
G1 X130.957 Y136.454 F1000
G1 X131.876 Y136.449 F1000
G1 X132.795 Y136.444 F1000
G1 X133.714 Y136.441 F1000
G1 X134.633 Y136.439 F1000
G1 X135.552 Y136.438 F1000
G1 X136.471 F1000
G1 X137.39 Y136.44 F1000
G1 X138.309 Y136.443 F1000
G1 X139.228 Y136.448 F1000
G1 X140.147 Y136.454 F1000
G1 X141.066 Y136.462 F1000
G1 X141.985 Y136.471 F1000
G1 X142.904 Y136.483 F1000
G1 X143.823 Y136.496 F1000
G1 X144.742 Y136.511 F1000
G1 X145.661 Y136.528 F1000
G1 X146.58 Y136.547 F1000
G1 X147.498 Y136.569 F1000
G1 X148.417 Y136.593 F1000
G1 X149.336 Y136.619 F1000
G1 X150.254 Y136.648 F1000
G1 X151.173 Y136.681 F1000
G1 X152.091 Y136.716 F1000
G1 X153.009 Y136.754 F1000
G1 X153.927 Y136.796 F1000
G1 X154.845 Y136.841 F1000
G1 X155.763 Y136.89 F1000
G1 X156.68 Y136.944 F1000
G1 X157.598 Y137.002 F1000
G1 X158.514 Y137.065 F1000
G1 X159.431 Y137.133 F1000
G1 X160.347 Y137.206 F1000
G1 X161.263 Y137.286 F1000
G1 X162.178 Y137.373 F1000
G1 X163.092 Y137.467 F1000
G1 X164.005 Y137.569 F1000
G1 X164.917 Y137.681 F1000
G1 X165.828 Y137.803 F1000
G1 X166.737 Y137.938 F1000
G1 X167.644 Y138.086 F1000
G1 X168.548 Y138.251 F1000
G1 X169.449 Y138.435 F1000
G1 X170.344 Y138.643 F1000
G1 X171.231 Y138.884 F1000
G1 X172.08 Y139.162 F1000
G1 X172.639 Y139.396 F1000
G1 X172.935 Y139.549 F1000
G1 X173.204 Y139.728 F1000
G1 X173.428 Y139.961 F1000
G1 X173.596 Y140.238 F1000
G1 X173.701 Y140.544 F1000
G1 X173.736 Y140.865 F1000
G1 Y143.389 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y143.974 I-0.635 J-0.022 F1000
G1 X173.221 Y143.995 Z-3.012 F1000
G1 X173.153 Y144.016 Z-3 F1000
G1 X173.088 Y144.036 Z-2.98 F1000
G1 X173.025 Y144.055 Z-2.953 F1000
G1 X172.966 Y144.073 Z-2.919 F1000
G1 X172.91 Y144.091 Z-2.877 F1000
G1 X172.859 Y144.106 Z-2.83 F1000
G1 X172.814 Y144.12 Z-2.777 F1000
G1 X172.775 Y144.132 Z-2.719 F1000
G1 X172.742 Y144.142 Z-2.657 F1000
G1 X172.716 Y144.151 Z-2.591 F1000
G1 X172.697 Y144.156 Z-2.522 F1000
G1 X172.685 Y144.16 Z-2.452 F1000
G1 X172.682 Y144.161 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y150.956 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y150.953 Z-2.452 F1000
G1 X22.509 Y150.943 Z-2.522 F1000
G1 X22.499 Y150.926 Z-2.591 F1000
G1 X22.485 Y150.902 Z-2.657 F1000
G1 X22.467 Y150.873 Z-2.719 F1000
G1 X22.446 Y150.837 Z-2.777 F1000
G1 X22.422 Y150.796 Z-2.83 F1000
G1 X22.395 Y150.751 Z-2.877 F1000
G1 X22.365 Y150.701 Z-2.919 F1000
G1 X22.333 Y150.647 Z-2.953 F1000
G1 X22.3 Y150.591 Z-2.98 F1000
G1 X22.265 Y150.532 Z-3 F1000
G1 X22.229 Y150.472 Z-3.012 F1000
G1 X22.192 Y150.411 Z-3.016 F1000
G3 X21.971 Y149.657 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y147.151 F1000
G1 X21.988 Y146.817 F1000
G1 X22.02 Y146.574 F1000
G1 X22.081 Y146.286 F1000
G1 X22.172 Y145.982 F1000
G1 X22.302 Y145.648 F1000
G1 X22.487 Y145.267 F1000
G1 X22.712 Y144.885 F1000
G1 X23.019 Y144.447 F1000
G1 X23.394 Y143.996 F1000
G1 X23.873 Y143.506 F1000
G1 X24.482 Y142.974 F1000
G1 X25.221 Y142.427 F1000
G1 X25.999 Y141.939 F1000
G1 X26.807 Y141.501 F1000
G1 X27.637 Y141.106 F1000
G1 X28.484 Y140.749 F1000
G1 X29.343 Y140.424 F1000
G1 X30.213 Y140.127 F1000
G1 X31.091 Y139.856 F1000
G1 X31.976 Y139.606 F1000
G1 X32.865 Y139.376 F1000
G1 X33.76 Y139.164 F1000
G1 X34.657 Y138.967 F1000
G1 X35.558 Y138.785 F1000
G1 X36.461 Y138.615 F1000
G1 X37.366 Y138.456 F1000
G1 X38.274 Y138.309 F1000
G1 X39.182 Y138.171 F1000
G1 X40.092 Y138.042 F1000
G1 X41.003 Y137.92 F1000
G1 X41.915 Y137.807 F1000
G1 X42.828 Y137.7 F1000
G1 X43.741 Y137.6 F1000
G1 X44.656 Y137.506 F1000
G1 X45.57 Y137.417 F1000
G1 X46.485 Y137.333 F1000
G1 X47.401 Y137.254 F1000
G1 X48.317 Y137.18 F1000
G1 X49.233 Y137.109 F1000
G1 X50.15 Y137.042 F1000
G1 X51.067 Y136.978 F1000
G1 X51.984 Y136.918 F1000
G1 X52.901 Y136.86 F1000
G1 X53.818 Y136.806 F1000
G1 X54.736 Y136.753 F1000
G1 X55.654 Y136.703 F1000
G1 X56.571 Y136.654 F1000
G1 X57.489 Y136.607 F1000
G1 X58.407 Y136.562 F1000
G1 X59.325 Y136.518 F1000
G1 X61.161 Y136.434 F1000
G1 X62.997 Y136.353 F1000
G1 X65.752 Y136.235 F1000
G1 X68.507 Y136.12 F1000
G1 X72.179 Y135.964 F1000
G1 X74.934 Y135.844 F1000
G1 X77.688 Y135.721 F1000
G1 X80.442 Y135.594 F1000
G1 X84.114 Y135.422 F1000
G1 X90.54 Y135.117 F1000
G1 X93.294 Y134.988 F1000
G1 X96.048 Y134.864 F1000
G1 X97.885 Y134.783 F1000
G1 X99.721 Y134.705 F1000
G1 X101.558 Y134.629 F1000
G1 X103.394 Y134.557 F1000
G1 X105.231 Y134.488 F1000
G1 X107.068 Y134.423 F1000
G1 X108.905 Y134.361 F1000
G1 X110.742 Y134.302 F1000
G1 X112.579 Y134.248 F1000
G1 X114.417 Y134.197 F1000
G1 X116.254 Y134.15 F1000
G1 X118.092 Y134.107 F1000
G1 X119.01 Y134.087 F1000
G1 X120.848 Y134.05 F1000
G1 X122.686 Y134.017 F1000
G1 X124.524 Y133.988 F1000
G1 X125.442 Y133.975 F1000
G1 X126.361 Y133.963 F1000
G1 X127.28 Y133.952 F1000
G1 X128.199 Y133.942 F1000
G1 X129.118 Y133.933 F1000
G1 X130.037 Y133.925 F1000
G1 X130.956 Y133.919 F1000
G1 X131.875 Y133.913 F1000
G1 X132.794 Y133.909 F1000
G1 X133.713 Y133.906 F1000
G1 X134.632 Y133.904 F1000
G1 X135.551 Y133.903 F1000
G1 X136.47 F1000
G1 X137.389 Y133.905 F1000
G1 X138.308 Y133.909 F1000
G1 X139.227 Y133.914 F1000
G1 X140.146 Y133.92 F1000
G1 X141.065 Y133.928 F1000
G1 X141.984 Y133.938 F1000
G1 X142.903 Y133.949 F1000
G1 X143.822 Y133.963 F1000
G1 X144.741 Y133.978 F1000
G1 X145.66 Y133.996 F1000
G1 X146.579 Y134.015 F1000
G1 X147.498 Y134.037 F1000
G1 X148.416 Y134.061 F1000
G1 X149.335 Y134.088 F1000
G1 X150.253 Y134.118 F1000
G1 X151.172 Y134.15 F1000
G1 X152.09 Y134.186 F1000
G1 X153.008 Y134.224 F1000
G1 X153.926 Y134.266 F1000
G1 X154.844 Y134.312 F1000
G1 X155.762 Y134.362 F1000
G1 X156.68 Y134.415 F1000
G1 X157.597 Y134.474 F1000
G1 X158.514 Y134.537 F1000
G1 X159.43 Y134.605 F1000
G1 X160.346 Y134.679 F1000
G1 X161.262 Y134.759 F1000
G1 X162.176 Y134.846 F1000
G1 X163.091 Y134.94 F1000
G1 X164.004 Y135.043 F1000
G1 X164.916 Y135.155 F1000
G1 X165.827 Y135.278 F1000
G1 X166.736 Y135.412 F1000
G1 X167.643 Y135.561 F1000
G1 X168.547 Y135.725 F1000
G1 X169.447 Y135.91 F1000
G1 X170.342 Y136.119 F1000
G1 X171.229 Y136.359 F1000
G1 X172.08 Y136.637 F1000
G1 X172.639 Y136.872 F1000
G1 X172.935 Y137.025 F1000
G1 X173.204 Y137.204 F1000
G1 X173.428 Y137.437 F1000
G1 X173.596 Y137.713 F1000
G1 X173.701 Y138.019 F1000
G1 X173.736 Y138.341 F1000
G1 Y140.865 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y141.45 I-0.635 J-0.022 F1000
G1 X173.221 Y141.471 Z-3.012 F1000
G1 X173.153 Y141.491 Z-3 F1000
G1 X173.088 Y141.512 Z-2.98 F1000
G1 X173.025 Y141.531 Z-2.953 F1000
G1 X172.966 Y141.549 Z-2.919 F1000
G1 X172.91 Y141.566 Z-2.877 F1000
G1 X172.859 Y141.582 Z-2.83 F1000
G1 X172.814 Y141.596 Z-2.777 F1000
G1 X172.775 Y141.608 Z-2.719 F1000
G1 X172.742 Y141.618 Z-2.657 F1000
G1 X172.716 Y141.626 Z-2.591 F1000
G1 X172.697 Y141.632 Z-2.522 F1000
G1 X172.685 Y141.636 Z-2.452 F1000
G1 X172.682 Y141.637 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y148.45 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y148.447 Z-2.452 F1000
G1 X22.509 Y148.437 Z-2.522 F1000
G1 X22.499 Y148.42 Z-2.591 F1000
G1 X22.485 Y148.396 Z-2.657 F1000
G1 X22.467 Y148.367 Z-2.719 F1000
G1 X22.446 Y148.331 Z-2.777 F1000
G1 X22.422 Y148.29 Z-2.83 F1000
G1 X22.395 Y148.245 Z-2.877 F1000
G1 X22.365 Y148.195 Z-2.919 F1000
G1 X22.333 Y148.141 Z-2.953 F1000
G1 X22.3 Y148.085 Z-2.98 F1000
G1 X22.265 Y148.026 Z-3 F1000
G1 X22.229 Y147.966 Z-3.012 F1000
G1 X22.192 Y147.905 Z-3.016 F1000
G3 X21.971 Y147.151 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y144.645 F1000
G1 X21.988 Y144.3 F1000
G1 X22.02 Y144.057 F1000
G1 X22.082 Y143.769 F1000
G1 X22.173 Y143.465 F1000
G1 X22.303 Y143.131 F1000
G1 X22.488 Y142.75 F1000
G1 X22.713 Y142.367 F1000
G1 X23.02 Y141.93 F1000
G1 X23.395 Y141.478 F1000
G1 X23.874 Y140.988 F1000
G1 X24.483 Y140.456 F1000
G1 X25.222 Y139.909 F1000
G1 X26.001 Y139.421 F1000
G1 X26.809 Y138.983 F1000
G1 X27.638 Y138.588 F1000
G1 X28.485 Y138.23 F1000
G1 X29.344 Y137.905 F1000
G1 X30.214 Y137.608 F1000
G1 X31.092 Y137.336 F1000
G1 X31.977 Y137.087 F1000
G1 X32.866 Y136.856 F1000
G1 X33.76 Y136.644 F1000
G1 X34.658 Y136.447 F1000
G1 X35.559 Y136.264 F1000
G1 X36.462 Y136.093 F1000
G1 X37.367 Y135.935 F1000
G1 X38.274 Y135.786 F1000
G1 X39.183 Y135.648 F1000
G1 X40.092 Y135.518 F1000
G1 X41.003 Y135.397 F1000
G1 X41.915 Y135.283 F1000
G1 X42.828 Y135.175 F1000
G1 X43.741 Y135.075 F1000
G1 X44.656 Y134.98 F1000
G1 X45.57 Y134.89 F1000
G1 X46.485 Y134.806 F1000
G1 X47.401 Y134.726 F1000
G1 X48.317 Y134.651 F1000
G1 X49.233 Y134.58 F1000
G1 X50.15 Y134.512 F1000
G1 X51.066 Y134.448 F1000
G1 X51.983 Y134.387 F1000
G1 X52.901 Y134.329 F1000
G1 X53.818 Y134.273 F1000
G1 X54.735 Y134.22 F1000
G1 X55.653 Y134.169 F1000
G1 X56.571 Y134.12 F1000
G1 X57.488 Y134.072 F1000
G1 X58.406 Y134.026 F1000
G1 X59.324 Y133.982 F1000
G1 X60.242 Y133.939 F1000
G1 X62.078 Y133.855 F1000
G1 X63.915 Y133.774 F1000
G1 X67.587 Y133.617 F1000
G1 X68.506 Y133.578 F1000
G1 X72.178 Y133.421 F1000
G1 X74.933 Y133.3 F1000
G1 X77.687 Y133.177 F1000
G1 X80.441 Y133.05 F1000
G1 X84.113 Y132.878 F1000
G1 X90.539 Y132.574 F1000
G1 X93.293 Y132.447 F1000
G1 X96.048 Y132.323 F1000
G1 X97.884 Y132.243 F1000
G1 X99.72 Y132.165 F1000
G1 X101.557 Y132.09 F1000
G1 X103.393 Y132.018 F1000
G1 X105.23 Y131.95 F1000
G1 X107.067 Y131.885 F1000
G1 X108.904 Y131.823 F1000
G1 X110.741 Y131.765 F1000
G1 X112.578 Y131.711 F1000
G1 X114.416 Y131.66 F1000
G1 X116.253 Y131.613 F1000
G1 X118.091 Y131.571 F1000
G1 X119.01 Y131.551 F1000
G1 X120.847 Y131.514 F1000
G1 X122.685 Y131.481 F1000
G1 X124.523 Y131.452 F1000
G1 X125.442 Y131.439 F1000
G1 X126.361 Y131.427 F1000
G1 X127.28 Y131.416 F1000
G1 X128.199 Y131.406 F1000
G1 X129.118 Y131.397 F1000
G1 X130.037 Y131.39 F1000
G1 X130.956 Y131.383 F1000
G1 X131.875 Y131.378 F1000
G1 X132.794 Y131.373 F1000
G1 X133.713 Y131.37 F1000
G1 X134.632 Y131.369 F1000
G1 X135.551 Y131.368 F1000
G1 X136.47 Y131.369 F1000
G1 X137.389 Y131.371 F1000
G1 X138.308 Y131.375 F1000
G1 X139.227 Y131.38 F1000
G1 X140.146 Y131.386 F1000
G1 X141.065 Y131.395 F1000
G1 X141.984 Y131.405 F1000
G1 X142.903 Y131.416 F1000
G1 X143.822 Y131.43 F1000
G1 X144.74 Y131.446 F1000
G1 X145.659 Y131.463 F1000
G1 X146.578 Y131.483 F1000
G1 X147.497 Y131.505 F1000
G1 X148.415 Y131.53 F1000
G1 X149.334 Y131.557 F1000
G1 X150.253 Y131.587 F1000
G1 X151.171 Y131.62 F1000
G1 X152.089 Y131.655 F1000
G1 X153.008 Y131.694 F1000
G1 X153.926 Y131.737 F1000
G1 X154.844 Y131.783 F1000
G1 X155.761 Y131.833 F1000
G1 X156.679 Y131.887 F1000
G1 X157.596 Y131.946 F1000
G1 X158.513 Y132.009 F1000
G1 X159.429 Y132.078 F1000
G1 X160.345 Y132.152 F1000
G1 X161.261 Y132.232 F1000
G1 X162.175 Y132.319 F1000
G1 X163.09 Y132.414 F1000
G1 X164.003 Y132.517 F1000
G1 X164.915 Y132.629 F1000
G1 X165.826 Y132.752 F1000
G1 X166.735 Y132.887 F1000
G1 X167.642 Y133.035 F1000
G1 X168.546 Y133.2 F1000
G1 X169.446 Y133.385 F1000
G1 X170.341 Y133.594 F1000
G1 X171.228 Y133.834 F1000
G1 X172.079 Y134.113 F1000
G1 X172.638 Y134.347 F1000
G1 X172.935 Y134.5 F1000
G1 X173.204 Y134.679 F1000
G1 X173.428 Y134.912 F1000
G1 X173.596 Y135.189 F1000
G1 X173.701 Y135.495 F1000
G1 X173.736 Y135.816 F1000
G1 Y138.341 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y138.926 I-0.635 J-0.022 F1000
G1 X173.221 Y138.946 Z-3.012 F1000
G1 X173.153 Y138.967 Z-3 F1000
G1 X173.088 Y138.987 Z-2.98 F1000
G1 X173.025 Y139.007 Z-2.953 F1000
G1 X172.966 Y139.025 Z-2.919 F1000
G1 X172.91 Y139.042 Z-2.877 F1000
G1 X172.859 Y139.058 Z-2.83 F1000
G1 X172.814 Y139.072 Z-2.777 F1000
G1 X172.775 Y139.084 Z-2.719 F1000
G1 X172.742 Y139.094 Z-2.657 F1000
G1 X172.716 Y139.102 Z-2.591 F1000
G1 X172.697 Y139.108 Z-2.522 F1000
G1 X172.685 Y139.111 Z-2.452 F1000
G1 X172.682 Y139.113 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y145.944 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y145.941 Z-2.452 F1000
G1 X22.509 Y145.931 Z-2.522 F1000
G1 X22.499 Y145.914 Z-2.591 F1000
G1 X22.485 Y145.89 Z-2.657 F1000
G1 X22.467 Y145.861 Z-2.719 F1000
G1 X22.446 Y145.825 Z-2.777 F1000
G1 X22.422 Y145.784 Z-2.83 F1000
G1 X22.395 Y145.739 Z-2.877 F1000
G1 X22.365 Y145.689 Z-2.919 F1000
G1 X22.333 Y145.635 Z-2.953 F1000
G1 X22.3 Y145.579 Z-2.98 F1000
G1 X22.265 Y145.52 Z-3 F1000
G1 X22.229 Y145.46 Z-3.012 F1000
G1 X22.192 Y145.399 Z-3.016 F1000
G3 X21.971 Y144.645 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y142.139 F1000
G1 X21.989 Y141.782 F1000
G1 X22.021 Y141.54 F1000
G1 X22.082 Y141.251 F1000
G1 X22.174 Y140.947 F1000
G1 X22.304 Y140.613 F1000
G1 X22.488 Y140.232 F1000
G1 X22.714 Y139.85 F1000
G1 X23.021 Y139.412 F1000
G1 X23.396 Y138.96 F1000
G1 X23.875 Y138.469 F1000
G1 X24.485 Y137.937 F1000
G1 X25.224 Y137.391 F1000
G1 X26.002 Y136.902 F1000
G1 X26.81 Y136.464 F1000
G1 X27.64 Y136.069 F1000
G1 X28.486 Y135.711 F1000
G1 X29.346 Y135.386 F1000
G1 X30.215 Y135.089 F1000
G1 X31.093 Y134.817 F1000
G1 X31.978 Y134.567 F1000
G1 X32.867 Y134.336 F1000
G1 X33.761 Y134.123 F1000
G1 X34.659 Y133.926 F1000
G1 X35.559 Y133.742 F1000
G1 X36.462 Y133.572 F1000
G1 X37.368 Y133.412 F1000
G1 X38.274 Y133.264 F1000
G1 X39.183 Y133.125 F1000
G1 X40.093 Y132.995 F1000
G1 X41.004 Y132.873 F1000
G1 X41.915 Y132.758 F1000
G1 X42.828 Y132.65 F1000
G1 X43.741 Y132.549 F1000
G1 X44.656 Y132.454 F1000
G1 X45.57 Y132.364 F1000
G1 X46.485 Y132.279 F1000
G1 X47.401 Y132.198 F1000
G1 X48.317 Y132.122 F1000
G1 X49.233 Y132.05 F1000
G1 X50.149 Y131.982 F1000
G1 X51.066 Y131.917 F1000
G1 X51.983 Y131.856 F1000
G1 X52.9 Y131.797 F1000
G1 X53.817 Y131.74 F1000
G1 X54.735 Y131.687 F1000
G1 X55.652 Y131.635 F1000
G1 X56.57 Y131.585 F1000
G1 X57.488 Y131.537 F1000
G1 X58.406 Y131.491 F1000
G1 X59.324 Y131.445 F1000
G1 X60.242 Y131.402 F1000
G1 X62.078 Y131.317 F1000
G1 X63.914 Y131.235 F1000
G1 X67.586 Y131.076 F1000
G1 X68.505 Y131.036 F1000
G1 X72.177 Y130.878 F1000
G1 X74.932 Y130.756 F1000
G1 X77.686 Y130.633 F1000
G1 X80.44 Y130.506 F1000
G1 X85.03 Y130.291 F1000
G1 X90.538 Y130.032 F1000
G1 X93.292 Y129.906 F1000
G1 X96.047 Y129.782 F1000
G1 X97.883 Y129.703 F1000
G1 X99.719 Y129.626 F1000
G1 X101.556 Y129.551 F1000
G1 X103.393 Y129.48 F1000
G1 X105.229 Y129.411 F1000
G1 X107.066 Y129.347 F1000
G1 X108.903 Y129.285 F1000
G1 X110.74 Y129.227 F1000
G1 X112.578 Y129.173 F1000
G1 X114.415 Y129.123 F1000
G1 X116.253 Y129.077 F1000
G1 X118.09 Y129.034 F1000
G1 X119.009 Y129.014 F1000
G1 X120.847 Y128.978 F1000
G1 X122.684 Y128.945 F1000
G1 X124.522 Y128.916 F1000
G1 X125.441 Y128.903 F1000
G1 X126.36 Y128.891 F1000
G1 X127.279 Y128.88 F1000
G1 X128.198 Y128.87 F1000
G1 X129.117 Y128.862 F1000
G1 X130.036 Y128.854 F1000
G1 X130.955 Y128.848 F1000
G1 X131.874 Y128.842 F1000
G1 X132.793 Y128.838 F1000
G1 X133.712 Y128.835 F1000
G1 X134.631 Y128.834 F1000
G1 X135.55 Y128.833 F1000
G1 X136.469 Y128.834 F1000
G1 X137.388 Y128.837 F1000
G1 X138.307 Y128.84 F1000
G1 X139.226 Y128.846 F1000
G1 X140.145 Y128.852 F1000
G1 X141.064 Y128.861 F1000
G1 X141.983 Y128.871 F1000
G1 X142.902 Y128.883 F1000
G1 X143.821 Y128.897 F1000
G1 X144.74 Y128.913 F1000
G1 X145.659 Y128.931 F1000
G1 X146.577 Y128.951 F1000
G1 X147.496 Y128.974 F1000
G1 X148.415 Y128.998 F1000
G1 X149.333 Y129.026 F1000
G1 X150.252 Y129.056 F1000
G1 X151.17 Y129.089 F1000
G1 X152.089 Y129.125 F1000
G1 X153.007 Y129.165 F1000
G1 X153.925 Y129.207 F1000
G1 X154.843 Y129.254 F1000
G1 X155.76 Y129.304 F1000
G1 X156.678 Y129.358 F1000
G1 X157.595 Y129.417 F1000
G1 X158.512 Y129.481 F1000
G1 X159.428 Y129.55 F1000
G1 X160.344 Y129.624 F1000
G1 X161.26 Y129.705 F1000
G1 X162.174 Y129.792 F1000
G1 X163.089 Y129.887 F1000
G1 X164.002 Y129.99 F1000
G1 X164.914 Y130.103 F1000
G1 X165.825 Y130.226 F1000
G1 X166.734 Y130.361 F1000
G1 X167.641 Y130.51 F1000
G1 X168.545 Y130.675 F1000
G1 X169.445 Y130.859 F1000
G1 X170.34 Y131.068 F1000
G1 X171.227 Y131.309 F1000
G1 X172.079 Y131.588 F1000
G1 X172.638 Y131.822 F1000
G1 X172.935 Y131.976 F1000
G1 X173.204 Y132.155 F1000
G1 X173.428 Y132.388 F1000
G1 X173.596 Y132.664 F1000
G1 X173.701 Y132.97 F1000
G1 X173.736 Y133.292 F1000
G1 Y135.816 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y136.401 I-0.635 J-0.022 F1000
G1 X173.221 Y136.422 Z-3.012 F1000
G1 X173.153 Y136.443 Z-3 F1000
G1 X173.088 Y136.463 Z-2.98 F1000
G1 X173.025 Y136.482 Z-2.953 F1000
G1 X172.966 Y136.501 Z-2.919 F1000
G1 X172.91 Y136.518 Z-2.877 F1000
G1 X172.859 Y136.533 Z-2.83 F1000
G1 X172.814 Y136.547 Z-2.777 F1000
G1 X172.775 Y136.559 Z-2.719 F1000
G1 X172.742 Y136.57 Z-2.657 F1000
G1 X172.716 Y136.578 Z-2.591 F1000
G1 X172.697 Y136.583 Z-2.522 F1000
G1 X172.685 Y136.587 Z-2.452 F1000
G1 X172.682 Y136.588 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y143.438 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y143.435 Z-2.452 F1000
G1 X22.509 Y143.425 Z-2.522 F1000
G1 X22.499 Y143.408 Z-2.591 F1000
G1 X22.485 Y143.384 Z-2.657 F1000
G1 X22.467 Y143.355 Z-2.719 F1000
G1 X22.446 Y143.319 Z-2.777 F1000
G1 X22.422 Y143.278 Z-2.83 F1000
G1 X22.395 Y143.233 Z-2.877 F1000
G1 X22.365 Y143.183 Z-2.919 F1000
G1 X22.333 Y143.129 Z-2.953 F1000
G1 X22.3 Y143.073 Z-2.98 F1000
G1 X22.265 Y143.014 Z-3 F1000
G1 X22.229 Y142.954 Z-3.012 F1000
G1 X22.192 Y142.893 Z-3.016 F1000
G3 X21.971 Y142.139 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y139.633 F1000
G1 X21.989 Y139.264 F1000
G1 X22.021 Y139.022 F1000
G1 X22.083 Y138.733 F1000
G1 X22.174 Y138.429 F1000
G1 X22.304 Y138.095 F1000
G1 X22.489 Y137.714 F1000
G1 X22.714 Y137.331 F1000
G1 X23.022 Y136.894 F1000
G1 X23.397 Y136.441 F1000
G1 X23.876 Y135.951 F1000
G1 X24.486 Y135.418 F1000
G1 X25.225 Y134.872 F1000
G1 X26.004 Y134.383 F1000
G1 X26.811 Y133.945 F1000
G1 X27.641 Y133.55 F1000
G1 X28.488 Y133.192 F1000
G1 X29.347 Y132.866 F1000
G1 X30.217 Y132.569 F1000
G1 X31.094 Y132.297 F1000
G1 X31.979 Y132.046 F1000
G1 X32.868 Y131.816 F1000
G1 X33.762 Y131.602 F1000
G1 X34.66 Y131.404 F1000
G1 X35.56 Y131.221 F1000
G1 X36.463 Y131.05 F1000
G1 X37.368 Y130.89 F1000
G1 X38.275 Y130.741 F1000
G1 X39.183 Y130.601 F1000
G1 X40.093 Y130.471 F1000
G1 X41.004 Y130.348 F1000
G1 X41.916 Y130.233 F1000
G1 X42.828 Y130.125 F1000
G1 X43.742 Y130.023 F1000
G1 X44.656 Y129.927 F1000
G1 X45.57 Y129.836 F1000
G1 X46.485 Y129.751 F1000
G1 X47.401 Y129.67 F1000
G1 X48.316 Y129.594 F1000
G1 X49.233 Y129.521 F1000
G1 X50.149 Y129.452 F1000
G1 X51.066 Y129.387 F1000
G1 X51.983 Y129.324 F1000
G1 X52.9 Y129.265 F1000
G1 X53.817 Y129.208 F1000
G1 X54.734 Y129.153 F1000
G1 X55.652 Y129.101 F1000
G1 X56.569 Y129.05 F1000
G1 X57.487 Y129.002 F1000
G1 X58.405 Y128.955 F1000
G1 X59.323 Y128.909 F1000
G1 X60.241 Y128.864 F1000
G1 X62.077 Y128.778 F1000
G1 X63.913 Y128.695 F1000
G1 X66.667 Y128.574 F1000
G1 X68.504 Y128.494 F1000
G1 X73.095 Y128.294 F1000
G1 X75.849 Y128.172 F1000
G1 X78.603 Y128.047 F1000
G1 X82.275 Y127.877 F1000
G1 X89.619 Y127.533 F1000
G1 X92.373 Y127.406 F1000
G1 X95.128 Y127.282 F1000
G1 X96.964 Y127.202 F1000
G1 X98.8 Y127.124 F1000
G1 X100.637 Y127.049 F1000
G1 X102.474 Y126.976 F1000
G1 X104.31 Y126.907 F1000
G1 X106.147 Y126.84 F1000
G1 X107.984 Y126.778 F1000
G1 X109.821 Y126.718 F1000
G1 X111.658 Y126.663 F1000
G1 X113.496 Y126.611 F1000
G1 X115.333 Y126.563 F1000
G1 X117.171 Y126.518 F1000
G1 X119.008 Y126.478 F1000
G1 X120.846 Y126.441 F1000
G1 X122.684 Y126.408 F1000
G1 X124.521 Y126.38 F1000
G1 X125.44 Y126.367 F1000
G1 X126.359 Y126.355 F1000
G1 X127.278 Y126.344 F1000
G1 X128.197 Y126.335 F1000
G1 X129.116 Y126.326 F1000
G1 X130.035 Y126.319 F1000
G1 X130.954 Y126.312 F1000
G1 X131.873 Y126.307 F1000
G1 X132.792 Y126.303 F1000
G1 X133.711 Y126.3 F1000
G1 X134.63 Y126.299 F1000
G1 X135.549 Y126.298 F1000
G1 X136.468 Y126.3 F1000
G1 X137.387 Y126.302 F1000
G1 X138.306 Y126.306 F1000
G1 X139.225 Y126.312 F1000
G1 X140.144 Y126.319 F1000
G1 X141.063 Y126.327 F1000
G1 X141.982 Y126.338 F1000
G1 X142.901 Y126.35 F1000
G1 X143.82 Y126.364 F1000
G1 X144.739 Y126.38 F1000
G1 X145.658 Y126.399 F1000
G1 X146.577 Y126.419 F1000
G1 X147.495 Y126.442 F1000
G1 X148.414 Y126.467 F1000
G1 X149.333 Y126.495 F1000
G1 X150.251 Y126.525 F1000
G1 X151.17 Y126.559 F1000
G1 X152.088 Y126.595 F1000
G1 X153.006 Y126.635 F1000
G1 X153.924 Y126.678 F1000
G1 X154.842 Y126.724 F1000
G1 X155.759 Y126.775 F1000
G1 X156.677 Y126.83 F1000
G1 X157.594 Y126.889 F1000
G1 X158.511 Y126.953 F1000
G1 X159.427 Y127.022 F1000
G1 X160.343 Y127.097 F1000
G1 X161.259 Y127.178 F1000
G1 X162.173 Y127.266 F1000
G1 X163.088 Y127.361 F1000
G1 X164.001 Y127.464 F1000
G1 X164.913 Y127.577 F1000
G1 X165.824 Y127.7 F1000
G1 X166.733 Y127.835 F1000
G1 X167.639 Y127.984 F1000
G1 X168.543 Y128.149 F1000
G1 X169.444 Y128.334 F1000
G1 X170.339 Y128.543 F1000
G1 X171.226 Y128.783 F1000
G1 X172.078 Y129.063 F1000
G1 X172.638 Y129.297 F1000
G1 X172.935 Y129.451 F1000
G1 X173.204 Y129.63 F1000
G1 X173.428 Y129.863 F1000
G1 X173.596 Y130.139 F1000
G1 X173.701 Y130.445 F1000
G1 X173.736 Y130.767 F1000
G1 Y133.292 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y133.876 I-0.635 J-0.022 F1000
G1 X173.221 Y133.897 Z-3.012 F1000
G1 X173.153 Y133.918 Z-3 F1000
G1 X173.088 Y133.938 Z-2.98 F1000
G1 X173.025 Y133.958 Z-2.953 F1000
G1 X172.966 Y133.976 Z-2.919 F1000
G1 X172.91 Y133.993 Z-2.877 F1000
G1 X172.859 Y134.009 Z-2.83 F1000
G1 X172.814 Y134.023 Z-2.777 F1000
G1 X172.775 Y134.035 Z-2.719 F1000
G1 X172.742 Y134.045 Z-2.657 F1000
G1 X172.716 Y134.053 Z-2.591 F1000
G1 X172.697 Y134.059 Z-2.522 F1000
G1 X172.685 Y134.062 Z-2.452 F1000
G1 X172.682 Y134.063 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y140.932 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y140.929 Z-2.452 F1000
G1 X22.509 Y140.919 Z-2.522 F1000
G1 X22.499 Y140.902 Z-2.591 F1000
G1 X22.485 Y140.878 Z-2.657 F1000
G1 X22.467 Y140.849 Z-2.719 F1000
G1 X22.446 Y140.813 Z-2.777 F1000
G1 X22.422 Y140.772 Z-2.83 F1000
G1 X22.395 Y140.727 Z-2.877 F1000
G1 X22.365 Y140.677 Z-2.919 F1000
G1 X22.333 Y140.623 Z-2.953 F1000
G1 X22.3 Y140.567 Z-2.98 F1000
G1 X22.265 Y140.508 Z-3 F1000
G1 X22.229 Y140.448 Z-3.012 F1000
G1 X22.192 Y140.386 Z-3.016 F1000
G3 X21.971 Y139.633 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y136.918 F1000
G1 X21.979 Y136.756 F1000
G1 X22.011 Y136.513 F1000
G1 X22.073 Y136.225 F1000
G1 X22.164 Y135.918 F1000
G1 X22.295 Y135.584 F1000
G1 X22.48 Y135.202 F1000
G1 X22.706 Y134.819 F1000
G1 X23.014 Y134.38 F1000
G1 X23.39 Y133.927 F1000
G1 X23.87 Y133.435 F1000
G1 X24.481 Y132.902 F1000
G1 X25.22 Y132.355 F1000
G1 X25.998 Y131.867 F1000
G1 X26.806 Y131.428 F1000
G1 X27.636 Y131.033 F1000
G1 X28.482 Y130.674 F1000
G1 X29.341 Y130.348 F1000
G1 X30.211 Y130.051 F1000
G1 X31.088 Y129.778 F1000
G1 X31.973 Y129.528 F1000
G1 X32.862 Y129.296 F1000
G1 X33.756 Y129.083 F1000
G1 X34.653 Y128.884 F1000
G1 X35.554 Y128.7 F1000
G1 X36.456 Y128.529 F1000
G1 X37.361 Y128.368 F1000
G1 X38.268 Y128.219 F1000
G1 X39.177 Y128.079 F1000
G1 X40.086 Y127.948 F1000
G1 X40.997 Y127.825 F1000
G1 X41.909 Y127.709 F1000
G1 X42.821 Y127.6 F1000
G1 X43.734 Y127.498 F1000
G1 X44.648 Y127.401 F1000
G1 X45.563 Y127.31 F1000
G1 X46.478 Y127.224 F1000
G1 X47.393 Y127.142 F1000
G1 X48.309 Y127.065 F1000
G1 X49.225 Y126.992 F1000
G1 X50.141 Y126.922 F1000
G1 X51.058 Y126.856 F1000
G1 X51.975 Y126.793 F1000
G1 X52.892 Y126.733 F1000
G1 X53.809 Y126.675 F1000
G1 X54.727 Y126.62 F1000
G1 X55.644 Y126.567 F1000
G1 X56.562 Y126.516 F1000
G1 X57.479 Y126.467 F1000
G1 X58.397 Y126.419 F1000
G1 X59.315 Y126.373 F1000
G1 X60.233 Y126.328 F1000
G1 X62.069 Y126.24 F1000
G1 X63.905 Y126.156 F1000
G1 X66.659 Y126.034 F1000
G1 X69.414 Y125.913 F1000
G1 X74.004 Y125.711 F1000
G1 X77.677 Y125.546 F1000
G1 X81.349 Y125.377 F1000
G1 X89.611 Y124.991 F1000
G1 X92.365 Y124.865 F1000
G1 X95.12 Y124.742 F1000
G1 X96.956 Y124.662 F1000
G1 X98.792 Y124.585 F1000
G1 X100.629 Y124.51 F1000
G1 X102.465 Y124.438 F1000
G1 X104.302 Y124.368 F1000
G1 X106.139 Y124.303 F1000
G1 X107.976 Y124.24 F1000
G1 X109.813 Y124.181 F1000
G1 X111.65 Y124.126 F1000
G1 X113.488 Y124.074 F1000
G1 X115.325 Y124.026 F1000
G1 X117.163 Y123.982 F1000
G1 X119 Y123.941 F1000
G1 X119.919 Y123.923 F1000
G1 X121.757 Y123.888 F1000
G1 X123.595 Y123.858 F1000
G1 X124.513 Y123.844 F1000
G1 X125.432 Y123.831 F1000
G1 X126.351 Y123.819 F1000
G1 X127.27 Y123.809 F1000
G1 X128.189 Y123.799 F1000
G1 X129.108 Y123.791 F1000
G1 X130.027 Y123.783 F1000
G1 X130.946 Y123.777 F1000
G1 X131.865 Y123.772 F1000
G1 X132.784 Y123.768 F1000
G1 X133.703 Y123.765 F1000
G1 X134.622 Y123.764 F1000
G1 X135.541 F1000
G1 X136.46 Y123.765 F1000
G1 X137.379 Y123.768 F1000
G1 X138.298 Y123.772 F1000
G1 X139.217 Y123.778 F1000
G1 X140.136 Y123.785 F1000
G1 X141.055 Y123.794 F1000
G1 X141.974 Y123.805 F1000
G1 X142.893 Y123.817 F1000
G1 X143.812 Y123.831 F1000
G1 X144.731 Y123.848 F1000
G1 X145.65 Y123.866 F1000
G1 X146.569 Y123.887 F1000
G1 X147.487 Y123.91 F1000
G1 X148.406 Y123.935 F1000
G1 X149.325 Y123.964 F1000
G1 X150.243 Y123.994 F1000
G1 X151.162 Y124.028 F1000
G1 X152.08 Y124.065 F1000
G1 X152.998 Y124.104 F1000
G1 X153.916 Y124.148 F1000
G1 X154.834 Y124.195 F1000
G1 X155.751 Y124.246 F1000
G1 X156.669 Y124.301 F1000
G1 X157.586 Y124.36 F1000
G1 X158.503 Y124.424 F1000
G1 X159.419 Y124.494 F1000
G1 X160.335 Y124.569 F1000
G1 X161.25 Y124.65 F1000
G1 X162.165 Y124.738 F1000
G1 X163.079 Y124.833 F1000
G1 X163.992 Y124.937 F1000
G1 X164.905 Y125.049 F1000
G1 X165.815 Y125.173 F1000
G1 X166.724 Y125.308 F1000
G1 X167.631 Y125.457 F1000
G1 X168.535 Y125.622 F1000
G1 X169.435 Y125.807 F1000
G1 X170.33 Y126.016 F1000
G1 X171.217 Y126.256 F1000
G1 X172.074 Y126.536 F1000
G1 X172.634 Y126.771 F1000
G1 X172.934 Y126.925 F1000
G1 X173.204 Y127.104 F1000
G1 X173.428 Y127.338 F1000
G1 X173.596 Y127.614 F1000
G1 X173.701 Y127.92 F1000
G1 X173.736 Y128.242 F1000
G1 Y130.767 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y131.352 I-0.635 J-0.022 F1000
G1 X173.221 Y131.373 Z-3.012 F1000
G1 X173.153 Y131.393 Z-3 F1000
G1 X173.088 Y131.413 Z-2.98 F1000
G1 X173.025 Y131.433 Z-2.953 F1000
G1 X172.966 Y131.451 Z-2.919 F1000
G1 X172.91 Y131.468 Z-2.877 F1000
G1 X172.859 Y131.484 Z-2.83 F1000
G1 X172.814 Y131.498 Z-2.777 F1000
G1 X172.775 Y131.51 Z-2.719 F1000
G1 X172.742 Y131.52 Z-2.657 F1000
G1 X172.716 Y131.528 Z-2.591 F1000
G1 X172.697 Y131.534 Z-2.522 F1000
G1 X172.685 Y131.537 Z-2.452 F1000
G1 X172.682 Y131.539 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y138.217 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y138.214 Z-2.452 F1000
G1 X22.509 Y138.204 Z-2.522 F1000
G1 X22.499 Y138.187 Z-2.591 F1000
G1 X22.485 Y138.163 Z-2.657 F1000
G1 X22.467 Y138.134 Z-2.719 F1000
G1 X22.446 Y138.098 Z-2.777 F1000
G1 X22.422 Y138.058 Z-2.83 F1000
G1 X22.395 Y138.012 Z-2.877 F1000
G1 X22.365 Y137.962 Z-2.919 F1000
G1 X22.333 Y137.908 Z-2.953 F1000
G1 X22.3 Y137.852 Z-2.98 F1000
G1 X22.265 Y137.793 Z-3 F1000
G1 X22.229 Y137.733 Z-3.012 F1000
G1 X22.192 Y137.672 Z-3.016 F1000
G3 X21.971 Y136.918 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y134.412 F1000
G1 X21.98 Y134.234 F1000
G1 X22.012 Y133.992 F1000
G1 X22.073 Y133.703 F1000
G1 X22.165 Y133.398 F1000
G1 X22.295 Y133.064 F1000
G1 X22.48 Y132.682 F1000
G1 X22.706 Y132.299 F1000
G1 X23.014 Y131.86 F1000
G1 X23.39 Y131.408 F1000
G1 X23.869 Y130.916 F1000
G1 X24.481 Y130.382 F1000
G1 X25.22 Y129.836 F1000
G1 X25.998 Y129.347 F1000
G1 X26.806 Y128.909 F1000
G1 X27.635 Y128.513 F1000
G1 X28.482 Y128.155 F1000
G1 X29.341 Y127.829 F1000
G1 X30.21 Y127.531 F1000
G1 X31.088 Y127.258 F1000
G1 X31.972 Y127.007 F1000
G1 X32.861 Y126.775 F1000
G1 X33.755 Y126.561 F1000
G1 X34.652 Y126.363 F1000
G1 X35.553 Y126.178 F1000
G1 X36.455 Y126.006 F1000
G1 X37.36 Y125.846 F1000
G1 X38.267 Y125.696 F1000
G1 X39.175 Y125.555 F1000
G1 X40.085 Y125.424 F1000
G1 X40.995 Y125.3 F1000
G1 X41.907 Y125.184 F1000
G1 X42.819 Y125.074 F1000
G1 X43.733 Y124.971 F1000
G1 X44.647 Y124.874 F1000
G1 X45.561 Y124.783 F1000
G1 X46.476 Y124.696 F1000
G1 X47.391 Y124.614 F1000
G1 X48.307 Y124.536 F1000
G1 X49.223 Y124.462 F1000
G1 X50.139 Y124.392 F1000
G1 X51.056 Y124.325 F1000
G1 X51.973 Y124.261 F1000
G1 X52.89 Y124.201 F1000
G1 X53.807 Y124.142 F1000
G1 X54.724 Y124.087 F1000
G1 X55.642 Y124.033 F1000
G1 X56.559 Y123.981 F1000
G1 X57.477 Y123.931 F1000
G1 X58.395 Y123.883 F1000
G1 X59.313 Y123.836 F1000
G1 X60.23 Y123.79 F1000
G1 X62.066 Y123.702 F1000
G1 X63.902 Y123.617 F1000
G1 X66.657 Y123.493 F1000
G1 X69.411 Y123.371 F1000
G1 X74.002 Y123.168 F1000
G1 X77.674 Y123.002 F1000
G1 X81.346 Y122.833 F1000
G1 X89.608 Y122.449 F1000
G1 X92.363 Y122.323 F1000
G1 X95.117 Y122.201 F1000
G1 X96.953 Y122.122 F1000
G1 X98.79 Y122.045 F1000
G1 X100.626 Y121.97 F1000
G1 X102.463 Y121.899 F1000
G1 X104.3 Y121.83 F1000
G1 X106.137 Y121.764 F1000
G1 X107.974 Y121.702 F1000
G1 X109.811 Y121.643 F1000
G1 X111.648 Y121.588 F1000
G1 X113.485 Y121.537 F1000
G1 X115.323 Y121.489 F1000
G1 X117.16 Y121.445 F1000
G1 X118.998 Y121.405 F1000
G1 X119.917 Y121.386 F1000
G1 X121.754 Y121.352 F1000
G1 X123.592 Y121.321 F1000
G1 X124.511 Y121.308 F1000
G1 X125.43 Y121.295 F1000
G1 X126.349 Y121.283 F1000
G1 X127.268 Y121.273 F1000
G1 X128.187 Y121.263 F1000
G1 X129.106 Y121.255 F1000
G1 X130.025 Y121.248 F1000
G1 X130.944 Y121.242 F1000
G1 X131.863 Y121.237 F1000
G1 X132.782 Y121.233 F1000
G1 X133.701 Y121.23 F1000
G1 X134.62 Y121.229 F1000
G1 X135.539 F1000
G1 X136.458 Y121.231 F1000
G1 X137.377 Y121.233 F1000
G1 X138.296 Y121.238 F1000
G1 X139.215 Y121.244 F1000
G1 X140.134 Y121.251 F1000
G1 X141.053 Y121.26 F1000
G1 X141.972 Y121.271 F1000
G1 X142.891 Y121.284 F1000
G1 X143.81 Y121.299 F1000
G1 X144.728 Y121.315 F1000
G1 X145.647 Y121.334 F1000
G1 X146.566 Y121.355 F1000
G1 X147.485 Y121.378 F1000
G1 X148.403 Y121.404 F1000
G1 X149.322 Y121.432 F1000
G1 X150.241 Y121.463 F1000
G1 X151.159 Y121.497 F1000
G1 X152.077 Y121.534 F1000
G1 X152.995 Y121.574 F1000
G1 X153.913 Y121.618 F1000
G1 X154.831 Y121.665 F1000
G1 X155.749 Y121.716 F1000
G1 X156.666 Y121.772 F1000
G1 X157.583 Y121.831 F1000
G1 X158.5 Y121.896 F1000
G1 X159.416 Y121.966 F1000
G1 X160.332 Y122.041 F1000
G1 X161.248 Y122.122 F1000
G1 X162.162 Y122.21 F1000
G1 X163.076 Y122.306 F1000
G1 X163.99 Y122.41 F1000
G1 X164.902 Y122.523 F1000
G1 X165.812 Y122.646 F1000
G1 X166.721 Y122.782 F1000
G1 X167.628 Y122.931 F1000
G1 X168.532 Y123.096 F1000
G1 X169.432 Y123.281 F1000
G1 X170.327 Y123.49 F1000
G1 X171.215 Y123.73 F1000
G1 X172.073 Y124.01 F1000
G1 X172.633 Y124.245 F1000
G1 X172.934 Y124.4 F1000
G1 X173.204 Y124.579 F1000
G1 X173.428 Y124.812 F1000
G1 X173.596 Y125.089 F1000
G1 X173.701 Y125.395 F1000
G1 X173.736 Y125.717 F1000
G1 Y128.242 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y128.827 I-0.635 J-0.022 F1000
G1 X173.221 Y128.847 Z-3.012 F1000
G1 X173.153 Y128.868 Z-3 F1000
G1 X173.088 Y128.888 Z-2.98 F1000
G1 X173.025 Y128.908 Z-2.953 F1000
G1 X172.966 Y128.926 Z-2.919 F1000
G1 X172.91 Y128.943 Z-2.877 F1000
G1 X172.859 Y128.959 Z-2.83 F1000
G1 X172.814 Y128.973 Z-2.777 F1000
G1 X172.775 Y128.985 Z-2.719 F1000
G1 X172.742 Y128.995 Z-2.657 F1000
G1 X172.716 Y129.003 Z-2.591 F1000
G1 X172.697 Y129.009 Z-2.522 F1000
G1 X172.685 Y129.012 Z-2.452 F1000
G1 X172.682 Y129.014 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y135.711 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y135.708 Z-2.452 F1000
G1 X22.509 Y135.698 Z-2.522 F1000
G1 X22.499 Y135.681 Z-2.591 F1000
G1 X22.485 Y135.657 Z-2.657 F1000
G1 X22.467 Y135.628 Z-2.719 F1000
G1 X22.446 Y135.592 Z-2.777 F1000
G1 X22.422 Y135.552 Z-2.83 F1000
G1 X22.395 Y135.506 Z-2.877 F1000
G1 X22.365 Y135.456 Z-2.919 F1000
G1 X22.333 Y135.402 Z-2.953 F1000
G1 X22.3 Y135.346 Z-2.98 F1000
G1 X22.265 Y135.287 Z-3 F1000
G1 X22.229 Y135.227 Z-3.012 F1000
G1 X22.192 Y135.166 Z-3.016 F1000
G3 X21.971 Y134.412 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y131.906 F1000
G1 X21.981 Y131.714 F1000
G1 X22.012 Y131.472 F1000
G1 X22.074 Y131.183 F1000
G1 X22.166 Y130.878 F1000
G1 X22.296 Y130.544 F1000
G1 X22.481 Y130.162 F1000
G1 X22.706 Y129.779 F1000
G1 X23.014 Y129.34 F1000
G1 X23.39 Y128.888 F1000
G1 X23.87 Y128.396 F1000
G1 X24.482 Y127.862 F1000
G1 X25.22 Y127.316 F1000
G1 X25.999 Y126.827 F1000
G1 X26.806 Y126.389 F1000
G1 X27.636 Y125.993 F1000
G1 X28.482 Y125.634 F1000
G1 X29.341 Y125.308 F1000
G1 X30.211 Y125.01 F1000
G1 X31.088 Y124.737 F1000
G1 X31.972 Y124.486 F1000
G1 X32.861 Y124.254 F1000
G1 X33.755 Y124.04 F1000
G1 X34.652 Y123.841 F1000
G1 X35.553 Y123.656 F1000
G1 X36.455 Y123.483 F1000
G1 X37.36 Y123.322 F1000
G1 X38.267 Y123.172 F1000
G1 X39.175 Y123.031 F1000
G1 X40.084 Y122.899 F1000
G1 X40.995 Y122.775 F1000
G1 X41.906 Y122.658 F1000
G1 X42.819 Y122.548 F1000
G1 X43.732 Y122.445 F1000
G1 X44.646 Y122.347 F1000
G1 X45.56 Y122.255 F1000
G1 X46.475 Y122.168 F1000
G1 X47.39 Y122.085 F1000
G1 X48.306 Y122.007 F1000
G1 X49.222 Y121.932 F1000
G1 X50.138 Y121.861 F1000
G1 X51.055 Y121.794 F1000
G1 X51.972 Y121.73 F1000
G1 X52.889 Y121.668 F1000
G1 X53.806 Y121.609 F1000
G1 X54.723 Y121.553 F1000
G1 X55.641 Y121.499 F1000
G1 X56.558 Y121.447 F1000
G1 X57.476 Y121.396 F1000
G1 X58.393 Y121.347 F1000
G1 X59.311 Y121.3 F1000
G1 X60.229 Y121.253 F1000
G1 X62.065 Y121.164 F1000
G1 X63.901 Y121.078 F1000
G1 X66.655 Y120.953 F1000
G1 X69.409 Y120.83 F1000
G1 X74.918 Y120.584 F1000
G1 X78.59 Y120.417 F1000
G1 X84.099 Y120.162 F1000
G1 X89.607 Y119.907 F1000
G1 X92.361 Y119.782 F1000
G1 X95.115 Y119.66 F1000
G1 X96.952 Y119.582 F1000
G1 X98.788 Y119.505 F1000
G1 X100.625 Y119.431 F1000
G1 X102.461 Y119.36 F1000
G1 X104.298 Y119.291 F1000
G1 X106.135 Y119.226 F1000
G1 X107.972 Y119.164 F1000
G1 X109.809 Y119.106 F1000
G1 X111.646 Y119.051 F1000
G1 X113.484 Y119 F1000
G1 X115.321 Y118.952 F1000
G1 X117.159 Y118.908 F1000
G1 X118.996 Y118.868 F1000
G1 X119.915 Y118.85 F1000
G1 X121.753 Y118.815 F1000
G1 X123.591 Y118.785 F1000
G1 X124.51 Y118.772 F1000
G1 X125.429 Y118.759 F1000
G1 X126.347 Y118.748 F1000
G1 X127.266 Y118.737 F1000
G1 X128.185 Y118.728 F1000
G1 X129.104 Y118.719 F1000
G1 X130.023 Y118.712 F1000
G1 X130.942 Y118.706 F1000
G1 X131.861 Y118.701 F1000
G1 X132.78 Y118.698 F1000
G1 X133.699 Y118.695 F1000
G1 X134.618 Y118.694 F1000
G1 X135.537 Y118.695 F1000
G1 X136.456 Y118.696 F1000
G1 X137.375 Y118.699 F1000
G1 X138.295 Y118.704 F1000
G1 X139.214 Y118.71 F1000
G1 X140.132 Y118.718 F1000
G1 X141.051 Y118.727 F1000
G1 X141.97 Y118.738 F1000
G1 X142.889 Y118.751 F1000
G1 X143.808 Y118.766 F1000
G1 X144.727 Y118.783 F1000
G1 X145.646 Y118.802 F1000
G1 X146.565 Y118.823 F1000
G1 X147.483 Y118.847 F1000
G1 X148.402 Y118.873 F1000
G1 X149.321 Y118.901 F1000
G1 X150.239 Y118.933 F1000
G1 X151.158 Y118.967 F1000
G1 X152.076 Y119.004 F1000
G1 X152.994 Y119.044 F1000
G1 X153.912 Y119.088 F1000
G1 X154.83 Y119.136 F1000
G1 X155.747 Y119.187 F1000
G1 X156.665 Y119.243 F1000
G1 X157.582 Y119.303 F1000
G1 X158.498 Y119.368 F1000
G1 X159.415 Y119.438 F1000
G1 X160.331 Y119.513 F1000
G1 X161.246 Y119.595 F1000
G1 X162.161 Y119.683 F1000
G1 X163.075 Y119.779 F1000
G1 X163.988 Y119.883 F1000
G1 X164.9 Y119.996 F1000
G1 X165.811 Y120.12 F1000
G1 X166.72 Y120.255 F1000
G1 X167.626 Y120.404 F1000
G1 X168.53 Y120.57 F1000
G1 X169.431 Y120.755 F1000
G1 X170.326 Y120.964 F1000
G1 X171.213 Y121.204 F1000
G1 X172.072 Y121.485 F1000
G1 X172.633 Y121.719 F1000
G1 X172.934 Y121.875 F1000
G1 X173.204 Y122.054 F1000
G1 X173.428 Y122.287 F1000
G1 X173.596 Y122.563 F1000
G1 X173.701 Y122.87 F1000
G1 X173.736 Y123.191 F1000
G1 Y125.717 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y126.301 I-0.635 J-0.022 F1000
G1 X173.221 Y126.322 Z-3.012 F1000
G1 X173.153 Y126.343 Z-3 F1000
G1 X173.088 Y126.363 Z-2.98 F1000
G1 X173.025 Y126.383 Z-2.953 F1000
G1 X172.966 Y126.401 Z-2.919 F1000
G1 X172.91 Y126.418 Z-2.877 F1000
G1 X172.859 Y126.434 Z-2.83 F1000
G1 X172.814 Y126.448 Z-2.777 F1000
G1 X172.775 Y126.46 Z-2.719 F1000
G1 X172.742 Y126.47 Z-2.657 F1000
G1 X172.716 Y126.478 Z-2.591 F1000
G1 X172.697 Y126.484 Z-2.522 F1000
G1 X172.685 Y126.487 Z-2.452 F1000
G1 X172.682 Y126.488 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y133.205 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y133.202 Z-2.452 F1000
G1 X22.509 Y133.192 Z-2.522 F1000
G1 X22.499 Y133.175 Z-2.591 F1000
G1 X22.485 Y133.151 Z-2.657 F1000
G1 X22.467 Y133.122 Z-2.719 F1000
G1 X22.446 Y133.086 Z-2.777 F1000
G1 X22.422 Y133.046 Z-2.83 F1000
G1 X22.395 Y133 Z-2.877 F1000
G1 X22.365 Y132.95 Z-2.919 F1000
G1 X22.333 Y132.896 Z-2.953 F1000
G1 X22.3 Y132.84 Z-2.98 F1000
G1 X22.265 Y132.781 Z-3 F1000
G1 X22.229 Y132.721 Z-3.012 F1000
G1 X22.192 Y132.66 Z-3.016 F1000
G3 X21.971 Y131.906 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y129.4 F1000
G1 X21.981 Y129.194 F1000
G1 X22.013 Y128.952 F1000
G1 X22.075 Y128.663 F1000
G1 X22.166 Y128.358 F1000
G1 X22.296 Y128.024 F1000
G1 X22.481 Y127.642 F1000
G1 X22.707 Y127.259 F1000
G1 X23.015 Y126.82 F1000
G1 X23.391 Y126.368 F1000
G1 X23.871 Y125.876 F1000
G1 X24.483 Y125.342 F1000
G1 X25.222 Y124.795 F1000
G1 X26 Y124.307 F1000
G1 X26.807 Y123.868 F1000
G1 X27.637 Y123.472 F1000
G1 X28.483 Y123.114 F1000
G1 X29.342 Y122.787 F1000
G1 X30.211 Y122.489 F1000
G1 X31.089 Y122.216 F1000
G1 X31.973 Y121.964 F1000
G1 X32.862 Y121.732 F1000
G1 X33.756 Y121.517 F1000
G1 X34.653 Y121.318 F1000
G1 X35.553 Y121.133 F1000
G1 X36.456 Y120.96 F1000
G1 X37.36 Y120.799 F1000
G1 X38.267 Y120.648 F1000
G1 X39.175 Y120.507 F1000
G1 X40.084 Y120.374 F1000
G1 X40.995 Y120.25 F1000
G1 X41.906 Y120.132 F1000
G1 X42.819 Y120.022 F1000
G1 X43.732 Y119.918 F1000
G1 X44.646 Y119.82 F1000
G1 X45.56 Y119.727 F1000
G1 X46.475 Y119.639 F1000
G1 X47.39 Y119.556 F1000
G1 X48.306 Y119.477 F1000
G1 X49.222 Y119.402 F1000
G1 X50.138 Y119.331 F1000
G1 X51.054 Y119.263 F1000
G1 X51.971 Y119.198 F1000
G1 X52.888 Y119.136 F1000
G1 X53.805 Y119.076 F1000
G1 X54.722 Y119.019 F1000
G1 X55.64 Y118.964 F1000
G1 X56.557 Y118.912 F1000
G1 X57.475 Y118.86 F1000
G1 X58.393 Y118.811 F1000
G1 X59.31 Y118.763 F1000
G1 X60.228 Y118.716 F1000
G1 X62.064 Y118.626 F1000
G1 X63.9 Y118.538 F1000
G1 X66.654 Y118.412 F1000
G1 X69.408 Y118.288 F1000
G1 X74.917 Y118.041 F1000
G1 X79.507 Y117.832 F1000
G1 X88.688 Y117.407 F1000
G1 X91.442 Y117.282 F1000
G1 X94.196 Y117.16 F1000
G1 X96.033 Y117.08 F1000
G1 X97.869 Y117.003 F1000
G1 X99.705 Y116.928 F1000
G1 X101.542 Y116.856 F1000
G1 X103.379 Y116.786 F1000
G1 X105.216 Y116.72 F1000
G1 X107.053 Y116.657 F1000
G1 X108.89 Y116.597 F1000
G1 X110.727 Y116.541 F1000
G1 X112.564 Y116.488 F1000
G1 X114.402 Y116.438 F1000
G1 X116.239 Y116.393 F1000
G1 X118.077 Y116.351 F1000
G1 X119.914 Y116.313 F1000
G1 X121.752 Y116.279 F1000
G1 X123.59 Y116.249 F1000
G1 X124.509 Y116.236 F1000
G1 X125.428 Y116.223 F1000
G1 X126.347 Y116.212 F1000
G1 X127.266 Y116.201 F1000
G1 X128.184 Y116.192 F1000
G1 X129.103 Y116.184 F1000
G1 X130.022 Y116.177 F1000
G1 X130.941 Y116.171 F1000
G1 X131.86 Y116.166 F1000
G1 X132.779 Y116.163 F1000
G1 X133.699 Y116.16 F1000
G1 X134.618 F1000
G1 X135.537 F1000
G1 X136.456 Y116.162 F1000
G1 X137.375 Y116.165 F1000
G1 X138.294 Y116.17 F1000
G1 X139.213 Y116.176 F1000
G1 X140.132 Y116.184 F1000
G1 X141.051 Y116.193 F1000
G1 X141.969 Y116.205 F1000
G1 X142.888 Y116.218 F1000
G1 X143.807 Y116.233 F1000
G1 X144.726 Y116.25 F1000
G1 X145.645 Y116.27 F1000
G1 X146.564 Y116.291 F1000
G1 X147.482 Y116.315 F1000
G1 X148.401 Y116.341 F1000
G1 X149.32 Y116.37 F1000
G1 X150.238 Y116.402 F1000
G1 X151.157 Y116.436 F1000
G1 X152.075 Y116.474 F1000
G1 X152.993 Y116.514 F1000
G1 X153.911 Y116.559 F1000
G1 X154.829 Y116.606 F1000
G1 X155.746 Y116.658 F1000
G1 X156.664 Y116.714 F1000
G1 X157.581 Y116.774 F1000
G1 X158.497 Y116.839 F1000
G1 X159.414 Y116.909 F1000
G1 X160.329 Y116.985 F1000
G1 X161.245 Y117.067 F1000
G1 X162.16 Y117.156 F1000
G1 X163.074 Y117.252 F1000
G1 X163.987 Y117.356 F1000
G1 X164.899 Y117.469 F1000
G1 X165.809 Y117.593 F1000
G1 X166.718 Y117.729 F1000
G1 X167.625 Y117.878 F1000
G1 X168.529 Y118.044 F1000
G1 X169.429 Y118.229 F1000
G1 X170.324 Y118.438 F1000
G1 X171.211 Y118.678 F1000
G1 X172.071 Y118.959 F1000
G1 X172.632 Y119.194 F1000
G1 X172.934 Y119.349 F1000
G1 X173.204 Y119.528 F1000
G1 X173.428 Y119.762 F1000
G1 X173.596 Y120.038 F1000
G1 X173.701 Y120.344 F1000
G1 X173.736 Y120.666 F1000
G1 Y123.191 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y123.776 I-0.635 J-0.022 F1000
G1 X173.221 Y123.797 Z-3.012 F1000
G1 X173.153 Y123.818 Z-3 F1000
G1 X173.088 Y123.838 Z-2.98 F1000
G1 X173.025 Y123.857 Z-2.953 F1000
G1 X172.966 Y123.876 Z-2.919 F1000
G1 X172.91 Y123.893 Z-2.877 F1000
G1 X172.859 Y123.908 Z-2.83 F1000
G1 X172.814 Y123.922 Z-2.777 F1000
G1 X172.775 Y123.934 Z-2.719 F1000
G1 X172.742 Y123.945 Z-2.657 F1000
G1 X172.716 Y123.953 Z-2.591 F1000
G1 X172.697 Y123.958 Z-2.522 F1000
G1 X172.685 Y123.962 Z-2.452 F1000
G1 X172.682 Y123.963 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y130.699 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y130.696 Z-2.452 F1000
G1 X22.509 Y130.686 Z-2.522 F1000
G1 X22.499 Y130.669 Z-2.591 F1000
G1 X22.485 Y130.645 Z-2.657 F1000
G1 X22.467 Y130.616 Z-2.719 F1000
G1 X22.446 Y130.58 Z-2.777 F1000
G1 X22.422 Y130.54 Z-2.83 F1000
G1 X22.395 Y130.494 Z-2.877 F1000
G1 X22.365 Y130.444 Z-2.919 F1000
G1 X22.333 Y130.39 Z-2.953 F1000
G1 X22.3 Y130.334 Z-2.98 F1000
G1 X22.265 Y130.275 Z-3 F1000
G1 X22.229 Y130.215 Z-3.012 F1000
G1 X22.192 Y130.154 Z-3.016 F1000
G3 X21.971 Y129.4 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y126.894 F1000
G1 X21.982 Y126.674 F1000
G1 X22.014 Y126.431 F1000
G1 X22.076 Y126.143 F1000
G1 X22.167 Y125.838 F1000
G1 X22.297 Y125.504 F1000
G1 X22.482 Y125.122 F1000
G1 X22.708 Y124.739 F1000
G1 X23.016 Y124.3 F1000
G1 X23.392 Y123.847 F1000
G1 X23.872 Y123.355 F1000
G1 X24.484 Y122.821 F1000
G1 X25.223 Y122.275 F1000
G1 X26.001 Y121.786 F1000
G1 X26.809 Y121.347 F1000
G1 X27.638 Y120.951 F1000
G1 X28.484 Y120.593 F1000
G1 X29.343 Y120.266 F1000
G1 X30.212 Y119.967 F1000
G1 X31.09 Y119.694 F1000
G1 X31.974 Y119.442 F1000
G1 X32.863 Y119.21 F1000
G1 X33.756 Y118.995 F1000
G1 X34.653 Y118.795 F1000
G1 X35.554 Y118.61 F1000
G1 X36.456 Y118.437 F1000
G1 X37.361 Y118.275 F1000
G1 X38.267 Y118.124 F1000
G1 X39.175 Y117.982 F1000
G1 X40.085 Y117.849 F1000
G1 X40.995 Y117.724 F1000
G1 X41.907 Y117.606 F1000
G1 X42.819 Y117.496 F1000
G1 X43.732 Y117.391 F1000
G1 X44.646 Y117.292 F1000
G1 X45.56 Y117.199 F1000
G1 X46.475 Y117.111 F1000
G1 X47.39 Y117.027 F1000
G1 X48.305 Y116.947 F1000
G1 X49.221 Y116.872 F1000
G1 X50.138 Y116.8 F1000
G1 X51.054 Y116.731 F1000
G1 X51.971 Y116.666 F1000
G1 X52.888 Y116.603 F1000
G1 X53.805 Y116.543 F1000
G1 X54.722 Y116.485 F1000
G1 X55.639 Y116.43 F1000
G1 X56.557 Y116.377 F1000
G1 X57.474 Y116.325 F1000
G1 X58.392 Y116.275 F1000
G1 X59.31 Y116.226 F1000
G1 X60.227 Y116.179 F1000
G1 X62.063 Y116.087 F1000
G1 X63.899 Y115.999 F1000
G1 X66.653 Y115.871 F1000
G1 X69.407 Y115.746 F1000
G1 X75.834 Y115.456 F1000
G1 X80.424 Y115.246 F1000
G1 X87.769 Y114.907 F1000
G1 X91.441 Y114.74 F1000
G1 X94.195 Y114.619 F1000
G1 X96.032 Y114.54 F1000
G1 X97.868 Y114.463 F1000
G1 X99.705 Y114.389 F1000
G1 X101.541 Y114.317 F1000
G1 X103.378 Y114.248 F1000
G1 X105.215 Y114.182 F1000
G1 X107.052 Y114.119 F1000
G1 X108.889 Y114.059 F1000
G1 X110.726 Y114.003 F1000
G1 X112.563 Y113.95 F1000
G1 X114.401 Y113.901 F1000
G1 X116.238 Y113.856 F1000
G1 X118.076 Y113.814 F1000
G1 X119.913 Y113.777 F1000
G1 X121.751 Y113.743 F1000
G1 X123.589 Y113.713 F1000
G1 X124.508 Y113.7 F1000
G1 X125.427 Y113.687 F1000
G1 X126.346 Y113.676 F1000
G1 X127.265 Y113.666 F1000
G1 X128.184 Y113.656 F1000
G1 X129.103 Y113.648 F1000
G1 X130.022 Y113.641 F1000
G1 X130.941 Y113.636 F1000
G1 X131.86 Y113.631 F1000
G1 X132.779 Y113.628 F1000
G1 X133.698 Y113.626 F1000
G1 X134.617 Y113.625 F1000
G1 X135.536 F1000
G1 X136.455 Y113.627 F1000
G1 X137.374 Y113.631 F1000
G1 X138.293 Y113.636 F1000
G1 X139.212 Y113.642 F1000
G1 X140.131 Y113.65 F1000
G1 X141.05 Y113.66 F1000
G1 X141.969 Y113.672 F1000
G1 X142.888 Y113.685 F1000
G1 X143.807 Y113.7 F1000
G1 X144.725 Y113.718 F1000
G1 X145.644 Y113.737 F1000
G1 X146.563 Y113.759 F1000
G1 X147.482 Y113.783 F1000
G1 X148.4 Y113.81 F1000
G1 X149.319 Y113.839 F1000
G1 X150.237 Y113.871 F1000
G1 X151.156 Y113.906 F1000
G1 X152.074 Y113.943 F1000
G1 X152.992 Y113.984 F1000
G1 X153.91 Y114.029 F1000
G1 X154.828 Y114.077 F1000
G1 X155.745 Y114.129 F1000
G1 X156.663 Y114.185 F1000
G1 X157.58 Y114.245 F1000
G1 X158.496 Y114.311 F1000
G1 X159.413 Y114.381 F1000
G1 X160.329 Y114.457 F1000
G1 X161.244 Y114.539 F1000
G1 X162.159 Y114.628 F1000
G1 X163.073 Y114.724 F1000
G1 X163.986 Y114.829 F1000
G1 X164.898 Y114.942 F1000
G1 X165.808 Y115.066 F1000
G1 X166.717 Y115.202 F1000
G1 X167.624 Y115.352 F1000
G1 X168.528 Y115.517 F1000
G1 X169.428 Y115.702 F1000
G1 X170.323 Y115.912 F1000
G1 X171.21 Y116.152 F1000
G1 X172.071 Y116.433 F1000
G1 X172.632 Y116.668 F1000
G1 X172.934 Y116.824 F1000
G1 X173.204 Y117.003 F1000
G1 X173.428 Y117.236 F1000
G1 X173.596 Y117.512 F1000
G1 X173.701 Y117.819 F1000
G1 X173.736 Y118.14 F1000
G1 Y120.666 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y121.251 I-0.635 J-0.022 F1000
G1 X173.221 Y121.272 Z-3.012 F1000
G1 X173.153 Y121.292 Z-3 F1000
G1 X173.088 Y121.312 Z-2.98 F1000
G1 X173.025 Y121.332 Z-2.953 F1000
G1 X172.966 Y121.35 Z-2.919 F1000
G1 X172.91 Y121.367 Z-2.877 F1000
G1 X172.859 Y121.383 Z-2.83 F1000
G1 X172.814 Y121.397 Z-2.777 F1000
G1 X172.775 Y121.409 Z-2.719 F1000
G1 X172.742 Y121.419 Z-2.657 F1000
G1 X172.716 Y121.427 Z-2.591 F1000
G1 X172.697 Y121.433 Z-2.522 F1000
G1 X172.685 Y121.436 Z-2.452 F1000
G1 X172.682 Y121.438 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y128.193 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y128.19 Z-2.452 F1000
G1 X22.509 Y128.18 Z-2.522 F1000
G1 X22.499 Y128.163 Z-2.591 F1000
G1 X22.485 Y128.139 Z-2.657 F1000
G1 X22.467 Y128.11 Z-2.719 F1000
G1 X22.446 Y128.074 Z-2.777 F1000
G1 X22.422 Y128.034 Z-2.83 F1000
G1 X22.395 Y127.988 Z-2.877 F1000
G1 X22.365 Y127.938 Z-2.919 F1000
G1 X22.333 Y127.884 Z-2.953 F1000
G1 X22.3 Y127.828 Z-2.98 F1000
G1 X22.265 Y127.769 Z-3 F1000
G1 X22.229 Y127.709 Z-3.012 F1000
G1 X22.192 Y127.648 Z-3.016 F1000
G3 X21.971 Y126.894 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y124.388 F1000
G1 X21.983 Y124.154 F1000
G1 X22.015 Y123.911 F1000
G1 X22.076 Y123.622 F1000
G1 X22.168 Y123.317 F1000
G1 X22.298 Y122.983 F1000
G1 X22.483 Y122.602 F1000
G1 X22.709 Y122.218 F1000
G1 X23.017 Y121.779 F1000
G1 X23.393 Y121.326 F1000
G1 X23.873 Y120.834 F1000
G1 X24.485 Y120.3 F1000
G1 X25.224 Y119.753 F1000
G1 X26.003 Y119.265 F1000
G1 X26.81 Y118.826 F1000
G1 X27.639 Y118.43 F1000
G1 X28.485 Y118.071 F1000
G1 X29.344 Y117.744 F1000
G1 X30.214 Y117.446 F1000
G1 X31.091 Y117.172 F1000
G1 X31.975 Y116.92 F1000
G1 X32.864 Y116.687 F1000
G1 X33.757 Y116.472 F1000
G1 X34.654 Y116.272 F1000
G1 X35.554 Y116.086 F1000
G1 X36.457 Y115.913 F1000
G1 X37.361 Y115.751 F1000
G1 X38.268 Y115.599 F1000
G1 X39.176 Y115.457 F1000
G1 X40.085 Y115.324 F1000
G1 X40.995 Y115.198 F1000
G1 X41.907 Y115.08 F1000
G1 X42.819 Y114.969 F1000
G1 X43.732 Y114.864 F1000
G1 X44.646 Y114.764 F1000
G1 X45.56 Y114.671 F1000
G1 X46.475 Y114.582 F1000
G1 X47.39 Y114.497 F1000
G1 X48.305 Y114.417 F1000
G1 X49.221 Y114.341 F1000
G1 X50.137 Y114.269 F1000
G1 X51.054 Y114.199 F1000
G1 X51.97 Y114.133 F1000
G1 X52.887 Y114.07 F1000
G1 X53.804 Y114.01 F1000
G1 X54.721 Y113.951 F1000
G1 X55.639 Y113.895 F1000
G1 X56.556 Y113.841 F1000
G1 X57.474 Y113.789 F1000
G1 X58.391 Y113.739 F1000
G1 X59.309 Y113.689 F1000
G1 X60.227 Y113.641 F1000
G1 X62.063 Y113.549 F1000
G1 X63.898 Y113.46 F1000
G1 X66.652 Y113.331 F1000
G1 X69.407 Y113.205 F1000
G1 X76.751 Y112.872 F1000
G1 X85.014 Y112.491 F1000
G1 X89.604 Y112.281 F1000
G1 X92.358 Y112.158 F1000
G1 X95.113 Y112.039 F1000
G1 X96.949 Y111.961 F1000
G1 X98.786 Y111.886 F1000
G1 X100.622 Y111.813 F1000
G1 X102.459 Y111.743 F1000
G1 X104.296 Y111.676 F1000
G1 X106.133 Y111.612 F1000
G1 X107.97 Y111.551 F1000
G1 X109.807 Y111.493 F1000
G1 X111.644 Y111.439 F1000
G1 X113.481 Y111.388 F1000
G1 X115.319 Y111.341 F1000
G1 X117.156 Y111.298 F1000
G1 X118.994 Y111.259 F1000
G1 X119.913 Y111.24 F1000
G1 X121.751 Y111.207 F1000
G1 X123.588 Y111.177 F1000
G1 X124.507 Y111.163 F1000
G1 X125.426 Y111.151 F1000
G1 X126.345 Y111.14 F1000
G1 X127.264 Y111.13 F1000
G1 X128.183 Y111.121 F1000
G1 X129.102 Y111.113 F1000
G1 X130.021 Y111.106 F1000
G1 X130.94 Y111.1 F1000
G1 X131.859 Y111.096 F1000
G1 X132.778 Y111.093 F1000
G1 X133.697 Y111.091 F1000
G1 X134.616 Y111.09 F1000
G1 X135.535 Y111.091 F1000
G1 X136.454 Y111.093 F1000
G1 X137.373 Y111.097 F1000
G1 X138.292 Y111.102 F1000
G1 X139.211 Y111.108 F1000
G1 X140.13 Y111.117 F1000
G1 X141.049 Y111.127 F1000
G1 X141.968 Y111.139 F1000
G1 X142.887 Y111.152 F1000
G1 X143.806 Y111.168 F1000
G1 X144.725 Y111.185 F1000
G1 X145.644 Y111.205 F1000
G1 X146.562 Y111.227 F1000
G1 X147.481 Y111.252 F1000
G1 X148.4 Y111.278 F1000
G1 X149.318 Y111.308 F1000
G1 X150.237 Y111.34 F1000
G1 X151.155 Y111.375 F1000
G1 X152.073 Y111.413 F1000
G1 X152.991 Y111.454 F1000
G1 X153.909 Y111.499 F1000
G1 X154.827 Y111.547 F1000
G1 X155.745 Y111.6 F1000
G1 X156.662 Y111.656 F1000
G1 X157.579 Y111.717 F1000
G1 X158.496 Y111.782 F1000
G1 X159.412 Y111.853 F1000
G1 X160.328 Y111.929 F1000
G1 X161.243 Y112.012 F1000
G1 X162.158 Y112.101 F1000
G1 X163.072 Y112.197 F1000
G1 X163.985 Y112.302 F1000
G1 X164.897 Y112.415 F1000
G1 X165.807 Y112.54 F1000
G1 X166.716 Y112.676 F1000
G1 X167.623 Y112.825 F1000
G1 X168.527 Y112.991 F1000
G1 X169.427 Y113.176 F1000
G1 X170.322 Y113.385 F1000
G1 X171.209 Y113.625 F1000
G1 X172.07 Y113.907 F1000
G1 X172.632 Y114.142 F1000
G1 X172.934 Y114.298 F1000
G1 X173.204 Y114.477 F1000
G1 X173.428 Y114.71 F1000
G1 X173.596 Y114.987 F1000
G1 X173.701 Y115.293 F1000
G1 X173.736 Y115.615 F1000
G1 Y118.14 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y118.725 I-0.635 J-0.022 F1000
G1 X173.221 Y118.746 Z-3.012 F1000
G1 X173.153 Y118.767 Z-3 F1000
G1 X173.088 Y118.787 Z-2.98 F1000
G1 X173.025 Y118.806 Z-2.953 F1000
G1 X172.966 Y118.824 Z-2.919 F1000
G1 X172.91 Y118.842 Z-2.877 F1000
G1 X172.859 Y118.857 Z-2.83 F1000
G1 X172.814 Y118.871 Z-2.777 F1000
G1 X172.775 Y118.883 Z-2.719 F1000
G1 X172.742 Y118.893 Z-2.657 F1000
G1 X172.716 Y118.902 Z-2.591 F1000
G1 X172.697 Y118.907 Z-2.522 F1000
G1 X172.685 Y118.911 Z-2.452 F1000
G1 X172.682 Y118.912 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y125.687 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y125.684 Z-2.452 F1000
G1 X22.509 Y125.674 Z-2.522 F1000
G1 X22.499 Y125.657 Z-2.591 F1000
G1 X22.485 Y125.633 Z-2.657 F1000
G1 X22.467 Y125.604 Z-2.719 F1000
G1 X22.446 Y125.568 Z-2.777 F1000
G1 X22.422 Y125.528 Z-2.83 F1000
G1 X22.395 Y125.482 Z-2.877 F1000
G1 X22.365 Y125.432 Z-2.919 F1000
G1 X22.333 Y125.378 Z-2.953 F1000
G1 X22.3 Y125.322 Z-2.98 F1000
G1 X22.265 Y125.263 Z-3 F1000
G1 X22.229 Y125.203 Z-3.012 F1000
G1 X22.192 Y125.142 Z-3.016 F1000
G3 X21.971 Y124.388 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y121.882 F1000
G1 X21.983 Y121.633 F1000
G1 X22.015 Y121.391 F1000
G1 X22.077 Y121.102 F1000
G1 X22.168 Y120.796 F1000
G1 X22.299 Y120.463 F1000
G1 X22.484 Y120.081 F1000
G1 X22.709 Y119.698 F1000
G1 X23.018 Y119.259 F1000
G1 X23.394 Y118.805 F1000
G1 X23.874 Y118.313 F1000
G1 X24.487 Y117.779 F1000
G1 X25.226 Y117.232 F1000
G1 X26.004 Y116.743 F1000
G1 X26.811 Y116.305 F1000
G1 X27.641 Y115.908 F1000
G1 X28.487 Y115.549 F1000
G1 X29.346 Y115.222 F1000
G1 X30.215 Y114.924 F1000
G1 X31.092 Y114.65 F1000
G1 X31.976 Y114.397 F1000
G1 X32.865 Y114.165 F1000
G1 X33.758 Y113.949 F1000
G1 X34.655 Y113.749 F1000
G1 X35.555 Y113.563 F1000
G1 X36.457 Y113.389 F1000
G1 X37.362 Y113.226 F1000
G1 X38.268 Y113.074 F1000
G1 X39.176 Y112.932 F1000
G1 X40.085 Y112.798 F1000
G1 X40.996 Y112.672 F1000
G1 X41.907 Y112.553 F1000
G1 X42.819 Y112.442 F1000
G1 X43.732 Y112.336 F1000
G1 X44.646 Y112.236 F1000
G1 X45.56 Y112.142 F1000
G1 X46.475 Y112.053 F1000
G1 X47.39 Y111.968 F1000
G1 X48.305 Y111.887 F1000
G1 X49.221 Y111.81 F1000
G1 X50.137 Y111.737 F1000
G1 X51.054 Y111.668 F1000
G1 X51.97 Y111.601 F1000
G1 X52.887 Y111.537 F1000
G1 X53.804 Y111.476 F1000
G1 X54.721 Y111.417 F1000
G1 X55.638 Y111.361 F1000
G1 X56.556 Y111.306 F1000
G1 X57.473 Y111.253 F1000
G1 X58.391 Y111.202 F1000
G1 X59.309 Y111.153 F1000
G1 X60.226 Y111.104 F1000
G1 X62.062 Y111.011 F1000
G1 X63.898 Y110.921 F1000
G1 X65.734 Y110.833 F1000
G1 X68.488 Y110.706 F1000
G1 X69.406 Y110.663 F1000
G1 X78.587 Y110.245 F1000
G1 X86.849 Y109.865 F1000
G1 X90.521 Y109.699 F1000
G1 X93.276 Y109.577 F1000
G1 X96.03 Y109.459 F1000
G1 X97.867 Y109.383 F1000
G1 X99.703 Y109.31 F1000
G1 X101.54 Y109.238 F1000
G1 X103.377 Y109.17 F1000
G1 X105.214 Y109.105 F1000
G1 X107.051 Y109.043 F1000
G1 X108.888 Y108.984 F1000
G1 X110.725 Y108.928 F1000
G1 X112.562 Y108.876 F1000
G1 X114.4 Y108.827 F1000
G1 X116.237 Y108.782 F1000
G1 X118.075 Y108.741 F1000
G1 X119.912 Y108.704 F1000
G1 X121.75 Y108.67 F1000
G1 X123.588 Y108.641 F1000
G1 X124.507 Y108.627 F1000
G1 X125.426 Y108.615 F1000
G1 X126.345 Y108.604 F1000
G1 X127.264 Y108.594 F1000
G1 X128.183 Y108.585 F1000
G1 X129.102 Y108.577 F1000
G1 X130.021 Y108.571 F1000
G1 X130.94 Y108.565 F1000
G1 X131.859 Y108.561 F1000
G1 X132.778 Y108.558 F1000
G1 X133.697 Y108.556 F1000
G1 X134.616 Y108.555 F1000
G1 X135.535 Y108.556 F1000
G1 X136.454 Y108.559 F1000
G1 X137.373 Y108.562 F1000
G1 X138.292 Y108.568 F1000
G1 X139.211 Y108.575 F1000
G1 X140.13 Y108.583 F1000
G1 X141.049 Y108.593 F1000
G1 X141.968 Y108.605 F1000
G1 X142.887 Y108.619 F1000
G1 X143.805 Y108.635 F1000
G1 X144.724 Y108.653 F1000
G1 X145.643 Y108.673 F1000
G1 X146.562 Y108.695 F1000
G1 X147.48 Y108.72 F1000
G1 X148.399 Y108.747 F1000
G1 X149.318 Y108.777 F1000
G1 X150.236 Y108.809 F1000
G1 X151.154 Y108.844 F1000
G1 X152.073 Y108.883 F1000
G1 X152.991 Y108.924 F1000
G1 X153.909 Y108.969 F1000
G1 X154.826 Y109.018 F1000
G1 X155.744 Y109.07 F1000
G1 X156.661 Y109.127 F1000
G1 X157.578 Y109.188 F1000
G1 X158.495 Y109.254 F1000
G1 X159.411 Y109.325 F1000
G1 X160.327 Y109.401 F1000
G1 X161.242 Y109.484 F1000
G1 X162.157 Y109.573 F1000
G1 X163.071 Y109.67 F1000
G1 X163.984 Y109.774 F1000
G1 X164.896 Y109.888 F1000
G1 X165.806 Y110.013 F1000
G1 X166.715 Y110.149 F1000
G1 X167.622 Y110.299 F1000
G1 X168.526 Y110.465 F1000
G1 X169.426 Y110.65 F1000
G1 X170.321 Y110.859 F1000
G1 X171.208 Y111.099 F1000
G1 X172.07 Y111.381 F1000
G1 X172.632 Y111.616 F1000
G1 X172.934 Y111.772 F1000
G1 X173.204 Y111.951 F1000
G1 X173.428 Y112.184 F1000
G1 X173.596 Y112.461 F1000
G1 X173.701 Y112.767 F1000
G1 X173.736 Y113.089 F1000
G1 Y115.615 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y116.199 I-0.635 J-0.022 F1000
G1 X173.221 Y116.22 Z-3.012 F1000
G1 X173.153 Y116.241 Z-3 F1000
G1 X173.088 Y116.261 Z-2.98 F1000
G1 X173.025 Y116.28 Z-2.953 F1000
G1 X172.966 Y116.299 Z-2.919 F1000
G1 X172.91 Y116.316 Z-2.877 F1000
G1 X172.859 Y116.331 Z-2.83 F1000
G1 X172.814 Y116.345 Z-2.777 F1000
G1 X172.775 Y116.358 Z-2.719 F1000
G1 X172.742 Y116.368 Z-2.657 F1000
G1 X172.716 Y116.376 Z-2.591 F1000
G1 X172.697 Y116.382 Z-2.522 F1000
G1 X172.685 Y116.385 Z-2.452 F1000
G1 X172.682 Y116.386 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y123.181 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y123.178 Z-2.452 F1000
G1 X22.509 Y123.168 Z-2.522 F1000
G1 X22.499 Y123.151 Z-2.591 F1000
G1 X22.485 Y123.127 Z-2.657 F1000
G1 X22.467 Y123.098 Z-2.719 F1000
G1 X22.446 Y123.062 Z-2.777 F1000
G1 X22.422 Y123.021 Z-2.83 F1000
G1 X22.395 Y122.976 Z-2.877 F1000
G1 X22.365 Y122.926 Z-2.919 F1000
G1 X22.333 Y122.872 Z-2.953 F1000
G1 X22.3 Y122.816 Z-2.98 F1000
G1 X22.265 Y122.757 Z-3 F1000
G1 X22.229 Y122.697 Z-3.012 F1000
G1 X22.192 Y122.636 Z-3.016 F1000
G3 X21.971 Y121.882 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y119.376 F1000
G1 X21.984 Y119.112 F1000
G1 X22.016 Y118.87 F1000
G1 X22.078 Y118.581 F1000
G1 X22.169 Y118.276 F1000
G1 X22.299 Y117.942 F1000
G1 X22.485 Y117.56 F1000
G1 X22.71 Y117.176 F1000
G1 X23.019 Y116.737 F1000
G1 X23.395 Y116.284 F1000
G1 X23.876 Y115.792 F1000
G1 X24.488 Y115.257 F1000
G1 X25.227 Y114.71 F1000
G1 X26.005 Y114.222 F1000
G1 X26.813 Y113.783 F1000
G1 X27.642 Y113.387 F1000
G1 X28.488 Y113.027 F1000
G1 X29.347 Y112.7 F1000
G1 X30.216 Y112.401 F1000
G1 X31.093 Y112.127 F1000
G1 X31.977 Y111.875 F1000
G1 X32.866 Y111.641 F1000
G1 X33.759 Y111.426 F1000
G1 X34.656 Y111.225 F1000
G1 X35.556 Y111.038 F1000
G1 X36.458 Y110.864 F1000
G1 X37.363 Y110.702 F1000
G1 X38.269 Y110.549 F1000
G1 X39.177 Y110.406 F1000
G1 X40.086 Y110.272 F1000
G1 X40.996 Y110.146 F1000
G1 X41.907 Y110.027 F1000
G1 X42.82 Y109.914 F1000
G1 X43.733 Y109.808 F1000
G1 X44.646 Y109.708 F1000
G1 X45.56 Y109.613 F1000
G1 X46.475 Y109.523 F1000
G1 X47.39 Y109.438 F1000
G1 X48.305 Y109.357 F1000
G1 X49.221 Y109.28 F1000
G1 X50.137 Y109.206 F1000
G1 X51.053 Y109.136 F1000
G1 X51.97 Y109.069 F1000
G1 X52.887 Y109.004 F1000
G1 X53.804 Y108.942 F1000
G1 X54.721 Y108.883 F1000
G1 X55.638 Y108.826 F1000
G1 X56.555 Y108.771 F1000
G1 X57.473 Y108.718 F1000
G1 X58.39 Y108.666 F1000
G1 X59.308 Y108.616 F1000
G1 X60.226 Y108.567 F1000
G1 X61.144 Y108.519 F1000
G1 X62.979 Y108.427 F1000
G1 X64.815 Y108.337 F1000
G1 X67.569 Y108.207 F1000
G1 X68.487 Y108.164 F1000
G1 X83.176 Y107.491 F1000
G1 X87.766 Y107.281 F1000
G1 X90.521 Y107.157 F1000
G1 X93.275 Y107.036 F1000
G1 X96.03 Y106.919 F1000
G1 X97.866 Y106.843 F1000
G1 X99.703 Y106.77 F1000
G1 X101.539 Y106.699 F1000
G1 X103.376 Y106.631 F1000
G1 X105.213 Y106.566 F1000
G1 X107.05 Y106.504 F1000
G1 X108.887 Y106.446 F1000
G1 X110.724 Y106.39 F1000
G1 X112.562 Y106.338 F1000
G1 X114.399 Y106.29 F1000
G1 X116.237 Y106.245 F1000
G1 X118.074 Y106.204 F1000
G1 X118.993 Y106.185 F1000
G1 X120.831 Y106.15 F1000
G1 X122.668 Y106.119 F1000
G1 X123.587 Y106.105 F1000
G1 X124.506 Y106.091 F1000
G1 X125.425 Y106.079 F1000
G1 X126.344 Y106.068 F1000
G1 X127.263 Y106.058 F1000
G1 X128.182 Y106.049 F1000
G1 X129.101 Y106.042 F1000
G1 X130.02 Y106.035 F1000
G1 X130.939 Y106.03 F1000
G1 X131.858 Y106.026 F1000
G1 X132.777 Y106.023 F1000
G1 X133.696 Y106.021 F1000
G1 X134.615 F1000
G1 X135.534 Y106.022 F1000
G1 X136.453 Y106.024 F1000
G1 X137.372 Y106.028 F1000
G1 X138.291 Y106.034 F1000
G1 X139.21 Y106.041 F1000
G1 X140.129 Y106.05 F1000
G1 X141.048 Y106.06 F1000
G1 X141.967 Y106.072 F1000
G1 X142.886 Y106.086 F1000
G1 X143.805 Y106.103 F1000
G1 X144.724 Y106.121 F1000
G1 X145.643 Y106.141 F1000
G1 X146.561 Y106.163 F1000
G1 X147.48 Y106.188 F1000
G1 X148.399 Y106.216 F1000
G1 X149.317 Y106.245 F1000
G1 X150.236 Y106.278 F1000
G1 X151.154 Y106.314 F1000
G1 X152.072 Y106.352 F1000
G1 X152.99 Y106.394 F1000
G1 X153.908 Y106.439 F1000
G1 X154.826 Y106.488 F1000
G1 X155.743 Y106.541 F1000
G1 X156.661 Y106.598 F1000
G1 X157.578 Y106.659 F1000
G1 X158.494 Y106.725 F1000
G1 X159.41 Y106.796 F1000
G1 X160.326 Y106.873 F1000
G1 X161.242 Y106.956 F1000
G1 X162.156 Y107.045 F1000
G1 X163.07 Y107.142 F1000
G1 X163.983 Y107.247 F1000
G1 X164.895 Y107.361 F1000
G1 X165.806 Y107.486 F1000
G1 X166.714 Y107.622 F1000
G1 X167.621 Y107.772 F1000
G1 X168.525 Y107.938 F1000
G1 X169.425 Y108.123 F1000
G1 X170.32 Y108.333 F1000
G1 X171.207 Y108.573 F1000
G1 X172.069 Y108.855 F1000
G1 X172.631 Y109.09 F1000
G1 X172.934 Y109.246 F1000
G1 X173.204 Y109.425 F1000
G1 X173.428 Y109.658 F1000
G1 X173.596 Y109.935 F1000
G1 X173.701 Y110.241 F1000
G1 X173.736 Y110.563 F1000
G1 Y113.089 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y113.673 I-0.635 J-0.022 F1000
G1 X173.221 Y113.694 Z-3.012 F1000
G1 X173.153 Y113.715 Z-3 F1000
G1 X173.088 Y113.735 Z-2.98 F1000
G1 X173.025 Y113.754 Z-2.953 F1000
G1 X172.966 Y113.773 Z-2.919 F1000
G1 X172.91 Y113.79 Z-2.877 F1000
G1 X172.859 Y113.806 Z-2.83 F1000
G1 X172.814 Y113.82 Z-2.777 F1000
G1 X172.775 Y113.832 Z-2.719 F1000
G1 X172.742 Y113.842 Z-2.657 F1000
G1 X172.716 Y113.85 Z-2.591 F1000
G1 X172.697 Y113.856 Z-2.522 F1000
G1 X172.685 Y113.859 Z-2.452 F1000
G1 X172.682 Y113.86 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y120.675 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y120.672 Z-2.452 F1000
G1 X22.509 Y120.662 Z-2.522 F1000
G1 X22.499 Y120.645 Z-2.591 F1000
G1 X22.485 Y120.621 Z-2.657 F1000
G1 X22.467 Y120.592 Z-2.719 F1000
G1 X22.446 Y120.556 Z-2.777 F1000
G1 X22.422 Y120.515 Z-2.83 F1000
G1 X22.395 Y120.47 Z-2.877 F1000
G1 X22.365 Y120.42 Z-2.919 F1000
G1 X22.333 Y120.366 Z-2.953 F1000
G1 X22.3 Y120.31 Z-2.98 F1000
G1 X22.265 Y120.251 Z-3 F1000
G1 X22.229 Y120.191 Z-3.012 F1000
G1 X22.192 Y120.13 Z-3.016 F1000
G3 X21.971 Y119.376 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y116.87 F1000
G1 X21.985 Y116.591 F1000
G1 X22.017 Y116.349 F1000
G1 X22.078 Y116.06 F1000
G1 X22.17 Y115.754 F1000
G1 X22.3 Y115.42 F1000
G1 X22.485 Y115.039 F1000
G1 X22.711 Y114.655 F1000
G1 X23.02 Y114.216 F1000
G1 X23.396 Y113.762 F1000
G1 X23.877 Y113.27 F1000
G1 X24.49 Y112.735 F1000
G1 X25.229 Y112.188 F1000
G1 X26.007 Y111.7 F1000
G1 X26.814 Y111.261 F1000
G1 X27.644 Y110.864 F1000
G1 X28.489 Y110.505 F1000
G1 X29.348 Y110.178 F1000
G1 X30.217 Y109.878 F1000
G1 X31.094 Y109.604 F1000
G1 X31.978 Y109.351 F1000
G1 X32.867 Y109.118 F1000
G1 X33.76 Y108.902 F1000
G1 X34.657 Y108.701 F1000
G1 X35.557 Y108.514 F1000
G1 X36.459 Y108.34 F1000
G1 X37.363 Y108.177 F1000
G1 X38.27 Y108.024 F1000
G1 X39.177 Y107.881 F1000
G1 X40.086 Y107.746 F1000
G1 X40.997 Y107.619 F1000
G1 X41.908 Y107.5 F1000
G1 X42.82 Y107.387 F1000
G1 X43.733 Y107.28 F1000
G1 X44.646 Y107.18 F1000
G1 X45.56 Y107.084 F1000
G1 X46.475 Y106.994 F1000
G1 X47.39 Y106.908 F1000
G1 X48.305 Y106.826 F1000
G1 X49.221 Y106.749 F1000
G1 X50.137 Y106.674 F1000
G1 X51.053 Y106.604 F1000
G1 X51.97 Y106.536 F1000
G1 X52.887 Y106.471 F1000
G1 X53.803 Y106.409 F1000
G1 X54.721 Y106.349 F1000
G1 X55.638 Y106.291 F1000
G1 X56.555 Y106.236 F1000
G1 X57.473 Y106.182 F1000
G1 X58.39 Y106.13 F1000
G1 X59.308 Y106.079 F1000
G1 X60.225 Y106.029 F1000
G1 X61.143 Y105.981 F1000
G1 X62.979 Y105.888 F1000
G1 X64.815 Y105.798 F1000
G1 X67.569 Y105.666 F1000
G1 X68.487 Y105.623 F1000
G1 X73.995 Y105.37 F1000
G1 X85.93 Y104.822 F1000
G1 X89.602 Y104.656 F1000
G1 X92.356 Y104.535 F1000
G1 X95.111 Y104.417 F1000
G1 X96.947 Y104.341 F1000
G1 X98.784 Y104.267 F1000
G1 X100.62 Y104.195 F1000
G1 X102.457 Y104.126 F1000
G1 X104.294 Y104.06 F1000
G1 X106.131 Y103.997 F1000
G1 X107.968 Y103.937 F1000
G1 X109.805 Y103.88 F1000
G1 X111.642 Y103.826 F1000
G1 X113.48 Y103.777 F1000
G1 X115.317 Y103.73 F1000
G1 X117.155 Y103.688 F1000
G1 X118.992 Y103.649 F1000
G1 X120.83 Y103.614 F1000
G1 X122.668 Y103.582 F1000
G1 X123.587 Y103.568 F1000
G1 X124.506 Y103.555 F1000
G1 X125.425 Y103.543 F1000
G1 X126.344 Y103.532 F1000
G1 X127.263 Y103.523 F1000
G1 X128.182 Y103.514 F1000
G1 X129.101 Y103.506 F1000
G1 X130.02 Y103.5 F1000
G1 X130.939 Y103.495 F1000
G1 X131.858 Y103.491 F1000
G1 X132.777 Y103.488 F1000
G1 X133.696 Y103.486 F1000
G1 X134.615 F1000
G1 X135.534 Y103.487 F1000
G1 X136.453 Y103.49 F1000
G1 X137.372 Y103.494 F1000
G1 X138.291 Y103.5 F1000
G1 X139.21 Y103.507 F1000
G1 X140.129 Y103.516 F1000
G1 X141.048 Y103.527 F1000
G1 X141.967 Y103.539 F1000
G1 X142.886 Y103.554 F1000
G1 X143.804 Y103.57 F1000
G1 X144.723 Y103.588 F1000
G1 X145.642 Y103.609 F1000
G1 X146.561 Y103.631 F1000
G1 X147.479 Y103.657 F1000
G1 X148.398 Y103.684 F1000
G1 X149.317 Y103.714 F1000
G1 X150.235 Y103.747 F1000
G1 X151.153 Y103.783 F1000
G1 X152.072 Y103.822 F1000
G1 X152.99 Y103.864 F1000
G1 X153.908 Y103.909 F1000
G1 X154.825 Y103.959 F1000
G1 X155.743 Y104.012 F1000
G1 X156.66 Y104.069 F1000
G1 X157.577 Y104.13 F1000
G1 X158.494 Y104.196 F1000
G1 X159.41 Y104.268 F1000
G1 X160.326 Y104.345 F1000
G1 X161.241 Y104.428 F1000
G1 X162.155 Y104.517 F1000
G1 X163.069 Y104.614 F1000
G1 X163.982 Y104.72 F1000
G1 X164.894 Y104.834 F1000
G1 X165.805 Y104.959 F1000
G1 X166.714 Y105.095 F1000
G1 X167.62 Y105.245 F1000
G1 X168.524 Y105.411 F1000
G1 X169.424 Y105.597 F1000
G1 X170.319 Y105.806 F1000
G1 X171.206 Y106.046 F1000
G1 X172.069 Y106.328 F1000
G1 X172.631 Y106.564 F1000
G1 X172.934 Y106.72 F1000
G1 X173.204 Y106.899 F1000
G1 X173.428 Y107.132 F1000
G1 X173.596 Y107.408 F1000
G1 X173.701 Y107.715 F1000
G1 X173.736 Y108.036 F1000
G1 Y110.563 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y111.147 I-0.635 J-0.022 F1000
G1 X173.221 Y111.168 Z-3.012 F1000
G1 X173.153 Y111.189 Z-3 F1000
G1 X173.088 Y111.209 Z-2.98 F1000
G1 X173.025 Y111.228 Z-2.953 F1000
G1 X172.966 Y111.247 Z-2.919 F1000
G1 X172.91 Y111.264 Z-2.877 F1000
G1 X172.859 Y111.28 Z-2.83 F1000
G1 X172.814 Y111.294 Z-2.777 F1000
G1 X172.775 Y111.306 Z-2.719 F1000
G1 X172.742 Y111.316 Z-2.657 F1000
G1 X172.716 Y111.324 Z-2.591 F1000
G1 X172.697 Y111.33 Z-2.522 F1000
G1 X172.685 Y111.333 Z-2.452 F1000
G1 X172.682 Y111.334 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y118.169 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y118.166 Z-2.452 F1000
G1 X22.509 Y118.156 Z-2.522 F1000
G1 X22.499 Y118.139 Z-2.591 F1000
G1 X22.485 Y118.115 Z-2.657 F1000
G1 X22.467 Y118.086 Z-2.719 F1000
G1 X22.446 Y118.05 Z-2.777 F1000
G1 X22.422 Y118.009 Z-2.83 F1000
G1 X22.395 Y117.964 Z-2.877 F1000
G1 X22.365 Y117.914 Z-2.919 F1000
G1 X22.333 Y117.86 Z-2.953 F1000
G1 X22.3 Y117.804 Z-2.98 F1000
G1 X22.265 Y117.745 Z-3 F1000
G1 X22.229 Y117.685 Z-3.012 F1000
G1 X22.192 Y117.624 Z-3.016 F1000
G3 X21.971 Y116.87 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y114.364 F1000
G1 X21.986 Y114.07 F1000
G1 X22.018 Y113.827 F1000
G1 X22.079 Y113.539 F1000
G1 X22.171 Y113.233 F1000
G1 X22.301 Y112.899 F1000
G1 X22.486 Y112.517 F1000
G1 X22.712 Y112.133 F1000
G1 X23.021 Y111.694 F1000
G1 X23.397 Y111.241 F1000
G1 X23.878 Y110.748 F1000
G1 X24.491 Y110.213 F1000
G1 X25.23 Y109.666 F1000
G1 X26.008 Y109.177 F1000
G1 X26.816 Y108.738 F1000
G1 X27.645 Y108.342 F1000
G1 X28.491 Y107.982 F1000
G1 X29.349 Y107.655 F1000
G1 X30.218 Y107.355 F1000
G1 X31.095 Y107.081 F1000
G1 X31.979 Y106.828 F1000
G1 X32.868 Y106.594 F1000
G1 X33.761 Y106.378 F1000
G1 X34.658 Y106.177 F1000
G1 X35.557 Y105.99 F1000
G1 X36.46 Y105.815 F1000
G1 X37.364 Y105.651 F1000
G1 X38.27 Y105.498 F1000
G1 X39.178 Y105.355 F1000
G1 X40.087 Y105.219 F1000
G1 X40.997 Y105.092 F1000
G1 X41.908 Y104.972 F1000
G1 X42.82 Y104.859 F1000
G1 X43.733 Y104.752 F1000
G1 X44.647 Y104.651 F1000
G1 X45.561 Y104.555 F1000
G1 X46.475 Y104.464 F1000
G1 X47.39 Y104.378 F1000
G1 X48.305 Y104.296 F1000
G1 X49.221 Y104.217 F1000
G1 X50.137 Y104.143 F1000
G1 X51.053 Y104.071 F1000
G1 X51.97 Y104.003 F1000
G1 X52.886 Y103.938 F1000
G1 X53.803 Y103.875 F1000
G1 X54.72 Y103.815 F1000
G1 X55.637 Y103.756 F1000
G1 X56.555 Y103.7 F1000
G1 X57.472 Y103.646 F1000
G1 X58.39 Y103.593 F1000
G1 X59.307 Y103.542 F1000
G1 X60.225 Y103.492 F1000
G1 X61.143 Y103.443 F1000
G1 X62.978 Y103.349 F1000
G1 X64.814 Y103.258 F1000
G1 X67.568 Y103.126 F1000
G1 X68.486 Y103.083 F1000
G1 X73.076 Y102.87 F1000
G1 X84.093 Y102.364 F1000
G1 X87.765 Y102.197 F1000
G1 X90.519 Y102.074 F1000
G1 X93.274 Y101.954 F1000
G1 X96.028 Y101.838 F1000
G1 X97.865 Y101.764 F1000
G1 X99.702 Y101.691 F1000
G1 X101.538 Y101.621 F1000
G1 X103.375 Y101.554 F1000
G1 X105.212 Y101.489 F1000
G1 X107.049 Y101.428 F1000
G1 X108.886 Y101.37 F1000
G1 X110.723 Y101.315 F1000
G1 X112.561 Y101.264 F1000
G1 X114.398 Y101.216 F1000
G1 X116.236 Y101.172 F1000
G1 X118.073 Y101.131 F1000
G1 X118.992 Y101.112 F1000
G1 X120.83 Y101.077 F1000
G1 X122.668 Y101.046 F1000
G1 X123.586 Y101.032 F1000
G1 X124.505 Y101.019 F1000
G1 X125.424 Y101.007 F1000
G1 X126.343 Y100.997 F1000
G1 X127.262 Y100.987 F1000
G1 X128.181 Y100.978 F1000
G1 X129.1 Y100.971 F1000
G1 X130.019 Y100.965 F1000
G1 X130.938 Y100.959 F1000
G1 X131.857 Y100.956 F1000
G1 X132.776 Y100.953 F1000
G1 X133.695 Y100.952 F1000
G1 X134.614 F1000
G1 X135.533 Y100.953 F1000
G1 X136.452 Y100.956 F1000
G1 X137.371 Y100.96 F1000
G1 X138.29 Y100.966 F1000
G1 X139.209 Y100.974 F1000
G1 X140.128 Y100.983 F1000
G1 X141.047 Y100.994 F1000
G1 X141.966 Y101.006 F1000
G1 X142.885 Y101.021 F1000
G1 X143.804 Y101.037 F1000
G1 X144.723 Y101.056 F1000
G1 X145.642 Y101.077 F1000
G1 X146.56 Y101.1 F1000
G1 X147.479 Y101.125 F1000
G1 X148.398 Y101.153 F1000
G1 X149.316 Y101.183 F1000
G1 X150.235 Y101.216 F1000
G1 X151.153 Y101.252 F1000
G1 X152.071 Y101.291 F1000
G1 X152.989 Y101.334 F1000
G1 X153.907 Y101.379 F1000
G1 X154.825 Y101.429 F1000
G1 X155.742 Y101.482 F1000
G1 X156.659 Y101.539 F1000
G1 X157.576 Y101.601 F1000
G1 X158.493 Y101.668 F1000
G1 X159.409 Y101.739 F1000
G1 X160.325 Y101.816 F1000
G1 X161.24 Y101.9 F1000
G1 X162.155 Y101.99 F1000
G1 X163.069 Y102.087 F1000
G1 X163.982 Y102.192 F1000
G1 X164.893 Y102.307 F1000
G1 X165.804 Y102.431 F1000
G1 X166.713 Y102.568 F1000
G1 X167.619 Y102.718 F1000
G1 X168.523 Y102.884 F1000
G1 X169.423 Y103.07 F1000
G1 X170.318 Y103.279 F1000
G1 X171.205 Y103.52 F1000
G1 X172.069 Y103.802 F1000
G1 X172.631 Y104.037 F1000
G1 X172.934 Y104.194 F1000
G1 X173.204 Y104.373 F1000
G1 X173.428 Y104.606 F1000
G1 X173.596 Y104.882 F1000
G1 X173.701 Y105.189 F1000
G1 X173.736 Y105.51 F1000
G1 Y108.036 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y108.621 I-0.635 J-0.022 F1000
G1 X173.221 Y108.642 Z-3.012 F1000
G1 X173.153 Y108.663 Z-3 F1000
G1 X173.088 Y108.683 Z-2.98 F1000
G1 X173.025 Y108.702 Z-2.953 F1000
G1 X172.966 Y108.721 Z-2.919 F1000
G1 X172.91 Y108.738 Z-2.877 F1000
G1 X172.859 Y108.753 Z-2.83 F1000
G1 X172.814 Y108.767 Z-2.777 F1000
G1 X172.775 Y108.78 Z-2.719 F1000
G1 X172.742 Y108.79 Z-2.657 F1000
G1 X172.716 Y108.798 Z-2.591 F1000
G1 X172.697 Y108.803 Z-2.522 F1000
G1 X172.685 Y108.807 Z-2.452 F1000
G1 X172.682 Y108.808 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y115.663 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y115.66 Z-2.452 F1000
G1 X22.509 Y115.65 Z-2.522 F1000
G1 X22.499 Y115.633 Z-2.591 F1000
G1 X22.485 Y115.609 Z-2.657 F1000
G1 X22.467 Y115.58 Z-2.719 F1000
G1 X22.446 Y115.544 Z-2.777 F1000
G1 X22.422 Y115.503 Z-2.83 F1000
G1 X22.395 Y115.458 Z-2.877 F1000
G1 X22.365 Y115.408 Z-2.919 F1000
G1 X22.333 Y115.354 Z-2.953 F1000
G1 X22.3 Y115.298 Z-2.98 F1000
G1 X22.265 Y115.239 Z-3 F1000
G1 X22.229 Y115.179 Z-3.012 F1000
G1 X22.192 Y115.117 Z-3.016 F1000
G3 X21.971 Y114.364 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y111.858 F1000
G1 X21.987 Y111.548 F1000
G1 X22.018 Y111.306 F1000
G1 X22.08 Y111.017 F1000
G1 X22.172 Y110.711 F1000
G1 X22.302 Y110.377 F1000
G1 X22.487 Y109.995 F1000
G1 X22.713 Y109.611 F1000
G1 X23.022 Y109.172 F1000
G1 X23.398 Y108.718 F1000
G1 X23.879 Y108.225 F1000
G1 X24.493 Y107.69 F1000
G1 X25.232 Y107.143 F1000
G1 X26.01 Y106.655 F1000
G1 X26.817 Y106.215 F1000
G1 X27.646 Y105.819 F1000
G1 X28.492 Y105.459 F1000
G1 X29.351 Y105.132 F1000
G1 X30.22 Y104.832 F1000
G1 X31.096 Y104.557 F1000
G1 X31.98 Y104.304 F1000
G1 X32.869 Y104.07 F1000
G1 X33.762 Y103.854 F1000
G1 X34.659 Y103.652 F1000
G1 X35.558 Y103.465 F1000
G1 X36.46 Y103.29 F1000
G1 X37.365 Y103.126 F1000
G1 X38.271 Y102.972 F1000
G1 X39.178 Y102.828 F1000
G1 X40.087 Y102.693 F1000
G1 X40.998 Y102.565 F1000
G1 X41.909 Y102.445 F1000
G1 X42.821 Y102.331 F1000
G1 X43.733 Y102.224 F1000
G1 X44.647 Y102.122 F1000
G1 X45.561 Y102.026 F1000
G1 X46.475 Y101.934 F1000
G1 X47.39 Y101.848 F1000
G1 X48.305 Y101.765 F1000
G1 X49.221 Y101.686 F1000
G1 X50.137 Y101.611 F1000
G1 X51.053 Y101.539 F1000
G1 X51.97 Y101.47 F1000
G1 X52.886 Y101.404 F1000
G1 X53.803 Y101.341 F1000
G1 X54.72 Y101.28 F1000
G1 X55.637 Y101.221 F1000
G1 X56.555 Y101.165 F1000
G1 X57.472 Y101.11 F1000
G1 X58.389 Y101.057 F1000
G1 X59.307 Y101.005 F1000
G1 X60.225 Y100.955 F1000
G1 X61.142 Y100.905 F1000
G1 X62.978 Y100.81 F1000
G1 X64.814 Y100.718 F1000
G1 X66.649 Y100.629 F1000
G1 X68.485 Y100.542 F1000
G1 X72.158 Y100.37 F1000
G1 X81.338 Y99.947 F1000
G1 X85.928 Y99.738 F1000
G1 X89.601 Y99.573 F1000
G1 X92.355 Y99.453 F1000
G1 X95.11 Y99.336 F1000
G1 X96.946 Y99.261 F1000
G1 X98.783 Y99.187 F1000
G1 X100.619 Y99.116 F1000
G1 X102.456 Y99.048 F1000
G1 X104.293 Y98.983 F1000
G1 X106.13 Y98.92 F1000
G1 X107.967 Y98.861 F1000
G1 X109.804 Y98.804 F1000
G1 X111.642 Y98.752 F1000
G1 X113.479 Y98.702 F1000
G1 X115.316 Y98.656 F1000
G1 X117.154 Y98.614 F1000
G1 X118.992 Y98.575 F1000
G1 X120.829 Y98.541 F1000
G1 X122.667 Y98.51 F1000
G1 X123.586 Y98.496 F1000
G1 X124.505 Y98.483 F1000
G1 X125.424 Y98.472 F1000
G1 X126.343 Y98.461 F1000
G1 X127.262 Y98.451 F1000
G1 X128.181 Y98.443 F1000
G1 X129.1 Y98.435 F1000
G1 X130.019 Y98.429 F1000
G1 X130.938 Y98.424 F1000
G1 X131.857 Y98.421 F1000
G1 X132.776 Y98.418 F1000
G1 X133.695 Y98.417 F1000
G1 X134.614 F1000
G1 X135.533 Y98.419 F1000
G1 X136.452 Y98.422 F1000
G1 X137.371 Y98.426 F1000
G1 X138.29 Y98.432 F1000
G1 X139.209 Y98.44 F1000
G1 X140.128 Y98.449 F1000
G1 X141.047 Y98.46 F1000
G1 X141.966 Y98.473 F1000
G1 X142.885 Y98.488 F1000
G1 X143.804 Y98.505 F1000
G1 X144.722 Y98.523 F1000
G1 X145.641 Y98.544 F1000
G1 X146.56 Y98.568 F1000
G1 X147.479 Y98.593 F1000
G1 X148.397 Y98.621 F1000
G1 X149.316 Y98.652 F1000
G1 X150.234 Y98.685 F1000
G1 X151.152 Y98.722 F1000
G1 X152.071 Y98.761 F1000
G1 X152.989 Y98.804 F1000
G1 X153.906 Y98.85 F1000
G1 X154.824 Y98.899 F1000
G1 X155.742 Y98.953 F1000
G1 X156.659 Y99.01 F1000
G1 X157.576 Y99.072 F1000
G1 X158.492 Y99.139 F1000
G1 X159.409 Y99.211 F1000
G1 X160.324 Y99.288 F1000
G1 X161.24 Y99.372 F1000
G1 X162.154 Y99.462 F1000
G1 X163.068 Y99.559 F1000
G1 X163.981 Y99.664 F1000
G1 X164.893 Y99.779 F1000
G1 X165.803 Y99.904 F1000
G1 X166.712 Y100.041 F1000
G1 X167.619 Y100.191 F1000
G1 X168.523 Y100.357 F1000
G1 X169.423 Y100.543 F1000
G1 X170.317 Y100.753 F1000
G1 X171.204 Y100.993 F1000
G1 X172.068 Y101.275 F1000
G1 X172.631 Y101.511 F1000
G1 X172.934 Y101.667 F1000
G1 X173.204 Y101.846 F1000
G1 X173.428 Y102.079 F1000
G1 X173.596 Y102.356 F1000
G1 X173.701 Y102.662 F1000
G1 X173.736 Y102.984 F1000
G1 Y105.51 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y106.095 I-0.635 J-0.022 F1000
G1 X173.221 Y106.116 Z-3.012 F1000
G1 X173.153 Y106.136 Z-3 F1000
G1 X173.088 Y106.157 Z-2.98 F1000
G1 X173.025 Y106.176 Z-2.953 F1000
G1 X172.966 Y106.194 Z-2.919 F1000
G1 X172.91 Y106.211 Z-2.877 F1000
G1 X172.859 Y106.227 Z-2.83 F1000
G1 X172.814 Y106.241 Z-2.777 F1000
G1 X172.775 Y106.253 Z-2.719 F1000
G1 X172.742 Y106.263 Z-2.657 F1000
G1 X172.716 Y106.271 Z-2.591 F1000
G1 X172.697 Y106.277 Z-2.522 F1000
G1 X172.685 Y106.281 Z-2.452 F1000
G1 X172.682 Y106.282 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y113.157 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y113.154 Z-2.452 F1000
G1 X22.509 Y113.144 Z-2.522 F1000
G1 X22.499 Y113.127 Z-2.591 F1000
G1 X22.485 Y113.103 Z-2.657 F1000
G1 X22.467 Y113.074 Z-2.719 F1000
G1 X22.446 Y113.038 Z-2.777 F1000
G1 X22.422 Y112.997 Z-2.83 F1000
G1 X22.395 Y112.952 Z-2.877 F1000
G1 X22.365 Y112.902 Z-2.919 F1000
G1 X22.333 Y112.848 Z-2.953 F1000
G1 X22.3 Y112.792 Z-2.98 F1000
G1 X22.265 Y112.733 Z-3 F1000
G1 X22.229 Y112.673 Z-3.012 F1000
G1 X22.192 Y112.611 Z-3.016 F1000
G3 X21.971 Y111.858 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y109.352 F1000
G1 X21.987 Y109.026 F1000
G1 X22.019 Y108.784 F1000
G1 X22.081 Y108.495 F1000
G1 X22.173 Y108.189 F1000
G1 X22.303 Y107.855 F1000
G1 X22.488 Y107.473 F1000
G1 X22.714 Y107.089 F1000
G1 X23.023 Y106.65 F1000
G1 X23.399 Y106.196 F1000
G1 X23.881 Y105.703 F1000
G1 X24.494 Y105.167 F1000
G1 X25.233 Y104.62 F1000
G1 X26.011 Y104.132 F1000
G1 X26.819 Y103.692 F1000
G1 X27.648 Y103.296 F1000
G1 X28.493 Y102.936 F1000
G1 X29.352 Y102.608 F1000
G1 X30.221 Y102.309 F1000
G1 X31.098 Y102.034 F1000
G1 X31.981 Y101.78 F1000
G1 X32.87 Y101.546 F1000
G1 X33.763 Y101.329 F1000
G1 X34.659 Y101.128 F1000
G1 X35.559 Y100.94 F1000
G1 X36.461 Y100.764 F1000
G1 X37.365 Y100.6 F1000
G1 X38.272 Y100.446 F1000
G1 X39.179 Y100.302 F1000
G1 X40.088 Y100.166 F1000
G1 X40.998 Y100.038 F1000
G1 X41.909 Y99.917 F1000
G1 X42.821 Y99.803 F1000
G1 X43.734 Y99.695 F1000
G1 X44.647 Y99.593 F1000
G1 X45.561 Y99.496 F1000
G1 X46.475 Y99.404 F1000
G1 X47.39 Y99.317 F1000
G1 X48.305 Y99.234 F1000
G1 X49.221 Y99.155 F1000
G1 X50.137 Y99.079 F1000
G1 X51.053 Y99.006 F1000
G1 X51.97 Y98.937 F1000
G1 X52.886 Y98.871 F1000
G1 X53.803 Y98.807 F1000
G1 X54.72 Y98.746 F1000
G1 X55.637 Y98.686 F1000
G1 X56.554 Y98.629 F1000
G1 X57.472 Y98.574 F1000
G1 X58.389 Y98.52 F1000
G1 X59.307 Y98.468 F1000
G1 X60.224 Y98.417 F1000
G1 X61.142 Y98.367 F1000
G1 X62.977 Y98.271 F1000
G1 X64.813 Y98.179 F1000
G1 X66.649 Y98.089 F1000
G1 X68.485 Y98.001 F1000
G1 X72.157 Y97.828 F1000
G1 X79.501 Y97.489 F1000
G1 X85.01 Y97.237 F1000
G1 X88.682 Y97.073 F1000
G1 X91.436 Y96.952 F1000
G1 X94.191 Y96.834 F1000
G1 X96.946 Y96.721 F1000
G1 X98.782 Y96.648 F1000
G1 X100.619 Y96.577 F1000
G1 X102.456 Y96.509 F1000
G1 X104.293 Y96.444 F1000
G1 X106.13 Y96.382 F1000
G1 X107.967 Y96.323 F1000
G1 X109.804 Y96.267 F1000
G1 X111.641 Y96.214 F1000
G1 X113.479 Y96.165 F1000
G1 X115.316 Y96.119 F1000
G1 X117.154 Y96.077 F1000
G1 X118.991 Y96.039 F1000
G1 X120.829 Y96.004 F1000
G1 X122.667 Y95.974 F1000
G1 X123.586 Y95.96 F1000
G1 X124.505 Y95.947 F1000
G1 X125.424 Y95.936 F1000
G1 X126.343 Y95.925 F1000
G1 X127.262 Y95.916 F1000
G1 X128.18 Y95.907 F1000
G1 X129.099 Y95.9 F1000
G1 X130.018 Y95.894 F1000
G1 X130.938 Y95.889 F1000
G1 X131.857 Y95.886 F1000
G1 X132.776 Y95.883 F1000
G1 X133.695 Y95.882 F1000
G1 X134.614 Y95.883 F1000
G1 X135.533 Y95.884 F1000
G1 X136.452 Y95.887 F1000
G1 X137.371 Y95.892 F1000
G1 X138.29 Y95.898 F1000
G1 X139.209 Y95.906 F1000
G1 X140.128 Y95.916 F1000
G1 X141.047 Y95.927 F1000
G1 X141.965 Y95.94 F1000
G1 X142.884 Y95.955 F1000
G1 X143.803 Y95.972 F1000
G1 X144.722 Y95.991 F1000
G1 X145.641 Y96.012 F1000
G1 X146.56 Y96.036 F1000
G1 X147.478 Y96.062 F1000
G1 X148.397 Y96.09 F1000
G1 X149.315 Y96.121 F1000
G1 X150.234 Y96.154 F1000
G1 X151.152 Y96.191 F1000
G1 X152.07 Y96.23 F1000
G1 X152.988 Y96.273 F1000
G1 X153.906 Y96.319 F1000
G1 X154.824 Y96.369 F1000
G1 X155.741 Y96.423 F1000
G1 X156.658 Y96.481 F1000
G1 X157.575 Y96.543 F1000
G1 X158.492 Y96.61 F1000
G1 X159.408 Y96.682 F1000
G1 X160.324 Y96.76 F1000
G1 X161.239 Y96.843 F1000
G1 X162.154 Y96.933 F1000
G1 X163.067 Y97.031 F1000
G1 X163.98 Y97.137 F1000
G1 X164.892 Y97.252 F1000
G1 X165.803 Y97.377 F1000
G1 X166.711 Y97.514 F1000
G1 X167.618 Y97.664 F1000
G1 X168.522 Y97.83 F1000
G1 X169.422 Y98.016 F1000
G1 X170.317 Y98.226 F1000
G1 X171.204 Y98.466 F1000
G1 X172.068 Y98.749 F1000
G1 X172.631 Y98.984 F1000
G1 X172.934 Y99.141 F1000
G1 X173.204 Y99.32 F1000
G1 X173.428 Y99.553 F1000
G1 X173.596 Y99.829 F1000
G1 X173.701 Y100.136 F1000
G1 X173.736 Y100.457 F1000
G1 Y102.984 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y103.568 I-0.635 J-0.022 F1000
G1 X173.221 Y103.589 Z-3.012 F1000
G1 X173.153 Y103.61 Z-3 F1000
G1 X173.088 Y103.63 Z-2.98 F1000
G1 X173.025 Y103.65 Z-2.953 F1000
G1 X172.966 Y103.668 Z-2.919 F1000
G1 X172.91 Y103.685 Z-2.877 F1000
G1 X172.859 Y103.701 Z-2.83 F1000
G1 X172.814 Y103.715 Z-2.777 F1000
G1 X172.775 Y103.727 Z-2.719 F1000
G1 X172.742 Y103.737 Z-2.657 F1000
G1 X172.716 Y103.745 Z-2.591 F1000
G1 X172.697 Y103.751 Z-2.522 F1000
G1 X172.685 Y103.754 Z-2.452 F1000
G1 X172.682 Y103.755 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y110.651 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y110.648 Z-2.452 F1000
G1 X22.509 Y110.638 Z-2.522 F1000
G1 X22.499 Y110.621 Z-2.591 F1000
G1 X22.485 Y110.597 Z-2.657 F1000
G1 X22.467 Y110.568 Z-2.719 F1000
G1 X22.446 Y110.532 Z-2.777 F1000
G1 X22.422 Y110.491 Z-2.83 F1000
G1 X22.395 Y110.446 Z-2.877 F1000
G1 X22.365 Y110.396 Z-2.919 F1000
G1 X22.333 Y110.342 Z-2.953 F1000
G1 X22.3 Y110.286 Z-2.98 F1000
G1 X22.265 Y110.227 Z-3 F1000
G1 X22.229 Y110.167 Z-3.012 F1000
G1 X22.192 Y110.105 Z-3.016 F1000
G3 X21.971 Y109.352 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y106.846 F1000
G1 X21.988 Y106.504 F1000
G1 X22.02 Y106.261 F1000
G1 X22.082 Y105.973 F1000
G1 X22.173 Y105.666 F1000
G1 X22.303 Y105.332 F1000
G1 X22.489 Y104.95 F1000
G1 X22.715 Y104.567 F1000
G1 X23.024 Y104.127 F1000
G1 X23.4 Y103.673 F1000
G1 X23.882 Y103.18 F1000
G1 X24.496 Y102.644 F1000
G1 X25.235 Y102.097 F1000
G1 X26.013 Y101.608 F1000
G1 X26.82 Y101.169 F1000
G1 X27.649 Y100.772 F1000
G1 X28.495 Y100.413 F1000
G1 X29.353 Y100.085 F1000
G1 X30.222 Y99.785 F1000
G1 X31.099 Y99.51 F1000
G1 X31.982 Y99.256 F1000
G1 X32.871 Y99.022 F1000
G1 X33.764 Y98.804 F1000
G1 X34.66 Y98.603 F1000
G1 X35.56 Y98.414 F1000
G1 X36.462 Y98.239 F1000
G1 X37.366 Y98.074 F1000
G1 X38.272 Y97.92 F1000
G1 X39.18 Y97.775 F1000
G1 X40.089 Y97.639 F1000
G1 X40.999 Y97.51 F1000
G1 X41.91 Y97.389 F1000
G1 X42.821 Y97.275 F1000
G1 X43.734 Y97.167 F1000
G1 X44.647 Y97.064 F1000
G1 X45.561 Y96.967 F1000
G1 X46.476 Y96.874 F1000
G1 X47.39 Y96.786 F1000
G1 X48.306 Y96.703 F1000
G1 X49.221 Y96.623 F1000
G1 X50.137 Y96.547 F1000
G1 X51.053 Y96.474 F1000
G1 X51.97 Y96.404 F1000
G1 X52.886 Y96.337 F1000
G1 X53.803 Y96.273 F1000
G1 X54.72 Y96.211 F1000
G1 X55.637 Y96.151 F1000
G1 X56.554 Y96.093 F1000
G1 X57.471 Y96.038 F1000
G1 X58.389 Y95.983 F1000
G1 X59.306 Y95.931 F1000
G1 X60.224 Y95.88 F1000
G1 X61.142 Y95.83 F1000
G1 X62.977 Y95.733 F1000
G1 X64.813 Y95.639 F1000
G1 X66.649 Y95.549 F1000
G1 X68.484 Y95.46 F1000
G1 X72.156 Y95.287 F1000
G1 X77.665 Y95.031 F1000
G1 X83.173 Y94.779 F1000
G1 X86.845 Y94.613 F1000
G1 X89.6 Y94.491 F1000
G1 X92.354 Y94.371 F1000
G1 X95.109 Y94.255 F1000
G1 X96.945 Y94.181 F1000
G1 X98.782 Y94.108 F1000
G1 X100.619 Y94.038 F1000
G1 X102.455 Y93.97 F1000
G1 X104.292 Y93.905 F1000
G1 X106.129 Y93.843 F1000
G1 X107.966 Y93.785 F1000
G1 X109.804 Y93.729 F1000
G1 X111.641 Y93.676 F1000
G1 X113.478 Y93.628 F1000
G1 X115.316 Y93.582 F1000
G1 X117.153 Y93.54 F1000
G1 X118.991 Y93.502 F1000
G1 X120.829 Y93.468 F1000
G1 X122.666 Y93.438 F1000
G1 X123.585 Y93.424 F1000
G1 X124.504 Y93.411 F1000
G1 X125.423 Y93.4 F1000
G1 X126.342 Y93.389 F1000
G1 X127.261 Y93.38 F1000
G1 X128.18 Y93.372 F1000
G1 X129.099 Y93.365 F1000
G1 X130.018 Y93.359 F1000
G1 X130.937 Y93.354 F1000
G1 X131.856 Y93.351 F1000
G1 X132.775 Y93.348 F1000
G1 X133.694 F1000
G1 X134.613 F1000
G1 X135.532 Y93.35 F1000
G1 X136.451 Y93.353 F1000
G1 X137.37 Y93.358 F1000
G1 X138.289 Y93.365 F1000
G1 X139.208 Y93.373 F1000
G1 X140.127 Y93.382 F1000
G1 X141.046 Y93.394 F1000
G1 X141.965 Y93.407 F1000
G1 X142.884 Y93.422 F1000
G1 X143.803 Y93.44 F1000
G1 X144.722 Y93.459 F1000
G1 X145.64 Y93.48 F1000
G1 X146.559 Y93.504 F1000
G1 X147.478 Y93.53 F1000
G1 X148.396 Y93.558 F1000
G1 X149.315 Y93.59 F1000
G1 X150.233 Y93.623 F1000
G1 X151.152 Y93.66 F1000
G1 X152.07 Y93.7 F1000
G1 X152.988 Y93.743 F1000
G1 X153.906 Y93.789 F1000
G1 X154.823 Y93.84 F1000
G1 X155.741 Y93.893 F1000
G1 X156.658 Y93.951 F1000
G1 X157.575 Y94.014 F1000
G1 X158.491 Y94.081 F1000
G1 X159.408 Y94.153 F1000
G1 X160.323 Y94.231 F1000
G1 X161.238 Y94.315 F1000
G1 X162.153 Y94.405 F1000
G1 X163.067 Y94.503 F1000
G1 X163.98 Y94.609 F1000
G1 X164.891 Y94.724 F1000
G1 X165.802 Y94.849 F1000
G1 X166.711 Y94.986 F1000
G1 X167.617 Y95.137 F1000
G1 X168.521 Y95.303 F1000
G1 X169.421 Y95.489 F1000
G1 X170.316 Y95.699 F1000
G1 X171.203 Y95.939 F1000
G1 X172.068 Y96.222 F1000
G1 X172.631 Y96.457 F1000
G1 X172.934 Y96.614 F1000
G1 X173.204 Y96.793 F1000
G1 X173.428 Y97.026 F1000
G1 X173.596 Y97.303 F1000
G1 X173.701 Y97.609 F1000
G1 X173.736 Y97.931 F1000
G1 Y100.457 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y101.042 I-0.635 J-0.022 F1000
G1 X173.221 Y101.063 Z-3.012 F1000
G1 X173.153 Y101.084 Z-3 F1000
G1 X173.088 Y101.104 Z-2.98 F1000
G1 X173.025 Y101.123 Z-2.953 F1000
G1 X172.966 Y101.141 Z-2.919 F1000
G1 X172.91 Y101.159 Z-2.877 F1000
G1 X172.859 Y101.174 Z-2.83 F1000
G1 X172.814 Y101.188 Z-2.777 F1000
G1 X172.775 Y101.2 Z-2.719 F1000
G1 X172.742 Y101.21 Z-2.657 F1000
G1 X172.716 Y101.218 Z-2.591 F1000
G1 X172.697 Y101.224 Z-2.522 F1000
G1 X172.685 Y101.228 Z-2.452 F1000
G1 X172.682 Y101.229 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y108.145 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y108.142 Z-2.452 F1000
G1 X22.509 Y108.132 Z-2.522 F1000
G1 X22.499 Y108.115 Z-2.591 F1000
G1 X22.485 Y108.091 Z-2.657 F1000
G1 X22.467 Y108.062 Z-2.719 F1000
G1 X22.446 Y108.026 Z-2.777 F1000
G1 X22.422 Y107.985 Z-2.83 F1000
G1 X22.395 Y107.94 Z-2.877 F1000
G1 X22.365 Y107.89 Z-2.919 F1000
G1 X22.333 Y107.836 Z-2.953 F1000
G1 X22.3 Y107.78 Z-2.98 F1000
G1 X22.265 Y107.721 Z-3 F1000
G1 X22.229 Y107.661 Z-3.012 F1000
G1 X22.192 Y107.599 Z-3.016 F1000
G3 X21.971 Y106.846 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y104.34 F1000
G1 X21.989 Y103.981 F1000
G1 X22.021 Y103.739 F1000
G1 X22.083 Y103.45 F1000
G1 X22.174 Y103.144 F1000
G1 X22.304 Y102.81 F1000
G1 X22.49 Y102.428 F1000
G1 X22.716 Y102.044 F1000
G1 X23.025 Y101.604 F1000
G1 X23.401 Y101.15 F1000
G1 X23.883 Y100.656 F1000
G1 X24.497 Y100.12 F1000
G1 X25.236 Y99.574 F1000
G1 X26.014 Y99.085 F1000
G1 X26.822 Y98.646 F1000
G1 X27.651 Y98.249 F1000
G1 X28.496 Y97.889 F1000
G1 X29.355 Y97.561 F1000
G1 X30.223 Y97.261 F1000
G1 X31.1 Y96.985 F1000
G1 X31.983 Y96.731 F1000
G1 X32.872 Y96.497 F1000
G1 X33.765 Y96.279 F1000
G1 X34.661 Y96.077 F1000
G1 X35.561 Y95.889 F1000
G1 X36.463 Y95.713 F1000
G1 X37.367 Y95.548 F1000
G1 X38.273 Y95.393 F1000
G1 X39.18 Y95.248 F1000
G1 X40.089 Y95.112 F1000
G1 X40.999 Y94.983 F1000
G1 X41.91 Y94.861 F1000
G1 X42.822 Y94.746 F1000
G1 X43.734 Y94.638 F1000
G1 X44.648 Y94.535 F1000
G1 X45.562 Y94.437 F1000
G1 X46.476 Y94.344 F1000
G1 X47.391 Y94.256 F1000
G1 X48.306 Y94.171 F1000
G1 X49.221 Y94.091 F1000
G1 X50.137 Y94.014 F1000
G1 X51.053 Y93.941 F1000
G1 X51.97 Y93.871 F1000
G1 X52.886 Y93.803 F1000
G1 X53.803 Y93.739 F1000
G1 X54.72 Y93.676 F1000
G1 X55.637 Y93.616 F1000
G1 X56.554 Y93.558 F1000
G1 X57.471 Y93.501 F1000
G1 X58.389 Y93.447 F1000
G1 X59.306 Y93.394 F1000
G1 X60.224 Y93.342 F1000
G1 X61.141 Y93.292 F1000
G1 X62.977 Y93.194 F1000
G1 X64.812 Y93.1 F1000
G1 X66.648 Y93.008 F1000
G1 X68.484 Y92.919 F1000
G1 X71.238 Y92.788 F1000
G1 X75.828 Y92.574 F1000
G1 X81.336 Y92.32 F1000
G1 X85.927 Y92.112 F1000
G1 X88.681 Y91.99 F1000
G1 X91.436 Y91.87 F1000
G1 X94.19 Y91.753 F1000
G1 X96.027 Y91.678 F1000
G1 X97.863 Y91.604 F1000
G1 X99.7 Y91.533 F1000
G1 X101.537 Y91.465 F1000
G1 X103.373 Y91.399 F1000
G1 X105.21 Y91.336 F1000
G1 X107.047 Y91.275 F1000
G1 X108.885 Y91.218 F1000
G1 X110.722 Y91.165 F1000
G1 X112.559 Y91.114 F1000
G1 X114.397 Y91.067 F1000
G1 X116.234 Y91.024 F1000
G1 X118.072 Y90.984 F1000
G1 X118.991 Y90.966 F1000
G1 X120.828 Y90.932 F1000
G1 X122.666 Y90.901 F1000
G1 X123.585 Y90.888 F1000
G1 X124.504 Y90.875 F1000
G1 X125.423 Y90.864 F1000
G1 X126.342 Y90.854 F1000
G1 X127.261 Y90.844 F1000
G1 X128.18 Y90.836 F1000
G1 X129.099 Y90.829 F1000
G1 X130.018 Y90.824 F1000
G1 X130.937 Y90.819 F1000
G1 X131.856 Y90.816 F1000
G1 X132.775 Y90.814 F1000
G1 X133.694 Y90.813 F1000
G1 X134.613 Y90.814 F1000
G1 X135.532 Y90.816 F1000
G1 X136.451 Y90.819 F1000
G1 X137.37 Y90.824 F1000
G1 X138.289 Y90.831 F1000
G1 X139.208 Y90.839 F1000
G1 X140.127 Y90.849 F1000
G1 X141.046 Y90.861 F1000
G1 X141.965 Y90.874 F1000
G1 X142.884 Y90.89 F1000
G1 X143.803 Y90.907 F1000
G1 X144.721 Y90.926 F1000
G1 X145.64 Y90.948 F1000
G1 X146.559 Y90.972 F1000
G1 X147.477 Y90.998 F1000
G1 X148.396 Y91.027 F1000
G1 X149.315 Y91.058 F1000
G1 X150.233 Y91.092 F1000
G1 X151.151 Y91.129 F1000
G1 X152.069 Y91.169 F1000
G1 X152.987 Y91.213 F1000
G1 X153.905 Y91.259 F1000
G1 X154.823 Y91.31 F1000
G1 X155.74 Y91.364 F1000
G1 X156.657 Y91.422 F1000
G1 X157.574 Y91.485 F1000
G1 X158.491 Y91.552 F1000
G1 X159.407 Y91.625 F1000
G1 X160.323 Y91.703 F1000
G1 X161.238 Y91.787 F1000
G1 X162.152 Y91.877 F1000
G1 X163.066 Y91.975 F1000
G1 X163.979 Y92.081 F1000
G1 X164.891 Y92.196 F1000
G1 X165.801 Y92.322 F1000
G1 X166.71 Y92.459 F1000
G1 X167.617 Y92.609 F1000
G1 X168.52 Y92.776 F1000
G1 X169.42 Y92.962 F1000
G1 X170.315 Y93.172 F1000
G1 X171.202 Y93.412 F1000
G1 X172.068 Y93.695 F1000
G1 X172.63 Y93.93 F1000
G1 X172.934 Y94.087 F1000
G1 X173.204 Y94.266 F1000
G1 X173.428 Y94.5 F1000
G1 X173.596 Y94.776 F1000
G1 X173.701 Y95.082 F1000
G1 X173.736 Y95.404 F1000
G1 Y97.931 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y98.515 I-0.635 J-0.022 F1000
G1 X173.221 Y98.536 Z-3.012 F1000
G1 X173.153 Y98.557 Z-3 F1000
G1 X173.088 Y98.577 Z-2.98 F1000
G1 X173.025 Y98.596 Z-2.953 F1000
G1 X172.966 Y98.615 Z-2.919 F1000
G1 X172.91 Y98.632 Z-2.877 F1000
G1 X172.859 Y98.648 Z-2.83 F1000
G1 X172.814 Y98.661 Z-2.777 F1000
G1 X172.775 Y98.674 Z-2.719 F1000
G1 X172.742 Y98.684 Z-2.657 F1000
G1 X172.716 Y98.692 Z-2.591 F1000
G1 X172.697 Y98.698 Z-2.522 F1000
G1 X172.685 Y98.701 Z-2.452 F1000
G1 X172.682 Y98.702 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y105.639 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y105.636 Z-2.452 F1000
G1 X22.509 Y105.626 Z-2.522 F1000
G1 X22.499 Y105.609 Z-2.591 F1000
G1 X22.485 Y105.585 Z-2.657 F1000
G1 X22.467 Y105.556 Z-2.719 F1000
G1 X22.446 Y105.52 Z-2.777 F1000
G1 X22.422 Y105.479 Z-2.83 F1000
G1 X22.395 Y105.434 Z-2.877 F1000
G1 X22.365 Y105.384 Z-2.919 F1000
G1 X22.333 Y105.33 Z-2.953 F1000
G1 X22.3 Y105.274 Z-2.98 F1000
G1 X22.265 Y105.215 Z-3 F1000
G1 X22.229 Y105.155 Z-3.012 F1000
G1 X22.192 Y105.093 Z-3.016 F1000
G3 X21.971 Y104.34 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y101.625 F1000
G1 X21.979 Y101.468 F1000
G1 X22.011 Y101.225 F1000
G1 X22.072 Y100.937 F1000
G1 X22.165 Y100.628 F1000
G1 X22.295 Y100.294 F1000
G1 X22.481 Y99.911 F1000
G1 X22.707 Y99.527 F1000
G1 X23.017 Y99.085 F1000
G1 X23.394 Y98.631 F1000
G1 X23.877 Y98.136 F1000
G1 X24.492 Y97.6 F1000
G1 X25.231 Y97.053 F1000
G1 X26.009 Y96.564 F1000
G1 X26.816 Y96.124 F1000
G1 X27.645 Y95.727 F1000
G1 X28.491 Y95.367 F1000
G1 X29.349 Y95.039 F1000
G1 X30.218 Y94.738 F1000
G1 X31.094 Y94.463 F1000
G1 X31.977 Y94.209 F1000
G1 X32.866 Y93.974 F1000
G1 X33.759 Y93.756 F1000
G1 X34.655 Y93.553 F1000
G1 X35.555 Y93.364 F1000
G1 X36.457 Y93.188 F1000
G1 X37.361 Y93.023 F1000
G1 X38.266 Y92.868 F1000
G1 X39.174 Y92.722 F1000
G1 X40.083 Y92.585 F1000
G1 X40.992 Y92.456 F1000
G1 X41.903 Y92.334 F1000
G1 X42.815 Y92.218 F1000
G1 X43.728 Y92.109 F1000
G1 X44.641 Y92.006 F1000
G1 X45.555 Y91.908 F1000
G1 X46.469 Y91.814 F1000
G1 X47.384 Y91.725 F1000
G1 X48.299 Y91.641 F1000
G1 X49.214 Y91.56 F1000
G1 X50.13 Y91.483 F1000
G1 X51.046 Y91.409 F1000
G1 X51.962 Y91.338 F1000
G1 X52.879 Y91.27 F1000
G1 X53.795 Y91.205 F1000
G1 X54.712 Y91.142 F1000
G1 X55.629 Y91.081 F1000
G1 X56.546 Y91.022 F1000
G1 X57.464 Y90.966 F1000
G1 X58.381 Y90.911 F1000
G1 X59.299 Y90.857 F1000
G1 X60.216 Y90.805 F1000
G1 X61.134 Y90.754 F1000
G1 X62.051 Y90.704 F1000
G1 X63.887 Y90.608 F1000
G1 X65.723 Y90.514 F1000
G1 X67.558 Y90.424 F1000
G1 X69.394 Y90.335 F1000
G1 X72.148 Y90.204 F1000
G1 X76.738 Y89.99 F1000
G1 X81.329 Y89.778 F1000
G1 X85.001 Y89.612 F1000
G1 X88.673 Y89.449 F1000
G1 X91.428 Y89.329 F1000
G1 X94.182 Y89.213 F1000
G1 X96.019 Y89.138 F1000
G1 X97.855 Y89.065 F1000
G1 X99.692 Y88.994 F1000
G1 X101.529 Y88.926 F1000
G1 X103.366 Y88.86 F1000
G1 X105.203 Y88.797 F1000
G1 X107.04 Y88.737 F1000
G1 X108.877 Y88.681 F1000
G1 X110.714 Y88.627 F1000
G1 X112.552 Y88.577 F1000
G1 X114.389 Y88.53 F1000
G1 X116.227 Y88.487 F1000
G1 X118.064 Y88.448 F1000
G1 X119.902 Y88.412 F1000
G1 X121.74 Y88.38 F1000
G1 X122.659 Y88.365 F1000
G1 X123.577 Y88.352 F1000
G1 X124.496 Y88.34 F1000
G1 X125.415 Y88.328 F1000
G1 X126.334 Y88.318 F1000
G1 X127.253 Y88.309 F1000
G1 X128.172 Y88.301 F1000
G1 X129.091 Y88.294 F1000
G1 X130.01 Y88.288 F1000
G1 X130.929 Y88.284 F1000
G1 X131.848 Y88.281 F1000
G1 X132.767 Y88.279 F1000
G1 X133.686 Y88.278 F1000
G1 X134.605 Y88.279 F1000
G1 X135.524 Y88.281 F1000
G1 X136.443 Y88.285 F1000
G1 X137.362 Y88.29 F1000
G1 X138.281 Y88.297 F1000
G1 X139.2 Y88.305 F1000
G1 X140.119 Y88.316 F1000
G1 X141.038 Y88.327 F1000
G1 X141.957 Y88.341 F1000
G1 X142.876 Y88.357 F1000
G1 X143.795 Y88.374 F1000
G1 X144.714 Y88.394 F1000
G1 X145.633 Y88.416 F1000
G1 X146.551 Y88.44 F1000
G1 X147.47 Y88.466 F1000
G1 X148.388 Y88.495 F1000
G1 X149.307 Y88.527 F1000
G1 X150.225 Y88.561 F1000
G1 X151.144 Y88.598 F1000
G1 X152.062 Y88.639 F1000
G1 X152.98 Y88.682 F1000
G1 X153.898 Y88.729 F1000
G1 X154.815 Y88.779 F1000
G1 X155.733 Y88.834 F1000
G1 X156.65 Y88.892 F1000
G1 X157.567 Y88.955 F1000
G1 X158.483 Y89.022 F1000
G1 X159.399 Y89.095 F1000
G1 X160.315 Y89.173 F1000
G1 X161.23 Y89.257 F1000
G1 X162.145 Y89.348 F1000
G1 X163.058 Y89.446 F1000
G1 X163.971 Y89.552 F1000
G1 X164.883 Y89.667 F1000
G1 X165.793 Y89.793 F1000
G1 X166.702 Y89.93 F1000
G1 X167.609 Y90.081 F1000
G1 X168.513 Y90.247 F1000
G1 X169.413 Y90.433 F1000
G1 X170.307 Y90.643 F1000
G1 X171.195 Y90.883 F1000
G1 X172.063 Y91.166 F1000
G1 X172.627 Y91.402 F1000
G1 X172.934 Y91.56 F1000
G1 X173.203 Y91.739 F1000
G1 X173.428 Y91.972 F1000
G1 X173.596 Y92.249 F1000
G1 X173.701 Y92.555 F1000
G1 X173.736 Y92.877 F1000
G1 Y95.404 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y95.988 I-0.635 J-0.022 F1000
G1 X173.221 Y96.009 Z-3.012 F1000
G1 X173.153 Y96.03 Z-3 F1000
G1 X173.088 Y96.05 Z-2.98 F1000
G1 X173.025 Y96.07 Z-2.953 F1000
G1 X172.966 Y96.088 Z-2.919 F1000
G1 X172.91 Y96.105 Z-2.877 F1000
G1 X172.859 Y96.121 Z-2.83 F1000
G1 X172.814 Y96.135 Z-2.777 F1000
G1 X172.775 Y96.147 Z-2.719 F1000
G1 X172.742 Y96.157 Z-2.657 F1000
G1 X172.716 Y96.165 Z-2.591 F1000
G1 X172.697 Y96.171 Z-2.522 F1000
G1 X172.685 Y96.174 Z-2.452 F1000
G1 X172.682 Y96.176 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y102.924 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y102.921 Z-2.452 F1000
G1 X22.509 Y102.911 Z-2.522 F1000
G1 X22.499 Y102.894 Z-2.591 F1000
G1 X22.485 Y102.87 Z-2.657 F1000
G1 X22.467 Y102.841 Z-2.719 F1000
G1 X22.446 Y102.805 Z-2.777 F1000
G1 X22.422 Y102.765 Z-2.83 F1000
G1 X22.395 Y102.719 Z-2.877 F1000
G1 X22.365 Y102.669 Z-2.919 F1000
G1 X22.333 Y102.615 Z-2.953 F1000
G1 X22.3 Y102.559 Z-2.98 F1000
G1 X22.265 Y102.5 Z-3 F1000
G1 X22.229 Y102.44 Z-3.012 F1000
G1 X22.192 Y102.379 Z-3.016 F1000
G3 X21.971 Y101.625 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y99.119 F1000
G1 X21.98 Y98.942 F1000
G1 X22.012 Y98.699 F1000
G1 X22.073 Y98.411 F1000
G1 X22.165 Y98.103 F1000
G1 X22.296 Y97.769 F1000
G1 X22.481 Y97.386 F1000
G1 X22.707 Y97.002 F1000
G1 X23.017 Y96.562 F1000
G1 X23.394 Y96.107 F1000
G1 X23.877 Y95.613 F1000
G1 X24.492 Y95.076 F1000
G1 X25.231 Y94.529 F1000
G1 X26.009 Y94.04 F1000
G1 X26.816 Y93.601 F1000
G1 X27.645 Y93.204 F1000
G1 X28.49 Y92.843 F1000
G1 X29.349 Y92.515 F1000
G1 X30.217 Y92.214 F1000
G1 X31.094 Y91.938 F1000
G1 X31.977 Y91.684 F1000
G1 X32.865 Y91.449 F1000
G1 X33.758 Y91.231 F1000
G1 X34.654 Y91.028 F1000
G1 X35.554 Y90.839 F1000
G1 X36.456 Y90.662 F1000
G1 X37.36 Y90.496 F1000
G1 X38.265 Y90.341 F1000
G1 X39.173 Y90.195 F1000
G1 X40.081 Y90.058 F1000
G1 X40.991 Y89.928 F1000
G1 X41.902 Y89.806 F1000
G1 X42.814 Y89.69 F1000
G1 X43.726 Y89.58 F1000
G1 X44.639 Y89.476 F1000
G1 X45.553 Y89.378 F1000
G1 X46.467 Y89.284 F1000
G1 X47.382 Y89.194 F1000
G1 X48.297 Y89.109 F1000
G1 X49.212 Y89.028 F1000
G1 X50.128 Y88.95 F1000
G1 X51.044 Y88.876 F1000
G1 X51.96 Y88.805 F1000
G1 X52.877 Y88.736 F1000
G1 X53.794 Y88.67 F1000
G1 X54.71 Y88.607 F1000
G1 X55.627 Y88.546 F1000
G1 X56.544 Y88.487 F1000
G1 X57.462 Y88.43 F1000
G1 X58.379 Y88.374 F1000
G1 X59.297 Y88.32 F1000
G1 X60.214 Y88.267 F1000
G1 X61.132 Y88.216 F1000
G1 X62.049 Y88.166 F1000
G1 X63.885 Y88.069 F1000
G1 X65.72 Y87.975 F1000
G1 X67.556 Y87.883 F1000
G1 X69.392 Y87.794 F1000
G1 X72.146 Y87.662 F1000
G1 X75.818 Y87.49 F1000
G1 X80.408 Y87.278 F1000
G1 X84.999 Y87.07 F1000
G1 X87.753 Y86.948 F1000
G1 X90.507 Y86.828 F1000
G1 X93.262 Y86.711 F1000
G1 X96.017 Y86.598 F1000
G1 X97.853 Y86.525 F1000
G1 X99.69 Y86.455 F1000
G1 X101.527 Y86.387 F1000
G1 X103.364 Y86.321 F1000
G1 X105.201 Y86.259 F1000
G1 X107.038 Y86.199 F1000
G1 X108.875 Y86.143 F1000
G1 X110.712 Y86.09 F1000
G1 X112.549 Y86.04 F1000
G1 X114.387 Y85.993 F1000
G1 X116.224 Y85.95 F1000
G1 X118.062 Y85.911 F1000
G1 X119.9 Y85.875 F1000
G1 X121.738 Y85.844 F1000
G1 X122.656 Y85.829 F1000
G1 X123.575 Y85.816 F1000
G1 X124.494 Y85.804 F1000
G1 X125.413 Y85.792 F1000
G1 X126.332 Y85.782 F1000
G1 X127.251 Y85.773 F1000
G1 X128.17 Y85.765 F1000
G1 X129.089 Y85.759 F1000
G1 X130.008 Y85.753 F1000
G1 X130.927 Y85.749 F1000
G1 X131.846 Y85.746 F1000
G1 X132.765 Y85.744 F1000
G1 X133.684 F1000
G1 X134.603 Y85.745 F1000
G1 X135.522 Y85.747 F1000
G1 X136.441 Y85.751 F1000
G1 X137.36 Y85.756 F1000
G1 X138.279 Y85.763 F1000
G1 X139.198 Y85.772 F1000
G1 X140.117 Y85.782 F1000
G1 X141.036 Y85.794 F1000
G1 X141.955 Y85.808 F1000
G1 X142.874 Y85.824 F1000
G1 X143.793 Y85.842 F1000
G1 X144.712 Y85.861 F1000
G1 X145.63 Y85.884 F1000
G1 X146.549 Y85.908 F1000
G1 X147.468 Y85.934 F1000
G1 X148.386 Y85.964 F1000
G1 X149.305 Y85.995 F1000
G1 X150.223 Y86.03 F1000
G1 X151.141 Y86.067 F1000
G1 X152.06 Y86.108 F1000
G1 X152.978 Y86.151 F1000
G1 X153.895 Y86.199 F1000
G1 X154.813 Y86.249 F1000
G1 X155.73 Y86.304 F1000
G1 X156.647 Y86.362 F1000
G1 X157.564 Y86.425 F1000
G1 X158.481 Y86.493 F1000
G1 X159.397 Y86.566 F1000
G1 X160.313 Y86.644 F1000
G1 X161.228 Y86.729 F1000
G1 X162.142 Y86.82 F1000
G1 X163.056 Y86.918 F1000
G1 X163.969 Y87.024 F1000
G1 X164.881 Y87.139 F1000
G1 X165.791 Y87.265 F1000
G1 X166.7 Y87.402 F1000
G1 X167.606 Y87.553 F1000
G1 X168.51 Y87.72 F1000
G1 X169.41 Y87.905 F1000
G1 X170.305 Y88.115 F1000
G1 X171.192 Y88.355 F1000
G1 X172.062 Y88.639 F1000
G1 X172.626 Y88.875 F1000
G1 X172.933 Y89.033 F1000
G1 X173.203 Y89.212 F1000
G1 X173.428 Y89.445 F1000
G1 X173.596 Y89.722 F1000
G1 X173.701 Y90.028 F1000
G1 X173.736 Y90.35 F1000
G1 Y92.877 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y93.462 I-0.635 J-0.022 F1000
G1 X173.221 Y93.482 Z-3.012 F1000
G1 X173.153 Y93.503 Z-3 F1000
G1 X173.088 Y93.523 Z-2.98 F1000
G1 X173.025 Y93.543 Z-2.953 F1000
G1 X172.966 Y93.561 Z-2.919 F1000
G1 X172.91 Y93.578 Z-2.877 F1000
G1 X172.859 Y93.594 Z-2.83 F1000
G1 X172.814 Y93.608 Z-2.777 F1000
G1 X172.775 Y93.62 Z-2.719 F1000
G1 X172.742 Y93.63 Z-2.657 F1000
G1 X172.716 Y93.638 Z-2.591 F1000
G1 X172.697 Y93.644 Z-2.522 F1000
G1 X172.685 Y93.647 Z-2.452 F1000
G1 X172.682 Y93.649 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y100.418 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y100.415 Z-2.452 F1000
G1 X22.509 Y100.405 Z-2.522 F1000
G1 X22.499 Y100.388 Z-2.591 F1000
G1 X22.485 Y100.364 Z-2.657 F1000
G1 X22.467 Y100.335 Z-2.719 F1000
G1 X22.446 Y100.299 Z-2.777 F1000
G1 X22.422 Y100.259 Z-2.83 F1000
G1 X22.395 Y100.213 Z-2.877 F1000
G1 X22.365 Y100.163 Z-2.919 F1000
G1 X22.333 Y100.109 Z-2.953 F1000
G1 X22.3 Y100.053 Z-2.98 F1000
G1 X22.265 Y99.994 Z-3 F1000
G1 X22.229 Y99.934 Z-3.012 F1000
G1 X22.192 Y99.873 Z-3.016 F1000
G3 X21.971 Y99.119 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y96.613 F1000
G1 X21.981 Y96.417 F1000
G1 X22.013 Y96.174 F1000
G1 X22.074 Y95.886 F1000
G1 X22.166 Y95.579 F1000
G1 X22.296 Y95.245 F1000
G1 X22.482 Y94.862 F1000
G1 X22.708 Y94.478 F1000
G1 X23.018 Y94.037 F1000
G1 X23.395 Y93.583 F1000
G1 X23.877 Y93.088 F1000
G1 X24.493 Y92.552 F1000
G1 X25.232 Y92.005 F1000
G1 X26.01 Y91.516 F1000
G1 X26.817 Y91.076 F1000
G1 X27.646 Y90.679 F1000
G1 X28.491 Y90.319 F1000
G1 X29.349 Y89.99 F1000
G1 X30.218 Y89.689 F1000
G1 X31.094 Y89.413 F1000
G1 X31.977 Y89.159 F1000
G1 X32.866 Y88.923 F1000
G1 X33.758 Y88.705 F1000
G1 X34.655 Y88.502 F1000
G1 X35.554 Y88.312 F1000
G1 X36.456 Y88.135 F1000
G1 X37.36 Y87.97 F1000
G1 X38.265 Y87.814 F1000
G1 X39.173 Y87.668 F1000
G1 X40.081 Y87.53 F1000
G1 X40.991 Y87.4 F1000
G1 X41.902 Y87.277 F1000
G1 X42.814 Y87.161 F1000
G1 X43.726 Y87.051 F1000
G1 X44.639 Y86.946 F1000
G1 X45.553 Y86.847 F1000
G1 X46.467 Y86.753 F1000
G1 X47.381 Y86.663 F1000
G1 X48.297 Y86.578 F1000
G1 X49.212 Y86.496 F1000
G1 X50.128 Y86.418 F1000
G1 X51.044 Y86.343 F1000
G1 X51.96 Y86.271 F1000
G1 X52.876 Y86.202 F1000
G1 X53.793 Y86.136 F1000
G1 X54.71 Y86.072 F1000
G1 X55.627 Y86.011 F1000
G1 X56.544 Y85.951 F1000
G1 X57.461 Y85.893 F1000
G1 X58.378 Y85.837 F1000
G1 X59.296 Y85.783 F1000
G1 X60.213 Y85.73 F1000
G1 X61.131 Y85.678 F1000
G1 X62.048 Y85.628 F1000
G1 X63.884 Y85.53 F1000
G1 X65.719 Y85.435 F1000
G1 X67.555 Y85.343 F1000
G1 X69.391 Y85.253 F1000
G1 X72.145 Y85.121 F1000
G1 X75.817 Y84.948 F1000
G1 X80.407 Y84.736 F1000
G1 X84.079 Y84.57 F1000
G1 X87.752 Y84.406 F1000
G1 X90.506 Y84.287 F1000
G1 X93.261 Y84.17 F1000
G1 X96.016 Y84.058 F1000
G1 X97.852 Y83.985 F1000
G1 X99.689 Y83.915 F1000
G1 X101.526 Y83.848 F1000
G1 X103.363 Y83.783 F1000
G1 X105.2 Y83.72 F1000
G1 X107.037 Y83.661 F1000
G1 X108.874 Y83.605 F1000
G1 X110.711 Y83.552 F1000
G1 X112.549 Y83.502 F1000
G1 X114.386 Y83.456 F1000
G1 X116.224 Y83.413 F1000
G1 X118.061 Y83.374 F1000
G1 X119.899 Y83.339 F1000
G1 X121.737 Y83.307 F1000
G1 X122.656 Y83.293 F1000
G1 X123.574 Y83.28 F1000
G1 X124.493 Y83.268 F1000
G1 X125.412 Y83.257 F1000
G1 X126.331 Y83.247 F1000
G1 X127.25 Y83.238 F1000
G1 X128.169 Y83.23 F1000
G1 X129.088 Y83.223 F1000
G1 X130.007 Y83.218 F1000
G1 X130.926 Y83.214 F1000
G1 X131.845 Y83.211 F1000
G1 X132.764 Y83.209 F1000
G1 X133.683 F1000
G1 X134.602 Y83.21 F1000
G1 X135.521 Y83.213 F1000
G1 X136.44 Y83.217 F1000
G1 X137.359 Y83.222 F1000
G1 X138.278 Y83.229 F1000
G1 X139.197 Y83.238 F1000
G1 X140.116 Y83.249 F1000
G1 X141.035 Y83.261 F1000
G1 X141.954 Y83.275 F1000
G1 X142.873 Y83.291 F1000
G1 X143.792 Y83.309 F1000
G1 X144.711 Y83.329 F1000
G1 X145.629 Y83.351 F1000
G1 X146.548 Y83.376 F1000
G1 X147.467 Y83.403 F1000
G1 X148.385 Y83.432 F1000
G1 X149.304 Y83.464 F1000
G1 X150.222 Y83.499 F1000
G1 X151.14 Y83.536 F1000
G1 X152.059 Y83.577 F1000
G1 X152.976 Y83.621 F1000
G1 X153.894 Y83.668 F1000
G1 X154.812 Y83.719 F1000
G1 X155.729 Y83.774 F1000
G1 X156.646 Y83.833 F1000
G1 X157.563 Y83.896 F1000
G1 X158.48 Y83.964 F1000
G1 X159.396 Y84.037 F1000
G1 X160.312 Y84.115 F1000
G1 X161.227 Y84.2 F1000
G1 X162.141 Y84.291 F1000
G1 X163.055 Y84.389 F1000
G1 X163.968 Y84.496 F1000
G1 X164.88 Y84.611 F1000
G1 X165.79 Y84.737 F1000
G1 X166.699 Y84.874 F1000
G1 X167.605 Y85.025 F1000
G1 X168.509 Y85.192 F1000
G1 X169.409 Y85.378 F1000
G1 X170.304 Y85.587 F1000
G1 X171.191 Y85.827 F1000
G1 X172.062 Y86.112 F1000
G1 X172.626 Y86.347 F1000
G1 X172.933 Y86.506 F1000
G1 X173.203 Y86.685 F1000
G1 X173.428 Y86.918 F1000
G1 X173.596 Y87.194 F1000
G1 X173.701 Y87.501 F1000
G1 X173.736 Y87.823 F1000
G1 Y90.35 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y90.935 I-0.635 J-0.022 F1000
G1 X173.221 Y90.955 Z-3.012 F1000
G1 X173.153 Y90.976 Z-3 F1000
G1 X173.088 Y90.996 Z-2.98 F1000
G1 X173.025 Y91.016 Z-2.953 F1000
G1 X172.966 Y91.034 Z-2.919 F1000
G1 X172.91 Y91.051 Z-2.877 F1000
G1 X172.859 Y91.067 Z-2.83 F1000
G1 X172.814 Y91.081 Z-2.777 F1000
G1 X172.775 Y91.093 Z-2.719 F1000
G1 X172.742 Y91.103 Z-2.657 F1000
G1 X172.716 Y91.111 Z-2.591 F1000
G1 X172.697 Y91.117 Z-2.522 F1000
G1 X172.685 Y91.12 Z-2.452 F1000
G1 X172.682 Y91.122 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y97.912 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y97.909 Z-2.452 F1000
G1 X22.509 Y97.899 Z-2.522 F1000
G1 X22.499 Y97.882 Z-2.591 F1000
G1 X22.485 Y97.858 Z-2.657 F1000
G1 X22.467 Y97.829 Z-2.719 F1000
G1 X22.446 Y97.793 Z-2.777 F1000
G1 X22.422 Y97.752 Z-2.83 F1000
G1 X22.395 Y97.707 Z-2.877 F1000
G1 X22.365 Y97.657 Z-2.919 F1000
G1 X22.333 Y97.603 Z-2.953 F1000
G1 X22.3 Y97.547 Z-2.98 F1000
G1 X22.265 Y97.488 Z-3 F1000
G1 X22.229 Y97.428 Z-3.012 F1000
G1 X22.192 Y97.367 Z-3.016 F1000
G3 X21.971 Y96.613 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y94.107 F1000
G1 X21.982 Y93.893 F1000
G1 X22.014 Y93.65 F1000
G1 X22.075 Y93.361 F1000
G1 X22.167 Y93.054 F1000
G1 X22.297 Y92.72 F1000
G1 X22.483 Y92.338 F1000
G1 X22.709 Y91.953 F1000
G1 X23.019 Y91.513 F1000
G1 X23.396 Y91.058 F1000
G1 X23.878 Y90.564 F1000
G1 X24.494 Y90.027 F1000
G1 X25.233 Y89.48 F1000
G1 X26.011 Y88.991 F1000
G1 X26.818 Y88.552 F1000
G1 X27.647 Y88.154 F1000
G1 X28.492 Y87.794 F1000
G1 X29.35 Y87.465 F1000
G1 X30.219 Y87.164 F1000
G1 X31.095 Y86.888 F1000
G1 X31.978 Y86.633 F1000
G1 X32.866 Y86.398 F1000
G1 X33.759 Y86.179 F1000
G1 X34.655 Y85.976 F1000
G1 X35.555 Y85.786 F1000
G1 X36.456 Y85.609 F1000
G1 X37.36 Y85.442 F1000
G1 X38.266 Y85.286 F1000
G1 X39.173 Y85.14 F1000
G1 X40.082 Y85.002 F1000
G1 X40.991 Y84.871 F1000
G1 X41.902 Y84.748 F1000
G1 X42.814 Y84.631 F1000
G1 X43.726 Y84.521 F1000
G1 X44.639 Y84.416 F1000
G1 X45.553 Y84.317 F1000
G1 X46.467 Y84.222 F1000
G1 X47.381 Y84.132 F1000
G1 X48.296 Y84.046 F1000
G1 X49.212 Y83.964 F1000
G1 X50.127 Y83.885 F1000
G1 X51.043 Y83.81 F1000
G1 X51.96 Y83.738 F1000
G1 X52.876 Y83.668 F1000
G1 X53.793 Y83.601 F1000
G1 X54.709 Y83.537 F1000
G1 X55.626 Y83.475 F1000
G1 X56.543 Y83.415 F1000
G1 X57.46 Y83.357 F1000
G1 X58.378 Y83.301 F1000
G1 X59.295 Y83.246 F1000
G1 X60.213 Y83.192 F1000
G1 X61.13 Y83.14 F1000
G1 X62.048 Y83.089 F1000
G1 X63.883 Y82.991 F1000
G1 X65.719 Y82.895 F1000
G1 X67.554 Y82.803 F1000
G1 X69.39 Y82.712 F1000
G1 X72.144 Y82.58 F1000
G1 X75.816 Y82.407 F1000
G1 X80.406 Y82.194 F1000
G1 X84.079 Y82.028 F1000
G1 X86.833 Y81.905 F1000
G1 X89.587 Y81.785 F1000
G1 X92.342 Y81.668 F1000
G1 X95.097 Y81.555 F1000
G1 X96.933 Y81.481 F1000
G1 X98.77 Y81.411 F1000
G1 X100.607 Y81.342 F1000
G1 X102.444 Y81.276 F1000
G1 X104.28 Y81.213 F1000
G1 X106.118 Y81.152 F1000
G1 X107.955 Y81.095 F1000
G1 X109.792 Y81.04 F1000
G1 X111.629 Y80.989 F1000
G1 X113.467 Y80.941 F1000
G1 X115.304 Y80.897 F1000
G1 X117.142 Y80.856 F1000
G1 X118.979 Y80.819 F1000
G1 X119.898 Y80.802 F1000
G1 X121.736 Y80.771 F1000
G1 X122.655 Y80.757 F1000
G1 X123.574 Y80.744 F1000
G1 X124.493 Y80.732 F1000
G1 X125.412 Y80.721 F1000
G1 X126.331 Y80.711 F1000
G1 X127.25 Y80.702 F1000
G1 X128.169 Y80.695 F1000
G1 X129.088 Y80.688 F1000
G1 X130.007 Y80.683 F1000
G1 X130.926 Y80.679 F1000
G1 X131.845 Y80.676 F1000
G1 X132.764 Y80.675 F1000
G1 X133.683 F1000
G1 X134.602 Y80.676 F1000
G1 X135.521 Y80.679 F1000
G1 X136.44 Y80.683 F1000
G1 X137.359 Y80.688 F1000
G1 X138.278 Y80.696 F1000
G1 X139.197 Y80.705 F1000
G1 X140.116 Y80.715 F1000
G1 X141.035 Y80.728 F1000
G1 X141.954 Y80.742 F1000
G1 X142.872 Y80.758 F1000
G1 X143.791 Y80.776 F1000
G1 X144.71 Y80.797 F1000
G1 X145.629 Y80.819 F1000
G1 X146.548 Y80.844 F1000
G1 X147.466 Y80.871 F1000
G1 X148.385 Y80.901 F1000
G1 X149.303 Y80.933 F1000
G1 X150.222 Y80.968 F1000
G1 X151.14 Y81.006 F1000
G1 X152.058 Y81.046 F1000
G1 X152.976 Y81.091 F1000
G1 X153.894 Y81.138 F1000
G1 X154.811 Y81.189 F1000
G1 X155.729 Y81.244 F1000
G1 X156.646 Y81.303 F1000
G1 X157.563 Y81.367 F1000
G1 X158.479 Y81.435 F1000
G1 X159.395 Y81.508 F1000
G1 X160.311 Y81.587 F1000
G1 X161.226 Y81.671 F1000
G1 X162.14 Y81.762 F1000
G1 X163.054 Y81.861 F1000
G1 X163.967 Y81.967 F1000
G1 X164.879 Y82.083 F1000
G1 X165.789 Y82.209 F1000
G1 X166.698 Y82.346 F1000
G1 X167.604 Y82.497 F1000
G1 X168.508 Y82.664 F1000
G1 X169.408 Y82.85 F1000
G1 X170.303 Y83.06 F1000
G1 X171.19 Y83.3 F1000
G1 X172.061 Y83.584 F1000
G1 X172.626 Y83.82 F1000
G1 X172.933 Y83.979 F1000
G1 X173.203 Y84.158 F1000
G1 X173.428 Y84.391 F1000
G1 X173.596 Y84.667 F1000
G1 X173.701 Y84.974 F1000
G1 X173.736 Y85.296 F1000
G1 Y87.823 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y88.407 I-0.635 J-0.022 F1000
G1 X173.221 Y88.428 Z-3.012 F1000
G1 X173.153 Y88.449 Z-3 F1000
G1 X173.088 Y88.469 Z-2.98 F1000
G1 X173.025 Y88.489 Z-2.953 F1000
G1 X172.966 Y88.507 Z-2.919 F1000
G1 X172.91 Y88.524 Z-2.877 F1000
G1 X172.859 Y88.54 Z-2.83 F1000
G1 X172.814 Y88.554 Z-2.777 F1000
G1 X172.775 Y88.566 Z-2.719 F1000
G1 X172.742 Y88.576 Z-2.657 F1000
G1 X172.716 Y88.584 Z-2.591 F1000
G1 X172.697 Y88.59 Z-2.522 F1000
G1 X172.685 Y88.593 Z-2.452 F1000
G1 X172.682 Y88.594 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y95.406 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y95.403 Z-2.452 F1000
G1 X22.509 Y95.393 Z-2.522 F1000
G1 X22.499 Y95.376 Z-2.591 F1000
G1 X22.485 Y95.352 Z-2.657 F1000
G1 X22.467 Y95.323 Z-2.719 F1000
G1 X22.446 Y95.287 Z-2.777 F1000
G1 X22.422 Y95.246 Z-2.83 F1000
G1 X22.395 Y95.201 Z-2.877 F1000
G1 X22.365 Y95.151 Z-2.919 F1000
G1 X22.333 Y95.097 Z-2.953 F1000
G1 X22.3 Y95.041 Z-2.98 F1000
G1 X22.265 Y94.982 Z-3 F1000
G1 X22.229 Y94.922 Z-3.012 F1000
G1 X22.192 Y94.861 Z-3.016 F1000
G3 X21.971 Y94.107 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y91.601 F1000
G1 X21.983 Y91.368 F1000
G1 X22.014 Y91.126 F1000
G1 X22.076 Y90.837 F1000
G1 X22.168 Y90.53 F1000
G1 X22.298 Y90.196 F1000
G1 X22.484 Y89.813 F1000
G1 X22.71 Y89.429 F1000
G1 X23.02 Y88.988 F1000
G1 X23.397 Y88.534 F1000
G1 X23.88 Y88.039 F1000
G1 X24.495 Y87.502 F1000
G1 X25.234 Y86.955 F1000
G1 X26.012 Y86.466 F1000
G1 X26.819 Y86.026 F1000
G1 X27.648 Y85.629 F1000
G1 X28.493 Y85.269 F1000
G1 X29.351 Y84.94 F1000
G1 X30.22 Y84.639 F1000
G1 X31.096 Y84.362 F1000
G1 X31.979 Y84.107 F1000
G1 X32.867 Y83.871 F1000
G1 X33.76 Y83.653 F1000
G1 X34.656 Y83.449 F1000
G1 X35.555 Y83.259 F1000
G1 X36.457 Y83.081 F1000
G1 X37.361 Y82.915 F1000
G1 X38.266 Y82.759 F1000
G1 X39.174 Y82.612 F1000
G1 X40.082 Y82.473 F1000
G1 X40.992 Y82.342 F1000
G1 X41.903 Y82.219 F1000
G1 X42.814 Y82.102 F1000
G1 X43.726 Y81.991 F1000
G1 X44.639 Y81.886 F1000
G1 X45.553 Y81.786 F1000
G1 X46.467 Y81.691 F1000
G1 X47.382 Y81.6 F1000
G1 X48.297 Y81.514 F1000
G1 X49.212 Y81.431 F1000
G1 X50.127 Y81.352 F1000
G1 X51.043 Y81.276 F1000
G1 X51.959 Y81.204 F1000
G1 X52.876 Y81.134 F1000
G1 X53.792 Y81.067 F1000
G1 X54.709 Y81.002 F1000
G1 X55.626 Y80.94 F1000
G1 X56.543 Y80.879 F1000
G1 X57.46 Y80.821 F1000
G1 X58.377 Y80.764 F1000
G1 X59.295 Y80.708 F1000
G1 X60.212 Y80.655 F1000
G1 X61.13 Y80.602 F1000
G1 X62.047 Y80.551 F1000
G1 X63.883 Y80.451 F1000
G1 X65.718 Y80.356 F1000
G1 X67.554 Y80.262 F1000
G1 X69.39 Y80.172 F1000
G1 X72.144 Y80.038 F1000
G1 X75.816 Y79.865 F1000
G1 X79.488 Y79.695 F1000
G1 X83.16 Y79.527 F1000
G1 X86.832 Y79.364 F1000
G1 X89.587 Y79.244 F1000
G1 X92.341 Y79.127 F1000
G1 X95.096 Y79.014 F1000
G1 X96.933 Y78.942 F1000
G1 X98.77 Y78.871 F1000
G1 X100.606 Y78.803 F1000
G1 X102.443 Y78.737 F1000
G1 X104.28 Y78.674 F1000
G1 X106.117 Y78.614 F1000
G1 X107.954 Y78.557 F1000
G1 X109.792 Y78.502 F1000
G1 X111.629 Y78.452 F1000
G1 X113.466 Y78.404 F1000
G1 X115.304 Y78.36 F1000
G1 X117.141 Y78.32 F1000
G1 X118.979 Y78.283 F1000
G1 X119.898 Y78.266 F1000
G1 X121.736 Y78.235 F1000
G1 X122.655 Y78.221 F1000
G1 X123.574 Y78.208 F1000
G1 X124.493 Y78.196 F1000
G1 X125.411 Y78.185 F1000
G1 X126.33 Y78.175 F1000
G1 X127.249 Y78.167 F1000
G1 X128.168 Y78.159 F1000
G1 X129.087 Y78.153 F1000
G1 X130.006 Y78.148 F1000
G1 X130.925 Y78.144 F1000
G1 X131.844 Y78.141 F1000
G1 X132.763 Y78.14 F1000
G1 X133.682 F1000
G1 X134.602 Y78.141 F1000
G1 X135.521 Y78.144 F1000
G1 X136.44 Y78.149 F1000
G1 X137.359 Y78.155 F1000
G1 X138.278 Y78.162 F1000
G1 X139.197 Y78.171 F1000
G1 X140.115 Y78.182 F1000
G1 X141.034 Y78.195 F1000
G1 X141.953 Y78.209 F1000
G1 X142.872 Y78.226 F1000
G1 X143.791 Y78.244 F1000
G1 X144.71 Y78.264 F1000
G1 X145.629 Y78.287 F1000
G1 X146.547 Y78.312 F1000
G1 X147.466 Y78.339 F1000
G1 X148.384 Y78.369 F1000
G1 X149.303 Y78.401 F1000
G1 X150.221 Y78.437 F1000
G1 X151.139 Y78.475 F1000
G1 X152.057 Y78.516 F1000
G1 X152.975 Y78.56 F1000
G1 X153.893 Y78.608 F1000
G1 X154.811 Y78.659 F1000
G1 X155.728 Y78.714 F1000
G1 X156.645 Y78.774 F1000
G1 X157.562 Y78.837 F1000
G1 X158.479 Y78.905 F1000
G1 X159.395 Y78.979 F1000
G1 X160.31 Y79.058 F1000
G1 X161.225 Y79.142 F1000
G1 X162.14 Y79.234 F1000
G1 X163.054 Y79.332 F1000
G1 X163.966 Y79.439 F1000
G1 X164.878 Y79.555 F1000
G1 X165.788 Y79.681 F1000
G1 X166.697 Y79.819 F1000
G1 X167.604 Y79.97 F1000
G1 X168.507 Y80.136 F1000
G1 X169.407 Y80.322 F1000
G1 X170.302 Y80.532 F1000
G1 X171.189 Y80.772 F1000
G1 X172.061 Y81.057 F1000
G1 X172.625 Y81.293 F1000
G1 X172.933 Y81.451 F1000
G1 X173.203 Y81.63 F1000
G1 X173.428 Y81.863 F1000
G1 X173.596 Y82.14 F1000
G1 X173.701 Y82.446 F1000
G1 X173.736 Y82.768 F1000
G1 Y85.296 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y85.88 I-0.635 J-0.022 F1000
G1 X173.221 Y85.901 Z-3.012 F1000
G1 X173.153 Y85.922 Z-3 F1000
G1 X173.088 Y85.942 Z-2.98 F1000
G1 X173.025 Y85.961 Z-2.953 F1000
G1 X172.966 Y85.98 Z-2.919 F1000
G1 X172.91 Y85.997 Z-2.877 F1000
G1 X172.859 Y86.012 Z-2.83 F1000
G1 X172.814 Y86.026 Z-2.777 F1000
G1 X172.775 Y86.039 Z-2.719 F1000
G1 X172.742 Y86.049 Z-2.657 F1000
G1 X172.716 Y86.057 Z-2.591 F1000
G1 X172.697 Y86.063 Z-2.522 F1000
G1 X172.685 Y86.066 Z-2.452 F1000
G1 X172.682 Y86.067 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y92.9 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y92.897 Z-2.452 F1000
G1 X22.509 Y92.887 Z-2.522 F1000
G1 X22.499 Y92.87 Z-2.591 F1000
G1 X22.485 Y92.846 Z-2.657 F1000
G1 X22.467 Y92.817 Z-2.719 F1000
G1 X22.446 Y92.781 Z-2.777 F1000
G1 X22.422 Y92.74 Z-2.83 F1000
G1 X22.395 Y92.695 Z-2.877 F1000
G1 X22.365 Y92.645 Z-2.919 F1000
G1 X22.333 Y92.591 Z-2.953 F1000
G1 X22.3 Y92.535 Z-2.98 F1000
G1 X22.265 Y92.476 Z-3 F1000
G1 X22.229 Y92.416 Z-3.012 F1000
G1 X22.192 Y92.355 Z-3.016 F1000
G3 X21.971 Y91.601 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y89.095 F1000
G1 X21.984 Y88.844 F1000
G1 X22.015 Y88.601 F1000
G1 X22.077 Y88.312 F1000
G1 X22.169 Y88.005 F1000
G1 X22.299 Y87.671 F1000
G1 X22.485 Y87.288 F1000
G1 X22.711 Y86.904 F1000
G1 X23.021 Y86.464 F1000
G1 X23.398 Y86.009 F1000
G1 X23.881 Y85.514 F1000
G1 X24.497 Y84.977 F1000
G1 X25.236 Y84.43 F1000
G1 X26.014 Y83.941 F1000
G1 X26.821 Y83.501 F1000
G1 X27.649 Y83.104 F1000
G1 X28.495 Y82.743 F1000
G1 X29.353 Y82.414 F1000
G1 X30.221 Y82.113 F1000
G1 X31.097 Y81.836 F1000
G1 X31.98 Y81.581 F1000
G1 X32.868 Y81.345 F1000
G1 X33.761 Y81.126 F1000
G1 X34.657 Y80.922 F1000
G1 X35.556 Y80.732 F1000
G1 X36.458 Y80.554 F1000
G1 X37.362 Y80.387 F1000
G1 X38.267 Y80.231 F1000
G1 X39.174 Y80.083 F1000
G1 X40.083 Y79.945 F1000
G1 X40.992 Y79.813 F1000
G1 X41.903 Y79.69 F1000
G1 X42.815 Y79.572 F1000
G1 X43.727 Y79.461 F1000
G1 X44.64 Y79.355 F1000
G1 X45.553 Y79.255 F1000
G1 X46.467 Y79.16 F1000
G1 X47.382 Y79.068 F1000
G1 X48.297 Y78.982 F1000
G1 X49.212 Y78.899 F1000
G1 X50.128 Y78.819 F1000
G1 X51.043 Y78.743 F1000
G1 X51.96 Y78.67 F1000
G1 X52.876 Y78.6 F1000
G1 X53.792 Y78.532 F1000
G1 X54.709 Y78.467 F1000
G1 X55.626 Y78.404 F1000
G1 X56.543 Y78.343 F1000
G1 X57.46 Y78.284 F1000
G1 X58.377 Y78.227 F1000
G1 X59.295 Y78.171 F1000
G1 X60.212 Y78.117 F1000
G1 X61.13 Y78.064 F1000
G1 X62.047 Y78.013 F1000
G1 X63.882 Y77.912 F1000
G1 X65.718 Y77.816 F1000
G1 X67.554 Y77.722 F1000
G1 X68.472 Y77.676 F1000
G1 X71.225 Y77.541 F1000
G1 X73.979 Y77.41 F1000
G1 X77.651 Y77.238 F1000
G1 X81.323 Y77.069 F1000
G1 X84.996 Y76.904 F1000
G1 X87.75 Y76.782 F1000
G1 X90.505 Y76.664 F1000
G1 X93.259 Y76.549 F1000
G1 X96.014 Y76.438 F1000
G1 X97.851 Y76.366 F1000
G1 X99.688 Y76.297 F1000
G1 X101.524 Y76.231 F1000
G1 X103.361 Y76.166 F1000
G1 X105.198 Y76.105 F1000
G1 X107.035 Y76.047 F1000
G1 X108.873 Y75.991 F1000
G1 X110.71 Y75.939 F1000
G1 X112.547 Y75.89 F1000
G1 X114.385 Y75.844 F1000
G1 X116.222 Y75.802 F1000
G1 X118.06 Y75.764 F1000
G1 X118.979 Y75.746 F1000
G1 X120.817 Y75.713 F1000
G1 X122.654 Y75.685 F1000
G1 X123.573 Y75.672 F1000
G1 X124.492 Y75.66 F1000
G1 X125.411 Y75.649 F1000
G1 X126.33 Y75.64 F1000
G1 X127.249 Y75.631 F1000
G1 X128.168 Y75.624 F1000
G1 X129.087 Y75.618 F1000
G1 X130.006 Y75.613 F1000
G1 X130.925 Y75.609 F1000
G1 X131.844 Y75.606 F1000
G1 X132.763 Y75.605 F1000
G1 X133.682 F1000
G1 X134.601 Y75.607 F1000
G1 X135.52 Y75.61 F1000
G1 X136.439 Y75.615 F1000
G1 X137.358 Y75.621 F1000
G1 X138.277 Y75.628 F1000
G1 X139.196 Y75.638 F1000
G1 X140.115 Y75.649 F1000
G1 X141.034 Y75.662 F1000
G1 X141.953 Y75.676 F1000
G1 X142.872 Y75.693 F1000
G1 X143.791 Y75.711 F1000
G1 X144.71 Y75.732 F1000
G1 X145.628 Y75.755 F1000
G1 X146.547 Y75.78 F1000
G1 X147.466 Y75.808 F1000
G1 X148.384 Y75.838 F1000
G1 X149.303 Y75.87 F1000
G1 X150.221 Y75.906 F1000
G1 X151.139 Y75.944 F1000
G1 X152.057 Y75.985 F1000
G1 X152.975 Y76.03 F1000
G1 X153.893 Y76.078 F1000
G1 X154.811 Y76.129 F1000
G1 X155.728 Y76.184 F1000
G1 X156.645 Y76.244 F1000
G1 X157.562 Y76.308 F1000
G1 X158.478 Y76.376 F1000
G1 X159.394 Y76.45 F1000
G1 X160.31 Y76.529 F1000
G1 X161.225 Y76.614 F1000
G1 X162.139 Y76.705 F1000
G1 X163.053 Y76.804 F1000
G1 X163.966 Y76.911 F1000
G1 X164.878 Y77.027 F1000
G1 X165.788 Y77.153 F1000
G1 X166.697 Y77.291 F1000
G1 X167.603 Y77.442 F1000
G1 X168.507 Y77.609 F1000
G1 X169.407 Y77.795 F1000
G1 X170.302 Y78.004 F1000
G1 X171.189 Y78.245 F1000
G1 X172.061 Y78.529 F1000
G1 X172.625 Y78.765 F1000
G1 X172.933 Y78.924 F1000
G1 X173.203 Y79.103 F1000
G1 X173.428 Y79.336 F1000
G1 X173.596 Y79.613 F1000
G1 X173.701 Y79.919 F1000
G1 X173.736 Y80.241 F1000
G1 Y82.768 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y83.353 I-0.635 J-0.022 F1000
G1 X173.221 Y83.374 Z-3.012 F1000
G1 X173.153 Y83.394 Z-3 F1000
G1 X173.088 Y83.415 Z-2.98 F1000
G1 X173.025 Y83.434 Z-2.953 F1000
G1 X172.966 Y83.452 Z-2.919 F1000
G1 X172.91 Y83.47 Z-2.877 F1000
G1 X172.859 Y83.485 Z-2.83 F1000
G1 X172.814 Y83.499 Z-2.777 F1000
G1 X172.775 Y83.511 Z-2.719 F1000
G1 X172.742 Y83.521 Z-2.657 F1000
G1 X172.716 Y83.529 Z-2.591 F1000
G1 X172.697 Y83.535 Z-2.522 F1000
G1 X172.685 Y83.539 Z-2.452 F1000
G1 X172.682 Y83.54 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y90.394 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y90.391 Z-2.452 F1000
G1 X22.509 Y90.381 Z-2.522 F1000
G1 X22.499 Y90.364 Z-2.591 F1000
G1 X22.485 Y90.34 Z-2.657 F1000
G1 X22.467 Y90.311 Z-2.719 F1000
G1 X22.446 Y90.275 Z-2.777 F1000
G1 X22.422 Y90.234 Z-2.83 F1000
G1 X22.395 Y90.189 Z-2.877 F1000
G1 X22.365 Y90.139 Z-2.919 F1000
G1 X22.333 Y90.085 Z-2.953 F1000
G1 X22.3 Y90.029 Z-2.98 F1000
G1 X22.265 Y89.97 Z-3 F1000
G1 X22.229 Y89.91 Z-3.012 F1000
G1 X22.192 Y89.848 Z-3.016 F1000
G3 X21.971 Y89.095 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y86.589 F1000
G1 X21.985 Y86.319 F1000
G1 X22.016 Y86.076 F1000
G1 X22.078 Y85.787 F1000
G1 X22.17 Y85.48 F1000
G1 X22.3 Y85.146 F1000
G1 X22.486 Y84.763 F1000
G1 X22.712 Y84.379 F1000
G1 X23.022 Y83.938 F1000
G1 X23.399 Y83.484 F1000
G1 X23.882 Y82.989 F1000
G1 X24.498 Y82.451 F1000
G1 X25.237 Y81.905 F1000
G1 X26.015 Y81.415 F1000
G1 X26.822 Y80.976 F1000
G1 X27.651 Y80.578 F1000
G1 X28.496 Y80.217 F1000
G1 X29.354 Y79.888 F1000
G1 X30.222 Y79.587 F1000
G1 X31.099 Y79.31 F1000
G1 X31.981 Y79.055 F1000
G1 X32.87 Y78.819 F1000
G1 X33.762 Y78.599 F1000
G1 X34.658 Y78.395 F1000
G1 X35.557 Y78.205 F1000
G1 X36.459 Y78.027 F1000
G1 X37.362 Y77.859 F1000
G1 X38.268 Y77.703 F1000
G1 X39.175 Y77.555 F1000
G1 X40.083 Y77.416 F1000
G1 X40.993 Y77.284 F1000
G1 X41.904 Y77.16 F1000
G1 X42.815 Y77.042 F1000
G1 X43.727 Y76.931 F1000
G1 X44.64 Y76.825 F1000
G1 X45.554 Y76.724 F1000
G1 X46.468 Y76.628 F1000
G1 X47.382 Y76.537 F1000
G1 X48.297 Y76.449 F1000
G1 X49.212 Y76.366 F1000
G1 X50.128 Y76.286 F1000
G1 X51.044 Y76.209 F1000
G1 X51.96 Y76.136 F1000
G1 X52.876 Y76.065 F1000
G1 X53.792 Y75.997 F1000
G1 X54.709 Y75.932 F1000
G1 X55.626 Y75.868 F1000
G1 X56.543 Y75.807 F1000
G1 X57.46 Y75.748 F1000
G1 X58.377 Y75.69 F1000
G1 X59.295 Y75.634 F1000
G1 X60.212 Y75.579 F1000
G1 X61.129 Y75.526 F1000
G1 X62.047 Y75.474 F1000
G1 X63.882 Y75.373 F1000
G1 X65.718 Y75.276 F1000
G1 X67.553 Y75.182 F1000
G1 X68.471 Y75.136 F1000
G1 X71.225 Y75 F1000
G1 X73.979 Y74.868 F1000
G1 X77.651 Y74.696 F1000
G1 X81.323 Y74.527 F1000
G1 X84.995 Y74.362 F1000
G1 X87.75 Y74.241 F1000
G1 X90.504 Y74.123 F1000
G1 X93.259 Y74.008 F1000
G1 X96.014 Y73.898 F1000
G1 X97.851 Y73.827 F1000
G1 X99.687 Y73.758 F1000
G1 X101.524 Y73.691 F1000
G1 X103.361 Y73.628 F1000
G1 X105.198 Y73.567 F1000
G1 X107.035 Y73.508 F1000
G1 X108.872 Y73.453 F1000
G1 X110.71 Y73.401 F1000
G1 X112.547 Y73.353 F1000
G1 X114.385 Y73.307 F1000
G1 X116.222 Y73.265 F1000
G1 X118.06 Y73.227 F1000
G1 X118.979 Y73.21 F1000
G1 X120.816 Y73.177 F1000
G1 X122.654 Y73.149 F1000
G1 X123.573 Y73.136 F1000
G1 X124.492 Y73.124 F1000
G1 X125.411 Y73.114 F1000
G1 X126.33 Y73.104 F1000
G1 X127.249 Y73.096 F1000
G1 X128.168 Y73.088 F1000
G1 X129.087 Y73.082 F1000
G1 X130.006 Y73.077 F1000
G1 X130.925 Y73.074 F1000
G1 X131.844 Y73.072 F1000
G1 X132.763 Y73.071 F1000
G1 X133.682 F1000
G1 X134.601 Y73.073 F1000
G1 X135.52 Y73.076 F1000
G1 X136.439 Y73.081 F1000
G1 X137.358 Y73.087 F1000
G1 X138.277 Y73.095 F1000
G1 X139.196 Y73.104 F1000
G1 X140.115 Y73.115 F1000
G1 X141.034 Y73.128 F1000
G1 X141.953 Y73.143 F1000
G1 X142.872 Y73.16 F1000
G1 X143.791 Y73.179 F1000
G1 X144.709 Y73.2 F1000
G1 X145.628 Y73.223 F1000
G1 X146.547 Y73.248 F1000
G1 X147.465 Y73.276 F1000
G1 X148.384 Y73.306 F1000
G1 X149.302 Y73.339 F1000
G1 X150.221 Y73.374 F1000
G1 X151.139 Y73.413 F1000
G1 X152.057 Y73.454 F1000
G1 X152.975 Y73.499 F1000
G1 X153.893 Y73.547 F1000
G1 X154.81 Y73.599 F1000
G1 X155.728 Y73.654 F1000
G1 X156.645 Y73.714 F1000
G1 X157.561 Y73.778 F1000
G1 X158.478 Y73.847 F1000
G1 X159.394 Y73.92 F1000
G1 X160.31 Y74 F1000
G1 X161.225 Y74.085 F1000
G1 X162.139 Y74.176 F1000
G1 X163.053 Y74.275 F1000
G1 X163.966 Y74.382 F1000
G1 X164.877 Y74.498 F1000
G1 X165.788 Y74.625 F1000
G1 X166.696 Y74.762 F1000
G1 X167.603 Y74.914 F1000
G1 X168.506 Y75.081 F1000
G1 X169.406 Y75.267 F1000
G1 X170.301 Y75.477 F1000
G1 X171.188 Y75.717 F1000
G1 X172.061 Y76.002 F1000
G1 X172.625 Y76.237 F1000
G1 X172.933 Y76.396 F1000
G1 X173.203 Y76.575 F1000
G1 X173.428 Y76.809 F1000
G1 X173.596 Y77.085 F1000
G1 X173.701 Y77.391 F1000
G1 X173.736 Y77.713 F1000
G1 Y80.241 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y80.825 I-0.635 J-0.022 F1000
G1 X173.221 Y80.846 Z-3.012 F1000
G1 X173.153 Y80.867 Z-3 F1000
G1 X173.088 Y80.887 Z-2.98 F1000
G1 X173.025 Y80.907 Z-2.953 F1000
G1 X172.966 Y80.925 Z-2.919 F1000
G1 X172.91 Y80.942 Z-2.877 F1000
G1 X172.859 Y80.958 Z-2.83 F1000
G1 X172.814 Y80.972 Z-2.777 F1000
G1 X172.775 Y80.984 Z-2.719 F1000
G1 X172.742 Y80.994 Z-2.657 F1000
G1 X172.716 Y81.002 Z-2.591 F1000
G1 X172.697 Y81.008 Z-2.522 F1000
G1 X172.685 Y81.011 Z-2.452 F1000
G1 X172.682 Y81.013 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y87.888 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y87.885 Z-2.452 F1000
G1 X22.509 Y87.875 Z-2.522 F1000
G1 X22.499 Y87.858 Z-2.591 F1000
G1 X22.485 Y87.834 Z-2.657 F1000
G1 X22.467 Y87.805 Z-2.719 F1000
G1 X22.446 Y87.769 Z-2.777 F1000
G1 X22.422 Y87.728 Z-2.83 F1000
G1 X22.395 Y87.683 Z-2.877 F1000
G1 X22.365 Y87.633 Z-2.919 F1000
G1 X22.333 Y87.579 Z-2.953 F1000
G1 X22.3 Y87.523 Z-2.98 F1000
G1 X22.265 Y87.464 Z-3 F1000
G1 X22.229 Y87.404 Z-3.012 F1000
G1 X22.192 Y87.342 Z-3.016 F1000
G3 X21.971 Y86.589 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y84.083 F1000
G1 X21.985 Y83.794 F1000
G1 X22.017 Y83.551 F1000
G1 X22.079 Y83.263 F1000
G1 X22.171 Y82.955 F1000
G1 X22.301 Y82.621 F1000
G1 X22.487 Y82.238 F1000
G1 X22.713 Y81.854 F1000
G1 X23.023 Y81.413 F1000
G1 X23.4 Y80.958 F1000
G1 X23.884 Y80.463 F1000
G1 X24.5 Y79.925 F1000
G1 X25.239 Y79.379 F1000
G1 X26.017 Y78.89 F1000
G1 X26.824 Y78.45 F1000
G1 X27.652 Y78.052 F1000
G1 X28.497 Y77.691 F1000
G1 X29.355 Y77.362 F1000
G1 X30.224 Y77.061 F1000
G1 X31.1 Y76.784 F1000
G1 X31.983 Y76.528 F1000
G1 X32.871 Y76.292 F1000
G1 X33.763 Y76.072 F1000
G1 X34.659 Y75.868 F1000
G1 X35.558 Y75.677 F1000
G1 X36.46 Y75.499 F1000
G1 X37.363 Y75.331 F1000
G1 X38.269 Y75.174 F1000
G1 X39.176 Y75.026 F1000
G1 X40.084 Y74.887 F1000
G1 X40.994 Y74.755 F1000
G1 X41.904 Y74.63 F1000
G1 X42.816 Y74.512 F1000
G1 X43.728 Y74.4 F1000
G1 X44.641 Y74.294 F1000
G1 X45.554 Y74.193 F1000
G1 X46.468 Y74.096 F1000
G1 X47.382 Y74.005 F1000
G1 X48.297 Y73.917 F1000
G1 X49.213 Y73.833 F1000
G1 X50.128 Y73.753 F1000
G1 X51.044 Y73.676 F1000
G1 X51.96 Y73.602 F1000
G1 X52.876 Y73.531 F1000
G1 X53.793 Y73.462 F1000
G1 X54.709 Y73.396 F1000
G1 X55.626 Y73.332 F1000
G1 X56.543 Y73.271 F1000
G1 X57.46 Y73.211 F1000
G1 X58.377 Y73.153 F1000
G1 X59.295 Y73.097 F1000
G1 X60.212 Y73.042 F1000
G1 X61.129 Y72.988 F1000
G1 X62.047 Y72.936 F1000
G1 X62.964 Y72.885 F1000
G1 X64.8 Y72.785 F1000
G1 X66.635 Y72.689 F1000
G1 X68.471 Y72.595 F1000
G1 X71.225 Y72.459 F1000
G1 X73.979 Y72.327 F1000
G1 X76.733 Y72.197 F1000
G1 X80.405 Y72.027 F1000
G1 X84.077 Y71.862 F1000
G1 X86.831 Y71.74 F1000
G1 X89.586 Y71.621 F1000
G1 X92.341 Y71.506 F1000
G1 X95.095 Y71.394 F1000
G1 X96.932 Y71.322 F1000
G1 X98.769 Y71.253 F1000
G1 X100.606 Y71.185 F1000
G1 X102.442 Y71.12 F1000
G1 X104.279 Y71.058 F1000
G1 X106.117 Y70.999 F1000
G1 X107.954 Y70.942 F1000
G1 X109.791 Y70.889 F1000
G1 X111.628 Y70.839 F1000
G1 X113.466 Y70.792 F1000
G1 X115.303 Y70.749 F1000
G1 X117.141 Y70.709 F1000
G1 X118.979 Y70.673 F1000
G1 X120.816 Y70.641 F1000
G1 X122.654 Y70.612 F1000
G1 X123.573 Y70.6 F1000
G1 X124.492 Y70.588 F1000
G1 X125.411 Y70.578 F1000
G1 X126.33 Y70.568 F1000
G1 X127.249 Y70.56 F1000
G1 X128.168 Y70.553 F1000
G1 X129.087 Y70.547 F1000
G1 X130.006 Y70.542 F1000
G1 X130.925 Y70.539 F1000
G1 X131.844 Y70.537 F1000
G1 X132.763 Y70.536 F1000
G1 X133.682 F1000
G1 X134.601 Y70.538 F1000
G1 X135.52 Y70.542 F1000
G1 X136.439 Y70.547 F1000
G1 X137.358 Y70.553 F1000
G1 X138.277 Y70.561 F1000
G1 X139.196 Y70.571 F1000
G1 X140.115 Y70.582 F1000
G1 X141.034 Y70.595 F1000
G1 X141.953 Y70.61 F1000
G1 X142.872 Y70.627 F1000
G1 X143.791 Y70.646 F1000
G1 X144.709 Y70.667 F1000
G1 X145.628 Y70.691 F1000
G1 X146.547 Y70.716 F1000
G1 X147.465 Y70.744 F1000
G1 X148.384 Y70.774 F1000
G1 X149.302 Y70.807 F1000
G1 X150.221 Y70.843 F1000
G1 X151.139 Y70.882 F1000
G1 X152.057 Y70.924 F1000
G1 X152.975 Y70.968 F1000
G1 X153.893 Y71.017 F1000
G1 X154.81 Y71.069 F1000
G1 X155.727 Y71.124 F1000
G1 X156.644 Y71.184 F1000
G1 X157.561 Y71.248 F1000
G1 X158.478 Y71.317 F1000
G1 X159.394 Y71.391 F1000
G1 X160.309 Y71.471 F1000
G1 X161.224 Y71.556 F1000
G1 X162.139 Y71.648 F1000
G1 X163.052 Y71.747 F1000
G1 X163.965 Y71.854 F1000
G1 X164.877 Y71.97 F1000
G1 X165.787 Y72.096 F1000
G1 X166.696 Y72.234 F1000
G1 X167.602 Y72.386 F1000
G1 X168.506 Y72.553 F1000
G1 X169.406 Y72.739 F1000
G1 X170.301 Y72.949 F1000
G1 X171.188 Y73.189 F1000
G1 X172.06 Y73.474 F1000
G1 X172.625 Y73.71 F1000
G1 X172.933 Y73.869 F1000
G1 X173.203 Y74.048 F1000
G1 X173.428 Y74.281 F1000
G1 X173.596 Y74.557 F1000
G1 X173.701 Y74.864 F1000
G1 X173.736 Y75.186 F1000
G1 Y77.713 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y78.298 I-0.635 J-0.022 F1000
G1 X173.221 Y78.319 Z-3.012 F1000
G1 X173.153 Y78.34 Z-3 F1000
G1 X173.088 Y78.36 Z-2.98 F1000
G1 X173.025 Y78.379 Z-2.953 F1000
G1 X172.966 Y78.397 Z-2.919 F1000
G1 X172.91 Y78.415 Z-2.877 F1000
G1 X172.859 Y78.43 Z-2.83 F1000
G1 X172.814 Y78.444 Z-2.777 F1000
G1 X172.775 Y78.456 Z-2.719 F1000
G1 X172.742 Y78.466 Z-2.657 F1000
G1 X172.716 Y78.475 Z-2.591 F1000
G1 X172.697 Y78.48 Z-2.522 F1000
G1 X172.685 Y78.484 Z-2.452 F1000
G1 X172.682 Y78.485 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y85.382 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y85.379 Z-2.452 F1000
G1 X22.509 Y85.369 Z-2.522 F1000
G1 X22.499 Y85.352 Z-2.591 F1000
G1 X22.485 Y85.328 Z-2.657 F1000
G1 X22.467 Y85.299 Z-2.719 F1000
G1 X22.446 Y85.263 Z-2.777 F1000
G1 X22.422 Y85.222 Z-2.83 F1000
G1 X22.395 Y85.177 Z-2.877 F1000
G1 X22.365 Y85.127 Z-2.919 F1000
G1 X22.333 Y85.073 Z-2.953 F1000
G1 X22.3 Y85.017 Z-2.98 F1000
G1 X22.265 Y84.958 Z-3 F1000
G1 X22.229 Y84.898 Z-3.012 F1000
G1 X22.192 Y84.836 Z-3.016 F1000
G3 X21.971 Y84.083 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y81.577 F1000
G1 X21.986 Y81.269 F1000
G1 X22.018 Y81.026 F1000
G1 X22.08 Y80.737 F1000
G1 X22.172 Y80.43 F1000
G1 X22.302 Y80.096 F1000
G1 X22.488 Y79.713 F1000
G1 X22.714 Y79.328 F1000
G1 X23.024 Y78.888 F1000
G1 X23.402 Y78.433 F1000
G1 X23.885 Y77.937 F1000
G1 X24.501 Y77.4 F1000
G1 X25.24 Y76.853 F1000
G1 X26.018 Y76.364 F1000
G1 X26.825 Y75.924 F1000
G1 X27.654 Y75.526 F1000
G1 X28.499 Y75.165 F1000
G1 X29.357 Y74.836 F1000
G1 X30.225 Y74.534 F1000
G1 X31.101 Y74.257 F1000
G1 X31.984 Y74.001 F1000
G1 X32.872 Y73.765 F1000
G1 X33.764 Y73.545 F1000
G1 X34.66 Y73.34 F1000
G1 X35.559 Y73.149 F1000
G1 X36.461 Y72.971 F1000
G1 X37.364 Y72.803 F1000
G1 X38.27 Y72.646 F1000
G1 X39.177 Y72.497 F1000
G1 X40.085 Y72.358 F1000
G1 X40.994 Y72.225 F1000
G1 X41.905 Y72.1 F1000
G1 X42.816 Y71.982 F1000
G1 X43.728 Y71.87 F1000
G1 X44.641 Y71.763 F1000
G1 X45.555 Y71.661 F1000
G1 X46.469 Y71.565 F1000
G1 X47.383 Y71.472 F1000
G1 X48.298 Y71.384 F1000
G1 X49.213 Y71.3 F1000
G1 X50.128 Y71.219 F1000
G1 X51.044 Y71.142 F1000
G1 X51.96 Y71.068 F1000
G1 X52.876 Y70.996 F1000
G1 X53.793 Y70.927 F1000
G1 X54.709 Y70.861 F1000
G1 X55.626 Y70.797 F1000
G1 X56.543 Y70.735 F1000
G1 X57.46 Y70.674 F1000
G1 X58.377 Y70.616 F1000
G1 X59.295 Y70.559 F1000
G1 X60.212 Y70.504 F1000
G1 X61.129 Y70.45 F1000
G1 X62.047 Y70.397 F1000
G1 X62.964 Y70.346 F1000
G1 X64.8 Y70.246 F1000
G1 X66.635 Y70.149 F1000
G1 X68.471 Y70.055 F1000
G1 X71.225 Y69.918 F1000
G1 X73.978 Y69.785 F1000
G1 X76.732 Y69.655 F1000
G1 X80.405 Y69.486 F1000
G1 X83.159 Y69.361 F1000
G1 X85.913 Y69.239 F1000
G1 X88.668 Y69.119 F1000
G1 X91.422 Y69.003 F1000
G1 X94.177 Y68.891 F1000
G1 X96.014 Y68.818 F1000
G1 X97.85 Y68.747 F1000
G1 X99.687 Y68.679 F1000
G1 X101.524 Y68.613 F1000
G1 X103.361 Y68.55 F1000
G1 X105.198 Y68.49 F1000
G1 X107.035 Y68.432 F1000
G1 X108.872 Y68.377 F1000
G1 X110.71 Y68.326 F1000
G1 X112.547 Y68.278 F1000
G1 X114.384 Y68.233 F1000
G1 X116.222 Y68.192 F1000
G1 X118.06 Y68.154 F1000
G1 X118.979 Y68.136 F1000
G1 X120.816 Y68.104 F1000
G1 X122.654 Y68.076 F1000
G1 X123.573 Y68.064 F1000
G1 X124.492 Y68.052 F1000
G1 X125.411 Y68.042 F1000
G1 X126.33 Y68.033 F1000
G1 X127.249 Y68.025 F1000
G1 X128.168 Y68.018 F1000
G1 X129.087 Y68.012 F1000
G1 X130.006 Y68.007 F1000
G1 X130.925 Y68.004 F1000
G1 X131.844 Y68.002 F1000
G1 X132.763 Y68.001 F1000
G1 X133.682 Y68.002 F1000
G1 X134.601 Y68.004 F1000
G1 X135.52 Y68.008 F1000
G1 X136.439 Y68.013 F1000
G1 X137.358 Y68.019 F1000
G1 X138.277 Y68.027 F1000
G1 X139.196 Y68.037 F1000
G1 X140.115 Y68.049 F1000
G1 X141.034 Y68.062 F1000
G1 X141.953 Y68.077 F1000
G1 X142.872 Y68.095 F1000
G1 X143.79 Y68.114 F1000
G1 X144.709 Y68.135 F1000
G1 X145.628 Y68.158 F1000
G1 X146.547 Y68.184 F1000
G1 X147.465 Y68.212 F1000
G1 X148.384 Y68.243 F1000
G1 X149.302 Y68.276 F1000
G1 X150.22 Y68.312 F1000
G1 X151.139 Y68.351 F1000
G1 X152.057 Y68.393 F1000
G1 X152.975 Y68.438 F1000
G1 X153.892 Y68.486 F1000
G1 X154.81 Y68.538 F1000
G1 X155.727 Y68.594 F1000
G1 X156.644 Y68.654 F1000
G1 X157.561 Y68.719 F1000
G1 X158.477 Y68.788 F1000
G1 X159.393 Y68.862 F1000
G1 X160.309 Y68.941 F1000
G1 X161.224 Y69.027 F1000
G1 X162.139 Y69.119 F1000
G1 X163.052 Y69.218 F1000
G1 X163.965 Y69.325 F1000
G1 X164.877 Y69.442 F1000
G1 X165.787 Y69.568 F1000
G1 X166.695 Y69.706 F1000
G1 X167.602 Y69.857 F1000
G1 X168.506 Y70.025 F1000
G1 X169.406 Y70.211 F1000
G1 X170.3 Y70.421 F1000
G1 X171.187 Y70.661 F1000
G1 X172.06 Y70.946 F1000
G1 X172.625 Y71.182 F1000
G1 X172.933 Y71.341 F1000
G1 X173.203 Y71.52 F1000
G1 X173.428 Y71.753 F1000
G1 X173.596 Y72.03 F1000
G1 X173.701 Y72.336 F1000
G1 X173.736 Y72.658 F1000
G1 Y75.186 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y75.77 I-0.635 J-0.022 F1000
G1 X173.221 Y75.791 Z-3.012 F1000
G1 X173.153 Y75.812 Z-3 F1000
G1 X173.088 Y75.832 Z-2.98 F1000
G1 X173.025 Y75.852 Z-2.953 F1000
G1 X172.966 Y75.87 Z-2.919 F1000
G1 X172.91 Y75.887 Z-2.877 F1000
G1 X172.859 Y75.903 Z-2.83 F1000
G1 X172.814 Y75.917 Z-2.777 F1000
G1 X172.775 Y75.929 Z-2.719 F1000
G1 X172.742 Y75.939 Z-2.657 F1000
G1 X172.716 Y75.947 Z-2.591 F1000
G1 X172.697 Y75.953 Z-2.522 F1000
G1 X172.685 Y75.956 Z-2.452 F1000
G1 X172.682 Y75.957 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y82.876 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y82.873 Z-2.452 F1000
G1 X22.509 Y82.863 Z-2.522 F1000
G1 X22.499 Y82.846 Z-2.591 F1000
G1 X22.485 Y82.822 Z-2.657 F1000
G1 X22.467 Y82.793 Z-2.719 F1000
G1 X22.446 Y82.757 Z-2.777 F1000
G1 X22.422 Y82.716 Z-2.83 F1000
G1 X22.395 Y82.671 Z-2.877 F1000
G1 X22.365 Y82.621 Z-2.919 F1000
G1 X22.333 Y82.567 Z-2.953 F1000
G1 X22.3 Y82.511 Z-2.98 F1000
G1 X22.265 Y82.452 Z-3 F1000
G1 X22.229 Y82.392 Z-3.012 F1000
G1 X22.192 Y82.33 Z-3.016 F1000
G3 X21.971 Y81.577 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y79.071 F1000
G1 X21.987 Y78.743 F1000
G1 X22.019 Y78.501 F1000
G1 X22.081 Y78.212 F1000
G1 X22.173 Y77.904 F1000
G1 X22.303 Y77.57 F1000
G1 X22.489 Y77.187 F1000
G1 X22.715 Y76.803 F1000
G1 X23.025 Y76.362 F1000
G1 X23.403 Y75.907 F1000
G1 X23.886 Y75.411 F1000
G1 X24.503 Y74.873 F1000
G1 X25.242 Y74.327 F1000
G1 X26.02 Y73.838 F1000
G1 X26.827 Y73.398 F1000
G1 X27.655 Y73 F1000
G1 X28.5 Y72.639 F1000
G1 X29.358 Y72.309 F1000
G1 X30.226 Y72.007 F1000
G1 X31.102 Y71.73 F1000
G1 X31.985 Y71.474 F1000
G1 X32.873 Y71.237 F1000
G1 X33.765 Y71.018 F1000
G1 X34.661 Y70.813 F1000
G1 X35.56 Y70.622 F1000
G1 X36.462 Y70.443 F1000
G1 X37.365 Y70.275 F1000
G1 X38.271 Y70.117 F1000
G1 X39.177 Y69.968 F1000
G1 X40.086 Y69.828 F1000
G1 X40.995 Y69.696 F1000
G1 X41.906 Y69.57 F1000
G1 X42.817 Y69.452 F1000
G1 X43.729 Y69.339 F1000
G1 X44.642 Y69.232 F1000
G1 X45.555 Y69.13 F1000
G1 X46.469 Y69.033 F1000
G1 X47.383 Y68.94 F1000
G1 X48.298 Y68.852 F1000
G1 X49.213 Y68.767 F1000
G1 X50.129 Y68.686 F1000
G1 X51.044 Y68.608 F1000
G1 X51.96 Y68.533 F1000
G1 X52.876 Y68.461 F1000
G1 X53.793 Y68.392 F1000
G1 X54.709 Y68.325 F1000
G1 X55.626 Y68.261 F1000
G1 X56.543 Y68.198 F1000
G1 X57.46 Y68.138 F1000
G1 X58.377 Y68.079 F1000
G1 X59.295 Y68.022 F1000
G1 X60.212 Y67.966 F1000
G1 X61.129 Y67.912 F1000
G1 X62.047 Y67.859 F1000
G1 X62.964 Y67.807 F1000
G1 X64.8 Y67.706 F1000
G1 X66.635 Y67.609 F1000
G1 X68.471 Y67.515 F1000
G1 X70.306 Y67.423 F1000
G1 X73.06 Y67.288 F1000
G1 X75.814 Y67.157 F1000
G1 X78.568 Y67.029 F1000
G1 X81.322 Y66.902 F1000
G1 X84.077 Y66.779 F1000
G1 X86.831 Y66.658 F1000
G1 X89.586 Y66.539 F1000
G1 X92.34 Y66.425 F1000
G1 X95.095 Y66.314 F1000
G1 X96.932 Y66.243 F1000
G1 X98.769 Y66.174 F1000
G1 X100.605 Y66.107 F1000
G1 X102.442 Y66.043 F1000
G1 X104.279 Y65.981 F1000
G1 X106.116 Y65.922 F1000
G1 X107.954 Y65.866 F1000
G1 X109.791 Y65.813 F1000
G1 X111.628 Y65.764 F1000
G1 X113.466 Y65.718 F1000
G1 X115.303 Y65.675 F1000
G1 X117.141 Y65.635 F1000
G1 X118.979 Y65.6 F1000
G1 X120.816 Y65.568 F1000
G1 X122.654 Y65.54 F1000
G1 X123.573 Y65.528 F1000
G1 X124.492 Y65.516 F1000
G1 X125.411 Y65.506 F1000
G1 X126.33 Y65.497 F1000
G1 X127.249 Y65.489 F1000
G1 X128.168 Y65.482 F1000
G1 X129.087 Y65.477 F1000
G1 X130.006 Y65.472 F1000
G1 X130.925 Y65.469 F1000
G1 X131.844 Y65.467 F1000
G1 X132.763 F1000
G1 X133.682 Y65.468 F1000
G1 X134.601 Y65.47 F1000
G1 X135.52 Y65.473 F1000
G1 X136.439 Y65.479 F1000
G1 X137.358 Y65.485 F1000
G1 X138.277 Y65.494 F1000
G1 X139.196 Y65.504 F1000
G1 X140.115 Y65.516 F1000
G1 X141.034 Y65.529 F1000
G1 X141.953 Y65.544 F1000
G1 X142.872 Y65.562 F1000
G1 X143.79 Y65.581 F1000
G1 X144.709 Y65.603 F1000
G1 X145.628 Y65.626 F1000
G1 X146.547 Y65.652 F1000
G1 X147.465 Y65.68 F1000
G1 X148.384 Y65.711 F1000
G1 X149.302 Y65.745 F1000
G1 X150.22 Y65.781 F1000
G1 X151.139 Y65.82 F1000
G1 X152.057 Y65.862 F1000
G1 X152.975 Y65.907 F1000
G1 X153.892 Y65.956 F1000
G1 X154.81 Y66.008 F1000
G1 X155.727 Y66.064 F1000
G1 X156.644 Y66.125 F1000
G1 X157.561 Y66.189 F1000
G1 X158.477 Y66.258 F1000
G1 X159.393 Y66.332 F1000
G1 X160.309 Y66.412 F1000
G1 X161.224 Y66.498 F1000
G1 X162.138 Y66.59 F1000
G1 X163.052 Y66.689 F1000
G1 X163.965 Y66.797 F1000
G1 X164.876 Y66.913 F1000
G1 X165.787 Y67.04 F1000
G1 X166.695 Y67.178 F1000
G1 X167.602 Y67.329 F1000
G1 X168.505 Y67.497 F1000
G1 X169.405 Y67.683 F1000
G1 X170.3 Y67.893 F1000
G1 X171.187 Y68.133 F1000
G1 X172.06 Y68.418 F1000
G1 X172.625 Y68.654 F1000
G1 X172.934 Y68.813 F1000
G1 X173.203 Y68.992 F1000
G1 X173.428 Y69.226 F1000
G1 X173.596 Y69.502 F1000
G1 X173.701 Y69.808 F1000
G1 X173.736 Y70.13 F1000
G1 Y72.658 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y73.243 I-0.635 J-0.022 F1000
G1 X173.221 Y73.264 Z-3.012 F1000
G1 X173.153 Y73.284 Z-3 F1000
G1 X173.088 Y73.304 Z-2.98 F1000
G1 X173.025 Y73.324 Z-2.953 F1000
G1 X172.966 Y73.342 Z-2.919 F1000
G1 X172.91 Y73.359 Z-2.877 F1000
G1 X172.859 Y73.375 Z-2.83 F1000
G1 X172.814 Y73.389 Z-2.777 F1000
G1 X172.775 Y73.401 Z-2.719 F1000
G1 X172.742 Y73.411 Z-2.657 F1000
G1 X172.716 Y73.419 Z-2.591 F1000
G1 X172.697 Y73.425 Z-2.522 F1000
G1 X172.685 Y73.429 Z-2.452 F1000
G1 X172.682 Y73.43 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y80.37 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y80.367 Z-2.452 F1000
G1 X22.509 Y80.357 Z-2.522 F1000
G1 X22.499 Y80.34 Z-2.591 F1000
G1 X22.485 Y80.316 Z-2.657 F1000
G1 X22.467 Y80.287 Z-2.719 F1000
G1 X22.446 Y80.251 Z-2.777 F1000
G1 X22.422 Y80.21 Z-2.83 F1000
G1 X22.395 Y80.165 Z-2.877 F1000
G1 X22.365 Y80.115 Z-2.919 F1000
G1 X22.333 Y80.061 Z-2.953 F1000
G1 X22.3 Y80.005 Z-2.98 F1000
G1 X22.265 Y79.946 Z-3 F1000
G1 X22.229 Y79.886 Z-3.012 F1000
G1 X22.192 Y79.824 Z-3.016 F1000
G3 X21.971 Y79.071 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y76.565 F1000
G1 X21.988 Y76.218 F1000
G1 X22.02 Y75.975 F1000
G1 X22.082 Y75.686 F1000
G1 X22.174 Y75.379 F1000
G1 X22.304 Y75.045 F1000
G1 X22.49 Y74.661 F1000
G1 X22.716 Y74.277 F1000
G1 X23.026 Y73.836 F1000
G1 X23.404 Y73.381 F1000
G1 X23.888 Y72.885 F1000
G1 X24.505 Y72.347 F1000
G1 X25.243 Y71.8 F1000
G1 X26.021 Y71.311 F1000
G1 X26.828 Y70.871 F1000
G1 X27.657 Y70.473 F1000
G1 X28.502 Y70.112 F1000
G1 X29.36 Y69.782 F1000
G1 X30.228 Y69.481 F1000
G1 X31.104 Y69.203 F1000
G1 X31.986 Y68.947 F1000
G1 X32.874 Y68.71 F1000
G1 X33.766 Y68.49 F1000
G1 X34.662 Y68.285 F1000
G1 X35.561 Y68.093 F1000
G1 X36.463 Y67.914 F1000
G1 X37.366 Y67.746 F1000
G1 X38.271 Y67.588 F1000
G1 X39.178 Y67.439 F1000
G1 X40.086 Y67.299 F1000
G1 X40.996 Y67.166 F1000
G1 X41.906 Y67.04 F1000
G1 X42.818 Y66.921 F1000
G1 X43.73 Y66.808 F1000
G1 X44.642 Y66.701 F1000
G1 X45.556 Y66.598 F1000
G1 X46.469 Y66.501 F1000
G1 X47.384 Y66.408 F1000
G1 X48.298 Y66.319 F1000
G1 X49.214 Y66.234 F1000
G1 X50.129 Y66.152 F1000
G1 X51.045 Y66.074 F1000
G1 X51.961 Y65.999 F1000
G1 X52.877 Y65.927 F1000
G1 X53.793 Y65.857 F1000
G1 X54.71 Y65.79 F1000
G1 X55.626 Y65.725 F1000
G1 X56.543 Y65.662 F1000
G1 X57.46 Y65.601 F1000
G1 X58.377 Y65.542 F1000
G1 X59.295 Y65.484 F1000
G1 X60.212 Y65.428 F1000
G1 X61.129 Y65.374 F1000
G1 X62.047 Y65.321 F1000
G1 X62.964 Y65.268 F1000
G1 X64.8 Y65.167 F1000
G1 X66.635 Y65.069 F1000
G1 X68.471 Y64.975 F1000
G1 X70.306 Y64.882 F1000
G1 X73.06 Y64.747 F1000
G1 X75.814 Y64.616 F1000
G1 X78.568 Y64.487 F1000
G1 X81.322 Y64.361 F1000
G1 X84.077 Y64.237 F1000
G1 X86.831 Y64.116 F1000
G1 X89.585 Y63.999 F1000
G1 X92.34 Y63.884 F1000
G1 X95.095 Y63.774 F1000
G1 X96.932 Y63.703 F1000
G1 X98.768 Y63.634 F1000
G1 X100.605 Y63.568 F1000
G1 X102.442 Y63.504 F1000
G1 X104.279 Y63.442 F1000
G1 X106.116 Y63.384 F1000
G1 X107.954 Y63.328 F1000
G1 X109.791 Y63.276 F1000
G1 X111.628 Y63.226 F1000
G1 X113.466 Y63.18 F1000
G1 X115.303 Y63.138 F1000
G1 X117.141 Y63.099 F1000
G1 X118.979 Y63.063 F1000
G1 X120.816 Y63.032 F1000
G1 X122.654 Y63.004 F1000
G1 X123.573 Y62.992 F1000
G1 X124.492 Y62.981 F1000
G1 X125.411 Y62.971 F1000
G1 X126.33 Y62.962 F1000
G1 X127.249 Y62.954 F1000
G1 X128.168 Y62.947 F1000
G1 X129.087 Y62.941 F1000
G1 X130.006 Y62.937 F1000
G1 X130.925 Y62.934 F1000
G1 X131.844 Y62.932 F1000
G1 X132.763 F1000
G1 X133.682 Y62.933 F1000
G1 X134.601 Y62.935 F1000
G1 X135.52 Y62.939 F1000
G1 X136.439 Y62.945 F1000
G1 X137.358 Y62.952 F1000
G1 X138.277 Y62.96 F1000
G1 X139.196 Y62.97 F1000
G1 X140.115 Y62.982 F1000
G1 X141.034 Y62.996 F1000
G1 X141.953 Y63.012 F1000
G1 X142.872 Y63.029 F1000
G1 X143.79 Y63.049 F1000
G1 X144.709 Y63.07 F1000
G1 X145.628 Y63.094 F1000
G1 X146.547 Y63.12 F1000
G1 X147.465 Y63.149 F1000
G1 X148.384 Y63.18 F1000
G1 X149.302 Y63.213 F1000
G1 X150.22 Y63.25 F1000
G1 X151.139 Y63.289 F1000
G1 X152.057 Y63.331 F1000
G1 X152.974 Y63.377 F1000
G1 X153.892 Y63.425 F1000
G1 X154.81 Y63.478 F1000
G1 X155.727 Y63.534 F1000
G1 X156.644 Y63.595 F1000
G1 X157.561 Y63.659 F1000
G1 X158.477 Y63.729 F1000
G1 X159.393 Y63.803 F1000
G1 X160.309 Y63.883 F1000
G1 X161.224 Y63.969 F1000
G1 X162.138 Y64.061 F1000
G1 X163.052 Y64.16 F1000
G1 X163.964 Y64.268 F1000
G1 X164.876 Y64.384 F1000
G1 X165.786 Y64.511 F1000
G1 X166.695 Y64.649 F1000
G1 X167.601 Y64.801 F1000
G1 X168.505 Y64.968 F1000
G1 X169.405 Y65.155 F1000
G1 X170.3 Y65.365 F1000
G1 X171.187 Y65.605 F1000
G1 X172.06 Y65.89 F1000
G1 X172.625 Y66.126 F1000
G1 X172.934 Y66.285 F1000
G1 X173.203 Y66.464 F1000
G1 X173.428 Y66.698 F1000
G1 X173.596 Y66.974 F1000
G1 X173.701 Y67.281 F1000
G1 X173.736 Y67.602 F1000
G1 Y70.13 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y70.715 I-0.635 J-0.022 F1000
G1 X173.221 Y70.736 Z-3.012 F1000
G1 X173.153 Y70.756 Z-3 F1000
G1 X173.088 Y70.777 Z-2.98 F1000
G1 X173.025 Y70.796 Z-2.953 F1000
G1 X172.966 Y70.814 Z-2.919 F1000
G1 X172.91 Y70.831 Z-2.877 F1000
G1 X172.859 Y70.847 Z-2.83 F1000
G1 X172.814 Y70.861 Z-2.777 F1000
G1 X172.775 Y70.873 Z-2.719 F1000
G1 X172.742 Y70.883 Z-2.657 F1000
G1 X172.716 Y70.891 Z-2.591 F1000
G1 X172.697 Y70.897 Z-2.522 F1000
G1 X172.685 Y70.901 Z-2.452 F1000
G1 X172.682 Y70.902 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y77.864 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y77.861 Z-2.452 F1000
G1 X22.509 Y77.851 Z-2.522 F1000
G1 X22.499 Y77.834 Z-2.591 F1000
G1 X22.485 Y77.81 Z-2.657 F1000
G1 X22.467 Y77.781 Z-2.719 F1000
G1 X22.446 Y77.745 Z-2.777 F1000
G1 X22.422 Y77.704 Z-2.83 F1000
G1 X22.395 Y77.659 Z-2.877 F1000
G1 X22.365 Y77.609 Z-2.919 F1000
G1 X22.333 Y77.555 Z-2.953 F1000
G1 X22.3 Y77.499 Z-2.98 F1000
G1 X22.265 Y77.44 Z-3 F1000
G1 X22.229 Y77.38 Z-3.012 F1000
G1 X22.192 Y77.318 Z-3.016 F1000
G3 X21.971 Y76.565 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y74.059 F1000
G1 X21.989 Y73.692 F1000
G1 X22.021 Y73.449 F1000
G1 X22.083 Y73.16 F1000
G1 X22.175 Y72.853 F1000
G1 X22.305 Y72.519 F1000
G1 X22.491 Y72.135 F1000
G1 X22.718 Y71.751 F1000
G1 X23.027 Y71.31 F1000
G1 X23.405 Y70.854 F1000
G1 X23.889 Y70.359 F1000
G1 X24.506 Y69.82 F1000
G1 X25.245 Y69.274 F1000
G1 X26.023 Y68.784 F1000
G1 X26.83 Y68.344 F1000
G1 X27.658 Y67.946 F1000
G1 X28.503 Y67.585 F1000
G1 X29.361 Y67.255 F1000
G1 X30.229 Y66.953 F1000
G1 X31.105 Y66.676 F1000
G1 X31.988 Y66.42 F1000
G1 X32.875 Y66.182 F1000
G1 X33.768 Y65.962 F1000
G1 X34.663 Y65.757 F1000
G1 X35.562 Y65.565 F1000
G1 X36.464 Y65.385 F1000
G1 X37.367 Y65.217 F1000
G1 X38.272 Y65.059 F1000
G1 X39.179 Y64.91 F1000
G1 X40.087 Y64.769 F1000
G1 X40.997 Y64.636 F1000
G1 X41.907 Y64.51 F1000
G1 X42.818 Y64.39 F1000
G1 X43.73 Y64.277 F1000
G1 X44.643 Y64.169 F1000
G1 X45.556 Y64.066 F1000
G1 X46.47 Y63.969 F1000
G1 X47.384 Y63.875 F1000
G1 X48.299 Y63.786 F1000
G1 X49.214 Y63.7 F1000
G1 X50.129 Y63.618 F1000
G1 X51.045 Y63.54 F1000
G1 X51.961 Y63.464 F1000
G1 X52.877 Y63.392 F1000
G1 X53.793 Y63.322 F1000
G1 X54.71 Y63.254 F1000
G1 X55.627 Y63.189 F1000
G1 X56.543 Y63.126 F1000
G1 X57.46 Y63.064 F1000
G1 X58.377 Y63.005 F1000
G1 X59.295 Y62.947 F1000
G1 X60.212 Y62.891 F1000
G1 X61.129 Y62.836 F1000
G1 X62.047 Y62.782 F1000
G1 X62.964 Y62.73 F1000
G1 X64.8 Y62.628 F1000
G1 X66.635 Y62.53 F1000
G1 X68.471 Y62.434 F1000
G1 X70.306 Y62.342 F1000
G1 X73.06 Y62.206 F1000
G1 X75.814 Y62.074 F1000
G1 X78.568 Y61.946 F1000
G1 X81.322 Y61.82 F1000
G1 X84.076 Y61.696 F1000
G1 X86.831 Y61.575 F1000
G1 X89.585 Y61.458 F1000
G1 X92.34 Y61.344 F1000
G1 X95.095 Y61.234 F1000
G1 X96.932 Y61.163 F1000
G1 X98.768 Y61.095 F1000
G1 X100.605 Y61.029 F1000
G1 X102.442 Y60.965 F1000
G1 X104.279 Y60.904 F1000
G1 X106.116 Y60.846 F1000
G1 X107.954 Y60.79 F1000
G1 X109.791 Y60.738 F1000
G1 X111.628 Y60.689 F1000
G1 X113.466 Y60.643 F1000
G1 X115.303 Y60.601 F1000
G1 X117.141 Y60.562 F1000
G1 X118.979 Y60.527 F1000
G1 X120.816 Y60.495 F1000
G1 X121.735 Y60.481 F1000
G1 X122.654 Y60.468 F1000
G1 X123.573 Y60.456 F1000
G1 X124.492 Y60.445 F1000
G1 X125.411 Y60.435 F1000
G1 X126.33 Y60.426 F1000
G1 X127.249 Y60.418 F1000
G1 X128.168 Y60.412 F1000
G1 X129.087 Y60.406 F1000
G1 X130.006 Y60.402 F1000
G1 X130.925 Y60.399 F1000
G1 X131.844 Y60.398 F1000
G1 X132.763 Y60.397 F1000
G1 X133.682 Y60.399 F1000
G1 X134.601 Y60.401 F1000
G1 X135.52 Y60.405 F1000
G1 X136.439 Y60.411 F1000
G1 X137.358 Y60.418 F1000
G1 X138.277 Y60.426 F1000
G1 X139.196 Y60.437 F1000
G1 X140.115 Y60.449 F1000
G1 X141.034 Y60.463 F1000
G1 X141.953 Y60.479 F1000
G1 X142.872 Y60.496 F1000
G1 X143.79 Y60.516 F1000
G1 X144.709 Y60.538 F1000
G1 X145.628 Y60.562 F1000
G1 X146.547 Y60.588 F1000
G1 X147.465 Y60.617 F1000
G1 X148.384 Y60.648 F1000
G1 X149.302 Y60.682 F1000
G1 X150.22 Y60.718 F1000
G1 X151.138 Y60.758 F1000
G1 X152.057 Y60.8 F1000
G1 X152.974 Y60.846 F1000
G1 X153.892 Y60.895 F1000
G1 X154.81 Y60.948 F1000
G1 X155.727 Y61.004 F1000
G1 X156.644 Y61.065 F1000
G1 X157.561 Y61.129 F1000
G1 X158.477 Y61.199 F1000
G1 X159.393 Y61.274 F1000
G1 X160.309 Y61.354 F1000
G1 X161.224 Y61.439 F1000
G1 X162.138 Y61.532 F1000
G1 X163.052 Y61.631 F1000
G1 X163.964 Y61.739 F1000
G1 X164.876 Y61.856 F1000
G1 X165.786 Y61.983 F1000
G1 X166.695 Y62.121 F1000
G1 X167.601 Y62.273 F1000
G1 X168.505 Y62.44 F1000
G1 X169.405 Y62.627 F1000
G1 X170.299 Y62.837 F1000
G1 X171.186 Y63.077 F1000
G1 X172.06 Y63.362 F1000
G1 X172.625 Y63.598 F1000
G1 X172.934 Y63.758 F1000
G1 X173.203 Y63.936 F1000
G1 X173.428 Y64.17 F1000
G1 X173.596 Y64.446 F1000
G1 X173.701 Y64.753 F1000
G1 X173.736 Y65.074 F1000
G1 Y67.602 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y68.187 I-0.635 J-0.022 F1000
G1 X173.221 Y68.208 Z-3.012 F1000
G1 X173.153 Y68.229 Z-3 F1000
G1 X173.088 Y68.249 Z-2.98 F1000
G1 X173.025 Y68.268 Z-2.953 F1000
G1 X172.966 Y68.286 Z-2.919 F1000
G1 X172.91 Y68.304 Z-2.877 F1000
G1 X172.859 Y68.319 Z-2.83 F1000
G1 X172.814 Y68.333 Z-2.777 F1000
G1 X172.775 Y68.345 Z-2.719 F1000
G1 X172.742 Y68.356 Z-2.657 F1000
G1 X172.716 Y68.364 Z-2.591 F1000
G1 X172.697 Y68.369 Z-2.522 F1000
G1 X172.685 Y68.373 Z-2.452 F1000
G1 X172.682 Y68.374 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y75.358 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y75.355 Z-2.452 F1000
G1 X22.509 Y75.345 Z-2.522 F1000
G1 X22.499 Y75.328 Z-2.591 F1000
G1 X22.485 Y75.304 Z-2.657 F1000
G1 X22.467 Y75.275 Z-2.719 F1000
G1 X22.446 Y75.239 Z-2.777 F1000
G1 X22.422 Y75.198 Z-2.83 F1000
G1 X22.395 Y75.153 Z-2.877 F1000
G1 X22.365 Y75.103 Z-2.919 F1000
G1 X22.333 Y75.049 Z-2.953 F1000
G1 X22.3 Y74.993 Z-2.98 F1000
G1 X22.265 Y74.934 Z-3 F1000
G1 X22.229 Y74.874 Z-3.012 F1000
G1 X22.192 Y74.812 Z-3.016 F1000
G3 X21.971 Y74.059 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y71.344 F1000
G1 X21.979 Y71.175 F1000
G1 X22.011 Y70.932 F1000
G1 X22.073 Y70.644 F1000
G1 X22.166 Y70.334 F1000
G1 X22.296 Y70 F1000
G1 X22.483 Y69.615 F1000
G1 X22.709 Y69.23 F1000
G1 X23.02 Y68.788 F1000
G1 X23.398 Y68.333 F1000
G1 X23.883 Y67.836 F1000
G1 X24.501 Y67.296 F1000
G1 X25.24 Y66.75 F1000
G1 X26.018 Y66.26 F1000
G1 X26.824 Y65.82 F1000
G1 X27.653 Y65.422 F1000
G1 X28.498 Y65.06 F1000
G1 X29.355 Y64.73 F1000
G1 X30.223 Y64.428 F1000
G1 X31.099 Y64.15 F1000
G1 X31.982 Y63.894 F1000
G1 X32.87 Y63.656 F1000
G1 X33.762 Y63.436 F1000
G1 X34.657 Y63.23 F1000
G1 X35.556 Y63.038 F1000
G1 X36.457 Y62.858 F1000
G1 X37.361 Y62.689 F1000
G1 X38.266 Y62.531 F1000
G1 X39.173 Y62.381 F1000
G1 X40.081 Y62.24 F1000
G1 X40.99 Y62.106 F1000
G1 X41.9 Y61.98 F1000
G1 X42.812 Y61.86 F1000
G1 X43.724 Y61.746 F1000
G1 X44.636 Y61.638 F1000
G1 X45.549 Y61.535 F1000
G1 X46.463 Y61.437 F1000
G1 X47.377 Y61.343 F1000
G1 X48.292 Y61.253 F1000
G1 X49.207 Y61.168 F1000
G1 X50.122 Y61.085 F1000
G1 X51.038 Y61.006 F1000
G1 X51.954 Y60.93 F1000
G1 X52.87 Y60.857 F1000
G1 X53.786 Y60.787 F1000
G1 X54.703 Y60.719 F1000
G1 X55.619 Y60.653 F1000
G1 X56.536 Y60.59 F1000
G1 X57.453 Y60.528 F1000
G1 X58.37 Y60.468 F1000
G1 X59.287 Y60.41 F1000
G1 X60.205 Y60.353 F1000
G1 X61.122 Y60.298 F1000
G1 X62.04 Y60.244 F1000
G1 X62.957 Y60.191 F1000
G1 X64.792 Y60.089 F1000
G1 X66.628 Y59.99 F1000
G1 X68.463 Y59.895 F1000
G1 X69.381 Y59.848 F1000
G1 X71.217 Y59.756 F1000
G1 X73.971 Y59.621 F1000
G1 X76.724 Y59.49 F1000
G1 X79.479 Y59.362 F1000
G1 X82.233 Y59.237 F1000
G1 X84.987 Y59.115 F1000
G1 X87.742 Y58.995 F1000
G1 X90.496 Y58.879 F1000
G1 X93.251 Y58.767 F1000
G1 X96.006 Y58.659 F1000
G1 X97.843 Y58.589 F1000
G1 X99.679 Y58.522 F1000
G1 X101.516 Y58.458 F1000
G1 X103.353 Y58.396 F1000
G1 X105.19 Y58.336 F1000
G1 X107.028 Y58.28 F1000
G1 X108.865 Y58.226 F1000
G1 X110.702 Y58.175 F1000
G1 X112.54 Y58.128 F1000
G1 X114.377 Y58.084 F1000
G1 X116.215 Y58.044 F1000
G1 X118.052 Y58.007 F1000
G1 X119.89 Y57.974 F1000
G1 X121.728 Y57.945 F1000
G1 X122.647 Y57.932 F1000
G1 X123.566 Y57.92 F1000
G1 X124.485 Y57.909 F1000
G1 X125.404 Y57.899 F1000
G1 X126.323 Y57.89 F1000
G1 X127.242 Y57.883 F1000
G1 X128.161 Y57.876 F1000
G1 X129.08 Y57.871 F1000
G1 X129.999 Y57.867 F1000
G1 X130.918 Y57.864 F1000
G1 X131.837 Y57.863 F1000
G1 X132.756 F1000
G1 X133.675 Y57.864 F1000
G1 X134.594 Y57.867 F1000
G1 X135.513 Y57.871 F1000
G1 X136.432 Y57.877 F1000
G1 X137.351 Y57.884 F1000
G1 X138.27 Y57.893 F1000
G1 X139.189 Y57.903 F1000
G1 X140.108 Y57.916 F1000
G1 X141.027 Y57.93 F1000
G1 X141.946 Y57.946 F1000
G1 X142.864 Y57.963 F1000
G1 X143.783 Y57.983 F1000
G1 X144.702 Y58.005 F1000
G1 X145.621 Y58.029 F1000
G1 X146.539 Y58.056 F1000
G1 X147.458 Y58.085 F1000
G1 X148.376 Y58.116 F1000
G1 X149.295 Y58.15 F1000
G1 X150.213 Y58.187 F1000
G1 X151.131 Y58.226 F1000
G1 X152.049 Y58.269 F1000
G1 X152.967 Y58.315 F1000
G1 X153.885 Y58.364 F1000
G1 X154.802 Y58.417 F1000
G1 X155.72 Y58.473 F1000
G1 X156.637 Y58.534 F1000
G1 X157.553 Y58.599 F1000
G1 X158.47 Y58.669 F1000
G1 X159.386 Y58.743 F1000
G1 X160.301 Y58.823 F1000
G1 X161.216 Y58.909 F1000
G1 X162.131 Y59.002 F1000
G1 X163.044 Y59.102 F1000
G1 X163.957 Y59.209 F1000
G1 X164.868 Y59.326 F1000
G1 X165.779 Y59.453 F1000
G1 X166.687 Y59.591 F1000
G1 X167.594 Y59.743 F1000
G1 X168.497 Y59.91 F1000
G1 X169.397 Y60.097 F1000
G1 X170.292 Y60.307 F1000
G1 X171.179 Y60.547 F1000
G1 X172.053 Y60.832 F1000
G1 X172.619 Y61.068 F1000
G1 X172.932 Y61.229 F1000
G1 X173.203 Y61.408 F1000
G1 X173.427 Y61.641 F1000
G1 X173.596 Y61.918 F1000
G1 X173.701 Y62.224 F1000
G1 X173.736 Y62.546 F1000
G1 Y65.074 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y65.659 I-0.635 J-0.022 F1000
G1 X173.221 Y65.68 Z-3.012 F1000
G1 X173.153 Y65.701 Z-3 F1000
G1 X173.088 Y65.721 Z-2.98 F1000
G1 X173.025 Y65.74 Z-2.953 F1000
G1 X172.966 Y65.759 Z-2.919 F1000
G1 X172.91 Y65.776 Z-2.877 F1000
G1 X172.859 Y65.791 Z-2.83 F1000
G1 X172.814 Y65.805 Z-2.777 F1000
G1 X172.775 Y65.817 Z-2.719 F1000
G1 X172.742 Y65.828 Z-2.657 F1000
G1 X172.716 Y65.836 Z-2.591 F1000
G1 X172.697 Y65.841 Z-2.522 F1000
G1 X172.685 Y65.845 Z-2.452 F1000
G1 X172.682 Y65.846 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y72.643 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y72.64 Z-2.452 F1000
G1 X22.509 Y72.63 Z-2.522 F1000
G1 X22.499 Y72.613 Z-2.591 F1000
G1 X22.485 Y72.589 Z-2.657 F1000
G1 X22.467 Y72.56 Z-2.719 F1000
G1 X22.446 Y72.524 Z-2.777 F1000
G1 X22.422 Y72.484 Z-2.83 F1000
G1 X22.395 Y72.438 Z-2.877 F1000
G1 X22.365 Y72.388 Z-2.919 F1000
G1 X22.333 Y72.334 Z-2.953 F1000
G1 X22.3 Y72.278 Z-2.98 F1000
G1 X22.265 Y72.219 Z-3 F1000
G1 X22.229 Y72.159 Z-3.012 F1000
G1 X22.192 Y72.098 Z-3.016 F1000
G3 X21.971 Y71.344 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y68.838 F1000
G1 X21.981 Y68.646 F1000
G1 X22.012 Y68.403 F1000
G1 X22.074 Y68.114 F1000
G1 X22.167 Y67.806 F1000
G1 X22.297 Y67.472 F1000
G1 X22.483 Y67.088 F1000
G1 X22.71 Y66.703 F1000
G1 X23.02 Y66.261 F1000
G1 X23.398 Y65.805 F1000
G1 X23.883 Y65.309 F1000
G1 X24.501 Y64.77 F1000
G1 X25.24 Y64.223 F1000
G1 X26.017 Y63.734 F1000
G1 X26.824 Y63.293 F1000
G1 X27.652 Y62.895 F1000
G1 X28.497 Y62.533 F1000
G1 X29.355 Y62.203 F1000
G1 X30.223 Y61.901 F1000
G1 X31.099 Y61.623 F1000
G1 X31.981 Y61.366 F1000
G1 X32.869 Y61.128 F1000
G1 X33.761 Y60.908 F1000
G1 X34.657 Y60.702 F1000
G1 X35.555 Y60.509 F1000
G1 X36.457 Y60.329 F1000
G1 X37.36 Y60.16 F1000
G1 X38.265 Y60.001 F1000
G1 X39.172 Y59.851 F1000
G1 X40.08 Y59.71 F1000
G1 X40.989 Y59.576 F1000
G1 X41.899 Y59.45 F1000
G1 X42.81 Y59.329 F1000
G1 X43.722 Y59.215 F1000
G1 X44.635 Y59.107 F1000
G1 X45.548 Y59.003 F1000
G1 X46.462 Y58.905 F1000
G1 X47.376 Y58.811 F1000
G1 X48.291 Y58.72 F1000
G1 X49.206 Y58.634 F1000
G1 X50.121 Y58.552 F1000
G1 X51.037 Y58.472 F1000
G1 X51.952 Y58.396 F1000
G1 X52.868 Y58.322 F1000
G1 X53.785 Y58.252 F1000
G1 X54.701 Y58.183 F1000
G1 X55.618 Y58.117 F1000
G1 X56.535 Y58.053 F1000
G1 X57.452 Y57.991 F1000
G1 X58.369 Y57.931 F1000
G1 X59.286 Y57.873 F1000
G1 X60.203 Y57.816 F1000
G1 X61.12 Y57.76 F1000
G1 X62.038 Y57.706 F1000
G1 X62.955 Y57.653 F1000
G1 X64.79 Y57.55 F1000
G1 X66.626 Y57.451 F1000
G1 X68.461 Y57.355 F1000
G1 X69.379 Y57.307 F1000
G1 X71.215 Y57.215 F1000
G1 X73.969 Y57.08 F1000
G1 X76.723 Y56.949 F1000
G1 X79.477 Y56.821 F1000
G1 X82.231 Y56.696 F1000
G1 X84.985 Y56.574 F1000
G1 X87.74 Y56.455 F1000
G1 X90.494 Y56.339 F1000
G1 X93.249 Y56.227 F1000
G1 X95.086 Y56.155 F1000
G1 X96.922 Y56.084 F1000
G1 X98.759 Y56.016 F1000
G1 X100.596 Y55.951 F1000
G1 X102.433 Y55.887 F1000
G1 X104.27 Y55.827 F1000
G1 X106.107 Y55.769 F1000
G1 X107.944 Y55.714 F1000
G1 X109.782 Y55.663 F1000
G1 X111.619 Y55.614 F1000
G1 X113.457 Y55.569 F1000
G1 X115.294 Y55.527 F1000
G1 X117.132 Y55.488 F1000
G1 X118.97 Y55.454 F1000
G1 X119.888 Y55.438 F1000
G1 X121.726 Y55.409 F1000
G1 X122.645 Y55.396 F1000
G1 X123.564 Y55.384 F1000
G1 X124.483 Y55.373 F1000
G1 X125.402 Y55.364 F1000
G1 X126.321 Y55.355 F1000
G1 X127.24 Y55.347 F1000
G1 X128.159 Y55.341 F1000
G1 X129.078 Y55.336 F1000
G1 X129.997 Y55.332 F1000
G1 X130.916 Y55.33 F1000
G1 X131.835 Y55.328 F1000
G1 X132.754 F1000
G1 X133.673 Y55.33 F1000
G1 X134.592 Y55.333 F1000
G1 X135.511 Y55.337 F1000
G1 X136.43 Y55.343 F1000
G1 X137.349 Y55.35 F1000
G1 X138.268 Y55.359 F1000
G1 X139.187 Y55.37 F1000
G1 X140.106 Y55.382 F1000
G1 X141.025 Y55.396 F1000
G1 X141.944 Y55.413 F1000
G1 X142.863 Y55.431 F1000
G1 X143.781 Y55.451 F1000
G1 X144.7 Y55.473 F1000
G1 X145.619 Y55.497 F1000
G1 X146.537 Y55.524 F1000
G1 X147.456 Y55.553 F1000
G1 X148.375 Y55.584 F1000
G1 X149.293 Y55.619 F1000
G1 X150.211 Y55.655 F1000
G1 X151.129 Y55.695 F1000
G1 X152.047 Y55.738 F1000
G1 X152.965 Y55.784 F1000
G1 X153.883 Y55.833 F1000
G1 X154.8 Y55.886 F1000
G1 X155.718 Y55.943 F1000
G1 X156.635 Y56.004 F1000
G1 X157.551 Y56.069 F1000
G1 X158.468 Y56.139 F1000
G1 X159.384 Y56.214 F1000
G1 X160.299 Y56.294 F1000
G1 X161.214 Y56.38 F1000
G1 X162.129 Y56.473 F1000
G1 X163.042 Y56.572 F1000
G1 X163.955 Y56.68 F1000
G1 X164.866 Y56.797 F1000
G1 X165.777 Y56.924 F1000
G1 X166.685 Y57.062 F1000
G1 X167.592 Y57.214 F1000
G1 X168.495 Y57.382 F1000
G1 X169.395 Y57.568 F1000
G1 X170.29 Y57.778 F1000
G1 X171.177 Y58.018 F1000
G1 X172.051 Y58.303 F1000
G1 X172.618 Y58.539 F1000
G1 X172.932 Y58.701 F1000
G1 X173.202 Y58.88 F1000
G1 X173.427 Y59.113 F1000
G1 X173.596 Y59.39 F1000
G1 X173.701 Y59.696 F1000
G1 X173.736 Y60.018 F1000
G1 Y62.546 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y63.131 I-0.635 J-0.022 F1000
G1 X173.221 Y63.152 Z-3.012 F1000
G1 X173.153 Y63.173 Z-3 F1000
G1 X173.088 Y63.193 Z-2.98 F1000
G1 X173.025 Y63.212 Z-2.953 F1000
G1 X172.966 Y63.231 Z-2.919 F1000
G1 X172.91 Y63.248 Z-2.877 F1000
G1 X172.859 Y63.263 Z-2.83 F1000
G1 X172.814 Y63.277 Z-2.777 F1000
G1 X172.775 Y63.289 Z-2.719 F1000
G1 X172.742 Y63.3 Z-2.657 F1000
G1 X172.716 Y63.308 Z-2.591 F1000
G1 X172.697 Y63.313 Z-2.522 F1000
G1 X172.685 Y63.317 Z-2.452 F1000
G1 X172.682 Y63.318 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y70.137 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y70.134 Z-2.452 F1000
G1 X22.509 Y70.124 Z-2.522 F1000
G1 X22.499 Y70.107 Z-2.591 F1000
G1 X22.485 Y70.083 Z-2.657 F1000
G1 X22.467 Y70.054 Z-2.719 F1000
G1 X22.446 Y70.018 Z-2.777 F1000
G1 X22.422 Y69.977 Z-2.83 F1000
G1 X22.395 Y69.932 Z-2.877 F1000
G1 X22.365 Y69.882 Z-2.919 F1000
G1 X22.333 Y69.828 Z-2.953 F1000
G1 X22.3 Y69.772 Z-2.98 F1000
G1 X22.265 Y69.713 Z-3 F1000
G1 X22.229 Y69.653 Z-3.012 F1000
G1 X22.192 Y69.592 Z-3.016 F1000
G3 X21.971 Y68.838 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y66.332 F1000
G1 X21.982 Y66.118 F1000
G1 X22.014 Y65.875 F1000
G1 X22.075 Y65.586 F1000
G1 X22.168 Y65.278 F1000
G1 X22.298 Y64.944 F1000
G1 X22.484 Y64.56 F1000
G1 X22.71 Y64.175 F1000
G1 X23.021 Y63.734 F1000
G1 X23.399 Y63.278 F1000
G1 X23.883 Y62.781 F1000
G1 X24.502 Y62.242 F1000
G1 X25.24 Y61.696 F1000
G1 X26.018 Y61.206 F1000
G1 X26.825 Y60.766 F1000
G1 X27.653 Y60.368 F1000
G1 X28.498 Y60.006 F1000
G1 X29.356 Y59.676 F1000
G1 X30.223 Y59.373 F1000
G1 X31.099 Y59.095 F1000
G1 X31.982 Y58.838 F1000
G1 X32.869 Y58.6 F1000
G1 X33.761 Y58.379 F1000
G1 X34.657 Y58.173 F1000
G1 X35.556 Y57.981 F1000
G1 X36.457 Y57.8 F1000
G1 X37.36 Y57.631 F1000
G1 X38.265 Y57.472 F1000
G1 X39.172 Y57.322 F1000
G1 X40.08 Y57.18 F1000
G1 X40.989 Y57.046 F1000
G1 X41.899 Y56.919 F1000
G1 X42.81 Y56.798 F1000
G1 X43.722 Y56.684 F1000
G1 X44.635 Y56.575 F1000
G1 X45.548 Y56.471 F1000
G1 X46.462 Y56.372 F1000
G1 X47.376 Y56.278 F1000
G1 X48.29 Y56.187 F1000
G1 X49.205 Y56.101 F1000
G1 X50.121 Y56.018 F1000
G1 X51.036 Y55.938 F1000
G1 X51.952 Y55.861 F1000
G1 X52.868 Y55.787 F1000
G1 X53.784 Y55.716 F1000
G1 X54.701 Y55.648 F1000
G1 X55.617 Y55.581 F1000
G1 X56.534 Y55.517 F1000
G1 X57.451 Y55.454 F1000
G1 X58.368 Y55.394 F1000
G1 X59.285 Y55.335 F1000
G1 X60.202 Y55.278 F1000
G1 X61.12 Y55.222 F1000
G1 X62.037 Y55.167 F1000
G1 X62.955 Y55.114 F1000
G1 X63.872 Y55.062 F1000
G1 X65.707 Y54.96 F1000
G1 X67.543 Y54.862 F1000
G1 X69.378 Y54.767 F1000
G1 X71.214 Y54.675 F1000
G1 X73.968 Y54.539 F1000
G1 X76.722 Y54.408 F1000
G1 X79.476 Y54.28 F1000
G1 X82.23 Y54.155 F1000
G1 X84.984 Y54.033 F1000
G1 X87.739 Y53.914 F1000
G1 X90.494 Y53.798 F1000
G1 X93.248 Y53.687 F1000
G1 X95.085 Y53.615 F1000
G1 X96.922 Y53.545 F1000
G1 X98.759 Y53.477 F1000
G1 X100.595 Y53.412 F1000
G1 X102.432 Y53.349 F1000
G1 X104.269 Y53.288 F1000
G1 X106.107 Y53.231 F1000
G1 X107.944 Y53.176 F1000
G1 X109.781 Y53.125 F1000
G1 X111.618 Y53.076 F1000
G1 X113.456 Y53.031 F1000
G1 X115.294 Y52.99 F1000
G1 X117.131 Y52.952 F1000
G1 X118.969 Y52.917 F1000
G1 X119.888 Y52.901 F1000
G1 X121.726 Y52.873 F1000
G1 X122.645 Y52.86 F1000
G1 X123.563 Y52.848 F1000
G1 X124.482 Y52.837 F1000
G1 X125.401 Y52.828 F1000
G1 X126.32 Y52.819 F1000
G1 X127.239 Y52.812 F1000
G1 X128.158 Y52.806 F1000
G1 X129.077 Y52.801 F1000
G1 X129.996 Y52.797 F1000
G1 X130.915 Y52.795 F1000
G1 X131.834 Y52.794 F1000
G1 X132.753 F1000
G1 X133.672 Y52.795 F1000
G1 X134.592 Y52.798 F1000
G1 X135.511 Y52.803 F1000
G1 X136.43 Y52.809 F1000
G1 X137.349 Y52.816 F1000
G1 X138.267 Y52.826 F1000
G1 X139.186 Y52.836 F1000
G1 X140.105 Y52.849 F1000
G1 X141.024 Y52.863 F1000
G1 X141.943 Y52.88 F1000
G1 X142.862 Y52.898 F1000
G1 X143.781 Y52.918 F1000
G1 X144.7 Y52.94 F1000
G1 X145.618 Y52.965 F1000
G1 X146.537 Y52.992 F1000
G1 X147.455 Y53.021 F1000
G1 X148.374 Y53.053 F1000
G1 X149.292 Y53.087 F1000
G1 X150.211 Y53.124 F1000
G1 X151.129 Y53.164 F1000
G1 X152.047 Y53.207 F1000
G1 X152.965 Y53.253 F1000
G1 X153.882 Y53.303 F1000
G1 X154.8 Y53.356 F1000
G1 X155.717 Y53.413 F1000
G1 X156.634 Y53.474 F1000
G1 X157.551 Y53.539 F1000
G1 X158.467 Y53.609 F1000
G1 X159.383 Y53.684 F1000
G1 X160.299 Y53.764 F1000
G1 X161.213 Y53.851 F1000
G1 X162.128 Y53.943 F1000
G1 X163.041 Y54.043 F1000
G1 X163.954 Y54.151 F1000
G1 X164.866 Y54.268 F1000
G1 X165.776 Y54.395 F1000
G1 X166.684 Y54.534 F1000
G1 X167.591 Y54.685 F1000
G1 X168.494 Y54.853 F1000
G1 X169.394 Y55.039 F1000
G1 X170.289 Y55.249 F1000
G1 X171.176 Y55.49 F1000
G1 X172.05 Y55.774 F1000
G1 X172.617 Y56.011 F1000
G1 X172.932 Y56.173 F1000
G1 X173.202 Y56.351 F1000
G1 X173.427 Y56.585 F1000
G1 X173.596 Y56.861 F1000
G1 X173.701 Y57.168 F1000
G1 X173.736 Y57.49 F1000
G1 Y60.018 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y60.603 I-0.635 J-0.022 F1000
G1 X173.221 Y60.624 Z-3.012 F1000
G1 X173.153 Y60.645 Z-3 F1000
G1 X173.088 Y60.665 Z-2.98 F1000
G1 X173.025 Y60.684 Z-2.953 F1000
G1 X172.966 Y60.703 Z-2.919 F1000
G1 X172.91 Y60.72 Z-2.877 F1000
G1 X172.859 Y60.735 Z-2.83 F1000
G1 X172.814 Y60.749 Z-2.777 F1000
G1 X172.775 Y60.761 Z-2.719 F1000
G1 X172.742 Y60.772 Z-2.657 F1000
G1 X172.716 Y60.78 Z-2.591 F1000
G1 X172.697 Y60.785 Z-2.522 F1000
G1 X172.685 Y60.789 Z-2.452 F1000
G1 X172.682 Y60.79 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y67.631 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y67.628 Z-2.452 F1000
G1 X22.509 Y67.618 Z-2.522 F1000
G1 X22.499 Y67.601 Z-2.591 F1000
G1 X22.485 Y67.577 Z-2.657 F1000
G1 X22.467 Y67.548 Z-2.719 F1000
G1 X22.446 Y67.512 Z-2.777 F1000
G1 X22.422 Y67.471 Z-2.83 F1000
G1 X22.395 Y67.426 Z-2.877 F1000
G1 X22.365 Y67.376 Z-2.919 F1000
G1 X22.333 Y67.322 Z-2.953 F1000
G1 X22.3 Y67.266 Z-2.98 F1000
G1 X22.265 Y67.207 Z-3 F1000
G1 X22.229 Y67.147 Z-3.012 F1000
G1 X22.192 Y67.086 Z-3.016 F1000
G3 X21.971 Y66.332 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y63.826 F1000
G1 X21.983 Y63.59 F1000
G1 X22.015 Y63.347 F1000
G1 X22.076 Y63.059 F1000
G1 X22.169 Y62.75 F1000
G1 X22.299 Y62.416 F1000
G1 X22.485 Y62.033 F1000
G1 X22.712 Y61.648 F1000
G1 X23.022 Y61.206 F1000
G1 X23.4 Y60.75 F1000
G1 X23.885 Y60.254 F1000
G1 X24.503 Y59.715 F1000
G1 X25.242 Y59.168 F1000
G1 X26.019 Y58.679 F1000
G1 X26.826 Y58.238 F1000
G1 X27.654 Y57.84 F1000
G1 X28.499 Y57.478 F1000
G1 X29.357 Y57.148 F1000
G1 X30.225 Y56.845 F1000
G1 X31.1 Y56.567 F1000
G1 X31.983 Y56.31 F1000
G1 X32.87 Y56.072 F1000
G1 X33.762 Y55.85 F1000
G1 X34.658 Y55.644 F1000
G1 X35.556 Y55.451 F1000
G1 X36.458 Y55.271 F1000
G1 X37.361 Y55.101 F1000
G1 X38.266 Y54.942 F1000
G1 X39.173 Y54.791 F1000
G1 X40.081 Y54.649 F1000
G1 X40.99 Y54.515 F1000
G1 X41.9 Y54.388 F1000
G1 X42.811 Y54.267 F1000
G1 X43.723 Y54.152 F1000
G1 X44.635 Y54.043 F1000
G1 X45.548 Y53.939 F1000
G1 X46.462 Y53.84 F1000
G1 X47.376 Y53.745 F1000
G1 X48.291 Y53.654 F1000
G1 X49.205 Y53.567 F1000
G1 X50.121 Y53.484 F1000
G1 X51.036 Y53.403 F1000
G1 X51.952 Y53.326 F1000
G1 X52.868 Y53.252 F1000
G1 X53.784 Y53.181 F1000
G1 X54.701 Y53.112 F1000
G1 X55.617 Y53.045 F1000
G1 X56.534 Y52.98 F1000
G1 X57.451 Y52.918 F1000
G1 X58.368 Y52.857 F1000
G1 X59.285 Y52.798 F1000
G1 X60.202 Y52.74 F1000
G1 X61.12 Y52.684 F1000
G1 X62.037 Y52.629 F1000
G1 X62.954 Y52.575 F1000
G1 X63.872 Y52.523 F1000
G1 X65.707 Y52.421 F1000
G1 X67.543 Y52.322 F1000
G1 X68.46 Y52.274 F1000
G1 X70.296 Y52.18 F1000
G1 X72.132 Y52.088 F1000
G1 X74.885 Y51.954 F1000
G1 X77.639 Y51.824 F1000
G1 X80.394 Y51.697 F1000
G1 X83.148 Y51.573 F1000
G1 X85.902 Y51.452 F1000
G1 X88.657 Y51.334 F1000
G1 X91.412 Y51.22 F1000
G1 X94.166 Y51.11 F1000
G1 X96.003 Y51.04 F1000
G1 X97.84 Y50.971 F1000
G1 X99.677 Y50.905 F1000
G1 X101.514 Y50.841 F1000
G1 X103.351 Y50.78 F1000
G1 X105.188 Y50.721 F1000
G1 X107.025 Y50.665 F1000
G1 X108.862 Y50.612 F1000
G1 X110.7 Y50.563 F1000
G1 X112.537 Y50.516 F1000
G1 X114.375 Y50.473 F1000
G1 X116.212 Y50.433 F1000
G1 X118.05 Y50.397 F1000
G1 X118.969 Y50.381 F1000
G1 X120.806 Y50.35 F1000
G1 X121.725 Y50.336 F1000
G1 X122.644 Y50.324 F1000
G1 X123.563 Y50.312 F1000
G1 X124.482 Y50.302 F1000
G1 X125.401 Y50.292 F1000
G1 X126.32 Y50.284 F1000
G1 X127.239 Y50.277 F1000
G1 X128.158 Y50.271 F1000
G1 X129.077 Y50.266 F1000
G1 X129.996 Y50.262 F1000
G1 X130.915 Y50.26 F1000
G1 X131.834 Y50.259 F1000
G1 X132.753 F1000
G1 X133.672 Y50.261 F1000
G1 X134.591 Y50.264 F1000
G1 X135.51 Y50.269 F1000
G1 X136.429 Y50.275 F1000
G1 X137.348 Y50.283 F1000
G1 X138.267 Y50.292 F1000
G1 X139.186 Y50.303 F1000
G1 X140.105 Y50.316 F1000
G1 X141.024 Y50.33 F1000
G1 X141.943 Y50.347 F1000
G1 X142.862 Y50.365 F1000
G1 X143.781 Y50.386 F1000
G1 X144.699 Y50.408 F1000
G1 X145.618 Y50.433 F1000
G1 X146.537 Y50.46 F1000
G1 X147.455 Y50.489 F1000
G1 X148.374 Y50.521 F1000
G1 X149.292 Y50.556 F1000
G1 X150.21 Y50.593 F1000
G1 X151.128 Y50.633 F1000
G1 X152.046 Y50.676 F1000
G1 X152.964 Y50.722 F1000
G1 X153.882 Y50.772 F1000
G1 X154.799 Y50.825 F1000
G1 X155.717 Y50.882 F1000
G1 X156.634 Y50.944 F1000
G1 X157.55 Y51.009 F1000
G1 X158.467 Y51.079 F1000
G1 X159.383 Y51.154 F1000
G1 X160.298 Y51.235 F1000
G1 X161.213 Y51.321 F1000
G1 X162.127 Y51.414 F1000
G1 X163.041 Y51.514 F1000
G1 X163.954 Y51.622 F1000
G1 X164.865 Y51.739 F1000
G1 X165.775 Y51.866 F1000
G1 X166.684 Y52.005 F1000
G1 X167.59 Y52.157 F1000
G1 X168.494 Y52.324 F1000
G1 X169.394 Y52.511 F1000
G1 X170.288 Y52.721 F1000
G1 X171.175 Y52.961 F1000
G1 X172.049 Y53.246 F1000
G1 X172.617 Y53.482 F1000
G1 X172.932 Y53.644 F1000
G1 X173.202 Y53.823 F1000
G1 X173.427 Y54.057 F1000
G1 X173.596 Y54.333 F1000
G1 X173.701 Y54.64 F1000
G1 X173.736 Y54.962 F1000
G1 Y57.49 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y58.075 I-0.635 J-0.022 F1000
G1 X173.221 Y58.096 Z-3.012 F1000
G1 X173.153 Y58.116 Z-3 F1000
G1 X173.088 Y58.137 Z-2.98 F1000
G1 X173.025 Y58.156 Z-2.953 F1000
G1 X172.966 Y58.174 Z-2.919 F1000
G1 X172.91 Y58.191 Z-2.877 F1000
G1 X172.859 Y58.207 Z-2.83 F1000
G1 X172.814 Y58.221 Z-2.777 F1000
G1 X172.775 Y58.233 Z-2.719 F1000
G1 X172.742 Y58.243 Z-2.657 F1000
G1 X172.716 Y58.251 Z-2.591 F1000
G1 X172.697 Y58.257 Z-2.522 F1000
G1 X172.685 Y58.261 Z-2.452 F1000
G1 X172.682 Y58.262 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y65.125 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y65.122 Z-2.452 F1000
G1 X22.509 Y65.112 Z-2.522 F1000
G1 X22.499 Y65.095 Z-2.591 F1000
G1 X22.485 Y65.071 Z-2.657 F1000
G1 X22.467 Y65.042 Z-2.719 F1000
G1 X22.446 Y65.006 Z-2.777 F1000
G1 X22.422 Y64.965 Z-2.83 F1000
G1 X22.395 Y64.92 Z-2.877 F1000
G1 X22.365 Y64.87 Z-2.919 F1000
G1 X22.333 Y64.816 Z-2.953 F1000
G1 X22.3 Y64.76 Z-2.98 F1000
G1 X22.265 Y64.701 Z-3 F1000
G1 X22.229 Y64.641 Z-3.012 F1000
G1 X22.192 Y64.58 Z-3.016 F1000
G3 X21.971 Y63.826 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y61.32 F1000
G1 X21.984 Y61.063 F1000
G1 X22.016 Y60.82 F1000
G1 X22.077 Y60.531 F1000
G1 X22.17 Y60.223 F1000
G1 X22.3 Y59.889 F1000
G1 X22.486 Y59.505 F1000
G1 X22.713 Y59.12 F1000
G1 X23.023 Y58.678 F1000
G1 X23.401 Y58.223 F1000
G1 X23.886 Y57.726 F1000
G1 X24.504 Y57.187 F1000
G1 X25.243 Y56.64 F1000
G1 X26.021 Y56.151 F1000
G1 X26.827 Y55.71 F1000
G1 X27.656 Y55.312 F1000
G1 X28.5 Y54.95 F1000
G1 X29.358 Y54.62 F1000
G1 X30.226 Y54.317 F1000
G1 X31.102 Y54.038 F1000
G1 X31.984 Y53.781 F1000
G1 X32.871 Y53.543 F1000
G1 X33.763 Y53.321 F1000
G1 X34.659 Y53.115 F1000
G1 X35.557 Y52.922 F1000
G1 X36.458 Y52.741 F1000
G1 X37.362 Y52.571 F1000
G1 X38.267 Y52.412 F1000
G1 X39.173 Y52.261 F1000
G1 X40.081 Y52.119 F1000
G1 X40.99 Y51.984 F1000
G1 X41.9 Y51.856 F1000
G1 X42.811 Y51.735 F1000
G1 X43.723 Y51.62 F1000
G1 X44.636 Y51.511 F1000
G1 X45.549 Y51.406 F1000
G1 X46.462 Y51.307 F1000
G1 X47.376 Y51.211 F1000
G1 X48.291 Y51.12 F1000
G1 X49.206 Y51.033 F1000
G1 X50.121 Y50.949 F1000
G1 X51.037 Y50.869 F1000
G1 X51.952 Y50.791 F1000
G1 X52.868 Y50.717 F1000
G1 X53.784 Y50.645 F1000
G1 X54.701 Y50.576 F1000
G1 X55.617 Y50.509 F1000
G1 X56.534 Y50.444 F1000
G1 X57.451 Y50.381 F1000
G1 X58.368 Y50.319 F1000
G1 X59.285 Y50.26 F1000
G1 X60.202 Y50.202 F1000
G1 X61.12 Y50.146 F1000
G1 X62.037 Y50.091 F1000
G1 X62.954 Y50.037 F1000
G1 X63.872 Y49.984 F1000
G1 X65.707 Y49.881 F1000
G1 X67.542 Y49.783 F1000
G1 X68.46 Y49.734 F1000
G1 X70.296 Y49.64 F1000
G1 X72.132 Y49.548 F1000
G1 X74.885 Y49.413 F1000
G1 X77.639 Y49.283 F1000
G1 X80.393 Y49.156 F1000
G1 X83.148 Y49.032 F1000
G1 X85.902 Y48.911 F1000
G1 X88.657 Y48.794 F1000
G1 X91.411 Y48.68 F1000
G1 X94.166 Y48.57 F1000
G1 X96.003 Y48.5 F1000
G1 X97.84 Y48.432 F1000
G1 X99.677 Y48.366 F1000
G1 X101.514 Y48.302 F1000
G1 X103.351 Y48.241 F1000
G1 X105.188 Y48.183 F1000
G1 X107.025 Y48.127 F1000
G1 X108.862 Y48.074 F1000
G1 X110.7 Y48.025 F1000
G1 X112.537 Y47.979 F1000
G1 X114.375 Y47.936 F1000
G1 X116.212 Y47.896 F1000
G1 X118.05 Y47.861 F1000
G1 X118.969 Y47.844 F1000
G1 X120.807 Y47.814 F1000
G1 X121.725 Y47.8 F1000
G1 X122.644 Y47.788 F1000
G1 X123.563 Y47.776 F1000
G1 X124.482 Y47.766 F1000
G1 X125.401 Y47.757 F1000
G1 X126.32 Y47.748 F1000
G1 X127.239 Y47.741 F1000
G1 X128.158 Y47.735 F1000
G1 X129.077 Y47.731 F1000
G1 X129.996 Y47.727 F1000
G1 X130.915 Y47.725 F1000
G1 X131.834 Y47.724 F1000
G1 X132.753 Y47.725 F1000
G1 X133.672 Y47.727 F1000
G1 X134.591 Y47.73 F1000
G1 X135.51 Y47.735 F1000
G1 X136.429 Y47.741 F1000
G1 X137.348 Y47.749 F1000
G1 X138.267 Y47.758 F1000
G1 X139.186 Y47.77 F1000
G1 X140.105 Y47.782 F1000
G1 X141.024 Y47.797 F1000
G1 X141.943 Y47.814 F1000
G1 X142.862 Y47.832 F1000
G1 X143.781 Y47.853 F1000
G1 X144.699 Y47.876 F1000
G1 X145.618 Y47.901 F1000
G1 X146.537 Y47.928 F1000
G1 X147.455 Y47.957 F1000
G1 X148.374 Y47.989 F1000
G1 X149.292 Y48.024 F1000
G1 X150.21 Y48.061 F1000
G1 X151.128 Y48.102 F1000
G1 X152.046 Y48.145 F1000
G1 X152.964 Y48.191 F1000
G1 X153.882 Y48.241 F1000
G1 X154.799 Y48.295 F1000
G1 X155.717 Y48.352 F1000
G1 X156.634 Y48.413 F1000
G1 X157.55 Y48.479 F1000
G1 X158.467 Y48.549 F1000
G1 X159.383 Y48.624 F1000
G1 X160.298 Y48.705 F1000
G1 X161.213 Y48.792 F1000
G1 X162.127 Y48.885 F1000
G1 X163.041 Y48.985 F1000
G1 X163.953 Y49.093 F1000
G1 X164.865 Y49.21 F1000
G1 X165.775 Y49.337 F1000
G1 X166.684 Y49.476 F1000
G1 X167.59 Y49.628 F1000
G1 X168.494 Y49.796 F1000
G1 X169.393 Y49.982 F1000
G1 X170.288 Y50.192 F1000
G1 X171.175 Y50.433 F1000
G1 X172.049 Y50.717 F1000
G1 X172.617 Y50.954 F1000
G1 X172.932 Y51.116 F1000
G1 X173.202 Y51.295 F1000
G1 X173.427 Y51.528 F1000
G1 X173.596 Y51.805 F1000
G1 X173.701 Y52.112 F1000
G1 X173.736 Y52.434 F1000
G1 Y54.962 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y55.547 I-0.635 J-0.022 F1000
G1 X173.221 Y55.568 Z-3.012 F1000
G1 X173.153 Y55.588 Z-3 F1000
G1 X173.088 Y55.608 Z-2.98 F1000
G1 X173.025 Y55.628 Z-2.953 F1000
G1 X172.966 Y55.646 Z-2.919 F1000
G1 X172.91 Y55.663 Z-2.877 F1000
G1 X172.859 Y55.679 Z-2.83 F1000
G1 X172.814 Y55.693 Z-2.777 F1000
G1 X172.775 Y55.705 Z-2.719 F1000
G1 X172.742 Y55.715 Z-2.657 F1000
G1 X172.716 Y55.723 Z-2.591 F1000
G1 X172.697 Y55.729 Z-2.522 F1000
G1 X172.685 Y55.733 Z-2.452 F1000
G1 X172.682 Y55.734 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y62.619 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y62.616 Z-2.452 F1000
G1 X22.509 Y62.606 Z-2.522 F1000
G1 X22.499 Y62.589 Z-2.591 F1000
G1 X22.485 Y62.565 Z-2.657 F1000
G1 X22.467 Y62.536 Z-2.719 F1000
G1 X22.446 Y62.5 Z-2.777 F1000
G1 X22.422 Y62.459 Z-2.83 F1000
G1 X22.395 Y62.414 Z-2.877 F1000
G1 X22.365 Y62.364 Z-2.919 F1000
G1 X22.333 Y62.31 Z-2.953 F1000
G1 X22.3 Y62.254 Z-2.98 F1000
G1 X22.265 Y62.195 Z-3 F1000
G1 X22.229 Y62.135 Z-3.012 F1000
G1 X22.192 Y62.073 Z-3.016 F1000
G3 X21.971 Y61.32 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y58.814 F1000
G1 X21.985 Y58.535 F1000
G1 X22.017 Y58.292 F1000
G1 X22.079 Y58.003 F1000
G1 X22.171 Y57.695 F1000
G1 X22.301 Y57.361 F1000
G1 X22.487 Y56.977 F1000
G1 X22.714 Y56.592 F1000
G1 X23.024 Y56.151 F1000
G1 X23.403 Y55.695 F1000
G1 X23.887 Y55.198 F1000
G1 X24.506 Y54.659 F1000
G1 X25.244 Y54.112 F1000
G1 X26.022 Y53.623 F1000
G1 X26.829 Y53.182 F1000
G1 X27.657 Y52.784 F1000
G1 X28.502 Y52.422 F1000
G1 X29.359 Y52.091 F1000
G1 X30.227 Y51.788 F1000
G1 X31.103 Y51.51 F1000
G1 X31.985 Y51.252 F1000
G1 X32.873 Y51.014 F1000
G1 X33.764 Y50.792 F1000
G1 X34.66 Y50.586 F1000
G1 X35.558 Y50.392 F1000
G1 X36.459 Y50.211 F1000
G1 X37.363 Y50.041 F1000
G1 X38.268 Y49.881 F1000
G1 X39.174 Y49.73 F1000
G1 X40.082 Y49.588 F1000
G1 X40.991 Y49.453 F1000
G1 X41.901 Y49.325 F1000
G1 X42.812 Y49.204 F1000
G1 X43.724 Y49.088 F1000
G1 X44.636 Y48.978 F1000
G1 X45.549 Y48.874 F1000
G1 X46.463 Y48.774 F1000
G1 X47.377 Y48.678 F1000
G1 X48.291 Y48.587 F1000
G1 X49.206 Y48.499 F1000
G1 X50.121 Y48.415 F1000
G1 X51.037 Y48.334 F1000
G1 X51.953 Y48.256 F1000
G1 X52.869 Y48.182 F1000
G1 X53.785 Y48.109 F1000
G1 X54.701 Y48.04 F1000
G1 X55.618 Y47.972 F1000
G1 X56.534 Y47.907 F1000
G1 X57.451 Y47.844 F1000
G1 X58.368 Y47.782 F1000
G1 X59.285 Y47.722 F1000
G1 X60.202 Y47.664 F1000
G1 X61.12 Y47.607 F1000
G1 X62.037 Y47.552 F1000
G1 X62.954 Y47.498 F1000
G1 X63.872 Y47.445 F1000
G1 X65.707 Y47.342 F1000
G1 X67.542 Y47.243 F1000
G1 X68.46 Y47.194 F1000
G1 X70.296 Y47.099 F1000
G1 X72.132 Y47.007 F1000
G1 X74.885 Y46.872 F1000
G1 X77.639 Y46.742 F1000
G1 X80.393 Y46.615 F1000
G1 X83.148 Y46.491 F1000
G1 X85.902 Y46.37 F1000
G1 X88.657 Y46.253 F1000
G1 X91.411 Y46.14 F1000
G1 X94.166 Y46.031 F1000
G1 X96.003 Y45.96 F1000
G1 X97.84 Y45.892 F1000
G1 X99.677 Y45.826 F1000
G1 X101.514 Y45.763 F1000
G1 X103.351 Y45.702 F1000
G1 X105.188 Y45.644 F1000
G1 X107.025 Y45.589 F1000
G1 X108.862 Y45.537 F1000
G1 X110.7 Y45.487 F1000
G1 X112.537 Y45.441 F1000
G1 X114.375 Y45.399 F1000
G1 X116.212 Y45.359 F1000
G1 X118.05 Y45.324 F1000
G1 X118.969 Y45.307 F1000
G1 X120.807 Y45.278 F1000
G1 X121.726 Y45.264 F1000
G1 X122.644 Y45.252 F1000
G1 X123.563 Y45.24 F1000
G1 X124.482 Y45.23 F1000
G1 X125.401 Y45.221 F1000
G1 X126.32 Y45.213 F1000
G1 X127.239 Y45.206 F1000
G1 X128.158 Y45.2 F1000
G1 X129.077 Y45.196 F1000
G1 X129.996 Y45.192 F1000
G1 X130.915 Y45.19 F1000
G1 X131.834 Y45.189 F1000
G1 X132.753 Y45.19 F1000
G1 X133.672 Y45.192 F1000
G1 X134.591 Y45.196 F1000
G1 X135.51 Y45.201 F1000
G1 X136.429 Y45.207 F1000
G1 X137.348 Y45.215 F1000
G1 X138.267 Y45.225 F1000
G1 X139.186 Y45.236 F1000
G1 X140.105 Y45.249 F1000
G1 X141.024 Y45.264 F1000
G1 X141.943 Y45.281 F1000
G1 X142.862 Y45.3 F1000
G1 X143.781 Y45.32 F1000
G1 X144.699 Y45.343 F1000
G1 X145.618 Y45.368 F1000
G1 X146.537 Y45.396 F1000
G1 X147.455 Y45.425 F1000
G1 X148.374 Y45.458 F1000
G1 X149.292 Y45.492 F1000
G1 X150.21 Y45.53 F1000
G1 X151.128 Y45.57 F1000
G1 X152.046 Y45.614 F1000
G1 X152.964 Y45.661 F1000
G1 X153.882 Y45.711 F1000
G1 X154.799 Y45.764 F1000
G1 X155.717 Y45.822 F1000
G1 X156.634 Y45.883 F1000
G1 X157.55 Y45.949 F1000
G1 X158.467 Y46.019 F1000
G1 X159.382 Y46.095 F1000
G1 X160.298 Y46.175 F1000
G1 X161.213 Y46.262 F1000
G1 X162.127 Y46.355 F1000
G1 X163.041 Y46.456 F1000
G1 X163.953 Y46.564 F1000
G1 X164.865 Y46.681 F1000
G1 X165.775 Y46.808 F1000
G1 X166.683 Y46.947 F1000
G1 X167.59 Y47.099 F1000
G1 X168.493 Y47.267 F1000
G1 X169.393 Y47.454 F1000
G1 X170.288 Y47.664 F1000
G1 X171.175 Y47.904 F1000
G1 X172.049 Y48.189 F1000
G1 X172.616 Y48.425 F1000
G1 X172.932 Y48.588 F1000
G1 X173.202 Y48.766 F1000
G1 X173.427 Y49 F1000
G1 X173.596 Y49.276 F1000
G1 X173.701 Y49.583 F1000
G1 X173.736 Y49.905 F1000
G1 Y52.434 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y53.018 I-0.635 J-0.022 F1000
G1 X173.221 Y53.039 Z-3.012 F1000
G1 X173.153 Y53.06 Z-3 F1000
G1 X173.088 Y53.08 Z-2.98 F1000
G1 X173.025 Y53.099 Z-2.953 F1000
G1 X172.966 Y53.118 Z-2.919 F1000
G1 X172.91 Y53.135 Z-2.877 F1000
G1 X172.859 Y53.151 Z-2.83 F1000
G1 X172.814 Y53.165 Z-2.777 F1000
G1 X172.775 Y53.177 Z-2.719 F1000
G1 X172.742 Y53.187 Z-2.657 F1000
G1 X172.716 Y53.195 Z-2.591 F1000
G1 X172.697 Y53.201 Z-2.522 F1000
G1 X172.685 Y53.204 Z-2.452 F1000
G1 X172.682 Y53.205 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y60.113 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y60.11 Z-2.452 F1000
G1 X22.509 Y60.1 Z-2.522 F1000
G1 X22.499 Y60.083 Z-2.591 F1000
G1 X22.485 Y60.059 Z-2.657 F1000
G1 X22.467 Y60.03 Z-2.719 F1000
G1 X22.446 Y59.994 Z-2.777 F1000
G1 X22.422 Y59.953 Z-2.83 F1000
G1 X22.395 Y59.908 Z-2.877 F1000
G1 X22.365 Y59.858 Z-2.919 F1000
G1 X22.333 Y59.804 Z-2.953 F1000
G1 X22.3 Y59.748 Z-2.98 F1000
G1 X22.265 Y59.689 Z-3 F1000
G1 X22.229 Y59.629 Z-3.012 F1000
G1 X22.192 Y59.567 Z-3.016 F1000
G3 X21.971 Y58.814 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y56.308 F1000
G1 X21.986 Y56.007 F1000
G1 X22.018 Y55.764 F1000
G1 X22.08 Y55.476 F1000
G1 X22.172 Y55.167 F1000
G1 X22.302 Y54.833 F1000
G1 X22.488 Y54.449 F1000
G1 X22.715 Y54.065 F1000
G1 X23.025 Y53.623 F1000
G1 X23.404 Y53.167 F1000
G1 X23.888 Y52.67 F1000
G1 X24.507 Y52.13 F1000
G1 X25.246 Y51.584 F1000
G1 X26.024 Y51.094 F1000
G1 X26.83 Y50.654 F1000
G1 X27.659 Y50.255 F1000
G1 X28.503 Y49.893 F1000
G1 X29.361 Y49.563 F1000
G1 X30.228 Y49.26 F1000
G1 X31.104 Y48.981 F1000
G1 X31.986 Y48.723 F1000
G1 X32.874 Y48.485 F1000
G1 X33.766 Y48.263 F1000
G1 X34.661 Y48.056 F1000
G1 X35.56 Y47.863 F1000
G1 X36.461 Y47.681 F1000
G1 X37.364 Y47.511 F1000
G1 X38.269 Y47.351 F1000
G1 X39.175 Y47.2 F1000
G1 X40.083 Y47.057 F1000
G1 X40.992 Y46.922 F1000
G1 X41.902 Y46.794 F1000
G1 X42.813 Y46.672 F1000
G1 X43.725 Y46.556 F1000
G1 X44.637 Y46.446 F1000
G1 X45.55 Y46.341 F1000
G1 X46.464 Y46.241 F1000
G1 X47.378 Y46.145 F1000
G1 X48.292 Y46.053 F1000
G1 X49.207 Y45.965 F1000
G1 X50.122 Y45.881 F1000
G1 X51.037 Y45.799 F1000
G1 X51.953 Y45.721 F1000
G1 X52.869 Y45.646 F1000
G1 X53.785 Y45.574 F1000
G1 X54.701 Y45.504 F1000
G1 X55.618 Y45.436 F1000
G1 X56.535 Y45.37 F1000
G1 X57.451 Y45.307 F1000
G1 X58.368 Y45.245 F1000
G1 X59.285 Y45.185 F1000
G1 X60.203 Y45.126 F1000
G1 X61.12 Y45.069 F1000
G1 X62.037 Y45.014 F1000
G1 X62.955 Y44.959 F1000
G1 X63.872 Y44.906 F1000
G1 X65.707 Y44.803 F1000
G1 X67.543 Y44.703 F1000
G1 X68.46 Y44.654 F1000
G1 X70.296 Y44.559 F1000
G1 X72.132 Y44.467 F1000
G1 X74.885 Y44.332 F1000
G1 X77.639 Y44.201 F1000
G1 X80.393 Y44.074 F1000
G1 X83.148 Y43.95 F1000
G1 X85.902 Y43.829 F1000
G1 X88.657 Y43.712 F1000
G1 X91.411 Y43.599 F1000
G1 X94.166 Y43.491 F1000
G1 X96.003 Y43.421 F1000
G1 X97.84 Y43.353 F1000
G1 X99.677 Y43.287 F1000
G1 X101.514 Y43.224 F1000
G1 X103.351 Y43.164 F1000
G1 X105.188 Y43.106 F1000
G1 X107.025 Y43.051 F1000
G1 X108.862 Y42.999 F1000
G1 X110.7 Y42.95 F1000
G1 X112.537 Y42.904 F1000
G1 X114.375 Y42.861 F1000
G1 X116.212 Y42.823 F1000
G1 X118.05 Y42.787 F1000
G1 X118.969 Y42.771 F1000
G1 X120.807 Y42.741 F1000
G1 X121.726 Y42.728 F1000
G1 X122.645 Y42.716 F1000
G1 X123.564 Y42.704 F1000
G1 X124.483 Y42.694 F1000
G1 X125.402 Y42.685 F1000
G1 X126.321 Y42.677 F1000
G1 X127.24 Y42.67 F1000
G1 X128.159 Y42.665 F1000
G1 X129.078 Y42.66 F1000
G1 X129.997 Y42.657 F1000
G1 X130.916 Y42.655 F1000
G1 X131.835 F1000
G1 X132.754 Y42.656 F1000
G1 X133.673 Y42.658 F1000
G1 X134.592 Y42.661 F1000
G1 X135.511 Y42.666 F1000
G1 X136.43 Y42.673 F1000
G1 X137.349 Y42.681 F1000
G1 X138.268 Y42.691 F1000
G1 X139.187 Y42.703 F1000
G1 X140.105 Y42.716 F1000
G1 X141.024 Y42.731 F1000
G1 X141.943 Y42.748 F1000
G1 X142.862 Y42.767 F1000
G1 X143.781 Y42.788 F1000
G1 X144.7 Y42.811 F1000
G1 X145.618 Y42.836 F1000
G1 X146.537 Y42.864 F1000
G1 X147.455 Y42.893 F1000
G1 X148.374 Y42.926 F1000
G1 X149.292 Y42.961 F1000
G1 X150.21 Y42.999 F1000
G1 X151.129 Y43.039 F1000
G1 X152.047 Y43.083 F1000
G1 X152.964 Y43.13 F1000
G1 X153.882 Y43.18 F1000
G1 X154.799 Y43.234 F1000
G1 X155.717 Y43.291 F1000
G1 X156.634 Y43.353 F1000
G1 X157.55 Y43.419 F1000
G1 X158.467 Y43.489 F1000
G1 X159.383 Y43.565 F1000
G1 X160.298 Y43.646 F1000
G1 X161.213 Y43.733 F1000
G1 X162.127 Y43.826 F1000
G1 X163.041 Y43.926 F1000
G1 X163.953 Y44.035 F1000
G1 X164.865 Y44.152 F1000
G1 X165.775 Y44.279 F1000
G1 X166.683 Y44.418 F1000
G1 X167.59 Y44.57 F1000
G1 X168.493 Y44.738 F1000
G1 X169.393 Y44.925 F1000
G1 X170.288 Y45.135 F1000
G1 X171.175 Y45.375 F1000
G1 X172.049 Y45.66 F1000
G1 X172.616 Y45.897 F1000
G1 X172.932 Y46.059 F1000
G1 X173.202 Y46.238 F1000
G1 X173.427 Y46.471 F1000
G1 X173.596 Y46.748 F1000
G1 X173.701 Y47.055 F1000
G1 X173.736 Y47.377 F1000
G1 Y49.905 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y50.49 I-0.635 J-0.022 F1000
G1 X173.221 Y50.511 Z-3.012 F1000
G1 X173.153 Y50.532 Z-3 F1000
G1 X173.088 Y50.552 Z-2.98 F1000
G1 X173.025 Y50.571 Z-2.953 F1000
G1 X172.966 Y50.589 Z-2.919 F1000
G1 X172.91 Y50.607 Z-2.877 F1000
G1 X172.859 Y50.622 Z-2.83 F1000
G1 X172.814 Y50.636 Z-2.777 F1000
G1 X172.775 Y50.648 Z-2.719 F1000
G1 X172.742 Y50.658 Z-2.657 F1000
G1 X172.716 Y50.666 Z-2.591 F1000
G1 X172.697 Y50.672 Z-2.522 F1000
G1 X172.685 Y50.676 Z-2.452 F1000
G1 X172.682 Y50.677 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y57.607 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y57.604 Z-2.452 F1000
G1 X22.509 Y57.594 Z-2.522 F1000
G1 X22.499 Y57.577 Z-2.591 F1000
G1 X22.485 Y57.553 Z-2.657 F1000
G1 X22.467 Y57.524 Z-2.719 F1000
G1 X22.446 Y57.488 Z-2.777 F1000
G1 X22.422 Y57.447 Z-2.83 F1000
G1 X22.395 Y57.402 Z-2.877 F1000
G1 X22.365 Y57.352 Z-2.919 F1000
G1 X22.333 Y57.298 Z-2.953 F1000
G1 X22.3 Y57.242 Z-2.98 F1000
G1 X22.265 Y57.183 Z-3 F1000
G1 X22.229 Y57.123 Z-3.012 F1000
G1 X22.192 Y57.061 Z-3.016 F1000
G3 X21.971 Y56.308 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y53.802 F1000
G1 X21.987 Y53.479 F1000
G1 X22.019 Y53.236 F1000
G1 X22.081 Y52.948 F1000
G1 X22.173 Y52.639 F1000
G1 X22.303 Y52.305 F1000
G1 X22.49 Y51.921 F1000
G1 X22.716 Y51.536 F1000
G1 X23.027 Y51.095 F1000
G1 X23.405 Y50.639 F1000
G1 X23.89 Y50.142 F1000
G1 X24.509 Y49.602 F1000
G1 X25.248 Y49.055 F1000
G1 X26.025 Y48.566 F1000
G1 X26.832 Y48.125 F1000
G1 X27.66 Y47.727 F1000
G1 X28.505 Y47.364 F1000
G1 X29.362 Y47.034 F1000
G1 X30.23 Y46.731 F1000
G1 X31.105 Y46.452 F1000
G1 X31.988 Y46.194 F1000
G1 X32.875 Y45.955 F1000
G1 X33.767 Y45.733 F1000
G1 X34.662 Y45.526 F1000
G1 X35.561 Y45.333 F1000
G1 X36.462 Y45.151 F1000
G1 X37.365 Y44.981 F1000
G1 X38.27 Y44.82 F1000
G1 X39.176 Y44.669 F1000
G1 X40.084 Y44.526 F1000
G1 X40.993 Y44.39 F1000
G1 X41.903 Y44.262 F1000
G1 X42.814 Y44.14 F1000
G1 X43.725 Y44.024 F1000
G1 X44.638 Y43.913 F1000
G1 X45.551 Y43.808 F1000
G1 X46.464 Y43.707 F1000
G1 X47.378 Y43.611 F1000
G1 X48.293 Y43.519 F1000
G1 X49.207 Y43.431 F1000
G1 X50.122 Y43.346 F1000
G1 X51.038 Y43.265 F1000
G1 X51.953 Y43.186 F1000
G1 X52.869 Y43.111 F1000
G1 X53.786 Y43.038 F1000
G1 X54.702 Y42.968 F1000
G1 X55.618 Y42.899 F1000
G1 X56.535 Y42.834 F1000
G1 X57.452 Y42.77 F1000
G1 X58.369 Y42.708 F1000
G1 X59.286 Y42.647 F1000
G1 X60.203 Y42.588 F1000
G1 X61.12 Y42.531 F1000
G1 X62.037 Y42.475 F1000
G1 X62.955 Y42.421 F1000
G1 X63.872 Y42.367 F1000
G1 X65.707 Y42.263 F1000
G1 X67.543 Y42.163 F1000
G1 X68.46 Y42.114 F1000
G1 X70.296 Y42.019 F1000
G1 X72.132 Y41.926 F1000
G1 X73.967 Y41.835 F1000
G1 X76.721 Y41.703 F1000
G1 X79.475 Y41.575 F1000
G1 X82.23 Y41.45 F1000
G1 X84.984 Y41.328 F1000
G1 X87.739 Y41.21 F1000
G1 X90.493 Y41.096 F1000
G1 X93.248 Y40.986 F1000
G1 X95.085 Y40.916 F1000
G1 X96.922 Y40.847 F1000
G1 X98.758 Y40.78 F1000
G1 X100.595 Y40.716 F1000
G1 X102.432 Y40.655 F1000
G1 X104.269 Y40.596 F1000
G1 X106.107 Y40.54 F1000
G1 X107.944 Y40.486 F1000
G1 X109.781 Y40.436 F1000
G1 X111.619 Y40.389 F1000
G1 X113.456 Y40.345 F1000
G1 X115.294 Y40.305 F1000
G1 X117.131 Y40.268 F1000
G1 X118.969 Y40.234 F1000
G1 X120.807 Y40.205 F1000
G1 X121.726 Y40.192 F1000
G1 X122.645 Y40.18 F1000
G1 X123.564 Y40.169 F1000
G1 X124.483 Y40.159 F1000
G1 X125.402 Y40.15 F1000
G1 X126.321 Y40.142 F1000
G1 X127.24 Y40.135 F1000
G1 X128.159 Y40.13 F1000
G1 X129.078 Y40.125 F1000
G1 X129.997 Y40.122 F1000
G1 X130.916 Y40.121 F1000
G1 X131.835 Y40.12 F1000
G1 X132.754 Y40.121 F1000
G1 X133.673 Y40.123 F1000
G1 X134.592 Y40.127 F1000
G1 X135.511 Y40.132 F1000
G1 X136.43 Y40.139 F1000
G1 X137.349 Y40.148 F1000
G1 X138.268 Y40.158 F1000
G1 X139.187 Y40.169 F1000
G1 X140.106 Y40.183 F1000
G1 X141.025 Y40.198 F1000
G1 X141.943 Y40.215 F1000
G1 X142.862 Y40.234 F1000
G1 X143.781 Y40.255 F1000
G1 X144.7 Y40.278 F1000
G1 X145.618 Y40.304 F1000
G1 X146.537 Y40.331 F1000
G1 X147.456 Y40.362 F1000
G1 X148.374 Y40.394 F1000
G1 X149.292 Y40.429 F1000
G1 X150.211 Y40.467 F1000
G1 X151.129 Y40.508 F1000
G1 X152.047 Y40.552 F1000
G1 X152.965 Y40.599 F1000
G1 X153.882 Y40.649 F1000
G1 X154.8 Y40.703 F1000
G1 X155.717 Y40.761 F1000
G1 X156.634 Y40.822 F1000
G1 X157.55 Y40.889 F1000
G1 X158.467 Y40.959 F1000
G1 X159.383 Y41.035 F1000
G1 X160.298 Y41.116 F1000
G1 X161.213 Y41.203 F1000
G1 X162.127 Y41.296 F1000
G1 X163.041 Y41.397 F1000
G1 X163.953 Y41.505 F1000
G1 X164.865 Y41.623 F1000
G1 X165.775 Y41.75 F1000
G1 X166.683 Y41.889 F1000
G1 X167.59 Y42.041 F1000
G1 X168.493 Y42.209 F1000
G1 X169.393 Y42.396 F1000
G1 X170.288 Y42.606 F1000
G1 X171.175 Y42.847 F1000
G1 X172.048 Y43.132 F1000
G1 X172.616 Y43.368 F1000
G1 X172.932 Y43.531 F1000
G1 X173.202 Y43.709 F1000
G1 X173.427 Y43.943 F1000
G1 X173.596 Y44.219 F1000
G1 X173.701 Y44.526 F1000
G1 X173.736 Y44.848 F1000
G1 Y47.377 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y47.961 I-0.635 J-0.022 F1000
G1 X173.221 Y47.982 Z-3.012 F1000
G1 X173.153 Y48.003 Z-3 F1000
G1 X173.088 Y48.023 Z-2.98 F1000
G1 X173.025 Y48.043 Z-2.953 F1000
G1 X172.966 Y48.061 Z-2.919 F1000
G1 X172.91 Y48.078 Z-2.877 F1000
G1 X172.859 Y48.094 Z-2.83 F1000
G1 X172.814 Y48.108 Z-2.777 F1000
G1 X172.775 Y48.12 Z-2.719 F1000
G1 X172.742 Y48.13 Z-2.657 F1000
G1 X172.716 Y48.138 Z-2.591 F1000
G1 X172.697 Y48.144 Z-2.522 F1000
G1 X172.685 Y48.147 Z-2.452 F1000
G1 X172.682 Y48.149 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y55.101 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y55.098 Z-2.452 F1000
G1 X22.509 Y55.088 Z-2.522 F1000
G1 X22.499 Y55.071 Z-2.591 F1000
G1 X22.485 Y55.047 Z-2.657 F1000
G1 X22.467 Y55.018 Z-2.719 F1000
G1 X22.446 Y54.982 Z-2.777 F1000
G1 X22.422 Y54.941 Z-2.83 F1000
G1 X22.395 Y54.896 Z-2.877 F1000
G1 X22.365 Y54.846 Z-2.919 F1000
G1 X22.333 Y54.792 Z-2.953 F1000
G1 X22.3 Y54.736 Z-2.98 F1000
G1 X22.265 Y54.677 Z-3 F1000
G1 X22.229 Y54.617 Z-3.012 F1000
G1 X22.192 Y54.555 Z-3.016 F1000
G3 X21.971 Y53.802 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y51.296 F1000
G1 X21.988 Y50.951 F1000
G1 X22.02 Y50.708 F1000
G1 X22.082 Y50.42 F1000
G1 X22.174 Y50.111 F1000
G1 X22.304 Y49.777 F1000
G1 X22.491 Y49.393 F1000
G1 X22.717 Y49.008 F1000
G1 X23.028 Y48.566 F1000
G1 X23.406 Y48.11 F1000
G1 X23.891 Y47.613 F1000
G1 X24.51 Y47.073 F1000
G1 X25.249 Y46.526 F1000
G1 X26.027 Y46.037 F1000
G1 X26.833 Y45.596 F1000
G1 X27.662 Y45.198 F1000
G1 X28.506 Y44.836 F1000
G1 X29.364 Y44.505 F1000
G1 X30.231 Y44.201 F1000
G1 X31.107 Y43.922 F1000
G1 X31.989 Y43.665 F1000
G1 X32.876 Y43.426 F1000
G1 X33.768 Y43.204 F1000
G1 X34.663 Y42.996 F1000
G1 X35.562 Y42.803 F1000
G1 X36.463 Y42.621 F1000
G1 X37.366 Y42.45 F1000
G1 X38.271 Y42.289 F1000
G1 X39.177 Y42.138 F1000
G1 X40.085 Y41.994 F1000
G1 X40.994 Y41.859 F1000
G1 X41.904 Y41.73 F1000
G1 X42.814 Y41.608 F1000
G1 X43.726 Y41.491 F1000
G1 X44.638 Y41.381 F1000
G1 X45.551 Y41.275 F1000
G1 X46.465 Y41.174 F1000
G1 X47.379 Y41.078 F1000
G1 X48.293 Y40.985 F1000
G1 X49.208 Y40.896 F1000
G1 X50.123 Y40.811 F1000
G1 X51.038 Y40.73 F1000
G1 X51.954 Y40.651 F1000
G1 X52.87 Y40.575 F1000
G1 X53.786 Y40.502 F1000
G1 X54.702 Y40.431 F1000
G1 X55.619 Y40.363 F1000
G1 X56.535 Y40.297 F1000
G1 X57.452 Y40.233 F1000
G1 X58.369 Y40.17 F1000
G1 X59.286 Y40.109 F1000
G1 X60.203 Y40.05 F1000
G1 X61.12 Y39.993 F1000
G1 X62.038 Y39.937 F1000
G1 X62.955 Y39.882 F1000
G1 X63.873 Y39.828 F1000
G1 X64.79 Y39.775 F1000
G1 X66.625 Y39.673 F1000
G1 X68.461 Y39.574 F1000
G1 X70.296 Y39.479 F1000
G1 X72.132 Y39.386 F1000
G1 X73.968 Y39.295 F1000
G1 X76.722 Y39.162 F1000
G1 X79.476 Y39.034 F1000
G1 X82.23 Y38.909 F1000
G1 X84.984 Y38.788 F1000
G1 X87.739 Y38.67 F1000
G1 X90.493 Y38.556 F1000
G1 X93.248 Y38.446 F1000
G1 X95.085 Y38.376 F1000
G1 X96.922 Y38.307 F1000
G1 X98.759 Y38.241 F1000
G1 X100.596 Y38.177 F1000
G1 X102.433 Y38.116 F1000
G1 X104.27 Y38.057 F1000
G1 X106.107 Y38.001 F1000
G1 X107.944 Y37.948 F1000
G1 X109.782 Y37.898 F1000
G1 X111.619 Y37.851 F1000
G1 X113.456 Y37.808 F1000
G1 X115.294 Y37.768 F1000
G1 X117.132 Y37.731 F1000
G1 X118.969 Y37.698 F1000
G1 X120.807 Y37.669 F1000
G1 X121.726 Y37.656 F1000
G1 X122.645 Y37.644 F1000
G1 X123.564 Y37.633 F1000
G1 X124.483 Y37.623 F1000
G1 X125.402 Y37.614 F1000
G1 X126.321 Y37.606 F1000
G1 X127.24 Y37.6 F1000
G1 X128.159 Y37.594 F1000
G1 X129.078 Y37.59 F1000
G1 X129.997 Y37.587 F1000
G1 X130.916 Y37.586 F1000
G1 X131.835 F1000
G1 X132.754 Y37.587 F1000
G1 X133.673 Y37.589 F1000
G1 X134.592 Y37.593 F1000
G1 X135.511 Y37.598 F1000
G1 X136.43 Y37.605 F1000
G1 X137.349 Y37.614 F1000
G1 X138.268 Y37.624 F1000
G1 X139.187 Y37.636 F1000
G1 X140.106 Y37.649 F1000
G1 X141.025 Y37.665 F1000
G1 X141.944 Y37.682 F1000
G1 X142.863 Y37.701 F1000
G1 X143.781 Y37.723 F1000
G1 X144.7 Y37.746 F1000
G1 X145.619 Y37.771 F1000
G1 X146.537 Y37.799 F1000
G1 X147.456 Y37.83 F1000
G1 X148.374 Y37.862 F1000
G1 X149.293 Y37.898 F1000
G1 X150.211 Y37.936 F1000
G1 X151.129 Y37.977 F1000
G1 X152.047 Y38.021 F1000
G1 X152.965 Y38.068 F1000
G1 X153.882 Y38.118 F1000
G1 X154.8 Y38.172 F1000
G1 X155.717 Y38.23 F1000
G1 X156.634 Y38.292 F1000
G1 X157.551 Y38.358 F1000
G1 X158.467 Y38.429 F1000
G1 X159.383 Y38.505 F1000
G1 X160.298 Y38.586 F1000
G1 X161.213 Y38.673 F1000
G1 X162.127 Y38.767 F1000
G1 X163.041 Y38.867 F1000
G1 X163.953 Y38.976 F1000
G1 X164.865 Y39.094 F1000
G1 X165.775 Y39.221 F1000
G1 X166.683 Y39.36 F1000
G1 X167.59 Y39.513 F1000
G1 X168.493 Y39.681 F1000
G1 X169.393 Y39.867 F1000
G1 X170.288 Y40.078 F1000
G1 X171.175 Y40.318 F1000
G1 X172.048 Y40.603 F1000
G1 X172.616 Y40.84 F1000
G1 X172.932 Y41.002 F1000
G1 X173.202 Y41.181 F1000
G1 X173.427 Y41.414 F1000
G1 X173.596 Y41.691 F1000
G1 X173.701 Y41.998 F1000
G1 X173.736 Y42.32 F1000
G1 Y44.848 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y45.433 I-0.635 J-0.022 F1000
G1 X173.221 Y45.454 Z-3.012 F1000
G1 X173.153 Y45.475 Z-3 F1000
G1 X173.088 Y45.495 Z-2.98 F1000
G1 X173.025 Y45.514 Z-2.953 F1000
G1 X172.966 Y45.532 Z-2.919 F1000
G1 X172.91 Y45.55 Z-2.877 F1000
G1 X172.859 Y45.565 Z-2.83 F1000
G1 X172.814 Y45.579 Z-2.777 F1000
G1 X172.775 Y45.591 Z-2.719 F1000
G1 X172.742 Y45.601 Z-2.657 F1000
G1 X172.716 Y45.609 Z-2.591 F1000
G1 X172.697 Y45.615 Z-2.522 F1000
G1 X172.685 Y45.619 Z-2.452 F1000
G1 X172.682 Y45.62 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y52.595 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y52.592 Z-2.452 F1000
G1 X22.509 Y52.582 Z-2.522 F1000
G1 X22.499 Y52.565 Z-2.591 F1000
G1 X22.485 Y52.541 Z-2.657 F1000
G1 X22.467 Y52.512 Z-2.719 F1000
G1 X22.446 Y52.476 Z-2.777 F1000
G1 X22.422 Y52.435 Z-2.83 F1000
G1 X22.395 Y52.39 Z-2.877 F1000
G1 X22.365 Y52.34 Z-2.919 F1000
G1 X22.333 Y52.286 Z-2.953 F1000
G1 X22.3 Y52.23 Z-2.98 F1000
G1 X22.265 Y52.171 Z-3 F1000
G1 X22.229 Y52.111 Z-3.012 F1000
G1 X22.192 Y52.049 Z-3.016 F1000
G3 X21.971 Y51.296 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y48.79 F1000
G1 X21.989 Y48.423 F1000
G1 X22.021 Y48.18 F1000
G1 X22.083 Y47.891 F1000
G1 X22.175 Y47.583 F1000
G1 X22.305 Y47.249 F1000
G1 X22.492 Y46.865 F1000
G1 X22.718 Y46.48 F1000
G1 X23.029 Y46.038 F1000
G1 X23.408 Y45.581 F1000
G1 X23.893 Y45.084 F1000
G1 X24.512 Y44.544 F1000
G1 X25.251 Y43.998 F1000
G1 X26.029 Y43.508 F1000
G1 X26.835 Y43.067 F1000
G1 X27.663 Y42.669 F1000
G1 X28.508 Y42.306 F1000
G1 X29.365 Y41.976 F1000
G1 X30.233 Y41.672 F1000
G1 X31.108 Y41.393 F1000
G1 X31.99 Y41.135 F1000
G1 X32.878 Y40.896 F1000
G1 X33.769 Y40.674 F1000
G1 X34.665 Y40.466 F1000
G1 X35.563 Y40.272 F1000
G1 X36.464 Y40.09 F1000
G1 X37.367 Y39.919 F1000
G1 X38.272 Y39.758 F1000
G1 X39.178 Y39.607 F1000
G1 X40.086 Y39.463 F1000
G1 X40.995 Y39.327 F1000
G1 X41.905 Y39.198 F1000
G1 X42.815 Y39.075 F1000
G1 X43.727 Y38.959 F1000
G1 X44.639 Y38.848 F1000
G1 X45.552 Y38.742 F1000
G1 X46.466 Y38.641 F1000
G1 X47.379 Y38.544 F1000
G1 X48.294 Y38.451 F1000
G1 X49.208 Y38.362 F1000
G1 X50.124 Y38.277 F1000
G1 X51.039 Y38.195 F1000
G1 X51.954 Y38.116 F1000
G1 X52.87 Y38.04 F1000
G1 X53.786 Y37.966 F1000
G1 X54.703 Y37.895 F1000
G1 X55.619 Y37.826 F1000
G1 X56.536 Y37.76 F1000
G1 X57.453 Y37.695 F1000
G1 X58.369 Y37.633 F1000
G1 X59.286 Y37.572 F1000
G1 X60.203 Y37.512 F1000
G1 X61.121 Y37.455 F1000
G1 X62.038 Y37.398 F1000
G1 X62.955 Y37.343 F1000
G1 X63.873 Y37.289 F1000
G1 X64.79 Y37.236 F1000
G1 X66.625 Y37.134 F1000
G1 X68.461 Y37.035 F1000
G1 X70.296 Y36.939 F1000
G1 X72.132 Y36.845 F1000
G1 X73.968 Y36.754 F1000
G1 X76.722 Y36.621 F1000
G1 X79.476 Y36.493 F1000
G1 X82.23 Y36.368 F1000
G1 X84.984 Y36.247 F1000
G1 X87.739 Y36.129 F1000
G1 X90.494 Y36.016 F1000
G1 X93.249 Y35.907 F1000
G1 X95.085 Y35.836 F1000
G1 X96.922 Y35.768 F1000
G1 X98.759 Y35.702 F1000
G1 X100.596 Y35.638 F1000
G1 X102.433 Y35.577 F1000
G1 X104.27 Y35.519 F1000
G1 X106.107 Y35.463 F1000
G1 X107.944 Y35.41 F1000
G1 X109.782 Y35.36 F1000
G1 X111.619 Y35.314 F1000
G1 X113.457 Y35.27 F1000
G1 X115.294 Y35.23 F1000
G1 X117.132 Y35.194 F1000
G1 X118.97 Y35.161 F1000
G1 X120.808 Y35.132 F1000
G1 X121.727 Y35.12 F1000
G1 X122.645 Y35.108 F1000
G1 X123.564 Y35.097 F1000
G1 X124.483 Y35.087 F1000
G1 X125.402 Y35.078 F1000
G1 X126.321 Y35.071 F1000
G1 X127.24 Y35.064 F1000
G1 X128.159 Y35.059 F1000
G1 X129.078 Y35.055 F1000
G1 X129.997 Y35.052 F1000
G1 X130.916 Y35.051 F1000
G1 X131.835 F1000
G1 X132.754 Y35.052 F1000
G1 X133.673 Y35.055 F1000
G1 X134.592 Y35.059 F1000
G1 X135.511 Y35.064 F1000
G1 X136.43 Y35.071 F1000
G1 X137.349 Y35.08 F1000
G1 X138.268 Y35.09 F1000
G1 X139.187 Y35.102 F1000
G1 X140.106 Y35.116 F1000
G1 X141.025 Y35.132 F1000
G1 X141.944 Y35.149 F1000
G1 X142.863 Y35.169 F1000
G1 X143.782 Y35.19 F1000
G1 X144.7 Y35.213 F1000
G1 X145.619 Y35.239 F1000
G1 X146.538 Y35.267 F1000
G1 X147.456 Y35.298 F1000
G1 X148.375 Y35.331 F1000
G1 X149.293 Y35.366 F1000
G1 X150.211 Y35.404 F1000
G1 X151.129 Y35.445 F1000
G1 X152.047 Y35.489 F1000
G1 X152.965 Y35.537 F1000
G1 X153.883 Y35.587 F1000
G1 X154.8 Y35.642 F1000
G1 X155.717 Y35.7 F1000
G1 X156.634 Y35.762 F1000
G1 X157.551 Y35.828 F1000
G1 X158.467 Y35.899 F1000
G1 X159.383 Y35.975 F1000
G1 X160.298 Y36.056 F1000
G1 X161.213 Y36.144 F1000
G1 X162.127 Y36.237 F1000
G1 X163.041 Y36.338 F1000
G1 X163.953 Y36.447 F1000
G1 X164.865 Y36.564 F1000
G1 X165.775 Y36.692 F1000
G1 X166.683 Y36.831 F1000
G1 X167.59 Y36.984 F1000
G1 X168.493 Y37.152 F1000
G1 X169.393 Y37.338 F1000
G1 X170.288 Y37.549 F1000
G1 X171.175 Y37.789 F1000
G1 X172.048 Y38.074 F1000
G1 X172.616 Y38.311 F1000
G1 X172.932 Y38.473 F1000
G1 X173.202 Y38.652 F1000
G1 X173.427 Y38.886 F1000
G1 X173.596 Y39.162 F1000
G1 X173.701 Y39.469 F1000
G1 X173.736 Y39.791 F1000
G1 Y42.32 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y42.904 I-0.635 J-0.022 F1000
G1 X173.221 Y42.925 Z-3.012 F1000
G1 X173.153 Y42.946 Z-3 F1000
G1 X173.088 Y42.966 Z-2.98 F1000
G1 X173.025 Y42.985 Z-2.953 F1000
G1 X172.966 Y43.004 Z-2.919 F1000
G1 X172.91 Y43.021 Z-2.877 F1000
G1 X172.859 Y43.037 Z-2.83 F1000
G1 X172.814 Y43.051 Z-2.777 F1000
G1 X172.775 Y43.063 Z-2.719 F1000
G1 X172.742 Y43.073 Z-2.657 F1000
G1 X172.716 Y43.081 Z-2.591 F1000
G1 X172.697 Y43.087 Z-2.522 F1000
G1 X172.685 Y43.09 Z-2.452 F1000
G1 X172.682 Y43.091 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y50.089 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y50.086 Z-2.452 F1000
G1 X22.509 Y50.076 Z-2.522 F1000
G1 X22.499 Y50.059 Z-2.591 F1000
G1 X22.485 Y50.035 Z-2.657 F1000
G1 X22.467 Y50.006 Z-2.719 F1000
G1 X22.446 Y49.97 Z-2.777 F1000
G1 X22.422 Y49.929 Z-2.83 F1000
G1 X22.395 Y49.884 Z-2.877 F1000
G1 X22.365 Y49.834 Z-2.919 F1000
G1 X22.333 Y49.78 Z-2.953 F1000
G1 X22.3 Y49.724 Z-2.98 F1000
G1 X22.265 Y49.665 Z-3 F1000
G1 X22.229 Y49.605 Z-3.012 F1000
G1 X22.192 Y49.543 Z-3.016 F1000
G3 X21.971 Y48.79 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y46.075 F1000
G1 X21.98 Y45.904 F1000
G1 X22.011 Y45.661 F1000
G1 X22.073 Y45.372 F1000
G1 X22.166 Y45.062 F1000
G1 X22.296 Y44.728 F1000
G1 X22.483 Y44.342 F1000
G1 X22.71 Y43.957 F1000
G1 X23.022 Y43.514 F1000
G1 X23.4 Y43.057 F1000
G1 X23.887 Y42.559 F1000
G1 X24.507 Y42.018 F1000
G1 X25.246 Y41.471 F1000
G1 X26.023 Y40.982 F1000
G1 X26.83 Y40.541 F1000
G1 X27.658 Y40.142 F1000
G1 X28.502 Y39.78 F1000
G1 X29.36 Y39.448 F1000
G1 X30.227 Y39.145 F1000
G1 X31.102 Y38.865 F1000
G1 X31.984 Y38.607 F1000
G1 X32.872 Y38.368 F1000
G1 X33.763 Y38.145 F1000
G1 X34.659 Y37.938 F1000
G1 X35.557 Y37.743 F1000
G1 X36.458 Y37.561 F1000
G1 X37.361 Y37.39 F1000
G1 X38.265 Y37.229 F1000
G1 X39.172 Y37.076 F1000
G1 X40.079 Y36.932 F1000
G1 X40.988 Y36.796 F1000
G1 X41.898 Y36.667 F1000
G1 X42.809 Y36.544 F1000
G1 X43.72 Y36.427 F1000
G1 X44.633 Y36.316 F1000
G1 X45.546 Y36.209 F1000
G1 X46.459 Y36.108 F1000
G1 X47.373 Y36.011 F1000
G1 X48.287 Y35.918 F1000
G1 X49.202 Y35.828 F1000
G1 X50.117 Y35.743 F1000
G1 X51.032 Y35.66 F1000
G1 X51.948 Y35.581 F1000
G1 X52.864 Y35.504 F1000
G1 X53.78 Y35.431 F1000
G1 X54.696 Y35.359 F1000
G1 X55.612 Y35.29 F1000
G1 X56.529 Y35.224 F1000
G1 X57.446 Y35.159 F1000
G1 X58.362 Y35.096 F1000
G1 X59.279 Y35.035 F1000
G1 X60.197 Y34.975 F1000
G1 X61.114 Y34.917 F1000
G1 X62.031 Y34.86 F1000
G1 X62.948 Y34.805 F1000
G1 X63.866 Y34.751 F1000
G1 X64.783 Y34.698 F1000
G1 X66.618 Y34.595 F1000
G1 X68.454 Y34.495 F1000
G1 X69.371 Y34.447 F1000
G1 X71.207 Y34.352 F1000
G1 X73.043 Y34.259 F1000
G1 X74.879 Y34.169 F1000
G1 X77.633 Y34.038 F1000
G1 X80.387 Y33.91 F1000
G1 X83.141 Y33.787 F1000
G1 X85.895 Y33.667 F1000
G1 X88.65 Y33.551 F1000
G1 X91.405 Y33.439 F1000
G1 X94.16 Y33.332 F1000
G1 X95.997 Y33.262 F1000
G1 X97.833 Y33.196 F1000
G1 X99.67 Y33.131 F1000
G1 X101.507 Y33.069 F1000
G1 X103.344 Y33.009 F1000
G1 X105.181 Y32.952 F1000
G1 X107.019 Y32.898 F1000
G1 X108.856 Y32.847 F1000
G1 X110.693 Y32.799 F1000
G1 X112.531 Y32.755 F1000
G1 X114.369 Y32.713 F1000
G1 X116.206 Y32.675 F1000
G1 X118.044 Y32.641 F1000
G1 X119.882 Y32.61 F1000
G1 X121.72 Y32.584 F1000
G1 X122.638 Y32.572 F1000
G1 X123.557 Y32.561 F1000
G1 X124.476 Y32.551 F1000
G1 X125.395 Y32.543 F1000
G1 X126.314 Y32.535 F1000
G1 X127.233 Y32.529 F1000
G1 X128.152 Y32.524 F1000
G1 X129.071 Y32.52 F1000
G1 X129.99 Y32.518 F1000
G1 X130.909 Y32.516 F1000
G1 X131.828 F1000
G1 X132.747 Y32.518 F1000
G1 X133.666 Y32.52 F1000
G1 X134.585 Y32.525 F1000
G1 X135.505 Y32.53 F1000
G1 X136.423 Y32.537 F1000
G1 X137.342 Y32.546 F1000
G1 X138.261 Y32.557 F1000
G1 X139.18 Y32.569 F1000
G1 X140.099 Y32.583 F1000
G1 X141.018 Y32.598 F1000
G1 X141.937 Y32.616 F1000
G1 X142.856 Y32.636 F1000
G1 X143.775 Y32.657 F1000
G1 X144.693 Y32.681 F1000
G1 X145.612 Y32.707 F1000
G1 X146.531 Y32.735 F1000
G1 X147.449 Y32.765 F1000
G1 X148.367 Y32.798 F1000
G1 X149.286 Y32.834 F1000
G1 X150.204 Y32.872 F1000
G1 X151.122 Y32.914 F1000
G1 X152.04 Y32.958 F1000
G1 X152.958 Y33.005 F1000
G1 X153.876 Y33.056 F1000
G1 X154.793 Y33.111 F1000
G1 X155.71 Y33.169 F1000
G1 X156.627 Y33.231 F1000
G1 X157.544 Y33.297 F1000
G1 X158.46 Y33.368 F1000
G1 X159.376 Y33.444 F1000
G1 X160.291 Y33.526 F1000
G1 X161.206 Y33.613 F1000
G1 X162.12 Y33.707 F1000
G1 X163.034 Y33.807 F1000
G1 X163.946 Y33.916 F1000
G1 X164.858 Y34.034 F1000
G1 X165.768 Y34.162 F1000
G1 X166.676 Y34.301 F1000
G1 X167.583 Y34.453 F1000
G1 X168.486 Y34.621 F1000
G1 X169.386 Y34.808 F1000
G1 X170.281 Y35.018 F1000
G1 X171.168 Y35.258 F1000
G1 X172.042 Y35.543 F1000
G1 X172.611 Y35.78 F1000
G1 X172.931 Y35.944 F1000
G1 X173.202 Y36.123 F1000
G1 X173.427 Y36.356 F1000
G1 X173.596 Y36.633 F1000
G1 X173.701 Y36.94 F1000
G1 X173.736 Y37.262 F1000
G1 Y39.791 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y40.376 I-0.635 J-0.022 F1000
G1 X173.221 Y40.397 Z-3.012 F1000
G1 X173.153 Y40.417 Z-3 F1000
G1 X173.088 Y40.437 Z-2.98 F1000
G1 X173.025 Y40.457 Z-2.953 F1000
G1 X172.966 Y40.475 Z-2.919 F1000
G1 X172.91 Y40.492 Z-2.877 F1000
G1 X172.859 Y40.508 Z-2.83 F1000
G1 X172.814 Y40.522 Z-2.777 F1000
G1 X172.775 Y40.534 Z-2.719 F1000
G1 X172.742 Y40.544 Z-2.657 F1000
G1 X172.716 Y40.552 Z-2.591 F1000
G1 X172.697 Y40.558 Z-2.522 F1000
G1 X172.685 Y40.561 Z-2.452 F1000
G1 X172.682 Y40.563 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y47.374 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y47.371 Z-2.452 F1000
G1 X22.509 Y47.361 Z-2.522 F1000
G1 X22.499 Y47.344 Z-2.591 F1000
G1 X22.485 Y47.32 Z-2.657 F1000
G1 X22.467 Y47.291 Z-2.719 F1000
G1 X22.446 Y47.255 Z-2.777 F1000
G1 X22.422 Y47.215 Z-2.83 F1000
G1 X22.395 Y47.169 Z-2.877 F1000
G1 X22.365 Y47.119 Z-2.919 F1000
G1 X22.333 Y47.065 Z-2.953 F1000
G1 X22.3 Y47.009 Z-2.98 F1000
G1 X22.265 Y46.95 Z-3 F1000
G1 X22.229 Y46.89 Z-3.012 F1000
G1 X22.192 Y46.829 Z-3.016 F1000
G3 X21.971 Y46.075 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y43.569 F1000
G1 X21.981 Y43.372 F1000
G1 X22.013 Y43.129 F1000
G1 X22.074 Y42.841 F1000
G1 X22.167 Y42.531 F1000
G1 X22.297 Y42.197 F1000
G1 X22.484 Y41.812 F1000
G1 X22.711 Y41.427 F1000
G1 X23.022 Y40.984 F1000
G1 X23.401 Y40.528 F1000
G1 X23.887 Y40.03 F1000
G1 X24.507 Y39.489 F1000
G1 X25.245 Y38.942 F1000
G1 X26.023 Y38.453 F1000
G1 X26.83 Y38.012 F1000
G1 X27.657 Y37.613 F1000
G1 X28.502 Y37.25 F1000
G1 X29.359 Y36.919 F1000
G1 X30.227 Y36.616 F1000
G1 X31.102 Y36.336 F1000
G1 X31.984 Y36.078 F1000
G1 X32.871 Y35.838 F1000
G1 X33.763 Y35.615 F1000
G1 X34.658 Y35.407 F1000
G1 X35.556 Y35.213 F1000
G1 X36.457 Y35.031 F1000
G1 X37.36 Y34.859 F1000
G1 X38.265 Y34.698 F1000
G1 X39.171 Y34.545 F1000
G1 X40.079 Y34.401 F1000
G1 X40.987 Y34.264 F1000
G1 X41.897 Y34.135 F1000
G1 X42.808 Y34.012 F1000
G1 X43.719 Y33.894 F1000
G1 X44.632 Y33.783 F1000
G1 X45.544 Y33.676 F1000
G1 X46.458 Y33.574 F1000
G1 X47.372 Y33.477 F1000
G1 X48.286 Y33.383 F1000
G1 X49.201 Y33.294 F1000
G1 X50.116 Y33.208 F1000
G1 X51.031 Y33.125 F1000
G1 X51.946 Y33.046 F1000
G1 X52.862 Y32.969 F1000
G1 X53.778 Y32.895 F1000
G1 X54.694 Y32.823 F1000
G1 X55.611 Y32.754 F1000
G1 X56.527 Y32.687 F1000
G1 X57.444 Y32.622 F1000
G1 X58.361 Y32.558 F1000
G1 X59.278 Y32.497 F1000
G1 X60.195 Y32.437 F1000
G1 X61.112 Y32.379 F1000
G1 X62.029 Y32.322 F1000
G1 X62.947 Y32.266 F1000
G1 X63.864 Y32.212 F1000
G1 X64.782 Y32.159 F1000
G1 X66.617 Y32.055 F1000
G1 X68.452 Y31.955 F1000
G1 X69.37 Y31.907 F1000
G1 X71.205 Y31.811 F1000
G1 X73.041 Y31.719 F1000
G1 X74.877 Y31.629 F1000
G1 X77.631 Y31.497 F1000
G1 X80.385 Y31.37 F1000
G1 X83.139 Y31.246 F1000
G1 X85.894 Y31.127 F1000
G1 X88.648 Y31.011 F1000
G1 X91.403 Y30.899 F1000
G1 X93.24 Y30.827 F1000
G1 X95.077 Y30.757 F1000
G1 X96.913 Y30.689 F1000
G1 X98.75 Y30.624 F1000
G1 X100.587 Y30.561 F1000
G1 X102.424 Y30.5 F1000
G1 X104.261 Y30.442 F1000
G1 X106.099 Y30.387 F1000
G1 X107.936 Y30.335 F1000
G1 X109.773 Y30.285 F1000
G1 X111.611 Y30.239 F1000
G1 X113.448 Y30.196 F1000
G1 X115.286 Y30.157 F1000
G1 X117.124 Y30.121 F1000
G1 X118.961 Y30.089 F1000
G1 X119.88 Y30.074 F1000
G1 X121.718 Y30.047 F1000
G1 X122.637 Y30.036 F1000
G1 X123.556 Y30.025 F1000
G1 X124.475 Y30.016 F1000
G1 X125.394 Y30.007 F1000
G1 X126.313 Y30 F1000
G1 X127.232 Y29.994 F1000
G1 X128.151 Y29.989 F1000
G1 X129.07 Y29.985 F1000
G1 X129.989 Y29.983 F1000
G1 X130.908 Y29.981 F1000
G1 X131.827 Y29.982 F1000
G1 X132.746 Y29.983 F1000
G1 X133.665 Y29.986 F1000
G1 X134.584 Y29.99 F1000
G1 X135.503 Y29.996 F1000
G1 X136.422 Y30.004 F1000
G1 X137.341 Y30.013 F1000
G1 X138.26 Y30.023 F1000
G1 X139.179 Y30.035 F1000
G1 X140.098 Y30.049 F1000
G1 X141.017 Y30.065 F1000
G1 X141.936 Y30.083 F1000
G1 X142.854 Y30.103 F1000
G1 X143.773 Y30.124 F1000
G1 X144.692 Y30.148 F1000
G1 X145.61 Y30.174 F1000
G1 X146.529 Y30.203 F1000
G1 X147.448 Y30.233 F1000
G1 X148.366 Y30.267 F1000
G1 X149.284 Y30.302 F1000
G1 X150.202 Y30.341 F1000
G1 X151.121 Y30.382 F1000
G1 X152.039 Y30.427 F1000
G1 X152.956 Y30.474 F1000
G1 X153.874 Y30.525 F1000
G1 X154.791 Y30.58 F1000
G1 X155.708 Y30.638 F1000
G1 X156.625 Y30.7 F1000
G1 X157.542 Y30.767 F1000
G1 X158.458 Y30.838 F1000
G1 X159.374 Y30.914 F1000
G1 X160.29 Y30.996 F1000
G1 X161.204 Y31.083 F1000
G1 X162.119 Y31.177 F1000
G1 X163.032 Y31.278 F1000
G1 X163.945 Y31.387 F1000
G1 X164.856 Y31.504 F1000
G1 X165.766 Y31.632 F1000
G1 X166.675 Y31.771 F1000
G1 X167.581 Y31.924 F1000
G1 X168.484 Y32.092 F1000
G1 X169.384 Y32.279 F1000
G1 X170.279 Y32.489 F1000
G1 X171.166 Y32.729 F1000
G1 X172.04 Y33.014 F1000
G1 X172.61 Y33.25 F1000
G1 X172.931 Y33.415 F1000
G1 X173.201 Y33.594 F1000
G1 X173.427 Y33.827 F1000
G1 X173.596 Y34.104 F1000
G1 X173.701 Y34.411 F1000
G1 X173.736 Y34.733 F1000
G1 Y37.262 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y37.847 I-0.635 J-0.022 F1000
G1 X173.221 Y37.868 Z-3.012 F1000
G1 X173.153 Y37.888 Z-3 F1000
G1 X173.088 Y37.909 Z-2.98 F1000
G1 X173.025 Y37.928 Z-2.953 F1000
G1 X172.966 Y37.946 Z-2.919 F1000
G1 X172.91 Y37.963 Z-2.877 F1000
G1 X172.859 Y37.979 Z-2.83 F1000
G1 X172.814 Y37.993 Z-2.777 F1000
G1 X172.775 Y38.005 Z-2.719 F1000
G1 X172.742 Y38.015 Z-2.657 F1000
G1 X172.716 Y38.023 Z-2.591 F1000
G1 X172.697 Y38.029 Z-2.522 F1000
G1 X172.685 Y38.033 Z-2.452 F1000
G1 X172.682 Y38.034 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y44.868 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y44.865 Z-2.452 F1000
G1 X22.509 Y44.855 Z-2.522 F1000
G1 X22.499 Y44.838 Z-2.591 F1000
G1 X22.485 Y44.814 Z-2.657 F1000
G1 X22.467 Y44.785 Z-2.719 F1000
G1 X22.446 Y44.749 Z-2.777 F1000
G1 X22.422 Y44.708 Z-2.83 F1000
G1 X22.395 Y44.663 Z-2.877 F1000
G1 X22.365 Y44.613 Z-2.919 F1000
G1 X22.333 Y44.559 Z-2.953 F1000
G1 X22.3 Y44.503 Z-2.98 F1000
G1 X22.265 Y44.444 Z-3 F1000
G1 X22.229 Y44.384 Z-3.012 F1000
G1 X22.192 Y44.323 Z-3.016 F1000
G3 X21.971 Y43.569 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y41.063 F1000
G1 X21.982 Y40.842 F1000
G1 X22.014 Y40.599 F1000
G1 X22.076 Y40.311 F1000
G1 X22.168 Y40.001 F1000
G1 X22.298 Y39.667 F1000
G1 X22.485 Y39.283 F1000
G1 X22.712 Y38.898 F1000
G1 X23.023 Y38.455 F1000
G1 X23.402 Y37.998 F1000
G1 X23.887 Y37.5 F1000
G1 X24.507 Y36.96 F1000
G1 X25.246 Y36.413 F1000
G1 X26.024 Y35.923 F1000
G1 X26.83 Y35.482 F1000
G1 X27.658 Y35.084 F1000
G1 X28.503 Y34.721 F1000
G1 X29.36 Y34.39 F1000
G1 X30.227 Y34.086 F1000
G1 X31.103 Y33.806 F1000
G1 X31.985 Y33.548 F1000
G1 X32.872 Y33.308 F1000
G1 X33.763 Y33.085 F1000
G1 X34.659 Y32.877 F1000
G1 X35.557 Y32.682 F1000
G1 X36.457 Y32.5 F1000
G1 X37.36 Y32.328 F1000
G1 X38.265 Y32.166 F1000
G1 X39.171 Y32.014 F1000
G1 X40.079 Y31.869 F1000
G1 X40.988 Y31.732 F1000
G1 X41.897 Y31.602 F1000
G1 X42.808 Y31.479 F1000
G1 X43.72 Y31.362 F1000
G1 X44.632 Y31.25 F1000
G1 X45.545 Y31.143 F1000
G1 X46.458 Y31.041 F1000
G1 X47.372 Y30.943 F1000
G1 X48.286 Y30.849 F1000
G1 X49.201 Y30.759 F1000
G1 X50.115 Y30.673 F1000
G1 X51.031 Y30.59 F1000
G1 X51.946 Y30.51 F1000
G1 X52.862 Y30.433 F1000
G1 X53.778 Y30.359 F1000
G1 X54.694 Y30.287 F1000
G1 X55.611 Y30.217 F1000
G1 X56.527 Y30.15 F1000
G1 X57.444 Y30.084 F1000
G1 X58.361 Y30.021 F1000
G1 X59.278 Y29.959 F1000
G1 X60.195 Y29.899 F1000
G1 X61.112 Y29.841 F1000
G1 X62.029 Y29.783 F1000
G1 X62.946 Y29.728 F1000
G1 X63.864 Y29.673 F1000
G1 X64.781 Y29.619 F1000
G1 X66.616 Y29.516 F1000
G1 X68.452 Y29.416 F1000
G1 X70.287 Y29.319 F1000
G1 X72.123 Y29.225 F1000
G1 X73.959 Y29.133 F1000
G1 X75.794 Y29.044 F1000
G1 X78.548 Y28.913 F1000
G1 X81.303 Y28.787 F1000
G1 X84.057 Y28.665 F1000
G1 X86.812 Y28.547 F1000
G1 X89.566 Y28.433 F1000
G1 X92.321 Y28.323 F1000
G1 X94.158 Y28.252 F1000
G1 X95.994 Y28.183 F1000
G1 X97.831 Y28.117 F1000
G1 X99.668 Y28.053 F1000
G1 X101.505 Y27.991 F1000
G1 X103.342 Y27.932 F1000
G1 X105.18 Y27.876 F1000
G1 X107.017 Y27.822 F1000
G1 X108.854 Y27.772 F1000
G1 X110.692 Y27.724 F1000
G1 X112.529 Y27.68 F1000
G1 X114.367 Y27.639 F1000
G1 X116.204 Y27.601 F1000
G1 X118.042 Y27.568 F1000
G1 X118.961 Y27.552 F1000
G1 X120.799 Y27.524 F1000
G1 X121.718 Y27.511 F1000
G1 X122.637 Y27.5 F1000
G1 X123.556 Y27.489 F1000
G1 X124.475 Y27.48 F1000
G1 X125.394 Y27.472 F1000
G1 X126.313 Y27.464 F1000
G1 X127.232 Y27.458 F1000
G1 X128.151 Y27.454 F1000
G1 X129.07 Y27.45 F1000
G1 X129.989 Y27.448 F1000
G1 X130.908 Y27.447 F1000
G1 X131.827 F1000
G1 X132.746 Y27.449 F1000
G1 X133.665 Y27.452 F1000
G1 X134.584 Y27.456 F1000
G1 X135.503 Y27.462 F1000
G1 X136.422 Y27.47 F1000
G1 X137.341 Y27.479 F1000
G1 X138.26 Y27.49 F1000
G1 X139.179 Y27.502 F1000
G1 X140.097 Y27.516 F1000
G1 X141.016 Y27.532 F1000
G1 X141.935 Y27.55 F1000
G1 X142.854 Y27.57 F1000
G1 X143.773 Y27.592 F1000
G1 X144.691 Y27.616 F1000
G1 X145.61 Y27.642 F1000
G1 X146.529 Y27.67 F1000
G1 X147.447 Y27.701 F1000
G1 X148.366 Y27.735 F1000
G1 X149.284 Y27.771 F1000
G1 X150.202 Y27.809 F1000
G1 X151.12 Y27.851 F1000
G1 X152.038 Y27.895 F1000
G1 X152.956 Y27.943 F1000
G1 X153.874 Y27.994 F1000
G1 X154.791 Y28.049 F1000
G1 X155.708 Y28.107 F1000
G1 X156.625 Y28.17 F1000
G1 X157.542 Y28.236 F1000
G1 X158.458 Y28.308 F1000
G1 X159.374 Y28.384 F1000
G1 X160.289 Y28.466 F1000
G1 X161.204 Y28.553 F1000
G1 X162.118 Y28.647 F1000
G1 X163.032 Y28.748 F1000
G1 X163.944 Y28.857 F1000
G1 X164.856 Y28.975 F1000
G1 X165.766 Y29.103 F1000
G1 X166.674 Y29.242 F1000
G1 X167.58 Y29.394 F1000
G1 X168.484 Y29.563 F1000
G1 X169.384 Y29.749 F1000
G1 X170.278 Y29.96 F1000
G1 X171.165 Y30.2 F1000
G1 X172.039 Y30.484 F1000
G1 X172.609 Y30.721 F1000
G1 X172.931 Y30.886 F1000
G1 X173.201 Y31.065 F1000
G1 X173.427 Y31.298 F1000
G1 X173.596 Y31.575 F1000
G1 X173.701 Y31.882 F1000
G1 X173.736 Y32.205 F1000
G1 Y34.733 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y35.318 I-0.635 J-0.022 F1000
G1 X173.221 Y35.339 Z-3.012 F1000
G1 X173.153 Y35.36 Z-3 F1000
G1 X173.088 Y35.38 Z-2.98 F1000
G1 X173.025 Y35.399 Z-2.953 F1000
G1 X172.966 Y35.418 Z-2.919 F1000
G1 X172.91 Y35.435 Z-2.877 F1000
G1 X172.859 Y35.45 Z-2.83 F1000
G1 X172.814 Y35.464 Z-2.777 F1000
G1 X172.775 Y35.476 Z-2.719 F1000
G1 X172.742 Y35.487 Z-2.657 F1000
G1 X172.716 Y35.495 Z-2.591 F1000
G1 X172.697 Y35.5 Z-2.522 F1000
G1 X172.685 Y35.504 Z-2.452 F1000
G1 X172.682 Y35.505 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y42.362 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y42.359 Z-2.452 F1000
G1 X22.509 Y42.349 Z-2.522 F1000
G1 X22.499 Y42.332 Z-2.591 F1000
G1 X22.485 Y42.308 Z-2.657 F1000
G1 X22.467 Y42.279 Z-2.719 F1000
G1 X22.446 Y42.243 Z-2.777 F1000
G1 X22.422 Y42.202 Z-2.83 F1000
G1 X22.395 Y42.157 Z-2.877 F1000
G1 X22.365 Y42.107 Z-2.919 F1000
G1 X22.333 Y42.053 Z-2.953 F1000
G1 X22.3 Y41.997 Z-2.98 F1000
G1 X22.265 Y41.938 Z-3 F1000
G1 X22.229 Y41.878 Z-3.012 F1000
G1 X22.192 Y41.817 Z-3.016 F1000
G3 X21.971 Y41.063 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y38.557 F1000
G1 X21.983 Y38.312 F1000
G1 X22.015 Y38.069 F1000
G1 X22.077 Y37.781 F1000
G1 X22.169 Y37.472 F1000
G1 X22.3 Y37.138 F1000
G1 X22.486 Y36.753 F1000
G1 X22.713 Y36.368 F1000
G1 X23.024 Y35.925 F1000
G1 X23.403 Y35.469 F1000
G1 X23.889 Y34.971 F1000
G1 X24.509 Y34.43 F1000
G1 X25.247 Y33.883 F1000
G1 X26.025 Y33.394 F1000
G1 X26.832 Y32.953 F1000
G1 X27.659 Y32.554 F1000
G1 X28.504 Y32.191 F1000
G1 X29.361 Y31.86 F1000
G1 X30.228 Y31.556 F1000
G1 X31.104 Y31.276 F1000
G1 X31.986 Y31.017 F1000
G1 X32.873 Y30.777 F1000
G1 X33.764 Y30.554 F1000
G1 X34.659 Y30.346 F1000
G1 X35.558 Y30.151 F1000
G1 X36.458 Y29.968 F1000
G1 X37.361 Y29.797 F1000
G1 X38.266 Y29.635 F1000
G1 X39.172 Y29.482 F1000
G1 X40.079 Y29.337 F1000
G1 X40.988 Y29.2 F1000
G1 X41.898 Y29.07 F1000
G1 X42.809 Y28.946 F1000
G1 X43.72 Y28.829 F1000
G1 X44.632 Y28.716 F1000
G1 X45.545 Y28.609 F1000
G1 X46.458 Y28.507 F1000
G1 X47.372 Y28.409 F1000
G1 X48.286 Y28.315 F1000
G1 X49.201 Y28.225 F1000
G1 X50.116 Y28.138 F1000
G1 X51.031 Y28.055 F1000
G1 X51.947 Y27.975 F1000
G1 X52.862 Y27.897 F1000
G1 X53.778 Y27.823 F1000
G1 X54.694 Y27.75 F1000
G1 X55.611 Y27.681 F1000
G1 X56.527 Y27.613 F1000
G1 X57.444 Y27.547 F1000
G1 X58.361 Y27.483 F1000
G1 X59.278 Y27.421 F1000
G1 X60.195 Y27.361 F1000
G1 X61.112 Y27.302 F1000
G1 X62.029 Y27.245 F1000
G1 X62.946 Y27.189 F1000
G1 X63.864 Y27.134 F1000
G1 X64.781 Y27.08 F1000
G1 X66.616 Y26.976 F1000
G1 X68.452 Y26.876 F1000
G1 X70.287 Y26.779 F1000
G1 X72.123 Y26.684 F1000
G1 X73.959 Y26.593 F1000
G1 X75.794 Y26.503 F1000
G1 X78.548 Y26.373 F1000
G1 X81.303 Y26.247 F1000
G1 X84.057 Y26.125 F1000
G1 X86.811 Y26.007 F1000
G1 X89.566 Y25.893 F1000
G1 X92.321 Y25.783 F1000
G1 X94.158 Y25.712 F1000
G1 X95.994 Y25.644 F1000
G1 X97.831 Y25.578 F1000
G1 X99.668 Y25.514 F1000
G1 X101.505 Y25.452 F1000
G1 X103.342 Y25.394 F1000
G1 X105.18 Y25.338 F1000
G1 X107.017 Y25.284 F1000
G1 X108.854 Y25.234 F1000
G1 X110.692 Y25.187 F1000
G1 X112.529 Y25.143 F1000
G1 X114.367 Y25.102 F1000
G1 X116.204 Y25.065 F1000
G1 X118.042 Y25.031 F1000
G1 X118.961 Y25.016 F1000
G1 X120.799 Y24.988 F1000
G1 X121.718 Y24.975 F1000
G1 X122.637 Y24.964 F1000
G1 X123.556 Y24.953 F1000
G1 X124.475 Y24.944 F1000
G1 X125.394 Y24.936 F1000
G1 X126.313 Y24.929 F1000
G1 X127.232 Y24.923 F1000
G1 X128.151 Y24.918 F1000
G1 X129.07 Y24.915 F1000
G1 X129.989 Y24.913 F1000
G1 X130.908 Y24.912 F1000
G1 X131.827 F1000
G1 X132.746 Y24.914 F1000
G1 X133.665 Y24.917 F1000
G1 X134.584 Y24.922 F1000
G1 X135.503 Y24.928 F1000
G1 X136.422 Y24.936 F1000
G1 X137.341 Y24.945 F1000
G1 X138.26 Y24.956 F1000
G1 X139.179 Y24.969 F1000
G1 X140.097 Y24.983 F1000
G1 X141.016 Y24.999 F1000
G1 X141.935 Y25.017 F1000
G1 X142.854 Y25.037 F1000
G1 X143.773 Y25.059 F1000
G1 X144.691 Y25.083 F1000
G1 X145.61 Y25.11 F1000
G1 X146.529 Y25.138 F1000
G1 X147.447 Y25.169 F1000
G1 X148.366 Y25.203 F1000
G1 X149.284 Y25.239 F1000
G1 X150.202 Y25.278 F1000
G1 X151.12 Y25.319 F1000
G1 X152.038 Y25.364 F1000
G1 X152.956 Y25.412 F1000
G1 X153.873 Y25.463 F1000
G1 X154.791 Y25.518 F1000
G1 X155.708 Y25.577 F1000
G1 X156.625 Y25.639 F1000
G1 X157.541 Y25.706 F1000
G1 X158.458 Y25.777 F1000
G1 X159.374 Y25.854 F1000
G1 X160.289 Y25.935 F1000
G1 X161.204 Y26.023 F1000
G1 X162.118 Y26.117 F1000
G1 X163.031 Y26.218 F1000
G1 X163.944 Y26.327 F1000
G1 X164.855 Y26.445 F1000
G1 X165.765 Y26.573 F1000
G1 X166.674 Y26.713 F1000
G1 X167.58 Y26.865 F1000
G1 X168.484 Y27.033 F1000
G1 X169.383 Y27.22 F1000
G1 X170.278 Y27.431 F1000
G1 X171.165 Y27.671 F1000
G1 X172.039 Y27.955 F1000
G1 X172.609 Y28.192 F1000
G1 X172.931 Y28.357 F1000
G1 X173.201 Y28.536 F1000
G1 X173.427 Y28.769 F1000
G1 X173.596 Y29.046 F1000
G1 X173.701 Y29.353 F1000
G1 X173.736 Y29.676 F1000
G1 Y32.205 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y32.789 I-0.635 J-0.022 F1000
G1 X173.221 Y32.81 Z-3.012 F1000
G1 X173.153 Y32.831 Z-3 F1000
G1 X173.088 Y32.851 Z-2.98 F1000
G1 X173.025 Y32.87 Z-2.953 F1000
G1 X172.966 Y32.889 Z-2.919 F1000
G1 X172.91 Y32.906 Z-2.877 F1000
G1 X172.859 Y32.921 Z-2.83 F1000
G1 X172.814 Y32.935 Z-2.777 F1000
G1 X172.775 Y32.948 Z-2.719 F1000
G1 X172.742 Y32.958 Z-2.657 F1000
G1 X172.716 Y32.966 Z-2.591 F1000
G1 X172.697 Y32.972 Z-2.522 F1000
G1 X172.685 Y32.975 Z-2.452 F1000
G1 X172.682 Y32.976 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y39.856 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y39.853 Z-2.452 F1000
G1 X22.509 Y39.843 Z-2.522 F1000
G1 X22.499 Y39.826 Z-2.591 F1000
G1 X22.485 Y39.802 Z-2.657 F1000
G1 X22.467 Y39.773 Z-2.719 F1000
G1 X22.446 Y39.737 Z-2.777 F1000
G1 X22.422 Y39.696 Z-2.83 F1000
G1 X22.395 Y39.651 Z-2.877 F1000
G1 X22.365 Y39.601 Z-2.919 F1000
G1 X22.333 Y39.547 Z-2.953 F1000
G1 X22.3 Y39.491 Z-2.98 F1000
G1 X22.265 Y39.432 Z-3 F1000
G1 X22.229 Y39.372 Z-3.012 F1000
G1 X22.192 Y39.311 Z-3.016 F1000
G3 X21.971 Y38.557 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y36.051 F1000
G1 X21.984 Y35.783 F1000
G1 X22.016 Y35.54 F1000
G1 X22.078 Y35.251 F1000
G1 X22.171 Y34.942 F1000
G1 X22.301 Y34.608 F1000
G1 X22.487 Y34.223 F1000
G1 X22.714 Y33.838 F1000
G1 X23.025 Y33.396 F1000
G1 X23.404 Y32.939 F1000
G1 X23.89 Y32.441 F1000
G1 X24.51 Y31.9 F1000
G1 X25.249 Y31.353 F1000
G1 X26.027 Y30.864 F1000
G1 X26.833 Y30.423 F1000
G1 X27.661 Y30.024 F1000
G1 X28.505 Y29.661 F1000
G1 X29.362 Y29.329 F1000
G1 X30.23 Y29.025 F1000
G1 X31.105 Y28.745 F1000
G1 X31.987 Y28.487 F1000
G1 X32.874 Y28.247 F1000
G1 X33.765 Y28.024 F1000
G1 X34.661 Y27.815 F1000
G1 X35.559 Y27.62 F1000
G1 X36.459 Y27.437 F1000
G1 X37.362 Y27.265 F1000
G1 X38.267 Y27.103 F1000
G1 X39.173 Y26.95 F1000
G1 X40.08 Y26.805 F1000
G1 X40.989 Y26.668 F1000
G1 X41.899 Y26.537 F1000
G1 X42.809 Y26.413 F1000
G1 X43.721 Y26.295 F1000
G1 X44.633 Y26.183 F1000
G1 X45.546 Y26.075 F1000
G1 X46.459 Y25.973 F1000
G1 X47.373 Y25.874 F1000
G1 X48.287 Y25.78 F1000
G1 X49.201 Y25.69 F1000
G1 X50.116 Y25.603 F1000
G1 X51.031 Y25.519 F1000
G1 X51.947 Y25.439 F1000
G1 X52.863 Y25.361 F1000
G1 X53.779 Y25.286 F1000
G1 X54.695 Y25.214 F1000
G1 X55.611 Y25.144 F1000
G1 X56.528 Y25.076 F1000
G1 X57.444 Y25.01 F1000
G1 X58.361 Y24.946 F1000
G1 X59.278 Y24.884 F1000
G1 X60.195 Y24.823 F1000
G1 X61.112 Y24.764 F1000
G1 X62.029 Y24.706 F1000
G1 X62.947 Y24.65 F1000
G1 X63.864 Y24.595 F1000
G1 X64.782 Y24.541 F1000
G1 X66.617 Y24.437 F1000
G1 X68.452 Y24.336 F1000
G1 X70.287 Y24.239 F1000
G1 X72.123 Y24.144 F1000
G1 X73.959 Y24.052 F1000
G1 X75.795 Y23.963 F1000
G1 X77.63 Y23.875 F1000
G1 X80.385 Y23.748 F1000
G1 X83.139 Y23.624 F1000
G1 X85.893 Y23.505 F1000
G1 X88.648 Y23.39 F1000
G1 X91.403 Y23.279 F1000
G1 X93.24 Y23.208 F1000
G1 X95.076 Y23.138 F1000
G1 X96.913 Y23.071 F1000
G1 X98.75 Y23.006 F1000
G1 X100.587 Y22.944 F1000
G1 X102.424 Y22.884 F1000
G1 X104.261 Y22.827 F1000
G1 X106.098 Y22.772 F1000
G1 X107.936 Y22.721 F1000
G1 X109.773 Y22.672 F1000
G1 X111.611 Y22.627 F1000
G1 X113.448 Y22.585 F1000
G1 X115.286 Y22.546 F1000
G1 X117.123 Y22.511 F1000
G1 X118.961 Y22.479 F1000
G1 X120.799 Y22.451 F1000
G1 X121.718 Y22.439 F1000
G1 X122.637 Y22.428 F1000
G1 X123.556 Y22.418 F1000
G1 X124.475 Y22.408 F1000
G1 X125.394 Y22.4 F1000
G1 X126.313 Y22.394 F1000
G1 X127.232 Y22.388 F1000
G1 X128.151 Y22.383 F1000
G1 X129.07 Y22.38 F1000
G1 X129.989 Y22.378 F1000
G1 X130.908 Y22.377 F1000
G1 X131.827 Y22.378 F1000
G1 X132.746 Y22.38 F1000
G1 X133.665 Y22.383 F1000
G1 X134.584 Y22.388 F1000
G1 X135.503 Y22.394 F1000
G1 X136.422 Y22.402 F1000
G1 X137.341 Y22.411 F1000
G1 X138.26 Y22.422 F1000
G1 X139.179 Y22.435 F1000
G1 X140.098 Y22.45 F1000
G1 X141.017 Y22.466 F1000
G1 X141.935 Y22.484 F1000
G1 X142.854 Y22.504 F1000
G1 X143.773 Y22.527 F1000
G1 X144.692 Y22.551 F1000
G1 X145.61 Y22.577 F1000
G1 X146.529 Y22.606 F1000
G1 X147.447 Y22.637 F1000
G1 X148.366 Y22.671 F1000
G1 X149.284 Y22.707 F1000
G1 X150.202 Y22.746 F1000
G1 X151.12 Y22.788 F1000
G1 X152.038 Y22.833 F1000
G1 X152.956 Y22.881 F1000
G1 X153.874 Y22.932 F1000
G1 X154.791 Y22.987 F1000
G1 X155.708 Y23.046 F1000
G1 X156.625 Y23.108 F1000
G1 X157.542 Y23.175 F1000
G1 X158.458 Y23.247 F1000
G1 X159.374 Y23.324 F1000
G1 X160.289 Y23.405 F1000
G1 X161.204 Y23.493 F1000
G1 X162.118 Y23.587 F1000
G1 X163.032 Y23.688 F1000
G1 X163.944 Y23.798 F1000
G1 X164.855 Y23.916 F1000
G1 X165.765 Y24.044 F1000
G1 X166.674 Y24.183 F1000
G1 X167.58 Y24.336 F1000
G1 X168.484 Y24.504 F1000
G1 X169.383 Y24.691 F1000
G1 X170.278 Y24.901 F1000
G1 X171.165 Y25.142 F1000
G1 X172.039 Y25.426 F1000
G1 X172.609 Y25.663 F1000
G1 X172.931 Y25.828 F1000
G1 X173.201 Y26.007 F1000
G1 X173.427 Y26.24 F1000
G1 X173.596 Y26.517 F1000
G1 X173.701 Y26.824 F1000
G1 X173.736 Y27.147 F1000
G1 Y29.676 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y30.26 I-0.635 J-0.022 F1000
G1 X173.221 Y30.281 Z-3.012 F1000
G1 X173.153 Y30.302 Z-3 F1000
G1 X173.088 Y30.322 Z-2.98 F1000
G1 X173.025 Y30.341 Z-2.953 F1000
G1 X172.966 Y30.36 Z-2.919 F1000
G1 X172.91 Y30.377 Z-2.877 F1000
G1 X172.859 Y30.393 Z-2.83 F1000
G1 X172.814 Y30.407 Z-2.777 F1000
G1 X172.775 Y30.419 Z-2.719 F1000
G1 X172.742 Y30.429 Z-2.657 F1000
G1 X172.716 Y30.437 Z-2.591 F1000
G1 X172.697 Y30.443 Z-2.522 F1000
G1 X172.685 Y30.446 Z-2.452 F1000
G1 X172.682 Y30.447 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y37.35 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y37.347 Z-2.452 F1000
G1 X22.509 Y37.337 Z-2.522 F1000
G1 X22.499 Y37.32 Z-2.591 F1000
G1 X22.485 Y37.296 Z-2.657 F1000
G1 X22.467 Y37.267 Z-2.719 F1000
G1 X22.446 Y37.231 Z-2.777 F1000
G1 X22.422 Y37.19 Z-2.83 F1000
G1 X22.395 Y37.145 Z-2.877 F1000
G1 X22.365 Y37.095 Z-2.919 F1000
G1 X22.333 Y37.041 Z-2.953 F1000
G1 X22.3 Y36.985 Z-2.98 F1000
G1 X22.265 Y36.926 Z-3 F1000
G1 X22.229 Y36.866 Z-3.012 F1000
G1 X22.192 Y36.805 Z-3.016 F1000
G3 X21.971 Y36.051 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y33.545 F1000
G1 X21.986 Y33.253 F1000
G1 X22.017 Y33.01 F1000
G1 X22.079 Y32.721 F1000
G1 X22.172 Y32.412 F1000
G1 X22.302 Y32.078 F1000
G1 X22.489 Y31.693 F1000
G1 X22.715 Y31.308 F1000
G1 X23.026 Y30.866 F1000
G1 X23.405 Y30.409 F1000
G1 X23.891 Y29.911 F1000
G1 X24.512 Y29.37 F1000
G1 X25.25 Y28.823 F1000
G1 X26.028 Y28.333 F1000
G1 X26.834 Y27.893 F1000
G1 X27.662 Y27.494 F1000
G1 X28.507 Y27.131 F1000
G1 X29.364 Y26.799 F1000
G1 X30.231 Y26.495 F1000
G1 X31.106 Y26.215 F1000
G1 X31.988 Y25.956 F1000
G1 X32.875 Y25.716 F1000
G1 X33.767 Y25.493 F1000
G1 X34.662 Y25.284 F1000
G1 X35.56 Y25.089 F1000
G1 X36.46 Y24.906 F1000
G1 X37.363 Y24.733 F1000
G1 X38.268 Y24.571 F1000
G1 X39.174 Y24.418 F1000
G1 X40.081 Y24.273 F1000
G1 X40.99 Y24.135 F1000
G1 X41.9 Y24.004 F1000
G1 X42.81 Y23.88 F1000
G1 X43.722 Y23.762 F1000
G1 X44.634 Y23.649 F1000
G1 X45.546 Y23.542 F1000
G1 X46.46 Y23.439 F1000
G1 X47.373 Y23.34 F1000
G1 X48.287 Y23.246 F1000
G1 X49.202 Y23.155 F1000
G1 X50.117 Y23.068 F1000
G1 X51.032 Y22.984 F1000
G1 X51.948 Y22.903 F1000
G1 X52.863 Y22.825 F1000
G1 X53.779 Y22.75 F1000
G1 X54.695 Y22.677 F1000
G1 X55.612 Y22.607 F1000
G1 X56.528 Y22.539 F1000
G1 X57.445 Y22.473 F1000
G1 X58.362 Y22.408 F1000
G1 X59.278 Y22.346 F1000
G1 X60.195 Y22.285 F1000
G1 X61.113 Y22.226 F1000
G1 X62.03 Y22.168 F1000
G1 X62.947 Y22.111 F1000
G1 X63.864 Y22.056 F1000
G1 X64.782 Y22.002 F1000
G1 X65.699 Y21.949 F1000
G1 X67.534 Y21.846 F1000
G1 X68.452 Y21.796 F1000
G1 X70.288 Y21.699 F1000
G1 X72.123 Y21.604 F1000
G1 X73.959 Y21.512 F1000
G1 X75.795 Y21.422 F1000
G1 X77.631 Y21.335 F1000
G1 X80.385 Y21.207 F1000
G1 X83.139 Y21.084 F1000
G1 X85.894 Y20.965 F1000
G1 X88.648 Y20.85 F1000
G1 X91.403 Y20.739 F1000
G1 X93.24 Y20.668 F1000
G1 X95.077 Y20.599 F1000
G1 X96.913 Y20.532 F1000
G1 X98.75 Y20.467 F1000
G1 X100.587 Y20.405 F1000
G1 X102.424 Y20.345 F1000
G1 X104.261 Y20.288 F1000
G1 X106.099 Y20.234 F1000
G1 X107.936 Y20.183 F1000
G1 X109.773 Y20.134 F1000
G1 X111.611 Y20.089 F1000
G1 X113.448 Y20.047 F1000
G1 X115.286 Y20.009 F1000
G1 X117.124 Y19.974 F1000
G1 X118.962 Y19.943 F1000
G1 X120.799 Y19.915 F1000
G1 X121.718 Y19.903 F1000
G1 X122.637 Y19.892 F1000
G1 X123.556 Y19.882 F1000
G1 X124.475 Y19.873 F1000
G1 X125.394 Y19.865 F1000
G1 X126.313 Y19.858 F1000
G1 X127.232 Y19.853 F1000
G1 X128.151 Y19.848 F1000
G1 X129.07 Y19.845 F1000
G1 X129.989 Y19.843 F1000
G1 X130.908 Y19.842 F1000
G1 X131.827 Y19.843 F1000
G1 X132.746 Y19.845 F1000
G1 X133.665 Y19.849 F1000
G1 X134.584 Y19.854 F1000
G1 X135.503 Y19.86 F1000
G1 X136.422 Y19.868 F1000
G1 X137.341 Y19.878 F1000
G1 X138.26 Y19.889 F1000
G1 X139.179 Y19.902 F1000
G1 X140.098 Y19.916 F1000
G1 X141.017 Y19.933 F1000
G1 X141.936 Y19.951 F1000
G1 X142.855 Y19.972 F1000
G1 X143.773 Y19.994 F1000
G1 X144.692 Y20.018 F1000
G1 X145.611 Y20.045 F1000
G1 X146.529 Y20.074 F1000
G1 X147.448 Y20.105 F1000
G1 X148.366 Y20.139 F1000
G1 X149.284 Y20.175 F1000
G1 X150.203 Y20.215 F1000
G1 X151.121 Y20.257 F1000
G1 X152.039 Y20.302 F1000
G1 X152.956 Y20.35 F1000
G1 X153.874 Y20.401 F1000
G1 X154.791 Y20.456 F1000
G1 X155.708 Y20.515 F1000
G1 X156.625 Y20.578 F1000
G1 X157.542 Y20.645 F1000
G1 X158.458 Y20.717 F1000
G1 X159.374 Y20.793 F1000
G1 X160.289 Y20.875 F1000
G1 X161.204 Y20.963 F1000
G1 X162.118 Y21.057 F1000
G1 X163.032 Y21.159 F1000
G1 X163.944 Y21.268 F1000
G1 X164.856 Y21.386 F1000
G1 X165.766 Y21.514 F1000
G1 X166.674 Y21.654 F1000
G1 X167.58 Y21.806 F1000
G1 X168.484 Y21.975 F1000
G1 X169.384 Y22.162 F1000
G1 X170.278 Y22.372 F1000
G1 X171.165 Y22.613 F1000
G1 X172.039 Y22.897 F1000
G1 X172.609 Y23.134 F1000
G1 X172.931 Y23.299 F1000
G1 X173.201 Y23.478 F1000
G1 X173.427 Y23.711 F1000
G1 X173.596 Y23.988 F1000
G1 X173.701 Y24.295 F1000
G1 X173.736 Y24.618 F1000
G1 Y27.147 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y27.731 I-0.635 J-0.022 F1000
G1 X173.221 Y27.752 Z-3.012 F1000
G1 X173.153 Y27.773 Z-3 F1000
G1 X173.088 Y27.793 Z-2.98 F1000
G1 X173.025 Y27.812 Z-2.953 F1000
G1 X172.966 Y27.831 Z-2.919 F1000
G1 X172.91 Y27.848 Z-2.877 F1000
G1 X172.859 Y27.864 Z-2.83 F1000
G1 X172.814 Y27.878 Z-2.777 F1000
G1 X172.775 Y27.89 Z-2.719 F1000
G1 X172.742 Y27.9 Z-2.657 F1000
G1 X172.716 Y27.908 Z-2.591 F1000
G1 X172.697 Y27.914 Z-2.522 F1000
G1 X172.685 Y27.917 Z-2.452 F1000
G1 X172.682 Y27.918 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y34.844 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y34.841 Z-2.452 F1000
G1 X22.509 Y34.831 Z-2.522 F1000
G1 X22.499 Y34.814 Z-2.591 F1000
G1 X22.485 Y34.79 Z-2.657 F1000
G1 X22.467 Y34.761 Z-2.719 F1000
G1 X22.446 Y34.725 Z-2.777 F1000
G1 X22.422 Y34.684 Z-2.83 F1000
G1 X22.395 Y34.639 Z-2.877 F1000
G1 X22.365 Y34.589 Z-2.919 F1000
G1 X22.333 Y34.535 Z-2.953 F1000
G1 X22.3 Y34.479 Z-2.98 F1000
G1 X22.265 Y34.42 Z-3 F1000
G1 X22.229 Y34.36 Z-3.012 F1000
G1 X22.192 Y34.298 Z-3.016 F1000
G3 X21.971 Y33.545 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y31.039 F1000
G1 X21.987 Y30.723 F1000
G1 X22.019 Y30.48 F1000
G1 X22.08 Y30.191 F1000
G1 X22.173 Y29.882 F1000
G1 X22.303 Y29.548 F1000
G1 X22.49 Y29.164 F1000
G1 X22.717 Y28.778 F1000
G1 X23.028 Y28.336 F1000
G1 X23.407 Y27.879 F1000
G1 X23.893 Y27.381 F1000
G1 X24.513 Y26.839 F1000
G1 X25.252 Y26.293 F1000
G1 X26.03 Y25.803 F1000
G1 X26.836 Y25.362 F1000
G1 X27.664 Y24.963 F1000
G1 X28.508 Y24.6 F1000
G1 X29.365 Y24.269 F1000
G1 X30.232 Y23.964 F1000
G1 X31.108 Y23.684 F1000
G1 X31.989 Y23.425 F1000
G1 X32.876 Y23.185 F1000
G1 X33.768 Y22.961 F1000
G1 X34.663 Y22.753 F1000
G1 X35.561 Y22.557 F1000
G1 X36.461 Y22.374 F1000
G1 X37.364 Y22.201 F1000
G1 X38.269 Y22.039 F1000
G1 X39.175 Y21.885 F1000
G1 X40.082 Y21.74 F1000
G1 X40.991 Y21.602 F1000
G1 X41.901 Y21.471 F1000
G1 X42.811 Y21.347 F1000
G1 X43.722 Y21.229 F1000
G1 X44.635 Y21.116 F1000
G1 X45.547 Y21.008 F1000
G1 X46.46 Y20.904 F1000
G1 X47.374 Y20.806 F1000
G1 X48.288 Y20.711 F1000
G1 X49.203 Y20.62 F1000
G1 X50.118 Y20.532 F1000
G1 X51.033 Y20.448 F1000
G1 X51.948 Y20.367 F1000
G1 X52.864 Y20.289 F1000
G1 X53.78 Y20.214 F1000
G1 X54.696 Y20.141 F1000
G1 X55.612 Y20.07 F1000
G1 X56.529 Y20.002 F1000
G1 X57.445 Y19.935 F1000
G1 X58.362 Y19.871 F1000
G1 X59.279 Y19.808 F1000
G1 X60.196 Y19.747 F1000
G1 X61.113 Y19.688 F1000
G1 X62.03 Y19.629 F1000
G1 X62.947 Y19.573 F1000
G1 X63.865 Y19.517 F1000
G1 X64.782 Y19.463 F1000
G1 X65.7 Y19.41 F1000
G1 X67.535 Y19.307 F1000
G1 X68.452 Y19.257 F1000
G1 X70.288 Y19.159 F1000
G1 X72.123 Y19.064 F1000
G1 X73.959 Y18.971 F1000
G1 X75.795 Y18.882 F1000
G1 X77.631 Y18.794 F1000
G1 X80.385 Y18.667 F1000
G1 X83.139 Y18.543 F1000
G1 X85.894 Y18.424 F1000
G1 X88.649 Y18.31 F1000
G1 X91.403 Y18.199 F1000
G1 X93.24 Y18.128 F1000
G1 X95.077 Y18.059 F1000
G1 X96.914 Y17.993 F1000
G1 X98.751 Y17.928 F1000
G1 X100.588 Y17.866 F1000
G1 X102.425 Y17.807 F1000
G1 X104.262 Y17.75 F1000
G1 X106.099 Y17.696 F1000
G1 X107.936 Y17.645 F1000
G1 X109.774 Y17.597 F1000
G1 X111.611 Y17.552 F1000
G1 X113.449 Y17.51 F1000
G1 X115.287 Y17.472 F1000
G1 X117.124 Y17.437 F1000
G1 X118.962 Y17.406 F1000
G1 X120.8 Y17.379 F1000
G1 X121.719 Y17.367 F1000
G1 X122.638 Y17.356 F1000
G1 X123.557 Y17.346 F1000
G1 X124.476 Y17.337 F1000
G1 X125.395 Y17.329 F1000
G1 X126.314 Y17.323 F1000
G1 X127.233 Y17.317 F1000
G1 X128.152 Y17.313 F1000
G1 X129.071 Y17.31 F1000
G1 X129.99 Y17.308 F1000
G1 X130.909 F1000
G1 X131.828 F1000
G1 X132.747 Y17.311 F1000
G1 X133.666 Y17.314 F1000
G1 X134.585 Y17.319 F1000
G1 X135.504 Y17.326 F1000
G1 X136.423 Y17.334 F1000
G1 X137.342 Y17.344 F1000
G1 X138.261 Y17.355 F1000
G1 X139.18 Y17.368 F1000
G1 X140.099 Y17.383 F1000
G1 X141.017 Y17.4 F1000
G1 X141.936 Y17.418 F1000
G1 X142.855 Y17.439 F1000
G1 X143.774 Y17.461 F1000
G1 X144.692 Y17.486 F1000
G1 X145.611 Y17.513 F1000
G1 X146.53 Y17.542 F1000
G1 X147.448 Y17.573 F1000
G1 X148.367 Y17.607 F1000
G1 X149.285 Y17.644 F1000
G1 X150.203 Y17.683 F1000
G1 X151.121 Y17.725 F1000
G1 X152.039 Y17.77 F1000
G1 X152.957 Y17.818 F1000
G1 X153.874 Y17.87 F1000
G1 X154.792 Y17.925 F1000
G1 X155.709 Y17.984 F1000
G1 X156.626 Y18.047 F1000
G1 X157.542 Y18.114 F1000
G1 X158.458 Y18.186 F1000
G1 X159.374 Y18.263 F1000
G1 X160.29 Y18.345 F1000
G1 X161.204 Y18.433 F1000
G1 X162.119 Y18.527 F1000
G1 X163.032 Y18.629 F1000
G1 X163.944 Y18.738 F1000
G1 X164.856 Y18.856 F1000
G1 X165.766 Y18.985 F1000
G1 X166.674 Y19.124 F1000
G1 X167.58 Y19.277 F1000
G1 X168.484 Y19.445 F1000
G1 X169.384 Y19.632 F1000
G1 X170.278 Y19.843 F1000
G1 X171.165 Y20.083 F1000
G1 X172.039 Y20.368 F1000
G1 X172.609 Y20.605 F1000
G1 X172.931 Y20.77 F1000
G1 X173.201 Y20.949 F1000
G1 X173.427 Y21.182 F1000
G1 X173.596 Y21.459 F1000
G1 X173.701 Y21.766 F1000
G1 X173.736 Y22.088 F1000
G1 Y24.618 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y25.202 I-0.635 J-0.022 F1000
G1 X173.221 Y25.223 Z-3.012 F1000
G1 X173.153 Y25.244 Z-3 F1000
G1 X173.088 Y25.264 Z-2.98 F1000
G1 X173.025 Y25.283 Z-2.953 F1000
G1 X172.966 Y25.302 Z-2.919 F1000
G1 X172.91 Y25.319 Z-2.877 F1000
G1 X172.859 Y25.334 Z-2.83 F1000
G1 X172.814 Y25.348 Z-2.777 F1000
G1 X172.775 Y25.361 Z-2.719 F1000
G1 X172.742 Y25.371 Z-2.657 F1000
G1 X172.716 Y25.379 Z-2.591 F1000
G1 X172.697 Y25.385 Z-2.522 F1000
G1 X172.685 Y25.388 Z-2.452 F1000
G1 X172.682 Y25.389 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y32.338 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y32.335 Z-2.452 F1000
G1 X22.509 Y32.325 Z-2.522 F1000
G1 X22.499 Y32.308 Z-2.591 F1000
G1 X22.485 Y32.284 Z-2.657 F1000
G1 X22.467 Y32.255 Z-2.719 F1000
G1 X22.446 Y32.219 Z-2.777 F1000
G1 X22.422 Y32.178 Z-2.83 F1000
G1 X22.395 Y32.133 Z-2.877 F1000
G1 X22.365 Y32.083 Z-2.919 F1000
G1 X22.333 Y32.029 Z-2.953 F1000
G1 X22.3 Y31.973 Z-2.98 F1000
G1 X22.265 Y31.914 Z-3 F1000
G1 X22.229 Y31.854 Z-3.012 F1000
G1 X22.192 Y31.792 Z-3.016 F1000
G3 X21.971 Y31.039 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y28.533 F1000
G1 X21.988 Y28.193 F1000
G1 X22.02 Y27.95 F1000
G1 X22.082 Y27.661 F1000
G1 X22.174 Y27.352 F1000
G1 X22.304 Y27.018 F1000
G1 X22.491 Y26.633 F1000
G1 X22.718 Y26.248 F1000
G1 X23.029 Y25.805 F1000
G1 X23.408 Y25.349 F1000
G1 X23.894 Y24.85 F1000
G1 X24.515 Y24.309 F1000
G1 X25.253 Y23.762 F1000
G1 X26.031 Y23.273 F1000
G1 X26.837 Y22.832 F1000
G1 X27.665 Y22.433 F1000
G1 X28.51 Y22.07 F1000
G1 X29.367 Y21.738 F1000
G1 X30.234 Y21.433 F1000
G1 X31.109 Y21.153 F1000
G1 X31.991 Y20.894 F1000
G1 X32.878 Y20.654 F1000
G1 X33.769 Y20.43 F1000
G1 X34.664 Y20.221 F1000
G1 X35.562 Y20.026 F1000
G1 X36.463 Y19.842 F1000
G1 X37.365 Y19.669 F1000
G1 X38.27 Y19.507 F1000
G1 X39.176 Y19.353 F1000
G1 X40.083 Y19.207 F1000
G1 X40.992 Y19.069 F1000
G1 X41.902 Y18.938 F1000
G1 X42.812 Y18.814 F1000
G1 X43.723 Y18.695 F1000
G1 X44.635 Y18.582 F1000
G1 X45.548 Y18.474 F1000
G1 X46.461 Y18.37 F1000
G1 X47.375 Y18.271 F1000
G1 X48.289 Y18.176 F1000
G1 X49.203 Y18.085 F1000
G1 X50.118 Y17.997 F1000
G1 X51.033 Y17.913 F1000
G1 X51.949 Y17.831 F1000
G1 X52.864 Y17.753 F1000
G1 X53.78 Y17.677 F1000
G1 X54.696 Y17.604 F1000
G1 X55.613 Y17.533 F1000
G1 X56.529 Y17.464 F1000
G1 X57.446 Y17.398 F1000
G1 X58.363 Y17.333 F1000
G1 X59.279 Y17.27 F1000
G1 X60.196 Y17.209 F1000
G1 X61.113 Y17.149 F1000
G1 X62.031 Y17.091 F1000
G1 X62.948 Y17.034 F1000
G1 X63.865 Y16.978 F1000
G1 X64.783 Y16.924 F1000
G1 X65.7 Y16.871 F1000
G1 X67.535 Y16.767 F1000
G1 X68.453 Y16.717 F1000
G1 X70.288 Y16.619 F1000
G1 X72.124 Y16.524 F1000
G1 X73.96 Y16.431 F1000
G1 X75.795 Y16.341 F1000
G1 X77.631 Y16.254 F1000
G1 X79.467 Y16.168 F1000
G1 X82.222 Y16.043 F1000
G1 X84.976 Y15.923 F1000
G1 X87.731 Y15.807 F1000
G1 X90.486 Y15.696 F1000
G1 X92.322 Y15.624 F1000
G1 X94.159 Y15.554 F1000
G1 X95.996 Y15.486 F1000
G1 X97.833 Y15.421 F1000
G1 X99.67 Y15.358 F1000
G1 X101.507 Y15.297 F1000
G1 X103.344 Y15.24 F1000
G1 X105.181 Y15.184 F1000
G1 X107.018 Y15.132 F1000
G1 X108.856 Y15.083 F1000
G1 X110.693 Y15.036 F1000
G1 X112.531 Y14.993 F1000
G1 X114.368 Y14.953 F1000
G1 X116.206 Y14.917 F1000
G1 X118.044 Y14.885 F1000
G1 X118.963 Y14.87 F1000
G1 X120.8 Y14.843 F1000
G1 X121.719 Y14.831 F1000
G1 X122.638 Y14.82 F1000
G1 X123.557 Y14.81 F1000
G1 X124.476 Y14.801 F1000
G1 X125.395 Y14.794 F1000
G1 X126.314 Y14.787 F1000
G1 X127.233 Y14.782 F1000
G1 X128.152 Y14.778 F1000
G1 X129.071 Y14.775 F1000
G1 X129.99 Y14.773 F1000
G1 X130.909 F1000
G1 X131.828 Y14.774 F1000
G1 X132.747 Y14.776 F1000
G1 X133.666 Y14.78 F1000
G1 X134.585 Y14.785 F1000
G1 X135.504 Y14.792 F1000
G1 X136.423 Y14.8 F1000
G1 X137.342 Y14.81 F1000
G1 X138.261 Y14.822 F1000
G1 X139.18 Y14.835 F1000
G1 X140.099 Y14.85 F1000
G1 X141.018 Y14.867 F1000
G1 X141.937 Y14.885 F1000
G1 X142.855 Y14.906 F1000
G1 X143.774 Y14.928 F1000
G1 X144.693 Y14.953 F1000
G1 X145.612 Y14.98 F1000
G1 X146.53 Y15.009 F1000
G1 X147.449 Y15.041 F1000
G1 X148.367 Y15.075 F1000
G1 X149.285 Y15.112 F1000
G1 X150.203 Y15.151 F1000
G1 X151.121 Y15.194 F1000
G1 X152.039 Y15.239 F1000
G1 X152.957 Y15.287 F1000
G1 X153.875 Y15.339 F1000
G1 X154.792 Y15.394 F1000
G1 X155.709 Y15.453 F1000
G1 X156.626 Y15.517 F1000
G1 X157.543 Y15.584 F1000
G1 X158.459 Y15.656 F1000
G1 X159.375 Y15.733 F1000
G1 X160.29 Y15.815 F1000
G1 X161.205 Y15.903 F1000
G1 X162.119 Y15.997 F1000
G1 X163.032 Y16.099 F1000
G1 X163.945 Y16.208 F1000
G1 X164.856 Y16.327 F1000
G1 X165.766 Y16.455 F1000
G1 X166.674 Y16.595 F1000
G1 X167.581 Y16.748 F1000
G1 X168.484 Y16.916 F1000
G1 X169.384 Y17.103 F1000
G1 X170.278 Y17.314 F1000
G1 X171.165 Y17.554 F1000
G1 X172.039 Y17.839 F1000
G1 X172.61 Y18.076 F1000
G1 X172.931 Y18.241 F1000
G1 X173.202 Y18.42 F1000
G1 X173.427 Y18.653 F1000
G1 X173.596 Y18.93 F1000
G1 X173.701 Y19.237 F1000
G1 X173.736 Y19.559 F1000
G1 Y22.088 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y22.673 I-0.635 J-0.022 F1000
G1 X173.221 Y22.694 Z-3.012 F1000
G1 X173.153 Y22.715 Z-3 F1000
G1 X173.088 Y22.735 Z-2.98 F1000
G1 X173.025 Y22.754 Z-2.953 F1000
G1 X172.966 Y22.773 Z-2.919 F1000
G1 X172.91 Y22.79 Z-2.877 F1000
G1 X172.859 Y22.805 Z-2.83 F1000
G1 X172.814 Y22.819 Z-2.777 F1000
G1 X172.775 Y22.831 Z-2.719 F1000
G1 X172.742 Y22.842 Z-2.657 F1000
G1 X172.716 Y22.85 Z-2.591 F1000
G1 X172.697 Y22.855 Z-2.522 F1000
G1 X172.685 Y22.859 Z-2.452 F1000
G1 X172.682 Y22.86 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y29.832 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y29.829 Z-2.452 F1000
G1 X22.509 Y29.819 Z-2.522 F1000
G1 X22.499 Y29.802 Z-2.591 F1000
G1 X22.485 Y29.778 Z-2.657 F1000
G1 X22.467 Y29.749 Z-2.719 F1000
G1 X22.446 Y29.713 Z-2.777 F1000
G1 X22.422 Y29.672 Z-2.83 F1000
G1 X22.395 Y29.627 Z-2.877 F1000
G1 X22.365 Y29.577 Z-2.919 F1000
G1 X22.333 Y29.523 Z-2.953 F1000
G1 X22.3 Y29.467 Z-2.98 F1000
G1 X22.265 Y29.408 Z-3 F1000
G1 X22.229 Y29.348 Z-3.012 F1000
G1 X22.192 Y29.286 Z-3.016 F1000
G3 X21.971 Y28.533 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y26.027 F1000
G1 X21.989 Y25.663 F1000
G1 X22.021 Y25.42 F1000
G1 X22.083 Y25.131 F1000
G1 X22.176 Y24.822 F1000
G1 X22.306 Y24.488 F1000
G1 X22.492 Y24.103 F1000
G1 X22.719 Y23.718 F1000
G1 X23.03 Y23.275 F1000
G1 X23.409 Y22.818 F1000
G1 X23.896 Y22.32 F1000
G1 X24.516 Y21.778 F1000
G1 X25.255 Y21.232 F1000
G1 X26.033 Y20.742 F1000
G1 X26.839 Y20.301 F1000
G1 X27.667 Y19.902 F1000
G1 X28.511 Y19.539 F1000
G1 X29.368 Y19.207 F1000
G1 X30.235 Y18.903 F1000
G1 X31.11 Y18.622 F1000
G1 X31.992 Y18.363 F1000
G1 X32.879 Y18.122 F1000
G1 X33.77 Y17.899 F1000
G1 X34.665 Y17.69 F1000
G1 X35.563 Y17.494 F1000
G1 X36.464 Y17.31 F1000
G1 X37.366 Y17.137 F1000
G1 X38.271 Y16.974 F1000
G1 X39.177 Y16.82 F1000
G1 X40.084 Y16.675 F1000
G1 X40.993 Y16.536 F1000
G1 X41.903 Y16.405 F1000
G1 X42.813 Y16.28 F1000
G1 X43.724 Y16.161 F1000
G1 X44.636 Y16.048 F1000
G1 X45.549 Y15.939 F1000
G1 X46.462 Y15.836 F1000
G1 X47.376 Y15.736 F1000
G1 X48.29 Y15.641 F1000
G1 X49.204 Y15.55 F1000
G1 X50.119 Y15.462 F1000
G1 X51.034 Y15.377 F1000
G1 X51.949 Y15.296 F1000
G1 X52.865 Y15.217 F1000
G1 X53.781 Y15.141 F1000
G1 X54.697 Y15.067 F1000
G1 X55.613 Y14.996 F1000
G1 X56.53 Y14.927 F1000
G1 X57.446 Y14.86 F1000
G1 X58.363 Y14.795 F1000
G1 X59.28 Y14.732 F1000
G1 X60.197 Y14.671 F1000
G1 X61.114 Y14.611 F1000
G1 X62.031 Y14.552 F1000
G1 X62.948 Y14.495 F1000
G1 X63.866 Y14.44 F1000
G1 X64.783 Y14.385 F1000
G1 X65.701 Y14.332 F1000
G1 X67.536 Y14.228 F1000
G1 X68.453 Y14.177 F1000
G1 X70.289 Y14.079 F1000
G1 X72.124 Y13.983 F1000
G1 X73.96 Y13.891 F1000
G1 X75.796 Y13.801 F1000
G1 X77.632 Y13.713 F1000
G1 X79.468 Y13.628 F1000
G1 X82.222 Y13.503 F1000
G1 X84.976 Y13.383 F1000
G1 X87.731 Y13.267 F1000
G1 X90.486 Y13.156 F1000
G1 X92.323 Y13.084 F1000
G1 X94.159 Y13.014 F1000
G1 X95.996 Y12.947 F1000
G1 X97.833 Y12.882 F1000
G1 X99.67 Y12.819 F1000
G1 X101.507 Y12.759 F1000
G1 X103.344 Y12.701 F1000
G1 X105.181 Y12.646 F1000
G1 X107.019 Y12.594 F1000
G1 X108.856 Y12.545 F1000
G1 X110.694 Y12.499 F1000
G1 X112.531 Y12.456 F1000
G1 X114.369 Y12.416 F1000
G1 X116.206 Y12.38 F1000
G1 X118.044 Y12.348 F1000
G1 X118.963 Y12.333 F1000
G1 X120.801 Y12.307 F1000
G1 X121.72 Y12.295 F1000
G1 X122.639 Y12.284 F1000
G1 X123.558 Y12.274 F1000
G1 X124.477 Y12.266 F1000
G1 X125.396 Y12.258 F1000
G1 X126.315 Y12.252 F1000
G1 X127.234 Y12.247 F1000
G1 X128.153 Y12.243 F1000
G1 X129.072 Y12.24 F1000
G1 X129.991 Y12.238 F1000
G1 X130.91 F1000
G1 X131.829 Y12.239 F1000
G1 X132.748 Y12.242 F1000
G1 X133.667 Y12.246 F1000
G1 X134.586 Y12.251 F1000
G1 X135.505 Y12.258 F1000
G1 X136.424 Y12.266 F1000
G1 X137.343 Y12.276 F1000
G1 X138.262 Y12.288 F1000
G1 X139.181 Y12.301 F1000
G1 X140.1 Y12.316 F1000
G1 X141.018 Y12.333 F1000
G1 X141.937 Y12.352 F1000
G1 X142.856 Y12.373 F1000
G1 X143.775 Y12.396 F1000
G1 X144.693 Y12.421 F1000
G1 X145.612 Y12.448 F1000
G1 X146.531 Y12.477 F1000
G1 X147.449 Y12.509 F1000
G1 X148.367 Y12.543 F1000
G1 X149.286 Y12.58 F1000
G1 X150.204 Y12.62 F1000
G1 X151.122 Y12.662 F1000
G1 X152.04 Y12.707 F1000
G1 X152.958 Y12.756 F1000
G1 X153.875 Y12.808 F1000
G1 X154.792 Y12.863 F1000
G1 X155.71 Y12.923 F1000
G1 X156.626 Y12.986 F1000
G1 X157.543 Y13.053 F1000
G1 X158.459 Y13.125 F1000
G1 X159.375 Y13.202 F1000
G1 X160.29 Y13.285 F1000
G1 X161.205 Y13.373 F1000
G1 X162.119 Y13.467 F1000
G1 X163.033 Y13.569 F1000
G1 X163.945 Y13.679 F1000
G1 X164.856 Y13.797 F1000
G1 X165.766 Y13.925 F1000
G1 X166.675 Y14.065 F1000
G1 X167.581 Y14.218 F1000
G1 X168.484 Y14.387 F1000
G1 X169.384 Y14.574 F1000
G1 X170.279 Y14.784 F1000
G1 X171.166 Y15.025 F1000
G1 X172.039 Y15.31 F1000
G1 X172.61 Y15.547 F1000
G1 X172.931 Y15.712 F1000
G1 X173.202 Y15.891 F1000
G1 X173.427 Y16.124 F1000
G1 X173.596 Y16.401 F1000
G1 X173.701 Y16.708 F1000
G1 X173.736 Y17.03 F1000
G1 Y19.559 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y20.144 I-0.635 J-0.022 F1000
G1 X173.221 Y20.165 Z-3.012 F1000
G1 X173.153 Y20.185 Z-3 F1000
G1 X173.088 Y20.206 Z-2.98 F1000
G1 X173.025 Y20.225 Z-2.953 F1000
G1 X172.966 Y20.243 Z-2.919 F1000
G1 X172.91 Y20.26 Z-2.877 F1000
G1 X172.859 Y20.276 Z-2.83 F1000
G1 X172.814 Y20.29 Z-2.777 F1000
G1 X172.775 Y20.302 Z-2.719 F1000
G1 X172.742 Y20.312 Z-2.657 F1000
G1 X172.716 Y20.32 Z-2.591 F1000
G1 X172.697 Y20.326 Z-2.522 F1000
G1 X172.685 Y20.33 Z-2.452 F1000
G1 X172.682 Y20.331 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y27.326 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y27.323 Z-2.452 F1000
G1 X22.509 Y27.313 Z-2.522 F1000
G1 X22.499 Y27.296 Z-2.591 F1000
G1 X22.485 Y27.272 Z-2.657 F1000
G1 X22.467 Y27.243 Z-2.719 F1000
G1 X22.446 Y27.207 Z-2.777 F1000
G1 X22.422 Y27.166 Z-2.83 F1000
G1 X22.395 Y27.121 Z-2.877 F1000
G1 X22.365 Y27.071 Z-2.919 F1000
G1 X22.333 Y27.017 Z-2.953 F1000
G1 X22.3 Y26.961 Z-2.98 F1000
G1 X22.265 Y26.902 Z-3 F1000
G1 X22.229 Y26.842 Z-3.012 F1000
G1 X22.192 Y26.78 Z-3.016 F1000
G3 X21.971 Y26.027 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y23.312 F1000
G1 X21.979 Y23.143 F1000
G1 X22.011 Y22.899 F1000
G1 X22.073 Y22.611 F1000
G1 X22.166 Y22.299 F1000
G1 X22.296 Y21.965 F1000
G1 X22.484 Y21.579 F1000
G1 X22.711 Y21.193 F1000
G1 X23.023 Y20.749 F1000
G1 X23.402 Y20.292 F1000
G1 X23.889 Y19.793 F1000
G1 X24.511 Y19.25 F1000
G1 X25.25 Y18.704 F1000
G1 X26.028 Y18.214 F1000
G1 X26.834 Y17.773 F1000
G1 X27.662 Y17.374 F1000
G1 X28.506 Y17.01 F1000
G1 X29.363 Y16.678 F1000
G1 X30.23 Y16.374 F1000
G1 X31.105 Y16.093 F1000
G1 X31.986 Y15.833 F1000
G1 X32.873 Y15.593 F1000
G1 X33.765 Y15.369 F1000
G1 X34.66 Y15.159 F1000
G1 X35.557 Y14.963 F1000
G1 X36.458 Y14.779 F1000
G1 X37.36 Y14.606 F1000
G1 X38.265 Y14.443 F1000
G1 X39.171 Y14.289 F1000
G1 X40.078 Y14.143 F1000
G1 X40.987 Y14.004 F1000
G1 X41.896 Y13.873 F1000
G1 X42.807 Y13.748 F1000
G1 X43.718 Y13.628 F1000
G1 X44.63 Y13.515 F1000
G1 X45.542 Y13.406 F1000
G1 X46.456 Y13.302 F1000
G1 X47.369 Y13.202 F1000
G1 X48.283 Y13.107 F1000
G1 X49.198 Y13.015 F1000
G1 X50.112 Y12.927 F1000
G1 X51.028 Y12.842 F1000
G1 X51.943 Y12.76 F1000
G1 X52.859 Y12.681 F1000
G1 X53.774 Y12.605 F1000
G1 X54.69 Y12.531 F1000
G1 X55.607 Y12.46 F1000
G1 X56.523 Y12.391 F1000
G1 X57.44 Y12.324 F1000
G1 X58.356 Y12.258 F1000
G1 X59.273 Y12.195 F1000
G1 X60.19 Y12.133 F1000
G1 X61.107 Y12.073 F1000
G1 X62.024 Y12.014 F1000
G1 X62.942 Y11.957 F1000
G1 X63.859 Y11.901 F1000
G1 X64.776 Y11.846 F1000
G1 X65.694 Y11.793 F1000
G1 X67.529 Y11.689 F1000
G1 X69.364 Y11.588 F1000
G1 X71.2 Y11.491 F1000
G1 X73.035 Y11.397 F1000
G1 X74.871 Y11.306 F1000
G1 X76.707 Y11.217 F1000
G1 X78.543 Y11.13 F1000
G1 X80.379 Y11.045 F1000
G1 X83.133 Y10.922 F1000
G1 X85.888 Y10.804 F1000
G1 X88.642 Y10.69 F1000
G1 X90.479 Y10.616 F1000
G1 X92.316 Y10.544 F1000
G1 X94.152 Y10.475 F1000
G1 X95.989 Y10.408 F1000
G1 X97.826 Y10.343 F1000
G1 X99.663 Y10.28 F1000
G1 X101.5 Y10.22 F1000
G1 X103.337 Y10.163 F1000
G1 X105.175 Y10.108 F1000
G1 X107.012 Y10.056 F1000
G1 X108.849 Y10.007 F1000
G1 X110.687 Y9.961 F1000
G1 X112.524 Y9.919 F1000
G1 X114.362 Y9.88 F1000
G1 X116.2 Y9.844 F1000
G1 X118.037 Y9.812 F1000
G1 X119.875 Y9.783 F1000
G1 X121.713 Y9.759 F1000
G1 X122.632 Y9.748 F1000
G1 X123.551 Y9.739 F1000
G1 X124.47 Y9.73 F1000
G1 X125.389 Y9.723 F1000
G1 X126.308 Y9.716 F1000
G1 X127.227 Y9.711 F1000
G1 X128.146 Y9.708 F1000
G1 X129.065 Y9.705 F1000
G1 X129.984 Y9.704 F1000
G1 X130.903 Y9.703 F1000
G1 X131.822 Y9.705 F1000
G1 X132.741 Y9.707 F1000
G1 X133.66 Y9.711 F1000
G1 X134.579 Y9.717 F1000
G1 X135.498 Y9.724 F1000
G1 X136.417 Y9.732 F1000
G1 X137.336 Y9.743 F1000
G1 X138.255 Y9.754 F1000
G1 X139.174 Y9.768 F1000
G1 X140.093 Y9.783 F1000
G1 X141.012 Y9.8 F1000
G1 X141.93 Y9.819 F1000
G1 X142.849 Y9.84 F1000
G1 X143.768 Y9.863 F1000
G1 X144.687 Y9.888 F1000
G1 X145.605 Y9.915 F1000
G1 X146.524 Y9.945 F1000
G1 X147.442 Y9.977 F1000
G1 X148.361 Y10.011 F1000
G1 X149.279 Y10.048 F1000
G1 X150.197 Y10.088 F1000
G1 X151.115 Y10.13 F1000
G1 X152.033 Y10.176 F1000
G1 X152.951 Y10.224 F1000
G1 X153.868 Y10.276 F1000
G1 X154.786 Y10.332 F1000
G1 X155.703 Y10.391 F1000
G1 X156.62 Y10.455 F1000
G1 X157.536 Y10.522 F1000
G1 X158.452 Y10.594 F1000
G1 X159.368 Y10.671 F1000
G1 X160.283 Y10.754 F1000
G1 X161.198 Y10.842 F1000
G1 X162.112 Y10.937 F1000
G1 X163.026 Y11.038 F1000
G1 X163.938 Y11.148 F1000
G1 X164.849 Y11.266 F1000
G1 X165.759 Y11.395 F1000
G1 X166.668 Y11.534 F1000
G1 X167.574 Y11.687 F1000
G1 X168.477 Y11.856 F1000
G1 X169.377 Y12.043 F1000
G1 X170.272 Y12.253 F1000
G1 X171.159 Y12.494 F1000
G1 X172.033 Y12.778 F1000
G1 X172.605 Y13.015 F1000
G1 X172.93 Y13.182 F1000
G1 X173.201 Y13.361 F1000
G1 X173.426 Y13.594 F1000
G1 X173.596 Y13.871 F1000
G1 X173.7 Y14.178 F1000
G1 X173.736 Y14.501 F1000
G1 Y17.03 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y17.615 I-0.635 J-0.022 F1000
G1 X173.221 Y17.635 Z-3.012 F1000
G1 X173.153 Y17.656 Z-3 F1000
G1 X173.088 Y17.676 Z-2.98 F1000
G1 X173.025 Y17.696 Z-2.953 F1000
G1 X172.966 Y17.714 Z-2.919 F1000
G1 X172.91 Y17.731 Z-2.877 F1000
G1 X172.859 Y17.747 Z-2.83 F1000
G1 X172.814 Y17.761 Z-2.777 F1000
G1 X172.775 Y17.773 Z-2.719 F1000
G1 X172.742 Y17.783 Z-2.657 F1000
G1 X172.716 Y17.791 Z-2.591 F1000
G1 X172.697 Y17.797 Z-2.522 F1000
G1 X172.685 Y17.8 Z-2.452 F1000
G1 X172.682 Y17.802 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y24.611 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y24.608 Z-2.452 F1000
G1 X22.509 Y24.598 Z-2.522 F1000
G1 X22.499 Y24.581 Z-2.591 F1000
G1 X22.485 Y24.557 Z-2.657 F1000
G1 X22.467 Y24.528 Z-2.719 F1000
G1 X22.446 Y24.492 Z-2.777 F1000
G1 X22.422 Y24.452 Z-2.83 F1000
G1 X22.395 Y24.406 Z-2.877 F1000
G1 X22.365 Y24.356 Z-2.919 F1000
G1 X22.333 Y24.302 Z-2.953 F1000
G1 X22.3 Y24.246 Z-2.98 F1000
G1 X22.265 Y24.187 Z-3 F1000
G1 X22.229 Y24.127 Z-3.012 F1000
G1 X22.192 Y24.066 Z-3.016 F1000
G3 X21.971 Y23.312 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y20.806 F1000
G1 X21.981 Y20.609 F1000
G1 X22.013 Y20.366 F1000
G1 X22.074 Y20.077 F1000
G1 X22.167 Y19.767 F1000
G1 X22.298 Y19.433 F1000
G1 X22.484 Y19.048 F1000
G1 X22.711 Y18.662 F1000
G1 X23.023 Y18.218 F1000
G1 X23.402 Y17.761 F1000
G1 X23.889 Y17.262 F1000
G1 X24.511 Y16.72 F1000
G1 X25.25 Y16.173 F1000
G1 X26.027 Y15.683 F1000
G1 X26.834 Y15.242 F1000
G1 X27.661 Y14.843 F1000
G1 X28.505 Y14.48 F1000
G1 X29.362 Y14.147 F1000
G1 X30.229 Y13.843 F1000
G1 X31.104 Y13.562 F1000
G1 X31.986 Y13.302 F1000
G1 X32.873 Y13.062 F1000
G1 X33.764 Y12.837 F1000
G1 X34.659 Y12.628 F1000
G1 X35.557 Y12.432 F1000
G1 X36.457 Y12.248 F1000
G1 X37.36 Y12.074 F1000
G1 X38.264 Y11.911 F1000
G1 X39.17 Y11.756 F1000
G1 X40.077 Y11.61 F1000
G1 X40.986 Y11.471 F1000
G1 X41.895 Y11.34 F1000
G1 X42.806 Y11.214 F1000
G1 X43.717 Y11.095 F1000
G1 X44.629 Y10.981 F1000
G1 X45.542 Y10.872 F1000
G1 X46.455 Y10.768 F1000
G1 X47.368 Y10.668 F1000
G1 X48.282 Y10.572 F1000
G1 X49.197 Y10.48 F1000
G1 X50.111 Y10.391 F1000
G1 X51.026 Y10.306 F1000
G1 X51.942 Y10.224 F1000
G1 X52.857 Y10.145 F1000
G1 X53.773 Y10.069 F1000
G1 X54.689 Y9.995 F1000
G1 X55.605 Y9.923 F1000
G1 X56.522 Y9.854 F1000
G1 X57.438 Y9.786 F1000
G1 X58.355 Y9.721 F1000
G1 X59.272 Y9.657 F1000
G1 X60.189 Y9.595 F1000
G1 X61.106 Y9.535 F1000
G1 X62.023 Y9.476 F1000
G1 X62.94 Y9.419 F1000
G1 X63.858 Y9.362 F1000
G1 X64.775 Y9.307 F1000
G1 X65.692 Y9.254 F1000
G1 X67.527 Y9.149 F1000
G1 X69.363 Y9.049 F1000
G1 X71.198 Y8.951 F1000
G1 X73.034 Y8.857 F1000
G1 X74.87 Y8.765 F1000
G1 X76.705 Y8.676 F1000
G1 X78.541 Y8.59 F1000
G1 X80.378 Y8.505 F1000
G1 X83.132 Y8.382 F1000
G1 X85.886 Y8.264 F1000
G1 X88.641 Y8.15 F1000
G1 X90.478 Y8.076 F1000
G1 X92.314 Y8.005 F1000
G1 X94.151 Y7.936 F1000
G1 X95.988 Y7.868 F1000
G1 X97.825 Y7.804 F1000
G1 X99.662 Y7.741 F1000
G1 X101.499 Y7.682 F1000
G1 X103.336 Y7.624 F1000
G1 X105.173 Y7.57 F1000
G1 X107.01 Y7.518 F1000
G1 X108.848 Y7.47 F1000
G1 X110.685 Y7.424 F1000
G1 X112.523 Y7.382 F1000
G1 X114.361 Y7.343 F1000
G1 X116.198 Y7.307 F1000
G1 X118.036 Y7.275 F1000
G1 X119.874 Y7.247 F1000
G1 X121.712 Y7.223 F1000
G1 X122.631 Y7.212 F1000
G1 X123.55 Y7.203 F1000
G1 X124.469 Y7.194 F1000
G1 X125.388 Y7.187 F1000
G1 X126.307 Y7.181 F1000
G1 X127.226 Y7.176 F1000
G1 X128.145 Y7.172 F1000
G1 X129.064 Y7.17 F1000
G1 X129.983 Y7.169 F1000
G1 X130.902 F1000
G1 X131.821 Y7.17 F1000
G1 X132.74 Y7.173 F1000
G1 X133.659 Y7.177 F1000
G1 X134.578 Y7.183 F1000
G1 X135.497 Y7.19 F1000
G1 X136.416 Y7.199 F1000
G1 X137.335 Y7.209 F1000
G1 X138.254 Y7.221 F1000
G1 X139.173 Y7.234 F1000
G1 X140.091 Y7.25 F1000
G1 X141.01 Y7.267 F1000
G1 X141.929 Y7.286 F1000
G1 X142.848 Y7.307 F1000
G1 X143.767 Y7.33 F1000
G1 X144.685 Y7.355 F1000
G1 X145.604 Y7.383 F1000
G1 X146.522 Y7.412 F1000
G1 X147.441 Y7.444 F1000
G1 X148.359 Y7.479 F1000
G1 X149.278 Y7.516 F1000
G1 X150.196 Y7.556 F1000
G1 X151.114 Y7.598 F1000
G1 X152.032 Y7.644 F1000
G1 X152.949 Y7.693 F1000
G1 X153.867 Y7.745 F1000
G1 X154.784 Y7.801 F1000
G1 X155.701 Y7.86 F1000
G1 X156.618 Y7.924 F1000
G1 X157.535 Y7.991 F1000
G1 X158.451 Y8.064 F1000
G1 X159.367 Y8.141 F1000
G1 X160.282 Y8.223 F1000
G1 X161.197 Y8.311 F1000
G1 X162.111 Y8.406 F1000
G1 X163.024 Y8.508 F1000
G1 X163.937 Y8.618 F1000
G1 X164.848 Y8.736 F1000
G1 X165.758 Y8.865 F1000
G1 X166.666 Y9.004 F1000
G1 X167.573 Y9.157 F1000
G1 X168.476 Y9.326 F1000
G1 X169.376 Y9.513 F1000
G1 X170.27 Y9.723 F1000
G1 X171.157 Y9.964 F1000
G1 X172.031 Y10.248 F1000
G1 X172.604 Y10.485 F1000
G1 X172.93 Y10.652 F1000
G1 X173.201 Y10.831 F1000
G1 X173.426 Y11.065 F1000
G1 X173.596 Y11.341 F1000
G1 X173.7 Y11.649 F1000
G1 X173.736 Y11.971 F1000
G1 Y14.501 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y15.085 I-0.635 J-0.022 F1000
G1 X173.221 Y15.106 Z-3.012 F1000
G1 X173.153 Y15.127 Z-3 F1000
G1 X173.088 Y15.147 Z-2.98 F1000
G1 X173.025 Y15.166 Z-2.953 F1000
G1 X172.966 Y15.185 Z-2.919 F1000
G1 X172.91 Y15.202 Z-2.877 F1000
G1 X172.859 Y15.217 Z-2.83 F1000
G1 X172.814 Y15.231 Z-2.777 F1000
G1 X172.775 Y15.244 Z-2.719 F1000
G1 X172.742 Y15.254 Z-2.657 F1000
G1 X172.716 Y15.262 Z-2.591 F1000
G1 X172.697 Y15.268 Z-2.522 F1000
G1 X172.685 Y15.271 Z-2.452 F1000
G1 X172.682 Y15.272 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y22.105 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y22.102 Z-2.452 F1000
G1 X22.509 Y22.092 Z-2.522 F1000
G1 X22.499 Y22.075 Z-2.591 F1000
G1 X22.485 Y22.051 Z-2.657 F1000
G1 X22.467 Y22.022 Z-2.719 F1000
G1 X22.446 Y21.986 Z-2.777 F1000
G1 X22.422 Y21.946 Z-2.83 F1000
G1 X22.395 Y21.9 Z-2.877 F1000
G1 X22.365 Y21.85 Z-2.919 F1000
G1 X22.333 Y21.796 Z-2.953 F1000
G1 X22.3 Y21.74 Z-2.98 F1000
G1 X22.265 Y21.681 Z-3 F1000
G1 X22.229 Y21.621 Z-3.012 F1000
G1 X22.192 Y21.56 Z-3.016 F1000
G3 X21.971 Y20.806 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y18.3 F1000
G1 X21.982 Y18.077 F1000
G1 X22.014 Y17.834 F1000
G1 X22.076 Y17.545 F1000
G1 X22.169 Y17.235 F1000
G1 X22.299 Y16.901 F1000
G1 X22.486 Y16.516 F1000
G1 X22.713 Y16.13 F1000
G1 X23.024 Y15.687 F1000
G1 X23.403 Y15.23 F1000
G1 X23.89 Y14.731 F1000
G1 X24.512 Y14.189 F1000
G1 X25.251 Y13.642 F1000
G1 X26.028 Y13.152 F1000
G1 X26.834 Y12.711 F1000
G1 X27.662 Y12.312 F1000
G1 X28.506 Y11.948 F1000
G1 X29.363 Y11.616 F1000
G1 X30.23 Y11.311 F1000
G1 X31.105 Y11.031 F1000
G1 X31.987 Y10.771 F1000
G1 X32.874 Y10.53 F1000
G1 X33.765 Y10.305 F1000
G1 X34.66 Y10.096 F1000
G1 X35.557 Y9.9 F1000
G1 X36.458 Y9.715 F1000
G1 X37.36 Y9.542 F1000
G1 X38.265 Y9.378 F1000
G1 X39.171 Y9.224 F1000
G1 X40.078 Y9.077 F1000
G1 X40.986 Y8.938 F1000
G1 X41.896 Y8.806 F1000
G1 X42.806 Y8.681 F1000
G1 X43.717 Y8.561 F1000
G1 X44.629 Y8.447 F1000
G1 X45.542 Y8.338 F1000
G1 X46.455 Y8.233 F1000
G1 X47.368 Y8.133 F1000
G1 X48.282 Y8.037 F1000
G1 X49.197 Y7.945 F1000
G1 X50.111 Y7.856 F1000
G1 X51.026 Y7.771 F1000
G1 X51.942 Y7.688 F1000
G1 X52.857 Y7.609 F1000
G1 X53.773 Y7.532 F1000
G1 X54.689 Y7.458 F1000
G1 X55.605 Y7.386 F1000
G1 X56.522 Y7.316 F1000
G1 X57.438 Y7.249 F1000
G1 X58.355 Y7.183 F1000
G1 X59.272 Y7.119 F1000
G1 X60.189 Y7.057 F1000
G1 X61.106 Y6.997 F1000
G1 X62.023 Y6.937 F1000
G1 X62.94 Y6.88 F1000
G1 X63.857 Y6.824 F1000
G1 X64.775 Y6.768 F1000
G1 X65.692 Y6.714 F1000
G1 X66.61 Y6.662 F1000
G1 X68.445 Y6.559 F1000
G1 X70.28 Y6.46 F1000
G1 X72.116 Y6.364 F1000
G1 X73.951 Y6.271 F1000
G1 X75.787 Y6.18 F1000
G1 X77.623 Y6.092 F1000
G1 X79.459 Y6.007 F1000
G1 X81.295 Y5.923 F1000
G1 X83.132 Y5.842 F1000
G1 X85.886 Y5.724 F1000
G1 X88.641 Y5.61 F1000
G1 X90.477 Y5.536 F1000
G1 X92.314 Y5.465 F1000
G1 X94.151 Y5.396 F1000
G1 X95.988 Y5.329 F1000
G1 X97.825 Y5.265 F1000
G1 X99.662 Y5.203 F1000
G1 X101.499 Y5.143 F1000
G1 X103.336 Y5.086 F1000
G1 X105.173 Y5.032 F1000
G1 X107.01 Y4.98 F1000
G1 X108.848 Y4.932 F1000
G1 X110.685 Y4.886 F1000
G1 X112.523 Y4.844 F1000
G1 X114.36 Y4.805 F1000
G1 X116.198 Y4.77 F1000
G1 X118.036 Y4.739 F1000
G1 X118.955 Y4.724 F1000
G1 X120.793 Y4.698 F1000
G1 X121.712 Y4.687 F1000
G1 X122.631 Y4.676 F1000
G1 X123.55 Y4.667 F1000
G1 X124.469 Y4.659 F1000
G1 X125.388 Y4.652 F1000
G1 X126.307 Y4.646 F1000
G1 X127.226 Y4.641 F1000
G1 X128.145 Y4.637 F1000
G1 X129.064 Y4.635 F1000
G1 X129.983 Y4.634 F1000
G1 X130.902 F1000
G1 X131.821 Y4.636 F1000
G1 X132.74 Y4.638 F1000
G1 X133.659 Y4.643 F1000
G1 X134.578 Y4.649 F1000
G1 X135.497 Y4.656 F1000
G1 X136.416 Y4.665 F1000
G1 X137.335 Y4.675 F1000
G1 X138.253 Y4.687 F1000
G1 X139.172 Y4.701 F1000
G1 X140.091 Y4.716 F1000
G1 X141.01 Y4.734 F1000
G1 X141.929 Y4.753 F1000
G1 X142.848 Y4.774 F1000
G1 X143.766 Y4.797 F1000
G1 X144.685 Y4.823 F1000
G1 X145.604 Y4.85 F1000
G1 X146.522 Y4.88 F1000
G1 X147.441 Y4.912 F1000
G1 X148.359 Y4.947 F1000
G1 X149.277 Y4.984 F1000
G1 X150.196 Y5.024 F1000
G1 X151.114 Y5.067 F1000
G1 X152.031 Y5.113 F1000
G1 X152.949 Y5.162 F1000
G1 X153.867 Y5.214 F1000
G1 X154.784 Y5.27 F1000
G1 X155.701 Y5.329 F1000
G1 X156.618 Y5.393 F1000
G1 X157.534 Y5.461 F1000
G1 X158.451 Y5.533 F1000
G1 X159.366 Y5.61 F1000
G1 X160.282 Y5.693 F1000
G1 X161.196 Y5.781 F1000
G1 X162.111 Y5.876 F1000
G1 X163.024 Y5.978 F1000
G1 X163.936 Y6.088 F1000
G1 X164.848 Y6.206 F1000
G1 X165.758 Y6.335 F1000
G1 X166.666 Y6.475 F1000
G1 X167.572 Y6.628 F1000
G1 X168.476 Y6.796 F1000
G1 X169.375 Y6.983 F1000
G1 X170.27 Y7.194 F1000
G1 X171.157 Y7.434 F1000
G1 X172.031 Y7.719 F1000
G1 X172.603 Y7.956 F1000
G1 X172.93 Y8.123 F1000
G1 X173.201 Y8.302 F1000
G1 X173.426 Y8.535 F1000
G1 X173.596 Y8.812 F1000
G1 X173.7 Y9.119 F1000
G1 X173.736 Y9.442 F1000
G1 Y11.971 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y12.556 I-0.635 J-0.022 F1000
G1 X173.221 Y12.577 Z-3.012 F1000
G1 X173.153 Y12.597 Z-3 F1000
G1 X173.088 Y12.618 Z-2.98 F1000
G1 X173.025 Y12.637 Z-2.953 F1000
G1 X172.966 Y12.655 Z-2.919 F1000
G1 X172.91 Y12.672 Z-2.877 F1000
G1 X172.859 Y12.688 Z-2.83 F1000
G1 X172.814 Y12.702 Z-2.777 F1000
G1 X172.775 Y12.714 Z-2.719 F1000
G1 X172.742 Y12.724 Z-2.657 F1000
G1 X172.716 Y12.732 Z-2.591 F1000
G1 X172.697 Y12.738 Z-2.522 F1000
G1 X172.685 Y12.742 Z-2.452 F1000
G1 X172.682 Y12.743 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y19.599 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y19.596 Z-2.452 F1000
G1 X22.509 Y19.586 Z-2.522 F1000
G1 X22.499 Y19.569 Z-2.591 F1000
G1 X22.485 Y19.545 Z-2.657 F1000
G1 X22.467 Y19.516 Z-2.719 F1000
G1 X22.446 Y19.48 Z-2.777 F1000
G1 X22.422 Y19.439 Z-2.83 F1000
G1 X22.395 Y19.394 Z-2.877 F1000
G1 X22.365 Y19.344 Z-2.919 F1000
G1 X22.333 Y19.29 Z-2.953 F1000
G1 X22.3 Y19.234 Z-2.98 F1000
G1 X22.265 Y19.175 Z-3 F1000
G1 X22.229 Y19.115 Z-3.012 F1000
G1 X22.192 Y19.054 Z-3.016 F1000
G3 X21.971 Y18.3 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y15.794 F1000
G1 X21.983 Y15.545 F1000
G1 X22.015 Y15.302 F1000
G1 X22.077 Y15.014 F1000
G1 X22.17 Y14.704 F1000
G1 X22.3 Y14.37 F1000
G1 X22.487 Y13.985 F1000
G1 X22.714 Y13.599 F1000
G1 X23.025 Y13.156 F1000
G1 X23.405 Y12.699 F1000
G1 X23.891 Y12.2 F1000
G1 X24.513 Y11.657 F1000
G1 X25.252 Y11.111 F1000
G1 X26.029 Y10.621 F1000
G1 X26.836 Y10.18 F1000
G1 X27.663 Y9.78 F1000
G1 X28.507 Y9.417 F1000
G1 X29.364 Y9.085 F1000
G1 X30.231 Y8.78 F1000
G1 X31.106 Y8.499 F1000
G1 X31.988 Y8.239 F1000
G1 X32.875 Y7.998 F1000
G1 X33.766 Y7.773 F1000
G1 X34.661 Y7.564 F1000
G1 X35.558 Y7.367 F1000
G1 X36.459 Y7.183 F1000
G1 X37.361 Y7.009 F1000
G1 X38.265 Y6.845 F1000
G1 X39.171 Y6.691 F1000
G1 X40.079 Y6.544 F1000
G1 X40.987 Y6.405 F1000
G1 X41.896 Y6.273 F1000
G1 X42.807 Y6.147 F1000
G1 X43.718 Y6.027 F1000
G1 X44.63 Y5.912 F1000
G1 X45.542 Y5.803 F1000
G1 X46.455 Y5.698 F1000
G1 X47.369 Y5.598 F1000
G1 X48.283 Y5.502 F1000
G1 X49.197 Y5.409 F1000
G1 X50.112 Y5.32 F1000
G1 X51.027 Y5.235 F1000
G1 X51.942 Y5.152 F1000
G1 X52.858 Y5.072 F1000
G1 X53.774 Y4.995 F1000
G1 X54.69 Y4.921 F1000
G1 X55.606 Y4.849 F1000
G1 X56.522 Y4.779 F1000
G1 X57.439 Y4.711 F1000
G1 X58.355 Y4.645 F1000
G1 X59.272 Y4.581 F1000
G1 X60.189 Y4.519 F1000
G1 X61.106 Y4.458 F1000
G1 X62.023 Y4.399 F1000
G1 X62.94 Y4.341 F1000
G1 X63.858 Y4.285 F1000
G1 X65.234 Y4.202 F1000
G1 X66.495 Y4.129 F1000
G1 X68.33 Y4.026 F1000
G1 X69.248 Y3.975 F1000
G1 X70.166 Y3.926 F1000
G1 X71.077 Y3.811 F1000
G1 X71.992 Y3.716 F1000
G1 X72.907 Y3.635 F1000
G1 X73.823 Y3.565 F1000
G1 X74.74 Y3.503 F1000
G1 X75.658 Y3.446 F1000
G1 X76.575 Y3.394 F1000
G1 X77.493 Y3.344 F1000
G1 X78.411 Y3.297 F1000
G1 X79.328 Y3.251 F1000
G1 X80.246 Y3.207 F1000
G1 X82.082 Y3.122 F1000
G1 X83.919 Y3.04 F1000
G1 X85.755 Y2.961 F1000
G1 X87.591 Y2.884 F1000
G1 X89.428 Y2.81 F1000
G1 X91.265 Y2.737 F1000
G1 X93.101 Y2.667 F1000
G1 X94.938 Y2.599 F1000
G1 X96.775 Y2.533 F1000
G1 X98.612 Y2.47 F1000
G1 X100.449 Y2.409 F1000
G1 X102.286 Y2.351 F1000
G1 X104.123 Y2.295 F1000
G1 X105.961 Y2.243 F1000
G1 X107.798 Y2.193 F1000
G1 X109.635 Y2.146 F1000
G1 X111.473 Y2.102 F1000
G1 X113.31 Y2.062 F1000
G1 X115.148 Y2.024 F1000
G1 X116.986 Y1.991 F1000
G1 X118.824 Y1.961 F1000
G1 X119.743 Y1.948 F1000
G1 X121.58 Y1.924 F1000
G1 X122.499 Y1.913 F1000
G1 X123.418 Y1.904 F1000
G1 X124.337 Y1.896 F1000
G1 X125.256 Y1.889 F1000
G1 X126.175 Y1.883 F1000
G1 X127.094 Y1.878 F1000
G1 X128.013 Y1.874 F1000
G1 X128.932 Y1.872 F1000
G1 X129.851 Y1.871 F1000
G1 X130.77 F1000
G1 X131.689 Y1.872 F1000
G1 X132.608 Y1.875 F1000
G1 X133.527 Y1.879 F1000
G1 X134.446 Y1.885 F1000
G1 X135.365 Y1.892 F1000
G1 X136.284 Y1.901 F1000
G1 X137.203 Y1.911 F1000
G1 X138.122 Y1.923 F1000
G1 X139.041 Y1.937 F1000
G1 X139.96 Y1.952 F1000
G1 X140.879 Y1.969 F1000
G1 X141.798 Y1.989 F1000
G1 X142.717 Y2.01 F1000
G1 X143.635 Y2.033 F1000
G1 X144.554 Y2.058 F1000
G1 X145.473 Y2.085 F1000
G1 X146.391 Y2.115 F1000
G1 X147.31 Y2.147 F1000
G1 X148.228 Y2.181 F1000
G1 X149.146 Y2.218 F1000
G1 X150.064 Y2.258 F1000
G1 X150.983 Y2.3 F1000
G1 X151.9 Y2.346 F1000
G1 X152.818 Y2.394 F1000
G1 X153.736 Y2.446 F1000
G1 X154.653 Y2.502 F1000
G1 X155.57 Y2.561 F1000
G1 X156.487 Y2.624 F1000
G1 X157.404 Y2.691 F1000
G1 X158.32 Y2.762 F1000
G1 X159.236 Y2.839 F1000
G1 X160.151 Y2.921 F1000
G1 X161.066 Y3.009 F1000
G1 X161.98 Y3.102 F1000
G1 X162.894 Y3.203 F1000
G1 X163.806 Y3.312 F1000
G1 X164.718 Y3.429 F1000
G1 X165.628 Y3.556 F1000
G1 X166.536 Y3.694 F1000
G1 X167.443 Y3.845 F1000
G1 X168.347 Y4.011 F1000
G1 X168.572 Y4.056 F1000
G1 X168.924 Y4.13 F1000
G1 X169.148 Y4.178 F1000
G1 X169.383 Y4.231 F1000
G1 X169.639 Y4.29 F1000
G1 X169.912 Y4.356 F1000
G1 X170.786 Y4.641 F1000
G1 X171.653 Y4.945 F1000
G1 X172.426 Y5.261 F1000
G1 X172.973 Y5.539 F1000
G1 X173.027 Y5.572 F1000
G1 X173.268 Y5.755 F1000
G1 X173.466 Y5.983 F1000
G1 X173.614 Y6.247 F1000
G1 X173.705 Y6.535 F1000
G1 X173.736 Y6.836 F1000
G1 Y9.442 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y10.026 I-0.635 J-0.022 F1000
G1 X173.221 Y10.047 Z-3.012 F1000
G1 X173.153 Y10.068 Z-3 F1000
G1 X173.088 Y10.088 Z-2.98 F1000
G1 X173.025 Y10.108 Z-2.953 F1000
G1 X172.966 Y10.126 Z-2.919 F1000
G1 X172.91 Y10.143 Z-2.877 F1000
G1 X172.859 Y10.159 Z-2.83 F1000
G1 X172.814 Y10.173 Z-2.777 F1000
G1 X172.775 Y10.185 Z-2.719 F1000
G1 X172.742 Y10.195 Z-2.657 F1000
G1 X172.716 Y10.203 Z-2.591 F1000
G1 X172.697 Y10.209 Z-2.522 F1000
G1 X172.685 Y10.212 Z-2.452 F1000
G1 X172.682 Y10.214 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y17.093 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y17.09 Z-2.452 F1000
G1 X22.509 Y17.08 Z-2.522 F1000
G1 X22.499 Y17.063 Z-2.591 F1000
G1 X22.485 Y17.039 Z-2.657 F1000
G1 X22.467 Y17.01 Z-2.719 F1000
G1 X22.446 Y16.974 Z-2.777 F1000
G1 X22.422 Y16.933 Z-2.83 F1000
G1 X22.395 Y16.888 Z-2.877 F1000
G1 X22.365 Y16.838 Z-2.919 F1000
G1 X22.333 Y16.784 Z-2.953 F1000
G1 X22.3 Y16.728 Z-2.98 F1000
G1 X22.265 Y16.669 Z-3 F1000
G1 X22.229 Y16.609 Z-3.012 F1000
G1 X22.192 Y16.548 Z-3.016 F1000
G3 X21.971 Y15.794 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y13.288 F1000
G1 X21.985 Y13.014 F1000
G1 X21.993 Y12.862 F1000
G1 X22.01 Y12.71 F1000
G1 X22.035 Y12.56 F1000
G1 X22.066 Y12.411 F1000
G1 X22.103 Y12.263 F1000
G1 X22.146 Y12.117 F1000
G1 X22.194 Y11.972 F1000
G1 X22.248 Y11.83 F1000
G1 X22.307 Y11.689 F1000
G1 X22.369 Y11.55 F1000
G1 X22.436 Y11.413 F1000
G1 X22.507 Y11.278 F1000
G1 X22.582 Y11.145 F1000
G1 X22.661 Y11.015 F1000
G1 X22.742 Y10.886 F1000
G1 X22.827 Y10.76 F1000
G1 X22.915 Y10.635 F1000
G1 X23.006 Y10.513 F1000
G1 X23.099 Y10.392 F1000
G1 X23.195 Y10.274 F1000
G1 X23.294 Y10.158 F1000
G1 X23.395 Y10.043 F1000
G1 X23.497 Y9.931 F1000
G1 X23.602 Y9.82 F1000
G1 X23.709 Y9.711 F1000
G1 X23.818 Y9.605 F1000
G1 X23.928 Y9.5 F1000
G1 X24.041 Y9.397 F1000
G1 X24.154 Y9.295 F1000
G1 X24.27 Y9.196 F1000
G1 X24.386 Y9.098 F1000
G1 X24.504 Y9.001 F1000
G1 X24.624 Y8.907 F1000
G1 X24.745 Y8.814 F1000
G1 X24.867 Y8.723 F1000
G1 X24.99 Y8.633 F1000
G1 X25.114 Y8.544 F1000
G1 X25.239 Y8.457 F1000
G1 X25.365 Y8.372 F1000
G1 X25.492 Y8.288 F1000
G1 X25.62 Y8.205 F1000
G1 X25.749 Y8.124 F1000
G1 X25.879 Y8.044 F1000
G1 X26.01 Y7.965 F1000
G1 X26.141 Y7.888 F1000
G1 X26.273 Y7.812 F1000
G1 X26.406 Y7.737 F1000
G1 X26.539 Y7.663 F1000
G1 X26.673 Y7.591 F1000
G1 X26.808 Y7.519 F1000
G1 X26.943 Y7.449 F1000
G1 X27.079 Y7.38 F1000
G1 X27.215 Y7.312 F1000
G1 X27.355 Y7.243 F1000
G1 X27.502 Y7.173 F1000
G1 X27.64 Y7.108 F1000
G1 X27.779 Y7.044 F1000
G1 X27.927 Y6.976 F1000
G1 X28.084 Y6.907 F1000
G1 X28.251 Y6.834 F1000
G1 X28.421 Y6.761 F1000
G1 X28.581 Y6.695 F1000
G1 X28.751 Y6.625 F1000
G1 X28.932 Y6.552 F1000
G1 X29.126 Y6.476 F1000
G1 X29.325 Y6.4 F1000
G1 X29.514 Y6.329 F1000
G1 X29.716 Y6.254 F1000
G1 X29.935 Y6.176 F1000
G1 X30.17 Y6.093 F1000
G1 X30.387 Y6.019 F1000
G1 X30.62 Y5.941 F1000
G1 X30.874 Y5.858 F1000
G1 X31.141 Y5.773 F1000
G1 X31.396 Y5.694 F1000
G1 X31.676 Y5.609 F1000
G1 X31.985 Y5.518 F1000
G1 X32.272 Y5.436 F1000
G1 X32.59 Y5.348 F1000
G1 X32.939 Y5.253 F1000
G1 X33.271 Y5.166 F1000
G1 X33.645 Y5.071 F1000
G1 X34.028 Y4.976 F1000
G1 X34.429 Y4.88 F1000
G1 X34.865 Y4.779 F1000
G1 X35.306 Y4.681 F1000
G1 X35.793 Y4.576 F1000
G1 X36.291 Y4.472 F1000
G1 X36.83 Y4.364 F1000
G1 X37.412 Y4.251 F1000
G1 X37.789 Y4.182 F1000
G1 X38.439 Y4.064 F1000
G1 X39.1 Y3.95 F1000
G1 X39.827 Y3.829 F1000
G1 X40.618 Y3.704 F1000
G1 X41.475 Y3.575 F1000
G1 X42.384 Y3.445 F1000
G1 X43.295 Y3.321 F1000
G1 X44.206 Y3.203 F1000
G1 X45.119 Y3.091 F1000
G1 X46.031 Y2.983 F1000
G1 X46.944 Y2.88 F1000
G1 X47.858 Y2.782 F1000
G1 X48.772 Y2.687 F1000
G1 X49.687 Y2.597 F1000
G1 X50.602 Y2.509 F1000
G1 X51.517 Y2.425 F1000
G1 X52.432 Y2.344 F1000
G1 X53.348 Y2.265 F1000
G1 X54.264 Y2.189 F1000
G1 X55.18 Y2.116 F1000
G1 X56.096 Y2.045 F1000
G1 X57.013 Y1.976 F1000
G1 X57.929 Y1.909 F1000
G1 X58.846 Y1.844 F1000
G1 X59.763 Y1.781 F1000
G1 X60.68 Y1.719 F1000
G1 X62.055 Y1.63 F1000
G1 X62.285 Y1.615 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X62.896 Y2.025 I0.018 J0.635 F1000
G1 X62.921 Y2.092 Z-3.012 F1000
G1 X62.946 Y2.157 Z-3 F1000
G1 X62.971 Y2.221 Z-2.98 F1000
G1 X62.994 Y2.283 Z-2.953 F1000
G1 X63.016 Y2.341 Z-2.919 F1000
G1 X63.037 Y2.395 Z-2.877 F1000
G1 X63.055 Y2.445 Z-2.83 F1000
G1 X63.072 Y2.489 Z-2.777 F1000
G1 X63.087 Y2.528 Z-2.719 F1000
G1 X63.099 Y2.56 Z-2.657 F1000
G1 X63.109 Y2.586 Z-2.591 F1000
G1 X63.116 Y2.604 Z-2.522 F1000
G1 X63.12 Y2.615 Z-2.452 F1000
G1 X63.121 Y2.619 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X22.517 Y14.587 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X22.515 Y14.584 Z-2.452 F1000
G1 X22.509 Y14.574 Z-2.522 F1000
G1 X22.499 Y14.557 Z-2.591 F1000
G1 X22.485 Y14.533 Z-2.657 F1000
G1 X22.467 Y14.504 Z-2.719 F1000
G1 X22.446 Y14.468 Z-2.777 F1000
G1 X22.422 Y14.427 Z-2.83 F1000
G1 X22.395 Y14.382 Z-2.877 F1000
G1 X22.365 Y14.332 Z-2.919 F1000
G1 X22.333 Y14.278 Z-2.953 F1000
G1 X22.3 Y14.222 Z-2.98 F1000
G1 X22.265 Y14.163 Z-3 F1000
G1 X22.229 Y14.103 Z-3.012 F1000
G1 X22.192 Y14.042 Z-3.016 F1000
G3 X21.971 Y13.288 I1.36 J-0.809 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y10.573 F1000
G1 X21.982 Y10.35 F1000
G1 X21.991 Y10.198 F1000
G1 X22.008 Y10.047 F1000
G1 X22.032 Y9.896 F1000
G1 X22.062 Y9.747 F1000
G1 X22.099 Y9.599 F1000
G1 X22.142 Y9.453 F1000
G1 X22.191 Y9.308 F1000
G1 X22.244 Y9.166 F1000
G1 X22.302 Y9.025 F1000
G1 X22.365 Y8.886 F1000
G1 X22.432 Y8.749 F1000
G1 X22.503 Y8.614 F1000
G1 X22.578 Y8.482 F1000
G1 X22.656 Y8.351 F1000
G1 X22.738 Y8.222 F1000
G1 X22.823 Y8.095 F1000
G1 X22.91 Y7.971 F1000
G1 X23.001 Y7.848 F1000
G1 X23.094 Y7.728 F1000
G1 X23.19 Y7.609 F1000
G1 X23.288 Y7.493 F1000
G1 X23.388 Y7.378 F1000
G1 X23.491 Y7.265 F1000
G1 X23.595 Y7.154 F1000
G1 X23.702 Y7.045 F1000
G1 X23.81 Y6.938 F1000
G1 X23.92 Y6.833 F1000
G1 X24.032 Y6.729 F1000
G1 X24.146 Y6.627 F1000
G1 X24.26 Y6.527 F1000
G1 X24.377 Y6.429 F1000
G1 X24.494 Y6.332 F1000
G1 X24.613 Y6.237 F1000
G1 X24.734 Y6.143 F1000
G1 X24.855 Y6.051 F1000
G1 X24.978 Y5.961 F1000
G1 X25.101 Y5.871 F1000
G1 X25.226 Y5.784 F1000
G1 X25.352 Y5.698 F1000
G1 X25.479 Y5.613 F1000
G1 X25.606 Y5.53 F1000
G1 X25.735 Y5.447 F1000
G1 X25.864 Y5.367 F1000
G1 X25.994 Y5.287 F1000
G1 X26.125 Y5.209 F1000
G1 X26.256 Y5.132 F1000
G1 X26.388 Y5.056 F1000
G1 X26.521 Y4.982 F1000
G1 X26.655 Y4.908 F1000
G1 X26.789 Y4.836 F1000
G1 X26.924 Y4.765 F1000
G1 X27.059 Y4.695 F1000
G1 X27.195 Y4.626 F1000
G1 X27.331 Y4.558 F1000
G1 X27.47 Y4.491 F1000
G1 X27.611 Y4.423 F1000
G1 X27.758 Y4.354 F1000
G1 X27.906 Y4.285 F1000
G1 X28.14 Y4.18 F1000
G1 X28.301 Y4.109 F1000
G1 X28.467 Y4.037 F1000
G1 X28.64 Y3.964 F1000
G1 X28.814 Y3.892 F1000
G1 X28.998 Y3.818 F1000
G1 X29.183 Y3.744 F1000
G1 X29.379 Y3.668 F1000
G1 X29.579 Y3.592 F1000
G1 X29.785 Y3.516 F1000
G1 X30.002 Y3.437 F1000
G1 X30.222 Y3.359 F1000
G1 X30.455 Y3.278 F1000
G1 X30.691 Y3.199 F1000
G1 X30.939 Y3.117 F1000
G1 X31.197 Y3.034 F1000
G1 X31.462 Y2.95 F1000
G1 X31.745 Y2.864 F1000
G1 X32.03 Y2.779 F1000
G1 X32.333 Y2.691 F1000
G1 X32.65 Y2.601 F1000
G1 X32.976 Y2.512 F1000
G1 X33.325 Y2.419 F1000
G1 X33.682 Y2.327 F1000
G1 X34.061 Y2.232 F1000
G1 X34.446 Y2.138 F1000
G1 X34.558 Y2.112 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X34.628 Y2.102 Z-3.001 F1000
G1 X34.7 Y2.1 Z-2.987 F1000
G1 X34.77 Y2.106 Z-2.972 F1000
G1 X34.84 Y2.12 Z-2.958 F1000
G1 X34.908 Y2.142 Z-2.943 F1000
G1 X34.973 Y2.171 Z-2.929 F1000
G1 X35.034 Y2.207 Z-2.914 F1000
G1 X35.091 Y2.25 Z-2.9 F1000
G1 X35.143 Y2.299 Z-2.885 F1000
G1 X35.189 Y2.353 Z-2.871 F1000
G1 X35.228 Y2.412 Z-2.856 F1000
G1 X35.261 Y2.475 Z-2.842 F1000
G1 X35.286 Y2.542 Z-2.827 F1000
G1 X35.304 Y2.611 Z-2.813 F1000
; MOVEMENT_LINK_DIRECT
G3 X35.027 Y3.268 I-0.623 J0.124 F1000
G1 X22.951 Y11.084 F1000
G3 X22.627 Y11.186 I-0.345 J-0.533 F1000
G1 X22.556 Y11.184 Z-2.827 F1000
G1 X22.486 Y11.174 Z-2.842 F1000
G1 X22.417 Y11.157 Z-2.856 F1000
G1 X22.35 Y11.132 Z-2.871 F1000
G1 X22.286 Y11.1 Z-2.885 F1000
G1 X22.227 Y11.061 Z-2.9 F1000
G1 X22.172 Y11.015 Z-2.914 F1000
G1 X22.123 Y10.964 Z-2.929 F1000
G1 X22.08 Y10.907 Z-2.943 F1000
G1 X22.043 Y10.846 Z-2.958 F1000
G1 X22.014 Y10.781 Z-2.972 F1000
G1 X21.992 Y10.714 Z-2.987 F1000
G1 X21.977 Y10.644 Z-3.001 F1000
G1 X21.971 Y10.573 Z-3.016 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y7.858 F1000
G1 X21.98 Y7.678 F1000
G1 X22.013 Y7.423 F1000
G1 X22.074 Y7.14 F1000
G1 X22.167 Y6.828 F1000
G1 X22.301 Y6.485 F1000
G1 X22.482 Y6.112 F1000
G1 X22.722 Y5.704 F1000
G1 X23.032 Y5.263 F1000
G1 X23.429 Y4.784 F1000
G1 X23.934 Y4.267 F1000
G1 X24.014 Y4.197 F1000
G1 X24.097 Y4.127 F1000
G1 X24.773 Y3.559 F1000
G1 X25.148 Y3.293 F1000
G1 X25.243 Y3.229 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X25.306 Y3.195 Z-3.001 F1000
G1 X25.372 Y3.169 Z-2.987 F1000
G1 X25.441 Y3.15 Z-2.972 F1000
G1 X25.511 Y3.139 Z-2.958 F1000
G1 X25.582 Y3.135 Z-2.943 F1000
G1 X25.653 Y3.14 Z-2.929 F1000
G1 X25.723 Y3.153 Z-2.914 F1000
G1 X25.791 Y3.173 Z-2.9 F1000
G1 X25.857 Y3.201 Z-2.885 F1000
G1 X25.919 Y3.236 Z-2.871 F1000
G1 X25.976 Y3.278 Z-2.856 F1000
G1 X26.029 Y3.326 Z-2.842 F1000
G1 X26.076 Y3.38 Z-2.827 F1000
G1 X26.116 Y3.438 Z-2.813 F1000
; MOVEMENT_LINK_DIRECT
G3 X26.088 Y4.145 I-0.541 J0.332 F1000
G1 X23.118 Y8.211 F1000
G3 X22.627 Y8.471 I-0.513 J-0.375 F1000
G1 X22.556 Y8.469 Z-2.827 F1000
G1 X22.486 Y8.46 Z-2.842 F1000
G1 X22.417 Y8.442 Z-2.856 F1000
G1 X22.35 Y8.417 Z-2.871 F1000
G1 X22.286 Y8.385 Z-2.885 F1000
G1 X22.227 Y8.346 Z-2.9 F1000
G1 X22.172 Y8.3 Z-2.914 F1000
G1 X22.123 Y8.249 Z-2.929 F1000
G1 X22.08 Y8.192 Z-2.943 F1000
G1 X22.043 Y8.131 Z-2.958 F1000
G1 X22.014 Y8.067 Z-2.972 F1000
G1 X21.992 Y7.999 Z-2.987 F1000
G1 X21.977 Y7.929 Z-3.001 F1000
G1 X21.971 Y7.858 Z-3.016 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y5.352 F1000
G1 X21.982 Y5.123 F1000
G1 X22.014 Y4.879 F1000
G1 X22.073 Y4.603 F1000
G1 X22.172 Y4.275 F1000
G1 X22.255 Y4.061 F1000
G1 X22.304 Y3.837 F1000
G1 X22.318 Y3.608 F1000
G1 X22.297 Y3.379 F1000
G1 X22.24 Y3.156 F1000
G1 X22.105 Y2.842 F1000
G1 X22.031 Y2.631 F1000
G1 X21.986 Y2.411 F1000
G1 X21.971 Y2.187 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X21.977 Y2.116 Z-3.001 F1000
G1 X21.992 Y2.046 Z-2.987 F1000
G1 X22.014 Y1.979 Z-2.972 F1000
G1 X22.043 Y1.914 Z-2.958 F1000
G1 X22.08 Y1.853 Z-2.943 F1000
G1 X22.123 Y1.796 Z-2.929 F1000
G1 X22.172 Y1.745 Z-2.914 F1000
G1 X22.227 Y1.699 Z-2.9 F1000
G1 X22.286 Y1.66 Z-2.885 F1000
G1 X22.35 Y1.628 Z-2.871 F1000
G1 X22.417 Y1.603 Z-2.856 F1000
G1 X22.486 Y1.585 Z-2.842 F1000
G1 X22.556 Y1.576 Z-2.827 F1000
G1 X22.627 Y1.574 Z-2.813 F1000
; MOVEMENT_LINK_DIRECT
G3 X23.241 Y2.209 I-0.022 J0.635 F1000
G1 Y5.33 F1000
G3 X22.627 Y5.965 I-0.635 F1000
G1 X22.556 Y5.963 Z-2.827 F1000
G1 X22.486 Y5.954 Z-2.842 F1000
G1 X22.417 Y5.936 Z-2.856 F1000
G1 X22.35 Y5.911 Z-2.871 F1000
G1 X22.286 Y5.879 Z-2.885 F1000
G1 X22.227 Y5.84 Z-2.9 F1000
G1 X22.172 Y5.794 Z-2.914 F1000
G1 X22.123 Y5.743 Z-2.929 F1000
G1 X22.08 Y5.686 Z-2.943 F1000
G1 X22.043 Y5.625 Z-2.958 F1000
G1 X22.014 Y5.56 Z-2.972 F1000
G1 X21.992 Y5.493 Z-2.987 F1000
G1 X21.977 Y5.423 Z-3.001 F1000
G1 X21.971 Y5.352 Z-3.016 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y1.061 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X22.419 Y0.476 I0.635 J0.022 F1000
G1 X22.486 Y0.455 Z-3.012 F1000
G1 X22.554 Y0.434 Z-3 F1000
G1 X22.619 Y0.414 Z-2.98 F1000
G1 X22.682 Y0.395 Z-2.953 F1000
G1 X22.741 Y0.376 Z-2.919 F1000
G1 X22.797 Y0.359 Z-2.877 F1000
G1 X22.848 Y0.344 Z-2.83 F1000
G1 X22.893 Y0.33 Z-2.777 F1000
G1 X22.932 Y0.318 Z-2.719 F1000
G1 X22.965 Y0.307 Z-2.657 F1000
G1 X22.991 Y0.299 Z-2.591 F1000
G1 X23.01 Y0.294 Z-2.522 F1000
G1 X23.022 Y0.29 Z-2.452 F1000
G1 X23.025 Y0.289 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z5.08 F1000
G1 X173.081 Y-6.238 F1000
G1 Z-1.746 F1000
; MOVEMENT_LEAD_IN
G1 Z-2.381 F1000
G1 X173.082 Y-6.234 Z-2.452 F1000
G1 X173.085 Y-6.222 Z-2.522 F1000
G1 X173.09 Y-6.203 Z-2.591 F1000
G1 X173.097 Y-6.177 Z-2.657 F1000
G1 X173.105 Y-6.144 Z-2.719 F1000
G1 X173.116 Y-6.104 Z-2.777 F1000
G1 X173.127 Y-6.058 Z-2.83 F1000
G1 X173.141 Y-6.006 Z-2.877 F1000
G1 X173.155 Y-5.95 Z-2.919 F1000
G1 X173.17 Y-5.89 Z-2.953 F1000
G1 X173.187 Y-5.826 Z-2.98 F1000
G1 X173.204 Y-5.76 Z-3 F1000
G1 X173.221 Y-5.692 Z-3.012 F1000
G1 X173.239 Y-5.623 Z-3.016 F1000
G3 X173.736 Y-2.166 I-15.704 J4.023 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y-1.842 F1000
G1 X173.734 Y-1.804 F1000
G1 X173.647 Y-1.679 F1000
G1 X173.551 Y-1.561 F1000
G1 X173.447 Y-1.45 F1000
G1 X173.336 Y-1.344 F1000
G1 X173.221 Y-1.245 F1000
G1 X173.101 Y-1.151 F1000
G1 X172.977 Y-1.062 F1000
G1 X172.85 Y-0.978 F1000
G1 X172.72 Y-0.898 F1000
G1 X172.588 Y-0.823 F1000
G1 X172.453 Y-0.751 F1000
G1 X172.317 Y-0.683 F1000
G1 X172.179 Y-0.619 F1000
G1 X171.982 Y-0.501 F1000
G1 X171.805 Y-0.354 F1000
G1 X171.653 Y-0.181 F1000
G1 X171.53 Y0.013 F1000
G1 X171.438 Y0.223 F1000
G1 X171.38 Y0.446 F1000
G1 X171.357 Y0.674 F1000
G1 X171.37 Y0.904 F1000
G1 X171.418 Y1.128 F1000
G1 X171.5 Y1.343 F1000
G1 X171.614 Y1.542 F1000
G1 X171.758 Y1.722 F1000
G1 X172.437 Y2.341 F1000
G1 X172.572 Y2.411 F1000
G1 X172.707 Y2.483 F1000
G1 X172.84 Y2.557 F1000
G1 X172.972 Y2.634 F1000
G1 X173.021 Y2.664 F1000
G1 X173.264 Y2.847 F1000
G1 X173.464 Y3.075 F1000
G1 X173.613 Y3.34 F1000
G1 X173.705 Y3.629 F1000
G1 X173.736 Y3.931 F1000
G1 Y6.836 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X173.73 Y6.906 Z-3.001 F1000
G1 X173.715 Y6.976 Z-2.987 F1000
G1 X173.693 Y7.044 Z-2.972 F1000
G1 X173.664 Y7.109 Z-2.958 F1000
G1 X173.627 Y7.17 Z-2.943 F1000
G1 X173.584 Y7.226 Z-2.929 F1000
G1 X173.535 Y7.278 Z-2.914 F1000
G1 X173.48 Y7.323 Z-2.9 F1000
G1 X173.421 Y7.362 Z-2.885 F1000
G1 X173.357 Y7.395 Z-2.871 F1000
G1 X173.29 Y7.42 Z-2.856 F1000
G1 X173.221 Y7.437 Z-2.842 F1000
G1 X173.151 Y7.446 Z-2.827 F1000
G1 X173.08 Y7.448 Z-2.813 F1000
; MOVEMENT_LINK_DIRECT
G3 X172.466 Y6.813 I0.022 J-0.635 F1000
G1 Y-1.82 F1000
G3 X173.08 Y-2.455 I0.635 F1000
G1 X173.151 Y-2.453 Z-2.827 F1000
G1 X173.221 Y-2.444 Z-2.842 F1000
G1 X173.29 Y-2.426 Z-2.856 F1000
G1 X173.357 Y-2.401 Z-2.871 F1000
G1 X173.421 Y-2.369 Z-2.885 F1000
G1 X173.48 Y-2.33 Z-2.9 F1000
G1 X173.535 Y-2.284 Z-2.914 F1000
G1 X173.584 Y-2.233 Z-2.929 F1000
G1 X173.627 Y-2.176 Z-2.943 F1000
G1 X173.664 Y-2.115 Z-2.958 F1000
G1 X173.693 Y-2.05 Z-2.972 F1000
G1 X173.715 Y-1.983 Z-2.987 F1000
G1 X173.73 Y-1.913 Z-3.001 F1000
G1 X173.736 Y-1.842 Z-3.016 F1000
; param: axial-engagement = 0.0000015079999684530776
; MOVEMENT_CUTTING
G1 Y3.931 F1000
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X173.288 Y4.516 I-0.635 J-0.022 F1000
G1 X173.221 Y4.537 Z-3.012 F1000
G1 X173.153 Y4.558 Z-3 F1000
G1 X173.088 Y4.578 Z-2.98 F1000
G1 X173.025 Y4.597 Z-2.953 F1000
G1 X172.966 Y4.616 Z-2.919 F1000
G1 X172.91 Y4.633 Z-2.877 F1000
G1 X172.859 Y4.648 Z-2.83 F1000
G1 X172.814 Y4.662 Z-2.777 F1000
G1 X172.775 Y4.674 Z-2.719 F1000
G1 X172.742 Y4.685 Z-2.657 F1000
G1 X172.716 Y4.693 Z-2.591 F1000
G1 X172.697 Y4.698 Z-2.522 F1000
G1 X172.685 Y4.702 Z-2.452 F1000
G1 X172.682 Y4.703 Z-2.381 F1000
; MOVEMENT_CUTTING
G1 Z15.24 F1000
; *** SECTION end ***
;
; *** STOP begin ***
M400
; COMMAND_COOLANT_OFF
; ---- Coolant: Off cur: Off A: Off B: Off
G0 X0 Y0 F4470
; COMMAND_STOP_SPINDLE
M300 S300 P3000
M0 Turn OFF spindle
M117 Job end
; *** STOP end ***
