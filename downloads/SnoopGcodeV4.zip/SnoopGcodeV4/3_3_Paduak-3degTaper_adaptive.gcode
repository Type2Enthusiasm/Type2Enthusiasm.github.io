; parseSafeZProperty: safeZMode = 'Retract'
; parseSafeZProperty: safeZHeightDefault = 15
; param: product-id = fusion360
;Fusion CAM 2602.1.25
; Posts processor: MPCNC v3.0 Beta 1.cps
; Gcode generated: Wed Aug 13 00:35:35 2025 GMT
; param: hostname = Harrisons-MacBook-Air.local
; param: username = harrisonesterly
; Document: snoop2 v18
; param: document-id = cdd3c627-a981-4b59-b2d6-a8cf2a6a6479
; param: model-version = bdc37a29-57e1-40f4-926d-96910b3fbf17
; param: leads-supported = 1
; Setup: Setup5
; param: machine-id = 1
; param: machine-v2 = {
   "controller" : {
      "default" : {
         "head_info_part_id" : "head",
         "max_block_processing_speed" : 118,
         "max_normal_speed" : 4000.0000000000005,
         "non_tcp_rapid_interpolation_mode" : "Unsynchronized",
         "parts" : {
            "X" : {
               "coordinate" : 0,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Y" : {
               "coordinate" : 1,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Z" : {
               "coordinate" : 2,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            }
         },
         "table_part_id" : "table",
         "tcp_rapid_interpolation_mode" : "ToolTip"
      }
   },
   "general" : {
      "capabilities" : [ "milling" ],
      "description" : "Generic 3-axis",
      "minimumRevision" : 45805,
      "vendor" : "MP_CNC"
   },
   "interactions" : {
      "default" : {
         "pairs" : [
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            }
         ]
      }
   },
   "kinematics" : {
      "default" : {
         "conventions" : {
            "rotation" : "right-handed"
         },
         "parts" : [
            {
               "control" : "driven",
               "direction" : [ -1, 0, 0 ],
               "id" : "X",
               "max" : 289.99999999999994,
               "min" : 289.99999999999994,
               "name" : "X",
               "parts" : [
                  {
                     "control" : "driven",
                     "direction" : [ 0, -1, 0 ],
                     "id" : "Y",
                     "name" : "Y",
                     "parts" : [
                        {
                           "control" : "driven",
                           "direction" : [ 0, 0, -1 ],
                           "id" : "Z",
                           "max" : 0,
                           "min" : 0,
                           "name" : "Z",
                           "parts" : [
                              {
                                 "attach_frame" : {
                                    "point" : [ 0, 0, 0 ],
                                    "x_direction" : [ 1, 0, 0 ],
                                    "z_direction" : [ 0, 0, 1 ]
                                 },
                                 "display_name" : "table",
                                 "id" : "table",
                                 "type" : "table"
                              }
                           ],
                           "type" : "linear"
                        }
                     ],
                     "type" : "linear"
                  }
               ],
               "type" : "linear"
            },
            {
               "attach_frame" : {
                  "point" : [ 0, 0, 0 ],
                  "x_direction" : [ 1, 0, 0 ],
                  "z_direction" : [ 0, 0, 1 ]
               },
               "display_name" : "head",
               "id" : "head",
               "spindle" : {
                  "max_speed" : 0,
                  "min_speed" : 0
               },
               "tool_station" : {
                  "coolants" : null,
                  "max_tool_diameter" : 0,
                  "max_tool_length" : 0
               },
               "type" : "head"
            }
         ],
         "units" : {
            "angle" : "degrees",
            "length" : "mm"
         }
      }
   },
   "machining" : {
      "default" : {
         "feedrate_ratio" : 1,
         "tool_change_time" : 15
      }
   },
   "post" : {
      "default" : {
         "output_folder" : "/Users/harrisonesterly/Desktop/LIFE/Projects/MPCNC/fusion_GCode",
         "path" : "user://MPCNC.cps"
      }
   },
   "tooling" : {
      "default" : {
         "has_tool_changer" : false,
         "number_of_tools" : 100,
         "supports_tool_preload" : true
      }
   }
}


; param: stock-type = box
; param: stock = 0, 0, -26.496, 141.732, 106.172, 0
; param: stock-lower-x = 0
; param: stock-lower-y = 0
; param: stock-lower-z = -26.495999999999995
; param: stock-upper-x = 141.732
; param: stock-upper-y = 106.17199999999997
; param: stock-upper-z = 0
; param: part-lower-x = 1.0159999999999911
; param: part-lower-y = 1.0159999999999982
; param: part-lower-z = -26.495999999999995
; param: part-upper-x = 140.71599999999998
; param: part-upper-y = 105.15599999999998
; param: part-upper-z = -1.016
; param: areBothSpindlesGrabbed = 0
; param: notes = 
; param: operation-strategy = adaptive2d
; param: autodeskcam:operation-id = 44
; param: leads-supported = 1
; param: autodeskcam:path = Setups\Setup5\2D Adaptive7 3
; param: operation:is2DStrategy = 1
; param: operation:is3DStrategy = 0
; param: operation:isRoughingStrategy = 1
; param: operation:isFinishingStrategy = 0
; param: operation:isMillingStrategy = 1
; param: operation:isTurningStrategy = 0
; param: operation:isJetStrategy = 0
; param: operation:isAdditiveStrategy = 0
; param: operation:isProbingStrategy = 0
; param: operation:isInspectionStrategy = 0
; param: operation:isDrillingStrategy = 0
; param: operation:isHoleMillingStrategy = 0
; param: operation:isThreadStrategy = 0
; param: operation:isSamplingStrategy = 0
; param: operation:isRotaryStrategy = 1
; param: operation:isSubspindleStrategy = 0
; param: operation:isSurfaceStrategy = 0
; param: operation:isCheckSurfaceStrategy = 0
; param: operation:isMultiAxisStrategy = 0
; param: operation:advancedMode = 0
; param: operation:betaMode = 0
; param: operation:alphaMode = 0
; param: operation:isXpress = 0
; param: operation:licenseMultiaxis = 1
; param: operation:license3D = 1
; param: operation:metric = 0
; param: operation:isAssemblyDocument = 1
; param: operation:context = operation
; param: operation:strategy = adaptive2d
; param: operation:operation_description = 2D Adaptive
; param: operation:tool_type = tapered mill
; param: operation:undercut = 0
; param: operation:tool_isTurning = 0
; param: operation:tool_isMill = 1
; param: operation:tool_isDrill = 0
; param: operation:tool_isJet = 0
; param: operation:tool_isDepositing = 0
; param: operation:tool_taperedType = tapered_bull_nose
; param: operation:tool_unit = millimeters
; param: operation:tool_number = 1
; param: operation:tool_diameterOffset = 1
; param: operation:tool_lengthOffset = 1
; param: operation:tool_compensationOffset = 1
; param: operation:tool_turret = 0
; param: operation:tool_manualToolChange = 0
; param: operation:tool_breakControl = 0
; param: operation:tool_live = 1
; param: operation:tool_material = carbide
; param: operation:tool_description = 46473 CNC 2D and 3D Carving 6.2 Deg Tapered Angle Ball Tip x 0.5mm Dia x 0.25mm Radius x 26.5mm x 6mm Shank x 75mm Long x 3 Flute Up-Cut Spiral Solid Carbide ZrN Coated
; param: operation:tool_comment = 
; param: operation:tool_vendor = Amana Tool
; param: operation:tool_productId = 46473
; param: operation:tool_productLink = https://www.amanatool.com/46473-cnc-2d-and-3d-carving-6-2-deg-tapered-angle-ball-tip-x-0-5mm-dia-x-0-25mm-radius-x-26-5mm-x-6mm-shank-x-75mm-long-x-3-flute-up-cut-spiral-solid-carbide-zrn-coated.html
; param: operation:tool_diameter = 0.5
; param: operation:tool_maximumCuttingDiameter = 0
; param: operation:tool_tipDiameter = 0
; param: operation:tool_tipOffset = 0
; param: operation:tool_cornerRadius = 0.25
; param: operation:tool_inclusiveAngle = 0
; param: operation:tool_taperAngle = 6.2
; param: operation:tool_tipAngle = 0
; param: operation:tool_threadTipType = point
; param: operation:tool_threadTipWidth = 0
; param: operation:tool_threadTipRadius = 0
; param: operation:tool_threadProfileAngle = 0
; param: operation:tool_tipLength = 0
; param: operation:tool_fluteLength = 26.5
; param: operation:tool_shoulderLength = 26.5
; param: operation:tool_bodyLength = 40
; param: operation:tool_overallLength = 75
; param: operation:tool_shaftDiameter = 6
; param: operation:tool_segmentHeight = 3
; param: operation:tool_segmentDiameterLower = 12
; param: operation:tool_segmentDiameterUpper = 12
; param: operation:tool_shaftSegmentHeight = 6.75
; param: operation:tool_shaftSegmentDiameterLower = 0.5
; param: operation:tool_shaftSegmentDiameterUpper = 6
; param: operation:tool_threadPitch = 0
; param: operation:tool_maximumThreadPitch = 0
; param: operation:tool_minimumThreadPitch = 0
; param: operation:tool_numberOfTeeth = 0
; param: operation:tool_numberOfFlutes = 3
; param: operation:tool_shoulderDiameter = 6.257643000000001
; param: operation:tool_upperRadius = 1.016
; param: operation:tool_profileRadius = 101.6
; param: operation:tool_lowerRadius = 1.016
; param: operation:tool_axialDistance = 1.016
; param: operation:tool_chamferWidth = 1.016
; param: operation:tool_chamferAngle = 45
; param: operation:holder_attached = 0
; param: operation:holder_description = 
; param: operation:holder_comment = 
; param: operation:holder_vendor = 
; param: operation:holder_productId = 
; param: operation:holder_productLink = 
; param: operation:holder_libraryName = 
; param: operation:tool_holderGaugeLength = 0
; param: operation:tool_assemblyGaugeLength = 40
; param: operation:tool_spindleSpeed = 18000
; param: operation:tool_stockDiameter = 0.5
; param: operation:tool_surfaceSpeed = 28274.33388230814
; param: operation:tool_rampSpindleSpeed = 18000
; param: operation:tool_feedCutting = 254
; param: operation:tool_feedPerTooth = 0.004703703703703704
; param: operation:tool_feedEntry = 254
; param: operation:tool_feedExit = 254
; param: operation:tool_feedTransition = 254
; param: operation:tool_feedRamp = 84.66666666666667
; param: operation:tool_feedPlunge = 84.66666666666667
; param: operation:tool_feedPerRevolution = 0.004703703703703704
; param: operation:tool_feedRetract = 84.66666666666667
; param: operation:tool_clockwise = 1
; param: operation:tool_coolant = disabled
; param: operation:featureOperationId = none
; param: operation:surfaceZHigh = -1.016
; param: operation:surfaceZLow = -26.496
; param: operation:surfaceXLow = 1.0159999999999896
; param: operation:surfaceXHigh = 140.71599999999998
; param: operation:surfaceYLow = 1.016
; param: operation:surfaceYHigh = 105.15599999999998
; param: operation:stockZHigh = 0
; param: operation:stockZLow = -26.496
; param: operation:stockXLow = 0
; param: operation:stockXHigh = 141.732
; param: operation:stockYLow = 0
; param: operation:stockYHigh = 106.17199999999997
; param: operation:multiAxisMachiningType = three_axis
; param: operation:view_orientation_mode = useWCS
; param: operation:view_orientation_flipZ = 0
; param: operation:view_orientation_axesZX_unselected_default = wcs
; param: operation:view_orientation_axesZY_unselected_default = wcs
; param: operation:view_orientation_axesXY_unselected_default = wcs
; param: operation:view_select_angles = turn_and_tilt
; param: operation:view_turn_from_recipe = 0
; param: operation:view_tilt_from_recipe = 0
; param: operation:view_orientation_flipX = 0
; param: operation:view_orientation_flipY = 0
; param: operation:view_origin_mode = jobOrigin
; param: operation:view_origin_boxPoint = top center
; param: operation:show_machine = 0
; param: operation:unwrap = 1
; param: operation:wrap_cylinder_radius = 0
; param: operation:wrap_nominalRadius_offset = 0
; param: operation:wrap_nominalRadius_value = 0
; param: operation:usePolarWhenNecessary = 0
; param: operation:polarMode = automatic
; param: operation:polarLineAngle = 0
; param: operation:pockets_detectOpenPockets = 1
; param: operation:pockets_connectOpenPockets = 1
; param: operation:pockets_errorCheck = 1
; param: operation:pockets_detectOverlaps = 0
; param: operation:restMaterialCutterDiameter = 5.08
; param: operation:restMaterialCornerRadius = 0
; param: operation:restMaterialTaperAngle = 0
; param: operation:restMaterialShoulderLength = 5.08
; param: operation:restMaterialTool = 
; param: operation:isClearanceAreaEnabled = 0
; param: operation:clearanceHeight_mode = from retract height
; param: operation:clearanceHeightFromHighest_checkStock = top
; param: operation:clearanceHeightFromLowest_checkStock = bottom
; param: operation:clearanceHeightFromHighest_checkModel = top
; param: operation:clearanceHeightFromLowest_checkModel = bottom
; param: operation:clearanceHeightFromHighest_checkFixture = top
; param: operation:clearanceHeightFromLowest_checkFixture = bottom
; param: operation:clearanceHeight_offset = 10.16
; param: operation:clearanceHeight_value = 15.239999999999998
; param: operation:clearanceHeight_absolute = 1
; param: operation:retractHeight_mode = from stock top
; param: operation:retractHeightFromHighest_checkStock = top
; param: operation:retractHeightFromLowest_checkStock = bottom
; param: operation:retractHeightFromHighest_checkModel = top
; param: operation:retractHeightFromLowest_checkModel = bottom
; param: operation:retractHeightFromHighest_checkFixture = top
; param: operation:retractHeightFromLowest_checkFixture = bottom
; param: operation:retractHeight_offset = 5.08
; param: operation:retractHeight_value = 5.08
; param: operation:retractHeight_absolute = 1
; param: operation:topHeight_mode = from stock top
; param: operation:topHeightFromHighest_checkStock = top
; param: operation:topHeightFromLowest_checkStock = bottom
; param: operation:topHeightFromHighest_checkModel = ignore
; param: operation:topHeightFromLowest_checkModel = ignore
; param: operation:topHeightFromHighest_checkFixture = ignore
; param: operation:topHeightFromLowest_checkFixture = ignore
; param: operation:topHeight_offset = 0
; param: operation:topHeight_value = 0
; param: operation:topHeight_absolute = 1
; param: operation:bottomHeight_mode = from contour
; param: operation:bottomHeightFromHighest_checkStock = bottom
; param: operation:bottomHeightFromLowest_checkStock = ignore
; param: operation:bottomHeightFromHighest_checkModel = bottom
; param: operation:bottomHeightFromLowest_checkModel = bottom
; param: operation:bottomHeightFromHighest_checkFixture = ignore
; param: operation:bottomHeightFromLowest_checkFixture = ignore
; param: operation:bottomHeight_offset = 0
; param: operation:bottomHeight_value = 0
; param: operation:bottomHeight_absolute = 0
; param: operation:tolerance = 0.1016
; param: operation:contourTolerance = 0.0508
; param: operation:totalSurfaceTolerance = 0.0508
; param: operation:surfaceTriangulationTolerance = 0.0508
; param: operation:calculationTolerance = 0.0508
; param: operation:thinningTolerance = 0.000508
; param: operation:chainingTolerance = 0.01016
; param: operation:gougingTolerance = 0.0508
; param: operation:optimalLoad = 0.2
; param: operation:optimalLoadWeight = 0
; param: operation:speedWeight = 0
; param: operation:feedWeight = 0
; param: operation:loadDeviation = 0.020000000000000004
; param: operation:maximumLoad = 0.22000000000000003
; param: operation:bothWays = 0
; param: operation:optimalLoadOtherWay = 0.2
; param: operation:loadDeviationOtherWay = 0.020000000000000004
; param: operation:maximumLoadOtherWay = 0.22000000000000003
; param: operation:otherWayFeedrate = 228.6
; param: operation:maximumCuspHeight = 0.13125657912962088
; param: operation:minimumCuttingRadius = 0.05
; param: operation:minimumCuttingRadiusJl = 0.05
; param: operation:machineCavities = 1
; param: operation:useSlotClearing = 0
; param: operation:slotClearingWidth = 0.625
; param: operation:direction = climb
; param: operation:maximumStepdown = 0
; param: operation:maximumStepdownJl = 2000000
; param: operation:slopeAngle = 0
; param: operation:useEvenStepdowns = 0
; param: operation:curveInRadius = 0.125
; param: operation:fineStepdown = 0
; param: operation:fineStepdownJl = 1000000
; param: operation:minimumStepdownJobline = 0
; param: operation:useSilhouetteAsStockBoundary = 0
; param: operation:orderByDepth = 0
; param: operation:orderByArea = 0
; param: operation:orderByAreaBufferSize = 400
; param: operation:stockToLeave = 0.127
; param: operation:verticalStockToLeave = 0
; param: operation:simpleStockToLeave = 0
; param: operation:useCombinedFilter = 1
; param: operation:useDMKSmoothing = 0
; param: operation:smoothingFilterMode = redistribute
; param: operation:smoothingFilterMaxSpacing = 0.508
; param: operation:smoothingFilterMaxAngle = 3
; param: operation:smoothingFilterToleranceForEvenlySpacedPoints = 0.0508
; param: operation:smoothingFilterToleranceFactor = 0.5
; param: operation:smoothingFilterTolerance = 0
; param: operation:reducedFeedChange = 25
; param: operation:reducedFeedRadius = 0
; param: operation:reducedFeedDistance = 0
; param: operation:reducedFeedrate = 228.6
; param: operation:reduceOnlyInnerCorners = 1
; param: operation:surfaceSpeedOnArcs = 0
; param: operation:maximumReducedFeedrateInternalArcFinishing = 100
; param: operation:maximumIncreasedFeedrateExternalArcFinishing = 100
; param: operation:maximumReducedFeedrateInternalArc = 100
; param: operation:maximumIncreasedFeedrateExternalArc = 100
; param: operation:retractionPolicy = full
; param: operation:highFeedrateMode = disabled
; param: operation:highFeedrate = 254
; param: operation:allowRapidRetract = 1
; param: operation:stayDownDistance = 2.5
; param: operation:minimumStayDownClearance = 2
; param: operation:stayDownLevel = level0
; param: operation:astarSpeedRatioJl = 0
; param: operation:liftHeight = 0.2032
; param: operation:noEngagementFeedrate = 254
; param: operation:leadRadius = 0.05
; param: operation:verticalLeadRadius = 0.05
; param: operation:leadInRadius = 0.05
; param: operation:leadInVerticalRadius = 0.05
; param: operation:leadOutRadius = 0.05
; param: operation:leadOutVerticalRadius = 0.05
; param: operation:rampType = helix
; param: operation:allowPlungingOutsideStockJl = 0
; param: operation:rampAngle = 2
; param: operation:rampTaperAngle = 1
; param: operation:rampClearanceHeight = 2.54
; param: operation:helicalRampDiameter = 0.125
; param: operation:minimumRampDiameter = 0.125
; param: operation:allowPlunging = 0
; param: operation:allowHelicalRamps = 1
; param: operation:isOperationTemplate = 0
; param: operation:use_tool_stepdown = 0
; param: operation:tool_stepdown = 23.85
; param: operation:tool_finishingStepdown = 0.2032
; param: operation:use_tool_stepover = 0
; param: operation:tool_stepover = 0.15
; param: operation:tool_finishingStepover = 0.05
; param: operation:tool_rampType = helix
; param: operation:tool_rampAngle = 2
;When using Fusion for Personal Use, the feedrate of rapid
;moves is reduced to match the feedrate of cutting moves,
;which can increase machining time. Unrestricted rapid moves
;are available with a Fusion Subscription.
; param: movement:lead_in = 254
; param: movement:cutting = 254
; param: movement:lead_out = 254
; param: movement:transition = 254
; param: movement:direct = 254
; param: movement:helix_ramp = 84.66666666666667
; param: movement:profile_ramp = 84.66666666666667
; param: movement:zigzag_ramp = 84.66666666666667
; param: movement:ramp = 84.66666666666667
; param: movement:plunge = 84.66666666666667
; param: movement:predrill = 254
; param: movement:extended = 254
; param: movement:reduced = 254
; param: movement:finish_cutting = 254
; param: movement:high_feed = 254
; param: movement:depositing = 0
; param: movement:connection = 0
; param: movement:drill_breakthrough = 0
; param: movement:gun_drill_positioning = 0
; 
; Ranges Table:
;   X: Min=74.596 Max=78.067 Size=3.471
;   Y: Min=61.753 Max=63.23 Size=1.476
;   Z: Min=-8.096 Max=15.24 Size=23.336
; 
; Tools Table:
;  T1 D=0.5 CR=0.25 TAPER=6.2deg - ZMIN=-8.096 - tapered mill 
; 
; Feedrate and Scaling Properties:
;   Feed: Travel speed X/Y = 4470
;   Feed: Travel Speed Z = 2235
;   Feed: Enforce Feedrate = true
;   Feed: Scale Feedrate = false
;   Feed: Max XY Cut Speed = 1000
;   Feed: Max Z Cut Speed = 400
;   Feed: Max Toolpath Speed = 1000
; 
; G1->G0 Mapping Properties:
;   Map: First G1 -> G0 Rapid = false
;   Map: G1s -> G0 Rapids = false
;   Map: SafeZ Mode = Retract : default = 15
;   Map: Allow Rapid Z = false
; 
; *** START begin ***
;   Set Absolute Positioning
;   Units = mm
G90
G21
;   Disable stepper timeout
M84 S0
;   Set current position to 0,0,0
G92 X0 Y0 Z0
; *** START end ***
; 
; *** SECTION begin ***
;   X Min: 74.596 - X Max: 78.067
;   Y Min: 61.753 - Y Max: 63.23
;   Z Min: -8.096 - Z Max: 15.24
; 2D Adaptive7 3 - Milling - Tool: 1 -  tapered mill
; COMMAND_START_SPINDLE
; COMMAND_SPINDLE_CLOCKWISE
; >>> Spindle Speed: Manual
M0 Turn ON 18000RPM
; COMMAND_COOLANT_ON
;   tool.coolant = 0 strCoolant = Off
; ---- Coolant: Off cur: Off A: Off B: Off
M117  2D Adaptive7 (3)
; MOVEMENT_CUTTING
G1 X74.596 Y63.23 Z15.24 F254
G1 Z5.08 F254
G1 Z-7.996 F254
; MOVEMENT_LEAD_IN
G1 Z-8.046 F254
G1 X74.598 Y63.227 Z-8.065 F254
G1 X74.604 Y63.218 Z-8.081 F254
G1 X74.614 Y63.205 Z-8.092 F254
G1 X74.625 Y63.189 Z-8.096 F254
G3 X75.836 Y62.189 I2.558 J1.865 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X76.426 Y61.936 F254
G1 X76.569 Y61.883 F254
G1 X76.72 Y61.866 F254
G1 X76.873 Y61.869 F254
G1 X77.024 Y61.885 F254
G1 X77.18 Y61.914 F254
G1 X77.343 Y61.957 F254
G1 X77.443 Y61.991 F254
G1 X77.459 Y61.998 F254
G1 X77.474 Y62.007 F254
G1 X77.488 Y62.018 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G1 X77.499 Y62.035 Z-8.045 F254
G1 X77.503 Y62.054 Z-7.994 F254
G1 X77.499 Y62.073 Z-7.944 F254
G1 X77.488 Y62.089 Z-7.893 F254
G3 X77.449 Y62.103 I-0.035 J-0.036 F254
G1 X76.957 Y62.068 F254
; MOVEMENT_LEAD_IN
G1 X76.444 Y62.031 F254
G3 X76.402 Y62.003 I0.004 J-0.05 F254
G1 X76.398 Y61.984 Z-7.944 F254
G1 X76.401 Y61.964 Z-7.994 F254
G1 X76.411 Y61.948 Z-8.045 F254
G1 X76.426 Y61.936 Z-8.096 F254
; param: axial-engagement = 0.00000404799993702909
; MOVEMENT_CUTTING
G1 X76.679 Y61.827 F254
G1 X76.705 Y61.817 F254
G1 X76.915 Y61.777 F254
G1 X76.984 Y61.764 F254
G1 X77.035 Y61.754 F254
G1 X77.054 Y61.753 F254
G1 X77.073 Y61.757 F254
G1 X77.273 Y61.827 F254
G1 X77.288 Y61.834 F254
G1 X77.303 Y61.844 F254
G1 X77.434 Y61.967 F254
G1 X77.752 Y62.266 F254
G1 X78.052 Y62.545 F254
; param: axial-engagement = 1
; MOVEMENT_LEAD_OUT
G3 X77.982 Y62.616 I-0.035 J0.035 F254
G1 X77.968 Y62.602 Z-8.092 F254
G1 X77.957 Y62.591 Z-8.081 F254
G1 X77.949 Y62.583 Z-8.065 F254
G1 X77.946 Y62.581 Z-8.046 F254
; MOVEMENT_CUTTING
G1 Z15.24 F254
; *** SECTION end ***
;
; *** STOP begin ***
M400
; COMMAND_COOLANT_OFF
; ---- Coolant: Off cur: Off A: Off B: Off
G0 X0 Y0 F4470
; COMMAND_STOP_SPINDLE
M300 S300 P3000
M0 Turn OFF spindle
M117 Job end
; *** STOP end ***
