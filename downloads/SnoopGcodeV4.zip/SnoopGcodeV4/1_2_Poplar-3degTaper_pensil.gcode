; parseSafeZProperty: safeZMode = 'Retract'
; parseSafeZProperty: safeZHeightDefault = 15
; param: product-id = fusion360
;Fusion CAM 2602.1.25
; Posts processor: MPCNC v3.0 Beta 1.cps
; Gcode generated: Sun Aug 10 02:52:15 2025 GMT
; param: hostname = Harrisons-MacBook-Air.local
; param: username = harrisonesterly
; Document: snoop2 v15
; param: document-id = cdd3c627-a981-4b59-b2d6-a8cf2a6a6479
; param: model-version = 1b7ac768-0c1f-4280-92ec-74a9411570f3
; param: leads-supported = 1
; Setup: Setup1
; param: machine-id = 1
; param: machine-v2 = {
   "controller" : {
      "default" : {
         "head_info_part_id" : "head",
         "max_block_processing_speed" : 118,
         "max_normal_speed" : 4000.0000000000005,
         "non_tcp_rapid_interpolation_mode" : "Unsynchronized",
         "parts" : {
            "X" : {
               "coordinate" : 0,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Y" : {
               "coordinate" : 1,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Z" : {
               "coordinate" : 2,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            }
         },
         "table_part_id" : "table",
         "tcp_rapid_interpolation_mode" : "ToolTip"
      }
   },
   "general" : {
      "capabilities" : [ "milling" ],
      "description" : "Generic 3-axis",
      "minimumRevision" : 45805,
      "vendor" : "MP_CNC"
   },
   "interactions" : {
      "default" : {
         "pairs" : [
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            }
         ]
      }
   },
   "kinematics" : {
      "default" : {
         "conventions" : {
            "rotation" : "right-handed"
         },
         "parts" : [
            {
               "control" : "driven",
               "direction" : [ -1, 0, 0 ],
               "id" : "X",
               "max" : 289.99999999999994,
               "min" : 289.99999999999994,
               "name" : "X",
               "parts" : [
                  {
                     "control" : "driven",
                     "direction" : [ 0, -1, 0 ],
                     "id" : "Y",
                     "name" : "Y",
                     "parts" : [
                        {
                           "control" : "driven",
                           "direction" : [ 0, 0, -1 ],
                           "id" : "Z",
                           "max" : 0,
                           "min" : 0,
                           "name" : "Z",
                           "parts" : [
                              {
                                 "attach_frame" : {
                                    "point" : [ 0, 0, 0 ],
                                    "x_direction" : [ 1, 0, 0 ],
                                    "z_direction" : [ 0, 0, 1 ]
                                 },
                                 "display_name" : "table",
                                 "id" : "table",
                                 "type" : "table"
                              }
                           ],
                           "type" : "linear"
                        }
                     ],
                     "type" : "linear"
                  }
               ],
               "type" : "linear"
            },
            {
               "attach_frame" : {
                  "point" : [ 0, 0, 0 ],
                  "x_direction" : [ 1, 0, 0 ],
                  "z_direction" : [ 0, 0, 1 ]
               },
               "display_name" : "head",
               "id" : "head",
               "spindle" : {
                  "max_speed" : 0,
                  "min_speed" : 0
               },
               "tool_station" : {
                  "coolants" : null,
                  "max_tool_diameter" : 0,
                  "max_tool_length" : 0
               },
               "type" : "head"
            }
         ],
         "units" : {
            "angle" : "degrees",
            "length" : "mm"
         }
      }
   },
   "machining" : {
      "default" : {
         "feedrate_ratio" : 1,
         "tool_change_time" : 15
      }
   },
   "post" : {
      "default" : {
         "output_folder" : "/Users/harrisonesterly/Desktop/LIFE/Projects/MPCNC/fusion_GCode",
         "path" : "user://MPCNC.cps"
      }
   },
   "tooling" : {
      "default" : {
         "has_tool_changer" : false,
         "number_of_tools" : 100,
         "supports_tool_preload" : true
      }
   }
}


; param: stock-type = box
; param: stock = 0, 0, -26.416, 198.882, 300.482, 0
; param: stock-lower-x = 0
; param: stock-lower-y = 0
; param: stock-lower-z = -26.415999999999997
; param: stock-upper-x = 198.882
; param: stock-upper-y = 300.48199999999997
; param: stock-upper-z = 0
; param: part-lower-x = 1.0160000000000018
; param: part-lower-y = 1.0160000000000053
; param: part-lower-z = -26.415999999999997
; param: part-upper-x = 197.866
; param: part-upper-y = 299.466
; param: part-upper-z = -1.016
; param: areBothSpindlesGrabbed = 0
; param: notes = 
; param: operation-strategy = pencil_new
; param: autodeskcam:operation-id = 17
; param: leads-supported = 1
; param: autodeskcam:path = Setups\Setup1\Pencil3
; param: operation:is2DStrategy = 0
; param: operation:is3DStrategy = 1
; param: operation:isRoughingStrategy = 0
; param: operation:isFinishingStrategy = 1
; param: operation:isMillingStrategy = 1
; param: operation:isTurningStrategy = 0
; param: operation:isJetStrategy = 0
; param: operation:isAdditiveStrategy = 0
; param: operation:isProbingStrategy = 0
; param: operation:isInspectionStrategy = 0
; param: operation:isDrillingStrategy = 0
; param: operation:isHoleMillingStrategy = 0
; param: operation:isThreadStrategy = 0
; param: operation:isSamplingStrategy = 0
; param: operation:isRotaryStrategy = 0
; param: operation:isSubspindleStrategy = 0
; param: operation:isSurfaceStrategy = 1
; param: operation:isCheckSurfaceStrategy = 1
; param: operation:isMultiAxisStrategy = 0
; param: operation:advancedMode = 0
; param: operation:betaMode = 0
; param: operation:alphaMode = 0
; param: operation:isXpress = 0
; param: operation:licenseMultiaxis = 1
; param: operation:license3D = 1
; param: operation:metric = 0
; param: operation:isAssemblyDocument = 1
; param: operation:context = operation
; param: operation:strategy = pencil_new
; param: operation:operation_description = 
; param: operation:tool_type = tapered mill
; param: operation:undercut = 0
; param: operation:tool_isTurning = 0
; param: operation:tool_isMill = 1
; param: operation:tool_isDrill = 0
; param: operation:tool_isJet = 0
; param: operation:tool_isDepositing = 0
; param: operation:tool_taperedType = tapered_bull_nose
; param: operation:tool_unit = millimeters
; param: operation:tool_number = 1
; param: operation:tool_diameterOffset = 1
; param: operation:tool_lengthOffset = 1
; param: operation:tool_compensationOffset = 1
; param: operation:tool_turret = 0
; param: operation:tool_manualToolChange = 0
; param: operation:tool_breakControl = 0
; param: operation:tool_live = 1
; param: operation:tool_material = carbide
; param: operation:tool_description = 46473 CNC 2D and 3D Carving 6.2 Deg Tapered Angle Ball Tip x 0.5mm Dia x 0.25mm Radius x 26.5mm x 6mm Shank x 75mm Long x 3 Flute Up-Cut Spiral Solid Carbide ZrN Coated
; param: operation:tool_comment = 
; param: operation:tool_vendor = Amana Tool
; param: operation:tool_productId = 46473
; param: operation:tool_productLink = https://www.amanatool.com/46473-cnc-2d-and-3d-carving-6-2-deg-tapered-angle-ball-tip-x-0-5mm-dia-x-0-25mm-radius-x-26-5mm-x-6mm-shank-x-75mm-long-x-3-flute-up-cut-spiral-solid-carbide-zrn-coated.html
; param: operation:tool_diameter = 0.5
; param: operation:tool_maximumCuttingDiameter = 0
; param: operation:tool_tipDiameter = 0
; param: operation:tool_tipOffset = 0
; param: operation:tool_cornerRadius = 0.25
; param: operation:tool_inclusiveAngle = 0
; param: operation:tool_taperAngle = 6.2
; param: operation:tool_tipAngle = 0
; param: operation:tool_threadTipType = point
; param: operation:tool_threadTipWidth = 0
; param: operation:tool_threadTipRadius = 0
; param: operation:tool_threadProfileAngle = 0
; param: operation:tool_tipLength = 0
; param: operation:tool_fluteLength = 26.5
; param: operation:tool_shoulderLength = 26.5
; param: operation:tool_bodyLength = 40
; param: operation:tool_overallLength = 75
; param: operation:tool_shaftDiameter = 6
; param: operation:tool_segmentHeight = 3
; param: operation:tool_segmentDiameterLower = 12
; param: operation:tool_segmentDiameterUpper = 12
; param: operation:tool_shaftSegmentHeight = 6.75
; param: operation:tool_shaftSegmentDiameterLower = 0.5
; param: operation:tool_shaftSegmentDiameterUpper = 6
; param: operation:tool_threadPitch = 0
; param: operation:tool_maximumThreadPitch = 0
; param: operation:tool_minimumThreadPitch = 0
; param: operation:tool_numberOfTeeth = 0
; param: operation:tool_numberOfFlutes = 3
; param: operation:tool_shoulderDiameter = 6.257643000000001
; param: operation:tool_upperRadius = 1.016
; param: operation:tool_profileRadius = 101.6
; param: operation:tool_lowerRadius = 1.016
; param: operation:tool_axialDistance = 1.016
; param: operation:tool_chamferWidth = 1.016
; param: operation:tool_chamferAngle = 45
; param: operation:holder_attached = 0
; param: operation:holder_description = 
; param: operation:holder_comment = 
; param: operation:holder_vendor = 
; param: operation:holder_productId = 
; param: operation:holder_productLink = 
; param: operation:holder_libraryName = 
; param: operation:tool_holderGaugeLength = 0
; param: operation:tool_assemblyGaugeLength = 40
; param: operation:tool_spindleSpeed = 18000
; param: operation:tool_stockDiameter = 0.5
; param: operation:tool_surfaceSpeed = 28274.33388230814
; param: operation:tool_rampSpindleSpeed = 18000
; param: operation:tool_feedCutting = 152.39999999999998
; param: operation:tool_feedPerTooth = 0.0028222222222222216
; param: operation:tool_feedEntry = 152.39999999999998
; param: operation:tool_feedExit = 152.39999999999998
; param: operation:tool_feedTransition = 152.39999999999998
; param: operation:tool_feedRamp = 50.79999999999999
; param: operation:tool_feedPlunge = 50.79999999999999
; param: operation:tool_feedPerRevolution = 0.0028222222222222216
; param: operation:tool_feedRetract = 50.79999999999999
; param: operation:tool_clockwise = 1
; param: operation:tool_coolant = disabled
; param: operation:featureOperationId = none
; param: operation:surfaceZHigh = -1.016
; param: operation:surfaceZLow = -26.416
; param: operation:surfaceXLow = 1.016
; param: operation:surfaceXHigh = 197.866
; param: operation:surfaceYLow = 1.01600000000001
; param: operation:surfaceYHigh = 299.46599999999995
; param: operation:stockZHigh = 0
; param: operation:stockZLow = -26.416
; param: operation:stockXLow = 0
; param: operation:stockXHigh = 198.88200000000003
; param: operation:stockYLow = 0
; param: operation:stockYHigh = 300.48199999999986
; param: operation:shaftAndHolderMode = dont care
; param: operation:useShaft = 0
; param: operation:shaftClearance = 1.016
; param: operation:useHolder = 0
; param: operation:holderClearance = 5.08
; param: operation:multiAxisMachiningType = three_axis
; param: operation:view_orientation_mode = useWCS
; param: operation:view_orientation_flipZ = 0
; param: operation:view_orientation_axesZX_unselected_default = wcs
; param: operation:view_orientation_axesZY_unselected_default = wcs
; param: operation:view_orientation_axesXY_unselected_default = wcs
; param: operation:view_select_angles = turn_and_tilt
; param: operation:view_turn_from_recipe = 0
; param: operation:view_tilt_from_recipe = 0
; param: operation:view_orientation_flipX = 0
; param: operation:view_orientation_flipY = 0
; param: operation:view_origin_mode = jobOrigin
; param: operation:view_origin_boxPoint = top center
; param: operation:show_machine = 0
; param: operation:multiAxisRotaryAxis_orientation_mode = axisZ
; param: operation:multiAxisRotaryAxis_origin_mode = jobOrigin
; param: operation:toolAxisMode = vertical
; param: operation:leadAngle = 0
; param: operation:leanAngle = 0
; param: operation:multiAxisTiltAngleFixed = 0
; param: operation:toolAxisLimitReferenceZ = setup
; param: operation:smoothingDistance = 1
; param: operation:smoothingAngle = 5
; param: operation:tiltAngle = 0
; param: operation:applyMicroTilt = 1
; param: operation:tiltToolMode = automatic
; param: operation:maximumTiltValidation = 180
; param: operation:minimumTilt5Axis = 0
; param: operation:maximumTilt5Axis = 90
; param: operation:tiltLimitMode = remove_toolpath
; param: operation:usePolarWhenNecessary = 0
; param: operation:polarMode = automatic
; param: operation:polarLineAngle = 0
; param: operation:boundaryMode = selection
; param: operation:useSilhouetteAsMachiningBoundary = 0
; param: operation:silhouetteAperture = 2.5
; param: operation:minimumSilhouetteArea = 0.009817477042468103
; param: operation:boundaryContainment = center
; param: operation:boundaryOffset = 0
; param: operation:machiningBoundaryOffset = 0
; param: operation:boundaryConfineTool = 0
; param: operation:contactOnly = 1
; param: operation:slopeAngleFrom = 0
; param: operation:slopeAngleTo = 90
; param: operation:restMaterialSource = none
; param: operation:restMaterialFromJob = 0
; param: operation:restMaterialOperation = 0
; param: operation:restMaterialUnion = 1
; param: operation:restMaterialPrevious = 1
; param: operation:restMaterialCutterDiameter = 1
; param: operation:restMaterialCornerRadius = 0.5
; param: operation:restMaterialTaperAngle = 0
; param: operation:restMaterialShoulderLength = 0
; param: operation:restMaterialResolution = 1.016
; param: operation:restMaterialOverlap = 0.05
; param: operation:restMaterialFile = 
; param: operation:restMaterialTool = 
; param: operation:restMaterialAdjustment = use as computed
; param: operation:restMaterialAdjustmentOffset = 0
; param: operation:ignoreStockLessThan = 0.02032
; param: operation:includeSetupModel = 1
; param: operation:touchAvoidMode = avoid
; param: operation:viewAbsoluteClearances = 0
; param: operation:radialClearanceInfo = 0
; param: operation:axialClearanceInfo = 0
; param: operation:clearanceInfo = 0
; param: operation:checkSurfaceClearance = 0.01016
; param: operation:trimCheckSurfaces = 0
; param: operation:isClearanceAreaEnabled = 0
; param: operation:clearanceAreaType = plane
; param: operation:clearanceArea_orientation_mode = toolAxisZ
; param: operation:clearanceArea_orientation_flipAxis = 0
; param: operation:clearanceArea_origin_mode = jobOrigin
; param: operation:clearanceArea_origin_boxPoint = top center
; param: operation:clearanceHeight_mode = from retract height
; param: operation:clearanceHeightFromHighest_checkStock = top
; param: operation:clearanceHeightFromLowest_checkStock = bottom
; param: operation:clearanceHeightFromHighest_checkModel = top
; param: operation:clearanceHeightFromLowest_checkModel = bottom
; param: operation:clearanceHeightFromHighest_checkFixture = top
; param: operation:clearanceHeightFromLowest_checkFixture = bottom
; param: operation:clearanceHeight_offset = 10.16
; param: operation:clearanceHeight_value = 15.239999999999998
; param: operation:zClearance = 15.239999999999998
; param: operation:relativeZClearance = 15.239999999999998
; param: operation:clearanceHeight_absolute = 1
; param: operation:clearanceAreaHeight_mode = from retract height
; param: operation:clearanceAreaHeightFromHighest_checkStock = top
; param: operation:clearanceAreaHeightFromLowest_checkStock = bottom
; param: operation:clearanceAreaHeightFromHighest_checkModel = top
; param: operation:clearanceAreaHeightFromLowest_checkModel = bottom
; param: operation:clearanceAreaHeightFromHighest_checkFixture = top
; param: operation:clearanceAreaHeightFromLowest_checkFixture = bottom
; param: operation:clearanceAreaHeight_offset = 10.16
; param: operation:clearanceAreaHeight_value = 0
; param: operation:clearanceAreaHeight_absolute = 0
; param: operation:clearanceAreaCylinderRadius_mode = from retract radius
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkStock = outer diameter
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkModel = outer diameter
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkFixture = outer diameter
; param: operation:clearanceAreaCylinderRadius_offset = 10.16
; param: operation:clearanceAreaCylinderRadius_direct = 2.032
; param: operation:clearanceAreaCylinderRadius_value = 1.016
; param: operation:clearanceAreaCylinderRadius_absolute = 0
; param: operation:clearanceAreaSphereRadius_mode = from retract radius
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkStock = outer diameter
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkModel = outer diameter
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkFixture = outer diameter
; param: operation:clearanceAreaSphereRadius_offset = 10.16
; param: operation:clearanceAreaSphereRadius_direct = 2.032
; param: operation:clearanceAreaSphereRadius_value = 1.016
; param: operation:clearanceAreaSphereRadius_absolute = 0
; param: operation:retractHeight_mode = from stock top
; param: operation:retractHeightFromHighest_checkStock = top
; param: operation:retractHeightFromLowest_checkStock = bottom
; param: operation:retractHeightFromHighest_checkModel = top
; param: operation:retractHeightFromLowest_checkModel = bottom
; param: operation:retractHeightFromHighest_checkFixture = top
; param: operation:retractHeightFromLowest_checkFixture = bottom
; param: operation:retractHeight_offset = 5.08
; param: operation:retractHeight_value = 5.08
; param: operation:zRetract = 5.08
; param: operation:relativeZRetract = 5.08
; param: operation:retractHeight_absolute = 1
; param: operation:retractAreaType = plane
; param: operation:retractAreaHeight_mode = from stock top
; param: operation:retractAreaHeightFromHighest_checkStock = top
; param: operation:retractAreaHeightFromLowest_checkStock = bottom
; param: operation:retractAreaHeightFromHighest_checkModel = top
; param: operation:retractAreaHeightFromLowest_checkModel = bottom
; param: operation:retractAreaHeightFromHighest_checkFixture = top
; param: operation:retractAreaHeightFromLowest_checkFixture = bottom
; param: operation:retractAreaHeight_offset = 5.08
; param: operation:retractAreaHeight_value = 0
; param: operation:retractAreaHeight_absolute = 1
; param: operation:retractAreaCylinderRadius_mode = from stock od
; param: operation:retractAreaCylinderRadiusFromOutermost_checkStock = outer diameter
; param: operation:retractAreaCylinderRadiusFromOutermost_checkModel = outer diameter
; param: operation:retractAreaCylinderRadiusFromOutermost_checkFixture = outer diameter
; param: operation:retractAreaCylinderRadius_offset = 5.08
; param: operation:retractAreaCylinderRadius_direct = 2.032
; param: operation:retractAreaCylinderRadius_value = 1.016
; param: operation:retractAreaCylinderRadius_absolute = 0
; param: operation:retractAreaSphereRadius_mode = from stock od
; param: operation:retractAreaSphereRadiusFromOutermost_checkStock = outer diameter
; param: operation:retractAreaSphereRadiusFromOutermost_checkModel = outer diameter
; param: operation:retractAreaSphereRadiusFromOutermost_checkFixture = outer diameter
; param: operation:retractAreaSphereRadius_offset = 5.08
; param: operation:retractAreaSphereRadius_direct = 2.032
; param: operation:retractAreaSphereRadius_value = 1.016
; param: operation:retractAreaSphereRadius_absolute = 0
; param: operation:topHeight_mode = from stock top
; param: operation:topHeightFromHighest_checkStock = top
; param: operation:topHeightFromLowest_checkStock = bottom
; param: operation:topHeightFromHighest_checkModel = ignore
; param: operation:topHeightFromLowest_checkModel = ignore
; param: operation:topHeightFromHighest_checkFixture = ignore
; param: operation:topHeightFromLowest_checkFixture = ignore
; param: operation:topHeight_offset = 0
; param: operation:topHeight_value = 0
; param: operation:topHeight_absolute = 1
; param: operation:bottomHeight_mode = from surface bottom
; param: operation:bottomHeightFromHighest_checkStock = bottom
; param: operation:bottomHeightFromLowest_checkStock = ignore
; param: operation:bottomHeightFromHighest_checkModel = bottom
; param: operation:bottomHeightFromLowest_checkModel = bottom
; param: operation:bottomHeightFromHighest_checkFixture = ignore
; param: operation:bottomHeightFromLowest_checkFixture = ignore
; param: operation:bottomHeight_offset = 0
; param: operation:bottomHeight_value = -26.416
; param: operation:bottomHeight_absolute = 1
; param: operation:tolerance = 0.01016
; param: operation:contourTolerance = 0.00508
; param: operation:totalSurfaceTolerance = 0.00508
; param: operation:surfaceTriangulationTolerance = 0.00508
; param: operation:calculationTolerance = 0.00508
; param: operation:thinningTolerance = 0.0000508
; param: operation:chainingTolerance = 0.01016
; param: operation:gougingTolerance = 0.00508
; param: operation:overthickness = 0
; param: operation:bitangentAngle = 20
; param: operation:internalPasses = 1
; param: operation:linkInsideOut = 0
; param: operation:linkInsideOutside = outside-in
; param: operation:limitNumberOfStepovers = 1
; param: operation:numberOfStepovers = 0
; param: operation:stepover = 0.25
; param: operation:cuspHeightStepover = 0.07322000000000001
; param: operation:minimumFragmentLength = 0.050800000000000005
; param: operation:fragmentExtensionDistance = 0
; param: operation:direction = both ways
; param: operation:upDownMilling = dont care
; param: operation:upDownMillingShallowAngle = 1
; param: operation:manualProfileDiameter = 0
; param: operation:minimumProfileDiameter = 0
; param: operation:stockToLeave = 0
; param: operation:verticalStockToLeave = 0
; param: operation:simpleStockToLeave = 0
; param: operation:filletsCornerRadius = 0
; param: operation:legacyFillets = 1
; param: operation:useCombinedFilter = 1
; param: operation:useDMKSmoothing = 0
; param: operation:smoothingFilterMode = redistribute
; param: operation:smoothingFilterMaxSpacing = 0.508
; param: operation:smoothingFilterMaxAngle = 3
; param: operation:smoothingFilterToleranceForEvenlySpacedPoints = 0.00508
; param: operation:smoothingFilterToleranceFactor = 0.5
; param: operation:smoothingFilterTolerance = 0
; param: operation:reducedFeedChange = 25
; param: operation:reducedFeedRadius = 0
; param: operation:reducedFeedDistance = 0
; param: operation:reducedFeedrate = 38.099999999999994
; param: operation:reduceOnlyInnerCorners = 1
; param: operation:surfaceSpeedOnArcs = 0
; param: operation:maximumReducedFeedrateInternalArcFinishing = 100
; param: operation:maximumIncreasedFeedrateExternalArcFinishing = 100
; param: operation:maximumReducedFeedrateInternalArc = 100
; param: operation:maximumIncreasedFeedrateExternalArc = 100
; param: operation:retractionPolicy = full
; param: operation:highFeedrateMode = disabled
; param: operation:highFeedrate = 152.39999999999998
; param: operation:allowRapidRetract = 1
; param: operation:safeDistance = 2.032
; param: operation:stayDownDistance = 2.5
; param: operation:entry_verticalRadius = 0.05
; param: operation:leadInRadius = 0.05
; param: operation:leadInVerticalRadius = 0.05
; param: operation:exit_verticalRadius = 0.05
; param: operation:leadOutRadius = 0.05
; param: operation:leadOutVerticalRadius = 0.05
; param: operation:transitionType = curve
; param: operation:isOperationTemplate = 0
; param: operation:use_tool_stepdown = 0
; param: operation:tool_stepdown = 23.85
; param: operation:tool_finishingStepdown = 0.2032
; param: operation:use_tool_stepover = 0
; param: operation:tool_stepover = 0.15
; param: operation:tool_finishingStepover = 0.05
; param: operation:tool_rampType = helix
; param: operation:tool_rampAngle = 2
;When using Fusion for Personal Use, the feedrate of rapid
;moves is reduced to match the feedrate of cutting moves,
;which can increase machining time. Unrestricted rapid moves
;are available with a Fusion Subscription.
; param: movement:lead_in = 152.39999999999998
; param: movement:cutting = 152.39999999999998
; param: movement:lead_out = 152.39999999999998
; param: movement:transition = 152.39999999999998
; param: movement:direct = 152.39999999999998
; param: movement:helix_ramp = 50.79999999999999
; param: movement:profile_ramp = 50.79999999999999
; param: movement:zigzag_ramp = 50.79999999999999
; param: movement:ramp = 50.79999999999999
; param: movement:plunge = 50.79999999999999
; param: movement:predrill = 152.39999999999998
; param: movement:extended = 152.39999999999998
; param: movement:reduced = 152.39999999999998
; param: movement:finish_cutting = 152.39999999999998
; param: movement:high_feed = 152.39999999999998
; param: movement:depositing = 0
; param: movement:connection = 0
; param: movement:drill_breakthrough = 0
; param: movement:gun_drill_positioning = 0
; 
; Ranges Table:
;   X: Min=56.519 Max=142.442 Size=85.923
;   Y: Min=150.056 Max=237.869 Size=87.813
;   Z: Min=-6.018 Max=15.24 Size=21.258
; 
; Tools Table:
;  T1 D=0.5 CR=0.25 TAPER=6.2deg - ZMIN=-6.018 - tapered mill 
; 
; Feedrate and Scaling Properties:
;   Feed: Travel speed X/Y = 4470
;   Feed: Travel Speed Z = 2235
;   Feed: Enforce Feedrate = true
;   Feed: Scale Feedrate = false
;   Feed: Max XY Cut Speed = 1000
;   Feed: Max Z Cut Speed = 400
;   Feed: Max Toolpath Speed = 1000
; 
; G1->G0 Mapping Properties:
;   Map: First G1 -> G0 Rapid = false
;   Map: G1s -> G0 Rapids = false
;   Map: SafeZ Mode = Retract : default = 15
;   Map: Allow Rapid Z = false
; 
; *** START begin ***
;   Set Absolute Positioning
;   Units = mm
G90
G21
;   Disable stepper timeout
M84 S0
;   Set current position to 0,0,0
G92 X0 Y0 Z0
; *** START end ***
; 
; *** SECTION begin ***
;   X Min: 56.519 - X Max: 142.442
;   Y Min: 150.056 - Y Max: 237.869
;   Z Min: -6.018 - Z Max: 15.24
; Pencil3 - Milling - Tool: 1 -  tapered mill
; COMMAND_START_SPINDLE
; COMMAND_SPINDLE_CLOCKWISE
; >>> Spindle Speed: Manual
M0 Turn ON 18000RPM
; COMMAND_COOLANT_ON
;   tool.coolant = 0 strCoolant = Off
; ---- Coolant: Off cur: Off A: Off B: Off
M117  Pencil3
; MOVEMENT_CUTTING
G1 X115.305 Y193.101 Z15.24 F152
G1 Z1.016 F152
; MOVEMENT_PLUNGE
G1 Z-0.983 F51
; MOVEMENT_LEAD_IN
G1 X115.302 Y193.1 Z-1 F152
G1 X115.294 Y193.098 Z-1.015 F152
G1 X115.282 Y193.095 Z-1.026 F152
G1 X115.267 Y193.091 Z-1.032 F152
; MOVEMENT_CUTTING
G1 X115.209 Y193.077 Z-1.045 F152
G1 X115.152 Y193.062 Z-1.06 F152
G1 X115.095 Y193.047 Z-1.078 F152
G1 X115.037 Y193.032 Z-1.097 F152
G1 X114.98 Y193.017 Z-1.121 F152
G1 X114.923 Y193.002 Z-1.149 F152
G1 X114.88 Y192.99 Z-1.177 F152
G1 X114.866 Y192.986 Z-1.187 F152
G1 X114.837 Y192.979 Z-1.216 F152
G1 X114.808 Y192.971 Z-1.285 F152
G1 X114.78 Y192.964 Z-1.356 F152
G1 X114.751 Y192.955 Z-1.433 F152
G1 X114.722 Y192.948 Z-1.493 F152
G1 X114.694 Y192.94 Z-1.562 F152
G1 X114.67 Y192.933 Z-1.623 F152
G1 X114.636 Y192.924 Z-1.699 F152
G1 X114.608 Y192.916 Z-1.768 F152
G1 X114.579 Y192.908 Z-1.836 F152
G1 X114.522 Y192.891 Z-1.958 F152
G1 X114.493 Y192.882 Z-2.027 F152
G1 X114.468 Y192.875 Z-2.081 F152
G1 X114.465 Y192.874 Z-2.088 F152
G1 X114.379 Y192.85 Z-2.27 F152
G1 X114.35 Y192.841 Z-2.336 F152
G1 X114.321 Y192.832 Z-2.398 F152
G1 X114.293 Y192.824 Z-2.452 F152
G1 X114.274 Y192.818 Z-2.497 F152
G1 X114.235 Y192.807 Z-2.569 F152
G1 X114.178 Y192.789 Z-2.694 F152
G1 X114.149 Y192.781 Z-2.748 F152
G1 X114.121 Y192.772 Z-2.807 F152
G1 X114.085 Y192.761 Z-2.882 F152
G1 X114.064 Y192.755 Z-2.92 F152
G1 X114.035 Y192.746 Z-2.977 F152
G1 X114.006 Y192.736 Z-3.042 F152
G1 X113.92 Y192.709 Z-3.211 F152
G1 X113.904 Y192.703 Z-3.246 F152
G1 X113.892 Y192.7 Z-3.264 F152
G1 X113.806 Y192.67 Z-3.433 F152
G1 X113.777 Y192.661 Z-3.482 F152
G1 X113.733 Y192.646 Z-3.569 F152
G1 X113.72 Y192.642 Z-3.594 F152
G1 X113.691 Y192.632 Z-3.651 F152
G1 X113.663 Y192.623 Z-3.699 F152
G1 X113.605 Y192.603 Z-3.811 F152
G1 X113.566 Y192.589 Z-3.896 F152
G1 X113.548 Y192.584 Z-3.924 F152
G1 X113.519 Y192.573 Z-3.989 F152
G1 X113.433 Y192.543 Z-4.158 F152
G1 X113.402 Y192.532 Z-4.217 F152
G1 X113.376 Y192.523 Z-4.258 F152
G1 X113.262 Y192.48 Z-4.469 F152
G1 X113.248 Y192.474 Z-4.496 F152
G1 X113.204 Y192.458 Z-4.574 F152
G1 X113.176 Y192.448 Z-4.627 F152
G1 X113.147 Y192.436 Z-4.687 F152
G1 X113.118 Y192.425 Z-4.74 F152
G1 X113.099 Y192.417 Z-4.782 F152
G1 X113.09 Y192.414 Z-4.801 F152
G1 X113.061 Y192.403 Z-4.854 F152
G1 X113.032 Y192.391 Z-4.914 F152
G1 X112.975 Y192.37 Z-5.02 F152
G1 X112.953 Y192.36 Z-5.066 F152
G1 X112.918 Y192.346 Z-5.125 F152
G1 X112.861 Y192.322 Z-5.219 F152
G1 X112.815 Y192.303 Z-5.304 F152
G1 X112.803 Y192.298 Z-5.321 F152
G1 X112.689 Y192.248 Z-5.541 F152
G1 X112.682 Y192.245 Z-5.552 F152
G1 X112.66 Y192.235 Z-5.596 F152
G1 X112.574 Y192.198 Z-5.761 F152
G1 X112.552 Y192.188 Z-5.805 F152
G1 X112.517 Y192.172 Z-5.862 F152
G1 X112.46 Y192.145 Z-5.955 F152
G1 X112.43 Y192.131 Z-6.008 F152
G1 X112.427 Y192.13 Z-6.009 F152
G1 X112.426 Y192.129 Z-6.012 F152
; MOVEMENT_LINK_TRANSITION
G1 X112.42 Y192.126 Z-6.016 F152
; MOVEMENT_CUTTING
G1 X112.418 F152
G1 X112.417 Y192.125 F152
G1 X112.413 Y192.124 F152
G1 X112.408 F152
G1 X112.406 Y192.123 F152
G1 X112.402 Y192.122 F152
G1 X112.392 Y192.118 F152
G1 X112.383 Y192.116 F152
G1 X112.381 Y192.115 F152
G1 X112.374 Y192.114 F152
G1 X112.345 Y192.105 F152
G1 X112.288 Y192.089 F152
G1 X112.232 Y192.073 F152
G1 X112.23 F152
G1 X112.173 Y192.056 F152
G1 X112.116 Y192.038 F152
G1 X112.059 Y192.017 F152
G1 X112.054 Y192.016 F152
G1 X112.001 Y191.997 F152
G1 X111.944 Y191.977 F152
G1 X111.892 Y191.959 F152
G1 X111.887 Y191.957 F152
G1 X111.772 Y191.916 F152
G1 X111.658 Y191.868 F152
G1 X111.603 Y191.844 F152
G1 X111.6 Y191.843 F152
G1 X111.543 Y191.818 F152
G1 X111.486 Y191.794 F152
G1 X111.468 Y191.787 F152
G1 X111.428 Y191.77 F152
G1 X111.371 Y191.743 F152
G1 X111.314 Y191.715 F152
G1 X111.199 Y191.659 F152
G1 X111.142 Y191.63 F152
G1 X111.11 Y191.615 F152
G1 X111.085 Y191.603 F152
G1 X111.027 Y191.573 F152
G1 X110.913 Y191.51 F152
G1 X110.894 Y191.501 F152
G1 X110.856 Y191.48 F152
G1 X110.684 Y191.386 F152
G1 X110.683 F152
G1 X110.626 Y191.353 F152
G1 X110.584 Y191.329 F152
G1 X110.569 Y191.32 F152
G1 X110.512 Y191.287 F152
G1 X110.486 Y191.272 F152
G1 X110.455 Y191.253 F152
G1 X110.397 Y191.22 F152
G1 X110.387 Y191.214 F152
G1 X110.34 Y191.187 F152
G1 X110.29 Y191.157 F152
G1 X110.283 Y191.153 F152
G1 X110.225 Y191.118 F152
G1 X110.196 Y191.1 F152
G1 X110.168 Y191.083 F152
G1 X110.111 Y191.048 F152
G1 X110.103 Y191.042 F152
G1 X110.054 Y191.012 F152
G1 X110.009 Y190.985 F152
G1 X109.996 Y190.977 F152
G1 X109.939 Y190.942 F152
G1 X109.915 Y190.928 F152
G1 X109.882 Y190.907 F152
G1 X109.767 Y190.834 F152
G1 X109.734 Y190.813 F152
G1 X109.71 Y190.798 F152
G1 X109.653 Y190.761 F152
G1 X109.644 Y190.756 F152
G1 X109.595 Y190.725 F152
G1 X109.554 Y190.699 F152
G1 X109.538 Y190.689 F152
G1 X109.481 Y190.652 F152
G1 X109.465 Y190.641 F152
G1 X109.423 Y190.614 F152
G1 X109.378 Y190.584 F152
G1 X109.366 Y190.576 F152
G1 X109.309 Y190.539 F152
G1 X109.291 Y190.527 F152
G1 X109.204 Y190.47 F152
G1 X109.194 Y190.463 F152
G1 X109.137 Y190.426 F152
G1 X109.117 Y190.412 F152
G1 X109.08 Y190.387 F152
G1 X109.033 Y190.355 F152
G1 X109.022 Y190.348 F152
G1 X108.965 Y190.309 F152
G1 X108.949 Y190.298 F152
G1 X108.908 Y190.269 F152
G1 X108.866 Y190.241 F152
G1 X108.851 Y190.23 F152
G1 X108.793 Y190.19 F152
G1 X108.783 Y190.183 F152
G1 X108.736 Y190.151 F152
G1 X108.7 Y190.126 F152
G1 X108.679 Y190.111 F152
G1 X108.621 Y190.07 F152
G1 X108.62 Y190.069 F152
G1 X108.564 Y190.028 F152
G1 X108.54 Y190.011 F152
G1 X108.507 Y189.987 F152
G1 X108.461 Y189.954 F152
G1 X108.45 Y189.945 F152
G1 X108.392 Y189.903 F152
G1 X108.384 Y189.897 F152
G1 X108.307 Y189.84 F152
G1 X108.278 Y189.817 F152
G1 X108.22 Y189.773 F152
G1 X108.163 Y189.729 F152
G1 X108.159 Y189.725 F152
G1 X108.085 Y189.668 F152
G1 X108.049 Y189.638 F152
G1 X108.015 Y189.61 F152
G1 X107.991 Y189.591 F152
G1 X107.946 Y189.553 F152
G1 X107.934 Y189.543 F152
G1 X107.877 Y189.496 F152
G1 X107.819 Y189.446 F152
G1 X107.811 Y189.439 F152
G1 X107.762 Y189.396 F152
G1 X107.705 Y189.345 F152
G1 X107.682 Y189.324 F152
G1 X107.648 Y189.291 F152
G1 X107.622 Y189.267 F152
G1 X107.59 Y189.238 F152
G1 X107.561 Y189.21 F152
G1 X107.533 Y189.182 F152
G1 X107.476 Y189.123 F152
G1 X107.448 Y189.095 F152
G1 X107.392 Y189.038 F152
G1 X107.361 Y189.006 F152
G1 X107.336 Y188.98 F152
G1 X107.304 Y188.947 F152
G1 X107.28 Y188.923 F152
G1 X107.247 Y188.886 F152
G1 X107.229 Y188.866 F152
G1 X107.189 Y188.822 F152
G1 X107.178 Y188.809 F152
G1 X107.132 Y188.757 F152
G1 X107.128 Y188.751 F152
G1 X107.076 Y188.694 F152
G1 X107.075 Y188.691 F152
G1 X107.026 Y188.637 F152
G1 X107.017 Y188.627 F152
G1 X106.976 Y188.579 F152
G1 X106.96 Y188.56 F152
G1 X106.903 Y188.489 F152
G1 X106.883 Y188.465 F152
G1 X106.846 Y188.419 F152
G1 X106.837 Y188.408 F152
G1 X106.79 Y188.35 F152
G1 X106.788 Y188.349 F152
G1 X106.744 Y188.293 F152
G1 X106.731 Y188.278 F152
G1 X106.696 Y188.236 F152
G1 X106.674 Y188.206 F152
G1 X106.653 Y188.179 F152
G1 X106.616 Y188.13 F152
G1 X106.61 Y188.121 F152
G1 X106.524 Y188.007 F152
G1 X106.502 Y187.977 F152
G1 X106.481 Y187.949 F152
G1 X106.445 Y187.901 F152
G1 X106.438 Y187.892 F152
G1 X106.395 Y187.835 F152
G1 X106.387 Y187.822 F152
G1 X106.358 Y187.778 F152
G1 X106.33 Y187.736 F152
G1 X106.319 Y187.72 F152
G1 X106.282 Y187.663 F152
G1 X106.273 Y187.65 F152
G1 X106.243 Y187.606 F152
G1 X106.215 Y187.565 F152
G1 X106.206 Y187.548 F152
G1 X106.158 Y187.478 F152
G1 X106.129 Y187.434 F152
G1 X106.064 Y187.319 F152
G1 X106.044 Y187.283 F152
G1 X106.033 Y187.262 F152
G1 X106.001 Y187.205 F152
G1 X105.986 Y187.18 F152
G1 X105.968 Y187.148 F152
G1 X105.937 Y187.09 F152
G1 X105.929 Y187.073 F152
G1 X105.91 Y187.033 F152
G1 X105.882 Y186.976 F152
G1 X105.872 Y186.952 F152
G1 X105.858 Y186.918 F152
G1 X105.814 Y186.815 F152
G1 X105.811 Y186.804 F152
G1 X105.79 Y186.747 F152
G1 X105.771 Y186.689 F152
G1 X105.757 Y186.649 F152
G1 X105.753 Y186.632 F152
G1 X105.736 Y186.575 F152
G1 X105.72 Y186.517 F152
G1 X105.709 Y186.46 F152
G1 X105.7 Y186.422 F152
G1 X105.696 Y186.403 F152
G1 X105.685 Y186.346 F152
G1 X105.672 Y186.288 F152
G1 X105.66 Y186.231 F152
G1 X105.644 Y186.117 F152
G1 X105.643 Y186.109 F152
G1 X105.635 Y186.059 F152
G1 X105.587 Y185.716 F152
G1 X105.585 Y185.708 F152
G1 X105.579 Y185.658 F152
G1 X105.561 Y185.544 F152
G1 X105.536 Y185.429 F152
G1 X105.528 Y185.394 F152
G1 X105.524 Y185.372 F152
G1 X105.511 Y185.315 F152
G1 X105.498 Y185.257 F152
G1 X105.485 Y185.2 F152
G1 X105.471 Y185.145 F152
G1 Y185.143 F152
G1 X105.433 Y185.028 F152
G1 X105.413 Y184.971 F152
G1 X105.393 Y184.914 F152
G1 X105.369 Y184.856 F152
G1 X105.356 Y184.828 F152
G1 X105.344 Y184.799 F152
G1 X105.319 Y184.742 F152
G1 X105.293 Y184.685 F152
G1 X105.261 Y184.627 F152
G1 X105.242 Y184.591 F152
G1 X105.231 Y184.57 F152
G1 X105.199 Y184.513 F152
G1 X105.184 Y184.487 F152
G1 X105.165 Y184.455 F152
G1 X105.127 Y184.4 F152
G1 X105.126 Y184.398 F152
G1 X105.089 Y184.341 F152
G1 X105.07 Y184.313 F152
G1 X105.049 Y184.284 F152
G1 X105.012 Y184.237 F152
G1 X105.003 Y184.226 F152
G1 X104.958 Y184.169 F152
G1 X104.955 Y184.165 F152
G1 X104.912 Y184.112 F152
G1 X104.898 Y184.096 F152
G1 X104.86 Y184.055 F152
G1 X104.841 Y184.034 F152
G1 X104.805 Y183.997 F152
G1 X104.783 Y183.974 F152
G1 X104.75 Y183.94 F152
G1 X104.726 Y183.915 F152
G1 X104.691 Y183.883 F152
G1 X104.669 Y183.863 F152
G1 X104.611 Y183.813 F152
G1 X104.561 Y183.768 F152
G1 X104.554 Y183.762 F152
G1 X104.497 Y183.715 F152
G1 X104.491 Y183.711 F152
G1 X104.44 Y183.672 F152
G1 X104.414 Y183.654 F152
G1 X104.382 Y183.629 F152
G1 X104.338 Y183.596 F152
G1 X104.325 Y183.587 F152
G1 X104.268 Y183.55 F152
G1 X104.251 Y183.539 F152
G1 X104.21 Y183.513 F152
G1 X104.161 Y183.482 F152
G1 X104.153 Y183.476 F152
G1 X104.096 Y183.441 F152
G1 X103.981 Y183.378 F152
G1 X103.962 Y183.367 F152
G1 X103.924 Y183.346 F152
G1 X103.867 Y183.316 F152
G1 X103.853 Y183.31 F152
G1 X103.809 Y183.288 F152
G1 X103.752 Y183.262 F152
G1 X103.733 Y183.253 F152
G1 X103.695 Y183.235 F152
G1 X103.638 Y183.209 F152
G1 X103.605 Y183.195 F152
G1 X103.58 Y183.185 F152
G1 X103.466 Y183.138 F152
G1 X103.408 Y183.116 F152
G1 X103.351 Y183.096 F152
G1 X103.306 Y183.081 F152
G1 X103.294 Y183.076 F152
G1 X103.179 Y183.037 F152
G1 X103.138 Y183.023 F152
G1 X103.122 Y183.018 F152
G1 X103.007 Y182.979 F152
G1 X102.967 Y182.966 F152
G1 X102.95 Y182.961 F152
G1 X102.778 Y182.913 F152
G1 X102.764 Y182.909 F152
G1 X102.721 Y182.896 F152
G1 X102.606 Y182.864 F152
G1 X102.561 Y182.852 F152
G1 X102.549 Y182.848 F152
G1 X102.263 Y182.772 F152
G1 X102.205 Y182.756 F152
G1 X102.148 Y182.741 F152
G1 X102.136 Y182.737 F152
G1 X102.091 Y182.724 F152
G1 X102.034 Y182.707 F152
G1 X101.976 Y182.689 F152
G1 X101.944 Y182.68 F152
G1 X101.919 Y182.672 F152
G1 X101.862 Y182.655 F152
G1 X101.804 Y182.637 F152
G1 X101.764 Y182.623 F152
G1 X101.747 Y182.616 F152
G1 X101.69 Y182.596 F152
G1 X101.633 Y182.572 F152
G1 X101.615 Y182.565 F152
G1 X101.575 Y182.548 F152
G1 X101.518 Y182.521 F152
G1 X101.461 Y182.493 F152
G1 X101.403 Y182.459 F152
G1 X101.39 Y182.451 F152
G1 X101.346 Y182.421 F152
G1 X101.308 Y182.393 F152
G1 X101.244 Y182.336 F152
G1 X101.232 Y182.323 F152
G1 X101.193 Y182.279 F152
G1 X101.174 Y182.254 F152
G1 X101.152 Y182.222 F152
G1 X101.117 Y182.165 F152
G1 X101.116 Y182.164 F152
G1 X101.087 Y182.107 F152
G1 X101.06 Y182.044 F152
G1 X101.04 Y181.992 F152
G1 X101.018 Y181.935 F152
G1 X101.002 Y181.899 F152
G1 X100.994 Y181.878 F152
G1 X100.974 Y181.821 F152
G1 X100.955 Y181.763 F152
G1 X100.945 Y181.735 F152
G1 X100.936 Y181.706 F152
G1 X100.899 Y181.592 F152
G1 X100.84 Y181.42 F152
G1 X100.831 Y181.395 F152
G1 X100.82 Y181.362 F152
G1 X100.8 Y181.305 F152
G1 X100.78 Y181.248 F152
G1 X100.773 Y181.23 F152
G1 X100.759 Y181.191 F152
G1 X100.734 Y181.133 F152
G1 X100.716 Y181.093 F152
G1 X100.709 Y181.076 F152
G1 X100.683 Y181.019 F152
G1 X100.659 Y180.964 F152
G1 X100.658 Y180.961 F152
G1 X100.632 Y180.904 F152
G1 X100.607 Y180.847 F152
G1 X100.601 Y180.836 F152
G1 X100.577 Y180.79 F152
G1 X100.545 Y180.732 F152
G1 X100.544 Y180.731 F152
G1 X100.512 Y180.675 F152
G1 X100.487 Y180.632 F152
G1 X100.479 Y180.618 F152
G1 X100.44 Y180.561 F152
G1 X100.43 Y180.544 F152
G1 X100.401 Y180.503 F152
G1 X100.372 Y180.463 F152
G1 X100.361 Y180.446 F152
G1 X100.315 Y180.385 F152
G1 X100.269 Y180.331 F152
G1 X100.258 Y180.318 F152
G1 X100.22 Y180.274 F152
G1 X100.2 Y180.251 F152
G1 X100.169 Y180.217 F152
G1 X100.143 Y180.191 F152
G1 X100.109 Y180.16 F152
G1 X100.086 Y180.137 F152
G1 X100.048 Y180.102 F152
G1 X100.029 Y180.084 F152
G1 X99.986 Y180.045 F152
G1 X99.971 Y180.033 F152
G1 X99.914 Y179.99 F152
G1 X99.91 Y179.988 F152
G1 X99.857 Y179.948 F152
G1 X99.832 Y179.93 F152
G1 X99.799 Y179.907 F152
G1 X99.746 Y179.873 F152
G1 X99.742 Y179.871 F152
G1 X99.685 Y179.838 F152
G1 X99.645 Y179.816 F152
G1 X99.628 Y179.806 F152
G1 X99.57 Y179.775 F152
G1 X99.536 Y179.759 F152
G1 X99.513 Y179.748 F152
G1 X99.398 Y179.701 F152
G1 X99.341 Y179.678 F152
G1 X99.284 Y179.658 F152
G1 X99.23 Y179.644 F152
G1 X99.227 Y179.643 F152
G1 X99.169 Y179.628 F152
G1 X99.112 Y179.612 F152
G1 X99.055 Y179.598 F152
G1 X98.997 Y179.588 F152
G1 X98.987 Y179.587 F152
G1 X98.94 Y179.58 F152
G1 X98.883 Y179.572 F152
G1 X98.826 Y179.563 F152
G1 X98.768 Y179.557 F152
G1 X98.654 Y179.552 F152
G1 X98.539 Y179.548 F152
G1 X98.482 Y179.55 F152
G1 X98.31 Y179.558 F152
G1 X98.253 Y179.564 F152
G1 X98.195 Y179.571 F152
G1 X98.138 Y179.577 F152
G1 X98.081 Y179.584 F152
G1 X98.063 Y179.587 F152
G1 X98.024 Y179.592 F152
G1 X97.966 Y179.603 F152
G1 X97.909 Y179.615 F152
G1 X97.852 Y179.625 F152
G1 X97.794 Y179.637 F152
G1 X97.758 Y179.644 F152
G1 X97.737 Y179.648 F152
G1 X97.68 Y179.659 F152
G1 X97.565 Y179.688 F152
G1 X97.516 Y179.701 F152
G1 X97.508 Y179.703 F152
G1 X97.451 Y179.717 F152
G1 X97.393 Y179.733 F152
G1 X97.336 Y179.747 F152
G1 X97.298 Y179.759 F152
G1 X97.279 Y179.764 F152
G1 X97.222 Y179.781 F152
G1 X97.164 Y179.799 F152
G1 X97.109 Y179.816 F152
G1 X97.107 F152
G1 X97.05 Y179.833 F152
G1 X96.992 Y179.851 F152
G1 X96.935 Y179.868 F152
G1 X96.919 Y179.873 F152
G1 X96.878 Y179.886 F152
G1 X96.763 Y179.92 F152
G1 X96.729 Y179.93 F152
G1 X96.706 Y179.938 F152
G1 X96.591 Y179.973 F152
G1 X96.549 Y179.988 F152
G1 X96.534 Y179.992 F152
G1 X96.42 Y180.03 F152
G1 X96.372 Y180.045 F152
G1 X96.362 Y180.048 F152
G1 X96.248 Y180.087 F152
G1 X96.203 Y180.102 F152
G1 X96.19 Y180.106 F152
G1 X96.076 Y180.145 F152
G1 X96.035 Y180.16 F152
G1 X96.019 Y180.165 F152
G1 X95.904 Y180.208 F152
G1 X95.882 Y180.217 F152
G1 X95.847 Y180.229 F152
G1 X95.732 Y180.272 F152
G1 X95.729 Y180.274 F152
G1 X95.675 Y180.297 F152
G1 X95.618 Y180.322 F152
G1 X95.598 Y180.331 F152
G1 X95.56 Y180.348 F152
G1 X95.503 Y180.373 F152
G1 X95.467 Y180.389 F152
G1 X95.446 Y180.398 F152
G1 X95.388 Y180.425 F152
G1 X95.331 Y180.457 F152
G1 X95.274 Y180.489 F152
G1 X95.248 Y180.503 F152
G1 X95.217 Y180.52 F152
G1 X95.159 Y180.552 F152
G1 X95.144 Y180.561 F152
G1 X95.102 Y180.585 F152
G1 X95.045 Y180.623 F152
G1 X94.93 Y180.707 F152
G1 X94.896 Y180.732 F152
G1 X94.873 Y180.749 F152
G1 X94.818 Y180.79 F152
G1 X94.816 Y180.791 F152
G1 X94.758 Y180.841 F152
G1 X94.752 Y180.847 F152
G1 X94.701 Y180.893 F152
G1 X94.689 Y180.904 F152
G1 X94.644 Y180.948 F152
G1 X94.63 Y180.961 F152
G1 X94.578 Y181.019 F152
G1 X94.529 Y181.072 F152
G1 X94.526 Y181.076 F152
G1 X94.48 Y181.133 F152
G1 X94.472 Y181.143 F152
G1 X94.435 Y181.191 F152
G1 X94.415 Y181.217 F152
G1 X94.392 Y181.248 F152
G1 X94.357 Y181.302 F152
G1 X94.355 Y181.305 F152
G1 X94.318 Y181.362 F152
G1 X94.3 Y181.39 F152
G1 X94.282 Y181.42 F152
G1 X94.252 Y181.477 F152
G1 X94.243 Y181.494 F152
G1 X94.221 Y181.534 F152
G1 X94.192 Y181.592 F152
G1 X94.185 Y181.605 F152
G1 X94.166 Y181.649 F152
G1 X94.141 Y181.706 F152
G1 X94.128 Y181.736 F152
G1 X94.116 Y181.763 F152
G1 X94.096 Y181.821 F152
G1 X94.078 Y181.878 F152
G1 X94.071 Y181.903 F152
G1 X94.06 Y181.935 F152
G1 X94.024 Y182.05 F152
G1 X94.014 Y182.085 F152
G1 X94.006 Y182.107 F152
G1 X93.993 Y182.164 F152
G1 X93.982 Y182.222 F152
G1 X93.972 Y182.279 F152
G1 X93.962 Y182.336 F152
G1 X93.956 Y182.367 F152
G1 X93.951 Y182.393 F152
G1 X93.931 Y182.508 F152
G1 X93.926 Y182.565 F152
G1 X93.917 Y182.68 F152
G1 X93.913 Y182.737 F152
G1 X93.904 Y182.852 F152
G1 X93.902 Y182.909 F152
G1 Y182.966 F152
G1 X93.903 Y183.023 F152
G1 Y183.195 F152
G1 X93.91 Y183.31 F152
G1 X93.912 Y183.367 F152
G1 X93.92 Y183.482 F152
G1 X93.938 Y183.654 F152
G1 X93.946 Y183.711 F152
G1 X93.952 Y183.768 F152
G1 X93.956 Y183.804 F152
G1 X93.958 Y183.825 F152
G1 X93.965 Y183.883 F152
G1 X93.978 Y183.997 F152
G1 X93.985 Y184.055 F152
G1 X93.994 Y184.112 F152
G1 X94.002 Y184.169 F152
G1 X94.011 Y184.226 F152
G1 X94.014 Y184.244 F152
G1 X94.019 Y184.284 F152
G1 X94.028 Y184.341 F152
G1 X94.036 Y184.398 F152
G1 X94.045 Y184.455 F152
G1 X94.053 Y184.513 F152
G1 X94.062 Y184.57 F152
G1 X94.069 Y184.627 F152
G1 X94.071 Y184.637 F152
G1 X94.076 Y184.685 F152
G1 X94.084 Y184.742 F152
G1 X94.091 Y184.799 F152
G1 X94.099 Y184.856 F152
G1 X94.114 Y184.971 F152
G1 X94.122 Y185.028 F152
G1 X94.128 Y185.077 F152
G1 X94.129 Y185.086 F152
G1 X94.135 Y185.143 F152
G1 X94.141 Y185.2 F152
G1 X94.145 Y185.257 F152
G1 X94.156 Y185.372 F152
G1 X94.161 Y185.486 F152
G1 X94.165 Y185.544 F152
G1 X94.168 Y185.601 F152
G1 X94.169 Y185.658 F152
G1 Y185.716 F152
G1 X94.171 Y185.83 F152
G1 Y185.887 F152
G1 X94.164 Y186.117 F152
G1 X94.16 Y186.174 F152
G1 X94.142 Y186.403 F152
G1 X94.136 Y186.46 F152
G1 X94.129 Y186.517 F152
G1 X94.128 Y186.532 F152
G1 X94.108 Y186.689 F152
G1 X94.082 Y186.861 F152
G1 X94.072 Y186.918 F152
G1 X94.071 Y186.927 F152
G1 X94.063 Y186.976 F152
G1 X94.028 Y187.148 F152
G1 X94.017 Y187.205 F152
G1 X94.014 Y187.223 F152
G1 X94.006 Y187.262 F152
G1 X93.991 Y187.319 F152
G1 X93.978 Y187.377 F152
G1 X93.963 Y187.434 F152
G1 X93.956 Y187.465 F152
G1 X93.95 Y187.491 F152
G1 X93.936 Y187.548 F152
G1 X93.922 Y187.606 F152
G1 X93.899 Y187.693 F152
G1 X93.891 Y187.72 F152
G1 X93.875 Y187.778 F152
G1 X93.858 Y187.835 F152
G1 X93.842 Y187.892 F152
G1 Y187.894 F152
G1 X93.826 Y187.949 F152
G1 X93.792 Y188.064 F152
G1 X93.784 Y188.085 F152
G1 X93.773 Y188.121 F152
G1 X93.735 Y188.236 F152
G1 X93.727 Y188.261 F152
G1 X93.716 Y188.293 F152
G1 X93.679 Y188.408 F152
G1 X93.67 Y188.433 F152
G1 X93.658 Y188.465 F152
G1 X93.637 Y188.522 F152
G1 X93.616 Y188.579 F152
G1 X93.613 Y188.59 F152
G1 X93.596 Y188.637 F152
G1 X93.574 Y188.694 F152
G1 X93.555 Y188.747 F152
G1 X93.531 Y188.809 F152
G1 X93.508 Y188.866 F152
G1 X93.498 Y188.892 F152
G1 X93.485 Y188.923 F152
G1 X93.462 Y188.98 F152
G1 X93.441 Y189.034 F152
G1 X93.439 Y189.038 F152
G1 X93.416 Y189.095 F152
G1 X93.391 Y189.152 F152
G1 X93.383 Y189.172 F152
G1 X93.366 Y189.21 F152
G1 X93.326 Y189.302 F152
G1 X93.269 Y189.432 F152
G1 X93.266 Y189.439 F152
G1 X93.239 Y189.496 F152
G1 X93.212 Y189.553 F152
G1 Y189.555 F152
G1 X93.157 Y189.668 F152
G1 X93.154 Y189.674 F152
G1 X93.13 Y189.725 F152
G1 X93.102 Y189.782 F152
G1 X93.097 Y189.794 F152
G1 X93.074 Y189.84 F152
G1 X93.043 Y189.897 F152
G1 X93.04 Y189.905 F152
G1 X93.014 Y189.954 F152
G1 X92.984 Y190.011 F152
G1 X92.982 Y190.016 F152
G1 X92.955 Y190.069 F152
G1 X92.925 Y190.126 F152
G1 X92.894 Y190.183 F152
G1 X92.868 Y190.23 F152
G1 X92.862 Y190.241 F152
G1 X92.83 Y190.298 F152
G1 X92.798 Y190.355 F152
G1 X92.767 Y190.412 F152
G1 X92.753 Y190.437 F152
G1 X92.734 Y190.47 F152
G1 X92.7 Y190.527 F152
G1 X92.696 Y190.534 F152
G1 X92.666 Y190.584 F152
G1 X92.639 Y190.632 F152
G1 X92.632 Y190.641 F152
G1 X92.599 Y190.699 F152
G1 X92.581 Y190.728 F152
G1 X92.565 Y190.756 F152
G1 X92.53 Y190.813 F152
G1 X92.524 Y190.823 F152
G1 X92.495 Y190.871 F152
G1 X92.467 Y190.916 F152
G1 X92.459 Y190.928 F152
G1 X92.424 Y190.985 F152
G1 X92.41 Y191.008 F152
G1 X92.388 Y191.042 F152
G1 X92.352 Y191.1 F152
G1 Y191.101 F152
G1 X92.316 Y191.157 F152
G1 X92.295 Y191.19 F152
G1 X92.279 Y191.214 F152
G1 X92.242 Y191.272 F152
G1 X92.238 Y191.279 F152
G1 X92.205 Y191.329 F152
G1 X92.18 Y191.366 F152
G1 X92.168 Y191.386 F152
G1 X92.13 Y191.443 F152
G1 X92.123 Y191.455 F152
G1 X92.093 Y191.501 F152
G1 X92.066 Y191.542 F152
G1 X92.055 Y191.558 F152
G1 X92.017 Y191.615 F152
G1 X92.009 Y191.627 F152
G1 X91.951 Y191.713 F152
G1 X91.94 Y191.73 F152
G1 X91.863 Y191.844 F152
G1 X91.837 Y191.883 F152
G1 X91.823 Y191.902 F152
G1 X91.784 Y191.959 F152
G1 X91.779 Y191.966 F152
G1 X91.745 Y192.016 F152
G1 X91.722 Y192.049 F152
G1 X91.705 Y192.073 F152
G1 X91.666 Y192.131 F152
G1 X91.665 Y192.133 F152
G1 X91.626 Y192.188 F152
G1 X91.608 Y192.216 F152
G1 X91.55 Y192.298 F152
G1 X91.548 Y192.303 F152
G1 X91.507 Y192.36 F152
G1 X91.493 Y192.38 F152
G1 X91.467 Y192.417 F152
G1 X91.436 Y192.462 F152
G1 X91.427 Y192.474 F152
G1 X91.386 Y192.532 F152
G1 X91.378 Y192.543 F152
G1 X91.346 Y192.589 F152
G1 X91.321 Y192.625 F152
G1 X91.306 Y192.646 F152
G1 X91.266 Y192.703 F152
G1 X91.264 Y192.705 F152
G1 X91.224 Y192.761 F152
G1 X91.207 Y192.786 F152
G1 X91.183 Y192.818 F152
G1 X91.143 Y192.875 F152
G1 X91.102 Y192.933 F152
G1 X91.092 Y192.947 F152
G1 X91.062 Y192.99 F152
G1 X91.035 Y193.027 F152
G1 X91.02 Y193.047 F152
G1 X90.979 Y193.104 F152
G1 X90.977 Y193.107 F152
G1 X90.938 Y193.162 F152
G1 X90.92 Y193.187 F152
G1 X90.897 Y193.219 F152
G1 X90.863 Y193.266 F152
G1 X90.855 Y193.276 F152
G1 X90.814 Y193.334 F152
G1 X90.806 Y193.345 F152
G1 X90.772 Y193.391 F152
G1 X90.748 Y193.425 F152
G1 X90.731 Y193.448 F152
G1 X90.691 Y193.504 F152
G1 X90.69 Y193.505 F152
G1 X90.648 Y193.563 F152
G1 X90.634 Y193.583 F152
G1 X90.607 Y193.62 F152
G1 X90.576 Y193.662 F152
G1 X90.566 Y193.677 F152
G1 X90.524 Y193.734 F152
G1 X90.519 Y193.742 F152
G1 X90.482 Y193.792 F152
G1 X90.405 Y193.9 F152
G1 X90.399 Y193.906 F152
G1 X90.358 Y193.964 F152
G1 X90.347 Y193.978 F152
G1 X90.316 Y194.021 F152
G1 X90.29 Y194.057 F152
G1 X90.275 Y194.078 F152
G1 X90.191 Y194.193 F152
G1 X90.175 Y194.214 F152
G1 X90.149 Y194.25 F152
G1 X90.118 Y194.293 F152
G1 X90.107 Y194.307 F152
G1 X90.065 Y194.365 F152
G1 X90.024 Y194.422 F152
G1 X90.004 Y194.45 F152
G1 X89.946 Y194.528 F152
G1 X89.94 Y194.536 F152
G1 X89.899 Y194.594 F152
G1 X89.832 Y194.685 F152
G1 X89.815 Y194.708 F152
G1 X89.774 Y194.764 F152
G1 Y194.766 F152
G1 X89.731 Y194.823 F152
G1 X89.717 Y194.842 F152
G1 X89.689 Y194.88 F152
G1 X89.648 Y194.937 F152
G1 X89.606 Y194.995 F152
G1 X89.603 Y195 F152
G1 X89.564 Y195.052 F152
G1 X89.545 Y195.078 F152
G1 X89.523 Y195.109 F152
G1 X89.488 Y195.157 F152
G1 X89.439 Y195.224 F152
G1 X89.431 Y195.235 F152
G1 X89.397 Y195.281 F152
G1 X89.373 Y195.314 F152
G1 X89.356 Y195.338 F152
G1 X89.313 Y195.396 F152
G1 X89.272 Y195.453 F152
G1 X89.259 Y195.471 F152
G1 X89.23 Y195.51 F152
G1 X89.202 Y195.55 F152
G1 X89.189 Y195.567 F152
G1 X89.148 Y195.625 F152
G1 X89.144 Y195.629 F152
G1 X89.106 Y195.682 F152
G1 X89.087 Y195.709 F152
G1 X89.065 Y195.739 F152
G1 X89.03 Y195.788 F152
G1 X89.023 Y195.797 F152
G1 X88.982 Y195.854 F152
G1 X88.94 Y195.911 F152
G1 X88.858 Y196.026 F152
G1 X88.816 Y196.083 F152
G1 X88.801 Y196.104 F152
G1 X88.775 Y196.14 F152
G1 X88.743 Y196.184 F152
G1 X88.733 Y196.197 F152
G1 X88.692 Y196.255 F152
G1 X88.686 Y196.264 F152
G1 X88.651 Y196.312 F152
G1 X88.629 Y196.344 F152
G1 X88.611 Y196.369 F152
G1 X88.571 Y196.424 F152
G1 X88.57 Y196.427 F152
G1 X88.528 Y196.484 F152
G1 X88.514 Y196.504 F152
G1 X88.487 Y196.541 F152
G1 X88.457 Y196.584 F152
G1 X88.447 Y196.598 F152
G1 X88.407 Y196.656 F152
G1 X88.4 Y196.666 F152
G1 X88.366 Y196.713 F152
G1 X88.342 Y196.747 F152
G1 X88.325 Y196.77 F152
G1 X88.285 Y196.828 F152
G1 X88.245 Y196.885 F152
G1 X88.204 Y196.942 F152
G1 X88.17 Y196.991 F152
G1 X88.164 Y196.999 F152
G1 X88.085 Y197.114 F152
G1 X88.045 Y197.171 F152
G1 X88.006 Y197.228 F152
G1 X87.999 Y197.238 F152
G1 X87.965 Y197.286 F152
G1 X87.941 Y197.322 F152
G1 X87.926 Y197.343 F152
G1 X87.884 Y197.406 F152
G1 X87.848 Y197.458 F152
G1 X87.827 Y197.49 F152
G1 X87.81 Y197.515 F152
G1 X87.77 Y197.572 F152
G1 X87.769 Y197.574 F152
G1 X87.732 Y197.629 F152
G1 X87.692 Y197.687 F152
G1 X87.655 Y197.744 F152
G1 X87.616 Y197.801 F152
G1 X87.579 Y197.859 F152
G1 X87.54 Y197.916 F152
G1 Y197.917 F152
G1 X87.503 Y197.973 F152
G1 X87.483 Y198.004 F152
G1 X87.465 Y198.03 F152
G1 X87.427 Y198.088 F152
G1 X87.426 Y198.091 F152
G1 X87.391 Y198.145 F152
G1 X87.368 Y198.181 F152
G1 X87.354 Y198.202 F152
G1 X87.281 Y198.317 F152
G1 X87.254 Y198.359 F152
G1 X87.244 Y198.374 F152
G1 X87.208 Y198.431 F152
G1 X87.197 Y198.45 F152
G1 X87.172 Y198.489 F152
G1 X87.139 Y198.543 F152
G1 X87.137 Y198.546 F152
G1 X87.102 Y198.603 F152
G1 X87.067 Y198.66 F152
G1 X87.031 Y198.718 F152
G1 X87.025 Y198.728 F152
G1 X86.996 Y198.775 F152
G1 X86.967 Y198.824 F152
G1 X86.963 Y198.832 F152
G1 X86.929 Y198.89 F152
G1 X86.91 Y198.922 F152
G1 X86.895 Y198.947 F152
G1 X86.861 Y199.004 F152
G1 X86.853 Y199.018 F152
G1 X86.827 Y199.061 F152
G1 X86.796 Y199.117 F152
G1 X86.795 Y199.119 F152
G1 X86.762 Y199.176 F152
G1 X86.738 Y199.221 F152
G1 X86.731 Y199.233 F152
G1 X86.699 Y199.29 F152
G1 X86.681 Y199.324 F152
G1 X86.668 Y199.348 F152
G1 X86.635 Y199.405 F152
G1 X86.624 Y199.427 F152
G1 X86.572 Y199.52 F152
G1 X86.566 Y199.53 F152
G1 X86.541 Y199.577 F152
G1 X86.509 Y199.641 F152
G1 X86.483 Y199.691 F152
G1 X86.452 Y199.754 F152
G1 X86.425 Y199.806 F152
G1 X86.395 Y199.867 F152
G1 X86.367 Y199.921 F152
G1 X86.31 Y200.035 F152
G1 X86.283 Y200.092 F152
G1 X86.28 Y200.1 F152
G1 X86.257 Y200.15 F152
G1 X86.223 Y200.225 F152
G1 X86.204 Y200.264 F152
G1 X86.178 Y200.321 F152
G1 X86.165 Y200.35 F152
G1 X86.152 Y200.379 F152
G1 X86.108 Y200.475 F152
G1 X86.099 Y200.493 F152
G1 X86.006 Y200.722 F152
G1 X85.994 Y200.754 F152
G1 X85.983 Y200.78 F152
G1 X85.936 Y200.894 F152
G1 Y200.896 F152
G1 X85.913 Y200.952 F152
G1 X85.891 Y201.009 F152
G1 X85.879 Y201.042 F152
G1 X85.87 Y201.066 F152
G1 X85.831 Y201.181 F152
G1 X85.822 Y201.206 F152
G1 X85.81 Y201.238 F152
G1 X85.771 Y201.352 F152
G1 X85.764 Y201.37 F152
G1 X85.75 Y201.41 F152
G1 X85.711 Y201.524 F152
G1 X85.707 Y201.536 F152
G1 X85.694 Y201.582 F152
G1 X85.66 Y201.696 F152
G1 X85.65 Y201.732 F152
G1 X85.643 Y201.753 F152
G1 X85.627 Y201.811 F152
G1 X85.593 Y201.925 F152
G1 Y201.927 F152
G1 X85.576 Y201.983 F152
G1 X85.559 Y202.04 F152
G1 X85.544 Y202.097 F152
G1 X85.535 Y202.137 F152
G1 X85.531 Y202.154 F152
G1 X85.478 Y202.38 F152
G1 X85.477 Y202.383 F152
G1 X85.423 Y202.613 F152
G1 X85.421 Y202.626 F152
G1 X85.413 Y202.67 F152
G1 X85.402 Y202.727 F152
G1 X85.382 Y202.842 F152
G1 X85.371 Y202.899 F152
G1 X85.363 Y202.948 F152
G1 X85.362 Y202.956 F152
G1 X85.352 Y203.014 F152
G1 X85.341 Y203.071 F152
G1 X85.321 Y203.185 F152
G1 X85.307 Y203.3 F152
G1 X85.306 Y203.314 F152
G1 X85.294 Y203.415 F152
G1 X85.281 Y203.529 F152
G1 X85.274 Y203.586 F152
G1 X85.268 Y203.644 F152
G1 X85.26 Y203.701 F152
G1 X85.254 Y203.758 F152
G1 X85.25 Y203.815 F152
G1 X85.249 Y203.835 F152
G1 X85.246 Y203.873 F152
G1 X85.243 Y203.93 F152
G1 X85.24 Y203.987 F152
G1 X85.235 Y204.102 F152
G1 X85.231 Y204.159 F152
G1 X85.228 Y204.216 F152
G1 X85.225 Y204.274 F152
G1 X85.219 Y204.388 F152
G1 X85.222 Y204.56 F152
G1 Y204.617 F152
G1 X85.227 Y204.961 F152
G1 X85.23 Y205.018 F152
G1 X85.239 Y205.133 F152
G1 X85.244 Y205.19 F152
G1 X85.249 Y205.244 F152
G1 Y205.247 F152
G1 X85.253 Y205.305 F152
G1 X85.259 Y205.362 F152
G1 X85.268 Y205.477 F152
G1 X85.273 Y205.534 F152
G1 X85.277 Y205.591 F152
G1 X85.285 Y205.648 F152
G1 X85.301 Y205.763 F152
G1 X85.306 Y205.798 F152
G1 X85.309 Y205.82 F152
G1 X85.317 Y205.877 F152
G1 X85.326 Y205.935 F152
G1 X85.346 Y206.049 F152
G1 X85.356 Y206.107 F152
G1 X85.363 Y206.147 F152
G1 X85.366 Y206.164 F152
G1 X85.377 Y206.221 F152
G1 X85.388 Y206.278 F152
G1 X85.414 Y206.393 F152
G1 X85.421 Y206.425 F152
G1 X85.426 Y206.45 F152
G1 X85.439 Y206.508 F152
G1 X85.452 Y206.565 F152
G1 X85.467 Y206.622 F152
G1 X85.478 Y206.664 F152
G1 X85.482 Y206.679 F152
G1 X85.496 Y206.737 F152
G1 X85.526 Y206.851 F152
G1 X85.535 Y206.879 F152
G1 X85.543 Y206.908 F152
G1 X85.577 Y207.023 F152
G1 X85.593 Y207.073 F152
G1 X85.594 Y207.08 F152
G1 X85.612 Y207.138 F152
G1 X85.632 Y207.195 F152
G1 X85.65 Y207.249 F152
G1 X85.651 Y207.252 F152
G1 X85.67 Y207.309 F152
G1 X85.689 Y207.367 F152
G1 X85.707 Y207.418 F152
G1 X85.709 Y207.424 F152
G1 X85.731 Y207.481 F152
G1 X85.753 Y207.539 F152
G1 X85.764 Y207.569 F152
G1 X85.774 Y207.596 F152
G1 X85.796 Y207.653 F152
G1 X85.818 Y207.71 F152
G1 X85.822 Y207.718 F152
G1 X85.842 Y207.768 F152
G1 X85.879 Y207.854 F152
G1 X85.936 Y207.99 F152
G1 X85.939 Y207.997 F152
G1 X85.967 Y208.054 F152
G1 X85.994 Y208.109 F152
G1 Y208.111 F152
G1 X86.05 Y208.226 F152
G1 X86.051 Y208.227 F152
G1 X86.078 Y208.283 F152
G1 X86.105 Y208.34 F152
G1 X86.108 Y208.345 F152
G1 X86.133 Y208.398 F152
G1 X86.161 Y208.455 F152
G1 X86.165 Y208.463 F152
G1 X86.189 Y208.512 F152
G1 X86.219 Y208.57 F152
G1 X86.223 Y208.575 F152
G1 X86.252 Y208.627 F152
G1 X86.28 Y208.675 F152
G1 X86.285 Y208.684 F152
G1 X86.318 Y208.741 F152
G1 X86.337 Y208.774 F152
G1 X86.351 Y208.799 F152
G1 X86.384 Y208.856 F152
G1 X86.395 Y208.875 F152
G1 X86.417 Y208.913 F152
G1 X86.449 Y208.97 F152
G1 X86.452 Y208.974 F152
G1 X86.482 Y209.028 F152
G1 X86.509 Y209.073 F152
G1 X86.516 Y209.085 F152
G1 X86.554 Y209.142 F152
G1 X86.566 Y209.16 F152
G1 X86.624 Y209.247 F152
G1 X86.63 Y209.257 F152
G1 X86.668 Y209.314 F152
G1 X86.681 Y209.333 F152
G1 X86.707 Y209.371 F152
G1 X86.738 Y209.419 F152
G1 X86.745 Y209.429 F152
G1 X86.783 Y209.486 F152
G1 X86.796 Y209.505 F152
G1 X86.821 Y209.543 F152
G1 X86.853 Y209.59 F152
G1 X86.904 Y209.658 F152
G1 X86.91 Y209.666 F152
G1 X86.948 Y209.715 F152
G1 X86.967 Y209.741 F152
G1 X86.991 Y209.772 F152
G1 X87.025 Y209.817 F152
G1 X87.035 Y209.83 F152
G1 X87.078 Y209.887 F152
G1 X87.082 Y209.892 F152
G1 X87.121 Y209.944 F152
G1 X87.139 Y209.967 F152
G1 X87.164 Y210.001 F152
G1 X87.208 Y210.059 F152
G1 X87.254 Y210.112 F152
G1 X87.257 Y210.116 F152
G1 X87.355 Y210.231 F152
G1 X87.368 Y210.247 F152
G1 X87.404 Y210.288 F152
G1 X87.426 Y210.313 F152
G1 X87.453 Y210.345 F152
G1 X87.483 Y210.38 F152
G1 X87.502 Y210.402 F152
G1 X87.551 Y210.46 F152
G1 X87.598 Y210.513 F152
G1 X87.6 Y210.517 F152
G1 X87.655 Y210.574 F152
G1 X87.712 Y210.633 F152
G1 X87.765 Y210.689 F152
G1 X87.769 Y210.693 F152
G1 X87.82 Y210.746 F152
G1 X87.827 Y210.753 F152
G1 X87.875 Y210.803 F152
G1 X87.884 Y210.813 F152
G1 X87.93 Y210.861 F152
G1 X87.941 Y210.872 F152
G1 X87.985 Y210.918 F152
G1 X87.999 Y210.932 F152
G1 X88.044 Y210.975 F152
G1 X88.056 Y210.986 F152
G1 X88.105 Y211.033 F152
G1 X88.113 Y211.04 F152
G1 X88.167 Y211.09 F152
G1 X88.17 Y211.093 F152
G1 X88.228 Y211.147 F152
G1 X88.285 Y211.2 F152
G1 X88.289 Y211.204 F152
G1 X88.342 Y211.254 F152
G1 X88.35 Y211.262 F152
G1 X88.412 Y211.319 F152
G1 X88.457 Y211.357 F152
G1 X88.479 Y211.376 F152
G1 X88.514 Y211.405 F152
G1 X88.571 Y211.453 F152
G1 X88.616 Y211.491 F152
G1 X88.629 Y211.501 F152
G1 X88.685 Y211.548 F152
G1 X88.686 Y211.549 F152
G1 X88.754 Y211.605 F152
G1 X88.801 Y211.645 F152
G1 X88.822 Y211.663 F152
G1 X88.858 Y211.691 F152
G1 X88.896 Y211.72 F152
G1 X88.915 Y211.734 F152
G1 X88.972 Y211.777 F152
G1 X89.03 Y211.819 F152
G1 X89.049 Y211.834 F152
G1 X89.087 Y211.862 F152
G1 X89.202 Y211.948 F152
G1 X89.203 Y211.949 F152
G1 X89.259 Y211.99 F152
G1 X89.281 Y212.006 F152
G1 X89.367 Y212.064 F152
G1 X89.373 Y212.068 F152
G1 X89.431 Y212.106 F152
G1 X89.455 Y212.121 F152
G1 X89.488 Y212.143 F152
G1 X89.542 Y212.178 F152
G1 X89.545 Y212.181 F152
G1 X89.66 Y212.256 F152
G1 X89.716 Y212.293 F152
G1 X89.717 Y212.294 F152
G1 X89.774 Y212.327 F152
G1 X89.816 Y212.35 F152
G1 X89.832 Y212.36 F152
G1 X89.889 Y212.392 F152
G1 X89.915 Y212.407 F152
G1 X89.946 Y212.425 F152
G1 X90.004 Y212.458 F152
G1 X90.015 Y212.464 F152
G1 X90.061 Y212.49 F152
G1 X90.115 Y212.522 F152
G1 X90.118 Y212.524 F152
G1 X90.175 Y212.555 F152
G1 X90.225 Y212.579 F152
G1 X90.233 Y212.583 F152
G1 X90.342 Y212.636 F152
G1 X90.347 Y212.639 F152
G1 X90.405 Y212.667 F152
G1 X90.459 Y212.694 F152
G1 X90.462 Y212.695 F152
G1 X90.576 Y212.751 F152
G1 X90.577 F152
G1 X90.634 Y212.777 F152
G1 X90.711 Y212.808 F152
G1 X90.806 Y212.847 F152
G1 X90.851 Y212.865 F152
G1 X90.863 Y212.87 F152
G1 X90.977 Y212.916 F152
G1 X90.993 Y212.923 F152
G1 X91.035 Y212.94 F152
G1 X91.092 Y212.962 F152
G1 X91.147 Y212.98 F152
G1 X91.149 Y212.981 F152
G1 X91.321 Y213.037 F152
G1 X91.323 F152
G1 X91.378 Y213.056 F152
G1 X91.493 Y213.094 F152
G1 X91.497 Y213.095 F152
G1 X91.55 Y213.112 F152
G1 X91.608 Y213.127 F152
G1 X91.665 Y213.141 F152
G1 X91.706 Y213.152 F152
G1 X91.722 Y213.156 F152
G1 X91.779 Y213.171 F152
G1 X91.837 Y213.186 F152
G1 X91.93 Y213.209 F152
G1 X91.951 Y213.215 F152
G1 X92.009 Y213.23 F152
G1 X92.066 Y213.242 F152
G1 X92.123 Y213.253 F152
G1 X92.18 Y213.265 F152
G1 X92.194 Y213.266 F152
G1 X92.238 Y213.275 F152
G1 X92.295 Y213.286 F152
G1 X92.352 Y213.298 F152
G1 X92.491 Y213.324 F152
G1 X92.524 Y213.33 F152
G1 X92.639 Y213.346 F152
G1 X92.696 Y213.353 F152
G1 X92.753 Y213.361 F152
G1 X92.868 Y213.376 F152
G1 X92.909 Y213.381 F152
G1 X92.925 Y213.384 F152
G1 X92.982 Y213.391 F152
G1 X93.04 Y213.399 F152
G1 X93.097 Y213.406 F152
G1 X93.154 Y213.411 F152
G1 X93.269 Y213.42 F152
G1 X93.326 Y213.424 F152
G1 X93.441 Y213.433 F152
G1 X93.498 Y213.436 F152
G1 X93.525 Y213.438 F152
G1 X93.555 Y213.441 F152
G1 X93.613 Y213.445 F152
G1 X93.67 Y213.449 F152
G1 X93.727 Y213.453 F152
G1 X93.842 Y213.455 F152
G1 X93.899 Y213.457 F152
G1 X94.185 Y213.461 F152
G1 X94.243 Y213.463 F152
G1 X94.3 Y213.464 F152
G1 X94.357 F152
G1 X94.586 Y213.457 F152
G1 X94.644 Y213.454 F152
G1 X94.816 Y213.449 F152
G1 X94.873 Y213.446 F152
G1 X94.93 Y213.444 F152
G1 X94.987 Y213.442 F152
G1 X95.028 Y213.438 F152
G1 X95.045 Y213.437 F152
G1 X95.217 Y213.421 F152
G1 X95.274 Y213.417 F152
G1 X95.446 Y213.401 F152
G1 X95.503 Y213.396 F152
G1 X95.618 Y213.385 F152
G1 X95.646 Y213.381 F152
G1 X95.675 Y213.377 F152
G1 X95.732 Y213.368 F152
G1 X95.789 Y213.36 F152
G1 X95.847 Y213.351 F152
G1 X95.961 Y213.335 F152
G1 X96.036 Y213.324 F152
G1 X96.076 Y213.318 F152
G1 X96.133 Y213.309 F152
G1 X96.19 Y213.301 F152
G1 X96.248 Y213.292 F152
G1 X96.362 Y213.269 F152
G1 X96.375 Y213.266 F152
G1 X96.42 Y213.257 F152
G1 X96.649 Y213.211 F152
G1 X96.654 Y213.209 F152
G1 X96.706 Y213.198 F152
G1 X96.821 Y213.175 F152
G1 X96.878 Y213.163 F152
G1 X96.92 Y213.152 F152
G1 X96.935 Y213.148 F152
G1 X97.137 Y213.095 F152
G1 X97.164 Y213.088 F152
G1 X97.336 Y213.043 F152
G1 X97.356 Y213.037 F152
G1 X97.393 Y213.027 F152
G1 X97.451 Y213.013 F152
G1 X97.508 Y212.997 F152
G1 X97.561 Y212.98 F152
G1 X97.565 Y212.979 F152
G1 X97.623 Y212.96 F152
G1 X97.737 Y212.924 F152
G1 X97.742 Y212.923 F152
G1 X97.794 Y212.907 F152
G1 X97.852 Y212.889 F152
G1 X97.909 Y212.87 F152
G1 X98.081 Y212.816 F152
G1 X98.104 Y212.808 F152
G1 X98.138 Y212.796 F152
G1 X98.253 Y212.755 F152
G1 X98.263 Y212.751 F152
G1 X98.31 Y212.734 F152
G1 X98.367 Y212.713 F152
G1 X98.421 Y212.694 F152
G1 X98.425 Y212.693 F152
G1 X98.482 Y212.672 F152
G1 X98.539 Y212.651 F152
G1 X98.579 Y212.636 F152
G1 X98.596 Y212.63 F152
G1 X98.711 Y212.589 F152
G1 X98.735 Y212.579 F152
G1 X98.768 Y212.566 F152
G1 X98.826 Y212.543 F152
G1 X98.877 Y212.522 F152
G1 X98.883 Y212.52 F152
G1 X98.997 Y212.473 F152
G1 X99.019 Y212.464 F152
G1 X99.055 Y212.45 F152
G1 X99.16 Y212.407 F152
G1 X99.284 Y212.357 F152
G1 X99.302 Y212.35 F152
G1 X99.341 Y212.334 F152
G1 X99.398 Y212.31 F152
G1 X99.456 Y212.284 F152
G1 X99.513 Y212.259 F152
G1 X99.565 Y212.235 F152
G1 X99.57 Y212.234 F152
G1 X99.628 Y212.208 F152
G1 X99.685 Y212.183 F152
G1 X99.695 Y212.178 F152
G1 X99.742 Y212.157 F152
G1 X99.799 Y212.132 F152
G1 X99.824 Y212.121 F152
G1 X99.857 Y212.106 F152
G1 X99.914 Y212.081 F152
G1 X99.953 Y212.064 F152
G1 X99.971 Y212.055 F152
G1 X100.029 Y212.029 F152
G1 X100.075 Y212.006 F152
G1 X100.086 Y212.001 F152
G1 X100.143 Y211.974 F152
G1 X100.194 Y211.949 F152
G1 X100.2 Y211.946 F152
G1 X100.258 Y211.919 F152
G1 X100.312 Y211.892 F152
G1 X100.315 Y211.891 F152
G1 X100.487 Y211.808 F152
G1 X100.544 Y211.781 F152
G1 X100.55 Y211.777 F152
G1 X100.601 Y211.753 F152
G1 X100.659 Y211.723 F152
G1 X100.665 Y211.72 F152
G1 X100.716 Y211.693 F152
G1 X100.773 Y211.663 F152
G1 X100.774 F152
G1 X100.831 Y211.633 F152
G1 X100.882 Y211.605 F152
G1 X100.888 Y211.603 F152
G1 X100.991 Y211.548 F152
G1 X101.002 Y211.542 F152
G1 X101.06 Y211.511 F152
G1 X101.099 Y211.491 F152
G1 X101.117 Y211.482 F152
G1 X101.174 Y211.451 F152
G1 X101.207 Y211.433 F152
G1 X101.232 Y211.421 F152
G1 X101.289 Y211.389 F152
G1 X101.309 Y211.376 F152
G1 X101.346 Y211.355 F152
G1 X101.403 Y211.322 F152
G1 X101.407 Y211.319 F152
G1 X101.461 Y211.288 F152
G1 X101.505 Y211.262 F152
G1 X101.518 Y211.254 F152
G1 X101.575 Y211.22 F152
G1 X101.602 Y211.204 F152
G1 X101.633 Y211.186 F152
G1 X101.69 Y211.153 F152
G1 X101.7 Y211.147 F152
G1 X101.747 Y211.119 F152
G1 X101.797 Y211.09 F152
G1 X101.804 Y211.085 F152
G1 X101.862 Y211.051 F152
G1 X101.891 Y211.033 F152
G1 X101.919 Y211.015 F152
G1 X101.976 Y210.978 F152
G1 X101.981 Y210.975 F152
G1 X102.034 Y210.941 F152
G1 X102.069 Y210.918 F152
G1 X102.091 Y210.905 F152
G1 X102.148 Y210.868 F152
G1 X102.159 Y210.861 F152
G1 X102.205 Y210.828 F152
G1 X102.242 Y210.803 F152
G1 X102.263 Y210.789 F152
G1 X102.32 Y210.75 F152
G1 X102.325 Y210.746 F152
G1 X102.377 Y210.71 F152
G1 X102.435 Y210.671 F152
G1 X102.489 Y210.632 F152
G1 X102.492 Y210.63 F152
G1 X102.549 Y210.588 F152
G1 X102.567 Y210.574 F152
G1 X102.606 Y210.546 F152
G1 X102.645 Y210.517 F152
G1 X102.664 Y210.504 F152
G1 X102.721 Y210.461 F152
G1 X102.722 Y210.46 F152
G1 X102.778 Y210.416 F152
G1 X102.794 Y210.402 F152
G1 X102.836 Y210.37 F152
G1 X102.867 Y210.345 F152
G1 X102.893 Y210.325 F152
G1 X102.939 Y210.288 F152
G1 X102.95 Y210.28 F152
G1 X103.007 Y210.232 F152
G1 X103.01 Y210.231 F152
G1 X103.077 Y210.173 F152
G1 X103.122 Y210.135 F152
G1 X103.144 Y210.116 F152
G1 X103.179 Y210.087 F152
G1 X103.237 Y210.037 F152
G1 X103.276 Y210.001 F152
G1 X103.294 Y209.985 F152
G1 X103.339 Y209.944 F152
G1 X103.351 Y209.933 F152
G1 X103.401 Y209.887 F152
G1 X103.408 Y209.881 F152
G1 X103.464 Y209.83 F152
G1 X103.523 Y209.771 F152
G1 X103.752 Y209.542 F152
G1 X103.781 Y209.515 F152
G1 X103.867 Y209.429 F152
G1 X103.921 Y209.371 F152
G1 X103.924 Y209.369 F152
G1 X103.975 Y209.314 F152
G1 X103.981 Y209.307 F152
G1 X104.029 Y209.257 F152
G1 X104.082 Y209.2 F152
G1 X104.135 Y209.142 F152
G1 X104.153 Y209.124 F152
G1 X104.189 Y209.085 F152
G1 X104.21 Y209.062 F152
G1 X104.243 Y209.028 F152
G1 X104.268 Y209.001 F152
G1 X104.297 Y208.97 F152
G1 X104.351 Y208.913 F152
G1 X104.382 Y208.881 F152
G1 X104.406 Y208.856 F152
G1 X104.44 Y208.82 F152
G1 X104.497 Y208.76 F152
G1 X104.515 Y208.741 F152
G1 X104.554 Y208.699 F152
G1 X104.569 Y208.684 F152
G1 X104.611 Y208.64 F152
G1 X104.625 Y208.627 F152
G1 X104.669 Y208.584 F152
G1 X104.683 Y208.57 F152
G1 X104.726 Y208.527 F152
G1 X104.742 Y208.512 F152
G1 X104.783 Y208.472 F152
G1 X104.841 Y208.42 F152
G1 X104.866 Y208.398 F152
G1 X104.898 Y208.368 F152
G1 X104.928 Y208.34 F152
G1 X104.955 Y208.316 F152
G1 X104.995 Y208.283 F152
G1 X105.012 Y208.269 F152
G1 X105.07 Y208.222 F152
G1 X105.127 Y208.175 F152
G1 X105.134 Y208.169 F152
G1 X105.184 Y208.132 F152
G1 X105.211 Y208.111 F152
G1 X105.289 Y208.054 F152
G1 X105.299 Y208.047 F152
G1 X105.356 Y208.007 F152
G1 X105.37 Y207.997 F152
G1 X105.456 Y207.939 F152
G1 X105.471 Y207.931 F152
G1 X105.528 Y207.892 F152
G1 X105.544 Y207.882 F152
G1 X105.642 Y207.825 F152
G1 X105.643 F152
G1 X105.7 Y207.791 F152
G1 X105.739 Y207.768 F152
G1 X105.757 Y207.757 F152
G1 X105.814 Y207.726 F152
G1 X105.872 Y207.697 F152
G1 X105.929 Y207.667 F152
G1 X105.986 Y207.637 F152
G1 X106.071 Y207.596 F152
G1 X106.101 Y207.582 F152
G1 X106.158 Y207.556 F152
G1 X106.194 Y207.539 F152
G1 X106.215 Y207.529 F152
G1 X106.273 Y207.502 F152
G1 X106.322 Y207.481 F152
G1 X106.33 Y207.479 F152
G1 X106.445 Y207.43 F152
G1 X106.459 Y207.424 F152
G1 X106.502 Y207.406 F152
G1 X106.559 Y207.383 F152
G1 X106.601 Y207.367 F152
G1 X106.616 Y207.361 F152
G1 X106.731 Y207.318 F152
G1 X106.753 Y207.309 F152
G1 X106.788 Y207.297 F152
G1 X106.846 Y207.275 F152
G1 X106.903 Y207.255 F152
G1 X106.96 Y207.236 F152
G1 X107.075 Y207.197 F152
G1 X107.079 Y207.195 F152
G1 X107.132 Y207.177 F152
G1 X107.189 Y207.158 F152
G1 X107.247 Y207.14 F152
G1 X107.255 Y207.138 F152
G1 X107.304 Y207.122 F152
G1 X107.418 Y207.087 F152
G1 X107.438 Y207.08 F152
G1 X107.476 Y207.069 F152
G1 X107.59 Y207.036 F152
G1 X107.639 Y207.023 F152
G1 X107.648 Y207.021 F152
G1 X107.762 Y206.989 F152
G1 X107.819 Y206.974 F152
G1 X107.846 Y206.966 F152
G1 X107.877 Y206.958 F152
G1 X107.934 Y206.942 F152
G1 X107.991 Y206.926 F152
G1 X108.049 Y206.91 F152
G1 X108.054 Y206.908 F152
G1 X108.106 Y206.894 F152
G1 X108.22 Y206.864 F152
G1 X108.271 Y206.851 F152
G1 X108.278 Y206.85 F152
G1 X108.335 Y206.836 F152
G1 X108.392 Y206.823 F152
G1 X108.507 Y206.794 F152
G1 X108.564 Y206.78 F152
G1 X108.621 Y206.766 F152
G1 X108.679 Y206.753 F152
G1 X108.736 Y206.738 F152
G1 X108.742 Y206.737 F152
G1 X108.793 Y206.725 F152
G1 X108.851 Y206.711 F152
G1 X108.908 Y206.697 F152
G1 X108.965 Y206.685 F152
G1 X108.987 Y206.679 F152
G1 X109.022 Y206.671 F152
G1 X109.137 Y206.646 F152
G1 X109.194 Y206.633 F152
G1 X109.243 Y206.622 F152
G1 X109.252 Y206.62 F152
G1 X109.309 Y206.608 F152
G1 X109.366 Y206.594 F152
G1 X109.481 Y206.569 F152
G1 X109.498 Y206.565 F152
G1 X109.538 Y206.556 F152
G1 X109.653 Y206.531 F152
G1 X109.71 Y206.519 F152
G1 X109.761 Y206.508 F152
G1 X109.767 Y206.507 F152
G1 X109.939 Y206.469 F152
G1 X109.996 Y206.457 F152
G1 X110.027 Y206.45 F152
G1 X110.054 Y206.445 F152
G1 X110.225 Y206.407 F152
G1 X110.283 Y206.396 F152
G1 X110.292 Y206.393 F152
G1 X110.34 Y206.383 F152
G1 X110.557 Y206.336 F152
G1 X110.626 Y206.32 F152
G1 X110.684 Y206.309 F152
G1 X110.798 Y206.284 F152
G1 X110.821 Y206.278 F152
G1 X110.856 Y206.271 F152
G1 X110.97 Y206.246 F152
G1 X111.027 Y206.233 F152
G1 X111.079 Y206.221 F152
G1 X111.085 Y206.22 F152
G1 X111.142 Y206.208 F152
G1 X111.199 Y206.194 F152
G1 X111.257 Y206.182 F152
G1 X111.314 Y206.168 F152
G1 X111.333 Y206.164 F152
G1 X111.371 Y206.156 F152
G1 X111.428 Y206.142 F152
G1 X111.486 Y206.13 F152
G1 X111.543 Y206.116 F152
G1 X111.587 Y206.107 F152
G1 X111.6 Y206.104 F152
G1 X111.658 Y206.091 F152
G1 X111.715 Y206.078 F152
G1 X111.772 Y206.064 F152
G1 X111.829 Y206.05 F152
G1 X111.831 Y206.049 F152
G1 X111.887 Y206.036 F152
G1 X112.001 Y206.009 F152
G1 X112.059 Y205.995 F152
G1 X112.068 Y205.992 F152
G1 X112.116 Y205.981 F152
G1 X112.173 Y205.967 F152
G1 X112.23 Y205.954 F152
G1 X112.306 Y205.935 F152
G1 X112.345 Y205.926 F152
G1 X112.402 Y205.911 F152
G1 X112.46 Y205.898 F152
G1 X112.517 Y205.883 F152
G1 X112.537 Y205.877 F152
G1 X112.574 Y205.869 F152
G1 X112.689 Y205.838 F152
G1 X112.746 Y205.824 F152
G1 X112.757 Y205.82 F152
G1 X112.803 Y205.809 F152
G1 X112.918 Y205.778 F152
G1 X112.975 Y205.764 F152
G1 X112.976 Y205.763 F152
G1 X113.032 Y205.749 F152
G1 X113.09 Y205.733 F152
G1 X113.147 Y205.719 F152
G1 X113.195 Y205.706 F152
G1 X113.204 Y205.704 F152
G1 X113.319 Y205.673 F152
G1 X113.376 Y205.657 F152
G1 X113.407 Y205.648 F152
G1 X113.433 Y205.641 F152
G1 X113.491 Y205.626 F152
G1 X113.605 Y205.594 F152
G1 X113.614 Y205.591 F152
G1 X113.663 Y205.578 F152
G1 X113.777 Y205.545 F152
G1 X113.817 Y205.534 F152
G1 X113.834 Y205.529 F152
G1 X113.892 Y205.512 F152
G1 X113.949 Y205.496 F152
G1 X114.006 Y205.479 F152
G1 X114.016 Y205.477 F152
G1 X114.121 Y205.447 F152
G1 X114.178 Y205.429 F152
G1 X114.35 Y205.378 F152
G1 X114.404 Y205.362 F152
G1 X114.407 Y205.361 F152
G1 X114.522 Y205.327 F152
G1 X114.636 Y205.291 F152
G1 X114.694 Y205.274 F152
G1 X114.751 Y205.256 F152
G1 X114.778 Y205.247 F152
G1 X114.808 Y205.238 F152
G1 X114.923 Y205.203 F152
G1 X114.962 Y205.19 F152
G1 X114.98 Y205.185 F152
G1 X115.095 Y205.147 F152
G1 X115.137 Y205.133 F152
G1 X115.152 Y205.128 F152
G1 X115.209 Y205.109 F152
G1 X115.267 Y205.09 F152
G1 X115.31 Y205.076 F152
G1 X115.324 Y205.071 F152
G1 X115.438 Y205.034 F152
G1 X115.482 Y205.018 F152
G1 X115.496 Y205.014 F152
G1 X115.61 Y204.976 F152
G1 X115.655 Y204.961 F152
G1 X115.668 Y204.957 F152
G1 X115.725 Y204.938 F152
G1 X115.782 Y204.919 F152
G1 X115.828 Y204.904 F152
G1 X115.839 Y204.9 F152
G1 X115.897 Y204.88 F152
G1 X115.954 Y204.86 F152
G1 X115.99 Y204.846 F152
G1 X116.011 Y204.839 F152
G1 X116.069 Y204.818 F152
G1 X116.126 Y204.797 F152
G1 X116.146 Y204.789 F152
G1 X116.24 Y204.755 F152
G1 X116.298 Y204.734 F152
G1 X116.302 Y204.732 F152
G1 X116.355 Y204.713 F152
G1 X116.412 Y204.692 F152
G1 X116.458 Y204.675 F152
G1 X116.47 Y204.671 F152
G1 X116.527 Y204.65 F152
G1 X116.584 Y204.629 F152
G1 X116.615 Y204.617 F152
G1 X116.641 Y204.607 F152
G1 X116.699 Y204.587 F152
G1 X116.813 Y204.544 F152
G1 X116.871 Y204.522 F152
G1 X116.916 Y204.503 F152
G1 X116.928 Y204.498 F152
G1 X116.985 Y204.475 F152
G1 X117.042 Y204.453 F152
G1 X117.059 Y204.446 F152
G1 X117.1 Y204.429 F152
G1 X117.157 Y204.406 F152
G1 X117.202 Y204.388 F152
G1 X117.214 Y204.384 F152
G1 X117.329 Y204.335 F152
G1 X117.339 Y204.331 F152
G1 X117.386 Y204.311 F152
G1 X117.472 Y204.274 F152
G1 X117.501 Y204.262 F152
G1 X117.558 Y204.237 F152
G1 X117.605 Y204.216 F152
G1 X117.615 Y204.213 F152
G1 X117.673 Y204.188 F152
G1 X117.73 Y204.162 F152
G1 X117.735 Y204.159 F152
G1 X117.787 Y204.135 F152
G1 X117.959 Y204.054 F152
G1 X117.98 Y204.045 F152
G1 X118.016 Y204.028 F152
G1 X118.188 Y203.947 F152
G1 X118.225 Y203.93 F152
G1 X118.245 Y203.921 F152
G1 X118.303 Y203.892 F152
G1 X118.339 Y203.873 F152
G1 X118.36 Y203.863 F152
G1 X118.417 Y203.833 F152
G1 X118.452 Y203.815 F152
G1 X118.475 Y203.805 F152
G1 X118.532 Y203.775 F152
G1 X118.563 Y203.758 F152
G1 X118.589 Y203.744 F152
G1 X118.646 Y203.713 F152
G1 X118.669 Y203.701 F152
G1 X118.704 Y203.682 F152
G1 X118.761 Y203.652 F152
G1 X118.818 Y203.619 F152
G1 X118.933 Y203.553 F152
G1 X118.975 Y203.529 F152
G1 X118.99 Y203.52 F152
G1 X119.047 Y203.487 F152
G1 X119.162 Y203.417 F152
G1 X119.166 Y203.415 F152
G1 X119.219 Y203.381 F152
G1 X119.259 Y203.357 F152
G1 X119.277 Y203.346 F152
G1 X119.334 Y203.309 F152
G1 X119.347 Y203.3 F152
G1 X119.391 Y203.271 F152
G1 X119.434 Y203.243 F152
G1 X119.448 Y203.234 F152
G1 X119.506 Y203.195 F152
G1 X119.521 Y203.185 F152
G1 X119.563 Y203.156 F152
G1 X119.601 Y203.128 F152
G1 X119.62 Y203.115 F152
G1 X119.678 Y203.074 F152
G1 X119.682 Y203.071 F152
G1 X119.735 Y203.033 F152
G1 X119.762 Y203.014 F152
G1 X119.792 Y202.99 F152
G1 X119.836 Y202.956 F152
G1 X119.849 Y202.946 F152
G1 X119.907 Y202.902 F152
G1 X119.964 Y202.858 F152
G1 X119.983 Y202.842 F152
G1 X120.021 Y202.81 F152
G1 X120.052 Y202.784 F152
G1 X120.079 Y202.763 F152
G1 X120.122 Y202.727 F152
G1 X120.136 Y202.715 F152
G1 X120.188 Y202.67 F152
G1 X120.193 Y202.665 F152
G1 X120.25 Y202.614 F152
G1 X120.251 Y202.613 F152
G1 X120.308 Y202.562 F152
G1 X120.315 Y202.555 F152
G1 X120.377 Y202.498 F152
G1 X120.422 Y202.453 F152
G1 X120.435 Y202.441 F152
G1 X120.48 Y202.398 F152
G1 X120.537 Y202.341 F152
G1 X120.55 Y202.326 F152
G1 X120.602 Y202.269 F152
G1 X120.651 Y202.214 F152
G1 X120.654 Y202.212 F152
G1 X120.706 Y202.154 F152
G1 X120.709 Y202.152 F152
G1 X120.766 Y202.088 F152
G1 X120.81 Y202.04 F152
G1 X120.823 Y202.026 F152
G1 X120.859 Y201.983 F152
G1 X120.881 Y201.956 F152
G1 X120.904 Y201.925 F152
G1 X120.938 Y201.881 F152
G1 X120.948 Y201.868 F152
G1 X120.992 Y201.811 F152
G1 X121.036 Y201.753 F152
G1 X121.081 Y201.696 F152
G1 X121.11 Y201.659 F152
G1 X121.124 Y201.639 F152
G1 X121.163 Y201.582 F152
G1 X121.167 Y201.575 F152
G1 X121.201 Y201.524 F152
G1 X121.224 Y201.489 F152
G1 X121.239 Y201.467 F152
G1 X121.276 Y201.41 F152
G1 X121.315 Y201.352 F152
G1 X121.339 Y201.315 F152
G1 X121.352 Y201.295 F152
G1 X121.386 Y201.238 F152
G1 X121.419 Y201.181 F152
G1 X121.452 Y201.123 F152
G1 X121.453 Y201.121 F152
G1 X121.485 Y201.066 F152
G1 X121.511 Y201.02 F152
G1 X121.55 Y200.952 F152
G1 X121.568 Y200.919 F152
G1 X121.581 Y200.894 F152
G1 X121.609 Y200.837 F152
G1 X121.666 Y200.722 F152
G1 X121.683 Y200.688 F152
G1 X121.723 Y200.608 F152
G1 X121.74 Y200.572 F152
G1 X121.751 Y200.551 F152
G1 X121.776 Y200.493 F152
G1 X121.797 Y200.441 F152
G1 X121.8 Y200.436 F152
G1 X121.824 Y200.379 F152
G1 X121.849 Y200.321 F152
G1 X121.854 Y200.308 F152
G1 X121.873 Y200.264 F152
G1 X121.897 Y200.207 F152
G1 X121.912 Y200.169 F152
G1 X121.919 Y200.15 F152
G1 X121.94 Y200.092 F152
G1 X121.961 Y200.035 F152
G1 X121.982 Y199.978 F152
G1 X122.003 Y199.921 F152
G1 X122.024 Y199.863 F152
G1 X122.026 Y199.856 F152
G1 X122.042 Y199.806 F152
G1 X122.059 Y199.749 F152
G1 X122.077 Y199.691 F152
G1 X122.084 Y199.67 F152
G1 X122.095 Y199.634 F152
G1 X122.129 Y199.52 F152
G1 X122.172 Y199.348 F152
G1 X122.186 Y199.29 F152
G1 X122.198 Y199.239 F152
G1 X122.2 Y199.233 F152
G1 X122.212 Y199.176 F152
G1 X122.234 Y199.061 F152
G1 X122.244 Y199.004 F152
G1 X122.255 Y198.947 F152
G1 Y198.939 F152
G1 X122.264 Y198.89 F152
G1 X122.273 Y198.832 F152
G1 X122.286 Y198.718 F152
G1 X122.293 Y198.66 F152
G1 X122.299 Y198.603 F152
G1 X122.306 Y198.546 F152
G1 X122.313 Y198.489 F152
G1 Y198.485 F152
G1 X122.319 Y198.431 F152
G1 X122.323 Y198.374 F152
G1 X122.325 Y198.317 F152
G1 X122.336 Y198.145 F152
G1 X122.339 Y198.088 F152
G1 X122.342 Y198.03 F152
G1 X122.345 Y197.973 F152
G1 X122.346 Y197.916 F152
G1 X122.349 Y197.801 F152
G1 X122.35 Y197.744 F152
G1 X122.354 Y197.629 F152
G1 X122.355 Y197.572 F152
G1 X122.357 Y197.515 F152
G1 Y197.458 F152
G1 X122.36 Y197.228 F152
G1 Y197.171 F152
G1 X122.364 Y196.942 F152
G1 Y196.885 F152
G1 X122.367 Y196.656 F152
G1 Y196.598 F152
G1 X122.37 Y196.427 F152
G1 Y196.376 F152
G1 X122.371 Y196.369 F152
G1 Y196.312 F152
G1 X122.374 Y196.083 F152
G1 Y196.026 F152
G1 X122.378 Y195.797 F152
G1 Y195.739 F152
G1 X122.382 Y195.51 F152
G1 Y195.453 F152
G1 X122.385 Y195.224 F152
G1 Y195.166 F152
G1 X122.387 Y195.052 F152
G1 Y194.995 F152
G1 X122.388 Y194.937 F152
G1 Y194.88 F152
G1 X122.389 Y194.823 F152
G1 Y194.422 F152
G1 X122.388 Y194.365 F152
G1 Y194.307 F152
G1 X122.386 Y194.193 F152
G1 Y194.135 F152
G1 X122.384 Y194.021 F152
G1 X122.383 Y193.964 F152
G1 X122.382 Y193.906 F152
G1 X122.38 Y193.849 F152
G1 X122.379 Y193.792 F152
G1 X122.377 Y193.734 F152
G1 X122.376 Y193.677 F152
G1 X122.374 Y193.62 F152
G1 X122.372 Y193.563 F152
G1 X122.37 Y193.516 F152
G1 Y193.505 F152
G1 X122.368 Y193.448 F152
G1 X122.366 Y193.391 F152
G1 X122.362 Y193.276 F152
G1 X122.346 Y192.933 F152
G1 X122.342 Y192.875 F152
G1 X122.337 Y192.761 F152
G1 X122.319 Y192.474 F152
G1 X122.316 Y192.417 F152
G1 X122.313 Y192.371 F152
G1 Y192.36 F152
G1 X122.309 Y192.303 F152
G1 X122.3 Y192.188 F152
G1 X122.297 Y192.131 F152
G1 X122.292 Y192.073 F152
G1 X122.289 Y192.016 F152
G1 X122.284 Y191.959 F152
G1 X122.28 Y191.902 F152
G1 X122.263 Y191.672 F152
G1 X122.257 Y191.615 F152
G1 X122.239 Y191.386 F152
G1 X122.234 Y191.329 F152
G1 X122.229 Y191.272 F152
G1 X122.203 Y190.985 F152
G1 X122.198 Y190.936 F152
G1 Y190.928 F152
G1 X122.182 Y190.756 F152
G1 X122.144 Y190.412 F152
G1 X122.141 Y190.378 F152
G1 X122.139 Y190.355 F152
G1 X122.101 Y190.011 F152
G1 X122.096 Y189.954 F152
G1 X122.09 Y189.897 F152
G1 X122.084 Y189.844 F152
G1 Y189.84 F152
G1 X122.065 Y189.668 F152
G1 X122.057 Y189.61 F152
G1 X122.05 Y189.553 F152
G1 X122.041 Y189.496 F152
G1 X122.027 Y189.381 F152
G1 X122.026 Y189.38 F152
G1 X122.019 Y189.324 F152
G1 X122.005 Y189.21 F152
G1 X121.997 Y189.152 F152
G1 X121.99 Y189.095 F152
G1 X121.982 Y189.038 F152
G1 X121.974 Y188.98 F152
G1 X121.969 Y188.942 F152
G1 X121.967 Y188.923 F152
G1 X121.959 Y188.866 F152
G1 X121.945 Y188.751 F152
G1 X121.937 Y188.694 F152
G1 X121.93 Y188.637 F152
G1 X121.922 Y188.579 F152
G1 X121.913 Y188.522 F152
G1 X121.912 Y188.52 F152
G1 X121.904 Y188.465 F152
G1 X121.895 Y188.408 F152
G1 X121.887 Y188.35 F152
G1 X121.854 Y188.145 F152
G1 X121.851 Y188.121 F152
G1 X121.843 Y188.064 F152
G1 X121.803 Y187.835 F152
G1 X121.797 Y187.8 F152
G1 X121.794 Y187.778 F152
G1 X121.744 Y187.491 F152
G1 X121.74 Y187.471 F152
G1 X121.733 Y187.434 F152
G1 X121.722 Y187.377 F152
G1 X121.71 Y187.319 F152
G1 X121.7 Y187.262 F152
G1 X121.688 Y187.205 F152
G1 X121.683 Y187.179 F152
G1 X121.677 Y187.148 F152
G1 X121.666 Y187.09 F152
G1 X121.655 Y187.033 F152
G1 X121.643 Y186.976 F152
G1 X121.632 Y186.918 F152
G1 X121.625 Y186.885 F152
G1 X121.61 Y186.804 F152
G1 X121.598 Y186.747 F152
G1 X121.585 Y186.689 F152
G1 X121.572 Y186.632 F152
G1 X121.568 Y186.616 F152
G1 X121.559 Y186.575 F152
G1 X121.546 Y186.517 F152
G1 X121.533 Y186.46 F152
G1 X121.52 Y186.403 F152
G1 X121.511 Y186.365 F152
G1 X121.506 Y186.346 F152
G1 X121.494 Y186.288 F152
G1 X121.467 Y186.174 F152
G1 X121.454 Y186.117 F152
G1 X121.453 Y186.116 F152
G1 X121.441 Y186.059 F152
G1 X121.427 Y186.002 F152
G1 X121.413 Y185.945 F152
G1 X121.398 Y185.887 F152
G1 X121.396 Y185.883 F152
G1 X121.383 Y185.83 F152
G1 X121.367 Y185.773 F152
G1 X121.351 Y185.716 F152
G1 X121.339 Y185.668 F152
G1 X121.336 Y185.658 F152
G1 X121.291 Y185.486 F152
G1 X121.282 Y185.453 F152
G1 X121.275 Y185.429 F152
G1 X121.23 Y185.257 F152
G1 X121.224 Y185.239 F152
G1 X121.213 Y185.2 F152
G1 X121.196 Y185.143 F152
G1 X121.178 Y185.086 F152
G1 X121.167 Y185.051 F152
G1 X121.161 Y185.028 F152
G1 X121.125 Y184.914 F152
G1 X121.11 Y184.864 F152
G1 X121.108 Y184.856 F152
G1 X121.072 Y184.742 F152
G1 X121.055 Y184.685 F152
G1 X121.052 Y184.677 F152
G1 X121.037 Y184.627 F152
G1 X121.019 Y184.57 F152
G1 X121.002 Y184.513 F152
G1 X120.995 Y184.491 F152
G1 X120.983 Y184.455 F152
G1 X120.964 Y184.398 F152
G1 X120.943 Y184.341 F152
G1 X120.938 Y184.326 F152
G1 X120.924 Y184.284 F152
G1 X120.904 Y184.226 F152
G1 X120.883 Y184.169 F152
G1 X120.881 Y184.161 F152
G1 X120.844 Y184.055 F152
G1 X120.823 Y183.997 F152
G1 X120.784 Y183.883 F152
G1 X120.766 Y183.833 F152
G1 X120.763 Y183.825 F152
G1 X120.744 Y183.768 F152
G1 X120.723 Y183.711 F152
G1 X120.709 Y183.675 F152
G1 X120.701 Y183.654 F152
G1 X120.678 Y183.596 F152
G1 X120.655 Y183.539 F152
G1 X120.651 Y183.529 F152
G1 X120.633 Y183.482 F152
G1 X120.543 Y183.253 F152
G1 X120.537 Y183.238 F152
G1 X120.521 Y183.195 F152
G1 X120.497 Y183.138 F152
G1 X120.48 Y183.092 F152
G1 X120.475 Y183.081 F152
G1 X120.453 Y183.023 F152
G1 X120.429 Y182.966 F152
G1 X120.422 Y182.95 F152
G1 X120.404 Y182.909 F152
G1 X120.379 Y182.852 F152
G1 X120.365 Y182.819 F152
G1 X120.354 Y182.794 F152
G1 X120.329 Y182.737 F152
G1 X120.303 Y182.68 F152
G1 X120.253 Y182.565 F152
G1 X120.25 Y182.56 F152
G1 X120.228 Y182.508 F152
G1 X120.203 Y182.451 F152
G1 X120.193 Y182.429 F152
G1 X120.178 Y182.393 F152
G1 X120.153 Y182.336 F152
G1 X120.136 Y182.299 F152
G1 X120.127 Y182.279 F152
G1 X120.101 Y182.222 F152
G1 X120.079 Y182.178 F152
G1 X120.072 Y182.164 F152
G1 X120.044 Y182.107 F152
G1 X120.021 Y182.061 F152
G1 X120.016 Y182.05 F152
G1 X119.987 Y181.992 F152
G1 X119.964 Y181.945 F152
G1 X119.96 Y181.935 F152
G1 X119.931 Y181.878 F152
G1 X119.907 Y181.829 F152
G1 X119.903 Y181.821 F152
G1 X119.849 Y181.713 F152
G1 X119.847 Y181.706 F152
G1 X119.761 Y181.534 F152
G1 X119.573 Y181.191 F152
G1 X119.563 Y181.174 F152
G1 X119.542 Y181.133 F152
G1 X119.51 Y181.076 F152
G1 X119.506 Y181.069 F152
G1 X119.478 Y181.019 F152
G1 X119.448 Y180.97 F152
G1 X119.443 Y180.961 F152
G1 X119.408 Y180.904 F152
G1 X119.391 Y180.876 F152
G1 X119.373 Y180.847 F152
G1 X119.339 Y180.79 F152
G1 X119.334 Y180.782 F152
G1 X119.304 Y180.732 F152
G1 X119.277 Y180.687 F152
G1 X119.269 Y180.675 F152
G1 X119.235 Y180.618 F152
G1 X119.219 Y180.592 F152
G1 X119.2 Y180.561 F152
G1 X119.163 Y180.503 F152
G1 X119.162 Y180.502 F152
G1 X119.124 Y180.446 F152
G1 X119.105 Y180.418 F152
G1 X119.085 Y180.389 F152
G1 X119.047 Y180.333 F152
G1 Y180.331 F152
G1 X119.007 Y180.274 F152
G1 X118.99 Y180.248 F152
G1 X118.969 Y180.217 F152
G1 X118.933 Y180.164 F152
G1 X118.93 Y180.16 F152
G1 X118.892 Y180.102 F152
G1 X118.876 Y180.08 F152
G1 X118.849 Y180.045 F152
G1 X118.818 Y180.006 F152
G1 X118.805 Y179.988 F152
G1 X118.717 Y179.873 F152
G1 X118.704 Y179.856 F152
G1 X118.673 Y179.816 F152
G1 X118.646 Y179.781 F152
G1 X118.629 Y179.759 F152
G1 X118.589 Y179.707 F152
G1 X118.586 Y179.701 F152
G1 X118.54 Y179.644 F152
G1 X118.532 Y179.635 F152
G1 X118.49 Y179.587 F152
G1 X118.475 Y179.57 F152
G1 X118.388 Y179.472 F152
G1 X118.36 Y179.441 F152
G1 X118.338 Y179.415 F152
G1 X118.303 Y179.376 F152
G1 X118.287 Y179.358 F152
G1 X118.245 Y179.311 F152
G1 X118.188 Y179.249 F152
G1 X118.131 Y179.191 F152
G1 X118.126 Y179.186 F152
G1 X118.012 Y179.071 F152
G1 X117.959 Y179.023 F152
G1 X117.95 Y179.014 F152
G1 X117.902 Y178.97 F152
G1 X117.873 Y178.943 F152
G1 X117.816 Y178.891 F152
G1 X117.792 Y178.871 F152
G1 X117.787 Y178.866 F152
G1 X117.758 Y178.842 F152
G1 X117.73 Y178.819 F152
G1 X117.69 Y178.785 F152
G1 X117.687 Y178.782 F152
G1 X117.673 Y178.771 F152
G1 X117.622 Y178.728 F152
G1 X117.615 Y178.722 F152
G1 X117.604 Y178.713 F152
G1 X117.601 Y178.712 F152
G1 X117.587 Y178.701 F152
G1 X117.585 Y178.699 F152
G1 X117.576 Y178.692 F152
G1 X117.566 Y178.685 F152
G1 X117.558 Y178.678 F152
G1 X117.529 Y178.657 F152
G1 X117.51 Y178.642 F152
G1 X117.508 Y178.64 F152
G1 X117.491 Y178.627 F152
G1 X117.486 Y178.624 F152
G1 X117.47 Y178.611 F152
G1 X117.463 Y178.606 F152
G1 X117.461 Y178.604 F152
G1 X117.453 Y178.599 F152
G1 X117.443 Y178.591 F152
G1 X117.435 Y178.584 F152
G1 X117.429 Y178.58 F152
G1 X117.426 Y178.578 F152
G1 X117.422 Y178.574 F152
G1 X117.418 Y178.572 F152
G1 X117.404 Y178.561 F152
G1 X117.402 Y178.56 F152
G1 X117.4 Y178.558 F152
G1 X117.396 Y178.556 F152
G1 X117.391 Y178.552 F152
G1 X117.388 Y178.55 F152
G1 X117.386 Y178.549 F152
G1 X117.383 Y178.547 F152
G1 X117.382 Y178.546 F152
G1 X117.379 Y178.544 F152
G1 X117.377 Y178.542 F152
G1 X117.375 Y178.541 F152
G1 X117.372 Y178.539 F152
G1 X117.366 Y178.535 F152
G1 Y178.534 F152
G1 X117.363 Y178.533 F152
G1 X117.362 Y178.532 F152
G1 X117.36 Y178.531 F152
G1 X117.359 Y178.53 F152
G1 X117.357 Y178.529 F152
G1 X117.356 Y178.528 F152
G1 X117.355 Y178.527 F152
G1 X117.352 Y178.525 F152
; MOVEMENT_LINK_TRANSITION
G1 X117.353 F152
; MOVEMENT_CUTTING
G1 X117.357 Y178.528 F152
G1 X117.359 Y178.529 F152
G1 X117.36 F152
G1 X117.363 Y178.532 F152
G1 X117.366 Y178.533 F152
G1 X117.367 Y178.534 F152
G1 X117.369 Y178.535 F152
G1 X117.372 Y178.537 F152
G1 X117.373 Y178.538 F152
G1 X117.377 Y178.54 F152
G1 X117.382 Y178.543 F152
G1 X117.383 Y178.544 F152
G1 X117.386 Y178.546 F152
G1 X117.387 Y178.547 F152
G1 X117.389 Y178.548 F152
G1 X117.39 Y178.549 F152
G1 X117.392 Y178.55 F152
G1 X117.393 F152
G1 X117.394 Y178.551 F152
G1 X117.397 Y178.553 F152
G1 X117.4 Y178.556 F152
G1 X117.401 F152
G1 X117.404 Y178.558 F152
G1 X117.405 F152
G1 X117.408 Y178.56 F152
G1 X117.409 Y178.561 F152
G1 X117.412 Y178.563 F152
G1 X117.415 Y178.565 F152
G1 X117.422 Y178.569 F152
G1 X117.426 Y178.572 F152
G1 X117.432 Y178.575 F152
G1 X117.436 Y178.578 F152
G1 X117.446 Y178.584 F152
G1 X117.448 Y178.586 F152
G1 X117.452 Y178.589 F152
G1 X117.457 Y178.592 F152
G1 X117.461 Y178.594 F152
G1 X117.469 Y178.599 F152
G1 X117.47 Y178.6 F152
G1 X117.49 Y178.613 F152
G1 X117.494 Y178.616 F152
G1 X117.501 Y178.62 F152
G1 X117.511 Y178.627 F152
G1 X117.515 Y178.631 F152
G1 X117.529 Y178.641 F152
G1 X117.531 Y178.642 F152
G1 X117.544 Y178.651 F152
G1 X117.558 Y178.661 F152
G1 X117.571 Y178.67 F152
G1 X117.576 Y178.674 F152
G1 X117.587 Y178.681 F152
G1 X117.612 Y178.699 F152
G1 X117.63 Y178.712 F152
G1 X117.644 Y178.722 F152
G1 X117.652 Y178.728 F152
G1 X117.658 Y178.732 F152
G1 X117.673 Y178.743 F152
G1 X117.692 Y178.756 F152
G1 X117.701 Y178.763 F152
G1 X117.73 Y178.783 F152
G1 X117.733 Y178.785 F152
G1 X117.758 Y178.804 F152
G1 X117.787 Y178.824 F152
G1 X117.816 Y178.844 F152
G1 X117.844 Y178.865 F152
G1 X117.894 Y178.899 F152
G1 X118.016 Y178.995 F152
G1 X118.04 Y179.014 F152
G1 X118.074 Y179.04 F152
G1 X118.113 Y179.071 F152
G1 X118.131 Y179.085 F152
G1 X118.186 Y179.129 F152
G1 X118.188 Y179.13 F152
G1 X118.245 Y179.175 F152
G1 X118.26 Y179.186 F152
G1 X118.303 Y179.221 F152
G1 X118.329 Y179.243 F152
G1 X118.36 Y179.27 F152
G1 X118.396 Y179.3 F152
G1 X118.417 Y179.319 F152
G1 X118.475 Y179.368 F152
G1 X118.53 Y179.415 F152
G1 X118.532 Y179.417 F152
G1 X118.589 Y179.466 F152
G1 X118.596 Y179.472 F152
G1 X118.646 Y179.515 F152
G1 X118.663 Y179.53 F152
G1 X118.704 Y179.566 F152
G1 X118.725 Y179.587 F152
G1 X118.761 Y179.62 F152
G1 X118.787 Y179.644 F152
G1 X118.818 Y179.674 F152
G1 X118.849 Y179.701 F152
G1 X118.876 Y179.726 F152
G1 X118.91 Y179.759 F152
G1 X118.933 Y179.78 F152
G1 X118.971 Y179.816 F152
G1 X118.99 Y179.834 F152
G1 X119.047 Y179.888 F152
G1 X119.089 Y179.93 F152
G1 X119.105 Y179.946 F152
G1 X119.146 Y179.988 F152
G1 X119.162 Y180.004 F152
G1 X119.202 Y180.045 F152
G1 X119.219 Y180.062 F152
G1 X119.259 Y180.102 F152
G1 X119.277 Y180.12 F152
G1 X119.315 Y180.16 F152
G1 X119.334 Y180.178 F152
G1 X119.371 Y180.217 F152
G1 X119.391 Y180.237 F152
G1 X119.425 Y180.274 F152
G1 X119.448 Y180.3 F152
G1 X119.506 Y180.363 F152
G1 X119.529 Y180.389 F152
G1 X119.581 Y180.446 F152
G1 X119.62 Y180.489 F152
G1 X119.633 Y180.503 F152
G1 X119.678 Y180.552 F152
G1 X119.685 Y180.561 F152
G1 X119.735 Y180.616 F152
G1 X119.736 Y180.618 F152
G1 X119.784 Y180.675 F152
G1 X119.792 Y180.685 F152
G1 X119.849 Y180.754 F152
G1 X119.879 Y180.79 F152
G1 X119.907 Y180.823 F152
G1 X119.927 Y180.847 F152
G1 X119.964 Y180.892 F152
G1 X119.975 Y180.904 F152
G1 X120.021 Y180.96 F152
G1 X120.022 Y180.961 F152
G1 X120.068 Y181.019 F152
G1 X120.079 Y181.033 F152
G1 X120.136 Y181.107 F152
G1 X120.156 Y181.133 F152
G1 X120.193 Y181.183 F152
G1 X120.199 Y181.191 F152
G1 X120.243 Y181.248 F152
G1 X120.25 Y181.258 F152
G1 X120.287 Y181.305 F152
G1 X120.308 Y181.332 F152
G1 X120.33 Y181.362 F152
G1 X120.365 Y181.412 F152
G1 X120.37 Y181.42 F152
G1 X120.411 Y181.477 F152
G1 X120.422 Y181.493 F152
G1 X120.451 Y181.534 F152
G1 X120.48 Y181.575 F152
G1 X120.491 Y181.592 F152
G1 X120.531 Y181.649 F152
G1 X120.537 Y181.656 F152
G1 X120.594 Y181.738 F152
G1 X120.647 Y181.821 F152
G1 X120.651 Y181.828 F152
G1 X120.684 Y181.878 F152
G1 X120.709 Y181.916 F152
G1 X120.72 Y181.935 F152
G1 X120.757 Y181.992 F152
G1 X120.766 Y182.006 F152
G1 X120.794 Y182.05 F152
G1 X120.823 Y182.095 F152
G1 X120.83 Y182.107 F152
G1 X120.864 Y182.164 F152
G1 X120.881 Y182.191 F152
G1 X120.898 Y182.222 F152
G1 X120.965 Y182.336 F152
G1 X120.995 Y182.387 F152
G1 X121.032 Y182.451 F152
G1 X121.052 Y182.485 F152
G1 X121.065 Y182.508 F152
G1 X121.095 Y182.565 F152
G1 X121.11 Y182.591 F152
G1 X121.126 Y182.623 F152
G1 X121.156 Y182.68 F152
G1 X121.167 Y182.699 F152
G1 X121.187 Y182.737 F152
G1 X121.218 Y182.794 F152
G1 X121.224 Y182.806 F152
G1 X121.248 Y182.852 F152
G1 X121.282 Y182.918 F152
G1 X121.305 Y182.966 F152
G1 X121.333 Y183.023 F152
G1 X121.339 Y183.035 F152
G1 X121.36 Y183.081 F152
G1 X121.389 Y183.138 F152
G1 X121.396 Y183.153 F152
G1 X121.417 Y183.195 F152
G1 X121.444 Y183.253 F152
G1 X121.453 Y183.272 F152
G1 X121.47 Y183.31 F152
G1 X121.495 Y183.367 F152
G1 X121.511 Y183.401 F152
G1 X121.521 Y183.424 F152
G1 X121.547 Y183.482 F152
G1 X121.568 Y183.53 F152
G1 X121.572 Y183.539 F152
G1 X121.598 Y183.596 F152
G1 X121.622 Y183.654 F152
G1 X121.625 Y183.661 F152
G1 X121.645 Y183.711 F152
G1 X121.668 Y183.768 F152
G1 X121.683 Y183.801 F152
G1 X121.739 Y183.94 F152
G1 X121.74 Y183.942 F152
G1 X121.762 Y183.997 F152
G1 X121.784 Y184.055 F152
G1 X121.797 Y184.089 F152
G1 X121.805 Y184.112 F152
G1 X121.848 Y184.226 F152
G1 X121.854 Y184.242 F152
G1 X121.87 Y184.284 F152
G1 X121.891 Y184.341 F152
G1 X121.912 Y184.395 F152
G1 X121.913 Y184.398 F152
G1 X121.952 Y184.513 F152
G1 X121.969 Y184.561 F152
G1 X121.972 Y184.57 F152
G1 X122.011 Y184.685 F152
G1 X122.026 Y184.728 F152
G1 X122.031 Y184.742 F152
G1 X122.05 Y184.799 F152
G1 X122.067 Y184.856 F152
G1 X122.084 Y184.907 F152
G1 X122.085 Y184.914 F152
G1 X122.139 Y185.086 F152
G1 X122.141 Y185.091 F152
G1 X122.157 Y185.143 F152
G1 X122.174 Y185.2 F152
G1 X122.206 Y185.315 F152
G1 X122.221 Y185.372 F152
G1 X122.254 Y185.486 F152
G1 X122.255 Y185.492 F152
G1 X122.27 Y185.544 F152
G1 X122.298 Y185.658 F152
G1 X122.312 Y185.716 F152
G1 X122.313 Y185.718 F152
G1 X122.325 Y185.773 F152
G1 X122.34 Y185.83 F152
G1 X122.366 Y185.945 F152
G1 X122.37 Y185.957 F152
G1 X122.379 Y186.002 F152
G1 X122.39 Y186.059 F152
G1 X122.413 Y186.174 F152
G1 X122.424 Y186.231 F152
G1 X122.427 Y186.247 F152
G1 X122.435 Y186.288 F152
G1 X122.446 Y186.346 F152
G1 X122.464 Y186.46 F152
G1 X122.472 Y186.517 F152
G1 X122.481 Y186.575 F152
G1 X122.485 Y186.597 F152
G1 X122.489 Y186.632 F152
G1 X122.498 Y186.689 F152
G1 X122.506 Y186.747 F152
G1 X122.517 Y186.861 F152
G1 X122.523 Y186.918 F152
G1 X122.539 Y187.09 F152
G1 X122.542 Y187.112 F152
G1 X122.544 Y187.148 F152
G1 X122.545 Y187.205 F152
G1 X122.556 Y187.434 F152
G1 X122.558 Y187.491 F152
G1 Y187.548 F152
G1 X122.557 Y187.606 F152
G1 Y187.663 F152
G1 X122.556 Y187.72 F152
G1 Y187.778 F152
G1 X122.555 Y187.835 F152
G1 X122.553 Y187.892 F152
G1 X122.546 Y188.007 F152
G1 X122.544 Y188.064 F152
G1 X122.542 Y188.097 F152
G1 X122.54 Y188.121 F152
G1 X122.533 Y188.236 F152
G1 X122.517 Y188.408 F152
G1 X122.511 Y188.465 F152
G1 X122.5 Y188.579 F152
G1 X122.493 Y188.637 F152
G1 X122.485 Y188.71 F152
G1 X122.479 Y188.751 F152
G1 X122.473 Y188.809 F152
G1 X122.459 Y188.923 F152
G1 X122.452 Y188.98 F152
G1 X122.438 Y189.095 F152
G1 X122.427 Y189.193 F152
G1 X122.425 Y189.21 F152
G1 X122.419 Y189.267 F152
G1 X122.413 Y189.324 F152
G1 X122.4 Y189.496 F152
G1 X122.396 Y189.553 F152
G1 X122.394 Y189.61 F152
G1 X122.391 Y189.668 F152
G1 X122.392 Y189.725 F152
G1 Y189.782 F152
G1 X122.394 Y189.84 F152
G1 X122.416 Y190.069 F152
G1 X122.424 Y190.126 F152
G1 X122.427 Y190.143 F152
G1 X122.435 Y190.183 F152
G1 X122.449 Y190.241 F152
G1 X122.461 Y190.298 F152
G1 X122.475 Y190.355 F152
G1 X122.485 Y190.391 F152
G1 X122.491 Y190.412 F152
G1 X122.51 Y190.47 F152
G1 X122.528 Y190.527 F152
G1 X122.542 Y190.571 F152
G1 X122.546 Y190.584 F152
G1 X122.565 Y190.641 F152
G1 X122.585 Y190.699 F152
G1 X122.599 Y190.739 F152
G1 X122.604 Y190.756 F152
G1 X122.624 Y190.813 F152
G1 X122.643 Y190.871 F152
G1 X122.656 Y190.91 F152
G1 X122.662 Y190.928 F152
G1 X122.68 Y190.985 F152
G1 X122.697 Y191.042 F152
G1 X122.713 Y191.1 F152
G1 X122.714 Y191.102 F152
G1 X122.729 Y191.157 F152
G1 X122.744 Y191.214 F152
G1 X122.758 Y191.272 F152
G1 X122.771 Y191.319 F152
G1 X122.773 Y191.329 F152
G1 X122.8 Y191.443 F152
G1 X122.825 Y191.558 F152
G1 X122.828 Y191.572 F152
G1 X122.837 Y191.615 F152
G1 X122.848 Y191.672 F152
G1 X122.86 Y191.73 F152
G1 X122.881 Y191.844 F152
G1 X122.886 Y191.867 F152
G1 X122.891 Y191.902 F152
G1 X122.902 Y191.959 F152
G1 X122.912 Y192.016 F152
G1 X122.943 Y192.217 F152
G1 X122.946 Y192.245 F152
G1 X122.973 Y192.417 F152
G1 X122.981 Y192.474 F152
G1 X122.996 Y192.589 F152
G1 X123 Y192.618 F152
G1 X123.011 Y192.703 F152
G1 X123.019 Y192.761 F152
G1 X123.033 Y192.875 F152
G1 X123.052 Y193.047 F152
G1 X123.057 Y193.088 F152
G1 X123.084 Y193.334 F152
G1 X123.111 Y193.62 F152
G1 X123.115 Y193.655 F152
G1 X123.116 Y193.677 F152
G1 X123.133 Y193.849 F152
G1 X123.136 Y193.906 F152
G1 X123.168 Y194.307 F152
G1 X123.171 Y194.365 F152
G1 X123.172 Y194.373 F152
G1 X123.175 Y194.422 F152
G1 X123.182 Y194.536 F152
G1 X123.185 Y194.594 F152
G1 X123.195 Y194.766 F152
G1 X123.203 Y194.937 F152
G1 X123.205 Y194.995 F152
G1 X123.208 Y195.052 F152
G1 X123.21 Y195.109 F152
G1 X123.215 Y195.224 F152
G1 X123.217 Y195.281 F152
G1 X123.219 Y195.396 F152
G1 X123.22 Y195.453 F152
G1 X123.222 Y195.567 F152
G1 X123.224 Y195.625 F152
G1 X123.225 Y195.682 F152
G1 Y195.911 F152
G1 X123.224 Y195.968 F152
G1 Y196.083 F152
G1 X123.222 Y196.197 F152
G1 X123.211 Y196.541 F152
G1 X123.206 Y196.656 F152
G1 X123.185 Y196.999 F152
G1 X123.18 Y197.057 F152
G1 X123.175 Y197.114 F152
G1 X123.172 Y197.147 F152
G1 X123.169 Y197.171 F152
G1 X123.142 Y197.458 F152
G1 X123.135 Y197.515 F152
G1 X123.129 Y197.572 F152
G1 X123.115 Y197.687 F152
G1 Y197.688 F152
G1 X123.108 Y197.744 F152
G1 X123.093 Y197.859 F152
G1 X123.085 Y197.916 F152
G1 X123.058 Y198.088 F152
G1 X123.057 Y198.098 F152
G1 X123.05 Y198.145 F152
G1 X123.023 Y198.317 F152
G1 X123.002 Y198.431 F152
G1 X123 Y198.445 F152
G1 X122.992 Y198.489 F152
G1 X122.96 Y198.66 F152
G1 X122.95 Y198.718 F152
G1 X122.943 Y198.755 F152
G1 X122.938 Y198.775 F152
G1 X122.926 Y198.832 F152
G1 X122.914 Y198.89 F152
G1 X122.902 Y198.947 F152
G1 X122.89 Y199.004 F152
G1 X122.865 Y199.119 F152
G1 X122.853 Y199.176 F152
G1 X122.84 Y199.233 F152
G1 X122.828 Y199.281 F152
G1 X122.826 Y199.29 F152
G1 X122.812 Y199.348 F152
G1 X122.798 Y199.405 F152
G1 X122.784 Y199.462 F152
G1 X122.771 Y199.519 F152
G1 X122.77 Y199.52 F152
G1 X122.757 Y199.577 F152
G1 X122.742 Y199.634 F152
G1 X122.727 Y199.691 F152
G1 X122.714 Y199.741 F152
G1 X122.711 Y199.749 F152
G1 X122.681 Y199.863 F152
G1 X122.664 Y199.921 F152
G1 X122.656 Y199.953 F152
G1 X122.649 Y199.978 F152
G1 X122.634 Y200.035 F152
G1 X122.617 Y200.092 F152
G1 X122.599 Y200.15 F152
G1 Y200.152 F152
G1 X122.582 Y200.207 F152
G1 X122.548 Y200.321 F152
G1 X122.542 Y200.342 F152
G1 X122.53 Y200.379 F152
G1 X122.513 Y200.436 F152
G1 X122.495 Y200.493 F152
G1 X122.485 Y200.526 F152
G1 X122.476 Y200.551 F152
G1 X122.457 Y200.608 F152
G1 X122.437 Y200.665 F152
G1 X122.427 Y200.696 F152
G1 X122.399 Y200.78 F152
G1 X122.38 Y200.837 F152
G1 X122.37 Y200.867 F152
G1 X122.359 Y200.894 F152
G1 X122.339 Y200.952 F152
G1 X122.317 Y201.009 F152
G1 X122.313 Y201.02 F152
G1 X122.296 Y201.066 F152
G1 X122.274 Y201.123 F152
G1 X122.255 Y201.174 F152
G1 X122.253 Y201.181 F152
G1 X122.231 Y201.238 F152
G1 X122.208 Y201.295 F152
G1 X122.198 Y201.32 F152
G1 X122.185 Y201.352 F152
G1 X122.161 Y201.41 F152
G1 X122.141 Y201.457 F152
G1 X122.136 Y201.467 F152
G1 X122.113 Y201.524 F152
G1 X122.089 Y201.582 F152
G1 X122.084 Y201.595 F152
G1 X122.064 Y201.639 F152
G1 X122.037 Y201.696 F152
G1 X122.026 Y201.72 F152
G1 X122.01 Y201.753 F152
G1 X121.983 Y201.811 F152
G1 X121.969 Y201.842 F152
G1 X121.956 Y201.868 F152
G1 X121.93 Y201.925 F152
G1 X121.912 Y201.965 F152
G1 X121.902 Y201.983 F152
G1 X121.871 Y202.04 F152
G1 X121.854 Y202.073 F152
G1 X121.841 Y202.097 F152
G1 X121.811 Y202.154 F152
G1 X121.797 Y202.181 F152
G1 X121.751 Y202.269 F152
G1 X121.74 Y202.29 F152
G1 X121.717 Y202.326 F152
G1 X121.683 Y202.383 F152
G1 Y202.385 F152
G1 X121.649 Y202.441 F152
G1 X121.625 Y202.48 F152
G1 X121.615 Y202.498 F152
G1 X121.581 Y202.555 F152
G1 X121.568 Y202.576 F152
G1 X121.545 Y202.613 F152
G1 X121.511 Y202.663 F152
G1 X121.506 Y202.67 F152
G1 X121.467 Y202.727 F152
G1 X121.453 Y202.747 F152
G1 X121.427 Y202.784 F152
G1 X121.389 Y202.842 F152
G1 X121.35 Y202.899 F152
G1 X121.339 Y202.912 F152
G1 X121.306 Y202.956 F152
G1 X121.282 Y202.988 F152
G1 X121.261 Y203.014 F152
G1 X121.224 Y203.062 F152
G1 X121.217 Y203.071 F152
G1 X121.173 Y203.128 F152
G1 X121.167 Y203.136 F152
G1 X121.128 Y203.185 F152
G1 X121.11 Y203.206 F152
G1 X121.078 Y203.243 F152
G1 X121.052 Y203.272 F152
G1 X121.029 Y203.3 F152
G1 X120.995 Y203.338 F152
G1 X120.979 Y203.357 F152
G1 X120.938 Y203.405 F152
G1 X120.93 Y203.415 F152
G1 X120.881 Y203.468 F152
G1 X120.877 Y203.472 F152
G1 X120.655 Y203.701 F152
G1 X120.651 Y203.704 F152
G1 X120.593 Y203.758 F152
G1 X120.537 Y203.811 F152
G1 X120.531 Y203.815 F152
G1 X120.48 Y203.864 F152
G1 X120.471 Y203.873 F152
G1 X120.422 Y203.917 F152
G1 X120.409 Y203.93 F152
G1 X120.365 Y203.968 F152
G1 X120.343 Y203.987 F152
G1 X120.308 Y204.017 F152
G1 X120.275 Y204.045 F152
G1 X120.25 Y204.064 F152
G1 X120.206 Y204.102 F152
G1 X120.193 Y204.113 F152
G1 X120.138 Y204.159 F152
G1 X120.136 Y204.161 F152
G1 X120.079 Y204.207 F152
G1 X120.065 Y204.216 F152
G1 X120.021 Y204.25 F152
G1 X119.99 Y204.274 F152
G1 X119.964 Y204.293 F152
G1 X119.849 Y204.379 F152
G1 X119.839 Y204.388 F152
G1 X119.792 Y204.421 F152
G1 X119.757 Y204.446 F152
G1 X119.735 Y204.461 F152
G1 X119.678 Y204.499 F152
G1 X119.673 Y204.503 F152
G1 X119.62 Y204.539 F152
G1 X119.589 Y204.56 F152
G1 X119.563 Y204.577 F152
G1 X119.503 Y204.617 F152
G1 X119.448 Y204.65 F152
G1 X119.409 Y204.675 F152
G1 X119.391 Y204.685 F152
G1 X119.334 Y204.72 F152
G1 X119.277 Y204.754 F152
G1 X119.22 Y204.789 F152
G1 X119.219 F152
G1 X119.162 Y204.821 F152
G1 X119.113 Y204.846 F152
G1 X119.105 Y204.851 F152
G1 X118.933 Y204.942 F152
G1 X118.893 Y204.961 F152
G1 X118.818 Y204.995 F152
G1 X118.769 Y205.018 F152
G1 X118.761 Y205.022 F152
G1 X118.704 Y205.048 F152
G1 X118.646 Y205.075 F152
G1 X118.644 Y205.076 F152
G1 X118.589 Y205.097 F152
G1 X118.532 Y205.119 F152
G1 X118.497 Y205.133 F152
G1 X118.475 Y205.141 F152
G1 X118.36 Y205.186 F152
G1 X118.347 Y205.19 F152
G1 X118.303 Y205.204 F152
G1 X118.245 Y205.222 F152
G1 X118.188 Y205.24 F152
G1 X118.167 Y205.247 F152
G1 X118.131 Y205.258 F152
G1 X118.074 Y205.276 F152
G1 X118.016 Y205.291 F152
G1 X117.964 Y205.305 F152
G1 X117.959 Y205.306 F152
G1 X117.902 Y205.321 F152
G1 X117.787 Y205.349 F152
G1 X117.732 Y205.362 F152
G1 X117.73 F152
G1 X117.615 Y205.387 F152
G1 X117.558 Y205.399 F152
G1 X117.501 Y205.411 F152
G1 X117.459 Y205.419 F152
G1 X117.443 Y205.422 F152
G1 X117.214 Y205.465 F152
G1 X117.157 Y205.475 F152
G1 X117.15 Y205.477 F152
G1 X117.1 Y205.485 F152
G1 X117.042 Y205.495 F152
G1 X116.928 Y205.515 F152
G1 X116.871 Y205.526 F152
G1 X116.825 Y205.534 F152
G1 X116.813 Y205.536 F152
G1 X116.756 Y205.545 F152
G1 X116.699 Y205.556 F152
G1 X116.641 Y205.566 F152
G1 X116.584 Y205.577 F152
G1 X116.527 Y205.587 F152
G1 X116.504 Y205.591 F152
G1 X116.47 Y205.597 F152
G1 X116.24 Y205.64 F152
G1 X116.202 Y205.648 F152
G1 X116.126 Y205.663 F152
G1 X115.954 Y205.698 F152
G1 X115.916 Y205.706 F152
G1 X115.897 Y205.709 F152
G1 X115.725 Y205.744 F152
G1 X115.668 Y205.757 F152
G1 X115.64 Y205.763 F152
G1 X115.61 Y205.769 F152
G1 X115.381 Y205.819 F152
G1 X115.379 Y205.82 F152
G1 X115.324 Y205.832 F152
G1 X115.267 Y205.844 F152
G1 X115.152 Y205.871 F152
G1 X115.127 Y205.877 F152
G1 X115.095 Y205.885 F152
G1 X114.751 Y205.965 F152
G1 X114.694 Y205.979 F152
G1 X114.643 Y205.992 F152
G1 X114.636 Y205.993 F152
G1 X114.579 Y206.007 F152
G1 X114.522 Y206.021 F152
G1 X114.465 Y206.035 F152
G1 X114.407 Y206.048 F152
G1 X114.406 Y206.049 F152
G1 X114.35 Y206.063 F152
G1 X114.178 Y206.106 F152
G1 X114.175 Y206.107 F152
G1 X114.121 Y206.12 F152
G1 X113.72 Y206.22 F152
G1 X113.718 Y206.221 F152
G1 X113.663 Y206.235 F152
G1 X113.605 Y206.249 F152
G1 X113.548 Y206.264 F152
G1 X113.492 Y206.278 F152
G1 X113.491 F152
G1 X113.319 Y206.321 F152
G1 X113.266 Y206.336 F152
G1 X113.262 Y206.337 F152
G1 X113.147 Y206.365 F152
G1 X113.09 Y206.38 F152
G1 X113.041 Y206.393 F152
G1 X113.032 Y206.395 F152
G1 X112.975 Y206.409 F152
G1 X112.918 Y206.424 F152
G1 X112.861 Y206.439 F152
G1 X112.817 Y206.45 F152
G1 X112.803 Y206.453 F152
G1 X112.746 Y206.468 F152
G1 X112.631 Y206.497 F152
G1 X112.592 Y206.508 F152
G1 X112.46 Y206.541 F152
G1 X112.402 Y206.556 F152
G1 X112.367 Y206.565 F152
G1 X112.345 Y206.57 F152
G1 X112.288 Y206.584 F152
G1 X112.23 Y206.6 F152
G1 X112.173 Y206.614 F152
G1 X112.144 Y206.622 F152
G1 X112.059 Y206.644 F152
G1 X112.001 Y206.659 F152
G1 X111.944 Y206.673 F152
G1 X111.923 Y206.679 F152
G1 X111.829 Y206.703 F152
G1 X111.772 Y206.718 F152
G1 X111.715 Y206.732 F152
G1 X111.701 Y206.737 F152
G1 X111.6 Y206.762 F152
G1 X111.543 Y206.777 F152
G1 X111.486 Y206.791 F152
G1 X111.479 Y206.794 F152
G1 X111.371 Y206.821 F152
G1 X111.142 Y206.882 F152
G1 X111.085 Y206.898 F152
G1 X111.045 Y206.908 F152
G1 X111.027 Y206.913 F152
G1 X110.97 Y206.928 F152
G1 X110.913 Y206.944 F152
G1 X110.856 Y206.959 F152
G1 X110.833 Y206.966 F152
G1 X110.798 Y206.975 F152
G1 X110.741 Y206.991 F152
G1 X110.626 Y207.021 F152
G1 X110.622 Y207.023 F152
G1 X110.569 Y207.037 F152
G1 X110.455 Y207.068 F152
G1 X110.411 Y207.08 F152
G1 X110.283 Y207.114 F152
G1 X110.225 Y207.13 F152
G1 X110.199 Y207.138 F152
G1 X110.168 Y207.147 F152
G1 X110.111 Y207.164 F152
G1 X110.054 Y207.18 F152
G1 X110.003 Y207.195 F152
G1 X109.996 Y207.197 F152
G1 X109.939 Y207.214 F152
G1 X109.882 Y207.23 F152
G1 X109.824 Y207.247 F152
G1 X109.807 Y207.252 F152
G1 X109.767 Y207.264 F152
G1 X109.71 Y207.28 F152
G1 X109.653 Y207.298 F152
G1 X109.615 Y207.309 F152
G1 X109.595 Y207.316 F152
G1 X109.481 Y207.351 F152
G1 X109.432 Y207.367 F152
G1 X109.423 Y207.369 F152
G1 X109.252 Y207.423 F152
G1 X109.25 Y207.424 F152
G1 X109.194 Y207.441 F152
G1 X109.137 Y207.46 F152
G1 X109.074 Y207.481 F152
G1 X109.022 Y207.498 F152
G1 X108.908 Y207.538 F152
G1 X108.907 Y207.539 F152
G1 X108.851 Y207.557 F152
G1 X108.621 Y207.636 F152
G1 X108.578 Y207.653 F152
G1 X108.45 Y207.701 F152
G1 X108.425 Y207.71 F152
G1 X108.392 Y207.723 F152
G1 X108.278 Y207.766 F152
G1 X108.273 Y207.768 F152
G1 X108.22 Y207.787 F152
G1 X108.163 Y207.809 F152
G1 X108.124 Y207.825 F152
G1 X108.106 Y207.832 F152
G1 X108.049 Y207.856 F152
G1 X107.991 Y207.88 F152
G1 X107.987 Y207.882 F152
G1 X107.934 Y207.904 F152
G1 X107.849 Y207.939 F152
G1 X107.819 Y207.951 F152
G1 X107.762 Y207.975 F152
G1 X107.712 Y207.997 F152
G1 X107.705 Y207.999 F152
G1 X107.648 Y208.024 F152
G1 X107.59 Y208.05 F152
G1 X107.583 Y208.054 F152
G1 X107.533 Y208.077 F152
G1 X107.476 Y208.103 F152
G1 X107.46 Y208.111 F152
G1 X107.418 Y208.13 F152
G1 X107.361 Y208.157 F152
G1 X107.336 Y208.169 F152
G1 X107.304 Y208.183 F152
G1 X107.247 Y208.21 F152
G1 X107.213 Y208.226 F152
G1 X107.189 Y208.237 F152
G1 X107.099 Y208.283 F152
G1 X107.017 Y208.325 F152
G1 X106.988 Y208.34 F152
G1 X106.96 Y208.354 F152
G1 X106.903 Y208.383 F152
G1 X106.876 Y208.398 F152
G1 X106.846 Y208.413 F152
G1 X106.764 Y208.455 F152
G1 X106.731 Y208.472 F152
G1 X106.674 Y208.504 F152
G1 X106.66 Y208.512 F152
G1 X106.616 Y208.537 F152
G1 X106.502 Y208.602 F152
G1 X106.457 Y208.627 F152
G1 X106.445 Y208.634 F152
G1 X106.387 Y208.666 F152
G1 X106.356 Y208.684 F152
G1 X106.33 Y208.698 F152
G1 X106.273 Y208.732 F152
G1 X106.257 Y208.741 F152
G1 X106.215 Y208.767 F152
G1 X106.164 Y208.799 F152
G1 X106.158 Y208.802 F152
G1 X106.101 Y208.837 F152
G1 X106.07 Y208.856 F152
G1 X106.044 Y208.872 F152
G1 X105.986 Y208.907 F152
G1 X105.976 Y208.913 F152
G1 X105.929 Y208.943 F152
G1 X105.883 Y208.97 F152
G1 X105.872 Y208.978 F152
G1 X105.814 Y209.015 F152
G1 X105.796 Y209.028 F152
G1 X105.757 Y209.053 F152
G1 X105.708 Y209.085 F152
G1 X105.7 Y209.09 F152
G1 X105.643 Y209.128 F152
G1 X105.62 Y209.142 F152
G1 X105.585 Y209.166 F152
G1 X105.533 Y209.2 F152
G1 X105.528 Y209.202 F152
G1 X105.471 Y209.24 F152
G1 X105.127 Y209.482 F152
G1 X105.121 Y209.486 F152
G1 X105.07 Y209.522 F152
G1 X105.039 Y209.543 F152
G1 X105.012 Y209.562 F152
G1 X104.958 Y209.601 F152
G1 X104.955 Y209.602 F152
G1 X104.898 Y209.643 F152
G1 X104.876 Y209.658 F152
G1 X104.841 Y209.683 F152
G1 X104.795 Y209.715 F152
G1 X104.783 Y209.723 F152
G1 X104.726 Y209.763 F152
G1 X104.713 Y209.772 F152
G1 X104.669 Y209.804 F152
G1 X104.633 Y209.83 F152
G1 X104.611 Y209.846 F152
G1 X104.555 Y209.887 F152
G1 X104.554 Y209.888 F152
G1 X104.497 Y209.93 F152
G1 X104.477 Y209.944 F152
G1 X104.44 Y209.972 F152
G1 X104.325 Y210.056 F152
G1 X104.322 Y210.059 F152
G1 X104.268 Y210.098 F152
G1 X104.244 Y210.116 F152
G1 X104.153 Y210.183 F152
G1 X104.096 Y210.225 F152
G1 X104.089 Y210.231 F152
G1 X104.039 Y210.267 F152
G1 X104.011 Y210.288 F152
G1 X103.981 Y210.309 F152
G1 X103.933 Y210.345 F152
G1 X103.924 Y210.351 F152
G1 X103.867 Y210.393 F152
G1 X103.855 Y210.402 F152
G1 X103.809 Y210.436 F152
G1 X103.752 Y210.479 F152
G1 X103.7 Y210.517 F152
G1 X103.695 Y210.521 F152
G1 X103.638 Y210.563 F152
G1 X103.622 Y210.574 F152
G1 X103.58 Y210.605 F152
G1 X103.523 Y210.648 F152
G1 X103.467 Y210.689 F152
G1 X103.466 Y210.69 F152
G1 X103.408 Y210.732 F152
G1 X103.39 Y210.746 F152
G1 X103.351 Y210.774 F152
G1 X103.294 Y210.817 F152
G1 X103.237 Y210.859 F152
G1 X103.234 Y210.861 F152
G1 X103.179 Y210.901 F152
G1 X103.156 Y210.918 F152
G1 X103.122 Y210.943 F152
G1 X103.079 Y210.975 F152
G1 X103.065 Y210.985 F152
G1 X103.007 Y211.027 F152
G1 X103 Y211.033 F152
G1 X102.95 Y211.068 F152
G1 X102.921 Y211.09 F152
G1 X102.893 Y211.11 F152
G1 X102.778 Y211.193 F152
G1 X102.763 Y211.204 F152
G1 X102.721 Y211.235 F152
G1 X102.684 Y211.262 F152
G1 X102.664 Y211.276 F152
G1 X102.606 Y211.318 F152
G1 X102.605 Y211.319 F152
G1 X102.549 Y211.359 F152
G1 X102.526 Y211.376 F152
G1 X102.492 Y211.401 F152
G1 X102.377 Y211.484 F152
G1 X102.368 Y211.491 F152
G1 X102.32 Y211.526 F152
G1 X102.289 Y211.548 F152
G1 X102.263 Y211.567 F152
G1 X102.209 Y211.605 F152
G1 X102.205 Y211.608 F152
G1 X102.148 Y211.649 F152
G1 X102.129 Y211.663 F152
G1 X102.091 Y211.689 F152
G1 X102.049 Y211.72 F152
G1 X102.034 Y211.731 F152
G1 X101.976 Y211.772 F152
G1 X101.968 Y211.777 F152
G1 X101.919 Y211.812 F152
G1 X101.889 Y211.834 F152
G1 X101.862 Y211.853 F152
G1 X101.807 Y211.892 F152
G1 X101.804 Y211.893 F152
G1 X101.747 Y211.935 F152
G1 X101.727 Y211.949 F152
G1 X101.69 Y211.975 F152
G1 X101.645 Y212.006 F152
G1 X101.633 Y212.015 F152
G1 X101.575 Y212.055 F152
G1 X101.565 Y212.064 F152
G1 X101.518 Y212.097 F152
G1 X101.483 Y212.121 F152
G1 X101.461 Y212.137 F152
G1 X101.403 Y212.176 F152
G1 X101.402 Y212.178 F152
G1 X101.346 Y212.217 F152
G1 X101.32 Y212.235 F152
G1 X101.289 Y212.257 F152
G1 X101.238 Y212.293 F152
G1 X101.232 Y212.297 F152
G1 X101.117 Y212.378 F152
G1 X101.002 Y212.456 F152
G1 X100.992 Y212.464 F152
G1 X100.945 Y212.497 F152
G1 X100.908 Y212.522 F152
G1 X100.888 Y212.536 F152
G1 X100.831 Y212.575 F152
G1 X100.826 Y212.579 F152
G1 X100.773 Y212.616 F152
G1 X100.743 Y212.636 F152
G1 X100.716 Y212.654 F152
G1 X100.601 Y212.733 F152
G1 X100.575 Y212.751 F152
G1 X100.544 Y212.771 F152
G1 X100.49 Y212.808 F152
G1 X100.487 Y212.811 F152
G1 X100.43 Y212.849 F152
G1 X100.406 Y212.865 F152
G1 X100.372 Y212.888 F152
G1 X100.315 Y212.926 F152
G1 X100.258 Y212.964 F152
G1 X100.234 Y212.98 F152
G1 X100.2 Y213.002 F152
G1 X100.148 Y213.037 F152
G1 X100.143 Y213.04 F152
G1 X100.086 Y213.078 F152
G1 X100.06 Y213.095 F152
G1 X100.029 Y213.114 F152
G1 X99.971 Y213.151 F152
G1 X99.97 Y213.152 F152
G1 X99.914 Y213.188 F152
G1 X99.88 Y213.209 F152
G1 X99.857 Y213.223 F152
G1 X99.799 Y213.26 F152
G1 X99.79 Y213.266 F152
G1 X99.742 Y213.295 F152
G1 X99.695 Y213.324 F152
G1 X99.685 Y213.329 F152
G1 X99.628 Y213.363 F152
G1 X99.599 Y213.381 F152
G1 X99.513 Y213.432 F152
G1 X99.502 Y213.438 F152
G1 X99.456 Y213.464 F152
G1 X99.398 Y213.495 F152
G1 X99.341 Y213.526 F152
G1 X99.292 Y213.553 F152
G1 X99.284 Y213.557 F152
G1 X99.227 Y213.588 F152
G1 X99.184 Y213.61 F152
G1 X99.169 Y213.616 F152
G1 X99.112 Y213.644 F152
G1 X99.063 Y213.667 F152
G1 X99.055 Y213.671 F152
G1 X98.997 Y213.699 F152
G1 X98.943 Y213.725 F152
G1 X98.94 F152
G1 X98.826 Y213.772 F152
G1 X98.802 Y213.782 F152
G1 X98.768 Y213.795 F152
G1 X98.711 Y213.819 F152
G1 X98.66 Y213.839 F152
G1 X98.654 Y213.841 F152
G1 X98.596 Y213.86 F152
G1 X98.539 Y213.879 F152
G1 X98.488 Y213.896 F152
G1 X98.482 Y213.898 F152
G1 X98.367 Y213.936 F152
G1 X98.31 Y213.951 F152
G1 X98.3 Y213.954 F152
G1 X98.138 Y213.997 F152
G1 X98.084 Y214.011 F152
G1 X98.081 Y214.012 F152
G1 X98.024 Y214.023 F152
G1 X97.966 Y214.036 F152
G1 X97.852 Y214.059 F152
G1 X97.812 Y214.068 F152
G1 X97.794 Y214.072 F152
G1 X97.737 Y214.083 F152
G1 X97.68 Y214.092 F152
G1 X97.623 Y214.101 F152
G1 X97.565 Y214.111 F152
G1 X97.508 Y214.12 F152
G1 X97.477 Y214.126 F152
G1 X97.451 Y214.129 F152
G1 X97.393 Y214.138 F152
G1 X97.279 Y214.152 F152
G1 X97.222 Y214.16 F152
G1 X97.05 Y214.182 F152
G1 X97.045 Y214.183 F152
G1 X96.992 Y214.187 F152
G1 X96.763 Y214.209 F152
G1 X96.706 Y214.213 F152
G1 X96.477 Y214.235 F152
G1 X96.422 Y214.24 F152
G1 X96.42 F152
G1 X96.305 Y214.251 F152
G1 X95.618 Y214.294 F152
G1 X95.568 Y214.297 F152
G1 X95.56 F152
G1 X95.503 Y214.301 F152
G1 X95.446 Y214.304 F152
G1 X95.388 Y214.305 F152
G1 X95.217 Y214.313 F152
G1 X95.045 Y214.319 F152
G1 X94.987 Y214.32 F152
G1 X94.93 Y214.322 F152
G1 X94.873 F152
G1 X94.816 Y214.324 F152
G1 X94.758 Y214.325 F152
G1 X94.472 F152
G1 X94.128 Y214.314 F152
G1 X94.014 Y214.307 F152
G1 X93.956 Y214.303 F152
G1 X93.899 Y214.299 F152
G1 X93.863 Y214.297 F152
G1 X93.842 Y214.296 F152
G1 X93.67 Y214.279 F152
G1 X93.613 Y214.273 F152
G1 X93.555 Y214.268 F152
G1 X93.498 Y214.262 F152
G1 X93.441 Y214.256 F152
G1 X93.326 Y214.244 F152
G1 X93.289 Y214.24 F152
G1 X93.269 Y214.238 F152
G1 X93.212 Y214.233 F152
G1 X92.982 Y214.215 F152
G1 X92.925 F152
G1 X92.811 Y214.213 F152
G1 X92.696 F152
G1 X92.639 Y214.216 F152
G1 X92.467 Y214.235 F152
G1 X92.423 Y214.24 F152
G1 X92.41 Y214.241 F152
G1 X92.352 Y214.248 F152
G1 X92.295 Y214.258 F152
G1 X92.238 Y214.271 F152
G1 X92.18 Y214.284 F152
G1 X92.126 Y214.297 F152
G1 X92.123 Y214.298 F152
G1 X92.009 Y214.332 F152
G1 X91.951 Y214.351 F152
G1 X91.941 Y214.355 F152
G1 X91.894 Y214.373 F152
G1 X91.837 Y214.394 F152
G1 X91.792 Y214.412 F152
G1 X91.779 Y214.416 F152
G1 X91.665 Y214.468 F152
G1 X91.664 Y214.469 F152
G1 X91.608 Y214.495 F152
G1 X91.493 Y214.556 F152
G1 X91.443 Y214.584 F152
G1 X91.436 Y214.587 F152
G1 X91.378 Y214.619 F152
G1 X91.337 Y214.641 F152
G1 X91.321 Y214.65 F152
G1 X91.264 Y214.683 F152
G1 X91.149 Y214.753 F152
G1 X91.146 Y214.756 F152
G1 X91.092 Y214.789 F152
G1 X91.053 Y214.813 F152
G1 X91.035 Y214.824 F152
G1 X90.977 Y214.859 F152
G1 X90.96 Y214.87 F152
G1 X90.92 Y214.896 F152
G1 X90.871 Y214.927 F152
G1 X90.863 Y214.932 F152
G1 X90.748 Y215.005 F152
G1 X90.691 Y215.041 F152
G1 X90.69 Y215.042 F152
G1 X90.634 Y215.077 F152
G1 X90.405 Y215.216 F152
G1 X90.347 Y215.249 F152
G1 X90.307 Y215.271 F152
G1 X90.29 Y215.28 F152
G1 X90.233 Y215.312 F152
G1 X90.098 Y215.386 F152
G1 X90.061 Y215.404 F152
G1 X90.004 Y215.43 F152
G1 X89.978 Y215.443 F152
G1 X89.946 Y215.457 F152
G1 X89.889 Y215.484 F152
G1 X89.856 Y215.5 F152
G1 X89.832 Y215.512 F152
G1 X89.774 Y215.536 F152
G1 X89.719 Y215.557 F152
G1 X89.717 Y215.558 F152
G1 X89.66 Y215.581 F152
G1 X89.603 Y215.602 F152
G1 X89.572 Y215.615 F152
G1 X89.545 Y215.625 F152
G1 X89.488 Y215.645 F152
G1 X89.259 Y215.717 F152
G1 X89.218 Y215.729 F152
G1 X89.202 Y215.733 F152
G1 X89.087 Y215.762 F152
G1 X89.03 Y215.775 F152
G1 X88.985 Y215.787 F152
G1 X88.972 Y215.789 F152
G1 X88.915 Y215.803 F152
G1 X88.858 Y215.814 F152
G1 X88.743 Y215.836 F152
G1 X88.705 Y215.844 F152
G1 X88.629 Y215.858 F152
G1 X88.4 Y215.894 F152
G1 X88.35 Y215.901 F152
G1 X88.342 Y215.902 F152
G1 X88.285 Y215.91 F152
G1 X88.228 Y215.917 F152
G1 X88.17 Y215.925 F152
G1 X88.113 Y215.932 F152
G1 X88.056 Y215.939 F152
G1 X87.941 Y215.951 F152
G1 X87.884 Y215.957 F152
G1 X87.874 Y215.958 F152
G1 X87.827 Y215.963 F152
G1 X87.769 Y215.967 F152
G1 X87.483 Y215.985 F152
G1 X87.426 Y215.988 F152
G1 X87.368 Y215.99 F152
G1 X87.254 F152
G1 X87.197 Y215.988 F152
G1 X87.139 Y215.985 F152
G1 X87.082 Y215.983 F152
G1 X87.025 Y215.979 F152
G1 X86.853 Y215.963 F152
G1 X86.817 Y215.958 F152
G1 X86.796 Y215.955 F152
G1 X86.681 Y215.939 F152
G1 X86.624 Y215.93 F152
G1 X86.566 Y215.918 F152
G1 X86.509 Y215.907 F152
G1 X86.478 Y215.901 F152
G1 X86.452 Y215.896 F152
G1 X86.395 Y215.884 F152
G1 X86.28 Y215.855 F152
G1 X86.233 Y215.844 F152
G1 X86.223 Y215.841 F152
G1 X86.165 Y215.827 F152
G1 X86.108 Y215.809 F152
G1 X86.033 Y215.787 F152
G1 X85.994 Y215.774 F152
G1 X85.936 Y215.757 F152
G1 X85.879 Y215.736 F152
G1 X85.86 Y215.729 F152
G1 X85.822 Y215.715 F152
G1 X85.764 Y215.694 F152
G1 X85.707 Y215.673 F152
G1 X85.704 Y215.672 F152
G1 X85.65 Y215.648 F152
G1 X85.593 Y215.623 F152
G1 X85.574 Y215.615 F152
G1 X85.535 Y215.598 F152
G1 X85.478 Y215.571 F152
G1 X85.451 Y215.557 F152
G1 X85.363 Y215.511 F152
G1 X85.343 Y215.5 F152
G1 X85.306 Y215.48 F152
G1 X85.244 Y215.443 F152
G1 X85.192 Y215.409 F152
G1 X85.155 Y215.386 F152
G1 X85.134 Y215.372 F152
G1 X85.077 Y215.329 F152
G1 X85.076 Y215.328 F152
G1 X85.02 Y215.285 F152
G1 X85.002 Y215.271 F152
G1 X84.962 Y215.236 F152
G1 X84.939 Y215.214 F152
G1 X84.905 Y215.182 F152
G1 X84.879 Y215.157 F152
G1 X84.848 Y215.122 F152
G1 X84.791 Y215.054 F152
G1 X84.782 Y215.042 F152
G1 X84.742 Y214.985 F152
G1 X84.733 Y214.972 F152
G1 X84.704 Y214.927 F152
G1 X84.676 Y214.877 F152
G1 X84.672 Y214.87 F152
G1 X84.643 Y214.813 F152
G1 X84.619 Y214.76 F152
G1 X84.594 Y214.698 F152
G1 X84.572 Y214.641 F152
G1 X84.561 Y214.608 F152
G1 X84.554 Y214.584 F152
G1 X84.536 Y214.526 F152
G1 X84.521 Y214.469 F152
G1 X84.508 Y214.412 F152
G1 X84.504 Y214.4 F152
G1 X84.493 Y214.355 F152
G1 X84.483 Y214.297 F152
G1 X84.473 Y214.24 F152
G1 X84.462 Y214.183 F152
G1 X84.456 Y214.126 F152
G1 X84.447 Y214.054 F152
G1 X84.442 Y214.011 F152
G1 X84.435 Y213.954 F152
G1 X84.429 Y213.896 F152
G1 X84.422 Y213.839 F152
G1 X84.418 Y213.782 F152
G1 X84.405 Y213.495 F152
G1 X84.403 Y213.438 F152
G1 X84.405 Y213.324 F152
G1 X84.407 Y213.266 F152
G1 X84.414 Y213.152 F152
G1 X84.42 Y213.095 F152
G1 X84.427 Y213.037 F152
G1 X84.435 Y212.98 F152
G1 X84.447 Y212.923 F152
G1 X84.459 Y212.865 F152
G1 X84.474 Y212.808 F152
G1 X84.492 Y212.751 F152
G1 X84.504 Y212.707 F152
G1 X84.509 Y212.694 F152
G1 X84.531 Y212.636 F152
G1 X84.552 Y212.579 F152
G1 X84.561 Y212.556 F152
G1 X84.577 Y212.522 F152
G1 X84.603 Y212.464 F152
G1 X84.619 Y212.428 F152
G1 X84.629 Y212.407 F152
G1 X84.654 Y212.35 F152
G1 X84.676 Y212.301 F152
G1 X84.68 Y212.293 F152
G1 X84.706 Y212.235 F152
G1 X84.731 Y212.178 F152
G1 X84.733 Y212.171 F152
G1 X84.755 Y212.121 F152
G1 X84.791 Y212.036 F152
G1 X84.803 Y212.006 F152
G1 X84.825 Y211.949 F152
G1 X84.844 Y211.892 F152
G1 X84.848 Y211.88 F152
G1 X84.864 Y211.834 F152
G1 X84.884 Y211.777 F152
G1 X84.902 Y211.72 F152
G1 X84.905 Y211.704 F152
G1 X84.915 Y211.663 F152
G1 X84.953 Y211.491 F152
G1 X84.962 Y211.436 F152
G1 X84.963 Y211.433 F152
G1 X84.97 Y211.376 F152
G1 X84.983 Y211.204 F152
G1 X84.987 Y211.147 F152
G1 Y211.09 F152
G1 X84.984 Y211.033 F152
G1 X84.973 Y210.861 F152
G1 X84.968 Y210.803 F152
G1 X84.962 Y210.771 F152
G1 X84.958 Y210.746 F152
G1 X84.915 Y210.517 F152
G1 X84.901 Y210.46 F152
G1 X84.852 Y210.288 F152
G1 X84.848 Y210.274 F152
G1 X84.836 Y210.231 F152
G1 X84.797 Y210.116 F152
G1 X84.791 Y210.098 F152
G1 X84.777 Y210.059 F152
G1 X84.757 Y210.001 F152
G1 X84.733 Y209.934 F152
G1 X84.715 Y209.887 F152
G1 X84.695 Y209.83 F152
G1 X84.676 Y209.781 F152
G1 X84.673 Y209.772 F152
G1 X84.63 Y209.658 F152
G1 X84.619 Y209.628 F152
G1 X84.609 Y209.601 F152
G1 X84.566 Y209.486 F152
G1 X84.561 Y209.474 F152
G1 X84.546 Y209.429 F152
G1 X84.526 Y209.371 F152
G1 X84.506 Y209.314 F152
G1 X84.504 Y209.31 F152
G1 X84.487 Y209.257 F152
G1 X84.469 Y209.2 F152
G1 X84.452 Y209.142 F152
G1 X84.447 Y209.125 F152
G1 X84.435 Y209.085 F152
G1 X84.42 Y209.028 F152
G1 X84.39 Y208.906 F152
G1 X84.378 Y208.856 F152
G1 X84.356 Y208.741 F152
G1 X84.347 Y208.684 F152
G1 X84.338 Y208.627 F152
G1 X84.332 Y208.591 F152
G1 X84.322 Y208.512 F152
G1 X84.314 Y208.455 F152
G1 X84.309 Y208.398 F152
G1 X84.305 Y208.34 F152
G1 X84.299 Y208.283 F152
G1 X84.295 Y208.226 F152
G1 X84.291 Y208.169 F152
G1 X84.286 Y208.054 F152
G1 X84.282 Y207.997 F152
G1 X84.277 Y207.825 F152
G1 X84.276 Y207.768 F152
G1 X84.275 Y207.767 F152
G1 X84.271 Y207.539 F152
G1 Y207.481 F152
G1 Y207.424 F152
G1 Y207.309 F152
G1 X84.27 Y207.252 F152
G1 Y207.08 F152
G1 X84.271 Y207.023 F152
G1 Y206.966 F152
G1 Y206.908 F152
G1 Y206.851 F152
G1 X84.273 Y206.737 F152
G1 Y206.679 F152
G1 X84.275 Y206.565 F152
G1 Y206.561 F152
G1 X84.277 Y206.45 F152
G1 X84.279 Y206.393 F152
G1 Y206.336 F152
G1 X84.283 Y206.221 F152
G1 X84.284 Y206.164 F152
G1 X84.291 Y205.935 F152
G1 X84.294 Y205.877 F152
G1 X84.296 Y205.82 F152
G1 X84.298 Y205.763 F152
G1 X84.3 Y205.706 F152
G1 X84.303 Y205.648 F152
G1 X84.306 Y205.591 F152
G1 X84.312 Y205.477 F152
G1 X84.315 Y205.419 F152
G1 X84.318 Y205.362 F152
G1 X84.325 Y205.247 F152
G1 X84.33 Y205.19 F152
G1 X84.332 Y205.146 F152
G1 X84.333 Y205.133 F152
G1 X84.342 Y205.018 F152
G1 X84.346 Y204.961 F152
G1 X84.35 Y204.904 F152
G1 X84.377 Y204.617 F152
G1 X84.39 Y204.503 F152
G1 Y204.497 F152
G1 X84.396 Y204.446 F152
G1 X84.408 Y204.331 F152
G1 X84.423 Y204.216 F152
G1 X84.439 Y204.102 F152
G1 X84.446 Y204.045 F152
G1 X84.447 Y204.037 F152
G1 X84.454 Y203.987 F152
G1 X84.462 Y203.93 F152
G1 X84.48 Y203.815 F152
G1 X84.49 Y203.758 F152
G1 X84.499 Y203.701 F152
G1 X84.504 Y203.665 F152
G1 X84.508 Y203.644 F152
G1 X84.518 Y203.586 F152
G1 X84.561 Y203.357 F152
G1 Y203.35 F152
G1 X84.571 Y203.3 F152
G1 X84.582 Y203.243 F152
G1 X84.607 Y203.128 F152
G1 X84.619 Y203.073 F152
G1 X84.62 Y203.071 F152
G1 X84.657 Y202.899 F152
G1 X84.671 Y202.842 F152
G1 X84.676 Y202.819 F152
G1 X84.685 Y202.784 F152
G1 X84.714 Y202.67 F152
G1 X84.727 Y202.613 F152
G1 X84.741 Y202.555 F152
G1 X84.757 Y202.498 F152
G1 X84.789 Y202.383 F152
G1 X84.791 Y202.376 F152
G1 X84.805 Y202.326 F152
G1 X84.821 Y202.269 F152
G1 X84.836 Y202.212 F152
G1 X84.848 Y202.171 F152
G1 X84.889 Y202.04 F152
G1 X84.905 Y201.986 F152
G1 X84.907 Y201.983 F152
G1 X84.924 Y201.925 F152
G1 X84.942 Y201.868 F152
G1 X84.961 Y201.811 F152
G1 X84.962 Y201.804 F152
G1 X84.979 Y201.753 F152
G1 X85.019 Y201.639 F152
G1 X85.02 Y201.635 F152
G1 X85.038 Y201.582 F152
G1 X85.057 Y201.524 F152
G1 X85.077 Y201.467 F152
G1 X85.12 Y201.352 F152
G1 X85.134 Y201.313 F152
G1 X85.141 Y201.295 F152
G1 X85.162 Y201.238 F152
G1 X85.205 Y201.123 F152
G1 X85.227 Y201.066 F152
G1 X85.297 Y200.894 F152
G1 X85.306 Y200.871 F152
G1 X85.32 Y200.837 F152
G1 X85.343 Y200.78 F152
G1 X85.363 Y200.73 F152
G1 X85.367 Y200.722 F152
G1 X85.392 Y200.665 F152
G1 X85.421 Y200.597 F152
G1 X85.441 Y200.551 F152
G1 X85.466 Y200.493 F152
G1 X85.478 Y200.465 F152
G1 X85.516 Y200.379 F152
G1 X85.569 Y200.264 F152
G1 X85.593 Y200.212 F152
G1 X85.595 Y200.207 F152
G1 X85.622 Y200.15 F152
G1 X85.648 Y200.092 F152
G1 X85.65 Y200.089 F152
G1 X85.675 Y200.035 F152
G1 X85.704 Y199.978 F152
G1 X85.707 Y199.97 F152
G1 X85.732 Y199.921 F152
G1 X85.789 Y199.806 F152
G1 X85.819 Y199.749 F152
G1 X85.822 Y199.742 F152
G1 X85.848 Y199.691 F152
G1 X85.934 Y199.52 F152
G1 X85.936 Y199.515 F152
G1 X85.963 Y199.462 F152
G1 X85.992 Y199.405 F152
G1 X85.994 Y199.401 F152
G1 X86.02 Y199.348 F152
G1 X86.051 Y199.289 F152
G1 X86.082 Y199.233 F152
G1 X86.108 Y199.185 F152
G1 X86.114 Y199.176 F152
G1 X86.165 Y199.081 F152
G1 X86.177 Y199.061 F152
G1 X86.208 Y199.004 F152
G1 X86.223 Y198.978 F152
G1 X86.24 Y198.947 F152
G1 X86.272 Y198.89 F152
G1 X86.28 Y198.874 F152
G1 X86.303 Y198.832 F152
G1 X86.335 Y198.775 F152
G1 X86.337 Y198.771 F152
G1 X86.367 Y198.718 F152
G1 X86.395 Y198.667 F152
G1 X86.43 Y198.603 F152
G1 X86.452 Y198.565 F152
G1 X86.463 Y198.546 F152
G1 X86.497 Y198.489 F152
G1 X86.509 Y198.468 F152
G1 X86.532 Y198.431 F152
G1 X86.566 Y198.374 F152
G1 Y198.372 F152
G1 X86.6 Y198.317 F152
G1 X86.624 Y198.276 F152
G1 X86.634 Y198.259 F152
G1 X86.668 Y198.202 F152
G1 X86.681 Y198.179 F152
G1 X86.702 Y198.145 F152
G1 X86.77 Y198.03 F152
G1 X86.796 Y197.987 F152
G1 X86.804 Y197.973 F152
G1 X86.838 Y197.916 F152
G1 X86.853 Y197.89 F152
G1 X86.872 Y197.859 F152
G1 X86.907 Y197.801 F152
G1 X86.91 Y197.797 F152
G1 X86.967 Y197.705 F152
G1 X86.979 Y197.687 F152
G1 X87.015 Y197.629 F152
G1 X87.025 Y197.614 F152
G1 X87.051 Y197.572 F152
G1 X87.082 Y197.523 F152
G1 X87.087 Y197.515 F152
G1 X87.123 Y197.458 F152
G1 X87.139 Y197.431 F152
G1 X87.159 Y197.4 F152
G1 X87.195 Y197.343 F152
G1 X87.197 Y197.339 F152
G1 X87.231 Y197.286 F152
G1 X87.254 Y197.248 F152
G1 X87.266 Y197.228 F152
G1 X87.338 Y197.114 F152
G1 X87.368 Y197.067 F152
G1 X87.376 Y197.057 F152
G1 X87.412 Y196.999 F152
G1 X87.426 Y196.979 F152
G1 X87.45 Y196.942 F152
G1 X87.483 Y196.89 F152
G1 X87.487 Y196.885 F152
G1 X87.523 Y196.828 F152
G1 X87.561 Y196.77 F152
G1 X87.634 Y196.656 F152
G1 X87.672 Y196.598 F152
G1 X87.709 Y196.541 F152
G1 X87.746 Y196.484 F152
G1 X87.769 Y196.447 F152
G1 X87.783 Y196.427 F152
G1 X87.82 Y196.369 F152
G1 X87.827 Y196.359 F152
G1 X87.884 Y196.271 F152
G1 X87.895 Y196.255 F152
G1 X87.932 Y196.197 F152
G1 X87.941 Y196.183 F152
G1 X87.97 Y196.14 F152
G1 X87.999 Y196.095 F152
G1 X88.008 Y196.083 F152
G1 X88.044 Y196.026 F152
G1 X88.056 Y196.008 F152
G1 X88.082 Y195.968 F152
G1 X88.113 Y195.92 F152
G1 X88.119 Y195.911 F152
G1 X88.157 Y195.854 F152
G1 X88.17 Y195.832 F152
G1 X88.195 Y195.797 F152
G1 X88.228 Y195.745 F152
G1 X88.269 Y195.682 F152
G1 X88.285 Y195.657 F152
G1 X88.306 Y195.625 F152
G1 X88.342 Y195.569 F152
G1 X88.344 Y195.567 F152
G1 X88.382 Y195.51 F152
G1 X88.4 Y195.481 F152
G1 X88.456 Y195.396 F152
G1 X88.457 Y195.394 F152
G1 X88.494 Y195.338 F152
G1 X88.569 Y195.224 F152
G1 X88.571 Y195.219 F152
G1 X88.605 Y195.166 F152
G1 X88.629 Y195.132 F152
G1 X88.643 Y195.109 F152
G1 X88.681 Y195.052 F152
G1 X88.686 Y195.044 F152
G1 X88.718 Y194.995 F152
G1 X88.743 Y194.956 F152
G1 X88.755 Y194.937 F152
G1 X88.792 Y194.88 F152
G1 X88.801 Y194.866 F152
G1 X88.828 Y194.823 F152
G1 X88.858 Y194.776 F152
G1 X88.865 Y194.766 F152
G1 X88.901 Y194.708 F152
G1 X88.938 Y194.651 F152
G1 X88.972 Y194.595 F152
G1 X88.974 Y194.594 F152
G1 X89.01 Y194.536 F152
G1 X89.03 Y194.506 F152
G1 X89.047 Y194.479 F152
G1 X89.083 Y194.422 F152
G1 X89.087 Y194.416 F152
G1 X89.12 Y194.365 F152
G1 X89.144 Y194.325 F152
G1 X89.156 Y194.307 F152
G1 X89.193 Y194.25 F152
G1 X89.228 Y194.193 F152
G1 X89.259 Y194.143 F152
G1 X89.263 Y194.135 F152
G1 X89.298 Y194.078 F152
G1 X89.316 Y194.049 F152
G1 X89.333 Y194.021 F152
G1 X89.368 Y193.964 F152
G1 X89.373 Y193.956 F152
G1 X89.404 Y193.906 F152
G1 X89.431 Y193.862 F152
G1 X89.439 Y193.849 F152
G1 X89.474 Y193.792 F152
G1 X89.488 Y193.768 F152
G1 X89.509 Y193.734 F152
G1 X89.543 Y193.677 F152
G1 X89.545 Y193.674 F152
G1 X89.578 Y193.62 F152
G1 X89.603 Y193.58 F152
G1 X89.613 Y193.563 F152
G1 X89.648 Y193.505 F152
G1 X89.66 Y193.487 F152
G1 X89.682 Y193.448 F152
G1 X89.715 Y193.391 F152
G1 X89.717 Y193.388 F152
G1 X89.748 Y193.334 F152
G1 X89.774 Y193.289 F152
G1 X89.782 Y193.276 F152
G1 X89.832 Y193.189 F152
G1 X89.881 Y193.104 F152
G1 X89.889 Y193.09 F152
G1 X89.914 Y193.047 F152
G1 X89.946 Y192.991 F152
G1 X89.947 Y192.99 F152
G1 X89.98 Y192.933 F152
G1 X90.004 Y192.891 F152
G1 X90.013 Y192.875 F152
G1 X90.047 Y192.818 F152
G1 X90.061 Y192.792 F152
G1 X90.08 Y192.761 F152
G1 X90.112 Y192.703 F152
G1 X90.118 Y192.691 F152
G1 X90.142 Y192.646 F152
G1 X90.173 Y192.589 F152
G1 X90.175 Y192.584 F152
G1 X90.204 Y192.532 F152
G1 X90.233 Y192.478 F152
G1 X90.234 Y192.474 F152
G1 X90.266 Y192.417 F152
G1 X90.29 Y192.371 F152
G1 X90.296 Y192.36 F152
G1 X90.328 Y192.303 F152
G1 X90.347 Y192.265 F152
G1 X90.389 Y192.188 F152
G1 X90.405 Y192.158 F152
G1 X90.42 Y192.131 F152
G1 X90.45 Y192.073 F152
G1 X90.462 Y192.052 F152
G1 X90.482 Y192.016 F152
G1 X90.511 Y191.959 F152
G1 X90.568 Y191.844 F152
G1 X90.576 Y191.827 F152
G1 X90.597 Y191.787 F152
G1 X90.626 Y191.73 F152
G1 X90.634 Y191.713 F152
G1 X90.653 Y191.672 F152
G1 X90.739 Y191.501 F152
G1 X90.748 Y191.482 F152
G1 X90.768 Y191.443 F152
G1 X90.796 Y191.386 F152
G1 X90.853 Y191.272 F152
G1 X90.863 Y191.251 F152
G1 X90.881 Y191.214 F152
G1 X90.907 Y191.157 F152
G1 X90.934 Y191.1 F152
G1 X90.977 Y191.003 F152
G1 X91.011 Y190.928 F152
G1 X91.035 Y190.877 F152
G1 X91.038 Y190.871 F152
G1 X91.09 Y190.756 F152
G1 X91.092 Y190.752 F152
G1 X91.116 Y190.699 F152
G1 X91.143 Y190.641 F152
G1 X91.149 Y190.626 F152
G1 X91.169 Y190.584 F152
G1 X91.195 Y190.527 F152
G1 X91.207 Y190.501 F152
G1 X91.221 Y190.47 F152
G1 X91.264 Y190.368 F152
G1 X91.269 Y190.355 F152
G1 X91.318 Y190.241 F152
G1 X91.321 Y190.232 F152
G1 X91.342 Y190.183 F152
G1 X91.366 Y190.126 F152
G1 X91.378 Y190.096 F152
G1 X91.39 Y190.069 F152
G1 X91.487 Y189.84 F152
G1 X91.493 Y189.824 F152
G1 X91.511 Y189.782 F152
G1 X91.535 Y189.725 F152
G1 X91.55 Y189.685 F152
G1 X91.557 Y189.668 F152
G1 X91.602 Y189.553 F152
G1 X91.608 Y189.54 F152
G1 X91.625 Y189.496 F152
G1 X91.648 Y189.439 F152
G1 X91.665 Y189.395 F152
G1 X91.67 Y189.381 F152
G1 X91.693 Y189.324 F152
G1 X91.716 Y189.267 F152
G1 X91.722 Y189.249 F152
G1 X91.738 Y189.21 F152
G1 X91.779 Y189.104 F152
G1 X91.806 Y189.038 F152
G1 X91.828 Y188.98 F152
G1 X91.837 Y188.956 F152
G1 X91.849 Y188.923 F152
G1 X91.892 Y188.809 F152
G1 X91.894 Y188.803 F152
G1 X91.914 Y188.751 F152
G1 X92 Y188.522 F152
G1 X92.009 Y188.498 F152
G1 X92.021 Y188.465 F152
G1 X92.064 Y188.35 F152
G1 X92.066 Y188.345 F152
G1 X92.086 Y188.293 F152
G1 X92.106 Y188.236 F152
G1 X92.123 Y188.189 F152
G1 X92.128 Y188.179 F152
G1 X92.18 Y188.032 F152
G1 X92.189 Y188.007 F152
G1 X92.211 Y187.949 F152
G1 X92.231 Y187.892 F152
G1 X92.238 Y187.873 F152
G1 X92.252 Y187.835 F152
G1 X92.293 Y187.72 F152
G1 X92.295 Y187.716 F152
G1 X92.315 Y187.663 F152
G1 X92.335 Y187.606 F152
G1 X92.352 Y187.557 F152
G1 X92.356 Y187.548 F152
G1 X92.376 Y187.491 F152
G1 X92.396 Y187.434 F152
G1 X92.41 Y187.396 F152
G1 X92.417 Y187.377 F152
G1 X92.458 Y187.262 F152
G1 X92.467 Y187.235 F152
G1 X92.478 Y187.205 F152
G1 X92.519 Y187.09 F152
G1 X92.524 Y187.074 F152
G1 X92.539 Y187.033 F152
G1 X92.559 Y186.976 F152
G1 X92.58 Y186.918 F152
G1 X92.581 Y186.913 F152
G1 X92.599 Y186.861 F152
G1 X92.62 Y186.804 F152
G1 X92.639 Y186.748 F152
G1 X92.64 Y186.747 F152
G1 X92.659 Y186.689 F152
G1 X92.68 Y186.632 F152
G1 X92.696 Y186.584 F152
G1 X92.7 Y186.575 F152
G1 X92.719 Y186.517 F152
G1 X92.74 Y186.46 F152
G1 X92.753 Y186.42 F152
G1 X92.76 Y186.403 F152
G1 X92.811 Y186.254 F152
G1 X92.819 Y186.231 F152
G1 X92.837 Y186.174 F152
G1 X92.857 Y186.117 F152
G1 X92.868 Y186.083 F152
G1 X92.896 Y186.002 F152
G1 X92.914 Y185.945 F152
G1 X92.925 Y185.912 F152
G1 X92.933 Y185.887 F152
G1 X92.953 Y185.83 F152
G1 X92.972 Y185.773 F152
G1 X92.982 Y185.74 F152
G1 X92.99 Y185.716 F152
G1 X93.01 Y185.658 F152
G1 X93.028 Y185.601 F152
G1 X93.04 Y185.563 F152
G1 X93.046 Y185.544 F152
G1 X93.082 Y185.429 F152
G1 X93.097 Y185.379 F152
G1 X93.1 Y185.372 F152
G1 X93.134 Y185.257 F152
G1 X93.154 Y185.184 F152
G1 X93.167 Y185.143 F152
G1 X93.199 Y185.028 F152
G1 X93.212 Y184.979 F152
G1 X93.214 Y184.971 F152
G1 X93.243 Y184.856 F152
G1 X93.258 Y184.799 F152
G1 X93.272 Y184.742 F152
G1 X93.297 Y184.627 F152
G1 X93.309 Y184.57 F152
G1 X93.322 Y184.513 F152
G1 X93.326 Y184.49 F152
G1 X93.334 Y184.455 F152
G1 X93.344 Y184.398 F152
G1 X93.38 Y184.169 F152
G1 X93.383 Y184.144 F152
G1 X93.387 Y184.112 F152
G1 X93.403 Y183.94 F152
G1 X93.408 Y183.883 F152
G1 X93.411 Y183.825 F152
G1 X93.413 Y183.711 F152
G1 Y183.654 F152
G1 X93.414 Y183.596 F152
G1 X93.413 Y183.539 F152
G1 X93.404 Y183.424 F152
G1 X93.388 Y183.253 F152
G1 X93.383 Y183.225 F152
G1 X93.378 Y183.195 F152
G1 X93.367 Y183.138 F152
G1 X93.332 Y182.966 F152
G1 X93.326 Y182.942 F152
G1 X93.317 Y182.909 F152
G1 X93.28 Y182.794 F152
G1 X93.269 Y182.761 F152
G1 X93.262 Y182.737 F152
G1 X93.243 Y182.68 F152
G1 X93.221 Y182.623 F152
G1 X93.212 Y182.604 F152
G1 X93.194 Y182.565 F152
G1 X93.168 Y182.508 F152
G1 X93.154 Y182.48 F152
G1 X93.141 Y182.451 F152
G1 X93.114 Y182.393 F152
G1 X93.097 Y182.359 F152
G1 X93.085 Y182.336 F152
G1 X93.05 Y182.279 F152
G1 X93.04 Y182.261 F152
G1 X93.016 Y182.222 F152
G1 X92.982 Y182.168 F152
G1 X92.981 Y182.164 F152
G1 X92.946 Y182.107 F152
G1 X92.925 Y182.076 F152
G1 X92.907 Y182.05 F152
G1 X92.868 Y181.998 F152
G1 X92.864 Y181.992 F152
G1 X92.82 Y181.935 F152
G1 X92.811 Y181.922 F152
G1 X92.777 Y181.878 F152
G1 X92.753 Y181.846 F152
G1 X92.734 Y181.821 F152
G1 X92.696 Y181.777 F152
G1 X92.684 Y181.763 F152
G1 X92.639 Y181.711 F152
G1 X92.634 Y181.706 F152
G1 X92.584 Y181.649 F152
G1 X92.581 Y181.646 F152
G1 X92.533 Y181.592 F152
G1 X92.524 Y181.582 F152
G1 X92.478 Y181.534 F152
G1 X92.467 Y181.523 F152
G1 X92.422 Y181.477 F152
G1 X92.41 Y181.464 F152
G1 X92.367 Y181.42 F152
G1 X92.352 Y181.404 F152
G1 X92.31 Y181.362 F152
G1 X92.295 Y181.348 F152
G1 X92.251 Y181.305 F152
G1 X92.238 Y181.292 F152
G1 X92.192 Y181.248 F152
G1 X92.18 Y181.236 F152
G1 X92.134 Y181.191 F152
G1 X92.123 Y181.181 F152
G1 X92.074 Y181.133 F152
G1 X92.066 Y181.125 F152
G1 X92.015 Y181.076 F152
G1 X92.009 Y181.07 F152
G1 X91.955 Y181.019 F152
G1 X91.951 Y181.015 F152
G1 X91.894 Y180.96 F152
G1 X91.836 Y180.904 F152
G1 X91.779 Y180.85 F152
G1 X91.777 Y180.847 F152
G1 X91.722 Y180.794 F152
G1 X91.548 Y180.618 F152
G1 X91.496 Y180.561 F152
G1 X91.493 Y180.557 F152
G1 X91.444 Y180.503 F152
G1 X91.436 Y180.495 F152
G1 X91.391 Y180.446 F152
G1 X91.378 Y180.433 F152
G1 X91.341 Y180.389 F152
G1 X91.292 Y180.331 F152
G1 X91.264 Y180.297 F152
G1 X91.245 Y180.274 F152
G1 X91.207 Y180.229 F152
G1 X91.154 Y180.16 F152
G1 X91.149 Y180.154 F152
G1 X91.11 Y180.102 F152
G1 X91.092 Y180.079 F152
G1 X91.066 Y180.045 F152
G1 X91.035 Y180.002 F152
G1 X90.946 Y179.873 F152
G1 X90.92 Y179.836 F152
G1 X90.907 Y179.816 F152
G1 X90.87 Y179.759 F152
G1 X90.863 Y179.747 F152
G1 X90.835 Y179.701 F152
G1 X90.806 Y179.655 F152
G1 X90.799 Y179.644 F152
G1 X90.763 Y179.587 F152
G1 X90.748 Y179.562 F152
G1 X90.73 Y179.53 F152
G1 X90.698 Y179.472 F152
G1 X90.691 Y179.46 F152
G1 X90.666 Y179.415 F152
G1 X90.634 Y179.358 F152
G1 X90.602 Y179.3 F152
G1 X90.576 Y179.251 F152
G1 X90.573 Y179.243 F152
G1 X90.543 Y179.186 F152
G1 X90.519 Y179.139 F152
G1 X90.485 Y179.071 F152
G1 X90.462 Y179.027 F152
G1 X90.456 Y179.014 F152
G1 X90.429 Y178.957 F152
G1 X90.405 Y178.906 F152
G1 X90.402 Y178.899 F152
G1 X90.348 Y178.785 F152
G1 X90.347 Y178.784 F152
G1 X90.321 Y178.728 F152
G1 X90.296 Y178.67 F152
G1 X90.29 Y178.658 F152
G1 X90.27 Y178.613 F152
G1 X90.195 Y178.441 F152
G1 X90.175 Y178.396 F152
G1 X90.171 Y178.384 F152
G1 X90.147 Y178.327 F152
G1 X90.124 Y178.269 F152
G1 X90.118 Y178.258 F152
G1 X90.099 Y178.212 F152
G1 X90.076 Y178.155 F152
G1 X90.061 Y178.12 F152
G1 X90.052 Y178.098 F152
G1 X90.029 Y178.04 F152
G1 X90.006 Y177.983 F152
G1 X90.004 Y177.978 F152
G1 X89.983 Y177.926 F152
G1 X89.961 Y177.868 F152
G1 X89.946 Y177.833 F152
G1 X89.938 Y177.811 F152
G1 X89.915 Y177.754 F152
G1 X89.893 Y177.697 F152
G1 X89.889 Y177.688 F152
G1 X89.871 Y177.639 F152
G1 X89.849 Y177.582 F152
G1 X89.832 Y177.537 F152
G1 X89.827 Y177.525 F152
G1 X89.806 Y177.468 F152
G1 X89.783 Y177.41 F152
G1 X89.774 Y177.387 F152
G1 X89.762 Y177.353 F152
G1 X89.719 Y177.238 F152
G1 X89.717 Y177.235 F152
G1 X89.697 Y177.181 F152
G1 X89.677 Y177.124 F152
G1 X89.66 Y177.08 F152
G1 X89.655 Y177.067 F152
G1 X89.634 Y177.009 F152
G1 X89.613 Y176.952 F152
G1 X89.603 Y176.925 F152
G1 X89.592 Y176.895 F152
G1 X89.551 Y176.78 F152
G1 X89.545 Y176.767 F152
G1 X89.53 Y176.723 F152
G1 X89.489 Y176.608 F152
G1 X89.488 Y176.607 F152
G1 X89.467 Y176.551 F152
G1 X89.447 Y176.494 F152
G1 X89.431 Y176.448 F152
G1 X89.427 Y176.437 F152
G1 X89.407 Y176.379 F152
G1 X89.387 Y176.322 F152
G1 X89.373 Y176.286 F152
G1 X89.366 Y176.265 F152
G1 X89.346 Y176.207 F152
G1 X89.326 Y176.15 F152
G1 X89.316 Y176.123 F152
G1 X89.305 Y176.093 F152
G1 X89.266 Y175.978 F152
G1 X89.259 Y175.958 F152
G1 X89.227 Y175.864 F152
G1 X89.207 Y175.806 F152
G1 X89.202 Y175.79 F152
G1 X89.188 Y175.749 F152
G1 X89.149 Y175.635 F152
G1 X89.144 Y175.623 F152
G1 X89.129 Y175.577 F152
G1 X89.09 Y175.463 F152
G1 X89.087 Y175.456 F152
G1 X89.07 Y175.406 F152
G1 X89.011 Y175.234 F152
G1 X88.973 Y175.119 F152
G1 X88.972 Y175.118 F152
G1 X88.955 Y175.062 F152
G1 X88.917 Y174.947 F152
G1 X88.915 Y174.943 F152
G1 X88.898 Y174.89 F152
G1 X88.804 Y174.604 F152
G1 X88.801 Y174.593 F152
G1 X88.767 Y174.489 F152
G1 X88.749 Y174.432 F152
G1 X88.743 Y174.417 F152
G1 X88.73 Y174.374 F152
G1 X88.711 Y174.317 F152
G1 X88.693 Y174.26 F152
G1 X88.686 Y174.238 F152
G1 X88.675 Y174.203 F152
G1 X88.639 Y174.088 F152
G1 X88.629 Y174.053 F152
G1 X88.622 Y174.031 F152
G1 X88.587 Y173.916 F152
G1 X88.571 Y173.868 F152
G1 X88.569 Y173.859 F152
G1 X88.551 Y173.802 F152
G1 X88.534 Y173.744 F152
G1 X88.516 Y173.687 F152
G1 X88.514 Y173.683 F152
G1 X88.498 Y173.63 F152
G1 X88.48 Y173.573 F152
G1 X88.463 Y173.515 F152
G1 X88.457 Y173.497 F152
G1 X88.411 Y173.343 F152
G1 X88.4 Y173.302 F152
G1 X88.379 Y173.229 F152
G1 X88.362 Y173.172 F152
G1 X88.346 Y173.114 F152
G1 X88.342 Y173.103 F152
G1 X88.33 Y173.057 F152
G1 X88.314 Y173 F152
G1 X88.297 Y172.943 F152
G1 X88.285 Y172.902 F152
G1 X88.281 Y172.885 F152
G1 X88.264 Y172.828 F152
G1 X88.247 Y172.771 F152
G1 X88.231 Y172.713 F152
G1 X88.228 Y172.702 F152
G1 X88.215 Y172.656 F152
G1 X88.198 Y172.599 F152
G1 X88.183 Y172.542 F152
G1 X88.17 Y172.497 F152
G1 X88.168 Y172.484 F152
G1 X88.122 Y172.312 F152
G1 X88.113 Y172.281 F152
G1 X88.107 Y172.255 F152
G1 X88.076 Y172.141 F152
G1 X88.062 Y172.083 F152
G1 X88.056 Y172.059 F152
G1 X88.048 Y172.026 F152
G1 X88.005 Y171.854 F152
G1 X87.999 Y171.831 F152
G1 X87.991 Y171.797 F152
G1 X87.976 Y171.74 F152
G1 X87.949 Y171.625 F152
G1 X87.941 Y171.592 F152
G1 X87.936 Y171.568 F152
G1 X87.896 Y171.396 F152
G1 X87.884 Y171.347 F152
G1 X87.832 Y171.11 F152
G1 X87.827 Y171.085 F152
G1 X87.82 Y171.052 F152
G1 X87.807 Y170.995 F152
G1 X87.795 Y170.938 F152
G1 X87.785 Y170.881 F152
G1 X87.773 Y170.823 F152
G1 X87.769 Y170.806 F152
G1 X87.762 Y170.766 F152
G1 X87.739 Y170.651 F152
G1 X87.728 Y170.594 F152
G1 X87.717 Y170.537 F152
G1 X87.712 Y170.515 F152
G1 X87.706 Y170.48 F152
G1 X87.683 Y170.365 F152
G1 X87.672 Y170.308 F152
G1 X87.66 Y170.25 F152
G1 X87.655 Y170.224 F152
G1 X87.649 Y170.193 F152
G1 X87.6 Y169.907 F152
G1 X87.598 Y169.894 F152
G1 X87.59 Y169.85 F152
G1 X87.581 Y169.792 F152
G1 X87.57 Y169.735 F152
G1 X87.55 Y169.62 F152
G1 X87.54 Y169.565 F152
G1 Y169.563 F152
G1 X87.521 Y169.449 F152
G1 X87.512 Y169.391 F152
G1 X87.502 Y169.334 F152
G1 X87.493 Y169.277 F152
G1 X87.483 Y169.22 F152
G1 Y169.219 F152
G1 X87.474 Y169.162 F152
G1 X87.464 Y169.105 F152
G1 X87.455 Y169.048 F152
G1 X87.445 Y168.99 F152
G1 X87.427 Y168.876 F152
G1 X87.426 Y168.87 F152
G1 X87.409 Y168.761 F152
G1 X87.389 Y168.647 F152
G1 X87.38 Y168.589 F152
G1 X87.37 Y168.532 F152
G1 X87.368 Y168.525 F152
G1 X87.36 Y168.475 F152
G1 X87.331 Y168.303 F152
G1 X87.322 Y168.246 F152
G1 X87.312 Y168.188 F152
G1 X87.311 Y168.187 F152
G1 X87.302 Y168.131 F152
G1 X87.282 Y168.017 F152
G1 X87.274 Y167.959 F152
G1 X87.264 Y167.902 F152
G1 X87.254 Y167.854 F152
G1 X87.253 Y167.845 F152
G1 X87.241 Y167.788 F152
G1 X87.198 Y167.558 F152
G1 X87.197 Y167.553 F152
G1 X87.187 Y167.501 F152
G1 X87.144 Y167.272 F152
G1 X87.139 Y167.252 F152
G1 X87.132 Y167.215 F152
G1 X87.111 Y167.1 F152
G1 X87.099 Y167.043 F152
G1 X87.074 Y166.928 F152
G1 X87.062 Y166.871 F152
G1 X87.037 Y166.757 F152
G1 X87.025 Y166.7 F152
G1 Y166.699 F152
G1 X87.012 Y166.642 F152
G1 X86.972 Y166.47 F152
G1 X86.967 Y166.452 F152
G1 X86.958 Y166.413 F152
G1 X86.918 Y166.241 F152
G1 X86.91 Y166.211 F152
G1 X86.904 Y166.184 F152
G1 X86.873 Y166.069 F152
G1 X86.859 Y166.012 F152
G1 X86.853 Y165.99 F152
G1 X86.844 Y165.955 F152
G1 X86.829 Y165.897 F152
G1 X86.814 Y165.84 F152
G1 X86.799 Y165.783 F152
G1 X86.796 Y165.771 F152
G1 X86.783 Y165.725 F152
G1 X86.766 Y165.668 F152
G1 X86.75 Y165.611 F152
G1 X86.738 Y165.572 F152
G1 X86.733 Y165.554 F152
G1 X86.717 Y165.496 F152
G1 X86.7 Y165.439 F152
G1 X86.684 Y165.382 F152
G1 X86.681 Y165.375 F152
G1 X86.667 Y165.325 F152
G1 X86.648 Y165.267 F152
G1 X86.63 Y165.21 F152
G1 X86.624 Y165.192 F152
G1 X86.611 Y165.153 F152
G1 X86.592 Y165.095 F152
G1 X86.574 Y165.038 F152
G1 X86.566 Y165.015 F152
G1 X86.556 Y164.981 F152
G1 X86.518 Y164.866 F152
G1 X86.509 Y164.844 F152
G1 X86.455 Y164.694 F152
G1 X86.452 Y164.686 F152
G1 X86.435 Y164.637 F152
G1 X86.413 Y164.58 F152
G1 X86.395 Y164.528 F152
G1 X86.393 Y164.523 F152
G1 X86.372 Y164.465 F152
G1 X86.349 Y164.408 F152
G1 X86.337 Y164.381 F152
G1 X86.325 Y164.351 F152
G1 X86.301 Y164.294 F152
G1 X86.28 Y164.242 F152
G1 X86.278 Y164.236 F152
G1 X86.255 Y164.179 F152
G1 X86.231 Y164.122 F152
G1 X86.223 Y164.102 F152
G1 X86.207 Y164.064 F152
G1 X86.181 Y164.007 F152
G1 X86.165 Y163.975 F152
G1 X86.154 Y163.95 F152
G1 X86.127 Y163.893 F152
G1 X86.108 Y163.853 F152
G1 X86.1 Y163.835 F152
G1 X86.073 Y163.778 F152
G1 X86.051 Y163.732 F152
G1 X86.046 Y163.721 F152
G1 X86.019 Y163.663 F152
G1 X85.994 Y163.618 F152
G1 X85.987 Y163.606 F152
G1 X85.956 Y163.549 F152
G1 X85.936 Y163.513 F152
G1 X85.925 Y163.492 F152
G1 X85.893 Y163.434 F152
G1 X85.879 Y163.408 F152
G1 X85.862 Y163.377 F152
G1 X85.831 Y163.32 F152
G1 X85.822 Y163.305 F152
G1 X85.796 Y163.263 F152
G1 X85.764 Y163.215 F152
G1 X85.758 Y163.205 F152
G1 X85.721 Y163.148 F152
G1 X85.707 Y163.127 F152
G1 X85.684 Y163.091 F152
G1 X85.609 Y162.976 F152
G1 X85.593 Y162.954 F152
G1 X85.567 Y162.919 F152
G1 X85.535 Y162.878 F152
G1 X85.524 Y162.862 F152
G1 X85.48 Y162.804 F152
G1 X85.478 Y162.802 F152
G1 X85.432 Y162.747 F152
G1 X85.421 Y162.734 F152
G1 X85.384 Y162.69 F152
G1 X85.363 Y162.666 F152
G1 X85.334 Y162.632 F152
G1 X85.306 Y162.603 F152
G1 X85.279 Y162.575 F152
G1 X85.249 Y162.543 F152
G1 X85.226 Y162.518 F152
G1 X85.192 Y162.486 F152
G1 X85.165 Y162.461 F152
G1 X85.134 Y162.432 F152
G1 X85.103 Y162.403 F152
G1 X85.077 Y162.38 F152
G1 X85.036 Y162.346 F152
G1 X85.02 Y162.334 F152
G1 X84.964 Y162.289 F152
G1 X84.962 Y162.287 F152
G1 X84.905 Y162.244 F152
G1 X84.886 Y162.232 F152
G1 X84.848 Y162.205 F152
G1 X84.803 Y162.174 F152
G1 X84.791 Y162.166 F152
G1 X84.733 Y162.131 F152
G1 X84.708 Y162.117 F152
G1 X84.676 Y162.098 F152
G1 X84.619 Y162.066 F152
G1 X84.606 Y162.06 F152
G1 X84.561 Y162.038 F152
G1 X84.504 Y162.011 F152
G1 X84.484 Y162.002 F152
G1 X84.447 Y161.985 F152
G1 X84.39 Y161.963 F152
G1 X84.332 Y161.945 F152
G1 X84.331 F152
G1 X84.275 Y161.927 F152
G1 X84.16 Y161.891 F152
G1 X84.15 Y161.888 F152
G1 X84.103 Y161.874 F152
G1 X84.046 Y161.862 F152
G1 X83.989 Y161.854 F152
G1 X83.931 Y161.845 F152
G1 X83.874 Y161.837 F152
G1 X83.831 Y161.831 F152
G1 X83.817 Y161.828 F152
G1 X83.759 Y161.821 F152
G1 X83.702 Y161.817 F152
G1 X83.645 Y161.815 F152
G1 X83.53 Y161.814 F152
G1 X83.473 Y161.812 F152
G1 X83.416 F152
G1 X83.244 Y161.823 F152
G1 X83.187 Y161.827 F152
G1 X83.134 Y161.831 F152
G1 X83.129 F152
G1 X83.072 Y161.837 F152
G1 X83.015 Y161.844 F152
G1 X82.957 Y161.85 F152
G1 X82.9 Y161.857 F152
G1 X82.843 Y161.864 F152
G1 X82.786 Y161.871 F152
G1 X82.671 Y161.883 F152
G1 X82.635 Y161.888 F152
G1 X82.614 Y161.89 F152
G1 X82.327 Y161.921 F152
G1 X82.155 Y161.932 F152
G1 X81.984 Y161.934 F152
G1 X81.812 Y161.929 F152
G1 X81.754 Y161.925 F152
G1 X81.697 Y161.92 F152
G1 X81.64 Y161.916 F152
G1 X81.583 Y161.908 F152
G1 X81.468 Y161.892 F152
G1 X81.43 Y161.888 F152
G1 X81.411 Y161.883 F152
G1 X81.239 Y161.851 F152
G1 X81.182 Y161.838 F152
G1 X81.148 Y161.831 F152
G1 X81.124 Y161.824 F152
G1 X81.067 Y161.811 F152
G1 X81.01 Y161.797 F152
G1 X80.952 Y161.78 F152
G1 X80.926 Y161.773 F152
G1 X80.895 Y161.764 F152
G1 X80.838 Y161.748 F152
G1 X80.781 Y161.729 F152
G1 X80.738 Y161.716 F152
G1 X80.723 Y161.711 F152
G1 X80.666 Y161.691 F152
G1 X80.609 Y161.672 F152
G1 X80.568 Y161.659 F152
G1 X80.551 Y161.652 F152
G1 X80.494 Y161.634 F152
G1 X80.437 Y161.614 F152
G1 X80.398 Y161.601 F152
G1 X80.38 Y161.594 F152
G1 X80.322 Y161.573 F152
G1 X80.208 Y161.528 F152
G1 X80.15 Y161.505 F152
G1 X80.104 Y161.487 F152
G1 X80.093 Y161.482 F152
G1 X80.036 Y161.46 F152
G1 X79.979 Y161.437 F152
G1 X79.959 Y161.43 F152
G1 X79.921 Y161.414 F152
G1 X79.864 Y161.39 F152
G1 X79.822 Y161.372 F152
G1 X79.807 Y161.365 F152
G1 X79.692 Y161.315 F152
G1 X79.691 F152
G1 X79.635 Y161.29 F152
G1 X79.578 Y161.265 F152
G1 X79.561 Y161.258 F152
G1 X79.52 Y161.24 F152
G1 X79.463 Y161.215 F152
G1 X79.43 Y161.201 F152
G1 X79.406 Y161.19 F152
G1 X79.348 Y161.162 F152
G1 X79.307 Y161.143 F152
G1 X79.291 Y161.135 F152
G1 X79.234 Y161.108 F152
G1 X79.187 Y161.086 F152
G1 X79.177 Y161.081 F152
G1 X79.119 Y161.054 F152
G1 X79.066 Y161.029 F152
G1 X79.062 Y161.026 F152
G1 X78.946 Y160.971 F152
G1 X78.776 Y160.884 F152
G1 X78.724 Y160.857 F152
G1 X78.718 Y160.854 F152
G1 X78.661 Y160.824 F152
G1 X78.614 Y160.8 F152
G1 X78.604 Y160.794 F152
G1 X78.546 Y160.765 F152
G1 X78.503 Y160.742 F152
G1 X78.489 Y160.735 F152
G1 X78.432 Y160.701 F152
G1 X78.403 Y160.685 F152
G1 X78.317 Y160.634 F152
G1 X78.307 Y160.628 F152
G1 X78.26 Y160.6 F152
G1 X78.21 Y160.57 F152
G1 X78.203 Y160.566 F152
G1 X78.145 Y160.532 F152
G1 X78.113 Y160.513 F152
G1 X78.088 Y160.499 F152
G1 X78.031 Y160.461 F152
G1 X78.022 Y160.456 F152
G1 X77.974 Y160.423 F152
G1 X77.938 Y160.399 F152
G1 X77.916 Y160.384 F152
G1 X77.859 Y160.343 F152
G1 X77.856 Y160.341 F152
G1 X77.802 Y160.3 F152
G1 X77.781 Y160.284 F152
G1 X77.744 Y160.256 F152
G1 X77.707 Y160.227 F152
G1 X77.687 Y160.21 F152
G1 X77.64 Y160.17 F152
G1 X77.63 Y160.161 F152
G1 X77.573 Y160.112 F152
G1 X77.514 Y160.055 F152
G1 X77.456 Y159.998 F152
G1 X77.403 Y159.94 F152
G1 X77.401 Y159.937 F152
G1 X77.353 Y159.883 F152
G1 X77.305 Y159.826 F152
G1 X77.286 Y159.8 F152
G1 X77.229 Y159.723 F152
G1 X77.22 Y159.711 F152
G1 X77.182 Y159.654 F152
G1 X77.172 Y159.637 F152
G1 X77.146 Y159.597 F152
G1 X77.114 Y159.546 F152
G1 X77.111 Y159.539 F152
G1 X77.08 Y159.482 F152
G1 X77.057 Y159.439 F152
G1 X77.05 Y159.425 F152
G1 X77.019 Y159.368 F152
G1 X77 Y159.322 F152
G1 X76.994 Y159.31 F152
G1 X76.969 Y159.253 F152
G1 X76.945 Y159.196 F152
G1 X76.942 Y159.191 F152
G1 X76.923 Y159.139 F152
G1 X76.902 Y159.081 F152
G1 X76.885 Y159.036 F152
G1 X76.882 Y159.024 F152
G1 X76.862 Y158.967 F152
G1 X76.844 Y158.909 F152
G1 X76.828 Y158.857 F152
G1 X76.827 Y158.852 F152
G1 X76.809 Y158.795 F152
G1 X76.763 Y158.623 F152
G1 X76.749 Y158.566 F152
G1 X76.722 Y158.451 F152
G1 X76.713 Y158.414 F152
G1 X76.709 Y158.394 F152
G1 X76.659 Y158.165 F152
G1 X76.656 Y158.154 F152
G1 X76.646 Y158.107 F152
G1 X76.609 Y157.936 F152
G1 X76.599 Y157.892 F152
G1 X76.596 Y157.878 F152
G1 X76.582 Y157.821 F152
G1 X76.568 Y157.764 F152
G1 X76.554 Y157.707 F152
G1 X76.541 Y157.658 F152
G1 X76.54 Y157.649 F152
G1 X76.522 Y157.592 F152
G1 X76.505 Y157.535 F152
G1 X76.487 Y157.477 F152
G1 X76.484 Y157.47 F152
G1 X76.468 Y157.42 F152
G1 X76.445 Y157.363 F152
G1 X76.427 Y157.323 F152
G1 X76.42 Y157.306 F152
G1 X76.395 Y157.248 F152
G1 X76.37 Y157.195 F152
G1 X76.368 Y157.191 F152
G1 X76.336 Y157.134 F152
G1 X76.312 Y157.096 F152
G1 X76.301 Y157.076 F152
G1 X76.26 Y157.019 F152
G1 X76.255 Y157.013 F152
G1 X76.214 Y156.962 F152
G1 X76.198 Y156.942 F152
G1 X76.163 Y156.905 F152
G1 X76.14 Y156.882 F152
G1 X76.101 Y156.847 F152
G1 X76.083 Y156.831 F152
G1 X76.032 Y156.79 F152
G1 X76.026 Y156.786 F152
G1 X75.969 Y156.747 F152
G1 X75.943 Y156.733 F152
G1 X75.911 Y156.715 F152
G1 X75.854 Y156.685 F152
G1 X75.797 Y156.661 F152
G1 X75.739 Y156.642 F152
G1 X75.682 Y156.627 F152
G1 X75.645 Y156.618 F152
G1 X75.625 Y156.614 F152
G1 X75.568 Y156.605 F152
G1 X75.51 Y156.6 F152
G1 X75.453 Y156.599 F152
G1 X75.396 F152
G1 X75.338 Y156.603 F152
G1 X75.281 Y156.612 F152
G1 X75.251 Y156.618 F152
G1 X75.224 Y156.624 F152
G1 X75.167 Y156.637 F152
G1 X75.109 Y156.655 F152
G1 X75.055 Y156.676 F152
G1 X75.052 F152
G1 X74.995 Y156.7 F152
G1 X74.937 Y156.728 F152
G1 X74.929 Y156.733 F152
G1 X74.88 Y156.76 F152
G1 X74.829 Y156.79 F152
G1 X74.823 Y156.795 F152
G1 X74.766 Y156.833 F152
G1 X74.745 Y156.847 F152
G1 X74.708 Y156.875 F152
G1 X74.672 Y156.905 F152
G1 X74.651 Y156.923 F152
G1 X74.604 Y156.962 F152
G1 X74.594 Y156.971 F152
G1 X74.537 Y157.019 F152
G1 X74.478 Y157.076 F152
G1 X74.45 Y157.105 F152
G1 X74.422 Y157.134 F152
G1 X74.394 Y157.162 F152
G1 X74.365 Y157.192 F152
G1 X74.312 Y157.248 F152
G1 X74.307 Y157.254 F152
G1 X74.261 Y157.306 F152
G1 X74.25 Y157.318 F152
G1 X74.21 Y157.363 F152
G1 X74.193 Y157.383 F152
G1 X74.159 Y157.42 F152
G1 X74.135 Y157.449 F152
G1 X74.078 Y157.517 F152
G1 X74.063 Y157.535 F152
G1 X74.021 Y157.586 F152
G1 X74.015 Y157.592 F152
G1 X73.964 Y157.655 F152
G1 X73.921 Y157.707 F152
G1 X73.906 Y157.726 F152
G1 X73.849 Y157.797 F152
G1 X73.829 Y157.821 F152
G1 X73.792 Y157.868 F152
G1 X73.784 Y157.878 F152
G1 X73.737 Y157.936 F152
G1 X73.734 Y157.939 F152
G1 X73.677 Y158.011 F152
G1 X73.646 Y158.05 F152
G1 X73.62 Y158.082 F152
G1 X73.599 Y158.107 F152
G1 X73.563 Y158.154 F152
G1 X73.554 Y158.165 F152
G1 X73.508 Y158.222 F152
G1 X73.505 Y158.226 F152
G1 X73.461 Y158.279 F152
G1 X73.448 Y158.296 F152
G1 X73.415 Y158.337 F152
G1 X73.391 Y158.366 F152
G1 X73.367 Y158.394 F152
G1 X73.333 Y158.433 F152
G1 X73.318 Y158.451 F152
G1 X73.276 Y158.501 F152
G1 X73.27 Y158.508 F152
G1 X73.222 Y158.566 F152
G1 X73.219 Y158.569 F152
G1 X73.173 Y158.623 F152
G1 X73.162 Y158.636 F152
G1 X73.125 Y158.68 F152
G1 X73.104 Y158.704 F152
G1 X73.077 Y158.738 F152
G1 X73.047 Y158.771 F152
G1 X72.99 Y158.832 F152
G1 X72.972 Y158.852 F152
G1 X72.918 Y158.909 F152
G1 X72.875 Y158.954 F152
G1 X72.863 Y158.967 F152
G1 X72.818 Y159.011 F152
G1 X72.747 Y159.081 F152
G1 X72.703 Y159.121 F152
G1 X72.683 Y159.139 F152
G1 X72.617 Y159.196 F152
G1 X72.589 Y159.221 F152
G1 X72.531 Y159.265 F152
G1 X72.474 Y159.308 F152
G1 X72.471 Y159.31 F152
G1 X72.417 Y159.346 F152
G1 X72.383 Y159.368 F152
G1 X72.36 Y159.383 F152
G1 X72.302 Y159.414 F152
G1 X72.282 Y159.425 F152
G1 X72.245 Y159.444 F152
G1 X72.188 Y159.468 F152
G1 X72.152 Y159.482 F152
G1 X72.13 Y159.49 F152
G1 X72.073 Y159.508 F152
G1 X72.016 Y159.525 F152
G1 X71.959 Y159.538 F152
G1 X71.949 Y159.539 F152
G1 X71.901 Y159.548 F152
G1 X71.787 Y159.572 F152
G1 X71.729 Y159.581 F152
G1 X71.672 Y159.589 F152
G1 X71.615 Y159.596 F152
G1 X71.613 Y159.597 F152
G1 X71.558 Y159.604 F152
G1 X71.5 Y159.611 F152
G1 X71.443 Y159.619 F152
G1 X71.386 Y159.626 F152
G1 X71.328 Y159.634 F152
G1 X71.214 Y159.649 F152
G1 X71.176 Y159.654 F152
G1 X71.157 Y159.656 F152
G1 X71.099 Y159.664 F152
G1 X71.042 Y159.673 F152
G1 X70.985 Y159.683 F152
G1 X70.87 Y159.701 F152
G1 X70.813 Y159.71 F152
G1 X70.809 Y159.711 F152
G1 X70.756 Y159.719 F152
G1 X70.698 Y159.729 F152
G1 X70.641 Y159.741 F152
G1 X70.584 Y159.753 F152
G1 X70.526 Y159.765 F152
G1 X70.512 Y159.769 F152
G1 X70.469 Y159.778 F152
G1 X70.412 Y159.789 F152
G1 X70.297 Y159.814 F152
G1 X70.246 Y159.826 F152
G1 X70.24 Y159.827 F152
G1 X70.183 Y159.842 F152
G1 X70.068 Y159.871 F152
G1 X70.022 Y159.883 F152
G1 X69.896 Y159.914 F152
G1 X69.839 Y159.93 F152
G1 X69.8 Y159.94 F152
G1 X69.782 Y159.945 F152
G1 X69.61 Y159.993 F152
G1 X69.595 Y159.998 F152
G1 X69.553 Y160.009 F152
G1 X69.495 Y160.025 F152
G1 X69.475 Y160.031 F152
G1 X69.473 F152
; MOVEMENT_LINK_TRANSITION
G1 Y160.03 F152
; MOVEMENT_CUTTING
G1 X69.474 Y160.028 F152
G1 X69.476 Y160.023 F152
G1 X69.477 Y160.02 F152
G1 X69.482 Y160.012 F152
G1 X69.488 Y159.998 F152
G1 X69.495 Y159.983 F152
G1 X69.516 Y159.94 F152
G1 X69.545 Y159.883 F152
G1 X69.553 Y159.865 F152
G1 X69.572 Y159.826 F152
G1 X69.6 Y159.769 F152
G1 X69.629 Y159.711 F152
G1 X69.658 Y159.654 F152
G1 X69.667 Y159.635 F152
G1 X69.687 Y159.597 F152
G1 X69.724 Y159.522 F152
G1 X69.745 Y159.482 F152
G1 X69.775 Y159.425 F152
G1 X69.782 Y159.411 F152
G1 X69.804 Y159.368 F152
G1 X69.834 Y159.31 F152
G1 X69.839 Y159.3 F152
G1 X69.863 Y159.253 F152
G1 X69.893 Y159.196 F152
G1 X69.896 Y159.19 F152
G1 X69.923 Y159.139 F152
G1 X69.982 Y159.024 F152
G1 X70.011 Y158.969 F152
G1 X70.013 Y158.967 F152
G1 X70.042 Y158.909 F152
G1 X70.068 Y158.86 F152
G1 X70.073 Y158.852 F152
G1 X70.102 Y158.795 F152
G1 X70.133 Y158.738 F152
G1 X70.162 Y158.68 F152
G1 X70.183 Y158.641 F152
G1 X70.193 Y158.623 F152
G1 X70.222 Y158.566 F152
G1 X70.24 Y158.531 F152
G1 X70.252 Y158.508 F152
G1 X70.281 Y158.451 F152
G1 X70.312 Y158.394 F152
G1 X70.341 Y158.337 F152
G1 X70.355 Y158.31 F152
G1 X70.371 Y158.279 F152
G1 X70.4 Y158.222 F152
G1 X70.412 Y158.2 F152
G1 X70.43 Y158.165 F152
G1 X70.46 Y158.107 F152
G1 X70.469 Y158.09 F152
G1 X70.49 Y158.05 F152
G1 X70.519 Y157.993 F152
G1 X70.526 Y157.978 F152
G1 X70.548 Y157.936 F152
G1 X70.577 Y157.878 F152
G1 X70.584 Y157.863 F152
G1 X70.605 Y157.821 F152
G1 X70.698 Y157.635 F152
G1 X70.721 Y157.592 F152
G1 X70.749 Y157.535 F152
G1 X70.756 Y157.521 F152
G1 X70.778 Y157.477 F152
G1 X70.835 Y157.363 F152
G1 X70.863 Y157.306 F152
G1 X70.87 Y157.29 F152
G1 X70.89 Y157.248 F152
G1 X70.918 Y157.191 F152
G1 X70.927 Y157.169 F152
G1 X70.944 Y157.134 F152
G1 X70.985 Y157.048 F152
G1 X70.999 Y157.019 F152
G1 X71.026 Y156.962 F152
G1 X71.042 Y156.928 F152
G1 X71.053 Y156.905 F152
G1 X71.08 Y156.847 F152
G1 X71.099 Y156.807 F152
G1 X71.107 Y156.79 F152
G1 X71.134 Y156.733 F152
G1 X71.157 Y156.686 F152
G1 X71.162 Y156.676 F152
G1 X71.187 Y156.618 F152
G1 X71.213 Y156.561 F152
G1 X71.214 Y156.558 F152
G1 X71.238 Y156.504 F152
G1 X71.264 Y156.446 F152
G1 X71.271 Y156.429 F152
G1 X71.289 Y156.389 F152
G1 X71.315 Y156.332 F152
G1 X71.328 Y156.299 F152
G1 X71.339 Y156.275 F152
G1 X71.363 Y156.217 F152
G1 X71.386 Y156.164 F152
G1 X71.387 Y156.16 F152
G1 X71.46 Y155.988 F152
G1 X71.482 Y155.931 F152
G1 X71.5 Y155.886 F152
G1 X71.506 Y155.874 F152
G1 X71.528 Y155.816 F152
G1 X71.551 Y155.759 F152
G1 X71.558 Y155.742 F152
G1 X71.574 Y155.702 F152
G1 X71.595 Y155.645 F152
G1 X71.615 Y155.591 F152
G1 X71.617 Y155.587 F152
G1 X71.638 Y155.53 F152
G1 X71.659 Y155.473 F152
G1 X71.672 Y155.436 F152
G1 X71.68 Y155.415 F152
G1 X71.701 Y155.358 F152
G1 X71.72 Y155.301 F152
G1 X71.739 Y155.244 F152
G1 X71.758 Y155.186 F152
G1 X71.778 Y155.129 F152
G1 X71.787 Y155.101 F152
G1 X71.797 Y155.072 F152
G1 X71.814 Y155.014 F152
G1 X71.831 Y154.957 F152
G1 X71.844 Y154.913 F152
G1 X71.848 Y154.9 F152
G1 X71.882 Y154.785 F152
G1 X71.898 Y154.728 F152
G1 X71.901 Y154.713 F152
G1 X71.912 Y154.671 F152
G1 X71.926 Y154.614 F152
G1 X71.942 Y154.556 F152
G1 X71.956 Y154.499 F152
G1 X71.959 Y154.486 F152
G1 X71.968 Y154.442 F152
G1 X71.979 Y154.384 F152
G1 X72.014 Y154.213 F152
G1 X72.016 Y154.197 F152
G1 X72.022 Y154.155 F152
G1 X72.038 Y154.041 F152
G1 X72.045 Y153.983 F152
G1 X72.052 Y153.926 F152
G1 X72.062 Y153.754 F152
G1 X72.065 Y153.697 F152
G1 X72.064 Y153.64 F152
G1 X72.062 Y153.583 F152
G1 X72.057 Y153.468 F152
G1 X72.052 Y153.411 F152
G1 X72.043 Y153.353 F152
G1 X72.033 Y153.296 F152
G1 X72.022 Y153.239 F152
G1 X72.016 Y153.207 F152
G1 X72.01 Y153.182 F152
G1 X71.993 Y153.124 F152
G1 X71.974 Y153.067 F152
G1 X71.959 Y153.027 F152
G1 X71.952 Y153.01 F152
G1 X71.931 Y152.952 F152
G1 X71.905 Y152.895 F152
G1 X71.872 Y152.838 F152
G1 X71.844 Y152.795 F152
G1 X71.835 Y152.781 F152
G1 X71.797 Y152.723 F152
G1 X71.787 Y152.708 F152
G1 X71.755 Y152.666 F152
G1 X71.729 Y152.636 F152
G1 X71.704 Y152.609 F152
G1 X71.672 Y152.578 F152
G1 X71.642 Y152.552 F152
G1 X71.575 Y152.494 F152
G1 X71.558 Y152.479 F152
G1 X71.5 Y152.438 F152
G1 X71.498 Y152.437 F152
G1 X71.443 Y152.403 F152
G1 X71.396 Y152.38 F152
G1 X71.328 Y152.349 F152
G1 X71.265 Y152.322 F152
G1 X71.214 Y152.304 F152
G1 X71.157 Y152.288 F152
G1 X71.099 Y152.276 F152
G1 X71.042 Y152.268 F152
G1 X71.021 Y152.265 F152
G1 X70.985 Y152.26 F152
G1 X70.927 Y152.253 F152
G1 X70.87 Y152.25 F152
G1 X70.813 Y152.252 F152
G1 X70.698 Y152.261 F152
G1 X70.641 Y152.266 F152
G1 X70.584 Y152.276 F152
G1 X70.469 Y152.303 F152
G1 X70.412 Y152.317 F152
G1 X70.394 Y152.322 F152
G1 X70.355 Y152.334 F152
G1 X70.297 Y152.356 F152
G1 X70.236 Y152.38 F152
G1 X70.183 Y152.399 F152
G1 X70.125 Y152.424 F152
G1 X70.068 Y152.452 F152
G1 X69.954 Y152.509 F152
G1 X69.896 Y152.542 F152
G1 X69.839 Y152.575 F152
G1 X69.783 Y152.609 F152
G1 X69.782 F152
G1 X69.724 Y152.644 F152
G1 X69.691 Y152.666 F152
G1 X69.667 Y152.682 F152
G1 X69.61 Y152.721 F152
G1 X69.606 Y152.723 F152
G1 X69.553 Y152.76 F152
G1 X69.522 Y152.781 F152
G1 X69.495 Y152.8 F152
G1 X69.438 Y152.843 F152
G1 X69.381 Y152.887 F152
G1 X69.323 Y152.93 F152
G1 X69.295 Y152.952 F152
G1 X69.266 Y152.976 F152
G1 X69.209 Y153.024 F152
G1 X69.094 Y153.119 F152
G1 X69.088 Y153.124 F152
G1 X69.037 Y153.17 F152
G1 X69.024 Y153.182 F152
G1 X68.98 Y153.221 F152
G1 X68.922 Y153.273 F152
G1 X68.896 Y153.296 F152
G1 X68.865 Y153.325 F152
G1 X68.836 Y153.353 F152
G1 X68.778 Y153.411 F152
G1 X68.751 Y153.438 F152
G1 X68.693 Y153.495 F152
G1 X68.662 Y153.525 F152
G1 X68.605 Y153.583 F152
G1 X68.579 Y153.608 F152
G1 X68.521 Y153.665 F152
G1 X68.488 Y153.697 F152
G1 X68.464 Y153.723 F152
G1 X68.407 Y153.786 F152
G1 X68.384 Y153.812 F152
G1 X68.332 Y153.869 F152
G1 X68.292 Y153.912 F152
G1 X68.28 Y153.926 F152
G1 X68.235 Y153.975 F152
G1 X68.227 Y153.983 F152
G1 X68.178 Y154.038 F152
G1 X68.175 Y154.041 F152
G1 X68.123 Y154.098 F152
G1 X68.12 Y154.102 F152
G1 X68.074 Y154.155 F152
G1 X68.063 Y154.169 F152
G1 X68.026 Y154.213 F152
G1 X68.006 Y154.238 F152
G1 X67.979 Y154.27 F152
G1 X67.932 Y154.327 F152
G1 X67.891 Y154.375 F152
G1 X67.883 Y154.384 F152
G1 X67.836 Y154.442 F152
G1 X67.834 Y154.443 F152
G1 X67.788 Y154.499 F152
G1 X67.777 Y154.512 F152
G1 X67.743 Y154.556 F152
G1 X67.719 Y154.586 F152
G1 X67.697 Y154.614 F152
G1 X67.662 Y154.659 F152
G1 X67.652 Y154.671 F152
G1 X67.608 Y154.728 F152
G1 X67.605 Y154.732 F152
G1 X67.563 Y154.785 F152
G1 X67.548 Y154.805 F152
G1 X67.518 Y154.843 F152
G1 X67.49 Y154.878 F152
G1 X67.473 Y154.9 F152
G1 X67.433 Y154.953 F152
G1 X67.429 Y154.957 F152
G1 X67.386 Y155.014 F152
G1 X67.376 Y155.028 F152
G1 X67.342 Y155.072 F152
G1 X67.318 Y155.103 F152
G1 X67.299 Y155.129 F152
G1 X67.261 Y155.178 F152
G1 X67.255 Y155.186 F152
G1 X67.211 Y155.244 F152
G1 X67.165 Y155.301 F152
G1 X67.147 Y155.325 F152
G1 X67.121 Y155.358 F152
G1 X67.075 Y155.415 F152
G1 X67.032 Y155.47 F152
G1 X67.029 Y155.473 F152
G1 X66.985 Y155.53 F152
G1 X66.975 Y155.542 F152
G1 X66.934 Y155.587 F152
G1 X66.917 Y155.607 F152
G1 X66.885 Y155.645 F152
G1 X66.835 Y155.702 F152
G1 X66.803 Y155.739 F152
G1 X66.785 Y155.759 F152
G1 X66.746 Y155.801 F152
G1 X66.73 Y155.816 F152
G1 X66.688 Y155.858 F152
G1 X66.671 Y155.874 F152
G1 X66.631 Y155.913 F152
G1 X66.613 Y155.931 F152
G1 X66.574 Y155.969 F152
G1 X66.554 Y155.988 F152
G1 X66.516 Y156.021 F152
G1 X66.489 Y156.045 F152
G1 X66.459 Y156.07 F152
G1 X66.418 Y156.103 F152
G1 X66.402 Y156.114 F152
G1 X66.345 Y156.158 F152
G1 X66.259 Y156.217 F152
G1 X66.23 Y156.236 F152
G1 X66.173 Y156.272 F152
G1 X66.115 Y156.306 F152
G1 X66.07 Y156.332 F152
G1 X66.058 Y156.337 F152
G1 X66.001 Y156.367 F152
G1 X65.958 Y156.389 F152
G1 X65.829 Y156.446 F152
G1 X65.827 F152
G1 X65.772 Y156.467 F152
G1 X65.714 Y156.488 F152
G1 X65.665 Y156.504 F152
G1 X65.657 Y156.506 F152
G1 X65.6 Y156.523 F152
G1 X65.543 Y156.536 F152
G1 X65.485 Y156.548 F152
G1 X65.428 Y156.557 F152
G1 X65.414 Y156.558 F152
G1 X65.408 F152
G1 X65.406 Y156.559 F152
G1 X65.404 F152
; MOVEMENT_LINK_TRANSITION
G1 X65.403 Y156.56 Z-6.013 F152
; MOVEMENT_CUTTING
G1 X65.402 Y156.561 Z-6.005 F152
G1 X65.394 Y156.568 Z-5.948 F152
G1 X65.386 Y156.574 Z-5.899 F152
G1 X65.371 Y156.589 Z-5.784 F152
G1 X65.362 Y156.596 Z-5.72 F152
G1 X65.352 Y156.603 Z-5.654 F152
G1 X65.313 Y156.637 Z-5.343 F152
G1 X65.306 Y156.644 Z-5.278 F152
G1 X65.299 Y156.65 Z-5.221 F152
G1 X65.292 Y156.657 Z-5.161 F152
G1 X65.285 Y156.662 Z-5.104 F152
G1 X65.276 Y156.669 Z-5.028 F152
G1 X65.268 Y156.676 Z-4.962 F152
G1 X65.263 Y156.68 Z-4.916 F152
G1 X65.249 Y156.693 Z-4.786 F152
G1 X65.242 Y156.7 Z-4.712 F152
G1 X65.235 Y156.706 Z-4.647 F152
G1 X65.227 Y156.712 Z-4.577 F152
G1 X65.21 Y156.726 Z-4.413 F152
G1 X65.199 Y156.736 Z-4.291 F152
; MOVEMENT_LEAD_OUT
G1 Y156.737 Z-4.283 F152
G1 X65.201 Y156.735 Z-4.264 F152
G1 X65.207 Y156.729 Z-4.246 F152
G1 X65.218 Y156.72 Z-4.232 F152
G1 X65.231 Y156.708 Z-4.224 F152
G1 X65.246 Y156.696 Z-4.22 F152
; MOVEMENT_LINK_TRANSITION
G1 X65.357 Y156.599 F152
; MOVEMENT_LEAD_IN
G1 X65.371 Y156.586 Z-4.224 F152
G1 X65.384 Y156.574 Z-4.232 F152
G1 X65.395 Y156.565 Z-4.246 F152
G1 X65.401 Y156.559 Z-4.264 F152
G1 X65.404 Y156.557 Z-4.283 F152
G1 Z-6.016 F152
; MOVEMENT_CUTTING
G1 Y156.554 F152
G1 X65.407 Y156.547 F152
G1 X65.41 Y156.532 F152
G1 X65.419 Y156.504 F152
G1 X65.428 Y156.477 F152
G1 X65.439 Y156.446 F152
G1 X65.46 Y156.389 F152
G1 X65.51 Y156.275 F152
G1 X65.541 Y156.217 F152
G1 X65.543 Y156.214 F152
G1 X65.571 Y156.16 F152
G1 X65.6 Y156.107 F152
G1 X65.603 Y156.103 F152
G1 X65.637 Y156.045 F152
G1 X65.672 Y155.988 F152
G1 X65.71 Y155.931 F152
G1 X65.714 Y155.924 F152
G1 X65.748 Y155.874 F152
G1 X65.772 Y155.839 F152
G1 X65.787 Y155.816 F152
G1 X65.829 Y155.761 F152
G1 X65.83 Y155.759 F152
G1 X65.874 Y155.702 F152
G1 X65.886 Y155.686 F152
G1 X65.944 Y155.611 F152
G1 X65.961 Y155.587 F152
G1 X66.001 Y155.535 F152
G1 X66.005 Y155.53 F152
G1 X66.058 Y155.461 F152
G1 X66.096 Y155.415 F152
G1 X66.144 Y155.358 F152
G1 X66.173 Y155.323 F152
G1 X66.191 Y155.301 F152
G1 X66.239 Y155.244 F152
G1 X66.287 Y155.186 F152
G1 Y155.185 F152
G1 X66.402 Y155.049 F152
G1 X66.431 Y155.014 F152
G1 X66.459 Y154.98 F152
G1 X66.479 Y154.957 F152
G1 X66.516 Y154.911 F152
G1 X66.525 Y154.9 F152
G1 X66.572 Y154.843 F152
G1 X66.574 Y154.84 F152
G1 X66.618 Y154.785 F152
G1 X66.661 Y154.728 F152
G1 X66.688 Y154.691 F152
G1 X66.703 Y154.671 F152
G1 X66.745 Y154.614 F152
G1 X66.746 Y154.613 F152
G1 X66.782 Y154.556 F152
G1 X66.803 Y154.524 F152
G1 X66.82 Y154.499 F152
G1 X66.856 Y154.442 F152
G1 X66.86 Y154.434 F152
G1 X66.887 Y154.384 F152
G1 X66.916 Y154.327 F152
G1 X66.917 Y154.323 F152
G1 X66.944 Y154.27 F152
G1 X66.969 Y154.213 F152
G1 X66.975 Y154.198 F152
G1 X66.99 Y154.155 F152
G1 X67.024 Y154.041 F152
G1 X67.032 Y154.011 F152
G1 X67.039 Y153.983 F152
G1 X67.05 Y153.926 F152
G1 X67.056 Y153.869 F152
G1 X67.06 Y153.754 F152
G1 X67.061 Y153.697 F152
G1 X67.057 Y153.64 F152
G1 X67.05 Y153.583 F152
G1 X67.038 Y153.525 F152
G1 X67.022 Y153.468 F152
G1 X67.003 Y153.411 F152
G1 X66.984 Y153.353 F152
G1 X66.975 Y153.33 F152
G1 X66.96 Y153.296 F152
G1 X66.932 Y153.239 F152
G1 X66.917 Y153.215 F152
G1 X66.896 Y153.182 F152
G1 X66.86 Y153.132 F152
G1 X66.803 Y153.059 F152
G1 X66.762 Y153.01 F152
G1 X66.746 Y152.993 F152
G1 X66.703 Y152.952 F152
G1 X66.688 Y152.94 F152
G1 X66.631 Y152.895 F152
G1 X66.63 F152
G1 X66.574 Y152.853 F152
G1 X66.553 Y152.838 F152
G1 X66.516 Y152.813 F152
G1 X66.462 Y152.781 F152
G1 X66.459 Y152.779 F152
G1 X66.402 Y152.75 F152
G1 X66.345 Y152.723 F152
G1 X66.287 Y152.696 F152
G1 X66.23 Y152.672 F152
G1 X66.21 Y152.666 F152
G1 X66.173 Y152.654 F152
G1 X66.058 Y152.616 F152
G1 X66.036 Y152.609 F152
G1 X66.001 Y152.599 F152
G1 X65.829 Y152.559 F152
G1 X65.796 Y152.552 F152
G1 X65.772 Y152.546 F152
G1 X65.714 Y152.536 F152
G1 X65.657 Y152.527 F152
G1 X65.543 Y152.508 F152
G1 X65.42 Y152.494 F152
G1 X65.371 Y152.488 F152
G1 X65.256 Y152.475 F152
G1 X65.199 Y152.47 F152
G1 X65.142 Y152.467 F152
G1 X65.084 Y152.462 F152
G1 X65.027 Y152.458 F152
G1 X64.97 Y152.454 F152
G1 X64.912 Y152.45 F152
G1 X64.855 Y152.448 F152
G1 X64.569 Y152.439 F152
G1 X64.511 Y152.438 F152
G1 X64.282 F152
G1 X64.225 Y152.437 F152
G1 X64.168 Y152.439 F152
G1 X64.11 Y152.441 F152
G1 X64.053 Y152.443 F152
G1 X63.996 Y152.446 F152
G1 X63.881 Y152.449 F152
G1 X63.824 Y152.452 F152
G1 X63.767 Y152.454 F152
G1 X63.709 Y152.457 F152
G1 X63.652 Y152.458 F152
G1 X63.595 Y152.461 F152
G1 X63.538 Y152.463 F152
G1 X63.194 Y152.49 F152
G1 X63.158 Y152.494 F152
G1 X63.137 Y152.496 F152
G1 X62.965 Y152.515 F152
G1 X62.907 Y152.522 F152
G1 X62.85 Y152.528 F152
G1 X62.736 Y152.544 F152
G1 X62.691 Y152.552 F152
G1 X62.564 Y152.569 F152
G1 X62.506 Y152.578 F152
G1 X62.392 Y152.6 F152
G1 X62.346 Y152.609 F152
G1 X62.335 Y152.611 F152
G1 X62.22 Y152.632 F152
G1 X62.105 Y152.657 F152
G1 X62.07 Y152.666 F152
G1 X62.048 Y152.671 F152
G1 X61.991 Y152.684 F152
G1 X61.934 Y152.697 F152
G1 X61.876 Y152.711 F152
G1 X61.833 Y152.723 F152
G1 X61.819 Y152.727 F152
G1 X61.704 Y152.759 F152
G1 X61.647 Y152.774 F152
G1 X61.627 Y152.781 F152
G1 X61.59 Y152.791 F152
G1 X61.475 Y152.829 F152
G1 X61.449 Y152.838 F152
G1 X61.418 Y152.848 F152
G1 X61.361 Y152.867 F152
G1 X61.303 Y152.886 F152
G1 X61.28 Y152.895 F152
G1 X61.246 Y152.908 F152
G1 X61.189 Y152.93 F152
G1 X61.132 Y152.952 F152
G1 X61.13 F152
G1 X61.074 Y152.973 F152
G1 X61.017 Y152.996 F152
G1 X60.986 Y153.01 F152
G1 X60.96 Y153.02 F152
G1 X60.853 Y153.067 F152
G1 X60.845 Y153.071 F152
G1 X60.788 Y153.095 F152
G1 X60.731 Y153.122 F152
G1 X60.724 Y153.124 F152
G1 X60.673 Y153.148 F152
G1 X60.616 Y153.176 F152
G1 X60.605 Y153.182 F152
G1 X60.559 Y153.204 F152
G1 X60.501 Y153.231 F152
G1 X60.486 Y153.239 F152
G1 X60.444 Y153.26 F152
G1 X60.387 Y153.292 F152
G1 X60.378 Y153.296 F152
G1 X60.33 Y153.322 F152
G1 X60.215 Y153.383 F152
G1 X60.163 Y153.411 F152
G1 X60.158 Y153.413 F152
G1 X60.1 Y153.444 F152
G1 X60.056 Y153.468 F152
G1 X60.043 Y153.474 F152
G1 X59.986 Y153.505 F152
G1 X59.871 Y153.569 F152
G1 X59.849 Y153.583 F152
G1 X59.757 Y153.634 F152
G1 X59.748 Y153.64 F152
G1 X59.699 Y153.667 F152
G1 X59.647 Y153.697 F152
G1 X59.642 Y153.699 F152
G1 X59.585 Y153.732 F152
G1 X59.545 Y153.754 F152
G1 X59.528 Y153.764 F152
G1 X59.47 Y153.796 F152
G1 X59.443 Y153.812 F152
G1 X59.413 Y153.829 F152
G1 X59.356 Y153.86 F152
G1 X59.34 Y153.869 F152
G1 X59.298 Y153.892 F152
G1 X59.241 Y153.924 F152
G1 X59.237 Y153.926 F152
G1 X59.184 Y153.955 F152
G1 X59.127 Y153.987 F152
G1 X59.069 Y154.018 F152
G1 X59.03 Y154.041 F152
G1 X58.955 Y154.082 F152
G1 X58.897 Y154.111 F152
G1 X58.84 Y154.138 F152
G1 X58.807 Y154.155 F152
G1 X58.783 Y154.167 F152
G1 X58.726 Y154.196 F152
G1 X58.691 Y154.213 F152
G1 X58.668 Y154.223 F152
G1 X58.575 Y154.27 F152
G1 X58.554 Y154.28 F152
G1 X58.439 Y154.337 F152
G1 X58.382 Y154.361 F152
G1 X58.327 Y154.384 F152
G1 X58.325 Y154.385 F152
G1 X58.267 Y154.409 F152
G1 X58.21 Y154.435 F152
G1 X58.192 Y154.442 F152
G1 X58.153 Y154.456 F152
G1 X58.095 Y154.477 F152
G1 X58.038 Y154.498 F152
G1 X58.035 Y154.499 F152
G1 X57.981 Y154.519 F152
G1 X57.924 Y154.537 F152
G1 X57.866 Y154.554 F152
G1 X57.861 Y154.556 F152
G1 X57.809 Y154.571 F152
G1 X57.752 Y154.588 F152
G1 X57.694 Y154.603 F152
G1 X57.649 Y154.614 F152
G1 X57.637 Y154.615 F152
G1 X57.523 Y154.64 F152
G1 X57.465 Y154.649 F152
G1 X57.408 Y154.656 F152
G1 X57.351 Y154.665 F152
G1 X57.293 Y154.67 F152
G1 X57.278 Y154.671 F152
G1 X57.236 Y154.672 F152
G1 X57.122 Y154.674 F152
G1 X57.091 Y154.671 F152
G1 X57.064 Y154.668 F152
G1 X57.007 Y154.663 F152
G1 X56.95 Y154.653 F152
G1 X56.892 Y154.64 F152
G1 X56.835 Y154.623 F152
G1 X56.808 Y154.614 F152
G1 X56.778 Y154.601 F152
G1 X56.721 Y154.572 F152
G1 X56.694 Y154.556 F152
G1 X56.663 Y154.535 F152
G1 X56.621 Y154.499 F152
G1 X56.62 Y154.498 F152
G1 X56.619 Y154.497 F152
G1 X56.606 Y154.481 F152
G1 X56.597 Y154.47 F152
G1 X56.585 Y154.456 F152
G1 X56.58 Y154.449 F152
G1 X56.576 Y154.445 F152
G1 X56.575 Y154.442 F152
G1 X56.549 Y154.395 F152
G1 X56.546 Y154.39 F152
G1 Y154.388 F152
G1 X56.544 Y154.384 F152
G1 X56.535 Y154.356 F152
G1 X56.53 Y154.341 F152
G1 X56.528 Y154.334 F152
G1 X56.527 Y154.333 F152
G1 Y154.331 F152
G1 X56.526 Y154.327 F152
G1 X56.519 Y154.268 F152
G1 Y154.266 F152
G1 Y154.263 F152
G1 X56.52 Y154.256 F152
G1 Y154.241 F152
G1 X56.522 Y154.213 F152
G1 X56.528 Y154.155 F152
G1 X56.544 Y154.098 F152
G1 X56.549 Y154.086 F152
G1 X56.567 Y154.041 F152
G1 X56.595 Y153.983 F152
G1 X56.606 Y153.965 F152
G1 X56.629 Y153.926 F152
G1 X56.663 Y153.875 F152
G1 X56.669 Y153.869 F152
G1 X56.713 Y153.812 F152
G1 X56.721 Y153.802 F152
G1 X56.763 Y153.754 F152
G1 X56.778 Y153.739 F152
G1 X56.822 Y153.697 F152
G1 X56.835 Y153.684 F152
G1 X56.881 Y153.64 F152
G1 X56.892 Y153.629 F152
G1 X56.944 Y153.583 F152
G1 X56.95 Y153.578 F152
G1 X57.007 Y153.533 F152
G1 X57.018 Y153.525 F152
G1 X57.064 Y153.489 F152
G1 X57.122 Y153.445 F152
G1 X57.179 Y153.407 F152
G1 X57.236 Y153.37 F152
G1 X57.262 Y153.353 F152
G1 X57.293 Y153.334 F152
G1 X57.351 Y153.296 F152
G1 X57.58 Y153.171 F152
G1 X57.637 Y153.14 F152
G1 X57.672 Y153.124 F152
G1 X57.694 Y153.114 F152
G1 X57.752 Y153.088 F152
G1 X57.795 Y153.067 F152
G1 X57.809 Y153.061 F152
G1 X57.866 Y153.034 F152
G1 X57.918 Y153.01 F152
G1 X57.924 Y153.007 F152
G1 X58.058 Y152.952 F152
G1 X58.095 Y152.938 F152
G1 X58.201 Y152.895 F152
G1 X58.21 Y152.892 F152
G1 X58.267 Y152.869 F152
G1 X58.325 Y152.849 F152
G1 X58.355 Y152.838 F152
G1 X58.382 Y152.829 F152
G1 X58.439 Y152.809 F152
G1 X58.496 Y152.789 F152
G1 X58.52 Y152.781 F152
G1 X58.611 Y152.749 F152
G1 X58.668 Y152.731 F152
G1 X58.691 Y152.723 F152
G1 X58.726 Y152.714 F152
G1 X58.783 Y152.696 F152
G1 X58.84 Y152.679 F152
G1 X58.88 Y152.666 F152
G1 X58.897 Y152.661 F152
G1 X59.012 Y152.627 F152
G1 X59.069 Y152.611 F152
G1 X59.073 Y152.609 F152
G1 X59.127 Y152.595 F152
G1 X59.184 Y152.579 F152
G1 X59.289 Y152.552 F152
G1 X59.298 Y152.549 F152
G1 X59.413 Y152.518 F152
G1 X59.47 Y152.504 F152
G1 X59.511 Y152.494 F152
G1 X59.528 Y152.491 F152
G1 X59.699 Y152.45 F152
G1 X59.754 Y152.437 F152
G1 X59.757 F152
G1 X59.871 Y152.41 F152
G1 X59.986 Y152.385 F152
G1 X60.011 Y152.38 F152
G1 X60.043 Y152.373 F152
G1 X60.1 Y152.361 F152
G1 X60.215 Y152.338 F152
G1 X60.272 Y152.325 F152
G1 X60.284 Y152.322 F152
G1 X60.33 Y152.313 F152
G1 X60.387 Y152.303 F152
G1 X60.444 Y152.291 F152
G1 X60.559 Y152.27 F152
G1 X60.582 Y152.265 F152
G1 X60.616 Y152.259 F152
G1 X60.788 Y152.227 F152
G1 X60.845 Y152.218 F152
G1 X60.901 Y152.208 F152
G1 X60.902 F152
G1 X60.96 Y152.199 F152
G1 X61.074 Y152.179 F152
G1 X61.132 Y152.17 F152
G1 X61.189 Y152.16 F152
G1 X61.246 Y152.151 F152
G1 X61.249 F152
G1 X61.303 Y152.142 F152
G1 X61.361 Y152.133 F152
G1 X61.418 Y152.123 F152
G1 X61.475 Y152.114 F152
G1 X61.533 Y152.104 F152
G1 X61.59 Y152.095 F152
G1 X61.597 Y152.093 F152
G1 X61.647 Y152.085 F152
G1 X61.762 Y152.067 F152
G1 X61.934 Y152.043 F152
G1 X61.98 Y152.036 F152
G1 X61.991 Y152.035 F152
G1 X62.048 Y152.027 F152
G1 X62.105 Y152.018 F152
G1 X62.335 Y151.986 F152
G1 X62.38 Y151.979 F152
G1 X62.392 Y151.978 F152
G1 X62.449 Y151.969 F152
G1 X62.678 Y151.937 F152
G1 X62.736 Y151.93 F152
G1 X62.791 Y151.921 F152
G1 X62.793 F152
G1 X62.85 Y151.914 F152
G1 X62.907 Y151.906 F152
G1 X62.965 Y151.899 F152
G1 X63.022 Y151.891 F152
G1 X63.079 Y151.884 F152
G1 X63.137 Y151.876 F152
G1 X63.194 Y151.869 F152
G1 X63.222 Y151.864 F152
G1 X63.251 Y151.861 F152
G1 X63.308 Y151.853 F152
G1 X63.366 Y151.845 F152
G1 X63.423 Y151.838 F152
G1 X63.48 Y151.83 F152
G1 X63.538 Y151.823 F152
G1 X63.595 Y151.815 F152
G1 X63.652 Y151.808 F152
G1 X63.654 Y151.807 F152
G1 X63.709 Y151.8 F152
G1 X63.767 Y151.793 F152
G1 X63.824 Y151.785 F152
G1 X63.939 Y151.77 F152
G1 X63.996 Y151.762 F152
G1 X64.053 Y151.755 F152
G1 X64.087 Y151.75 F152
G1 X64.11 Y151.747 F152
G1 X64.168 Y151.739 F152
G1 X64.225 Y151.732 F152
G1 X64.282 Y151.724 F152
G1 X64.34 Y151.717 F152
G1 X64.454 Y151.7 F152
G1 X64.511 Y151.693 F152
G1 X64.512 Y151.692 F152
G1 X64.569 Y151.685 F152
G1 X64.912 Y151.637 F152
G1 X64.921 Y151.635 F152
G1 X64.97 Y151.629 F152
G1 X65.027 Y151.62 F152
G1 X65.142 Y151.604 F152
G1 X65.199 Y151.595 F152
G1 X65.256 Y151.587 F152
G1 X65.312 Y151.578 F152
G1 X65.313 F152
G1 X65.371 Y151.569 F152
G1 X65.428 Y151.561 F152
G1 X65.6 Y151.534 F152
G1 X65.657 Y151.524 F152
G1 X65.68 Y151.521 F152
G1 X65.714 Y151.515 F152
G1 X65.829 Y151.497 F152
G1 X66.001 Y151.468 F152
G1 X66.026 Y151.463 F152
G1 X66.058 Y151.458 F152
G1 X66.23 Y151.428 F152
G1 X66.287 Y151.418 F152
G1 X66.345 Y151.408 F152
G1 X66.351 Y151.406 F152
G1 X66.402 Y151.397 F152
G1 X66.459 Y151.386 F152
G1 X66.516 Y151.376 F152
G1 X66.574 Y151.365 F152
G1 X66.631 Y151.354 F152
G1 X66.655 Y151.349 F152
G1 X66.746 Y151.332 F152
G1 X66.917 Y151.297 F152
G1 X66.941 Y151.291 F152
G1 X66.975 Y151.285 F152
G1 X67.032 Y151.273 F152
G1 X67.089 Y151.261 F152
G1 X67.204 Y151.236 F152
G1 X67.21 Y151.234 F152
G1 X67.261 Y151.222 F152
G1 X67.318 Y151.21 F152
G1 X67.46 Y151.177 F152
G1 X67.49 Y151.171 F152
G1 X67.605 Y151.144 F152
G1 X67.662 Y151.131 F152
G1 X67.71 Y151.12 F152
G1 X67.719 Y151.118 F152
G1 X67.891 Y151.075 F152
G1 X67.94 Y151.062 F152
G1 X67.949 Y151.061 F152
G1 X68.12 Y151.018 F152
G1 X68.167 Y151.005 F152
G1 X68.292 Y150.974 F152
G1 X68.35 Y150.958 F152
G1 X68.389 Y150.948 F152
G1 X68.407 Y150.943 F152
G1 X68.579 Y150.898 F152
G1 X68.605 Y150.89 F152
G1 X68.636 Y150.882 F152
G1 X68.821 Y150.833 F152
G1 X68.865 Y150.822 F152
G1 X68.98 Y150.792 F152
G1 X69.037 Y150.778 F152
G1 X69.041 Y150.776 F152
G1 X69.094 Y150.762 F152
G1 X69.152 Y150.747 F152
G1 X69.209 Y150.733 F152
G1 X69.263 Y150.719 F152
G1 X69.266 F152
G1 X69.495 Y150.665 F152
G1 X69.51 Y150.661 F152
G1 X69.553 Y150.652 F152
G1 X69.667 Y150.625 F152
G1 X69.724 Y150.613 F152
G1 X69.773 Y150.604 F152
G1 X69.782 Y150.603 F152
G1 X69.896 Y150.582 F152
G1 X69.954 Y150.572 F152
G1 X70.011 Y150.561 F152
G1 X70.068 Y150.551 F152
G1 X70.09 Y150.547 F152
G1 X70.125 Y150.541 F152
G1 X70.526 Y150.497 F152
G1 X70.584 Y150.492 F152
G1 X70.629 Y150.49 F152
G1 X70.641 F152
G1 X70.698 Y150.487 F152
G1 X70.756 Y150.483 F152
G1 X70.813 F152
G1 X70.927 Y150.481 F152
G1 X70.985 F152
G1 X71.214 Y150.489 F152
G1 X71.234 Y150.49 F152
G1 X71.271 Y150.492 F152
G1 X71.328 Y150.497 F152
G1 X71.386 Y150.5 F152
G1 X71.443 Y150.505 F152
G1 X71.5 Y150.51 F152
G1 X71.558 Y150.516 F152
G1 X71.615 Y150.522 F152
G1 X71.672 Y150.528 F152
G1 X71.823 Y150.547 F152
G1 X71.844 Y150.55 F152
G1 X71.901 Y150.558 F152
G1 X71.959 Y150.566 F152
G1 X72.188 Y150.601 F152
G1 X72.206 Y150.604 F152
G1 X72.245 Y150.611 F152
G1 X72.36 Y150.631 F152
G1 X72.417 Y150.642 F152
G1 X72.474 Y150.652 F152
G1 X72.531 Y150.661 F152
G1 Y150.662 F152
G1 X72.589 Y150.673 F152
G1 X72.646 Y150.685 F152
G1 X72.703 Y150.695 F152
G1 X72.761 Y150.707 F152
G1 X72.818 Y150.718 F152
G1 X72.824 Y150.719 F152
G1 X72.875 Y150.729 F152
G1 X72.932 Y150.74 F152
G1 X72.99 Y150.752 F152
G1 X73.047 Y150.762 F152
G1 X73.104 Y150.774 F152
G1 X73.117 Y150.776 F152
G1 X73.162 Y150.785 F152
G1 X73.333 Y150.82 F152
G1 X73.391 Y150.83 F152
G1 X73.563 Y150.865 F152
G1 X73.62 Y150.876 F152
G1 X73.677 Y150.888 F152
G1 X73.691 Y150.89 F152
G1 X73.734 Y150.899 F152
G1 X73.792 Y150.911 F152
G1 X73.964 Y150.943 F152
G1 X73.991 Y150.948 F152
G1 X74.021 Y150.953 F152
G1 X74.25 Y150.996 F152
G1 X74.303 Y151.005 F152
G1 X74.307 Y151.006 F152
G1 X74.479 Y151.038 F152
G1 X74.536 Y151.048 F152
G1 X74.594 Y151.057 F152
G1 X74.631 Y151.062 F152
G1 X74.651 Y151.066 F152
G1 X74.708 Y151.074 F152
G1 X74.88 Y151.101 F152
G1 X74.937 Y151.109 F152
G1 X74.995 Y151.118 F152
G1 X75.01 Y151.12 F152
G1 X75.052 Y151.127 F152
G1 X75.109 Y151.135 F152
G1 X75.224 Y151.153 F152
G1 X75.281 Y151.161 F152
G1 X75.396 Y151.175 F152
G1 X75.417 Y151.177 F152
G1 X75.51 Y151.188 F152
G1 X75.568 Y151.195 F152
G1 X75.625 Y151.202 F152
G1 X75.682 Y151.208 F152
G1 X75.911 Y151.23 F152
G1 X75.963 Y151.234 F152
G1 X75.969 Y151.235 F152
G1 X76.083 Y151.246 F152
G1 X76.484 Y151.271 F152
G1 X76.541 Y151.274 F152
G1 X76.713 Y151.279 F152
G1 X76.771 Y151.282 F152
G1 X76.885 Y151.285 F152
G1 X76.942 F152
G1 X77 Y151.286 F152
G1 X77.172 F152
G1 X77.229 Y151.287 F152
G1 X77.286 F152
G1 X77.343 Y151.285 F152
G1 X77.401 Y151.284 F152
G1 X77.573 Y151.279 F152
G1 X77.63 Y151.278 F152
G1 X77.687 Y151.276 F152
G1 X77.744 Y151.274 F152
G1 X77.859 Y151.266 F152
G1 X77.916 Y151.264 F152
G1 X78.088 Y151.253 F152
G1 X78.203 Y151.244 F152
G1 X78.26 Y151.239 F152
G1 X78.306 Y151.234 F152
G1 X78.375 Y151.229 F152
G1 X78.489 Y151.218 F152
G1 X78.604 Y151.205 F152
G1 X78.661 Y151.198 F152
G1 X78.718 Y151.192 F152
G1 X78.776 Y151.185 F152
G1 X78.833 Y151.179 F152
G1 X78.844 Y151.177 F152
G1 X78.89 Y151.171 F152
G1 X79.234 Y151.123 F152
G1 X79.254 Y151.12 F152
G1 X79.291 Y151.114 F152
G1 X79.348 Y151.104 F152
G1 X79.406 Y151.095 F152
G1 X79.52 Y151.076 F152
G1 X79.578 Y151.067 F152
G1 X79.601 Y151.062 F152
G1 X79.635 Y151.057 F152
G1 X79.749 Y151.035 F152
G1 X79.807 Y151.026 F152
G1 X79.864 Y151.015 F152
G1 X79.913 Y151.005 F152
G1 X79.921 Y151.004 F152
G1 X79.979 Y150.993 F152
G1 X80.38 Y150.912 F152
G1 X80.478 Y150.89 F152
G1 X80.494 Y150.888 F152
G1 X80.609 Y150.863 F152
G1 X80.666 Y150.851 F152
G1 X80.723 Y150.839 F152
G1 X80.744 Y150.833 F152
G1 X80.952 Y150.788 F152
G1 X81.005 Y150.776 F152
G1 X81.01 Y150.775 F152
G1 X81.267 Y150.719 F152
G1 X81.296 Y150.713 F152
G1 X81.411 Y150.688 F152
G1 X81.525 Y150.665 F152
G1 X81.541 Y150.661 F152
G1 X81.583 Y150.653 F152
G1 X81.64 Y150.643 F152
G1 X81.697 Y150.631 F152
G1 X81.812 Y150.611 F152
G1 X81.848 Y150.604 F152
G1 X81.869 Y150.601 F152
G1 X81.926 Y150.592 F152
G1 X82.041 Y150.575 F152
G1 X82.098 Y150.568 F152
G1 X82.213 Y150.558 F152
G1 X82.27 Y150.554 F152
G1 X82.327 Y150.551 F152
G1 X82.385 Y150.55 F152
G1 X82.442 Y150.552 F152
G1 X82.499 Y150.555 F152
G1 X82.556 Y150.561 F152
G1 X82.614 Y150.571 F152
G1 X82.671 Y150.583 F152
G1 X82.728 Y150.593 F152
G1 X82.783 Y150.604 F152
G1 X82.786 Y150.605 F152
G1 X82.843 Y150.619 F152
G1 X83.187 Y150.711 F152
G1 X83.219 Y150.719 F152
G1 X83.244 Y150.726 F152
G1 X83.301 Y150.74 F152
G1 X83.358 Y150.754 F152
G1 X83.416 Y150.766 F152
G1 X83.461 Y150.776 F152
G1 X83.473 Y150.779 F152
G1 X83.588 Y150.8 F152
G1 X83.645 Y150.812 F152
G1 X83.702 Y150.82 F152
G1 X83.759 Y150.829 F152
G1 X83.79 Y150.833 F152
G1 X83.817 Y150.838 F152
G1 X83.931 Y150.852 F152
G1 X84.046 Y150.865 F152
G1 X84.103 Y150.87 F152
G1 X84.218 Y150.879 F152
G1 X84.275 Y150.882 F152
G1 X84.447 Y150.89 F152
G1 X84.458 F152
G1 X84.504 Y150.893 F152
G1 X84.676 Y150.896 F152
G1 X84.791 F152
G1 X85.02 Y150.892 F152
G1 X85.069 Y150.89 F152
G1 X85.077 F152
G1 X85.134 Y150.889 F152
G1 X85.192 Y150.886 F152
G1 X85.249 Y150.884 F152
G1 X85.306 Y150.882 F152
G1 X85.535 Y150.867 F152
G1 X85.593 Y150.865 F152
G1 X85.65 Y150.859 F152
G1 X85.879 Y150.841 F152
G1 X85.936 Y150.836 F152
G1 X85.964 Y150.833 F152
G1 X85.994 Y150.83 F152
G1 X86.223 Y150.809 F152
G1 X86.509 Y150.778 F152
G1 X86.521 Y150.776 F152
G1 X86.566 Y150.771 F152
G1 X86.738 Y150.75 F152
G1 X86.796 Y150.744 F152
G1 X86.91 Y150.729 F152
G1 X86.967 Y150.721 F152
G1 X86.987 Y150.719 F152
G1 X87.025 Y150.714 F152
G1 X87.082 Y150.706 F152
G1 X87.139 Y150.699 F152
G1 X87.197 Y150.691 F152
G1 X87.254 Y150.684 F152
G1 X87.311 Y150.676 F152
G1 X87.368 Y150.669 F152
G1 X87.426 Y150.66 F152
G1 X87.54 Y150.646 F152
G1 X87.598 Y150.638 F152
G1 X87.655 Y150.629 F152
G1 X87.827 Y150.605 F152
G1 X87.83 Y150.604 F152
G1 X87.884 Y150.597 F152
G1 X87.941 Y150.589 F152
G1 X87.999 Y150.58 F152
G1 X88.228 Y150.548 F152
G1 X88.23 Y150.547 F152
G1 X88.285 Y150.54 F152
G1 X88.342 Y150.531 F152
G1 X88.457 Y150.515 F152
G1 X88.514 Y150.506 F152
G1 X88.571 Y150.498 F152
G1 X88.622 Y150.49 F152
G1 X88.743 Y150.473 F152
G1 X88.801 Y150.464 F152
G1 X88.915 Y150.447 F152
G1 X88.972 Y150.439 F152
G1 X89.014 Y150.432 F152
G1 X89.03 Y150.43 F152
G1 X89.144 Y150.414 F152
G1 X89.202 Y150.405 F152
G1 X89.373 Y150.381 F152
G1 X89.415 Y150.375 F152
G1 X89.431 Y150.373 F152
G1 X89.545 Y150.357 F152
G1 X89.603 Y150.348 F152
G1 X89.774 Y150.324 F152
G1 X89.822 Y150.318 F152
G1 X89.832 Y150.317 F152
G1 X89.889 Y150.31 F152
G1 X89.946 Y150.302 F152
G1 X90.004 Y150.294 F152
G1 X90.061 Y150.286 F152
G1 X90.118 Y150.279 F152
G1 X90.175 Y150.271 F152
G1 X90.233 Y150.264 F152
G1 X90.257 Y150.26 F152
G1 X90.29 Y150.257 F152
G1 X90.347 Y150.249 F152
G1 X90.405 Y150.242 F152
G1 X90.462 Y150.234 F152
G1 X90.691 Y150.208 F152
G1 X90.732 Y150.203 F152
G1 X91.035 Y150.17 F152
G1 X91.092 Y150.163 F152
G1 X91.149 Y150.157 F152
G1 X91.207 Y150.152 F152
G1 X91.264 Y150.147 F152
G1 X91.267 Y150.146 F152
G1 X91.321 Y150.141 F152
G1 X91.436 Y150.131 F152
G1 X91.55 Y150.122 F152
G1 X91.608 Y150.118 F152
G1 X91.722 Y150.109 F152
G1 X91.837 Y150.102 F152
G1 X91.951 Y150.097 F152
G1 X92.009 Y150.093 F152
G1 X92.066 Y150.09 F152
G1 X92.113 Y150.089 F152
G1 X92.123 F152
G1 X92.18 Y150.088 F152
G1 X92.295 Y150.084 F152
G1 X92.352 Y150.083 F152
G1 X92.467 F152
G1 X92.524 Y150.084 F152
G1 X92.581 F152
G1 X92.639 Y150.085 F152
G1 X92.696 Y150.088 F152
G1 X92.727 Y150.089 F152
G1 X92.753 Y150.09 F152
G1 X92.811 Y150.092 F152
G1 X92.868 Y150.096 F152
G1 X92.925 Y150.101 F152
G1 X93.04 Y150.11 F152
G1 X93.097 Y150.117 F152
G1 X93.212 Y150.133 F152
G1 X93.269 Y150.142 F152
G1 X93.287 Y150.146 F152
G1 X93.383 Y150.166 F152
G1 X93.441 Y150.18 F152
G1 X93.498 Y150.196 F152
G1 X93.526 Y150.203 F152
G1 X93.555 Y150.213 F152
G1 X93.613 Y150.234 F152
G1 X93.67 Y150.259 F152
G1 X93.674 Y150.26 F152
G1 X93.727 Y150.286 F152
G1 X93.778 Y150.318 F152
G1 X93.784 Y150.322 F152
G1 X93.813 Y150.344 F152
G1 X93.842 Y150.367 F152
G1 X93.85 Y150.375 F152
G1 X93.899 Y150.429 F152
G1 X93.902 Y150.432 F152
G1 X93.943 Y150.49 F152
G1 X93.956 Y150.51 F152
G1 X93.977 Y150.547 F152
G1 X94.008 Y150.604 F152
G1 X94.014 Y150.616 F152
G1 X94.06 Y150.719 F152
G1 X94.071 Y150.741 F152
G1 X94.087 Y150.776 F152
G1 X94.113 Y150.833 F152
G1 X94.128 Y150.867 F152
G1 X94.138 Y150.89 F152
G1 X94.163 Y150.948 F152
G1 X94.185 Y150.998 F152
G1 X94.188 Y151.005 F152
G1 X94.238 Y151.12 F152
G1 X94.243 Y151.128 F152
G1 X94.268 Y151.177 F152
G1 X94.297 Y151.234 F152
G1 X94.3 Y151.238 F152
G1 X94.328 Y151.291 F152
G1 X94.357 Y151.346 F152
G1 X94.358 Y151.349 F152
G1 X94.389 Y151.406 F152
G1 X94.42 Y151.463 F152
G1 X94.456 Y151.521 F152
G1 X94.472 Y151.545 F152
G1 X94.494 Y151.578 F152
G1 X94.533 Y151.635 F152
G1 X94.574 Y151.692 F152
G1 X94.586 Y151.708 F152
G1 X94.62 Y151.75 F152
G1 X94.667 Y151.807 F152
G1 X94.701 Y151.848 F152
G1 X94.714 Y151.864 F152
G1 X94.758 Y151.909 F152
G1 X94.885 Y152.036 F152
G1 X94.93 Y152.075 F152
G1 X94.953 Y152.093 F152
G1 X94.987 Y152.121 F152
G1 X95.023 Y152.151 F152
G1 X95.045 Y152.168 F152
G1 X95.095 Y152.208 F152
G1 X95.102 Y152.213 F152
G1 X95.159 Y152.252 F152
G1 X95.18 Y152.265 F152
G1 X95.217 Y152.289 F152
G1 X95.268 Y152.322 F152
G1 X95.274 Y152.327 F152
G1 X95.331 Y152.364 F152
G1 X95.388 Y152.395 F152
G1 X95.47 Y152.437 F152
G1 X95.503 Y152.455 F152
G1 X95.56 Y152.484 F152
G1 X95.581 Y152.494 F152
G1 X95.618 Y152.511 F152
G1 X95.675 Y152.535 F152
G1 X95.789 Y152.583 F152
G1 X95.847 Y152.606 F152
G1 X95.875 Y152.617 F152
G1 X95.904 Y152.626 F152
G1 X95.933 Y152.636 F152
G1 X95.94 Y152.637 F152
G1 X95.947 Y152.64 F152
G1 X95.961 Y152.645 F152
G1 X95.976 Y152.65 F152
G1 X95.984 Y152.652 F152
G1 X95.986 Y152.653 F152
G1 X95.988 Y152.654 F152
; MOVEMENT_LINK_TRANSITION
G1 Y152.655 F152
; MOVEMENT_CUTTING
G1 X95.986 F152
G1 X95.983 Y152.654 F152
G1 X95.976 F152
G1 X95.904 Y152.65 F152
G1 X95.875 Y152.649 F152
G1 X95.789 Y152.644 F152
G1 X95.732 Y152.641 F152
G1 X95.618 Y152.639 F152
G1 X95.56 Y152.637 F152
G1 X95.388 Y152.635 F152
G1 X95.274 F152
G1 X95.217 Y152.636 F152
G1 X95.102 F152
G1 X94.93 Y152.638 F152
G1 X94.758 Y152.644 F152
G1 X94.701 Y152.645 F152
G1 X94.586 Y152.648 F152
G1 X94.529 Y152.649 F152
G1 X94.415 Y152.653 F152
G1 X94.357 Y152.654 F152
G1 X94.185 Y152.659 F152
G1 X94.128 Y152.66 F152
G1 X93.956 Y152.665 F152
G1 X93.934 Y152.666 F152
G1 X93.899 Y152.667 F152
G1 X93.842 Y152.668 F152
G1 X93.613 Y152.675 F152
G1 X93.555 F152
G1 X93.498 Y152.676 F152
G1 X93.383 F152
G1 X93.326 Y152.677 F152
G1 X93.212 F152
G1 X93.154 Y152.678 F152
G1 X93.04 F152
G1 X92.982 Y152.679 F152
G1 X92.925 F152
G1 X92.868 Y152.678 F152
G1 X92.524 Y152.667 F152
G1 X92.488 Y152.666 F152
G1 X92.467 Y152.665 F152
G1 X92.352 Y152.662 F152
G1 X92.295 Y152.659 F152
G1 X92.18 Y152.655 F152
G1 X92.066 Y152.646 F152
G1 X92.009 Y152.643 F152
G1 X91.665 Y152.616 F152
G1 X91.608 Y152.612 F152
G1 X91.56 Y152.609 F152
G1 X91.55 Y152.608 F152
G1 X91.493 Y152.603 F152
G1 X91.436 Y152.598 F152
G1 X91.378 Y152.591 F152
G1 X91.207 Y152.572 F152
G1 X91.149 Y152.565 F152
G1 X91.027 Y152.552 F152
G1 X90.977 Y152.545 F152
G1 X90.863 Y152.533 F152
G1 X90.806 Y152.526 F152
G1 X90.748 Y152.519 F152
G1 X90.691 Y152.512 F152
G1 X90.576 Y152.496 F152
G1 X90.557 Y152.494 F152
G1 X90.462 Y152.481 F152
G1 X90.405 Y152.474 F152
G1 X90.175 Y152.441 F152
G1 X90.141 Y152.437 F152
G1 X90.118 Y152.433 F152
G1 X89.946 Y152.409 F152
G1 X89.889 Y152.402 F152
G1 X89.774 Y152.386 F152
G1 X89.727 Y152.38 F152
G1 X89.717 Y152.378 F152
G1 X89.545 Y152.356 F152
G1 X89.488 Y152.35 F152
G1 X89.373 Y152.336 F152
G1 X89.259 Y152.325 F152
G1 X89.227 Y152.322 F152
G1 X89.202 Y152.32 F152
G1 X89.144 Y152.315 F152
G1 X89.087 Y152.312 F152
G1 X88.972 Y152.306 F152
G1 X88.858 F152
G1 X88.801 Y152.307 F152
G1 X88.686 Y152.314 F152
G1 X88.629 Y152.322 F152
G1 X88.625 F152
G1 X88.571 Y152.33 F152
G1 X88.514 Y152.34 F152
G1 X88.457 Y152.355 F152
G1 X88.4 Y152.372 F152
G1 X88.374 Y152.38 F152
G1 X88.342 Y152.39 F152
G1 X88.285 Y152.414 F152
G1 X88.238 Y152.437 F152
G1 X88.228 Y152.442 F152
G1 X88.17 Y152.473 F152
G1 X88.135 Y152.494 F152
G1 X88.113 Y152.509 F152
G1 X88.057 Y152.552 F152
G1 X88.056 F152
G1 X87.999 Y152.603 F152
G1 X87.992 Y152.609 F152
G1 X87.941 Y152.66 F152
G1 X87.936 Y152.666 F152
G1 X87.888 Y152.723 F152
G1 X87.884 Y152.73 F152
G1 X87.85 Y152.781 F152
G1 X87.827 Y152.82 F152
G1 X87.786 Y152.895 F152
G1 X87.769 Y152.933 F152
G1 X87.761 Y152.952 F152
G1 X87.742 Y153.01 F152
G1 X87.726 Y153.067 F152
G1 X87.713 Y153.124 F152
G1 X87.703 Y153.182 F152
G1 X87.697 Y153.239 F152
G1 X87.695 Y153.296 F152
G1 Y153.353 F152
G1 X87.697 Y153.411 F152
G1 X87.703 Y153.468 F152
G1 X87.712 Y153.525 F152
G1 X87.722 Y153.583 F152
G1 X87.749 Y153.697 F152
G1 X87.766 Y153.754 F152
G1 X87.769 Y153.764 F152
G1 X87.784 Y153.812 F152
G1 X87.803 Y153.869 F152
G1 X87.823 Y153.926 F152
G1 X87.827 Y153.937 F152
G1 X87.844 Y153.983 F152
G1 X87.864 Y154.041 F152
G1 X87.884 Y154.093 F152
G1 X87.886 Y154.098 F152
G1 X87.927 Y154.213 F152
G1 X87.941 Y154.253 F152
G1 X87.948 Y154.27 F152
G1 X87.987 Y154.384 F152
G1 X87.999 Y154.418 F152
G1 X88.023 Y154.499 F152
G1 X88.041 Y154.556 F152
G1 X88.056 Y154.607 F152
G1 X88.058 Y154.614 F152
G1 X88.073 Y154.671 F152
G1 X88.1 Y154.785 F152
G1 X88.113 Y154.841 F152
G1 Y154.843 F152
G1 X88.127 Y154.9 F152
G1 X88.135 Y154.957 F152
G1 X88.144 Y155.014 F152
G1 X88.152 Y155.072 F152
G1 X88.161 Y155.129 F152
G1 X88.166 Y155.186 F152
G1 X88.169 Y155.244 F152
G1 X88.17 Y155.263 F152
G1 X88.172 Y155.301 F152
G1 X88.176 Y155.358 F152
G1 X88.178 Y155.415 F152
G1 X88.177 Y155.43 F152
G1 Y155.432 F152
; MOVEMENT_LINK_TRANSITION
G1 X88.174 Y155.433 F152
; MOVEMENT_CUTTING
G1 X88.171 Y155.43 F152
G1 X88.17 Y155.428 F152
G1 X88.162 Y155.415 F152
G1 X88.131 Y155.358 F152
G1 X88.113 Y155.326 F152
G1 X88.1 Y155.301 F152
G1 X88.069 Y155.244 F152
G1 X88.056 Y155.22 F152
G1 X88.038 Y155.186 F152
G1 X88.012 Y155.129 F152
G1 X87.999 Y155.098 F152
G1 X87.988 Y155.072 F152
G1 X87.963 Y155.014 F152
G1 X87.941 Y154.964 F152
G1 X87.939 Y154.957 F152
G1 X87.916 Y154.9 F152
G1 X87.897 Y154.843 F152
G1 X87.884 Y154.805 F152
G1 X87.878 Y154.785 F152
G1 X87.838 Y154.671 F152
G1 X87.827 Y154.63 F152
G1 X87.823 Y154.614 F152
G1 X87.791 Y154.499 F152
G1 X87.776 Y154.442 F152
G1 X87.769 Y154.422 F152
G1 X87.76 Y154.384 F152
G1 X87.746 Y154.327 F152
G1 X87.712 Y154.191 F152
G1 X87.704 Y154.155 F152
G1 X87.689 Y154.098 F152
G1 X87.675 Y154.041 F152
G1 X87.659 Y153.983 F152
G1 X87.655 Y153.967 F152
G1 X87.644 Y153.926 F152
G1 X87.63 Y153.869 F152
G1 X87.614 Y153.812 F152
G1 X87.598 Y153.763 F152
G1 X87.595 Y153.754 F152
G1 X87.577 Y153.697 F152
G1 X87.558 Y153.64 F152
G1 X87.54 Y153.586 F152
G1 X87.539 Y153.583 F152
G1 X87.516 Y153.525 F152
G1 X87.492 Y153.468 F152
G1 X87.483 Y153.447 F152
G1 X87.469 Y153.411 F152
G1 X87.444 Y153.353 F152
G1 X87.426 Y153.314 F152
G1 X87.417 Y153.296 F152
G1 X87.352 Y153.182 F152
G1 X87.321 Y153.124 F152
G1 X87.311 Y153.107 F152
G1 X87.287 Y153.067 F152
G1 X87.254 Y153.019 F152
G1 X87.248 Y153.01 F152
G1 X87.162 Y152.895 F152
G1 X87.139 Y152.866 F152
G1 X87.119 Y152.838 F152
G1 X87.082 Y152.795 F152
G1 X87.069 Y152.781 F152
G1 X87.025 Y152.735 F152
G1 X87.013 Y152.723 F152
G1 X86.967 Y152.677 F152
G1 X86.957 Y152.666 F152
G1 X86.91 Y152.619 F152
G1 X86.9 Y152.609 F152
G1 X86.853 Y152.566 F152
G1 X86.836 Y152.552 F152
G1 X86.796 Y152.52 F152
G1 X86.762 Y152.494 F152
G1 X86.738 Y152.475 F152
G1 X86.681 Y152.431 F152
G1 X86.624 Y152.387 F152
G1 X86.614 Y152.38 F152
G1 X86.566 Y152.349 F152
G1 X86.521 Y152.322 F152
G1 X86.452 Y152.28 F152
G1 X86.426 Y152.265 F152
G1 X86.395 Y152.246 F152
G1 X86.337 Y152.212 F152
G1 X86.327 Y152.208 F152
G1 X86.28 Y152.185 F152
G1 X86.108 Y152.108 F152
G1 X86.077 Y152.093 F152
G1 X86.051 Y152.082 F152
G1 X85.994 Y152.061 F152
G1 X85.936 Y152.043 F152
G1 X85.914 Y152.036 F152
G1 X85.879 Y152.025 F152
G1 X85.764 Y151.989 F152
G1 X85.729 Y151.979 F152
G1 X85.707 Y151.972 F152
G1 X85.65 Y151.961 F152
G1 X85.478 Y151.931 F152
G1 X85.415 Y151.921 F152
G1 X85.363 Y151.914 F152
G1 X85.306 Y151.911 F152
G1 X85.249 Y151.91 F152
G1 X85.192 F152
G1 X85.077 Y151.908 F152
G1 X85.02 Y151.909 F152
G1 X84.962 Y151.914 F152
G1 X84.908 Y151.921 F152
G1 X84.905 F152
G1 X84.848 Y151.929 F152
G1 X84.791 Y151.938 F152
G1 X84.676 Y151.965 F152
G1 X84.627 Y151.979 F152
G1 X84.619 Y151.981 F152
G1 X84.561 Y152 F152
G1 X84.504 Y152.021 F152
G1 X84.465 Y152.036 F152
G1 X84.447 Y152.043 F152
G1 X84.39 Y152.07 F152
G1 X84.344 Y152.093 F152
G1 X84.332 Y152.099 F152
G1 X84.275 Y152.129 F152
G1 X84.239 Y152.151 F152
G1 X84.218 Y152.165 F152
G1 X84.16 Y152.204 F152
G1 X84.155 Y152.208 F152
G1 X84.103 Y152.245 F152
G1 X84.077 Y152.265 F152
G1 X84.046 Y152.293 F152
G1 X83.989 Y152.344 F152
G1 X83.951 Y152.38 F152
G1 X83.931 Y152.4 F152
G1 X83.899 Y152.437 F152
G1 X83.874 Y152.467 F152
G1 X83.85 Y152.494 F152
G1 X83.817 Y152.535 F152
G1 X83.804 Y152.552 F152
G1 X83.766 Y152.609 F152
G1 X83.759 Y152.62 F152
G1 X83.729 Y152.666 F152
G1 X83.702 Y152.71 F152
G1 X83.694 Y152.723 F152
G1 X83.665 Y152.781 F152
G1 X83.645 Y152.824 F152
G1 X83.638 Y152.838 F152
G1 X83.611 Y152.895 F152
G1 X83.59 Y152.952 F152
G1 X83.588 Y152.96 F152
G1 X83.57 Y153.01 F152
G1 X83.55 Y153.067 F152
G1 X83.534 Y153.124 F152
G1 X83.53 Y153.144 F152
G1 X83.522 Y153.182 F152
G1 X83.497 Y153.296 F152
G1 X83.486 Y153.353 F152
G1 X83.477 Y153.411 F152
G1 X83.474 Y153.468 F152
G1 X83.46 Y153.64 F152
G1 Y153.697 F152
G1 X83.461 Y153.754 F152
G1 X83.467 Y153.869 F152
G1 X83.469 Y153.926 F152
G1 X83.473 Y153.981 F152
G1 Y153.983 F152
G1 X83.48 Y154.041 F152
G1 X83.489 Y154.098 F152
G1 X83.505 Y154.213 F152
G1 X83.514 Y154.27 F152
G1 X83.527 Y154.327 F152
G1 X83.53 Y154.34 F152
G1 X83.54 Y154.384 F152
G1 X83.567 Y154.499 F152
G1 X83.581 Y154.556 F152
G1 X83.588 Y154.577 F152
G1 X83.599 Y154.614 F152
G1 X83.635 Y154.728 F152
G1 X83.645 Y154.759 F152
G1 X83.653 Y154.785 F152
G1 X83.673 Y154.843 F152
G1 X83.695 Y154.9 F152
G1 X83.702 Y154.917 F152
G1 X83.718 Y154.957 F152
G1 X83.741 Y155.014 F152
G1 X83.759 Y155.062 F152
G1 X83.763 Y155.072 F152
G1 X83.789 Y155.129 F152
G1 X83.816 Y155.186 F152
G1 X83.817 Y155.187 F152
G1 X83.844 Y155.244 F152
G1 X83.87 Y155.301 F152
G1 X83.899 Y155.358 F152
G1 X83.93 Y155.415 F152
G1 X83.931 Y155.416 F152
G1 X83.962 Y155.473 F152
G1 X83.989 Y155.52 F152
G1 X83.994 Y155.53 F152
G1 X84.026 Y155.587 F152
G1 X84.046 Y155.618 F152
G1 X84.063 Y155.645 F152
G1 X84.099 Y155.702 F152
G1 X84.103 Y155.708 F152
G1 X84.135 Y155.759 F152
G1 X84.16 Y155.798 F152
G1 X84.213 Y155.874 F152
G1 X84.218 Y155.879 F152
G1 X84.254 Y155.931 F152
G1 X84.296 Y155.988 F152
G1 X84.332 Y156.036 F152
G1 X84.339 Y156.045 F152
G1 X84.385 Y156.103 F152
G1 X84.39 Y156.109 F152
G1 X84.447 Y156.182 F152
G1 X84.478 Y156.217 F152
G1 X84.504 Y156.248 F152
G1 X84.528 Y156.275 F152
G1 X84.578 Y156.332 F152
G1 X84.59 Y156.345 F152
G1 X84.603 Y156.361 F152
G1 X84.604 Y156.362 F152
G1 X84.615 Y156.375 F152
G1 X84.619 Y156.378 F152
G1 X84.628 Y156.389 F152
G1 X84.633 Y156.395 F152
G1 X84.634 Y156.396 F152
; MOVEMENT_LINK_TRANSITION
G1 X84.633 Y156.398 F152
; MOVEMENT_CUTTING
G1 X84.59 Y156.377 F152
G1 X84.561 Y156.363 F152
G1 X84.504 Y156.335 F152
G1 X84.498 Y156.332 F152
G1 X84.447 Y156.305 F152
G1 X84.396 Y156.275 F152
G1 X84.39 Y156.271 F152
G1 X84.332 Y156.236 F152
G1 X84.3 Y156.217 F152
G1 X84.275 Y156.202 F152
G1 X84.218 Y156.168 F152
G1 X84.205 Y156.16 F152
G1 X84.103 Y156.087 F152
G1 X84.053 Y156.045 F152
G1 X84.046 Y156.039 F152
G1 X83.989 Y155.99 F152
G1 X83.987 Y155.988 F152
G1 X83.931 Y155.936 F152
G1 X83.926 Y155.931 F152
G1 X83.874 Y155.875 F152
G1 X83.872 Y155.874 F152
G1 X83.821 Y155.816 F152
G1 X83.817 Y155.811 F152
G1 X83.776 Y155.759 F152
G1 X83.759 Y155.739 F152
G1 X83.733 Y155.702 F152
G1 X83.702 Y155.656 F152
G1 X83.695 Y155.645 F152
G1 X83.658 Y155.587 F152
G1 X83.645 Y155.565 F152
G1 X83.624 Y155.53 F152
G1 X83.592 Y155.473 F152
G1 X83.588 Y155.464 F152
G1 X83.563 Y155.415 F152
G1 X83.533 Y155.358 F152
G1 X83.53 Y155.352 F152
G1 X83.483 Y155.244 F152
G1 X83.473 Y155.222 F152
G1 X83.458 Y155.186 F152
G1 X83.432 Y155.129 F152
G1 X83.416 Y155.092 F152
G1 X83.407 Y155.072 F152
G1 X83.383 Y155.014 F152
G1 X83.36 Y154.957 F152
G1 X83.358 Y154.955 F152
G1 X83.337 Y154.9 F152
G1 X83.315 Y154.843 F152
G1 X83.301 Y154.81 F152
G1 X83.292 Y154.785 F152
G1 X83.269 Y154.728 F152
G1 X83.247 Y154.671 F152
G1 X83.244 Y154.665 F152
G1 X83.223 Y154.614 F152
G1 X83.2 Y154.556 F152
G1 X83.187 Y154.525 F152
G1 X83.177 Y154.499 F152
G1 X83.152 Y154.442 F152
G1 X83.129 Y154.392 F152
G1 X83.101 Y154.327 F152
G1 X83.074 Y154.27 F152
G1 X83.072 Y154.268 F152
G1 X83.016 Y154.155 F152
G1 X83.015 Y154.154 F152
G1 X82.985 Y154.098 F152
G1 X82.957 Y154.051 F152
G1 X82.951 Y154.041 F152
G1 X82.916 Y153.983 F152
G1 X82.9 Y153.958 F152
G1 X82.881 Y153.926 F152
G1 X82.843 Y153.872 F152
G1 X82.84 Y153.869 F152
G1 X82.796 Y153.812 F152
G1 X82.786 Y153.798 F152
G1 X82.752 Y153.754 F152
G1 X82.728 Y153.726 F152
G1 X82.702 Y153.697 F152
G1 X82.671 Y153.666 F152
G1 X82.643 Y153.64 F152
G1 X82.614 Y153.611 F152
G1 X82.583 Y153.583 F152
G1 X82.556 Y153.557 F152
G1 X82.517 Y153.525 F152
G1 X82.499 Y153.512 F152
G1 X82.442 Y153.474 F152
G1 X82.432 Y153.468 F152
G1 X82.385 Y153.438 F152
G1 X82.34 Y153.411 F152
G1 X82.327 Y153.403 F152
G1 X82.27 Y153.373 F152
G1 X82.224 Y153.353 F152
G1 X82.213 Y153.349 F152
G1 X82.098 Y153.31 F152
G1 X82.041 Y153.292 F152
G1 X81.984 Y153.277 F152
G1 X81.926 Y153.268 F152
G1 X81.869 Y153.262 F152
G1 X81.754 Y153.255 F152
G1 X81.697 Y153.253 F152
G1 X81.64 Y153.256 F152
G1 X81.583 Y153.263 F152
G1 X81.525 Y153.273 F152
G1 X81.468 Y153.282 F152
G1 X81.411 Y153.293 F152
G1 X81.399 Y153.296 F152
G1 X81.353 Y153.309 F152
G1 X81.296 Y153.327 F152
G1 X81.239 Y153.348 F152
G1 X81.225 Y153.353 F152
G1 X81.182 Y153.371 F152
G1 X81.124 Y153.398 F152
G1 X81.1 Y153.411 F152
G1 X81.067 Y153.427 F152
G1 X81.01 Y153.458 F152
G1 X80.994 Y153.468 F152
G1 X80.952 Y153.494 F152
G1 X80.904 Y153.525 F152
G1 X80.895 Y153.531 F152
G1 X80.838 Y153.573 F152
G1 X80.825 Y153.583 F152
G1 X80.781 Y153.617 F152
G1 X80.752 Y153.64 F152
G1 X80.723 Y153.664 F152
G1 X80.689 Y153.697 F152
G1 X80.666 Y153.719 F152
G1 X80.609 Y153.777 F152
G1 X80.573 Y153.812 F152
G1 X80.551 Y153.833 F152
G1 X80.517 Y153.869 F152
G1 X80.494 Y153.894 F152
G1 X80.468 Y153.926 F152
G1 X80.437 Y153.967 F152
G1 X80.424 Y153.983 F152
G1 X80.381 Y154.041 F152
G1 X80.38 Y154.043 F152
G1 X80.322 Y154.12 F152
G1 X80.296 Y154.155 F152
G1 X80.265 Y154.206 F152
G1 X80.229 Y154.27 F152
G1 X80.208 Y154.307 F152
G1 X80.197 Y154.327 F152
G1 X80.165 Y154.384 F152
G1 X80.15 Y154.409 F152
G1 X80.133 Y154.442 F152
G1 X80.104 Y154.499 F152
G1 X80.093 Y154.526 F152
G1 X80.081 Y154.556 F152
G1 X80.058 Y154.614 F152
G1 X80.036 Y154.669 F152
G1 X80.035 Y154.671 F152
G1 X80.012 Y154.728 F152
G1 X79.989 Y154.785 F152
G1 X79.979 Y154.818 F152
G1 X79.971 Y154.843 F152
G1 X79.942 Y154.957 F152
G1 X79.927 Y155.014 F152
G1 X79.921 Y155.039 F152
G1 X79.912 Y155.072 F152
G1 X79.898 Y155.129 F152
G1 X79.886 Y155.186 F152
G1 X79.879 Y155.244 F152
G1 X79.867 Y155.358 F152
G1 X79.864 Y155.385 F152
G1 X79.86 Y155.415 F152
G1 X79.854 Y155.473 F152
G1 X79.849 Y155.53 F152
G1 X79.847 Y155.587 F152
G1 X79.854 Y155.816 F152
G1 X79.855 Y155.874 F152
G1 X79.86 Y155.931 F152
G1 X79.864 Y155.959 F152
G1 X79.868 Y155.988 F152
G1 X79.871 Y156.003 F152
G1 X79.876 Y156.029 F152
G1 Y156.031 F152
; MOVEMENT_LINK_TRANSITION
G1 Y156.036 F152
; MOVEMENT_CUTTING
G1 Y156.035 F152
G1 X79.871 Y156.028 F152
G1 X79.869 Y156.024 F152
G1 X79.864 Y156.016 F152
G1 X79.848 Y155.988 F152
G1 X79.835 Y155.969 F152
G1 X79.813 Y155.931 F152
G1 X79.807 Y155.921 F152
G1 X79.778 Y155.874 F152
G1 X79.749 Y155.832 F152
G1 X79.74 Y155.816 F152
G1 X79.702 Y155.759 F152
G1 X79.692 Y155.745 F152
G1 X79.635 Y155.659 F152
G1 X79.626 Y155.645 F152
G1 X79.587 Y155.587 F152
G1 X79.578 Y155.572 F152
G1 X79.55 Y155.53 F152
G1 X79.51 Y155.473 F152
G1 X79.466 Y155.415 F152
G1 X79.463 Y155.412 F152
G1 X79.421 Y155.358 F152
G1 X79.406 Y155.338 F152
G1 X79.377 Y155.301 F152
G1 X79.348 Y155.266 F152
G1 X79.329 Y155.244 F152
G1 X79.291 Y155.202 F152
G1 X79.277 Y155.186 F152
G1 X79.224 Y155.129 F152
G1 X79.177 Y155.078 F152
G1 X79.171 Y155.072 F152
G1 X79.119 Y155.024 F152
G1 X79.108 Y155.014 F152
G1 X79.062 Y154.974 F152
G1 X79.042 Y154.957 F152
G1 X79.005 Y154.925 F152
G1 X78.976 Y154.9 F152
G1 X78.947 Y154.878 F152
G1 X78.89 Y154.839 F152
G1 X78.833 Y154.803 F152
G1 X78.803 Y154.785 F152
G1 X78.776 Y154.768 F152
G1 X78.718 Y154.733 F152
G1 X78.661 Y154.705 F152
G1 X78.604 Y154.681 F152
G1 X78.546 Y154.657 F152
G1 X78.489 Y154.638 F152
G1 X78.432 Y154.622 F152
G1 X78.398 Y154.614 F152
G1 X78.375 Y154.607 F152
G1 X78.317 Y154.597 F152
G1 X78.26 Y154.588 F152
G1 X78.203 Y154.582 F152
G1 X78.145 Y154.579 F152
G1 X78.088 Y154.58 F152
G1 X78.031 Y154.582 F152
G1 X77.974 Y154.587 F152
G1 X77.916 Y154.595 F152
G1 X77.859 Y154.607 F152
G1 X77.831 Y154.614 F152
G1 X77.802 Y154.62 F152
G1 X77.744 Y154.636 F152
G1 X77.687 Y154.657 F152
G1 X77.63 Y154.681 F152
G1 X77.573 Y154.707 F152
G1 X77.531 Y154.728 F152
G1 X77.515 Y154.738 F152
G1 X77.458 Y154.772 F152
G1 X77.437 Y154.785 F152
G1 X77.401 Y154.81 F152
G1 X77.358 Y154.843 F152
G1 X77.343 Y154.854 F152
G1 X77.288 Y154.9 F152
G1 X77.286 Y154.902 F152
G1 X77.228 Y154.957 F152
G1 X77.173 Y155.014 F152
G1 X77.172 Y155.016 F152
G1 X77.123 Y155.072 F152
G1 X77.114 Y155.084 F152
G1 X77.08 Y155.129 F152
G1 X77.057 Y155.16 F152
G1 X77.038 Y155.186 F152
G1 X77.002 Y155.244 F152
G1 X77 Y155.249 F152
G1 X76.971 Y155.301 F152
G1 X76.942 Y155.355 F152
G1 X76.94 Y155.358 F152
G1 X76.909 Y155.415 F152
G1 X76.885 Y155.462 F152
G1 X76.88 Y155.473 F152
G1 X76.856 Y155.53 F152
G1 X76.836 Y155.587 F152
G1 X76.814 Y155.645 F152
G1 X76.794 Y155.702 F152
G1 X76.778 Y155.759 F152
G1 X76.771 Y155.787 F152
G1 X76.763 Y155.816 F152
G1 X76.734 Y155.931 F152
G1 X76.723 Y155.988 F152
G1 X76.714 Y156.045 F152
G1 X76.713 Y156.057 F152
G1 X76.697 Y156.16 F152
G1 X76.691 Y156.217 F152
G1 X76.684 Y156.332 F152
G1 X76.678 Y156.446 F152
G1 Y156.504 F152
G1 X76.684 Y156.618 F152
G1 X76.686 Y156.676 F152
G1 X76.689 Y156.733 F152
G1 X76.695 Y156.79 F152
G1 X76.703 Y156.847 F152
G1 X76.711 Y156.905 F152
G1 X76.713 Y156.92 F152
G1 X76.719 Y156.962 F152
G1 X76.728 Y157.019 F152
G1 X76.754 Y157.134 F152
G1 X76.767 Y157.191 F152
G1 X76.771 Y157.207 F152
G1 X76.78 Y157.248 F152
G1 X76.797 Y157.306 F152
G1 X76.814 Y157.363 F152
G1 X76.828 Y157.403 F152
G1 X76.851 Y157.477 F152
G1 X76.871 Y157.535 F152
G1 X76.885 Y157.571 F152
G1 X76.894 Y157.592 F152
G1 X76.918 Y157.649 F152
G1 X76.942 Y157.707 F152
G1 X76.966 Y157.764 F152
G1 X76.993 Y157.821 F152
G1 X77 Y157.834 F152
G1 X77.023 Y157.878 F152
G1 X77.053 Y157.936 F152
G1 X77.057 Y157.945 F152
G1 X77.082 Y157.993 F152
G1 X77.112 Y158.05 F152
G1 X77.114 Y158.052 F152
G1 X77.148 Y158.107 F152
G1 X77.172 Y158.145 F152
G1 X77.183 Y158.165 F152
G1 X77.219 Y158.222 F152
G1 X77.229 Y158.238 F152
G1 X77.255 Y158.279 F152
G1 X77.286 Y158.323 F152
G1 X77.295 Y158.337 F152
G1 X77.336 Y158.394 F152
G1 X77.343 Y158.403 F152
G1 X77.377 Y158.451 F152
G1 X77.401 Y158.482 F152
G1 X77.42 Y158.508 F152
G1 X77.513 Y158.623 F152
G1 X77.515 Y158.626 F152
G1 X77.573 Y158.695 F152
G1 X77.607 Y158.738 F152
G1 X77.63 Y158.762 F152
G1 X77.66 Y158.795 F152
G1 X77.687 Y158.824 F152
G1 X77.712 Y158.852 F152
G1 X77.765 Y158.909 F152
G1 X77.802 Y158.949 F152
G1 X77.82 Y158.967 F152
G1 X77.878 Y159.024 F152
G1 X77.916 Y159.062 F152
G1 X77.936 Y159.081 F152
G1 X77.974 Y159.118 F152
G1 X77.994 Y159.139 F152
G1 X78.031 Y159.173 F152
G1 X78.057 Y159.196 F152
G1 X78.119 Y159.253 F152
G1 X78.145 Y159.276 F152
G1 X78.203 Y159.328 F152
G1 X78.249 Y159.368 F152
G1 X78.317 Y159.424 F152
G1 X78.318 Y159.425 F152
G1 X78.375 Y159.471 F152
G1 X78.388 Y159.482 F152
G1 X78.432 Y159.518 F152
G1 X78.489 Y159.565 F152
G1 X78.528 Y159.597 F152
G1 X78.546 Y159.613 F152
G1 X78.597 Y159.654 F152
G1 X78.604 Y159.659 F152
G1 X78.661 Y159.706 F152
G1 X78.718 Y159.749 F152
G1 X78.745 Y159.769 F152
G1 X78.776 Y159.792 F152
G1 X78.821 Y159.826 F152
G1 X78.833 Y159.835 F152
G1 X78.89 Y159.878 F152
G1 X78.898 Y159.883 F152
G1 X78.947 Y159.92 F152
G1 X78.974 Y159.94 F152
G1 X79.005 Y159.963 F152
G1 X79.062 Y160.006 F152
G1 X79.129 Y160.055 F152
G1 X79.177 Y160.088 F152
G1 X79.211 Y160.112 F152
G1 X79.234 Y160.128 F152
G1 X79.291 Y160.17 F152
G1 X79.292 F152
G1 X79.348 Y160.21 F152
G1 X79.463 Y160.29 F152
G1 X79.52 Y160.332 F152
G1 X79.535 Y160.341 F152
G1 X79.578 Y160.371 F152
G1 X79.619 Y160.399 F152
G1 X79.635 Y160.409 F152
G1 X79.692 Y160.449 F152
G1 X79.703 Y160.456 F152
G1 X79.749 Y160.488 F152
G1 X79.786 Y160.513 F152
G1 X79.807 Y160.528 F152
G1 X79.864 Y160.566 F152
G1 X79.87 Y160.57 F152
G1 X79.921 Y160.605 F152
G1 X79.954 Y160.628 F152
G1 X79.979 Y160.645 F152
G1 X80.036 Y160.682 F152
G1 X80.039 Y160.685 F152
G1 X80.093 Y160.721 F152
G1 X80.124 Y160.742 F152
G1 X80.15 Y160.759 F152
G1 X80.21 Y160.8 F152
G1 X80.265 Y160.835 F152
G1 X80.297 Y160.857 F152
G1 X80.322 Y160.873 F152
G1 X80.385 Y160.914 F152
G1 X80.437 Y160.949 F152
G1 X80.494 Y160.986 F152
G1 X80.551 Y161.022 F152
G1 X80.562 Y161.029 F152
G1 X80.653 Y161.086 F152
G1 X80.666 Y161.095 F152
G1 X80.723 Y161.13 F152
G1 X80.746 Y161.143 F152
G1 X80.781 Y161.165 F152
G1 X80.838 Y161.199 F152
G1 X80.841 Y161.201 F152
G1 X80.895 Y161.232 F152
G1 X80.952 Y161.263 F152
G1 X81.01 Y161.294 F152
G1 X81.067 Y161.322 F152
G1 X81.124 Y161.35 F152
G1 X81.177 Y161.372 F152
G1 X81.239 Y161.397 F152
G1 X81.296 Y161.417 F152
G1 X81.337 Y161.43 F152
G1 X81.353 Y161.435 F152
G1 X81.411 Y161.449 F152
G1 X81.468 Y161.459 F152
G1 X81.525 Y161.468 F152
G1 X81.583 Y161.473 F152
G1 X81.64 F152
G1 X81.697 Y161.47 F152
G1 X81.754 Y161.465 F152
G1 X81.812 Y161.455 F152
G1 X81.869 Y161.441 F152
G1 X81.905 Y161.43 F152
G1 X81.926 Y161.422 F152
G1 X81.984 Y161.399 F152
G1 X82.041 Y161.371 F152
G1 X82.098 Y161.338 F152
G1 X82.134 Y161.315 F152
G1 X82.155 Y161.3 F152
G1 X82.206 Y161.258 F152
G1 X82.213 Y161.252 F152
G1 X82.266 Y161.201 F152
G1 X82.313 Y161.143 F152
G1 X82.327 Y161.124 F152
G1 X82.353 Y161.086 F152
G1 X82.385 Y161.037 F152
G1 X82.389 Y161.029 F152
G1 X82.419 Y160.971 F152
G1 X82.442 Y160.914 F152
G1 X82.461 Y160.857 F152
G1 X82.475 Y160.8 F152
G1 X82.487 Y160.742 F152
G1 X82.495 Y160.685 F152
G1 X82.498 Y160.628 F152
G1 X82.497 Y160.57 F152
G1 X82.495 Y160.513 F152
G1 X82.489 Y160.456 F152
G1 X82.479 Y160.399 F152
G1 X82.468 Y160.341 F152
G1 X82.453 Y160.284 F152
G1 X82.442 Y160.248 F152
G1 X82.436 Y160.227 F152
G1 X82.417 Y160.17 F152
G1 X82.395 Y160.112 F152
G1 X82.385 Y160.085 F152
G1 X82.373 Y160.055 F152
G1 X82.348 Y159.998 F152
G1 X82.327 Y159.952 F152
G1 X82.322 Y159.94 F152
G1 X82.295 Y159.883 F152
G1 X82.27 Y159.832 F152
G1 X82.267 Y159.826 F152
G1 X82.238 Y159.769 F152
G1 X82.213 Y159.72 F152
G1 X82.208 Y159.711 F152
G1 X82.177 Y159.654 F152
G1 X82.155 Y159.616 F152
G1 X82.145 Y159.597 F152
G1 X82.082 Y159.482 F152
G1 X82.049 Y159.425 F152
G1 X82.041 Y159.411 F152
G1 X82.015 Y159.368 F152
G1 X81.984 Y159.314 F152
G1 X81.982 Y159.31 F152
G1 X81.948 Y159.253 F152
G1 X81.926 Y159.216 F152
G1 X81.914 Y159.196 F152
G1 X81.869 Y159.124 F152
G1 X81.843 Y159.081 F152
G1 X81.807 Y159.024 F152
G1 X81.772 Y158.967 F152
G1 X81.737 Y158.909 F152
G1 X81.702 Y158.852 F152
G1 X81.697 Y158.846 F152
G1 X81.665 Y158.795 F152
G1 X81.64 Y158.756 F152
G1 X81.628 Y158.738 F152
G1 X81.592 Y158.68 F152
G1 X81.583 Y158.667 F152
G1 X81.554 Y158.623 F152
G1 X81.481 Y158.508 F152
G1 X81.471 Y158.494 F152
G1 X81.468 Y158.49 F152
G1 X81.454 Y158.467 F152
G1 X81.443 Y158.451 F152
G1 X81.439 Y158.445 F152
G1 X81.438 Y158.444 F152
G1 X81.435 Y158.439 F152
G1 X81.433 Y158.436 F152
G1 X81.432 Y158.433 F152
G1 X81.431 Y158.432 F152
G1 X81.43 Y158.431 F152
; MOVEMENT_LINK_TRANSITION
G1 X81.431 F152
; MOVEMENT_CUTTING
G1 X81.433 Y158.433 F152
G1 X81.434 F152
G1 X81.436 Y158.435 F152
G1 X81.447 Y158.444 F152
G1 X81.454 Y158.449 F152
G1 X81.456 Y158.451 F152
G1 X81.468 Y158.46 F152
G1 X81.486 Y158.473 F152
G1 X81.525 Y158.502 F152
G1 X81.533 Y158.508 F152
G1 X81.583 Y158.545 F152
G1 X81.611 Y158.566 F152
G1 X81.64 Y158.587 F152
G1 X81.689 Y158.623 F152
G1 X81.697 Y158.629 F152
G1 X81.754 Y158.668 F152
G1 X81.773 Y158.68 F152
G1 X81.812 Y158.707 F152
G1 X81.857 Y158.738 F152
G1 X81.869 Y158.746 F152
G1 X81.926 Y158.784 F152
G1 X81.945 Y158.795 F152
G1 X82.04 Y158.852 F152
G1 X82.041 Y158.853 F152
G1 X82.136 Y158.909 F152
G1 X82.155 Y158.922 F152
G1 X82.213 Y158.956 F152
G1 X82.231 Y158.967 F152
G1 X82.27 Y158.991 F152
G1 X82.325 Y159.024 F152
G1 X82.327 Y159.025 F152
G1 X82.385 Y159.058 F152
G1 X82.431 Y159.081 F152
G1 X82.442 Y159.087 F152
G1 X82.499 Y159.117 F152
G1 X82.542 Y159.139 F152
G1 X82.556 Y159.147 F152
G1 X82.614 Y159.176 F152
G1 X82.653 Y159.196 F152
G1 X82.671 Y159.206 F152
G1 X82.728 Y159.235 F152
G1 X82.764 Y159.253 F152
G1 X82.786 Y159.265 F152
G1 X82.843 Y159.292 F152
G1 X82.885 Y159.31 F152
G1 X82.9 Y159.318 F152
G1 X82.957 Y159.343 F152
G1 X83.013 Y159.368 F152
G1 X83.015 Y159.369 F152
G1 X83.072 Y159.394 F152
G1 X83.129 Y159.42 F152
G1 X83.142 Y159.425 F152
G1 X83.187 Y159.445 F152
G1 X83.244 Y159.471 F152
G1 X83.271 Y159.482 F152
G1 X83.301 Y159.495 F152
G1 X83.416 Y159.539 F152
G1 X83.417 F152
G1 X83.473 Y159.562 F152
G1 X83.53 Y159.584 F152
G1 X83.563 Y159.597 F152
G1 X83.588 Y159.607 F152
G1 X83.702 Y159.651 F152
G1 X83.709 Y159.654 F152
G1 X83.759 Y159.672 F152
G1 X83.817 Y159.693 F152
G1 X83.872 Y159.711 F152
G1 X83.874 Y159.712 F152
G1 X83.931 Y159.732 F152
G1 X83.989 Y159.752 F152
G1 X84.037 Y159.769 F152
G1 X84.046 Y159.772 F152
G1 X84.103 Y159.792 F152
G1 X84.16 Y159.812 F152
G1 X84.202 Y159.826 F152
G1 X84.218 Y159.831 F152
G1 X84.332 Y159.867 F152
G1 X84.385 Y159.883 F152
G1 X84.39 Y159.885 F152
G1 X84.561 Y159.939 F152
G1 X84.569 Y159.94 F152
G1 X84.619 Y159.957 F152
G1 X84.676 Y159.974 F152
G1 X84.733 Y159.991 F152
G1 X84.76 Y159.998 F152
G1 X84.791 Y160.007 F152
G1 X84.962 Y160.055 F152
G1 X84.964 F152
G1 X85.02 Y160.071 F152
G1 X85.077 Y160.087 F152
G1 X85.134 Y160.102 F152
G1 X85.192 Y160.118 F152
G1 X85.306 Y160.147 F152
G1 X85.363 Y160.161 F152
G1 X85.4 Y160.17 F152
G1 X85.421 Y160.175 F152
G1 X85.535 Y160.204 F152
G1 X85.593 Y160.217 F152
G1 X85.633 Y160.227 F152
G1 X85.65 Y160.231 F152
G1 X85.707 Y160.246 F152
G1 X85.822 Y160.269 F152
G1 X85.879 Y160.281 F152
G1 X85.895 Y160.284 F152
G1 X85.936 Y160.293 F152
G1 X86.051 Y160.316 F152
G1 X86.108 Y160.329 F152
G1 X86.165 Y160.34 F152
G1 X86.172 Y160.341 F152
G1 X86.223 Y160.352 F152
G1 X86.28 Y160.363 F152
G1 X86.337 Y160.373 F152
G1 X86.504 Y160.399 F152
G1 X86.566 Y160.409 F152
G1 X86.738 Y160.436 F152
G1 X86.796 Y160.446 F152
G1 X86.853 Y160.453 F152
G1 X86.881 Y160.456 F152
G1 X86.91 Y160.459 F152
G1 X86.967 Y160.465 F152
G1 X87.025 Y160.471 F152
G1 X87.082 Y160.476 F152
G1 X87.139 Y160.483 F152
G1 X87.197 Y160.488 F152
G1 X87.311 Y160.501 F152
G1 X87.368 Y160.506 F152
G1 X87.426 Y160.51 F152
G1 X87.483 Y160.513 F152
G1 X87.492 F152
G1 X87.54 Y160.516 F152
G1 X87.598 Y160.519 F152
G1 X87.655 Y160.522 F152
G1 X87.712 Y160.524 F152
G1 X87.769 Y160.525 F152
G1 X87.827 F152
G1 X87.941 Y160.527 F152
G1 X87.999 Y160.526 F152
G1 X88.228 Y160.519 F152
G1 X88.285 Y160.516 F152
G1 X88.31 Y160.513 F152
G1 X88.342 Y160.511 F152
G1 X88.457 Y160.502 F152
G1 X88.571 Y160.492 F152
G1 X88.629 Y160.485 F152
G1 X88.686 Y160.476 F152
G1 X88.801 Y160.462 F152
G1 X88.915 Y160.442 F152
G1 X88.972 Y160.432 F152
G1 X89.03 Y160.422 F152
G1 X89.087 Y160.411 F152
G1 X89.14 Y160.399 F152
G1 X89.144 Y160.398 F152
G1 X89.259 Y160.371 F152
G1 X89.316 Y160.357 F152
G1 X89.373 Y160.343 F152
G1 X89.379 Y160.341 F152
G1 X89.431 Y160.328 F152
G1 X89.545 Y160.294 F152
G1 X89.576 Y160.284 F152
G1 X89.603 Y160.276 F152
G1 X89.66 Y160.259 F152
G1 X89.717 Y160.241 F152
G1 X89.757 Y160.227 F152
G1 X89.774 Y160.221 F152
G1 X89.832 Y160.201 F152
G1 X89.889 Y160.181 F152
G1 X89.92 Y160.17 F152
G1 X89.946 Y160.161 F152
G1 X90.004 Y160.14 F152
G1 X90.061 Y160.118 F152
G1 X90.073 Y160.112 F152
G1 X90.118 Y160.095 F152
G1 X90.221 Y160.055 F152
G1 X90.233 Y160.05 F152
G1 X90.347 Y160.006 F152
G1 X90.366 Y159.998 F152
G1 X90.405 Y159.982 F152
G1 X90.462 Y159.961 F152
G1 X90.516 Y159.94 F152
G1 X90.519 F152
G1 X90.634 Y159.898 F152
G1 X90.686 Y159.883 F152
G1 X90.691 Y159.882 F152
G1 X90.748 Y159.865 F152
G1 X90.806 Y159.854 F152
G1 X90.863 Y159.846 F152
G1 X90.92 F152
G1 X90.931 F152
G1 X90.949 Y159.851 F152
G1 X90.977 Y159.862 F152
G1 X91.018 Y159.883 F152
G1 X91.035 Y159.894 F152
G1 X91.092 Y159.933 F152
G1 X91.101 Y159.94 F152
G1 X91.149 Y159.981 F152
G1 X91.168 Y159.998 F152
G1 X91.207 Y160.034 F152
G1 X91.227 Y160.055 F152
G1 X91.264 Y160.095 F152
G1 X91.279 Y160.112 F152
G1 X91.321 Y160.159 F152
G1 X91.331 Y160.17 F152
G1 X91.378 Y160.222 F152
G1 X91.382 Y160.227 F152
G1 X91.426 Y160.284 F152
G1 X91.436 Y160.296 F152
G1 X91.471 Y160.341 F152
G1 X91.515 Y160.399 F152
G1 X91.55 Y160.446 F152
G1 X91.557 Y160.456 F152
G1 X91.596 Y160.513 F152
G1 X91.608 Y160.529 F152
G1 X91.635 Y160.57 F152
G1 X91.676 Y160.628 F152
G1 X91.713 Y160.685 F152
G1 X91.722 Y160.698 F152
G1 X91.749 Y160.742 F152
G1 X91.779 Y160.79 F152
G1 X91.785 Y160.8 F152
G1 X91.821 Y160.857 F152
G1 X91.857 Y160.914 F152
G1 X91.892 Y160.971 F152
G1 X91.894 Y160.973 F152
G1 X91.925 Y161.029 F152
G1 X91.951 Y161.073 F152
G1 X91.959 Y161.086 F152
G1 X92.009 Y161.171 F152
G1 X92.059 Y161.258 F152
G1 X92.066 Y161.27 F152
G1 X92.091 Y161.315 F152
G1 X92.122 Y161.372 F152
G1 X92.123 Y161.373 F152
G1 X92.154 Y161.43 F152
G1 X92.18 Y161.478 F152
G1 X92.185 Y161.487 F152
G1 X92.216 Y161.544 F152
G1 X92.238 Y161.583 F152
G1 X92.248 Y161.601 F152
G1 X92.278 Y161.659 F152
G1 X92.295 Y161.691 F152
G1 X92.308 Y161.716 F152
G1 X92.338 Y161.773 F152
G1 X92.368 Y161.831 F152
G1 X92.398 Y161.888 F152
G1 X92.41 Y161.909 F152
G1 X92.428 Y161.945 F152
G1 X92.457 Y162.002 F152
G1 X92.467 Y162.021 F152
G1 X92.487 Y162.06 F152
G1 X92.515 Y162.117 F152
G1 X92.524 Y162.134 F152
G1 X92.545 Y162.174 F152
G1 X92.573 Y162.232 F152
G1 X92.581 Y162.247 F152
G1 X92.602 Y162.289 F152
G1 X92.639 Y162.362 F152
G1 X92.658 Y162.403 F152
G1 X92.716 Y162.518 F152
G1 X92.743 Y162.575 F152
G1 X92.753 Y162.596 F152
G1 X92.77 Y162.632 F152
G1 X92.798 Y162.69 F152
G1 X92.811 Y162.715 F152
G1 X92.826 Y162.747 F152
G1 X92.854 Y162.804 F152
G1 X92.868 Y162.836 F152
G1 X92.879 Y162.862 F152
G1 X92.925 Y162.959 F152
G1 X92.933 Y162.976 F152
G1 X92.959 Y163.033 F152
G1 X92.982 Y163.084 F152
G1 X92.985 Y163.091 F152
G1 X93.01 Y163.148 F152
G1 X93.034 Y163.205 F152
G1 X93.04 Y163.217 F152
G1 X93.059 Y163.263 F152
G1 X93.084 Y163.32 F152
G1 X93.097 Y163.349 F152
G1 X93.109 Y163.377 F152
G1 X93.134 Y163.434 F152
G1 X93.154 Y163.483 F152
G1 X93.158 Y163.492 F152
G1 X93.183 Y163.549 F152
G1 X93.206 Y163.606 F152
G1 X93.212 Y163.621 F152
G1 X93.229 Y163.663 F152
G1 X93.25 Y163.721 F152
G1 X93.269 Y163.767 F152
G1 X93.272 Y163.778 F152
G1 X93.295 Y163.835 F152
G1 X93.314 Y163.893 F152
G1 X93.326 Y163.924 F152
G1 X93.335 Y163.95 F152
G1 X93.376 Y164.064 F152
G1 X93.383 Y164.086 F152
G1 X93.394 Y164.122 F152
G1 X93.413 Y164.179 F152
G1 X93.431 Y164.236 F152
G1 X93.441 Y164.265 F152
G1 X93.468 Y164.351 F152
G1 X93.484 Y164.408 F152
G1 X93.498 Y164.458 F152
G1 X93.5 Y164.465 F152
G1 X93.532 Y164.58 F152
G1 X93.555 Y164.673 F152
G1 X93.56 Y164.694 F152
G1 X93.6 Y164.866 F152
G1 X93.612 Y164.924 F152
G1 X93.613 Y164.926 F152
G1 X93.622 Y164.981 F152
G1 X93.632 Y165.038 F152
G1 X93.643 Y165.095 F152
G1 X93.653 Y165.153 F152
G1 X93.667 Y165.267 F152
G1 X93.67 Y165.283 F152
G1 X93.673 Y165.325 F152
G1 X93.678 Y165.382 F152
G1 X93.681 Y165.439 F152
G1 X93.683 Y165.496 F152
G1 X93.684 Y165.554 F152
G1 X93.677 Y165.668 F152
G1 X93.67 Y165.722 F152
G1 X93.655 Y165.783 F152
G1 X93.644 Y165.811 F152
G1 X93.64 Y165.819 F152
G1 X93.638 Y165.822 F152
G1 X93.634 Y165.826 F152
G1 X93.614 Y165.84 F152
G1 X93.555 Y165.869 F152
G1 X93.498 Y165.889 F152
G1 X93.473 Y165.897 F152
G1 X93.441 Y165.906 F152
G1 X93.383 Y165.921 F152
G1 X93.326 Y165.933 F152
G1 X93.269 Y165.944 F152
G1 X93.212 Y165.952 F152
G1 X93.195 Y165.955 F152
G1 X93.154 Y165.959 F152
G1 X93.04 Y165.973 F152
G1 X92.982 Y165.98 F152
G1 X92.925 Y165.983 F152
G1 X92.868 Y165.986 F152
G1 X92.811 Y165.99 F152
G1 X92.696 Y165.995 F152
G1 X92.639 Y165.994 F152
G1 X92.622 F152
G1 X92.621 F152
; MOVEMENT_LINK_TRANSITION
G1 X92.62 Y165.993 F152
; MOVEMENT_CUTTING
G1 X92.621 Y165.99 F152
G1 X92.622 Y165.983 F152
G1 X92.635 Y165.897 F152
G1 X92.639 Y165.87 F152
G1 X92.643 Y165.84 F152
G1 X92.659 Y165.725 F152
G1 X92.666 Y165.668 F152
G1 X92.679 Y165.554 F152
G1 X92.695 Y165.382 F152
G1 X92.696 Y165.361 F152
G1 X92.7 Y165.267 F152
G1 X92.702 Y165.21 F152
G1 X92.705 Y165.153 F152
G1 X92.707 Y165.095 F152
G1 X92.708 Y165.038 F152
G1 X92.706 Y164.981 F152
G1 X92.705 Y164.924 F152
G1 X92.703 Y164.866 F152
G1 X92.702 Y164.809 F152
G1 X92.7 Y164.752 F152
G1 X92.696 Y164.708 F152
G1 X92.695 Y164.694 F152
G1 X92.69 Y164.637 F152
G1 X92.685 Y164.58 F152
G1 X92.675 Y164.465 F152
G1 X92.668 Y164.408 F152
G1 X92.641 Y164.236 F152
G1 X92.639 Y164.223 F152
G1 X92.632 Y164.179 F152
G1 X92.623 Y164.122 F152
G1 X92.613 Y164.064 F152
G1 X92.599 Y164.007 F152
G1 X92.587 Y163.95 F152
G1 X92.581 Y163.928 F152
G1 X92.574 Y163.893 F152
G1 X92.561 Y163.835 F152
G1 X92.548 Y163.778 F152
G1 X92.533 Y163.721 F152
G1 X92.524 Y163.691 F152
G1 X92.516 Y163.663 F152
G1 X92.5 Y163.606 F152
G1 X92.467 Y163.494 F152
G1 Y163.492 F152
G1 X92.45 Y163.434 F152
G1 X92.41 Y163.32 F152
G1 Y163.319 F152
G1 X92.39 Y163.263 F152
G1 X92.369 Y163.205 F152
G1 X92.352 Y163.159 F152
G1 X92.349 Y163.148 F152
G1 X92.328 Y163.091 F152
G1 X92.305 Y163.033 F152
G1 X92.295 Y163.012 F152
G1 X92.281 Y162.976 F152
G1 X92.257 Y162.919 F152
G1 X92.238 Y162.876 F152
G1 X92.232 Y162.862 F152
G1 X92.208 Y162.804 F152
G1 X92.182 Y162.747 F152
G1 X92.154 Y162.69 F152
G1 X92.123 Y162.627 F152
G1 X92.07 Y162.518 F152
G1 X92.066 Y162.51 F152
G1 X92.042 Y162.461 F152
G1 X92.01 Y162.403 F152
G1 X92.009 Y162.401 F152
G1 X91.978 Y162.346 F152
G1 X91.951 Y162.299 F152
G1 X91.946 Y162.289 F152
G1 X91.881 Y162.174 F152
G1 X91.837 Y162.103 F152
G1 X91.809 Y162.06 F152
G1 X91.779 Y162.013 F152
G1 X91.772 Y162.002 F152
G1 X91.736 Y161.945 F152
G1 X91.722 Y161.924 F152
G1 X91.699 Y161.888 F152
G1 X91.665 Y161.84 F152
G1 X91.616 Y161.773 F152
G1 X91.608 Y161.763 F152
G1 X91.574 Y161.716 F152
G1 X91.55 Y161.685 F152
G1 X91.531 Y161.659 F152
G1 X91.487 Y161.601 F152
G1 X91.437 Y161.544 F152
G1 X91.436 Y161.542 F152
G1 X91.388 Y161.487 F152
G1 X91.34 Y161.43 F152
G1 X91.321 Y161.408 F152
G1 X91.288 Y161.372 F152
G1 X91.264 Y161.348 F152
G1 X91.23 Y161.315 F152
G1 X91.207 Y161.292 F152
G1 X91.172 Y161.258 F152
G1 X91.149 Y161.235 F152
G1 X91.113 Y161.201 F152
G1 X91.092 Y161.18 F152
G1 X91.048 Y161.143 F152
G1 X91.035 Y161.133 F152
G1 X90.977 Y161.088 F152
G1 X90.975 Y161.086 F152
G1 X90.92 Y161.043 F152
G1 X90.902 Y161.029 F152
G1 X90.863 Y160.998 F152
G1 X90.823 Y160.971 F152
G1 X90.806 Y160.96 F152
G1 X90.748 Y160.927 F152
G1 X90.726 Y160.914 F152
G1 X90.691 Y160.894 F152
G1 X90.627 Y160.857 F152
G1 X90.576 Y160.83 F152
G1 X90.519 Y160.805 F152
G1 X90.503 Y160.8 F152
G1 X90.462 Y160.784 F152
G1 X90.347 Y160.743 F152
G1 X90.343 Y160.742 F152
G1 X90.29 Y160.725 F152
G1 X90.233 Y160.711 F152
G1 X90.175 Y160.702 F152
G1 X90.118 Y160.695 F152
G1 X90.061 Y160.689 F152
G1 X90.03 Y160.685 F152
G1 X90.004 Y160.681 F152
G1 X89.946 Y160.678 F152
G1 X89.889 F152
G1 X89.832 Y160.682 F152
G1 X89.66 Y160.706 F152
G1 X89.603 Y160.717 F152
G1 X89.545 Y160.732 F152
G1 X89.488 Y160.751 F152
G1 X89.431 Y160.775 F152
G1 X89.375 Y160.8 F152
G1 X89.373 F152
G1 X89.316 Y160.825 F152
G1 X89.259 Y160.852 F152
G1 X89.251 Y160.857 F152
G1 X89.202 Y160.885 F152
G1 X89.161 Y160.914 F152
G1 X89.083 Y160.971 F152
G1 X89.03 Y161.011 F152
G1 X89.006 Y161.029 F152
G1 X88.972 Y161.057 F152
G1 X88.942 Y161.086 F152
G1 X88.915 Y161.114 F152
G1 X88.887 Y161.143 F152
G1 X88.858 Y161.175 F152
G1 X88.835 Y161.201 F152
G1 X88.801 Y161.238 F152
G1 X88.782 Y161.258 F152
G1 X88.735 Y161.315 F152
G1 X88.656 Y161.43 F152
G1 X88.629 Y161.471 F152
G1 X88.618 Y161.487 F152
G1 X88.579 Y161.544 F152
G1 X88.571 Y161.559 F152
G1 X88.548 Y161.601 F152
G1 X88.518 Y161.659 F152
G1 X88.514 Y161.666 F152
G1 X88.487 Y161.716 F152
G1 X88.457 Y161.773 F152
G1 Y161.774 F152
G1 X88.429 Y161.831 F152
G1 X88.404 Y161.888 F152
G1 X88.4 Y161.9 F152
G1 X88.342 Y162.036 F152
G1 X88.332 Y162.06 F152
G1 X88.309 Y162.117 F152
G1 X88.29 Y162.174 F152
G1 X88.285 Y162.19 F152
G1 X88.271 Y162.232 F152
G1 X88.251 Y162.289 F152
G1 X88.232 Y162.346 F152
G1 X88.228 Y162.36 F152
G1 X88.212 Y162.403 F152
G1 X88.197 Y162.461 F152
G1 X88.181 Y162.518 F152
G1 X88.17 Y162.558 F152
G1 X88.165 Y162.575 F152
G1 X88.15 Y162.632 F152
G1 X88.134 Y162.69 F152
G1 X88.12 Y162.747 F152
G1 X88.113 Y162.78 F152
G1 X88.108 Y162.804 F152
G1 X88.094 Y162.862 F152
G1 X88.057 Y163.033 F152
G1 X88.056 Y163.04 F152
G1 X88.046 Y163.091 F152
G1 X88.007 Y163.32 F152
G1 X87.999 Y163.37 F152
G1 X87.997 Y163.377 F152
G1 X87.988 Y163.434 F152
G1 X87.981 Y163.492 F152
G1 X87.973 Y163.549 F152
G1 X87.951 Y163.721 F152
G1 X87.943 Y163.778 F152
G1 X87.941 Y163.798 F152
G1 X87.937 Y163.835 F152
G1 X87.931 Y163.893 F152
G1 X87.927 Y163.95 F152
G1 X87.916 Y164.064 F152
G1 X87.912 Y164.122 F152
G1 X87.906 Y164.179 F152
G1 X87.902 Y164.236 F152
G1 X87.899 Y164.294 F152
G1 X87.896 Y164.351 F152
G1 X87.893 Y164.408 F152
G1 X87.889 Y164.465 F152
G1 X87.887 Y164.523 F152
G1 X87.884 Y164.576 F152
G1 X87.883 Y164.58 F152
G1 X87.88 Y164.637 F152
G1 X87.879 Y164.752 F152
G1 X87.877 Y164.809 F152
G1 X87.876 Y164.866 F152
G1 X87.874 Y164.924 F152
G1 X87.872 Y165.038 F152
G1 Y165.095 F152
G1 X87.873 Y165.153 F152
G1 Y165.21 F152
G1 X87.874 Y165.267 F152
G1 Y165.325 F152
G1 X87.875 Y165.382 F152
G1 Y165.439 F152
G1 X87.882 Y165.668 F152
G1 X87.884 Y165.7 F152
G1 Y165.725 F152
G1 X87.887 Y165.783 F152
G1 X87.888 Y165.84 F152
G1 X87.894 Y165.955 F152
G1 X87.901 Y166.069 F152
G1 X87.904 Y166.126 F152
G1 X87.918 Y166.356 F152
G1 X87.923 Y166.413 F152
G1 X87.937 Y166.585 F152
G1 X87.941 Y166.637 F152
G1 Y166.642 F152
G1 X87.946 Y166.699 F152
G1 X87.962 Y166.871 F152
G1 X87.968 Y166.928 F152
G1 X87.979 Y167.043 F152
G1 X87.985 Y167.1 F152
G1 X87.991 Y167.157 F152
G1 X88.005 Y167.272 F152
G1 X88.011 Y167.329 F152
G1 X88.054 Y167.673 F152
G1 X88.056 Y167.682 F152
G1 X88.061 Y167.73 F152
G1 X88.097 Y168.017 F152
G1 X88.105 Y168.074 F152
G1 X88.113 Y168.127 F152
G1 Y168.131 F152
G1 X88.14 Y168.303 F152
G1 X88.148 Y168.36 F152
G1 X88.166 Y168.475 F152
G1 X88.17 Y168.503 F152
G1 X88.175 Y168.532 F152
G1 X88.183 Y168.589 F152
G1 X88.21 Y168.761 F152
G1 X88.218 Y168.819 F152
G1 X88.227 Y168.876 F152
G1 X88.228 Y168.878 F152
G1 X88.236 Y168.933 F152
G1 X88.245 Y168.99 F152
G1 X88.255 Y169.048 F152
G1 X88.275 Y169.162 F152
G1 X88.285 Y169.215 F152
G1 Y169.219 F152
G1 X88.296 Y169.277 F152
G1 X88.315 Y169.391 F152
G1 X88.326 Y169.449 F152
G1 X88.336 Y169.506 F152
G1 X88.342 Y169.54 F152
G1 X88.346 Y169.563 F152
G1 X88.356 Y169.62 F152
G1 X88.366 Y169.678 F152
G1 X88.386 Y169.792 F152
G1 X88.397 Y169.85 F152
G1 X88.4 Y169.865 F152
G1 X88.407 Y169.907 F152
G1 X88.43 Y170.021 F152
G1 X88.441 Y170.079 F152
G1 X88.452 Y170.136 F152
G1 X88.457 Y170.156 F152
G1 X88.464 Y170.193 F152
G1 X88.475 Y170.25 F152
G1 X88.498 Y170.365 F152
G1 X88.509 Y170.422 F152
G1 X88.514 Y170.446 F152
G1 X88.52 Y170.48 F152
G1 X88.532 Y170.537 F152
G1 X88.543 Y170.594 F152
G1 X88.566 Y170.709 F152
G1 X88.571 Y170.734 F152
G1 X88.579 Y170.766 F152
G1 X88.616 Y170.938 F152
G1 X88.629 Y170.994 F152
G1 Y170.995 F152
G1 X88.679 Y171.224 F152
G1 X88.686 Y171.255 F152
G1 X88.691 Y171.281 F152
G1 X88.716 Y171.396 F152
G1 X88.73 Y171.453 F152
G1 X88.742 Y171.511 F152
G1 X88.743 Y171.514 F152
G1 X88.769 Y171.625 F152
G1 X88.801 Y171.75 F152
G1 X88.811 Y171.797 F152
G1 X88.858 Y171.983 F152
G1 X88.868 Y172.026 F152
G1 X88.896 Y172.141 F152
G1 X88.91 Y172.198 F152
G1 X88.915 Y172.217 F152
G1 X88.924 Y172.255 F152
G1 X88.938 Y172.312 F152
G1 X88.969 Y172.427 F152
G1 X88.972 Y172.438 F152
G1 X88.985 Y172.484 F152
G1 X89.001 Y172.542 F152
G1 X89.016 Y172.599 F152
G1 X89.03 Y172.645 F152
G1 X89.032 Y172.656 F152
G1 X89.049 Y172.713 F152
G1 X89.064 Y172.771 F152
G1 X89.08 Y172.828 F152
G1 X89.087 Y172.852 F152
G1 X89.096 Y172.885 F152
G1 X89.112 Y172.943 F152
G1 X89.127 Y173 F152
G1 X89.143 Y173.057 F152
G1 X89.144 Y173.059 F152
G1 X89.159 Y173.114 F152
G1 X89.176 Y173.172 F152
G1 X89.194 Y173.229 F152
G1 X89.202 Y173.252 F152
G1 X89.211 Y173.286 F152
G1 X89.229 Y173.343 F152
G1 X89.246 Y173.401 F152
G1 X89.259 Y173.44 F152
G1 X89.264 Y173.458 F152
G1 X89.3 Y173.573 F152
G1 X89.316 Y173.62 F152
G1 X89.319 Y173.63 F152
G1 X89.356 Y173.744 F152
G1 X89.373 Y173.795 F152
G1 X89.375 Y173.802 F152
G1 X89.394 Y173.859 F152
G1 X89.414 Y173.916 F152
G1 X89.434 Y173.974 F152
G1 X89.474 Y174.088 F152
G1 X89.488 Y174.127 F152
G1 X89.494 Y174.145 F152
G1 X89.514 Y174.203 F152
G1 X89.535 Y174.26 F152
G1 X89.545 Y174.285 F152
G1 X89.557 Y174.317 F152
G1 X89.578 Y174.374 F152
G1 X89.603 Y174.436 F152
G1 X89.622 Y174.489 F152
G1 X89.644 Y174.546 F152
G1 X89.66 Y174.587 F152
G1 X89.667 Y174.604 F152
G1 X89.714 Y174.718 F152
G1 X89.717 Y174.726 F152
G1 X89.737 Y174.775 F152
G1 X89.76 Y174.833 F152
G1 X89.774 Y174.867 F152
G1 X89.783 Y174.89 F152
G1 X89.809 Y174.947 F152
G1 X89.832 Y174.998 F152
G1 X89.859 Y175.062 F152
G1 X89.885 Y175.119 F152
G1 X89.889 Y175.127 F152
G1 X89.91 Y175.176 F152
G1 X89.936 Y175.234 F152
G1 X89.946 Y175.253 F152
G1 X89.964 Y175.291 F152
G1 X90.004 Y175.372 F152
G1 X90.019 Y175.406 F152
G1 X90.047 Y175.463 F152
G1 X90.061 Y175.491 F152
G1 X90.074 Y175.52 F152
G1 X90.105 Y175.577 F152
G1 X90.134 Y175.635 F152
G1 X90.165 Y175.692 F152
G1 X90.175 Y175.712 F152
G1 X90.194 Y175.749 F152
G1 X90.225 Y175.806 F152
G1 X90.233 Y175.821 F152
G1 X90.258 Y175.864 F152
G1 X90.29 Y175.919 F152
G1 X90.291 Y175.921 F152
G1 X90.39 Y176.093 F152
G1 X90.405 Y176.117 F152
G1 X90.423 Y176.15 F152
G1 X90.457 Y176.207 F152
G1 X90.462 Y176.215 F152
G1 X90.519 Y176.301 F152
G1 X90.533 Y176.322 F152
G1 X90.57 Y176.379 F152
G1 X90.576 Y176.388 F152
G1 X90.608 Y176.437 F152
G1 X90.634 Y176.475 F152
G1 X90.645 Y176.494 F152
G1 X90.684 Y176.551 F152
G1 X90.691 Y176.563 F152
G1 X90.724 Y176.608 F152
G1 X90.748 Y176.641 F152
G1 X90.766 Y176.666 F152
G1 X90.806 Y176.718 F152
G1 X90.809 Y176.723 F152
G1 X90.895 Y176.837 F152
G1 X90.92 Y176.871 F152
G1 X90.938 Y176.895 F152
G1 X90.977 Y176.944 F152
G1 X90.984 Y176.952 F152
G1 X91.033 Y177.009 F152
G1 X91.035 Y177.012 F152
G1 X91.092 Y177.079 F152
G1 X91.13 Y177.124 F152
G1 X91.149 Y177.147 F152
G1 X91.179 Y177.181 F152
G1 X91.207 Y177.214 F152
G1 X91.228 Y177.238 F152
G1 X91.283 Y177.296 F152
G1 X91.321 Y177.335 F152
G1 X91.338 Y177.353 F152
G1 X91.378 Y177.395 F152
G1 X91.394 Y177.41 F152
G1 X91.436 Y177.454 F152
G1 X91.448 Y177.468 F152
G1 X91.493 Y177.513 F152
G1 X91.506 Y177.525 F152
G1 X91.55 Y177.566 F152
G1 X91.568 Y177.582 F152
G1 X91.608 Y177.618 F152
G1 X91.665 Y177.671 F152
G1 X91.722 Y177.723 F152
G1 X91.756 Y177.754 F152
G1 X91.779 Y177.774 F152
G1 X91.826 Y177.811 F152
G1 X91.837 Y177.82 F152
G1 X91.894 Y177.866 F152
G1 X91.898 Y177.868 F152
G1 X91.951 Y177.911 F152
G1 X91.97 Y177.926 F152
G1 X92.009 Y177.957 F152
G1 X92.042 Y177.983 F152
G1 X92.066 Y178.001 F152
G1 X92.122 Y178.04 F152
G1 X92.123 Y178.041 F152
G1 X92.18 Y178.081 F152
G1 X92.205 Y178.098 F152
G1 X92.238 Y178.12 F152
G1 X92.295 Y178.158 F152
G1 X92.352 Y178.198 F152
G1 X92.376 Y178.212 F152
G1 X92.467 Y178.265 F152
G1 X92.475 Y178.269 F152
G1 X92.573 Y178.327 F152
G1 X92.581 Y178.331 F152
G1 X92.639 Y178.364 F152
G1 X92.675 Y178.384 F152
G1 X92.696 Y178.395 F152
G1 X92.811 Y178.448 F152
G1 X92.868 Y178.476 F152
G1 X92.915 Y178.499 F152
G1 X92.925 Y178.503 F152
G1 X92.982 Y178.53 F152
G1 X93.04 Y178.551 F152
G1 X93.052 Y178.556 F152
G1 X93.097 Y178.573 F152
G1 X93.269 Y178.637 F152
G1 X93.326 Y178.656 F152
G1 X93.378 Y178.67 F152
G1 X93.383 Y178.672 F152
G1 X93.555 Y178.72 F152
G1 X93.58 Y178.728 F152
G1 X93.613 Y178.737 F152
G1 X93.727 Y178.76 F152
G1 X93.784 Y178.771 F152
G1 X93.842 Y178.782 F152
G1 X93.86 Y178.785 F152
G1 X93.899 Y178.793 F152
G1 X93.956 Y178.803 F152
G1 X94.014 Y178.809 F152
G1 X94.071 Y178.816 F152
G1 X94.185 Y178.829 F152
G1 X94.243 Y178.836 F152
G1 X94.3 Y178.84 F152
G1 X94.357 Y178.841 F152
G1 X94.38 Y178.842 F152
G1 X94.415 Y178.844 F152
G1 X94.529 Y178.849 F152
G1 X94.586 Y178.85 F152
G1 X94.701 Y178.848 F152
G1 X94.758 Y178.847 F152
G1 X94.816 Y178.846 F152
G1 X94.873 Y178.844 F152
G1 X94.901 Y178.842 F152
G1 X94.93 Y178.84 F152
G1 X94.987 Y178.834 F152
G1 X95.274 Y178.807 F152
G1 X95.388 Y178.788 F152
G1 X95.401 Y178.785 F152
G1 X95.446 Y178.777 F152
G1 X95.56 Y178.757 F152
G1 X95.675 Y178.736 F152
G1 X95.709 Y178.728 F152
G1 X95.732 Y178.722 F152
G1 X95.789 Y178.707 F152
G1 X95.847 Y178.691 F152
G1 X95.904 Y178.676 F152
G1 X95.924 Y178.67 F152
G1 X95.961 Y178.661 F152
G1 X96.076 Y178.63 F152
G1 X96.129 Y178.613 F152
G1 X96.133 Y178.612 F152
G1 X96.19 Y178.592 F152
G1 X96.248 Y178.574 F152
G1 X96.3 Y178.556 F152
G1 X96.305 Y178.554 F152
G1 X96.42 Y178.511 F152
G1 X96.451 Y178.499 F152
G1 X96.477 Y178.489 F152
G1 X96.534 Y178.466 F152
G1 X96.591 Y178.442 F152
G1 X96.593 Y178.441 F152
G1 X96.649 Y178.418 F152
G1 X96.727 Y178.384 F152
G1 X96.763 Y178.368 F152
G1 X96.821 Y178.34 F152
G1 X96.935 Y178.286 F152
G1 X96.992 Y178.258 F152
G1 X97.05 Y178.228 F152
G1 X97.079 Y178.212 F152
G1 X97.164 Y178.168 F152
G1 X97.189 Y178.155 F152
G1 X97.222 Y178.137 F152
G1 X97.279 Y178.105 F152
G1 X97.291 Y178.098 F152
G1 X97.336 Y178.073 F152
G1 X97.393 Y178.04 F152
G1 X97.451 Y178.005 F152
G1 X97.508 Y177.971 F152
G1 X97.565 Y177.936 F152
G1 X97.582 Y177.926 F152
G1 X97.623 Y177.902 F152
G1 X97.674 Y177.868 F152
G1 X97.68 Y177.865 F152
G1 X97.737 Y177.827 F152
G1 X97.794 Y177.791 F152
G1 X97.85 Y177.754 F152
G1 X97.852 Y177.753 F152
G1 X97.909 Y177.712 F152
G1 X97.93 Y177.697 F152
G1 X97.966 Y177.672 F152
G1 X98.081 Y177.589 F152
G1 X98.091 Y177.582 F152
G1 X98.138 Y177.549 F152
G1 X98.171 Y177.525 F152
G1 X98.195 Y177.508 F152
G1 X98.252 Y177.468 F152
G1 X98.253 Y177.467 F152
G1 X98.31 Y177.425 F152
G1 X98.327 Y177.41 F152
G1 X98.399 Y177.353 F152
G1 X98.425 Y177.332 F152
G1 X98.47 Y177.296 F152
G1 X98.482 Y177.286 F152
G1 X98.539 Y177.24 F152
G1 X98.541 Y177.238 F152
G1 X98.596 Y177.194 F152
G1 X98.613 Y177.181 F152
G1 X98.654 Y177.148 F152
G1 X98.684 Y177.124 F152
G1 X98.711 Y177.102 F152
G1 X98.752 Y177.067 F152
G1 X98.768 Y177.052 F152
G1 X98.826 Y177 F152
G1 X98.879 Y176.952 F152
G1 X98.883 Y176.948 F152
G1 X98.94 Y176.897 F152
G1 X98.943 Y176.895 F152
G1 X98.997 Y176.846 F152
G1 X99.005 Y176.837 F152
G1 X99.055 Y176.794 F152
G1 X99.069 Y176.78 F152
G1 X99.112 Y176.742 F152
G1 X99.133 Y176.723 F152
G1 X99.169 Y176.689 F152
G1 X99.193 Y176.666 F152
G1 X99.227 Y176.631 F152
G1 X99.248 Y176.608 F152
G1 X99.284 Y176.572 F152
G1 X99.304 Y176.551 F152
G1 X99.341 Y176.513 F152
G1 X99.36 Y176.494 F152
G1 X99.398 Y176.454 F152
G1 X99.416 Y176.437 F152
G1 X99.456 Y176.395 F152
G1 X99.472 Y176.379 F152
G1 X99.513 Y176.337 F152
G1 X99.528 Y176.322 F152
G1 X99.57 Y176.278 F152
G1 X99.583 Y176.265 F152
G1 X99.628 Y176.213 F152
G1 X99.632 Y176.207 F152
G1 X99.681 Y176.15 F152
G1 X99.685 Y176.146 F152
G1 X99.73 Y176.093 F152
G1 X99.742 Y176.079 F152
G1 X99.799 Y176.011 F152
G1 X99.827 Y175.978 F152
G1 X99.857 Y175.944 F152
G1 X99.876 Y175.921 F152
G1 X99.914 Y175.877 F152
G1 X99.926 Y175.864 F152
G1 X99.971 Y175.808 F152
G1 X99.973 Y175.806 F152
G1 X100.061 Y175.692 F152
G1 X100.086 Y175.659 F152
G1 X100.105 Y175.635 F152
G1 X100.143 Y175.584 F152
G1 X100.148 Y175.577 F152
G1 X100.189 Y175.52 F152
G1 X100.2 Y175.504 F152
G1 X100.229 Y175.463 F152
G1 X100.258 Y175.423 F152
G1 X100.27 Y175.406 F152
G1 X100.311 Y175.348 F152
G1 X100.315 Y175.341 F152
G1 X100.349 Y175.291 F152
G1 X100.372 Y175.255 F152
G1 X100.387 Y175.234 F152
G1 X100.43 Y175.167 F152
G1 X100.461 Y175.119 F152
G1 X100.487 Y175.079 F152
G1 X100.498 Y175.062 F152
G1 X100.532 Y175.005 F152
G1 X100.567 Y174.947 F152
G1 X100.601 Y174.89 F152
G1 Y174.888 F152
G1 X100.635 Y174.833 F152
G1 X100.659 Y174.792 F152
G1 X100.668 Y174.775 F152
G1 X100.699 Y174.718 F152
G1 X100.716 Y174.687 F152
G1 X100.73 Y174.661 F152
G1 X100.762 Y174.604 F152
G1 X100.773 Y174.582 F152
G1 X100.793 Y174.546 F152
G1 X100.823 Y174.489 F152
G1 X100.831 Y174.472 F152
G1 X100.851 Y174.432 F152
G1 X100.937 Y174.26 F152
G1 X100.945 Y174.243 F152
G1 X100.963 Y174.203 F152
G1 X100.988 Y174.145 F152
G1 X101.002 Y174.113 F152
G1 X101.014 Y174.088 F152
G1 X101.039 Y174.031 F152
G1 X101.06 Y173.983 F152
G1 X101.064 Y173.974 F152
G1 X101.089 Y173.916 F152
G1 X101.115 Y173.859 F152
G1 X101.117 Y173.854 F152
G1 X101.14 Y173.802 F152
G1 X101.174 Y173.724 F152
G1 X101.19 Y173.687 F152
G1 X101.213 Y173.63 F152
G1 X101.232 Y173.581 F152
G1 X101.235 Y173.573 F152
G1 X101.258 Y173.515 F152
G1 X101.279 Y173.458 F152
G1 X101.289 Y173.433 F152
G1 X101.346 Y173.286 F152
G1 Y173.284 F152
G1 X101.366 Y173.229 F152
G1 X101.448 Y173 F152
G1 X101.461 Y172.964 F152
G1 X101.469 Y172.943 F152
G1 X101.508 Y172.828 F152
G1 X101.518 Y172.798 F152
G1 X101.528 Y172.771 F152
G1 X101.548 Y172.713 F152
G1 X101.566 Y172.656 F152
G1 X101.625 Y172.484 F152
G1 X101.633 Y172.461 F152
G1 X101.664 Y172.37 F152
G1 X101.683 Y172.312 F152
G1 X101.69 Y172.29 F152
G1 X101.701 Y172.255 F152
G1 X101.721 Y172.198 F152
G1 X101.74 Y172.141 F152
G1 X101.747 Y172.12 F152
G1 X101.779 Y172.026 F152
G1 X101.799 Y171.969 F152
G1 X101.804 Y171.953 F152
G1 X101.819 Y171.912 F152
G1 X101.858 Y171.797 F152
G1 X101.862 Y171.787 F152
G1 X101.878 Y171.74 F152
G1 X101.919 Y171.625 F152
G1 X101.94 Y171.568 F152
G1 X101.961 Y171.511 F152
G1 X101.976 Y171.469 F152
G1 X101.983 Y171.453 F152
G1 X102.003 Y171.396 F152
G1 X102.025 Y171.339 F152
G1 X102.034 Y171.313 F152
G1 X102.046 Y171.281 F152
G1 X102.069 Y171.224 F152
G1 X102.091 Y171.169 F152
G1 X102.092 Y171.167 F152
G1 X102.115 Y171.11 F152
G1 X102.137 Y171.052 F152
G1 X102.148 Y171.026 F152
G1 X102.161 Y170.995 F152
G1 X102.183 Y170.938 F152
G1 X102.205 Y170.885 F152
G1 X102.207 Y170.881 F152
G1 X102.233 Y170.823 F152
G1 X102.258 Y170.766 F152
G1 X102.263 Y170.755 F152
G1 X102.283 Y170.709 F152
G1 X102.309 Y170.651 F152
G1 X102.32 Y170.626 F152
G1 X102.334 Y170.594 F152
G1 X102.359 Y170.537 F152
G1 X102.377 Y170.499 F152
G1 X102.416 Y170.422 F152
G1 X102.435 Y170.384 F152
G1 X102.444 Y170.365 F152
G1 X102.472 Y170.308 F152
G1 X102.492 Y170.267 F152
G1 X102.501 Y170.25 F152
G1 X102.529 Y170.193 F152
G1 X102.549 Y170.152 F152
G1 X102.557 Y170.136 F152
G1 X102.589 Y170.079 F152
G1 X102.606 Y170.046 F152
G1 X102.621 Y170.021 F152
G1 X102.652 Y169.964 F152
G1 X102.717 Y169.85 F152
G1 X102.721 Y169.841 F152
G1 X102.778 Y169.738 F152
G1 X102.78 Y169.735 F152
G1 X102.816 Y169.678 F152
G1 X102.836 Y169.645 F152
G1 X102.852 Y169.62 F152
G1 X102.887 Y169.563 F152
G1 X102.893 Y169.553 F152
G1 X102.922 Y169.506 F152
G1 X102.95 Y169.461 F152
G1 X102.958 Y169.449 F152
G1 X102.994 Y169.391 F152
G1 X103.007 Y169.369 F152
G1 X103.031 Y169.334 F152
G1 X103.065 Y169.285 F152
G1 X103.07 Y169.277 F152
G1 X103.11 Y169.219 F152
G1 X103.122 Y169.202 F152
G1 X103.15 Y169.162 F152
G1 X103.268 Y168.99 F152
G1 X103.294 Y168.956 F152
G1 X103.312 Y168.933 F152
G1 X103.351 Y168.88 F152
G1 X103.355 Y168.876 F152
G1 X103.399 Y168.819 F152
G1 X103.408 Y168.805 F152
G1 X103.442 Y168.761 F152
G1 X103.466 Y168.73 F152
G1 X103.485 Y168.704 F152
G1 X103.528 Y168.647 F152
G1 X103.575 Y168.589 F152
G1 X103.58 Y168.582 F152
G1 X103.638 Y168.512 F152
G1 X103.669 Y168.475 F152
G1 X103.716 Y168.418 F152
G1 X103.752 Y168.374 F152
G1 X103.763 Y168.36 F152
G1 X103.809 Y168.304 F152
G1 X103.81 Y168.303 F152
G1 X103.86 Y168.246 F152
G1 X103.867 Y168.238 F152
G1 X103.91 Y168.188 F152
G1 X103.961 Y168.131 F152
G1 X103.981 Y168.107 F152
G1 X104.011 Y168.074 F152
G1 X104.039 Y168.042 F152
G1 X104.061 Y168.017 F152
G1 X104.096 Y167.976 F152
G1 X104.111 Y167.959 F152
G1 X104.164 Y167.902 F152
G1 X104.21 Y167.851 F152
G1 X104.217 Y167.845 F152
G1 X104.268 Y167.789 F152
G1 X104.269 Y167.788 F152
G1 X104.321 Y167.73 F152
G1 X104.325 Y167.727 F152
G1 X104.374 Y167.673 F152
G1 X104.382 Y167.664 F152
G1 X104.427 Y167.616 F152
G1 X104.481 Y167.558 F152
G1 X104.497 Y167.541 F152
G1 X104.534 Y167.501 F152
G1 X104.554 Y167.48 F152
G1 X104.588 Y167.444 F152
G1 X104.611 Y167.418 F152
G1 X104.641 Y167.387 F152
G1 X104.669 Y167.356 F152
G1 X104.694 Y167.329 F152
G1 X104.747 Y167.272 F152
G1 X104.783 Y167.232 F152
G1 X104.798 Y167.215 F152
G1 X104.841 Y167.167 F152
G1 X104.85 Y167.157 F152
G1 X104.898 Y167.102 F152
G1 X104.9 Y167.1 F152
G1 X104.948 Y167.043 F152
G1 X104.955 Y167.034 F152
G1 X104.995 Y166.986 F152
G1 X105.012 Y166.964 F152
G1 X105.039 Y166.928 F152
G1 X105.07 Y166.888 F152
G1 X105.082 Y166.871 F152
G1 X105.121 Y166.814 F152
G1 X105.157 Y166.757 F152
G1 X105.184 Y166.709 F152
G1 X105.19 Y166.699 F152
G1 X105.219 Y166.642 F152
G1 X105.242 Y166.591 F152
G1 X105.244 Y166.585 F152
G1 X105.265 Y166.527 F152
G1 X105.284 Y166.47 F152
G1 X105.298 Y166.413 F152
G1 X105.299 Y166.407 F152
G1 X105.308 Y166.356 F152
G1 X105.313 Y166.298 F152
G1 X105.317 Y166.241 F152
G1 X105.318 Y166.184 F152
G1 X105.313 Y166.126 F152
G1 X105.305 Y166.069 F152
G1 X105.293 Y166.012 F152
G1 X105.276 Y165.955 F152
G1 X105.255 Y165.897 F152
G1 X105.242 Y165.864 F152
G1 X105.231 Y165.84 F152
G1 X105.2 Y165.783 F152
G1 X105.184 Y165.756 F152
G1 X105.164 Y165.725 F152
G1 X105.127 Y165.677 F152
G1 X105.12 Y165.668 F152
G1 X105.07 Y165.614 F152
G1 X105.067 Y165.611 F152
G1 X105.012 Y165.559 F152
G1 X105.006 Y165.554 F152
G1 X104.955 Y165.513 F152
G1 X104.93 Y165.496 F152
G1 X104.898 Y165.476 F152
G1 X104.841 Y165.444 F152
G1 X104.828 Y165.439 F152
G1 X104.783 Y165.418 F152
G1 X104.726 Y165.394 F152
G1 X104.688 Y165.382 F152
G1 X104.669 Y165.376 F152
G1 X104.611 Y165.362 F152
G1 X104.554 Y165.35 F152
G1 X104.497 Y165.341 F152
G1 X104.382 Y165.332 F152
G1 X104.325 Y165.331 F152
G1 X104.268 F152
G1 X104.21 Y165.333 F152
G1 X104.153 Y165.337 F152
G1 X104.096 Y165.342 F152
G1 X104.039 Y165.347 F152
G1 X103.867 Y165.368 F152
G1 X103.809 Y165.376 F152
G1 X103.769 Y165.382 F152
G1 X103.752 Y165.384 F152
G1 X103.58 Y165.41 F152
G1 X103.523 Y165.419 F152
G1 X103.408 Y165.436 F152
G1 X103.392 Y165.439 F152
G1 X103.351 Y165.445 F152
G1 X103.294 Y165.453 F152
G1 X103.179 Y165.471 F152
G1 X103.007 Y165.495 F152
G1 X103.004 Y165.496 F152
G1 X102.95 Y165.504 F152
G1 X102.664 Y165.539 F152
G1 X102.549 Y165.55 F152
G1 X102.52 Y165.554 F152
G1 X102.492 Y165.555 F152
G1 X102.377 Y165.566 F152
G1 X102.32 Y165.571 F152
G1 X102.034 Y165.584 F152
G1 X101.976 Y165.586 F152
G1 X101.862 Y165.591 F152
G1 X101.747 F152
G1 X101.69 Y165.59 F152
G1 X101.633 F152
G1 X101.575 Y165.588 F152
G1 X101.518 Y165.584 F152
G1 X101.403 Y165.579 F152
G1 X101.346 Y165.573 F152
G1 X101.289 Y165.567 F152
G1 X101.232 Y165.562 F152
G1 X101.174 Y165.555 F152
G1 X101.159 Y165.554 F152
G1 X101.117 Y165.547 F152
G1 X101.06 Y165.538 F152
G1 X101.002 Y165.53 F152
G1 X100.945 Y165.52 F152
G1 X100.831 Y165.496 F152
G1 X100.827 F152
G1 X100.773 Y165.483 F152
G1 X100.716 Y165.468 F152
G1 X100.659 Y165.453 F152
G1 X100.611 Y165.439 F152
G1 X100.601 Y165.436 F152
G1 X100.544 Y165.418 F152
G1 X100.487 Y165.399 F152
G1 X100.444 Y165.382 F152
G1 X100.43 Y165.376 F152
G1 X100.372 Y165.354 F152
G1 X100.315 Y165.328 F152
G1 X100.307 Y165.325 F152
G1 X100.258 Y165.301 F152
G1 X100.2 Y165.272 F152
G1 X100.191 Y165.267 F152
G1 X100.143 Y165.24 F152
G1 X100.094 Y165.21 F152
G1 X100.086 Y165.205 F152
G1 X100.029 Y165.167 F152
G1 X100.01 Y165.153 F152
G1 X99.971 Y165.123 F152
G1 X99.937 Y165.095 F152
G1 X99.914 Y165.075 F152
G1 X99.874 Y165.038 F152
G1 X99.857 Y165.02 F152
G1 X99.82 Y164.981 F152
G1 X99.799 Y164.956 F152
G1 X99.774 Y164.924 F152
G1 X99.742 Y164.88 F152
G1 X99.733 Y164.866 F152
G1 X99.698 Y164.809 F152
G1 X99.685 Y164.785 F152
G1 X99.667 Y164.752 F152
G1 X99.628 Y164.665 F152
G1 X99.617 Y164.637 F152
G1 X99.596 Y164.58 F152
G1 X99.577 Y164.523 F152
G1 X99.56 Y164.465 F152
G1 X99.545 Y164.408 F152
G1 X99.532 Y164.351 F152
G1 X99.519 Y164.294 F152
G1 X99.513 Y164.262 F152
G1 X99.509 Y164.236 F152
G1 X99.498 Y164.179 F152
G1 X99.489 Y164.122 F152
G1 X99.473 Y164.007 F152
G1 X99.466 Y163.95 F152
G1 X99.459 Y163.893 F152
G1 X99.456 Y163.864 F152
G1 X99.448 Y163.778 F152
G1 X99.443 Y163.721 F152
G1 X99.438 Y163.663 F152
G1 X99.433 Y163.606 F152
G1 X99.431 Y163.549 F152
G1 X99.423 Y163.434 F152
G1 X99.421 Y163.377 F152
G1 X99.408 Y162.976 F152
G1 X99.406 Y162.862 F152
G1 Y162.804 F152
G1 Y162.747 F152
G1 Y162.69 F152
G1 X99.405 Y162.632 F152
G1 Y162.575 F152
G1 X99.404 Y162.518 F152
G1 Y162.461 F152
G1 X99.406 Y162.346 F152
G1 Y162.289 F152
G1 X99.408 Y162.117 F152
G1 Y162.06 F152
G1 X99.412 Y161.831 F152
G1 Y161.773 F152
G1 X99.414 Y161.716 F152
G1 X99.415 Y161.659 F152
G1 X99.418 Y161.544 F152
G1 X99.419 Y161.487 F152
G1 X99.423 Y161.372 F152
G1 Y161.315 F152
G1 X99.427 Y161.201 F152
G1 X99.428 Y161.143 F152
G1 X99.44 Y160.742 F152
G1 X99.443 Y160.685 F152
G1 X99.452 Y160.399 F152
G1 X99.455 Y160.341 F152
G1 X99.456 Y160.291 F152
G1 X99.457 Y160.284 F152
G1 X99.46 Y160.17 F152
G1 X99.463 Y160.112 F152
G1 X99.466 Y159.998 F152
G1 X99.469 Y159.94 F152
G1 X99.471 Y159.883 F152
G1 X99.474 Y159.826 F152
G1 X99.477 Y159.711 F152
G1 X99.48 Y159.654 F152
G1 X99.483 Y159.539 F152
G1 X99.486 Y159.482 F152
G1 X99.492 Y159.31 F152
G1 X99.494 Y159.253 F152
G1 X99.5 Y159.081 F152
G1 X99.502 Y159.024 F152
G1 X99.513 Y158.68 F152
G1 Y158.67 F152
G1 X99.515 Y158.623 F152
G1 X99.517 Y158.566 F152
G1 Y158.508 F152
G1 X99.521 Y158.394 F152
G1 X99.522 Y158.337 F152
G1 X99.526 Y158.222 F152
G1 Y158.165 F152
G1 X99.53 Y158.05 F152
G1 X99.531 Y157.993 F152
G1 Y157.936 F152
G1 X99.532 Y157.878 F152
G1 Y157.821 F152
G1 X99.533 Y157.764 F152
G1 Y157.707 F152
G1 X99.534 Y157.592 F152
G1 Y157.535 F152
G1 X99.535 Y157.477 F152
G1 Y157.42 F152
G1 X99.536 Y157.363 F152
G1 X99.534 Y157.248 F152
G1 X99.533 Y157.191 F152
G1 X99.532 Y157.134 F152
G1 X99.53 Y157.076 F152
G1 X99.528 Y156.962 F152
G1 X99.526 Y156.905 F152
G1 Y156.847 F152
G1 X99.524 Y156.79 F152
G1 X99.522 Y156.676 F152
G1 X99.519 Y156.618 F152
G1 X99.514 Y156.532 F152
G1 X99.513 Y156.526 F152
G1 X99.512 Y156.504 F152
G1 X99.511 Y156.489 F152
G1 Y156.487 F152
; MOVEMENT_LINK_TRANSITION
G1 X99.513 Y156.486 F152
; MOVEMENT_CUTTING
G1 X99.519 Y156.504 F152
G1 X99.527 Y156.525 F152
G1 X99.542 Y156.561 F152
G1 X99.568 Y156.618 F152
G1 X99.57 Y156.621 F152
G1 X99.596 Y156.676 F152
G1 X99.624 Y156.733 F152
G1 X99.628 Y156.74 F152
G1 X99.654 Y156.79 F152
G1 X99.685 Y156.84 F152
G1 X99.688 Y156.847 F152
G1 X99.76 Y156.962 F152
G1 X99.799 Y157.018 F152
G1 X99.8 Y157.019 F152
G1 X99.845 Y157.076 F152
G1 X99.857 Y157.091 F152
G1 X99.891 Y157.134 F152
G1 X99.914 Y157.163 F152
G1 X99.937 Y157.191 F152
G1 X99.971 Y157.227 F152
G1 X99.994 Y157.248 F152
G1 X100.051 Y157.306 F152
G1 X100.086 Y157.34 F152
G1 X100.11 Y157.363 F152
G1 X100.143 Y157.392 F152
G1 X100.179 Y157.42 F152
G1 X100.2 Y157.437 F152
G1 X100.253 Y157.477 F152
G1 X100.258 Y157.481 F152
G1 X100.315 Y157.524 F152
G1 X100.33 Y157.535 F152
G1 X100.372 Y157.562 F152
G1 X100.43 Y157.596 F152
G1 X100.487 Y157.63 F152
G1 X100.544 Y157.663 F152
G1 X100.601 Y157.691 F152
G1 X100.636 Y157.707 F152
G1 X100.716 Y157.741 F152
G1 X100.768 Y157.764 F152
G1 X100.773 Y157.767 F152
G1 X100.831 Y157.789 F152
G1 X100.888 Y157.807 F152
G1 X100.934 Y157.821 F152
G1 X100.945 Y157.825 F152
G1 X101.002 Y157.843 F152
G1 X101.06 Y157.86 F152
G1 X101.117 Y157.873 F152
G1 X101.147 Y157.878 F152
G1 X101.174 Y157.885 F152
G1 X101.232 Y157.896 F152
G1 X101.289 Y157.909 F152
G1 X101.346 Y157.918 F152
G1 X101.403 Y157.925 F152
G1 X101.461 Y157.931 F152
G1 X101.497 Y157.936 F152
G1 X101.518 Y157.938 F152
G1 X101.575 Y157.945 F152
G1 X101.69 Y157.95 F152
G1 X101.747 Y157.954 F152
G1 X101.804 Y157.956 F152
G1 X101.862 F152
G1 X102.034 Y157.954 F152
G1 X102.091 Y157.952 F152
G1 X102.263 Y157.941 F152
G1 X102.319 Y157.936 F152
G1 X102.32 F152
G1 X102.721 Y157.886 F152
G1 X102.766 Y157.878 F152
G1 X102.778 Y157.877 F152
G1 X102.836 Y157.866 F152
G1 X102.893 Y157.854 F152
G1 X103.007 Y157.833 F152
G1 X103.065 Y157.821 F152
G1 X103.179 Y157.8 F152
G1 X103.294 Y157.771 F152
G1 X103.322 Y157.764 F152
G1 X103.351 Y157.757 F152
G1 X103.408 Y157.742 F152
G1 X103.466 Y157.729 F152
G1 X103.523 Y157.715 F152
G1 X103.58 Y157.699 F152
G1 X103.638 Y157.682 F152
G1 X103.695 Y157.666 F152
G1 X103.751 Y157.649 F152
G1 X103.752 F152
G1 X103.809 Y157.631 F152
G1 X103.867 Y157.612 F152
G1 X103.924 Y157.593 F152
G1 X103.926 Y157.592 F152
G1 X103.981 Y157.573 F152
G1 X104.039 Y157.552 F152
G1 X104.082 Y157.535 F152
G1 X104.096 Y157.529 F152
G1 X104.153 Y157.507 F152
G1 X104.21 Y157.483 F152
G1 X104.223 Y157.477 F152
G1 X104.268 Y157.457 F152
G1 X104.325 Y157.431 F152
G1 X104.348 Y157.42 F152
G1 X104.382 Y157.404 F152
G1 X104.44 Y157.374 F152
G1 X104.458 Y157.363 F152
G1 X104.497 Y157.342 F152
G1 X104.564 Y157.306 F152
G1 X104.611 Y157.276 F152
G1 X104.654 Y157.248 F152
G1 X104.669 Y157.239 F152
G1 X104.726 Y157.202 F152
G1 X104.74 Y157.193 F152
G1 X104.755 Y157.183 F152
G1 X104.762 Y157.178 F152
G1 X104.773 Y157.17 F152
G1 X104.778 Y157.167 F152
G1 X104.781 Y157.164 F152
G1 X104.783 Y157.162 F152
G1 X104.785 Y157.161 F152
G1 X104.786 Y157.16 F152
; MOVEMENT_LINK_TRANSITION
G1 Y157.162 F152
; MOVEMENT_CUTTING
G1 X104.784 Y157.164 F152
G1 X104.783 Y157.166 F152
G1 X104.782 Y157.168 F152
G1 X104.781 Y157.171 F152
G1 X104.776 Y157.178 F152
G1 X104.773 Y157.184 F152
G1 X104.768 Y157.191 F152
G1 X104.755 Y157.214 F152
G1 X104.751 Y157.22 F152
G1 X104.734 Y157.248 F152
G1 X104.726 Y157.263 F152
G1 X104.701 Y157.306 F152
G1 X104.669 Y157.36 F152
G1 X104.667 Y157.363 F152
G1 X104.633 Y157.42 F152
G1 X104.611 Y157.456 F152
G1 X104.599 Y157.477 F152
G1 X104.564 Y157.535 F152
G1 X104.554 Y157.552 F152
G1 X104.53 Y157.592 F152
G1 X104.453 Y157.707 F152
G1 X104.44 Y157.726 F152
G1 X104.382 Y157.812 F152
G1 X104.376 Y157.821 F152
G1 X104.335 Y157.878 F152
G1 X104.325 Y157.891 F152
G1 X104.289 Y157.936 F152
G1 X104.268 Y157.962 F152
G1 X104.21 Y158.024 F152
G1 X104.184 Y158.05 F152
G1 X104.122 Y158.107 F152
G1 X104.096 Y158.127 F152
G1 X104.047 Y158.165 F152
G1 X104.039 Y158.169 F152
G1 X103.981 Y158.204 F152
G1 X103.947 Y158.222 F152
G1 X103.924 Y158.233 F152
G1 X103.867 Y158.257 F152
G1 X103.809 Y158.276 F152
G1 X103.8 Y158.279 F152
G1 X103.752 Y158.295 F152
G1 X103.638 Y158.32 F152
G1 X103.58 Y158.33 F152
G1 X103.531 Y158.337 F152
G1 X103.523 Y158.338 F152
G1 X103.466 Y158.345 F152
G1 X103.408 Y158.351 F152
G1 X103.237 Y158.362 F152
G1 X103.179 Y158.363 F152
G1 X103.065 Y158.365 F152
G1 X103.007 Y158.367 F152
G1 X102.778 Y158.371 F152
G1 X102.606 Y158.376 F152
G1 X102.549 Y158.379 F152
G1 X102.492 Y158.38 F152
G1 X102.435 Y158.383 F152
G1 X102.32 Y158.387 F152
G1 X102.263 Y158.389 F152
G1 X102.205 Y158.391 F152
G1 X102.174 Y158.394 F152
G1 X102.148 Y158.396 F152
G1 X102.034 Y158.408 F152
G1 X101.976 Y158.414 F152
G1 X101.919 Y158.42 F152
G1 X101.862 Y158.428 F152
G1 X101.747 Y158.448 F152
G1 X101.731 Y158.451 F152
G1 X101.633 Y158.468 F152
G1 X101.575 Y158.48 F152
G1 X101.518 Y158.495 F152
G1 X101.47 Y158.508 F152
G1 X101.461 Y158.51 F152
G1 X101.346 Y158.541 F152
G1 X101.289 Y158.559 F152
G1 X101.27 Y158.566 F152
G1 X101.232 Y158.58 F152
G1 X101.174 Y158.602 F152
G1 X101.119 Y158.623 F152
G1 X101.117 F152
G1 X101.06 Y158.645 F152
G1 X101.002 Y158.67 F152
G1 X100.982 Y158.68 F152
G1 X100.945 Y158.699 F152
G1 X100.888 Y158.729 F152
G1 X100.872 Y158.738 F152
G1 X100.831 Y158.758 F152
G1 X100.773 Y158.789 F152
G1 X100.763 Y158.795 F152
G1 X100.716 Y158.823 F152
G1 X100.675 Y158.852 F152
G1 X100.659 Y158.863 F152
G1 X100.511 Y158.967 F152
G1 X100.487 Y158.985 F152
G1 X100.442 Y159.024 F152
G1 X100.38 Y159.081 F152
G1 X100.372 Y159.089 F152
G1 X100.319 Y159.139 F152
G1 X100.315 Y159.142 F152
G1 X100.258 Y159.198 F152
G1 X100.209 Y159.253 F152
G1 X100.2 Y159.265 F152
G1 X100.163 Y159.31 F152
G1 X100.116 Y159.368 F152
G1 X100.086 Y159.405 F152
G1 X100.071 Y159.425 F152
G1 X100.031 Y159.482 F152
G1 X100.029 Y159.487 F152
G1 X99.971 Y159.578 F152
G1 X99.959 Y159.597 F152
G1 X99.925 Y159.654 F152
G1 X99.867 Y159.769 F152
G1 X99.857 Y159.791 F152
G1 X99.839 Y159.826 F152
G1 X99.814 Y159.883 F152
G1 X99.799 Y159.922 F152
G1 X99.792 Y159.94 F152
G1 X99.77 Y159.998 F152
G1 X99.748 Y160.055 F152
G1 X99.742 Y160.074 F152
G1 X99.73 Y160.112 F152
G1 X99.714 Y160.17 F152
G1 X99.698 Y160.227 F152
G1 X99.685 Y160.275 F152
G1 X99.682 Y160.284 F152
G1 X99.67 Y160.341 F152
G1 X99.658 Y160.399 F152
G1 X99.637 Y160.513 F152
G1 X99.628 Y160.57 F152
G1 Y160.584 F152
G1 X99.622 Y160.628 F152
G1 X99.61 Y160.742 F152
G1 X99.606 Y160.8 F152
G1 X99.603 Y160.857 F152
G1 X99.602 Y160.914 F152
G1 X99.599 Y160.971 F152
G1 Y161.029 F152
G1 X99.604 Y161.201 F152
G1 X99.608 Y161.258 F152
G1 X99.612 Y161.315 F152
G1 X99.623 Y161.43 F152
G1 X99.628 Y161.47 F152
G1 X99.629 Y161.487 F152
G1 X99.638 Y161.544 F152
G1 X99.646 Y161.601 F152
G1 X99.664 Y161.716 F152
G1 X99.691 Y161.831 F152
G1 X99.704 Y161.888 F152
G1 X99.717 Y161.945 F152
G1 X99.73 Y162.002 F152
G1 X99.742 Y162.054 F152
G1 X99.743 Y162.06 F152
G1 X99.756 Y162.117 F152
G1 X99.773 Y162.174 F152
G1 X99.791 Y162.232 F152
G1 X99.799 Y162.255 F152
G1 X99.81 Y162.289 F152
G1 X99.829 Y162.346 F152
G1 X99.849 Y162.403 F152
G1 X99.857 Y162.428 F152
G1 X99.867 Y162.461 F152
G1 X99.886 Y162.518 F152
G1 X99.906 Y162.575 F152
G1 X99.914 Y162.596 F152
G1 X99.929 Y162.632 F152
G1 X99.954 Y162.69 F152
G1 X99.971 Y162.728 F152
G1 X99.979 Y162.747 F152
G1 X100.003 Y162.804 F152
G1 X100.029 Y162.861 F152
G1 Y162.862 F152
G1 X100.079 Y162.976 F152
G1 X100.086 Y162.991 F152
G1 X100.106 Y163.033 F152
G1 X100.138 Y163.091 F152
G1 X100.143 Y163.1 F152
G1 X100.169 Y163.148 F152
G1 X100.232 Y163.263 F152
G1 X100.258 Y163.311 F152
G1 X100.262 Y163.32 F152
G1 X100.294 Y163.377 F152
G1 X100.315 Y163.412 F152
G1 X100.329 Y163.434 F152
G1 X100.368 Y163.492 F152
G1 X100.372 Y163.498 F152
G1 X100.43 Y163.584 F152
G1 X100.445 Y163.606 F152
G1 X100.522 Y163.721 F152
G1 X100.544 Y163.754 F152
G1 X100.562 Y163.778 F152
G1 X100.601 Y163.828 F152
G1 X100.607 Y163.835 F152
G1 X100.652 Y163.893 F152
G1 X100.659 Y163.901 F152
G1 X100.698 Y163.95 F152
G1 X100.716 Y163.97 F152
G1 X100.773 Y164.036 F152
G1 X100.798 Y164.064 F152
G1 X100.831 Y164.1 F152
G1 X100.851 Y164.122 F152
G1 X100.888 Y164.159 F152
G1 X100.907 Y164.179 F152
G1 X100.945 Y164.217 F152
G1 X100.963 Y164.236 F152
G1 X101.002 Y164.274 F152
G1 X101.025 Y164.294 F152
G1 X101.06 Y164.326 F152
G1 X101.088 Y164.351 F152
G1 X101.117 Y164.377 F152
G1 X101.153 Y164.408 F152
G1 X101.174 Y164.425 F152
G1 X101.227 Y164.465 F152
G1 X101.232 Y164.469 F152
G1 X101.289 Y164.514 F152
G1 X101.301 Y164.523 F152
G1 X101.346 Y164.558 F152
G1 X101.378 Y164.58 F152
G1 X101.461 Y164.633 F152
G1 X101.518 Y164.669 F152
G1 X101.558 Y164.694 F152
G1 X101.575 Y164.705 F152
G1 X101.633 Y164.737 F152
G1 X101.804 Y164.823 F152
G1 X101.862 Y164.85 F152
G1 X101.919 Y164.873 F152
G1 X102.091 Y164.937 F152
G1 X102.148 Y164.955 F152
G1 X102.205 Y164.97 F152
G1 X102.247 Y164.981 F152
G1 X102.263 Y164.985 F152
G1 X102.32 Y165.001 F152
G1 X102.377 Y165.013 F152
G1 X102.435 Y165.023 F152
G1 X102.492 Y165.032 F152
G1 X102.528 Y165.038 F152
G1 X102.549 Y165.042 F152
G1 X102.606 Y165.05 F152
G1 X102.721 Y165.059 F152
G1 X102.778 Y165.064 F152
G1 X102.836 Y165.067 F152
G1 X103.007 F152
G1 X103.065 Y165.066 F152
G1 X103.122 Y165.061 F152
G1 X103.179 Y165.058 F152
G1 X103.237 Y165.053 F152
G1 X103.294 Y165.048 F152
G1 X103.351 Y165.04 F152
G1 X103.36 Y165.038 F152
G1 X103.408 Y165.032 F152
G1 X103.466 Y165.024 F152
G1 X103.523 Y165.015 F152
G1 X103.58 Y165.001 F152
G1 X103.638 Y164.989 F152
G1 X103.672 Y164.981 F152
G1 X103.695 Y164.976 F152
G1 X103.752 Y164.963 F152
G1 X103.809 Y164.95 F152
G1 X103.867 Y164.937 F152
G1 X103.924 Y164.924 F152
G1 X103.925 F152
G1 X103.981 Y164.907 F152
G1 X104.039 Y164.889 F152
G1 X104.096 Y164.871 F152
G1 X104.108 Y164.866 F152
G1 X104.153 Y164.852 F152
G1 X104.268 Y164.816 F152
G1 X104.288 Y164.809 F152
G1 X104.325 Y164.797 F152
G1 X104.382 Y164.778 F152
G1 X104.44 Y164.754 F152
G1 X104.447 Y164.752 F152
G1 X104.497 Y164.732 F152
G1 X104.554 Y164.71 F152
G1 X104.592 Y164.694 F152
G1 X104.611 Y164.687 F152
G1 X104.669 Y164.665 F152
G1 X104.726 Y164.642 F152
G1 X104.738 Y164.637 F152
G1 X104.783 Y164.618 F152
G1 X104.841 Y164.592 F152
G1 X104.867 Y164.58 F152
G1 X104.898 Y164.566 F152
G1 X104.955 Y164.54 F152
G1 X104.991 Y164.523 F152
G1 X105.012 Y164.513 F152
G1 X105.07 Y164.486 F152
G1 X105.114 Y164.465 F152
G1 X105.127 Y164.46 F152
G1 X105.184 Y164.433 F152
G1 X105.231 Y164.408 F152
G1 X105.242 Y164.403 F152
G1 X105.299 Y164.372 F152
G1 X105.356 Y164.341 F152
G1 X105.413 Y164.311 F152
G1 X105.446 Y164.294 F152
G1 X105.471 Y164.28 F152
G1 X105.528 Y164.25 F152
G1 X105.553 Y164.236 F152
G1 X105.585 Y164.218 F152
G1 X105.643 Y164.183 F152
G1 X105.7 Y164.148 F152
G1 X105.742 Y164.122 F152
G1 X105.757 Y164.113 F152
G1 X105.814 Y164.077 F152
G1 X105.834 Y164.064 F152
G1 X105.872 Y164.041 F152
G1 X105.926 Y164.007 F152
G1 X105.929 Y164.006 F152
G1 X105.986 Y163.969 F152
G1 X106.012 Y163.95 F152
G1 X106.044 Y163.927 F152
G1 X106.091 Y163.893 F152
G1 X106.158 Y163.843 F152
G1 X106.169 Y163.835 F152
G1 X106.215 Y163.802 F152
G1 X106.248 Y163.778 F152
G1 X106.273 Y163.76 F152
G1 X106.33 Y163.718 F152
G1 X106.387 Y163.67 F152
G1 X106.445 Y163.62 F152
G1 X106.46 Y163.606 F152
G1 X106.502 Y163.57 F152
G1 X106.526 Y163.549 F152
G1 X106.559 Y163.519 F152
G1 X106.616 Y163.47 F152
G1 X106.657 Y163.434 F152
G1 X106.674 Y163.419 F152
G1 X106.715 Y163.377 F152
G1 X106.731 Y163.36 F152
G1 X106.788 Y163.3 F152
G1 X106.823 Y163.263 F152
G1 X106.846 Y163.239 F152
G1 X106.878 Y163.205 F152
G1 X106.903 Y163.178 F152
G1 X106.96 Y163.118 F152
G1 X106.984 Y163.091 F152
G1 X107.017 Y163.05 F152
G1 X107.03 Y163.033 F152
G1 X107.074 Y162.976 F152
G1 X107.075 Y162.975 F152
G1 X107.119 Y162.919 F152
G1 X107.132 Y162.902 F152
G1 X107.163 Y162.862 F152
G1 X107.189 Y162.828 F152
G1 X107.207 Y162.804 F152
G1 X107.247 Y162.752 F152
G1 X107.25 Y162.747 F152
G1 X107.287 Y162.69 F152
G1 X107.304 Y162.664 F152
G1 X107.324 Y162.632 F152
G1 X107.36 Y162.575 F152
G1 X107.361 Y162.573 F152
G1 X107.397 Y162.518 F152
G1 X107.418 Y162.484 F152
G1 X107.434 Y162.461 F152
G1 X107.469 Y162.403 F152
G1 X107.476 Y162.391 F152
G1 X107.5 Y162.346 F152
G1 X107.529 Y162.289 F152
G1 X107.533 Y162.283 F152
G1 X107.56 Y162.232 F152
G1 X107.621 Y162.117 F152
G1 X107.648 Y162.065 F152
G1 X107.65 Y162.06 F152
G1 X107.676 Y162.002 F152
G1 X107.701 Y161.945 F152
G1 X107.705 Y161.936 F152
G1 X107.726 Y161.888 F152
G1 X107.751 Y161.831 F152
G1 X107.762 Y161.805 F152
G1 X107.776 Y161.773 F152
G1 X107.801 Y161.716 F152
G1 X107.819 Y161.667 F152
G1 X107.822 Y161.659 F152
G1 X107.843 Y161.601 F152
G1 X107.862 Y161.544 F152
G1 X107.877 Y161.503 F152
G1 X107.883 Y161.487 F152
G1 X107.934 Y161.338 F152
G1 X107.941 Y161.315 F152
G1 X107.956 Y161.258 F152
G1 X107.971 Y161.201 F152
G1 X107.986 Y161.143 F152
G1 X107.991 Y161.12 F152
G1 X108 Y161.086 F152
G1 X108.015 Y161.029 F152
G1 X108.03 Y160.971 F152
G1 X108.042 Y160.914 F152
G1 X108.049 Y160.879 F152
G1 X108.053 Y160.857 F152
G1 X108.063 Y160.8 F152
G1 X108.074 Y160.742 F152
G1 X108.083 Y160.685 F152
G1 X108.089 Y160.628 F152
G1 X108.103 Y160.513 F152
G1 X108.106 Y160.487 F152
G1 X108.109 Y160.456 F152
G1 X108.113 Y160.399 F152
G1 X108.12 Y160.284 F152
G1 X108.123 Y160.227 F152
G1 X108.125 Y160.112 F152
G1 Y159.998 F152
G1 X108.123 Y159.94 F152
G1 X108.117 Y159.826 F152
G1 X108.116 Y159.769 F152
G1 X108.111 Y159.711 F152
G1 X108.106 Y159.664 F152
G1 X108.089 Y159.482 F152
G1 X108.08 Y159.425 F152
G1 X108.056 Y159.253 F152
G1 X108.049 Y159.212 F152
G1 X108.046 Y159.196 F152
G1 X108.035 Y159.139 F152
G1 X108.023 Y159.081 F152
G1 X108.002 Y158.967 F152
G1 X107.962 Y158.795 F152
G1 X107.947 Y158.738 F152
G1 X107.934 Y158.681 F152
G1 Y158.68 F152
G1 X107.919 Y158.623 F152
G1 X107.902 Y158.566 F152
G1 X107.886 Y158.508 F152
G1 X107.877 Y158.477 F152
G1 X107.87 Y158.451 F152
G1 X107.853 Y158.394 F152
G1 X107.835 Y158.337 F152
G1 X107.819 Y158.291 F152
G1 X107.816 Y158.279 F152
G1 X107.778 Y158.165 F152
G1 X107.762 Y158.117 F152
G1 X107.738 Y158.05 F152
G1 X107.716 Y157.993 F152
G1 X107.673 Y157.878 F152
G1 X107.65 Y157.821 F152
G1 X107.648 Y157.815 F152
G1 X107.625 Y157.764 F152
G1 X107.601 Y157.707 F152
G1 X107.59 Y157.683 F152
G1 X107.576 Y157.649 F152
G1 X107.551 Y157.592 F152
G1 X107.533 Y157.552 F152
G1 X107.526 Y157.535 F152
G1 X107.497 Y157.477 F152
G1 X107.476 Y157.435 F152
G1 X107.469 Y157.42 F152
G1 X107.439 Y157.363 F152
G1 X107.418 Y157.323 F152
G1 X107.409 Y157.306 F152
G1 X107.38 Y157.248 F152
G1 X107.361 Y157.215 F152
G1 X107.347 Y157.191 F152
G1 X107.312 Y157.134 F152
G1 X107.304 Y157.121 F152
G1 X107.277 Y157.076 F152
G1 X107.247 Y157.027 F152
G1 X107.242 Y157.019 F152
G1 X107.205 Y156.962 F152
G1 X107.123 Y156.847 F152
G1 X107.077 Y156.79 F152
G1 X107.075 Y156.787 F152
G1 X107.03 Y156.733 F152
G1 X107.017 Y156.719 F152
G1 X106.977 Y156.676 F152
G1 X106.96 Y156.659 F152
G1 X106.921 Y156.618 F152
G1 X106.903 Y156.6 F152
G1 X106.863 Y156.561 F152
G1 X106.846 Y156.546 F152
G1 X106.792 Y156.504 F152
G1 X106.731 Y156.458 F152
G1 X106.674 Y156.417 F152
G1 X106.63 Y156.389 F152
G1 X106.616 Y156.381 F152
G1 X106.559 Y156.352 F152
G1 X106.513 Y156.332 F152
G1 X106.502 Y156.327 F152
G1 X106.445 Y156.301 F152
G1 X106.387 Y156.279 F152
G1 X106.33 Y156.262 F152
G1 X106.273 Y156.25 F152
G1 X106.215 Y156.241 F152
G1 X106.158 Y156.233 F152
G1 X106.101 Y156.226 F152
G1 X106.044 Y156.224 F152
G1 X105.986 Y156.226 F152
G1 X105.929 Y156.232 F152
G1 X105.814 Y156.251 F152
G1 X105.757 Y156.264 F152
G1 X105.719 Y156.275 F152
G1 X105.7 Y156.28 F152
G1 X105.643 Y156.301 F152
G1 X105.639 Y156.303 F152
G1 X105.614 Y156.314 F152
G1 X105.585 Y156.328 F152
; MOVEMENT_LINK_TRANSITION
G1 Y156.32 F152
; MOVEMENT_CUTTING
G1 X105.614 Y156.278 F152
G1 X105.617 Y156.275 F152
G1 X105.643 Y156.235 F152
G1 X105.655 Y156.217 F152
G1 X105.694 Y156.16 F152
G1 X105.7 Y156.149 F152
G1 X105.728 Y156.103 F152
G1 X105.794 Y155.988 F152
G1 X105.814 Y155.952 F152
G1 X105.827 Y155.931 F152
G1 X105.86 Y155.874 F152
G1 X105.872 Y155.853 F152
G1 X105.893 Y155.816 F152
G1 X105.926 Y155.759 F152
G1 X105.929 Y155.753 F152
G1 X105.955 Y155.702 F152
G1 X105.983 Y155.645 F152
G1 X105.986 Y155.637 F152
G1 X106.01 Y155.587 F152
G1 X106.038 Y155.53 F152
G1 X106.044 Y155.518 F152
G1 X106.063 Y155.473 F152
G1 X106.087 Y155.415 F152
G1 X106.101 Y155.382 F152
G1 X106.112 Y155.358 F152
G1 X106.135 Y155.301 F152
G1 X106.155 Y155.244 F152
G1 X106.158 Y155.235 F152
G1 X106.175 Y155.186 F152
G1 X106.195 Y155.129 F152
G1 X106.214 Y155.072 F152
G1 X106.215 Y155.065 F152
G1 X106.229 Y155.014 F152
G1 X106.272 Y154.843 F152
G1 X106.273 Y154.835 F152
G1 X106.282 Y154.785 F152
G1 X106.29 Y154.728 F152
G1 X106.304 Y154.614 F152
G1 X106.309 Y154.556 F152
G1 Y154.499 F152
G1 X106.307 Y154.384 F152
G1 X106.304 Y154.327 F152
G1 X106.297 Y154.27 F152
G1 X106.286 Y154.213 F152
G1 X106.274 Y154.155 F152
G1 X106.273 Y154.153 F152
G1 X106.261 Y154.098 F152
G1 X106.246 Y154.041 F152
G1 X106.225 Y153.983 F152
G1 X106.215 Y153.96 F152
G1 X106.199 Y153.926 F152
G1 X106.144 Y153.812 F152
G1 X106.111 Y153.754 F152
G1 X106.101 Y153.739 F152
G1 X106.07 Y153.697 F152
G1 X106.044 Y153.663 F152
G1 X106.024 Y153.64 F152
G1 X105.986 Y153.597 F152
G1 X105.975 Y153.583 F152
G1 X105.929 Y153.533 F152
G1 X105.921 Y153.525 F152
G1 X105.872 Y153.481 F152
G1 X105.855 Y153.468 F152
G1 X105.814 Y153.438 F152
G1 X105.778 Y153.411 F152
G1 X105.757 Y153.395 F152
G1 X105.7 Y153.355 F152
G1 X105.696 Y153.353 F152
G1 X105.643 Y153.322 F152
G1 X105.59 Y153.296 F152
G1 X105.585 Y153.293 F152
G1 X105.528 Y153.265 F152
G1 X105.472 Y153.239 F152
G1 X105.471 Y153.238 F152
G1 X105.413 Y153.216 F152
G1 X105.356 Y153.197 F152
G1 X105.313 Y153.182 F152
G1 X105.299 Y153.176 F152
G1 X105.242 Y153.158 F152
G1 X105.127 Y153.128 F152
G1 X105.111 Y153.124 F152
G1 X105.07 Y153.114 F152
G1 X105.012 Y153.101 F152
G1 X104.898 Y153.078 F152
G1 X104.841 Y153.067 F152
G1 X104.84 F152
G1 X104.783 Y153.057 F152
G1 X104.726 Y153.048 F152
G1 X104.611 Y153.029 F152
G1 X104.497 Y153.012 F152
G1 X104.476 Y153.01 F152
G1 X104.44 Y153.004 F152
G1 X104.325 Y152.988 F152
G1 X104.039 Y152.952 F152
G1 X104.032 F152
G1 X103.981 Y152.946 F152
G1 X103.809 Y152.927 F152
G1 X103.752 Y152.922 F152
G1 X103.695 Y152.916 F152
G1 X103.58 Y152.905 F152
G1 X103.466 Y152.896 F152
G1 X103.45 Y152.895 F152
G1 X103.408 Y152.892 F152
G1 X103.351 Y152.887 F152
G1 X103.294 Y152.882 F152
G1 X103.237 Y152.877 F152
G1 X103.122 Y152.872 F152
G1 X103.065 Y152.87 F152
G1 X102.95 Y152.865 F152
G1 X102.893 Y152.863 F152
G1 X102.836 Y152.86 F152
G1 X102.778 Y152.859 F152
G1 X102.664 F152
G1 X102.435 Y152.862 F152
G1 X102.377 F152
G1 X102.32 Y152.866 F152
G1 X102.205 Y152.875 F152
G1 X102.148 Y152.878 F152
G1 X101.976 Y152.892 F152
G1 X101.947 Y152.895 F152
G1 X101.919 Y152.899 F152
G1 X101.862 Y152.908 F152
G1 X101.804 Y152.916 F152
G1 X101.747 Y152.925 F152
G1 X101.69 Y152.933 F152
G1 X101.575 Y152.951 F152
G1 X101.518 Y152.963 F152
G1 X101.461 Y152.977 F152
G1 X101.403 Y152.991 F152
G1 X101.346 Y153.004 F152
G1 X101.325 Y153.01 F152
G1 X101.289 Y153.018 F152
G1 X101.232 Y153.031 F152
G1 X101.174 Y153.047 F152
G1 X101.117 Y153.066 F152
G1 X101.116 Y153.067 F152
G1 X101.06 Y153.087 F152
G1 X101.002 Y153.106 F152
G1 X100.952 Y153.124 F152
G1 X100.945 Y153.127 F152
G1 X100.888 Y153.147 F152
G1 X100.831 Y153.167 F152
G1 X100.797 Y153.182 F152
G1 X100.773 Y153.192 F152
G1 X100.716 Y153.218 F152
G1 X100.671 Y153.239 F152
G1 X100.659 Y153.244 F152
G1 X100.601 Y153.274 F152
G1 X100.56 Y153.296 F152
G1 X100.544 Y153.304 F152
G1 X100.487 Y153.336 F152
G1 X100.456 Y153.353 F152
G1 X100.43 Y153.37 F152
G1 X100.372 Y153.407 F152
G1 X100.366 Y153.411 F152
G1 X100.315 Y153.444 F152
G1 X100.281 Y153.468 F152
G1 X100.258 Y153.485 F152
G1 X100.205 Y153.525 F152
G1 X100.2 Y153.529 F152
G1 X100.143 Y153.573 F152
G1 X100.132 Y153.583 F152
G1 X100.086 Y153.624 F152
G1 X100.069 Y153.64 F152
G1 X100.029 Y153.676 F152
G1 X100.006 Y153.697 F152
G1 X99.971 Y153.732 F152
G1 X99.951 Y153.754 F152
G1 X99.914 Y153.795 F152
G1 X99.899 Y153.812 F152
G1 X99.857 Y153.858 F152
G1 X99.848 Y153.869 F152
G1 X99.799 Y153.933 F152
G1 X99.761 Y153.983 F152
G1 X99.742 Y154.009 F152
G1 X99.721 Y154.041 F152
G1 X99.686 Y154.098 F152
G1 X99.685 Y154.1 F152
G1 X99.651 Y154.155 F152
G1 X99.628 Y154.195 F152
G1 X99.618 Y154.213 F152
G1 X99.589 Y154.27 F152
G1 X99.57 Y154.308 F152
G1 X99.561 Y154.327 F152
G1 X99.534 Y154.384 F152
G1 X99.489 Y154.499 F152
G1 X99.467 Y154.556 F152
G1 X99.456 Y154.59 F152
G1 X99.449 Y154.614 F152
G1 X99.432 Y154.671 F152
G1 X99.415 Y154.728 F152
G1 X99.4 Y154.785 F152
G1 X99.398 Y154.794 F152
G1 X99.388 Y154.843 F152
G1 X99.377 Y154.9 F152
G1 X99.365 Y154.957 F152
G1 X99.355 Y155.014 F152
G1 X99.348 Y155.072 F152
G1 X99.341 Y155.137 F152
G1 X99.34 Y155.143 F152
G1 X99.338 Y155.158 F152
G1 Y155.167 F152
G1 X99.337 Y155.172 F152
G1 X99.336 Y155.176 F152
; MOVEMENT_LINK_TRANSITION
G1 Y155.177 F152
; MOVEMENT_CUTTING
G1 Y155.176 F152
G1 X99.334 Y155.167 F152
G1 X99.333 Y155.164 F152
G1 X99.332 Y155.158 F152
G1 X99.329 Y155.143 F152
G1 X99.327 Y155.138 F152
G1 X99.325 Y155.129 F152
G1 X99.308 Y155.072 F152
G1 X99.292 Y155.014 F152
G1 X99.284 Y154.989 F152
G1 X99.275 Y154.957 F152
G1 X99.258 Y154.9 F152
G1 X99.242 Y154.843 F152
G1 X99.227 Y154.793 F152
G1 X99.224 Y154.785 F152
G1 X99.203 Y154.728 F152
G1 X99.18 Y154.671 F152
G1 X99.169 Y154.645 F152
G1 X99.157 Y154.614 F152
G1 X99.134 Y154.556 F152
G1 X99.112 Y154.502 F152
G1 X99.111 Y154.499 F152
G1 X99.088 Y154.442 F152
G1 X99.061 Y154.384 F152
G1 X99.055 Y154.374 F152
G1 X99.03 Y154.327 F152
G1 X98.998 Y154.27 F152
G1 X98.968 Y154.213 F152
G1 X98.94 Y154.162 F152
G1 X98.937 Y154.155 F152
G1 X98.905 Y154.098 F152
G1 X98.883 Y154.062 F152
G1 X98.869 Y154.041 F152
G1 X98.826 Y153.983 F152
G1 X98.784 Y153.926 F152
G1 X98.768 Y153.904 F152
G1 X98.742 Y153.869 F152
G1 X98.711 Y153.826 F152
G1 X98.701 Y153.812 F152
G1 X98.656 Y153.754 F152
G1 X98.654 Y153.752 F152
G1 X98.596 Y153.688 F152
G1 X98.553 Y153.64 F152
G1 X98.539 Y153.625 F152
G1 X98.497 Y153.583 F152
G1 X98.482 Y153.568 F152
G1 X98.435 Y153.525 F152
G1 X98.425 Y153.515 F152
G1 X98.374 Y153.468 F152
G1 X98.367 Y153.462 F152
G1 X98.31 Y153.415 F152
G1 X98.304 Y153.411 F152
G1 X98.253 Y153.37 F152
G1 X98.233 Y153.353 F152
G1 X98.195 Y153.326 F152
G1 X98.138 Y153.285 F152
G1 X98.081 Y153.246 F152
G1 X98.07 Y153.239 F152
G1 X98.024 Y153.209 F152
G1 X97.977 Y153.182 F152
G1 X97.966 Y153.175 F152
G1 X97.909 Y153.141 F152
G1 X97.879 Y153.124 F152
G1 X97.794 Y153.08 F152
G1 X97.767 Y153.067 F152
G1 X97.737 Y153.052 F152
G1 X97.68 Y153.025 F152
G1 X97.643 Y153.01 F152
G1 X97.508 Y152.957 F152
G1 X97.497 Y152.952 F152
G1 X97.479 Y152.945 F152
G1 X97.451 Y152.934 F152
G1 X97.443 Y152.931 F152
G1 X97.436 Y152.929 F152
G1 X97.422 Y152.923 F152
G1 X97.419 Y152.922 F152
G1 X97.415 Y152.92 F152
G1 X97.411 Y152.919 F152
G1 X97.41 Y152.918 F152
G1 X97.408 F152
G1 X97.406 Y152.917 F152
; MOVEMENT_LINK_TRANSITION
G1 X97.408 Y152.916 F152
; MOVEMENT_CUTTING
G1 X97.41 F152
G1 X97.411 Y152.917 F152
G1 X97.415 F152
G1 X97.418 F152
G1 X97.422 F152
G1 X97.436 Y152.918 F152
G1 X97.451 Y152.919 F152
G1 X97.479 Y152.922 F152
G1 X97.508 Y152.924 F152
G1 X97.565 Y152.929 F152
G1 X97.623 Y152.931 F152
G1 X97.68 Y152.934 F152
G1 X97.737 Y152.935 F152
G1 X97.794 Y152.938 F152
G1 X97.909 Y152.942 F152
G1 X97.966 Y152.944 F152
G1 X98.024 Y152.945 F152
G1 X98.367 F152
G1 X98.425 Y152.944 F152
G1 X98.482 F152
G1 X98.539 Y152.942 F152
G1 X98.654 Y152.938 F152
G1 X98.711 Y152.935 F152
G1 X98.826 Y152.932 F152
G1 X98.883 Y152.929 F152
G1 X98.94 Y152.927 F152
G1 X98.997 Y152.924 F152
G1 X99.055 Y152.919 F152
G1 X99.227 Y152.909 F152
G1 X99.284 Y152.904 F152
G1 X99.398 Y152.897 F152
G1 X99.415 Y152.895 F152
G1 X99.456 Y152.892 F152
G1 X99.914 Y152.849 F152
G1 X99.971 Y152.841 F152
G1 X100.001 Y152.838 F152
G1 X100.029 Y152.835 F152
G1 X100.143 Y152.821 F152
G1 X100.2 Y152.815 F152
G1 X100.258 Y152.807 F152
G1 X100.315 Y152.801 F152
G1 X100.43 Y152.787 F152
G1 X100.47 Y152.781 F152
G1 X100.487 Y152.779 F152
G1 X100.544 Y152.771 F152
G1 X100.601 Y152.762 F152
G1 X100.831 Y152.73 F152
G1 X100.871 Y152.723 F152
G1 X100.888 Y152.722 F152
G1 X100.945 Y152.713 F152
G1 X101.002 Y152.703 F152
G1 X101.06 Y152.694 F152
G1 X101.117 Y152.684 F152
G1 X101.174 Y152.675 F152
G1 X101.225 Y152.666 F152
G1 X101.232 Y152.665 F152
G1 X101.289 Y152.656 F152
G1 X101.346 Y152.646 F152
G1 X101.403 Y152.637 F152
G1 X101.518 Y152.616 F152
G1 X101.556 Y152.609 F152
G1 X101.575 Y152.605 F152
G1 X101.633 Y152.595 F152
G1 X101.862 Y152.552 F152
G1 X101.865 F152
G1 X101.919 Y152.542 F152
G1 X102.148 Y152.495 F152
G1 X102.15 Y152.494 F152
G1 X102.205 Y152.484 F152
G1 X102.263 Y152.472 F152
G1 X102.32 Y152.459 F152
G1 X102.377 Y152.448 F152
G1 X102.549 Y152.41 F152
G1 X102.606 Y152.397 F152
G1 X102.664 Y152.384 F152
G1 X102.683 Y152.38 F152
G1 X102.721 Y152.372 F152
G1 X102.778 Y152.358 F152
G1 X102.836 Y152.346 F152
G1 X102.893 Y152.332 F152
G1 X102.934 Y152.322 F152
G1 X102.95 Y152.319 F152
G1 X103.007 Y152.305 F152
G1 X103.065 Y152.291 F152
G1 X103.122 Y152.277 F152
G1 X103.169 Y152.265 F152
G1 X103.179 Y152.263 F152
G1 X103.237 Y152.249 F152
G1 X103.294 Y152.236 F152
G1 X103.351 Y152.221 F152
G1 X103.401 Y152.208 F152
G1 X103.466 Y152.192 F152
G1 X103.58 Y152.161 F152
G1 X103.621 Y152.151 F152
G1 X103.638 Y152.147 F152
G1 X103.809 Y152.101 F152
G1 X103.924 Y152.069 F152
G1 X103.981 Y152.054 F152
G1 X104.039 Y152.038 F152
G1 X104.043 Y152.036 F152
G1 X104.096 Y152.022 F152
G1 X104.21 Y151.989 F152
G1 X104.247 Y151.979 F152
G1 X104.268 Y151.973 F152
G1 X104.44 Y151.922 F152
G1 Y151.921 F152
G1 X104.497 Y151.905 F152
G1 X104.611 Y151.871 F152
G1 X104.633 Y151.864 F152
G1 X104.669 Y151.853 F152
G1 X104.783 Y151.818 F152
G1 X104.816 Y151.807 F152
G1 X104.841 Y151.8 F152
G1 X104.955 Y151.764 F152
G1 X104.999 Y151.75 F152
G1 X105.012 Y151.746 F152
G1 X105.127 Y151.708 F152
G1 X105.174 Y151.692 F152
G1 X105.184 Y151.69 F152
G1 X105.299 Y151.652 F152
G1 X105.348 Y151.635 F152
G1 X105.413 Y151.614 F152
G1 X105.471 Y151.594 F152
G1 X105.517 Y151.578 F152
G1 X105.528 Y151.574 F152
G1 X105.643 Y151.535 F152
G1 X105.684 Y151.521 F152
G1 X105.7 Y151.515 F152
G1 X105.757 Y151.495 F152
G1 X105.814 Y151.475 F152
G1 X105.848 Y151.463 F152
G1 X105.872 Y151.454 F152
G1 X105.929 Y151.435 F152
G1 X105.986 Y151.414 F152
G1 X106.007 Y151.406 F152
G1 X106.044 Y151.393 F152
G1 X106.101 Y151.373 F152
G1 X106.158 Y151.351 F152
G1 X106.166 Y151.349 F152
G1 X106.215 Y151.331 F152
G1 X106.273 Y151.309 F152
G1 X106.321 Y151.291 F152
G1 X106.33 Y151.289 F152
G1 X106.445 Y151.246 F152
G1 X106.476 Y151.234 F152
G1 X106.502 Y151.224 F152
G1 X106.616 Y151.181 F152
G1 X106.628 Y151.177 F152
G1 X106.674 Y151.16 F152
G1 X106.731 Y151.138 F152
G1 X106.78 Y151.12 F152
G1 X106.788 Y151.117 F152
G1 X106.846 Y151.095 F152
G1 X106.903 Y151.073 F152
G1 X106.931 Y151.062 F152
G1 X106.96 Y151.052 F152
G1 X107.017 Y151.029 F152
G1 X107.189 Y150.965 F152
G1 X107.233 Y150.948 F152
G1 X107.247 Y150.943 F152
G1 X107.361 Y150.9 F152
G1 X107.385 Y150.89 F152
G1 X107.418 Y150.878 F152
G1 X107.533 Y150.835 F152
G1 X107.537 Y150.833 F152
G1 X107.59 Y150.813 F152
G1 X107.705 Y150.772 F152
G1 X107.762 Y150.753 F152
G1 X107.819 Y150.732 F152
G1 X107.855 Y150.719 F152
G1 X107.877 Y150.711 F152
G1 X107.991 Y150.67 F152
G1 X108.015 Y150.661 F152
G1 X108.049 Y150.65 F152
G1 X108.106 Y150.63 F152
G1 X108.163 Y150.612 F152
G1 X108.186 Y150.604 F152
G1 X108.22 Y150.593 F152
G1 X108.278 Y150.575 F152
G1 X108.335 Y150.557 F152
G1 X108.366 Y150.547 F152
G1 X108.45 Y150.521 F152
G1 X108.507 Y150.502 F152
G1 X108.545 Y150.49 F152
G1 X108.564 Y150.484 F152
G1 X108.621 Y150.468 F152
G1 X108.736 Y150.438 F152
G1 X108.754 Y150.432 F152
G1 X108.793 Y150.421 F152
G1 X108.965 Y150.376 F152
G1 X108.967 Y150.375 F152
G1 X109.022 Y150.361 F152
G1 X109.08 Y150.346 F152
G1 X109.137 Y150.335 F152
G1 X109.194 Y150.322 F152
G1 X109.213 Y150.318 F152
G1 X109.252 Y150.31 F152
G1 X109.309 Y150.298 F152
G1 X109.366 Y150.285 F152
G1 X109.423 Y150.274 F152
G1 X109.481 Y150.261 F152
G1 X109.483 Y150.26 F152
G1 X109.538 Y150.249 F152
G1 X109.595 Y150.239 F152
G1 X109.767 Y150.212 F152
G1 X109.823 Y150.203 F152
G1 X109.824 F152
G1 X110.054 Y150.167 F152
G1 X110.111 Y150.16 F152
G1 X110.225 Y150.148 F152
G1 X110.238 Y150.146 F152
G1 X110.283 Y150.141 F152
G1 X110.569 Y150.11 F152
G1 X110.626 Y150.105 F152
G1 X110.856 Y150.09 F152
G1 X110.875 Y150.089 F152
G1 X110.913 Y150.087 F152
G1 X111.027 Y150.08 F152
G1 X111.085 Y150.075 F152
G1 X111.142 Y150.072 F152
G1 X111.199 Y150.069 F152
G1 X111.257 Y150.068 F152
G1 X111.314 Y150.066 F152
G1 X111.371 Y150.065 F152
G1 X111.428 Y150.064 F152
G1 X111.486 Y150.063 F152
G1 X111.6 Y150.059 F152
G1 X111.658 Y150.058 F152
G1 X111.715 Y150.056 F152
G1 X111.829 F152
G1 X111.944 Y150.058 F152
G1 X112.001 F152
G1 X112.173 Y150.061 F152
G1 X112.23 F152
G1 X112.288 Y150.062 F152
G1 X112.345 Y150.064 F152
G1 X112.46 Y150.069 F152
G1 X112.517 Y150.071 F152
G1 X112.861 Y150.087 F152
G1 X112.901 Y150.089 F152
G1 X112.918 Y150.09 F152
G1 X113.433 Y150.131 F152
G1 X113.491 Y150.138 F152
G1 X113.548 Y150.144 F152
G1 X113.568 Y150.146 F152
G1 X113.605 Y150.15 F152
G1 X113.663 Y150.157 F152
G1 X113.72 Y150.164 F152
G1 X113.892 Y150.183 F152
G1 X113.949 Y150.19 F152
G1 X114.044 Y150.203 F152
G1 X114.064 Y150.207 F152
G1 X114.121 Y150.215 F152
G1 X114.178 Y150.224 F152
G1 X114.235 Y150.232 F152
G1 X114.35 Y150.25 F152
G1 X114.407 Y150.258 F152
G1 X114.427 Y150.26 F152
G1 X114.465 Y150.267 F152
G1 X114.694 Y150.31 F152
G1 X114.738 Y150.318 F152
G1 X114.751 Y150.32 F152
G1 X114.923 Y150.353 F152
G1 X114.98 Y150.365 F152
G1 X115.026 Y150.375 F152
G1 X115.095 Y150.391 F152
G1 X115.283 Y150.432 F152
G1 X115.324 Y150.442 F152
G1 X115.381 Y150.455 F152
G1 X115.438 Y150.468 F152
G1 X115.496 Y150.483 F152
G1 X115.523 Y150.49 F152
G1 X115.553 Y150.498 F152
G1 X115.61 Y150.512 F152
G1 X115.668 Y150.527 F152
G1 X115.725 Y150.541 F152
G1 X115.748 Y150.547 F152
G1 X115.782 Y150.556 F152
G1 X115.839 Y150.57 F152
G1 X115.897 Y150.585 F152
G1 X115.954 Y150.601 F152
G1 X115.965 Y150.604 F152
G1 X116.011 Y150.617 F152
G1 X116.069 Y150.634 F152
G1 X116.126 Y150.649 F152
G1 X116.171 Y150.661 F152
G1 X116.183 Y150.665 F152
G1 X116.298 Y150.697 F152
G1 X116.355 Y150.712 F152
G1 X116.376 Y150.719 F152
G1 X116.412 Y150.729 F152
G1 X116.47 Y150.745 F152
G1 X116.527 Y150.762 F152
G1 X116.574 Y150.776 F152
G1 X116.584 Y150.779 F152
G1 X116.641 Y150.796 F152
G1 X116.699 Y150.812 F152
G1 X116.756 Y150.829 F152
G1 X116.773 Y150.833 F152
G1 X116.813 Y150.845 F152
G1 X116.871 Y150.862 F152
G1 X116.928 Y150.878 F152
G1 X116.972 Y150.89 F152
G1 X116.985 Y150.895 F152
G1 X117.1 Y150.927 F152
G1 X117.157 Y150.944 F152
G1 X117.171 Y150.948 F152
G1 X117.214 Y150.96 F152
G1 X117.272 Y150.977 F152
G1 X117.329 Y150.993 F152
G1 X117.371 Y151.005 F152
G1 X117.386 Y151.009 F152
G1 X117.443 Y151.026 F152
G1 X117.558 Y151.056 F152
G1 X117.581 Y151.062 F152
G1 X117.615 Y151.072 F152
G1 X117.673 Y151.087 F152
G1 X117.73 Y151.103 F152
G1 X117.787 Y151.119 F152
G1 X117.792 Y151.12 F152
G1 X117.844 Y151.134 F152
G1 X118.016 Y151.177 F152
G1 X118.018 F152
G1 X118.074 Y151.191 F152
G1 X118.131 Y151.205 F152
G1 X118.245 Y151.233 F152
G1 X118.251 Y151.234 F152
G1 X118.303 Y151.248 F152
G1 X118.417 Y151.273 F152
G1 X118.475 Y151.284 F152
G1 X118.509 Y151.291 F152
G1 X118.532 Y151.297 F152
G1 X118.589 Y151.309 F152
G1 X118.646 Y151.321 F152
G1 X118.704 Y151.333 F152
G1 X118.761 Y151.345 F152
G1 X118.778 Y151.349 F152
G1 X118.818 Y151.358 F152
G1 X119.047 Y151.397 F152
G1 X119.105 Y151.406 F152
G1 X119.106 F152
G1 X119.162 Y151.416 F152
G1 X119.277 Y151.436 F152
G1 X119.334 Y151.444 F152
G1 X119.391 Y151.452 F152
G1 X119.489 Y151.463 F152
G1 X119.506 Y151.466 F152
G1 X119.563 Y151.472 F152
G1 X119.62 Y151.479 F152
G1 X119.678 Y151.486 F152
G1 X119.792 Y151.5 F152
G1 X119.849 Y151.506 F152
G1 X119.907 Y151.511 F152
G1 X120.021 Y151.518 F152
G1 X120.069 Y151.521 F152
G1 X120.079 F152
G1 X120.365 Y151.539 F152
G1 X120.422 Y151.542 F152
G1 X120.651 F152
G1 X120.709 Y151.543 F152
G1 X120.938 F152
G1 X120.995 Y151.54 F152
G1 X121.052 Y151.537 F152
G1 X121.11 Y151.534 F152
G1 X121.224 Y151.527 F152
G1 X121.282 Y151.524 F152
G1 X121.336 Y151.521 F152
G1 X121.339 F152
G1 X121.396 Y151.518 F152
G1 X121.453 Y151.514 F152
G1 X121.511 Y151.509 F152
G1 X121.74 Y151.484 F152
G1 X121.797 Y151.477 F152
G1 X121.912 Y151.464 F152
G1 X121.919 Y151.463 F152
G1 X121.969 Y151.458 F152
G1 X122.026 Y151.45 F152
G1 X122.255 Y151.414 F152
G1 X122.306 Y151.406 F152
G1 X122.313 Y151.405 F152
G1 X122.37 Y151.396 F152
G1 X122.427 Y151.388 F152
G1 X122.485 Y151.378 F152
G1 X122.599 Y151.357 F152
G1 X122.64 Y151.349 F152
G1 X122.656 Y151.346 F152
G1 X122.771 Y151.325 F152
G1 X122.828 Y151.313 F152
G1 X122.886 Y151.302 F152
G1 X122.941 Y151.291 F152
G1 X122.943 F152
G1 X123.057 Y151.27 F152
G1 X123.115 Y151.258 F152
G1 X123.229 Y151.237 F152
G1 X123.242 Y151.234 F152
G1 X123.287 Y151.226 F152
G1 X123.344 Y151.215 F152
G1 X123.401 Y151.204 F152
G1 X123.458 Y151.194 F152
G1 X123.516 Y151.183 F152
G1 X123.545 Y151.177 F152
G1 X123.573 Y151.172 F152
G1 X123.802 Y151.129 F152
G1 X123.857 Y151.12 F152
G1 X123.859 F152
G1 X124.089 Y151.084 F152
G1 X124.146 Y151.076 F152
G1 X124.203 Y151.067 F152
G1 X124.228 Y151.062 F152
G1 X124.26 Y151.059 F152
G1 X124.375 Y151.048 F152
G1 X124.432 Y151.042 F152
G1 X124.49 Y151.036 F152
G1 X124.547 Y151.03 F152
G1 X124.604 Y151.025 F152
G1 X124.891 Y151.016 F152
G1 X124.948 Y151.015 F152
G1 X125.005 Y151.017 F152
G1 X125.062 Y151.019 F152
G1 X125.177 Y151.026 F152
G1 X125.234 Y151.029 F152
G1 X125.292 Y151.033 F152
G1 X125.349 Y151.04 F152
G1 X125.406 Y151.049 F152
G1 X125.501 Y151.062 F152
G1 X125.521 Y151.066 F152
G1 X125.578 Y151.074 F152
G1 X125.635 Y151.083 F152
G1 X125.693 Y151.095 F152
G1 X125.75 Y151.11 F152
G1 X125.794 Y151.12 F152
G1 X125.807 Y151.123 F152
G1 X125.922 Y151.15 F152
G1 X125.979 Y151.164 F152
G1 X126.02 Y151.177 F152
G1 X126.036 Y151.182 F152
G1 X126.094 Y151.2 F152
G1 X126.151 Y151.219 F152
G1 X126.201 Y151.234 F152
G1 X126.208 Y151.237 F152
G1 X126.265 Y151.255 F152
G1 X126.323 Y151.274 F152
G1 X126.371 Y151.291 F152
G1 X126.38 Y151.295 F152
G1 X126.437 Y151.317 F152
G1 X126.495 Y151.339 F152
G1 X126.521 Y151.349 F152
G1 X126.552 Y151.36 F152
G1 X126.609 Y151.383 F152
G1 X126.666 Y151.404 F152
G1 X126.671 Y151.406 F152
G1 X126.724 Y151.428 F152
G1 X126.781 Y151.453 F152
G1 X126.805 Y151.463 F152
G1 X126.838 Y151.478 F152
G1 X126.896 Y151.502 F152
G1 X126.939 Y151.521 F152
G1 X126.953 Y151.527 F152
G1 X127.01 Y151.551 F152
G1 X127.067 Y151.576 F152
G1 X127.071 Y151.578 F152
G1 X127.125 Y151.602 F152
G1 X127.182 Y151.628 F152
G1 X127.198 Y151.635 F152
G1 X127.239 Y151.654 F152
G1 X127.297 Y151.68 F152
G1 X127.325 Y151.692 F152
G1 X127.354 Y151.706 F152
G1 X127.411 Y151.732 F152
G1 X127.451 Y151.75 F152
G1 X127.468 Y151.758 F152
G1 X127.526 Y151.784 F152
G1 X127.579 Y151.807 F152
G1 X127.583 Y151.809 F152
G1 X127.698 Y151.861 F152
G1 X127.706 Y151.864 F152
G1 X127.755 Y151.887 F152
G1 X127.812 Y151.912 F152
G1 X127.835 Y151.921 F152
G1 X127.869 Y151.937 F152
G1 X127.927 Y151.961 F152
G1 X127.969 Y151.979 F152
G1 X127.984 Y151.986 F152
G1 X128.041 Y152.01 F152
G1 X128.099 Y152.035 F152
G1 X128.101 Y152.036 F152
G1 X128.156 Y152.059 F152
G1 X128.213 Y152.082 F152
G1 X128.243 Y152.093 F152
G1 X128.27 Y152.104 F152
G1 X128.385 Y152.149 F152
G1 X128.391 Y152.151 F152
G1 X128.442 Y152.17 F152
G1 X128.5 Y152.193 F152
G1 X128.539 Y152.208 F152
G1 X128.557 Y152.215 F152
G1 X128.614 Y152.234 F152
G1 X128.671 Y152.252 F152
G1 X128.713 Y152.265 F152
G1 X128.729 Y152.271 F152
G1 X128.843 Y152.308 F152
G1 X128.889 Y152.322 F152
G1 X128.901 Y152.327 F152
G1 X128.958 Y152.345 F152
G1 X129.015 Y152.359 F152
G1 X129.072 Y152.373 F152
G1 X129.102 Y152.38 F152
G1 X129.13 Y152.387 F152
G1 X129.187 Y152.401 F152
G1 X129.244 Y152.415 F152
G1 X129.302 Y152.429 F152
G1 X129.336 Y152.437 F152
G1 X129.359 Y152.442 F152
G1 X129.531 Y152.469 F152
G1 X129.588 Y152.477 F152
G1 X129.645 Y152.486 F152
G1 X129.702 Y152.494 F152
G1 X129.703 Y152.495 F152
G1 X129.76 Y152.502 F152
G1 X129.817 Y152.507 F152
G1 X130.046 Y152.518 F152
G1 X130.104 Y152.519 F152
G1 X130.161 Y152.522 F152
G1 X130.218 Y152.52 F152
G1 X130.275 Y152.516 F152
G1 X130.505 Y152.501 F152
G1 X130.562 Y152.497 F152
G1 X130.582 Y152.494 F152
G1 X130.619 Y152.489 F152
G1 X130.734 Y152.469 F152
G1 X130.791 Y152.46 F152
G1 X130.906 Y152.441 F152
G1 X130.924 Y152.437 F152
G1 X130.963 Y152.429 F152
G1 X131.02 Y152.415 F152
G1 X131.152 Y152.38 F152
G1 X131.192 Y152.37 F152
G1 X131.307 Y152.339 F152
G1 X131.36 Y152.322 F152
G1 X131.364 F152
G1 X131.421 Y152.303 F152
G1 X131.478 Y152.283 F152
G1 X131.532 Y152.265 F152
G1 X131.536 Y152.264 F152
G1 X131.65 Y152.227 F152
G1 X131.701 Y152.208 F152
G1 X131.708 Y152.206 F152
G1 X131.765 Y152.185 F152
G1 X131.822 Y152.164 F152
G1 X131.857 Y152.151 F152
G1 X131.879 Y152.143 F152
G1 X131.937 Y152.121 F152
G1 X131.994 Y152.1 F152
G1 X132.012 Y152.093 F152
G1 X132.051 Y152.079 F152
G1 X132.109 Y152.057 F152
G1 X132.165 Y152.036 F152
G1 X132.166 F152
G1 X132.28 Y151.993 F152
G1 X132.318 Y151.979 F152
G1 X132.338 Y151.972 F152
G1 X132.452 Y151.932 F152
G1 X132.481 Y151.921 F152
G1 X132.567 Y151.892 F152
G1 X132.624 Y151.871 F152
G1 X132.645 Y151.864 F152
G1 X132.681 Y151.853 F152
G1 X132.739 Y151.836 F152
G1 X132.796 Y151.819 F152
G1 X132.833 Y151.807 F152
G1 X132.853 Y151.801 F152
G1 X132.911 Y151.784 F152
G1 X132.968 Y151.766 F152
G1 X133.025 Y151.751 F152
G1 X133.031 Y151.75 F152
G1 X133.082 Y151.737 F152
G1 X133.261 Y151.692 F152
G1 X133.312 Y151.681 F152
G1 X133.541 Y151.638 F152
G1 X133.551 Y151.635 F152
G1 X133.598 Y151.627 F152
G1 X133.655 Y151.615 F152
G1 X133.942 Y151.58 F152
G1 X133.952 Y151.578 F152
G1 X133.999 Y151.572 F152
G1 X134.056 Y151.567 F152
G1 X134.114 Y151.563 F152
G1 X134.171 Y151.559 F152
G1 X134.4 Y151.545 F152
G1 X134.457 Y151.544 F152
G1 X134.572 F152
G1 X134.629 Y151.543 F152
G1 X134.744 F152
G1 X134.801 Y151.544 F152
G1 X134.916 Y151.551 F152
G1 X134.973 Y151.555 F152
G1 X135.145 Y151.566 F152
G1 X135.202 Y151.572 F152
G1 X135.248 Y151.578 F152
G1 X135.259 Y151.58 F152
G1 X135.317 Y151.587 F152
G1 X135.488 Y151.616 F152
G1 X135.546 Y151.63 F152
G1 X135.57 Y151.635 F152
G1 X135.603 Y151.643 F152
G1 X135.66 Y151.658 F152
G1 X135.718 Y151.676 F152
G1 X135.766 Y151.692 F152
G1 X135.803 Y151.708 F152
G1 X135.832 Y151.718 F152
G1 X135.834 Y151.719 F152
; MOVEMENT_LINK_TRANSITION
; MOVEMENT_CUTTING
G1 X135.832 Y151.721 F152
G1 Y151.722 F152
G1 X135.813 Y151.75 F152
G1 X135.775 Y151.793 F152
G1 X135.761 Y151.807 F152
G1 X135.718 Y151.85 F152
G1 X135.7 Y151.864 F152
G1 X135.66 Y151.897 F152
G1 X135.631 Y151.921 F152
G1 X135.603 Y151.943 F152
G1 X135.553 Y151.979 F152
G1 X135.546 Y151.983 F152
G1 X135.488 Y152.023 F152
G1 X135.471 Y152.036 F152
G1 X135.431 Y152.064 F152
G1 X135.386 Y152.093 F152
G1 X135.374 Y152.101 F152
G1 X135.317 Y152.139 F152
G1 X135.3 Y152.151 F152
G1 X135.259 Y152.177 F152
G1 X135.212 Y152.208 F152
G1 X135.202 Y152.214 F152
G1 X135.145 Y152.252 F152
G1 X135.124 Y152.265 F152
G1 X135.037 Y152.322 F152
G1 X135.03 Y152.327 F152
G1 X134.916 Y152.402 F152
G1 X134.801 Y152.479 F152
G1 X134.78 Y152.494 F152
G1 X134.744 Y152.518 F152
G1 X134.696 Y152.552 F152
G1 X134.686 Y152.558 F152
G1 X134.612 Y152.609 F152
G1 X134.572 Y152.637 F152
G1 X134.532 Y152.666 F152
G1 X134.515 Y152.68 F152
G1 X134.457 Y152.721 F152
G1 X134.455 Y152.723 F152
G1 X134.4 Y152.765 F152
G1 X134.38 Y152.781 F152
G1 X134.343 Y152.809 F152
G1 X134.307 Y152.838 F152
G1 X134.285 Y152.856 F152
G1 X134.24 Y152.895 F152
G1 X134.228 Y152.905 F152
G1 X134.174 Y152.952 F152
G1 X134.171 Y152.955 F152
G1 X134.114 Y153.012 F152
G1 X134.062 Y153.067 F152
G1 X134.056 Y153.072 F152
G1 X134.012 Y153.124 F152
G1 X133.999 Y153.141 F152
G1 X133.971 Y153.182 F152
G1 X133.942 Y153.225 F152
G1 X133.933 Y153.239 F152
G1 X133.901 Y153.296 F152
G1 X133.884 Y153.33 F152
G1 X133.875 Y153.353 F152
G1 X133.852 Y153.411 F152
G1 X133.834 Y153.468 F152
G1 X133.827 Y153.498 F152
G1 X133.821 Y153.525 F152
G1 X133.812 Y153.583 F152
G1 X133.806 Y153.64 F152
G1 X133.805 Y153.697 F152
G1 X133.807 Y153.754 F152
G1 X133.814 Y153.812 F152
G1 X133.824 Y153.869 F152
G1 X133.827 Y153.881 F152
G1 X133.839 Y153.926 F152
G1 X133.858 Y153.983 F152
G1 X133.883 Y154.041 F152
G1 X133.912 Y154.098 F152
G1 X133.942 Y154.145 F152
G1 X133.948 Y154.155 F152
G1 X133.991 Y154.213 F152
G1 X133.999 Y154.222 F152
G1 X134.042 Y154.27 F152
G1 X134.056 Y154.284 F152
G1 X134.105 Y154.327 F152
G1 X134.114 Y154.334 F152
G1 X134.171 Y154.376 F152
G1 X134.183 Y154.384 F152
G1 X134.228 Y154.411 F152
G1 X134.287 Y154.442 F152
G1 X134.343 Y154.465 F152
G1 X134.4 Y154.485 F152
G1 X134.453 Y154.499 F152
G1 X134.515 Y154.512 F152
G1 X134.572 Y154.519 F152
G1 X134.629 Y154.524 F152
G1 X134.686 Y154.526 F152
G1 X134.801 Y154.52 F152
G1 X134.858 Y154.513 F152
G1 X134.916 Y154.505 F152
G1 X134.951 Y154.499 F152
G1 X134.973 Y154.496 F152
G1 X135.03 Y154.485 F152
G1 X135.145 Y154.46 F152
G1 X135.202 Y154.446 F152
G1 X135.217 Y154.442 F152
G1 X135.259 Y154.431 F152
G1 X135.374 Y154.401 F152
G1 X135.488 Y154.368 F152
G1 X135.546 Y154.351 F152
G1 X135.603 Y154.335 F152
G1 X135.628 Y154.327 F152
G1 X135.66 Y154.317 F152
G1 X135.775 Y154.283 F152
G1 X135.817 Y154.27 F152
G1 X135.832 Y154.265 F152
G1 X135.947 Y154.23 F152
G1 X136 Y154.213 F152
G1 X136.004 Y154.212 F152
G1 X136.176 Y154.158 F152
G1 X136.182 Y154.155 F152
G1 X136.233 Y154.139 F152
G1 X136.348 Y154.103 F152
G1 X136.363 Y154.098 F152
G1 X136.405 Y154.085 F152
G1 X136.52 Y154.049 F152
G1 X136.543 Y154.041 F152
G1 X136.577 Y154.03 F152
G1 X136.691 Y153.994 F152
G1 X136.725 Y153.983 F152
G1 X136.749 Y153.976 F152
G1 X136.863 Y153.941 F152
G1 X136.907 Y153.926 F152
G1 X136.921 Y153.923 F152
G1 X137.035 Y153.887 F152
G1 X137.092 Y153.868 F152
G1 X137.15 Y153.85 F152
G1 X137.207 Y153.833 F152
G1 X137.276 Y153.812 F152
G1 X137.322 Y153.798 F152
G1 X137.436 Y153.764 F152
G1 X137.467 Y153.754 F152
G1 X137.493 Y153.747 F152
G1 X137.551 Y153.729 F152
G1 X137.608 Y153.712 F152
G1 X137.658 Y153.697 F152
G1 X137.665 Y153.695 F152
G1 X137.78 Y153.661 F152
G1 X137.837 Y153.645 F152
G1 X137.854 Y153.64 F152
G1 X137.894 Y153.629 F152
G1 X138.124 Y153.565 F152
G1 X138.181 Y153.549 F152
G1 X138.238 Y153.533 F152
G1 X138.265 Y153.525 F152
G1 X138.295 Y153.517 F152
G1 X138.353 Y153.501 F152
G1 X138.467 Y153.472 F152
G1 X138.482 Y153.468 F152
G1 X138.639 Y153.429 F152
G1 X138.696 Y153.413 F152
G1 X138.936 Y153.353 F152
G1 X138.983 Y153.344 F152
G1 X139.097 Y153.317 F152
G1 X139.155 Y153.304 F152
G1 X139.188 Y153.296 F152
G1 X139.212 Y153.291 F152
G1 X139.269 Y153.278 F152
G1 X139.384 Y153.251 F152
G1 X139.441 Y153.24 F152
G1 X139.442 Y153.239 F152
G1 X139.498 Y153.228 F152
G1 X139.556 Y153.216 F152
G1 X139.613 Y153.204 F152
G1 X139.842 Y153.157 F152
G1 X140.014 Y153.125 F152
G1 X140.017 Y153.124 F152
G1 X140.071 Y153.114 F152
G1 X140.129 Y153.105 F152
G1 X140.329 Y153.067 F152
G1 X140.358 Y153.063 F152
G1 X140.472 Y153.043 F152
G1 X140.53 Y153.034 F152
G1 X140.644 Y153.014 F152
G1 X140.669 Y153.01 F152
G1 X140.701 Y153.004 F152
G1 X140.988 Y152.96 F152
G1 X141.029 Y152.952 F152
G1 X141.045 Y152.951 F152
G1 X141.217 Y152.924 F152
G1 X141.389 Y152.9 F152
G1 X141.416 Y152.895 F152
G1 X141.446 Y152.892 F152
G1 X141.503 Y152.883 F152
G1 X141.618 Y152.868 F152
G1 X141.675 Y152.862 F152
G1 X141.847 Y152.841 F152
G1 X141.883 Y152.838 F152
G1 X141.904 Y152.837 F152
G1 X141.962 Y152.833 F152
G1 X142.019 Y152.829 F152
G1 X142.076 Y152.824 F152
G1 X142.134 Y152.821 F152
G1 X142.208 F152
; MOVEMENT_LINK_TRANSITION
G1 X142.209 Y152.822 F152
; MOVEMENT_CUTTING
G1 Y152.824 F152
G1 X142.206 Y152.838 F152
G1 X142.198 Y152.895 F152
G1 X142.191 Y152.935 F152
G1 X142.186 Y152.952 F152
G1 X142.173 Y153.01 F152
G1 X142.159 Y153.067 F152
G1 X142.141 Y153.124 F152
G1 X142.134 Y153.148 F152
G1 X142.123 Y153.182 F152
G1 X142.103 Y153.239 F152
G1 X142.081 Y153.296 F152
G1 X142.076 Y153.309 F152
G1 X142.059 Y153.353 F152
G1 X142.033 Y153.411 F152
G1 X142.019 Y153.444 F152
G1 X142.008 Y153.468 F152
G1 X141.982 Y153.525 F152
G1 X141.962 Y153.565 F152
G1 X141.952 Y153.583 F152
G1 X141.922 Y153.64 F152
G1 X141.904 Y153.674 F152
G1 X141.892 Y153.697 F152
G1 X141.858 Y153.754 F152
G1 X141.847 Y153.771 F152
G1 X141.823 Y153.812 F152
G1 X141.79 Y153.865 F152
G1 X141.787 Y153.869 F152
G1 X141.748 Y153.926 F152
G1 X141.733 Y153.949 F152
G1 X141.708 Y153.983 F152
G1 X141.675 Y154.028 F152
G1 X141.665 Y154.041 F152
G1 X141.62 Y154.098 F152
G1 X141.618 Y154.101 F152
G1 X141.572 Y154.155 F152
G1 X141.561 Y154.168 F152
G1 X141.503 Y154.231 F152
G1 X141.466 Y154.27 F152
G1 X141.446 Y154.288 F152
G1 X141.389 Y154.341 F152
G1 X141.337 Y154.384 F152
G1 X141.332 Y154.388 F152
G1 X141.274 Y154.433 F152
G1 X141.261 Y154.442 F152
G1 X141.217 Y154.47 F152
G1 X141.17 Y154.499 F152
G1 X141.102 Y154.533 F152
G1 X141.049 Y154.556 F152
G1 X141.045 Y154.557 F152
G1 X140.988 Y154.579 F152
G1 X140.931 Y154.594 F152
G1 X140.873 Y154.607 F152
G1 X140.838 Y154.614 F152
G1 X140.816 Y154.617 F152
G1 X140.759 Y154.623 F152
G1 X140.701 Y154.628 F152
G1 X140.644 Y154.63 F152
G1 X140.587 Y154.631 F152
G1 X140.53 Y154.629 F152
G1 X140.472 Y154.624 F152
G1 X140.3 Y154.614 F152
G1 X140.299 F152
G1 X140.243 Y154.608 F152
G1 X140.129 Y154.596 F152
G1 X140.071 Y154.588 F152
G1 X139.957 Y154.576 F152
G1 X139.899 Y154.569 F152
G1 X139.842 Y154.563 F152
G1 X139.785 Y154.557 F152
G1 X139.775 Y154.556 F152
G1 X139.728 Y154.551 F152
G1 X139.556 Y154.532 F152
G1 X139.498 Y154.527 F152
G1 X139.441 Y154.524 F152
G1 X139.384 Y154.52 F152
G1 X139.327 Y154.518 F152
G1 X139.212 Y154.511 F152
G1 X139.155 Y154.508 F152
G1 X139.097 Y154.504 F152
G1 X139.04 F152
G1 X138.696 Y154.51 F152
G1 X138.639 Y154.512 F152
G1 X138.582 Y154.514 F152
G1 X138.525 Y154.52 F152
G1 X138.467 Y154.526 F152
G1 X138.181 Y154.553 F152
G1 X138.152 Y154.556 F152
G1 X138.124 Y154.559 F152
G1 X138.066 Y154.569 F152
G1 X138.009 Y154.578 F152
G1 X137.8 Y154.614 F152
G1 X137.78 Y154.616 F152
G1 X137.665 Y154.636 F152
G1 X137.608 Y154.647 F152
G1 X137.551 Y154.66 F152
G1 X137.502 Y154.671 F152
G1 X137.493 Y154.673 F152
G1 X137.436 Y154.685 F152
G1 X137.379 Y154.699 F152
G1 X137.264 Y154.724 F152
G1 X137.246 Y154.728 F152
G1 X137.207 Y154.736 F152
G1 X137.15 Y154.75 F152
G1 X137.035 Y154.778 F152
G1 X137.01 Y154.785 F152
G1 X136.921 Y154.808 F152
G1 X136.789 Y154.843 F152
G1 X136.749 Y154.852 F152
G1 X136.691 Y154.868 F152
G1 X136.634 Y154.882 F152
G1 X136.571 Y154.9 F152
G1 X136.52 Y154.913 F152
G1 X136.462 Y154.929 F152
G1 X136.405 Y154.945 F152
G1 X136.361 Y154.957 F152
G1 X136.29 Y154.976 F152
G1 X136.233 Y154.992 F152
G1 X136.176 Y155.007 F152
G1 X136.153 Y155.014 F152
G1 X136.119 Y155.023 F152
G1 X136.004 Y155.054 F152
G1 X135.947 Y155.07 F152
G1 X135.94 Y155.072 F152
G1 X135.889 Y155.085 F152
G1 X135.775 Y155.116 F152
G1 X135.727 Y155.129 F152
G1 X135.718 Y155.131 F152
G1 X135.66 Y155.146 F152
G1 X135.603 Y155.162 F152
G1 X135.546 Y155.176 F152
G1 X135.505 Y155.186 F152
G1 X135.488 Y155.19 F152
G1 X135.431 Y155.204 F152
G1 X135.374 Y155.218 F152
G1 X135.317 Y155.232 F152
G1 X135.271 Y155.244 F152
G1 X135.202 Y155.26 F152
G1 X135.087 Y155.288 F152
G1 X135.03 Y155.3 F152
G1 X135.027 Y155.301 F152
G1 X134.973 Y155.312 F152
G1 X134.801 Y155.347 F152
G1 X134.747 Y155.358 F152
G1 X134.744 F152
G1 X134.572 Y155.393 F152
G1 X134.515 Y155.402 F152
G1 X134.457 Y155.41 F152
G1 X134.424 Y155.415 F152
G1 X134.4 Y155.419 F152
G1 X134.343 Y155.427 F152
G1 X134.285 Y155.436 F152
G1 X134.228 Y155.444 F152
G1 X134.171 Y155.453 F152
G1 X134.114 Y155.461 F152
G1 X134.056 Y155.468 F152
G1 X134.012 Y155.473 F152
G1 X133.999 Y155.474 F152
G1 X133.884 Y155.484 F152
G1 X133.827 Y155.489 F152
G1 X133.77 Y155.492 F152
G1 X133.713 Y155.495 F152
G1 X133.655 Y155.499 F152
G1 X133.483 Y155.501 F152
G1 X133.426 F152
G1 X133.254 Y155.496 F152
G1 X133.14 Y155.487 F152
G1 X133.082 Y155.482 F152
G1 X133.025 Y155.475 F152
G1 X133.009 Y155.473 F152
G1 X132.968 Y155.466 F152
G1 X132.911 Y155.458 F152
G1 X132.853 Y155.448 F152
G1 X132.796 Y155.436 F152
G1 X132.739 Y155.423 F152
G1 X132.707 Y155.415 F152
G1 X132.681 Y155.408 F152
G1 X132.624 Y155.393 F152
G1 X132.567 Y155.374 F152
G1 X132.519 Y155.358 F152
G1 X132.51 Y155.355 F152
G1 X132.452 Y155.333 F152
G1 X132.395 Y155.309 F152
G1 X132.374 Y155.301 F152
G1 X132.338 Y155.283 F152
G1 X132.28 Y155.256 F152
G1 X132.257 Y155.244 F152
G1 X132.223 Y155.225 F152
G1 X132.166 Y155.193 F152
G1 X132.152 Y155.186 F152
G1 X132.109 Y155.16 F152
G1 X132.055 Y155.129 F152
G1 X132.051 Y155.127 F152
G1 X131.994 Y155.093 F152
G1 X131.956 Y155.072 F152
G1 X131.879 Y155.03 F152
G1 X131.822 Y155 F152
G1 X131.765 Y154.976 F152
G1 X131.719 Y154.957 F152
G1 X131.708 Y154.952 F152
G1 X131.65 Y154.931 F152
G1 X131.593 Y154.915 F152
G1 X131.536 Y154.903 F152
G1 X131.52 Y154.9 F152
G1 X131.478 Y154.891 F152
G1 X131.421 Y154.883 F152
G1 X131.364 Y154.878 F152
G1 X131.307 F152
G1 X131.249 Y154.882 F152
G1 X131.192 Y154.888 F152
G1 X131.135 Y154.895 F152
G1 X131.112 Y154.9 F152
G1 X131.077 Y154.907 F152
G1 X131.02 Y154.923 F152
G1 X130.963 Y154.944 F152
G1 X130.932 Y154.957 F152
G1 X130.906 Y154.97 F152
G1 X130.848 Y154.998 F152
G1 X130.818 Y155.014 F152
G1 X130.791 Y155.03 F152
G1 X130.734 Y155.067 F152
G1 X130.727 Y155.072 F152
G1 X130.676 Y155.112 F152
G1 X130.658 Y155.129 F152
G1 X130.619 Y155.165 F152
G1 X130.597 Y155.186 F152
G1 X130.562 Y155.22 F152
G1 X130.54 Y155.244 F152
G1 X130.505 Y155.287 F152
G1 X130.494 Y155.301 F152
G1 X130.453 Y155.358 F152
G1 X130.447 Y155.366 F152
G1 X130.412 Y155.415 F152
G1 X130.39 Y155.449 F152
G1 X130.377 Y155.473 F152
G1 X130.345 Y155.53 F152
G1 X130.333 Y155.554 F152
G1 X130.315 Y155.587 F152
G1 X130.285 Y155.645 F152
G1 X130.275 Y155.666 F152
G1 X130.259 Y155.702 F152
G1 X130.234 Y155.759 F152
G1 X130.218 Y155.797 F152
G1 X130.209 Y155.816 F152
G1 X130.187 Y155.874 F152
G1 X130.165 Y155.931 F152
G1 X130.161 Y155.944 F152
G1 X130.144 Y155.988 F152
G1 X130.122 Y156.045 F152
G1 X130.104 Y156.103 F152
G1 Y156.105 F152
G1 X130.085 Y156.16 F152
G1 X130.047 Y156.275 F152
G1 X130.046 Y156.278 F152
G1 X130.03 Y156.332 F152
G1 X130.013 Y156.389 F152
G1 X129.995 Y156.446 F152
G1 X129.989 Y156.47 F152
G1 X129.978 Y156.504 F152
G1 X129.963 Y156.561 F152
G1 X129.947 Y156.618 F152
G1 X129.932 Y156.675 F152
G1 X129.931 Y156.676 F152
G1 X129.916 Y156.733 F152
G1 X129.899 Y156.79 F152
G1 X129.871 Y156.905 F152
G1 X129.856 Y156.962 F152
G1 X129.827 Y157.076 F152
G1 X129.817 Y157.119 F152
G1 X129.814 Y157.134 F152
G1 X129.76 Y157.363 F152
G1 X129.746 Y157.42 F152
G1 X129.705 Y157.592 F152
G1 X129.703 Y157.606 F152
G1 X129.693 Y157.649 F152
G1 X129.68 Y157.707 F152
G1 X129.669 Y157.764 F152
G1 X129.656 Y157.821 F152
G1 X129.645 Y157.871 F152
G1 X129.643 Y157.878 F152
G1 X129.618 Y157.993 F152
G1 X129.607 Y158.05 F152
G1 X129.594 Y158.107 F152
G1 X129.588 Y158.137 F152
G1 X129.582 Y158.165 F152
G1 X129.535 Y158.394 F152
G1 X129.531 Y158.417 F152
G1 X129.524 Y158.451 F152
G1 X129.477 Y158.68 F152
G1 X129.473 Y158.699 F152
G1 X129.465 Y158.738 F152
G1 X129.43 Y158.909 F152
G1 X129.42 Y158.967 F152
G1 X129.416 Y158.985 F152
G1 X129.373 Y159.196 F152
G1 X129.361 Y159.253 F152
G1 X129.359 Y159.264 F152
G1 X129.349 Y159.31 F152
G1 X129.311 Y159.482 F152
G1 X129.302 Y159.526 F152
G1 X129.298 Y159.539 F152
G1 X129.285 Y159.597 F152
G1 X129.271 Y159.654 F152
G1 X129.256 Y159.711 F152
G1 X129.244 Y159.759 F152
G1 X129.242 Y159.769 F152
G1 X129.208 Y159.883 F152
G1 X129.187 Y159.943 F152
G1 X129.167 Y159.998 F152
G1 X129.141 Y160.055 F152
G1 X129.13 Y160.081 F152
G1 X129.111 Y160.112 F152
G1 X129.101 Y160.127 F152
G1 X129.089 Y160.141 F152
G1 X129.081 Y160.147 F152
G1 X129.072 Y160.152 F152
G1 X129.044 Y160.164 F152
G1 X129.029 Y160.17 F152
G1 X129.015 Y160.173 F152
G1 X128.958 Y160.185 F152
G1 X128.901 Y160.193 F152
G1 X128.843 Y160.195 F152
G1 X128.786 F152
G1 X128.729 Y160.191 F152
G1 X128.671 Y160.183 F152
G1 X128.614 Y160.171 F152
G1 X128.608 Y160.17 F152
G1 X128.557 Y160.153 F152
G1 X128.528 Y160.142 F152
G1 X128.5 Y160.126 F152
G1 X128.483 Y160.112 F152
G1 X128.477 Y160.105 F152
G1 X128.473 Y160.098 F152
G1 X128.466 Y160.084 F152
G1 X128.455 Y160.055 F152
G1 X128.442 Y160.01 F152
G1 X128.44 Y159.998 F152
G1 X128.431 Y159.94 F152
G1 X128.423 Y159.883 F152
G1 X128.418 Y159.769 F152
G1 Y159.711 F152
G1 X128.422 Y159.597 F152
G1 X128.429 Y159.482 F152
G1 X128.433 Y159.425 F152
G1 X128.44 Y159.368 F152
G1 X128.442 Y159.335 F152
G1 X128.451 Y159.253 F152
G1 X128.459 Y159.196 F152
G1 X128.466 Y159.139 F152
G1 X128.499 Y158.909 F152
G1 X128.5 Y158.898 F152
G1 X128.506 Y158.852 F152
G1 X128.524 Y158.738 F152
G1 X128.534 Y158.68 F152
G1 X128.551 Y158.566 F152
G1 X128.557 Y158.533 F152
G1 X128.561 Y158.508 F152
G1 X128.57 Y158.451 F152
G1 X128.58 Y158.394 F152
G1 X128.598 Y158.279 F152
G1 X128.608 Y158.222 F152
G1 X128.614 Y158.179 F152
G1 X128.617 Y158.165 F152
G1 X128.626 Y158.107 F152
G1 X128.636 Y158.05 F152
G1 X128.645 Y157.993 F152
G1 X128.654 Y157.936 F152
G1 X128.663 Y157.878 F152
G1 X128.671 Y157.824 F152
G1 X128.672 Y157.821 F152
G1 X128.69 Y157.707 F152
G1 X128.698 Y157.649 F152
G1 X128.725 Y157.477 F152
G1 X128.729 Y157.452 F152
G1 X128.734 Y157.42 F152
G1 X128.766 Y157.191 F152
G1 X128.781 Y157.076 F152
G1 X128.786 Y157.033 F152
G1 X128.788 Y157.019 F152
G1 X128.795 Y156.962 F152
G1 X128.814 Y156.79 F152
G1 X128.824 Y156.676 F152
G1 X128.833 Y156.561 F152
G1 X128.837 Y156.504 F152
G1 X128.842 Y156.389 F152
G1 X128.843 Y156.363 F152
G1 X128.845 Y156.332 F152
G1 Y156.16 F152
G1 X128.843 Y156.121 F152
G1 X128.84 Y156.045 F152
G1 X128.836 Y155.988 F152
G1 X128.83 Y155.931 F152
G1 X128.814 Y155.816 F152
G1 X128.803 Y155.759 F152
G1 X128.774 Y155.645 F152
G1 X128.757 Y155.587 F152
G1 X128.736 Y155.53 F152
G1 X128.729 Y155.513 F152
G1 X128.713 Y155.473 F152
G1 X128.688 Y155.415 F152
G1 X128.671 Y155.384 F152
G1 X128.657 Y155.358 F152
G1 X128.623 Y155.301 F152
G1 X128.614 Y155.287 F152
G1 X128.586 Y155.244 F152
G1 X128.557 Y155.203 F152
G1 X128.543 Y155.186 F152
G1 X128.5 Y155.133 F152
G1 X128.496 Y155.129 F152
G1 X128.444 Y155.072 F152
G1 X128.442 Y155.07 F152
G1 X128.385 Y155.017 F152
G1 X128.381 Y155.014 F152
G1 X128.328 Y154.966 F152
G1 X128.317 Y154.957 F152
G1 X128.27 Y154.916 F152
G1 X128.251 Y154.9 F152
G1 X128.213 Y154.872 F152
G1 X128.095 Y154.785 F152
G1 X128.041 Y154.747 F152
G1 X128.014 Y154.728 F152
G1 X127.984 Y154.707 F152
G1 X127.932 Y154.671 F152
G1 X127.927 Y154.667 F152
G1 X127.869 Y154.627 F152
G1 X127.849 Y154.614 F152
G1 X127.812 Y154.589 F152
G1 X127.761 Y154.556 F152
G1 X127.755 Y154.552 F152
G1 X127.698 Y154.515 F152
G1 X127.673 Y154.499 F152
G1 X127.64 Y154.478 F152
G1 X127.583 Y154.443 F152
G1 X127.581 Y154.442 F152
G1 X127.526 Y154.411 F152
G1 X127.477 Y154.384 F152
G1 X127.468 Y154.379 F152
G1 X127.374 Y154.327 F152
G1 X127.354 Y154.316 F152
G1 X127.297 Y154.288 F152
G1 X127.256 Y154.27 F152
G1 X127.239 Y154.263 F152
G1 X127.182 Y154.238 F152
G1 X127.125 Y154.214 F152
G1 X127.119 Y154.213 F152
G1 X127.067 Y154.195 F152
G1 X127.01 Y154.176 F152
G1 X126.953 Y154.158 F152
G1 X126.896 Y154.144 F152
G1 X126.838 Y154.132 F152
G1 X126.781 Y154.12 F152
G1 X126.724 Y154.11 F152
G1 X126.666 Y154.104 F152
G1 X126.609 Y154.1 F152
G1 X126.584 Y154.098 F152
G1 X126.552 Y154.095 F152
G1 X126.495 Y154.094 F152
G1 X126.437 Y154.095 F152
G1 X126.406 Y154.098 F152
G1 X126.38 Y154.099 F152
G1 X126.323 Y154.103 F152
G1 X126.265 Y154.11 F152
G1 X126.208 Y154.12 F152
G1 X126.094 Y154.145 F152
G1 X126.051 Y154.155 F152
G1 X126.036 Y154.159 F152
G1 X125.979 Y154.179 F152
G1 X125.922 Y154.2 F152
G1 X125.888 Y154.213 F152
G1 X125.864 Y154.221 F152
G1 X125.807 Y154.245 F152
G1 X125.759 Y154.27 F152
G1 X125.75 Y154.274 F152
G1 X125.693 Y154.304 F152
G1 X125.65 Y154.327 F152
G1 X125.635 Y154.335 F152
G1 X125.578 Y154.371 F152
G1 X125.558 Y154.384 F152
G1 X125.472 Y154.442 F152
G1 X125.463 Y154.448 F152
G1 X125.406 Y154.492 F152
G1 X125.397 Y154.499 F152
G1 X125.349 Y154.538 F152
G1 X125.326 Y154.556 F152
G1 X125.292 Y154.585 F152
G1 X125.26 Y154.614 F152
G1 X125.234 Y154.638 F152
G1 X125.199 Y154.671 F152
G1 X125.177 Y154.691 F152
G1 X125.139 Y154.728 F152
G1 X125.084 Y154.785 F152
G1 X125.062 Y154.809 F152
G1 X125.03 Y154.843 F152
G1 X125.005 Y154.87 F152
G1 X124.978 Y154.9 F152
G1 X124.948 Y154.938 F152
G1 X124.932 Y154.957 F152
G1 X124.891 Y155.008 F152
G1 X124.885 Y155.014 F152
G1 X124.839 Y155.072 F152
G1 X124.833 Y155.078 F152
G1 X124.791 Y155.129 F152
G1 X124.776 Y155.148 F152
G1 X124.746 Y155.186 F152
G1 X124.719 Y155.223 F152
G1 X124.703 Y155.244 F152
G1 X124.663 Y155.301 F152
G1 X124.661 Y155.304 F152
G1 X124.622 Y155.358 F152
G1 X124.604 Y155.383 F152
G1 X124.581 Y155.415 F152
G1 X124.5 Y155.53 F152
G1 X124.49 Y155.547 F152
G1 X124.464 Y155.587 F152
G1 X124.432 Y155.635 F152
G1 X124.426 Y155.645 F152
G1 X124.388 Y155.702 F152
G1 X124.375 Y155.723 F152
G1 X124.352 Y155.759 F152
G1 X124.314 Y155.816 F152
G1 X124.277 Y155.874 F152
G1 X124.26 Y155.902 F152
G1 X124.243 Y155.931 F152
G1 X124.208 Y155.988 F152
G1 X124.203 Y155.995 F152
G1 X124.173 Y156.045 F152
G1 X124.146 Y156.089 F152
G1 X124.138 Y156.103 F152
G1 X124.102 Y156.16 F152
G1 X124.089 Y156.183 F152
G1 X124.068 Y156.217 F152
G1 X124.034 Y156.275 F152
G1 X124.031 Y156.28 F152
G1 X123.974 Y156.378 F152
G1 X123.967 Y156.389 F152
G1 X123.934 Y156.446 F152
G1 X123.9 Y156.504 F152
G1 X123.867 Y156.561 F152
G1 X123.859 Y156.574 F152
G1 X123.833 Y156.618 F152
G1 X123.802 Y156.674 F152
G1 X123.8 Y156.676 F152
G1 X123.768 Y156.733 F152
G1 X123.745 Y156.774 F152
G1 X123.735 Y156.79 F152
G1 X123.703 Y156.847 F152
G1 X123.688 Y156.874 F152
G1 X123.67 Y156.905 F152
G1 X123.637 Y156.962 F152
G1 X123.63 Y156.975 F152
G1 X123.606 Y157.019 F152
G1 X123.574 Y157.076 F152
G1 X123.573 Y157.079 F152
G1 X123.516 Y157.182 F152
G1 X123.51 Y157.191 F152
G1 X123.478 Y157.248 F152
G1 X123.458 Y157.285 F152
G1 X123.415 Y157.363 F152
G1 X123.401 Y157.388 F152
G1 X123.383 Y157.42 F152
G1 X123.351 Y157.477 F152
G1 X123.344 Y157.491 F152
G1 X123.319 Y157.535 F152
G1 X123.287 Y157.592 F152
G1 Y157.594 F152
G1 X123.255 Y157.649 F152
G1 X123.193 Y157.764 F152
G1 X123.172 Y157.802 F152
G1 X123.162 Y157.821 F152
G1 X123.131 Y157.878 F152
G1 X123.115 Y157.909 F152
G1 X123.099 Y157.936 F152
G1 X123.069 Y157.993 F152
G1 X123.057 Y158.014 F152
G1 X123.038 Y158.05 F152
G1 X123 Y158.121 F152
G1 X122.976 Y158.165 F152
G1 X122.945 Y158.222 F152
G1 X122.943 Y158.227 F152
G1 X122.886 Y158.332 F152
G1 X122.883 Y158.337 F152
G1 X122.852 Y158.394 F152
G1 X122.828 Y158.439 F152
G1 X122.821 Y158.451 F152
G1 X122.791 Y158.508 F152
G1 X122.771 Y158.547 F152
G1 X122.761 Y158.566 F152
G1 X122.731 Y158.623 F152
G1 X122.714 Y158.657 F152
G1 X122.701 Y158.68 F152
G1 X122.656 Y158.767 F152
G1 X122.641 Y158.795 F152
G1 X122.599 Y158.876 F152
G1 X122.582 Y158.909 F152
G1 X122.552 Y158.967 F152
G1 X122.542 Y158.986 F152
G1 X122.522 Y159.024 F152
G1 X122.493 Y159.081 F152
G1 X122.462 Y159.139 F152
G1 X122.433 Y159.196 F152
G1 X122.427 Y159.207 F152
G1 X122.403 Y159.253 F152
G1 X122.374 Y159.31 F152
G1 X122.37 Y159.318 F152
G1 X122.345 Y159.368 F152
G1 X121.973 Y160.112 F152
G1 X121.969 Y160.12 F152
G1 X121.945 Y160.17 F152
G1 X121.888 Y160.284 F152
G1 X121.86 Y160.341 F152
G1 X121.803 Y160.456 F152
G1 X121.797 Y160.468 F152
G1 X121.774 Y160.513 F152
G1 X121.74 Y160.581 F152
G1 X121.716 Y160.628 F152
G1 X121.687 Y160.685 F152
G1 X121.683 Y160.695 F152
G1 X121.658 Y160.742 F152
G1 X121.63 Y160.8 F152
G1 X121.625 Y160.808 F152
G1 X121.598 Y160.857 F152
G1 X121.568 Y160.914 F152
G1 Y160.915 F152
G1 X121.538 Y160.971 F152
G1 X121.511 Y161.022 F152
G1 X121.507 Y161.029 F152
G1 X121.477 Y161.086 F152
G1 X121.453 Y161.129 F152
G1 X121.445 Y161.143 F152
G1 X121.411 Y161.201 F152
G1 X121.396 Y161.226 F152
G1 X121.377 Y161.258 F152
G1 X121.343 Y161.315 F152
G1 X121.339 Y161.322 F152
G1 X121.309 Y161.372 F152
G1 X121.282 Y161.419 F152
G1 X121.275 Y161.43 F152
G1 X121.236 Y161.487 F152
G1 X121.224 Y161.503 F152
G1 X121.196 Y161.544 F152
G1 X121.167 Y161.586 F152
G1 X121.156 Y161.601 F152
G1 X121.117 Y161.659 F152
G1 X121.11 Y161.669 F152
G1 X121.074 Y161.716 F152
G1 X121.026 Y161.773 F152
G1 X120.995 Y161.811 F152
G1 X120.978 Y161.831 F152
G1 X120.938 Y161.879 F152
G1 X120.931 Y161.888 F152
G1 X120.881 Y161.945 F152
G1 X120.823 Y162.004 F152
G1 X120.765 Y162.06 F152
G1 X120.709 Y162.111 F152
G1 X120.702 Y162.117 F152
G1 X120.651 Y162.159 F152
G1 X120.633 Y162.174 F152
G1 X120.56 Y162.232 F152
G1 X120.537 Y162.248 F152
G1 X120.48 Y162.288 F152
G1 X120.479 Y162.289 F152
G1 X120.422 Y162.326 F152
G1 X120.391 Y162.346 F152
G1 X120.365 Y162.361 F152
G1 X120.308 Y162.396 F152
G1 X120.193 Y162.457 F152
G1 X120.187 Y162.461 F152
G1 X120.136 Y162.484 F152
G1 X120.079 Y162.51 F152
G1 X120.062 Y162.518 F152
G1 X120.021 Y162.534 F152
G1 X119.964 Y162.556 F152
G1 X119.915 Y162.575 F152
G1 X119.907 Y162.578 F152
G1 X119.792 Y162.614 F152
G1 X119.721 Y162.632 F152
G1 X119.678 Y162.642 F152
G1 X119.62 Y162.655 F152
G1 X119.506 Y162.673 F152
G1 X119.448 Y162.677 F152
G1 X119.391 Y162.681 F152
G1 X119.334 Y162.679 F152
G1 X119.327 F152
G1 X119.325 F152
; MOVEMENT_LINK_TRANSITION
G1 X119.324 Y162.678 F152
; MOVEMENT_CUTTING
G1 X119.325 Y162.675 F152
G1 X119.333 Y162.632 F152
G1 X119.334 Y162.624 F152
G1 X119.346 Y162.575 F152
G1 X119.363 Y162.518 F152
G1 X119.381 Y162.461 F152
G1 X119.391 Y162.434 F152
G1 X119.403 Y162.403 F152
G1 X119.424 Y162.346 F152
G1 X119.448 Y162.289 F152
G1 X119.474 Y162.232 F152
G1 X119.499 Y162.174 F152
G1 X119.528 Y162.117 F152
G1 X119.558 Y162.06 F152
G1 X119.563 Y162.048 F152
G1 X119.586 Y162.002 F152
G1 X119.618 Y161.945 F152
G1 X119.62 Y161.941 F152
G1 X119.65 Y161.888 F152
G1 X119.682 Y161.831 F152
G1 X119.717 Y161.773 F152
G1 X119.753 Y161.716 F152
G1 X119.789 Y161.659 F152
G1 X119.792 Y161.653 F152
G1 X119.825 Y161.601 F152
G1 X119.849 Y161.562 F152
G1 X119.861 Y161.544 F152
G1 X119.897 Y161.487 F152
G1 X119.907 Y161.472 F152
G1 X119.934 Y161.43 F152
G1 X119.964 Y161.384 F152
G1 X119.973 Y161.372 F152
G1 X120.013 Y161.315 F152
G1 X120.021 Y161.303 F152
G1 X120.053 Y161.258 F152
G1 X120.079 Y161.222 F152
G1 X120.094 Y161.201 F152
G1 X120.134 Y161.143 F152
G1 X120.136 Y161.141 F152
G1 X120.174 Y161.086 F152
G1 X120.193 Y161.059 F152
G1 X120.215 Y161.029 F152
G1 X120.25 Y160.981 F152
G1 X120.258 Y160.971 F152
G1 X120.301 Y160.914 F152
G1 X120.308 Y160.906 F152
G1 X120.345 Y160.857 F152
G1 X120.365 Y160.831 F152
G1 X120.388 Y160.8 F152
G1 X120.422 Y160.756 F152
G1 X120.432 Y160.742 F152
G1 X120.476 Y160.685 F152
G1 X120.48 Y160.681 F152
G1 X120.52 Y160.628 F152
G1 X120.537 Y160.606 F152
G1 X120.565 Y160.57 F152
G1 X120.594 Y160.536 F152
G1 X120.651 Y160.464 F152
G1 X120.658 Y160.456 F152
G1 X120.703 Y160.399 F152
G1 X120.709 Y160.392 F152
G1 X120.75 Y160.341 F152
G1 X120.766 Y160.321 F152
G1 X120.796 Y160.284 F152
G1 X120.823 Y160.25 F152
G1 X120.842 Y160.227 F152
G1 X120.937 Y160.112 F152
G1 X120.938 Y160.11 F152
G1 X120.983 Y160.055 F152
G1 X120.995 Y160.041 F152
G1 X121.031 Y159.998 F152
G1 X121.078 Y159.94 F152
G1 X121.125 Y159.883 F152
G1 X121.167 Y159.832 F152
G1 X121.172 Y159.826 F152
G1 X121.219 Y159.769 F152
G1 X121.224 Y159.762 F152
G1 X121.266 Y159.711 F152
G1 X121.313 Y159.654 F152
G1 X121.36 Y159.597 F152
G1 X121.396 Y159.552 F152
G1 X121.406 Y159.539 F152
G1 X121.452 Y159.482 F152
G1 X121.453 Y159.479 F152
G1 X121.496 Y159.425 F152
G1 X121.542 Y159.368 F152
G1 X121.568 Y159.335 F152
G1 X121.588 Y159.31 F152
G1 X121.625 Y159.263 F152
G1 X121.633 Y159.253 F152
G1 X121.676 Y159.196 F152
G1 X121.683 Y159.187 F152
G1 X121.718 Y159.139 F152
G1 X121.761 Y159.081 F152
G1 X121.797 Y159.032 F152
G1 X121.803 Y159.024 F152
G1 X121.846 Y158.967 F152
G1 X121.854 Y158.955 F152
G1 X121.888 Y158.909 F152
G1 X121.912 Y158.875 F152
G1 X121.928 Y158.852 F152
G1 X121.966 Y158.795 F152
G1 X121.969 Y158.791 F152
G1 X122.006 Y158.738 F152
G1 X122.026 Y158.707 F152
G1 X122.044 Y158.68 F152
G1 X122.084 Y158.623 F152
G1 Y158.622 F152
G1 X122.122 Y158.566 F152
G1 X122.141 Y158.536 F152
G1 X122.158 Y158.508 F152
G1 X122.193 Y158.451 F152
G1 X122.198 Y158.442 F152
G1 X122.228 Y158.394 F152
G1 X122.255 Y158.347 F152
G1 X122.263 Y158.337 F152
G1 X122.297 Y158.279 F152
G1 X122.313 Y158.253 F152
G1 X122.332 Y158.222 F152
G1 X122.366 Y158.165 F152
G1 X122.37 Y158.157 F152
G1 X122.397 Y158.107 F152
G1 X122.427 Y158.05 F152
G1 Y158.049 F152
G1 X122.458 Y157.993 F152
G1 X122.485 Y157.943 F152
G1 X122.488 Y157.936 F152
G1 X122.519 Y157.878 F152
G1 X122.542 Y157.835 F152
G1 X122.55 Y157.821 F152
G1 X122.579 Y157.764 F152
G1 X122.599 Y157.721 F152
G1 X122.606 Y157.707 F152
G1 X122.632 Y157.649 F152
G1 X122.656 Y157.597 F152
G1 X122.659 Y157.592 F152
G1 X122.713 Y157.477 F152
G1 X122.714 Y157.475 F152
G1 X122.74 Y157.42 F152
G1 X122.766 Y157.363 F152
G1 X122.771 Y157.349 F152
G1 X122.788 Y157.306 F152
G1 X122.811 Y157.248 F152
G1 X122.828 Y157.204 F152
G1 X122.834 Y157.191 F152
G1 X122.857 Y157.134 F152
G1 X122.924 Y156.962 F152
G1 X122.943 Y156.906 F152
G1 X122.944 Y156.905 F152
G1 X122.962 Y156.847 F152
G1 X122.98 Y156.79 F152
G1 X122.998 Y156.733 F152
G1 X123.036 Y156.618 F152
G1 X123.054 Y156.561 F152
G1 X123.057 Y156.548 F152
G1 X123.069 Y156.504 F152
G1 X123.084 Y156.446 F152
G1 X123.113 Y156.332 F152
G1 X123.115 Y156.32 F152
G1 X123.125 Y156.275 F152
G1 X123.135 Y156.217 F152
G1 X123.147 Y156.16 F152
G1 X123.157 Y156.103 F152
G1 X123.165 Y156.045 F152
G1 X123.172 Y155.988 F152
G1 Y155.987 F152
G1 X123.18 Y155.931 F152
G1 X123.187 Y155.816 F152
G1 X123.19 Y155.759 F152
G1 X123.192 Y155.702 F152
G1 X123.184 Y155.53 F152
G1 X123.177 Y155.473 F152
G1 X123.172 Y155.443 F152
G1 X123.167 Y155.415 F152
G1 X123.156 Y155.358 F152
G1 X123.144 Y155.301 F152
G1 X123.129 Y155.244 F152
G1 X123.115 Y155.203 F152
G1 X123.108 Y155.186 F152
G1 X123.086 Y155.129 F152
G1 X123.063 Y155.072 F152
G1 X123.034 Y155.014 F152
G1 X123 Y154.957 F152
G1 X122.961 Y154.9 F152
G1 X122.943 Y154.876 F152
G1 X122.919 Y154.843 F152
G1 X122.886 Y154.801 F152
G1 X122.871 Y154.785 F152
G1 X122.828 Y154.742 F152
G1 X122.813 Y154.728 F152
G1 X122.771 Y154.693 F152
G1 X122.714 Y154.648 F152
G1 X122.666 Y154.614 F152
G1 X122.656 Y154.607 F152
G1 X122.599 Y154.572 F152
G1 X122.567 Y154.556 F152
G1 X122.542 Y154.545 F152
G1 X122.485 Y154.521 F152
G1 X122.427 Y154.499 F152
G1 X122.426 F152
G1 X122.37 Y154.479 F152
G1 X122.313 Y154.465 F152
G1 X122.255 Y154.454 F152
G1 X122.198 Y154.447 F152
G1 X122.152 Y154.442 F152
G1 X122.141 Y154.44 F152
G1 X122.084 Y154.435 F152
G1 X122.026 F152
G1 X121.969 Y154.438 F152
G1 X121.931 Y154.442 F152
G1 X121.912 Y154.443 F152
G1 X121.854 Y154.448 F152
G1 X121.797 Y154.456 F152
G1 X121.683 Y154.481 F152
G1 X121.625 Y154.495 F152
G1 X121.568 Y154.512 F152
G1 X121.453 Y154.551 F152
G1 X121.396 Y154.572 F152
G1 X121.339 Y154.597 F152
G1 X121.282 Y154.622 F152
G1 X121.224 Y154.648 F152
G1 X121.167 Y154.676 F152
G1 X121.11 Y154.706 F152
G1 X121.067 Y154.728 F152
G1 X121.052 Y154.735 F152
G1 X120.995 Y154.767 F152
G1 X120.964 Y154.785 F152
G1 X120.938 Y154.801 F152
G1 X120.881 Y154.834 F152
G1 X120.866 Y154.843 F152
G1 X120.823 Y154.869 F152
G1 X120.774 Y154.9 F152
G1 X120.766 Y154.905 F152
G1 X120.709 Y154.942 F152
G1 X120.685 Y154.957 F152
G1 X120.651 Y154.979 F152
G1 X120.6 Y155.014 F152
G1 X120.594 Y155.018 F152
G1 X120.537 Y155.057 F152
G1 X120.517 Y155.072 F152
G1 X120.48 Y155.098 F152
G1 X120.436 Y155.129 F152
G1 X120.365 Y155.181 F152
G1 X120.358 Y155.186 F152
G1 X120.308 Y155.223 F152
G1 X120.28 Y155.244 F152
G1 X120.25 Y155.266 F152
G1 X120.207 Y155.301 F152
G1 X120.193 Y155.311 F152
G1 X120.136 Y155.356 F152
G1 X120.134 Y155.358 F152
G1 X120.062 Y155.415 F152
G1 X119.99 Y155.473 F152
G1 X119.964 Y155.493 F152
G1 X119.917 Y155.53 F152
G1 X119.907 Y155.539 F152
G1 X119.849 Y155.585 F152
G1 X119.848 Y155.587 F152
G1 X119.792 Y155.635 F152
G1 X119.78 Y155.645 F152
G1 X119.735 Y155.684 F152
G1 X119.714 Y155.702 F152
G1 X119.647 Y155.759 F152
G1 X119.62 Y155.782 F152
G1 X119.563 Y155.831 F152
G1 X119.514 Y155.874 F152
G1 X119.506 Y155.88 F152
G1 X119.449 Y155.931 F152
G1 X119.448 Y155.932 F152
G1 X119.391 Y155.984 F152
G1 X119.387 Y155.988 F152
G1 X119.334 Y156.036 F152
G1 X119.277 Y156.088 F152
G1 X119.26 Y156.103 F152
G1 X119.198 Y156.16 F152
G1 X119.134 Y156.217 F152
G1 X119.105 Y156.245 F152
G1 X119.074 Y156.275 F152
G1 X119.047 Y156.3 F152
G1 X119.014 Y156.332 F152
G1 X118.99 Y156.354 F152
G1 X118.954 Y156.389 F152
G1 X118.933 Y156.409 F152
G1 X118.893 Y156.446 F152
G1 X118.876 Y156.464 F152
G1 X118.833 Y156.504 F152
G1 X118.818 Y156.519 F152
G1 X118.774 Y156.561 F152
G1 X118.704 Y156.631 F152
G1 X118.658 Y156.676 F152
G1 X118.589 Y156.744 F152
G1 X118.543 Y156.79 F152
G1 X118.417 Y156.915 F152
G1 X118.373 Y156.962 F152
G1 X118.36 Y156.974 F152
G1 X118.316 Y157.019 F152
G1 X118.303 Y157.034 F152
G1 X118.261 Y157.076 F152
G1 X118.245 Y157.092 F152
G1 X118.204 Y157.134 F152
G1 X118.188 Y157.151 F152
G1 X118.149 Y157.191 F152
G1 X118.094 Y157.248 F152
G1 X118.074 Y157.27 F152
G1 X118.04 Y157.306 F152
G1 X118.016 Y157.33 F152
G1 X117.985 Y157.363 F152
G1 X117.959 Y157.391 F152
G1 X117.93 Y157.42 F152
G1 X117.902 Y157.451 F152
G1 X117.877 Y157.477 F152
G1 X117.844 Y157.511 F152
G1 X117.822 Y157.535 F152
G1 X117.787 Y157.572 F152
G1 X117.769 Y157.592 F152
G1 X117.716 Y157.649 F152
G1 X117.673 Y157.696 F152
G1 X117.662 Y157.707 F152
G1 X117.615 Y157.757 F152
G1 X117.609 Y157.764 F152
G1 X117.558 Y157.818 F152
G1 X117.555 Y157.821 F152
G1 X117.502 Y157.878 F152
G1 X117.501 Y157.88 F152
G1 X117.45 Y157.936 F152
G1 X117.443 Y157.942 F152
G1 X117.397 Y157.993 F152
G1 X117.386 Y158.005 F152
G1 X117.329 Y158.065 F152
G1 X117.29 Y158.107 F152
G1 X117.272 Y158.127 F152
G1 X117.214 Y158.189 F152
G1 X117.183 Y158.222 F152
G1 X117.157 Y158.251 F152
G1 X117.074 Y158.337 F152
G1 X117.042 Y158.369 F152
G1 X117.017 Y158.394 F152
G1 X116.985 Y158.427 F152
G1 X116.962 Y158.451 F152
G1 X116.928 Y158.486 F152
G1 X116.906 Y158.508 F152
G1 X116.871 Y158.545 F152
G1 X116.85 Y158.566 F152
G1 X116.813 Y158.603 F152
G1 X116.794 Y158.623 F152
G1 X116.756 Y158.662 F152
G1 X116.739 Y158.68 F152
G1 X116.679 Y158.738 F152
G1 X116.641 Y158.772 F152
G1 X116.618 Y158.795 F152
G1 X116.584 Y158.827 F152
G1 X116.557 Y158.852 F152
G1 X116.527 Y158.881 F152
G1 X116.47 Y158.932 F152
G1 X116.43 Y158.967 F152
G1 X116.412 Y158.982 F152
G1 X116.365 Y159.024 F152
G1 X116.355 Y159.033 F152
G1 X116.299 Y159.081 F152
G1 X116.298 Y159.082 F152
G1 X116.24 Y159.13 F152
G1 X116.229 Y159.139 F152
G1 X116.183 Y159.176 F152
G1 X116.16 Y159.196 F152
G1 X116.126 Y159.224 F152
G1 X116.09 Y159.253 F152
G1 X116.069 Y159.27 F152
G1 X116.016 Y159.31 F152
G1 X116.011 Y159.314 F152
G1 X115.954 Y159.358 F152
G1 X115.941 Y159.368 F152
G1 X115.897 Y159.402 F152
G1 X115.839 Y159.445 F152
G1 X115.79 Y159.482 F152
G1 X115.782 Y159.488 F152
G1 X115.725 Y159.529 F152
G1 X115.668 Y159.569 F152
G1 X115.629 Y159.597 F152
G1 X115.61 Y159.61 F152
G1 X115.553 Y159.651 F152
G1 X115.549 Y159.654 F152
G1 X115.496 Y159.692 F152
G1 X115.466 Y159.711 F152
G1 X115.438 Y159.729 F152
G1 X115.381 Y159.767 F152
G1 X115.379 Y159.769 F152
G1 X115.324 Y159.805 F152
G1 X115.209 Y159.88 F152
G1 X115.206 Y159.883 F152
G1 X115.152 Y159.917 F152
G1 X115.114 Y159.94 F152
G1 X115.095 Y159.952 F152
G1 X115.037 Y159.986 F152
G1 X115.019 Y159.998 F152
G1 X114.924 Y160.055 F152
G1 X114.923 Y160.056 F152
G1 X114.894 Y160.073 F152
G1 X114.88 Y160.082 F152
G1 X114.876 Y160.084 F152
G1 X114.866 Y160.09 F152
G1 X114.863 Y160.092 F152
G1 X114.861 Y160.093 F152
; MOVEMENT_LINK_TRANSITION
G1 X114.858 F152
; MOVEMENT_CUTTING
G1 X114.86 Y160.091 F152
G1 X114.861 Y160.087 F152
G1 X114.866 Y160.078 F152
G1 X114.871 Y160.069 F152
G1 X114.907 Y159.998 F152
G1 X114.966 Y159.883 F152
G1 X114.98 Y159.856 F152
G1 X114.997 Y159.826 F152
G1 X115.028 Y159.769 F152
G1 X115.037 Y159.751 F152
G1 X115.059 Y159.711 F152
G1 X115.095 Y159.648 F152
G1 X115.125 Y159.597 F152
G1 X115.158 Y159.539 F152
G1 X115.192 Y159.482 F152
G1 X115.209 Y159.453 F152
G1 X115.225 Y159.425 F152
G1 X115.259 Y159.368 F152
G1 X115.267 Y159.355 F152
G1 X115.293 Y159.31 F152
G1 X115.324 Y159.258 F152
G1 X115.361 Y159.196 F152
G1 X115.381 Y159.162 F152
G1 X115.396 Y159.139 F152
G1 X115.433 Y159.081 F152
G1 X115.438 Y159.072 F152
G1 X115.47 Y159.024 F152
G1 X115.496 Y158.983 F152
G1 X115.506 Y158.967 F152
G1 X115.542 Y158.909 F152
G1 X115.553 Y158.893 F152
G1 X115.579 Y158.852 F152
G1 X115.61 Y158.803 F152
G1 X115.616 Y158.795 F152
G1 X115.652 Y158.738 F152
G1 X115.668 Y158.713 F152
G1 X115.69 Y158.68 F152
G1 X115.725 Y158.629 F152
G1 X115.729 Y158.623 F152
G1 X115.769 Y158.566 F152
G1 X115.782 Y158.547 F152
G1 X115.809 Y158.508 F152
G1 X115.839 Y158.464 F152
G1 X115.848 Y158.451 F152
G1 X115.888 Y158.394 F152
G1 X115.897 Y158.38 F152
G1 X115.927 Y158.337 F152
G1 X115.954 Y158.297 F152
G1 X116.007 Y158.222 F152
G1 X116.011 Y158.216 F152
G1 X116.126 Y158.06 F152
G1 X116.133 Y158.05 F152
G1 X116.176 Y157.993 F152
G1 X116.183 Y157.984 F152
G1 X116.22 Y157.936 F152
G1 X116.264 Y157.878 F152
G1 X116.298 Y157.835 F152
G1 X116.354 Y157.764 F152
G1 X116.355 Y157.763 F152
G1 X116.401 Y157.707 F152
G1 X116.412 Y157.691 F152
G1 X116.446 Y157.649 F152
G1 X116.47 Y157.622 F152
G1 X116.496 Y157.592 F152
G1 X116.527 Y157.554 F152
G1 X116.544 Y157.535 F152
G1 X116.584 Y157.487 F152
G1 X116.593 Y157.477 F152
G1 X116.641 Y157.424 F152
G1 X116.645 Y157.42 F152
G1 X116.696 Y157.363 F152
G1 X116.699 Y157.36 F152
G1 X116.75 Y157.306 F152
G1 X116.756 Y157.299 F152
G1 X116.805 Y157.248 F152
G1 X116.813 Y157.24 F152
G1 X116.862 Y157.191 F152
G1 X116.871 Y157.182 F152
G1 X116.921 Y157.134 F152
G1 X116.928 Y157.128 F152
G1 X116.981 Y157.076 F152
G1 X116.985 Y157.072 F152
G1 X117.042 Y157.022 F152
G1 X117.045 Y157.019 F152
G1 X117.1 Y156.971 F152
G1 X117.11 Y156.962 F152
G1 X117.157 Y156.925 F152
G1 X117.183 Y156.905 F152
G1 X117.214 Y156.88 F152
G1 X117.256 Y156.847 F152
G1 X117.272 Y156.836 F152
G1 X117.329 Y156.79 F152
G1 X117.386 Y156.747 F152
G1 X117.407 Y156.733 F152
G1 X117.443 Y156.709 F152
G1 X117.492 Y156.676 F152
G1 X117.501 Y156.669 F152
G1 X117.558 Y156.631 F152
G1 X117.577 Y156.618 F152
G1 X117.662 Y156.561 F152
G1 X117.673 Y156.555 F152
G1 X117.73 Y156.521 F152
G1 X117.758 Y156.504 F152
G1 X117.787 Y156.486 F152
G1 X117.902 Y156.418 F152
G1 X117.948 Y156.389 F152
G1 X118.016 Y156.35 F152
G1 X118.048 Y156.332 F152
G1 X118.074 Y156.318 F152
G1 X118.131 Y156.285 F152
G1 X118.15 Y156.275 F152
G1 X118.188 Y156.253 F152
G1 X118.36 Y156.156 F152
G1 X118.417 Y156.125 F152
G1 X118.458 Y156.103 F152
G1 X118.475 Y156.094 F152
G1 X118.532 Y156.062 F152
G1 X118.646 Y155.999 F152
G1 X118.665 Y155.988 F152
G1 X118.704 Y155.968 F152
G1 X118.769 Y155.931 F152
G1 X118.818 Y155.904 F152
G1 X118.872 Y155.874 F152
G1 X118.876 Y155.872 F152
G1 X118.933 Y155.84 F152
G1 X118.974 Y155.816 F152
G1 X118.99 Y155.807 F152
G1 X119.076 Y155.759 F152
G1 X119.105 Y155.744 F152
G1 X119.162 Y155.712 F152
G1 X119.179 Y155.702 F152
G1 X119.219 Y155.679 F152
G1 X119.277 Y155.647 F152
G1 X119.281 Y155.645 F152
G1 X119.334 Y155.614 F152
G1 X119.379 Y155.587 F152
G1 X119.391 Y155.58 F152
G1 X119.448 Y155.547 F152
G1 X119.477 Y155.53 F152
G1 X119.506 Y155.514 F152
G1 X119.563 Y155.481 F152
G1 X119.576 Y155.473 F152
G1 X119.62 Y155.447 F152
G1 X119.674 Y155.415 F152
G1 X119.678 Y155.414 F152
G1 X119.735 Y155.381 F152
G1 X119.792 Y155.347 F152
G1 X119.849 Y155.311 F152
G1 X119.907 Y155.276 F152
G1 X119.959 Y155.244 F152
G1 X119.964 Y155.24 F152
G1 X120.021 Y155.205 F152
G1 X120.052 Y155.186 F152
G1 X120.079 Y155.17 F152
G1 X120.136 Y155.134 F152
G1 X120.145 Y155.129 F152
G1 X120.193 Y155.1 F152
G1 X120.238 Y155.072 F152
G1 X120.308 Y155.027 F152
G1 X120.327 Y155.014 F152
G1 X120.365 Y154.99 F152
G1 X120.415 Y154.957 F152
G1 X120.422 Y154.953 F152
G1 X120.48 Y154.916 F152
G1 X120.504 Y154.9 F152
G1 X120.537 Y154.878 F152
G1 X120.651 Y154.801 F152
G1 X120.673 Y154.785 F152
G1 X120.709 Y154.761 F152
G1 X120.757 Y154.728 F152
G1 X120.766 Y154.722 F152
G1 X120.823 Y154.681 F152
G1 X120.838 Y154.671 F152
G1 X120.881 Y154.64 F152
G1 X120.918 Y154.614 F152
G1 X120.938 Y154.599 F152
G1 X120.995 Y154.557 F152
G1 X120.996 Y154.556 F152
G1 X121.071 Y154.499 F152
G1 X121.11 Y154.47 F152
G1 X121.147 Y154.442 F152
G1 X121.167 Y154.426 F152
G1 X121.219 Y154.384 F152
G1 X121.224 Y154.38 F152
G1 X121.282 Y154.333 F152
G1 X121.289 Y154.327 F152
G1 X121.359 Y154.27 F152
G1 X121.396 Y154.236 F152
G1 X121.422 Y154.213 F152
G1 X121.453 Y154.184 F152
G1 X121.486 Y154.155 F152
G1 X121.511 Y154.132 F152
G1 X121.547 Y154.098 F152
G1 X121.568 Y154.076 F152
G1 X121.601 Y154.041 F152
G1 X121.625 Y154.016 F152
G1 X121.657 Y153.983 F152
G1 X121.683 Y153.956 F152
G1 X121.708 Y153.926 F152
G1 X121.74 Y153.884 F152
G1 X121.752 Y153.869 F152
G1 X121.797 Y153.812 F152
G1 Y153.811 F152
G1 X121.837 Y153.754 F152
G1 X121.854 Y153.727 F152
G1 X121.871 Y153.697 F152
G1 X121.903 Y153.64 F152
G1 X121.912 Y153.622 F152
G1 X121.933 Y153.583 F152
G1 X121.959 Y153.525 F152
G1 X121.969 Y153.498 F152
G1 X121.98 Y153.468 F152
G1 X121.995 Y153.411 F152
G1 X122.02 Y153.296 F152
G1 X122.026 Y153.255 F152
G1 X122.029 Y153.239 F152
G1 X122.033 Y153.182 F152
G1 Y153.124 F152
G1 X122.03 Y153.067 F152
G1 X122.026 Y153.039 F152
G1 X122.022 Y153.01 F152
G1 X122.01 Y152.952 F152
G1 X121.996 Y152.895 F152
G1 X121.98 Y152.838 F152
G1 X121.969 Y152.807 F152
G1 X121.959 Y152.781 F152
G1 X121.933 Y152.723 F152
G1 X121.912 Y152.683 F152
G1 X121.902 Y152.666 F152
G1 X121.863 Y152.609 F152
G1 X121.854 Y152.597 F152
G1 X121.817 Y152.552 F152
G1 X121.797 Y152.53 F152
G1 X121.764 Y152.494 F152
G1 X121.74 Y152.468 F152
G1 X121.708 Y152.437 F152
G1 X121.683 Y152.415 F152
G1 X121.636 Y152.38 F152
G1 X121.625 Y152.372 F152
G1 X121.568 Y152.336 F152
G1 X121.544 Y152.322 F152
G1 X121.511 Y152.305 F152
G1 X121.453 Y152.277 F152
G1 X121.428 Y152.265 F152
G1 X121.396 Y152.251 F152
G1 X121.339 Y152.229 F152
G1 X121.282 Y152.212 F152
G1 X121.262 Y152.208 F152
G1 X121.224 Y152.198 F152
G1 X121.167 Y152.184 F152
G1 X121.11 Y152.171 F152
G1 X120.995 Y152.157 F152
G1 X120.941 Y152.151 F152
G1 X120.938 Y152.15 F152
G1 X120.881 Y152.144 F152
G1 X120.766 Y152.139 F152
G1 X120.651 Y152.135 F152
G1 X120.594 F152
G1 X120.422 Y152.138 F152
G1 X120.365 Y152.14 F152
G1 X120.193 Y152.148 F152
G1 X120.148 Y152.151 F152
G1 X120.136 F152
G1 X120.079 Y152.155 F152
G1 X119.907 Y152.166 F152
G1 X119.678 Y152.184 F152
G1 X119.62 Y152.189 F152
G1 X119.506 Y152.198 F152
G1 X119.448 Y152.203 F152
G1 X119.399 Y152.208 F152
G1 X119.391 F152
G1 X119.334 Y152.213 F152
G1 X119.277 Y152.218 F152
G1 X119.219 Y152.223 F152
G1 X119.162 Y152.228 F152
G1 X119.105 Y152.233 F152
G1 X118.818 Y152.255 F152
G1 X118.761 Y152.261 F152
G1 X118.705 Y152.265 F152
G1 X118.704 F152
G1 X118.475 Y152.283 F152
G1 X118.417 Y152.286 F152
G1 X118.245 Y152.296 F152
G1 X118.188 Y152.299 F152
G1 X118.016 Y152.31 F152
G1 X117.959 Y152.313 F152
G1 X117.902 Y152.316 F152
G1 X117.844 Y152.318 F152
G1 X117.787 Y152.319 F152
G1 X117.73 Y152.321 F152
G1 X117.678 Y152.322 F152
G1 X117.673 F152
G1 X117.615 Y152.323 F152
G1 X117.501 Y152.327 F152
G1 X117.443 Y152.328 F152
G1 X117.386 Y152.33 F152
G1 X117.329 F152
G1 X117.157 F152
G1 X117.042 Y152.329 F152
G1 X116.985 Y152.327 F152
G1 X116.928 Y152.326 F152
G1 X116.813 Y152.322 F152
G1 X116.799 F152
G1 X116.756 Y152.32 F152
G1 X116.584 Y152.312 F152
G1 X116.527 Y152.307 F152
G1 X116.47 Y152.304 F152
G1 X116.298 Y152.29 F152
G1 X116.24 Y152.285 F152
G1 X116.183 Y152.279 F152
G1 X116.126 Y152.273 F152
G1 X116.069 Y152.267 F152
G1 X116.049 Y152.265 F152
G1 X116.011 Y152.261 F152
G1 X115.897 Y152.246 F152
G1 X115.839 Y152.238 F152
G1 X115.782 Y152.229 F152
G1 X115.725 Y152.221 F152
G1 X115.668 Y152.212 F152
G1 X115.634 Y152.208 F152
G1 X115.438 Y152.177 F152
G1 X115.381 Y152.168 F152
G1 X115.324 Y152.157 F152
G1 X115.285 Y152.151 F152
G1 X115.209 Y152.136 F152
G1 X115.152 Y152.126 F152
G1 X115.095 Y152.116 F152
G1 X115.037 Y152.106 F152
G1 X114.98 Y152.094 F152
G1 X114.971 Y152.093 F152
G1 X114.923 Y152.083 F152
G1 X114.694 Y152.04 F152
G1 X114.667 Y152.036 F152
G1 X114.636 Y152.031 F152
G1 X114.35 Y151.981 F152
G1 X114.334 Y151.979 F152
G1 X114.293 Y151.972 F152
G1 X114.064 Y151.943 F152
G1 X114.006 Y151.935 F152
G1 X113.949 Y151.928 F152
G1 X113.892 Y151.921 F152
G1 X113.881 F152
G1 X113.834 Y151.919 F152
G1 X113.72 Y151.912 F152
G1 X113.663 Y151.909 F152
G1 X113.548 Y151.902 F152
G1 X113.491 Y151.9 F152
G1 X113.376 Y151.904 F152
G1 X113.319 F152
G1 X113.147 Y151.91 F152
G1 X113.09 Y151.913 F152
G1 X113.032 Y151.918 F152
G1 X113.008 Y151.921 F152
G1 X112.918 Y151.931 F152
G1 X112.803 Y151.946 F152
G1 X112.746 Y151.952 F152
G1 X112.689 Y151.959 F152
G1 X112.631 Y151.97 F152
G1 X112.588 Y151.979 F152
G1 X112.574 Y151.981 F152
G1 X112.345 Y152.028 F152
G1 X112.31 Y152.036 F152
G1 X112.288 Y152.04 F152
G1 X112.23 Y152.054 F152
G1 X112.173 Y152.071 F152
G1 X112.116 Y152.087 F152
G1 X112.095 Y152.093 F152
G1 X112.059 Y152.103 F152
G1 X112.001 Y152.12 F152
G1 X111.944 Y152.136 F152
G1 X111.829 Y152.17 F152
G1 X111.6 Y152.253 F152
G1 X111.566 Y152.265 F152
G1 X111.543 Y152.273 F152
G1 X111.428 Y152.314 F152
G1 X111.409 Y152.322 F152
G1 X111.371 Y152.338 F152
G1 X111.314 Y152.363 F152
G1 X111.274 Y152.38 F152
G1 X111.257 Y152.387 F152
G1 X111.199 Y152.412 F152
G1 X111.142 Y152.436 F152
G1 X111.141 Y152.437 F152
G1 X111.085 Y152.461 F152
G1 X111.027 Y152.485 F152
G1 X110.97 Y152.511 F152
G1 X110.89 Y152.552 F152
G1 X110.856 Y152.568 F152
G1 X110.798 Y152.596 F152
G1 X110.774 Y152.609 F152
G1 X110.741 Y152.625 F152
G1 X110.684 Y152.654 F152
G1 X110.626 Y152.681 F152
G1 X110.569 Y152.71 F152
G1 X110.546 Y152.723 F152
G1 X110.512 Y152.742 F152
G1 X110.455 Y152.774 F152
G1 X110.444 Y152.781 F152
G1 X110.397 Y152.807 F152
G1 X110.343 Y152.838 F152
G1 X110.34 Y152.84 F152
G1 X110.283 Y152.872 F152
G1 X110.242 Y152.895 F152
G1 X110.225 Y152.904 F152
G1 X110.168 Y152.936 F152
G1 X110.142 Y152.952 F152
G1 X110.111 Y152.972 F152
G1 X110.054 Y153.01 F152
G1 X109.996 Y153.046 F152
G1 X109.939 Y153.084 F152
G1 X109.882 Y153.121 F152
G1 X109.824 Y153.158 F152
G1 X109.788 Y153.182 F152
G1 X109.767 Y153.195 F152
G1 X109.71 Y153.236 F152
G1 X109.653 Y153.279 F152
G1 X109.63 Y153.296 F152
G1 X109.595 Y153.323 F152
G1 X109.554 Y153.353 F152
G1 X109.538 Y153.366 F152
G1 X109.481 Y153.409 F152
G1 X109.478 Y153.411 F152
G1 X109.402 Y153.468 F152
G1 X109.366 Y153.497 F152
G1 X109.309 Y153.545 F152
G1 X109.266 Y153.583 F152
G1 X109.252 Y153.594 F152
G1 X109.199 Y153.64 F152
G1 X109.194 Y153.643 F152
G1 X109.137 Y153.697 F152
G1 X109.08 Y153.752 F152
G1 X109.077 Y153.754 F152
G1 X109.022 Y153.806 F152
G1 X109.017 Y153.812 F152
G1 X108.965 Y153.866 F152
G1 X108.962 Y153.869 F152
G1 X108.908 Y153.926 F152
G1 X108.855 Y153.983 F152
G1 X108.851 Y153.988 F152
G1 X108.793 Y154.057 F152
G1 X108.758 Y154.098 F152
G1 X108.736 Y154.126 F152
G1 X108.712 Y154.155 F152
G1 X108.679 Y154.2 F152
G1 X108.669 Y154.213 F152
G1 X108.628 Y154.27 F152
G1 X108.621 Y154.279 F152
G1 X108.587 Y154.327 F152
G1 X108.564 Y154.36 F152
G1 X108.549 Y154.384 F152
G1 X108.514 Y154.442 F152
G1 X108.507 Y154.454 F152
G1 X108.479 Y154.499 F152
G1 X108.446 Y154.556 F152
G1 X108.417 Y154.614 F152
G1 X108.392 Y154.663 F152
G1 X108.388 Y154.671 F152
G1 X108.36 Y154.728 F152
G1 X108.335 Y154.784 F152
G1 X108.334 Y154.785 F152
G1 X108.289 Y154.9 F152
G1 X108.278 Y154.931 F152
G1 X108.268 Y154.957 F152
G1 X108.249 Y155.014 F152
G1 X108.233 Y155.072 F152
G1 X108.22 Y155.117 F152
G1 X108.217 Y155.129 F152
G1 X108.201 Y155.186 F152
G1 X108.189 Y155.244 F152
G1 X108.168 Y155.358 F152
G1 X108.158 Y155.415 F152
G1 X108.151 Y155.473 F152
G1 X108.141 Y155.587 F152
G1 X108.136 Y155.645 F152
G1 X108.134 Y155.759 F152
G1 Y155.816 F152
G1 X108.135 Y155.874 F152
G1 X108.139 Y155.931 F152
G1 X108.143 Y155.988 F152
G1 X108.147 Y156.045 F152
G1 X108.152 Y156.103 F152
G1 X108.16 Y156.16 F152
G1 X108.163 Y156.173 F152
G1 X108.169 Y156.217 F152
G1 X108.177 Y156.275 F152
G1 X108.187 Y156.332 F152
G1 X108.211 Y156.446 F152
G1 X108.22 Y156.49 F152
G1 X108.223 Y156.504 F152
G1 X108.237 Y156.561 F152
G1 X108.267 Y156.676 F152
G1 X108.278 Y156.717 F152
G1 X108.281 Y156.733 F152
G1 X108.3 Y156.79 F152
G1 X108.318 Y156.847 F152
G1 X108.337 Y156.905 F152
G1 X108.355 Y156.962 F152
G1 X108.373 Y157.019 F152
G1 X108.391 Y157.076 F152
G1 X108.392 Y157.077 F152
G1 X108.41 Y157.134 F152
G1 X108.432 Y157.191 F152
G1 X108.45 Y157.239 F152
G1 X108.453 Y157.248 F152
G1 X108.474 Y157.306 F152
G1 X108.495 Y157.363 F152
G1 X108.507 Y157.392 F152
G1 X108.517 Y157.42 F152
G1 X108.56 Y157.535 F152
G1 X108.564 Y157.545 F152
G1 X108.582 Y157.592 F152
G1 X108.605 Y157.649 F152
G1 X108.672 Y157.821 F152
G1 X108.679 Y157.835 F152
G1 X108.696 Y157.878 F152
G1 X108.736 Y157.981 F152
G1 X108.74 Y157.993 F152
G1 X108.785 Y158.107 F152
G1 X108.793 Y158.127 F152
G1 X108.808 Y158.165 F152
G1 X108.83 Y158.222 F152
G1 X108.851 Y158.274 F152
G1 X108.852 Y158.279 F152
G1 X108.875 Y158.337 F152
G1 X108.896 Y158.394 F152
G1 X108.908 Y158.425 F152
G1 X108.917 Y158.451 F152
G1 X108.938 Y158.508 F152
G1 X108.959 Y158.566 F152
G1 X108.965 Y158.581 F152
G1 X108.98 Y158.623 F152
G1 X109.001 Y158.68 F152
G1 X109.022 Y158.737 F152
G1 Y158.738 F152
G1 X109.079 Y158.909 F152
G1 X109.08 Y158.911 F152
G1 X109.098 Y158.967 F152
G1 X109.135 Y159.081 F152
G1 X109.137 Y159.086 F152
G1 X109.154 Y159.139 F152
G1 X109.186 Y159.253 F152
G1 X109.194 Y159.283 F152
G1 X109.201 Y159.31 F152
G1 X109.218 Y159.368 F152
G1 X109.233 Y159.425 F152
G1 X109.249 Y159.482 F152
G1 X109.252 Y159.49 F152
G1 X109.265 Y159.539 F152
G1 X109.278 Y159.597 F152
G1 X109.29 Y159.654 F152
G1 X109.309 Y159.74 F152
G1 X109.314 Y159.769 F152
G1 X109.339 Y159.883 F152
G1 X109.351 Y159.94 F152
G1 X109.362 Y159.998 F152
G1 X109.366 Y160.027 F152
G1 X109.37 Y160.055 F152
G1 X109.418 Y160.399 F152
G1 X109.422 Y160.456 F152
G1 X109.423 Y160.476 F152
G1 X109.425 Y160.513 F152
G1 X109.429 Y160.57 F152
G1 X109.433 Y160.628 F152
G1 X109.444 Y160.8 F152
G1 X109.445 Y160.857 F152
G1 X109.442 Y161.029 F152
G1 Y161.086 F152
G1 X109.44 Y161.201 F152
G1 X109.438 Y161.258 F152
G1 X109.427 Y161.372 F152
G1 X109.423 Y161.421 F152
G1 X109.417 Y161.487 F152
G1 X109.401 Y161.659 F152
G1 X109.392 Y161.716 F152
G1 X109.372 Y161.831 F152
G1 X109.366 Y161.872 F152
G1 X109.363 Y161.888 F152
G1 X109.344 Y162.002 F152
G1 X109.335 Y162.06 F152
G1 X109.322 Y162.117 F152
G1 X109.309 Y162.174 F152
G1 Y162.175 F152
G1 X109.295 Y162.232 F152
G1 X109.281 Y162.289 F152
G1 X109.252 Y162.415 F152
G1 X109.24 Y162.461 F152
G1 X109.227 Y162.518 F152
G1 X109.209 Y162.575 F152
G1 X109.194 Y162.623 F152
G1 X109.191 Y162.632 F152
G1 X109.174 Y162.69 F152
G1 X109.156 Y162.747 F152
G1 X109.139 Y162.804 F152
G1 X109.137 Y162.81 F152
G1 X109.121 Y162.862 F152
G1 X109.103 Y162.919 F152
G1 X109.084 Y162.976 F152
G1 X109.08 Y162.988 F152
G1 X109.063 Y163.033 F152
G1 X109.041 Y163.091 F152
G1 X109.022 Y163.144 F152
G1 X109.021 Y163.148 F152
G1 X108.999 Y163.205 F152
G1 X108.979 Y163.263 F152
G1 X108.965 Y163.299 F152
G1 X108.957 Y163.32 F152
G1 X108.936 Y163.377 F152
G1 X108.912 Y163.434 F152
G1 X108.908 Y163.445 F152
G1 X108.888 Y163.492 F152
G1 X108.863 Y163.549 F152
G1 X108.851 Y163.58 F152
G1 X108.839 Y163.606 F152
G1 X108.815 Y163.663 F152
G1 X108.793 Y163.715 F152
G1 X108.791 Y163.721 F152
G1 X108.766 Y163.778 F152
G1 X108.741 Y163.835 F152
G1 X108.736 Y163.847 F152
G1 X108.715 Y163.893 F152
G1 X108.687 Y163.95 F152
G1 X108.679 Y163.969 F152
G1 X108.66 Y164.007 F152
G1 X108.633 Y164.064 F152
G1 X108.621 Y164.089 F152
G1 X108.606 Y164.122 F152
G1 X108.579 Y164.179 F152
G1 X108.564 Y164.211 F152
G1 X108.507 Y164.326 F152
G1 X108.493 Y164.351 F152
G1 X108.464 Y164.408 F152
G1 X108.435 Y164.465 F152
G1 X108.347 Y164.637 F152
G1 X108.335 Y164.66 F152
G1 X108.317 Y164.694 F152
G1 X108.285 Y164.752 F152
G1 X108.278 Y164.766 F152
G1 X108.254 Y164.809 F152
G1 X108.222 Y164.866 F152
G1 X108.22 Y164.87 F152
G1 X108.191 Y164.924 F152
G1 X108.163 Y164.974 F152
G1 X108.16 Y164.981 F152
G1 X108.127 Y165.038 F152
G1 X108.106 Y165.078 F152
G1 X108.096 Y165.095 F152
G1 X108.064 Y165.153 F152
G1 X108.049 Y165.179 F152
G1 X108.031 Y165.21 F152
G1 X107.997 Y165.267 F152
G1 X107.991 Y165.278 F152
G1 X107.964 Y165.325 F152
G1 X107.934 Y165.376 F152
G1 X107.93 Y165.382 F152
G1 X107.897 Y165.439 F152
G1 X107.877 Y165.475 F152
G1 X107.864 Y165.496 F152
G1 X107.83 Y165.554 F152
G1 X107.819 Y165.572 F152
G1 X107.795 Y165.611 F152
G1 X107.762 Y165.666 F152
G1 X107.76 Y165.668 F152
G1 X107.725 Y165.725 F152
G1 X107.705 Y165.76 F152
G1 X107.691 Y165.783 F152
G1 X107.656 Y165.84 F152
G1 X107.648 Y165.854 F152
G1 X107.621 Y165.897 F152
G1 X107.59 Y165.948 F152
G1 X107.586 Y165.955 F152
G1 X107.551 Y166.012 F152
G1 X107.533 Y166.04 F152
G1 X107.514 Y166.069 F152
G1 X107.478 Y166.126 F152
G1 X107.476 Y166.13 F152
G1 X107.418 Y166.22 F152
G1 X107.405 Y166.241 F152
G1 X107.369 Y166.298 F152
G1 X107.332 Y166.356 F152
G1 X107.304 Y166.401 F152
G1 X107.296 Y166.413 F152
G1 X107.259 Y166.47 F152
G1 X107.247 Y166.489 F152
G1 X107.221 Y166.527 F152
G1 X107.189 Y166.576 F152
G1 X107.183 Y166.585 F152
G1 X107.145 Y166.642 F152
G1 X107.132 Y166.663 F152
G1 X107.108 Y166.699 F152
G1 X107.075 Y166.75 F152
G1 X107.07 Y166.757 F152
G1 X107.017 Y166.837 F152
G1 X106.994 Y166.871 F152
G1 X106.96 Y166.922 F152
G1 X106.956 Y166.928 F152
G1 X106.916 Y166.986 F152
G1 X106.903 Y167.006 F152
G1 X106.878 Y167.043 F152
G1 X106.846 Y167.09 F152
G1 X106.838 Y167.1 F152
G1 X106.8 Y167.157 F152
G1 X106.761 Y167.215 F152
G1 X106.731 Y167.259 F152
G1 X106.722 Y167.272 F152
G1 X106.683 Y167.329 F152
G1 X106.674 Y167.342 F152
G1 X106.642 Y167.387 F152
G1 X106.616 Y167.423 F152
G1 X106.602 Y167.444 F152
G1 X106.562 Y167.501 F152
G1 X106.559 Y167.506 F152
G1 X106.522 Y167.558 F152
G1 X106.482 Y167.616 F152
G1 X106.445 Y167.669 F152
G1 X106.442 Y167.673 F152
G1 X106.402 Y167.73 F152
G1 X106.387 Y167.75 F152
G1 X106.36 Y167.788 F152
G1 X106.33 Y167.83 F152
G1 X106.319 Y167.845 F152
G1 X106.278 Y167.902 F152
G1 X106.273 Y167.909 F152
G1 X106.237 Y167.959 F152
G1 X106.215 Y167.99 F152
G1 X106.196 Y168.017 F152
G1 X106.158 Y168.069 F152
G1 X106.155 Y168.074 F152
G1 X106.113 Y168.131 F152
G1 X106.101 Y168.149 F152
G1 X106.071 Y168.188 F152
G1 X106.044 Y168.226 F152
G1 X106.029 Y168.246 F152
G1 X105.943 Y168.36 F152
G1 X105.929 Y168.38 F152
G1 X105.901 Y168.418 F152
G1 X105.858 Y168.475 F152
G1 X105.816 Y168.532 F152
G1 X105.814 Y168.534 F152
G1 X105.773 Y168.589 F152
G1 X105.73 Y168.647 F152
G1 X105.7 Y168.688 F152
G1 X105.688 Y168.704 F152
G1 X105.602 Y168.819 F152
G1 X105.585 Y168.842 F152
G1 X105.56 Y168.876 F152
G1 X105.474 Y168.99 F152
G1 X105.471 Y168.996 F152
G1 X105.432 Y169.048 F152
G1 X105.413 Y169.073 F152
G1 X105.388 Y169.105 F152
G1 X105.356 Y169.147 F152
G1 X105.344 Y169.162 F152
G1 X105.3 Y169.219 F152
G1 X105.299 Y169.221 F152
G1 X105.256 Y169.277 F152
G1 X105.242 Y169.295 F152
G1 X105.211 Y169.334 F152
G1 X105.184 Y169.369 F152
G1 X105.167 Y169.391 F152
G1 X105.127 Y169.443 F152
G1 X105.123 Y169.449 F152
G1 X105.035 Y169.563 F152
G1 X104.99 Y169.62 F152
G1 X104.946 Y169.678 F152
G1 X104.901 Y169.735 F152
G1 X104.898 Y169.74 F152
G1 X104.858 Y169.792 F152
G1 X104.841 Y169.815 F152
G1 X104.813 Y169.85 F152
G1 X104.783 Y169.888 F152
G1 X104.769 Y169.907 F152
G1 X104.726 Y169.962 F152
G1 X104.725 Y169.964 F152
G1 X104.679 Y170.021 F152
G1 X104.669 Y170.036 F152
G1 X104.635 Y170.079 F152
G1 X104.611 Y170.108 F152
G1 X104.59 Y170.136 F152
G1 X104.554 Y170.181 F152
G1 X104.5 Y170.25 F152
G1 X104.497 Y170.254 F152
G1 X104.455 Y170.308 F152
G1 X104.44 Y170.327 F152
G1 X104.409 Y170.365 F152
G1 X104.382 Y170.4 F152
G1 X104.325 Y170.472 F152
G1 X104.274 Y170.537 F152
G1 X104.268 Y170.544 F152
G1 X104.228 Y170.594 F152
G1 X104.21 Y170.617 F152
G1 X104.183 Y170.651 F152
G1 X104.153 Y170.689 F152
G1 X104.138 Y170.709 F152
G1 X104.047 Y170.823 F152
G1 X104.039 Y170.834 F152
G1 X104.001 Y170.881 F152
G1 X103.981 Y170.906 F152
G1 X103.956 Y170.938 F152
G1 X103.924 Y170.978 F152
G1 X103.867 Y171.051 F152
G1 X103.865 Y171.052 F152
G1 X103.819 Y171.11 F152
G1 X103.809 Y171.123 F152
G1 X103.775 Y171.167 F152
G1 X103.752 Y171.195 F152
G1 X103.729 Y171.224 F152
G1 X103.695 Y171.267 F152
G1 X103.683 Y171.281 F152
G1 X103.638 Y171.339 F152
G1 Y171.34 F152
G1 X103.593 Y171.396 F152
G1 X103.58 Y171.412 F152
G1 X103.547 Y171.453 F152
G1 X103.523 Y171.485 F152
G1 X103.502 Y171.511 F152
G1 X103.466 Y171.557 F152
G1 X103.457 Y171.568 F152
G1 X103.412 Y171.625 F152
G1 X103.366 Y171.682 F152
G1 X103.351 Y171.702 F152
G1 X103.322 Y171.74 F152
G1 X103.294 Y171.775 F152
G1 X103.277 Y171.797 F152
G1 X103.237 Y171.849 F152
G1 X103.232 Y171.854 F152
G1 X103.187 Y171.912 F152
G1 X103.179 Y171.921 F152
G1 X103.143 Y171.969 F152
G1 X103.122 Y171.996 F152
G1 X103.098 Y172.026 F152
G1 X103.065 Y172.069 F152
G1 X103.053 Y172.083 F152
G1 X103.009 Y172.141 F152
G1 X103.007 Y172.143 F152
G1 X102.95 Y172.218 F152
G1 X102.921 Y172.255 F152
G1 X102.893 Y172.292 F152
G1 X102.878 Y172.312 F152
G1 X102.836 Y172.367 F152
G1 X102.834 Y172.37 F152
G1 X102.79 Y172.427 F152
G1 X102.778 Y172.443 F152
G1 X102.721 Y172.518 F152
G1 X102.704 Y172.542 F152
G1 X102.661 Y172.599 F152
G1 X102.606 Y172.673 F152
G1 X102.576 Y172.713 F152
G1 X102.549 Y172.75 F152
G1 X102.534 Y172.771 F152
G1 X102.492 Y172.828 F152
G1 X102.41 Y172.943 F152
G1 X102.367 Y173 F152
G1 X102.326 Y173.057 F152
G1 X102.286 Y173.114 F152
G1 X102.263 Y173.147 F152
G1 X102.245 Y173.172 F152
G1 X102.205 Y173.227 F152
G1 Y173.229 F152
G1 X102.163 Y173.286 F152
G1 X102.148 Y173.308 F152
G1 X102.123 Y173.343 F152
G1 X102.082 Y173.401 F152
G1 X102.042 Y173.458 F152
G1 X102.034 Y173.469 F152
G1 X101.976 Y173.549 F152
G1 X101.96 Y173.573 F152
G1 X101.919 Y173.63 F152
G1 X101.879 Y173.687 F152
G1 X101.862 Y173.71 F152
G1 X101.838 Y173.744 F152
G1 X101.804 Y173.79 F152
G1 X101.796 Y173.802 F152
G1 X101.755 Y173.859 F152
G1 X101.747 Y173.87 F152
G1 X101.69 Y173.95 F152
G1 X101.673 Y173.974 F152
G1 X101.633 Y174.03 F152
G1 X101.632 Y174.031 F152
G1 X101.59 Y174.088 F152
G1 X101.575 Y174.11 F152
G1 X101.55 Y174.145 F152
G1 X101.518 Y174.192 F152
G1 X101.51 Y174.203 F152
G1 X101.461 Y174.274 F152
G1 X101.43 Y174.317 F152
G1 X101.403 Y174.356 F152
G1 X101.391 Y174.374 F152
G1 X101.353 Y174.432 F152
G1 X101.346 Y174.443 F152
G1 X101.289 Y174.53 F152
G1 X101.278 Y174.546 F152
G1 X101.241 Y174.604 F152
G1 X101.232 Y174.617 F152
G1 X101.205 Y174.661 F152
G1 X101.174 Y174.713 F152
G1 X101.172 Y174.718 F152
G1 X101.138 Y174.775 F152
G1 X101.117 Y174.812 F152
G1 X101.104 Y174.833 F152
G1 X101.071 Y174.89 F152
G1 X101.06 Y174.911 F152
G1 X101.002 Y175.026 F152
G1 X100.985 Y175.062 F152
G1 X100.96 Y175.119 F152
G1 X100.945 Y175.156 F152
G1 X100.936 Y175.176 F152
G1 X100.914 Y175.234 F152
G1 X100.894 Y175.291 F152
G1 X100.888 Y175.311 F152
G1 X100.874 Y175.348 F152
G1 X100.858 Y175.406 F152
G1 X100.844 Y175.463 F152
G1 X100.831 Y175.52 F152
G1 Y175.524 F152
G1 X100.82 Y175.577 F152
G1 X100.805 Y175.692 F152
G1 X100.801 Y175.749 F152
G1 X100.799 Y175.806 F152
G1 X100.801 Y175.921 F152
G1 X100.805 Y175.978 F152
G1 X100.82 Y176.093 F152
G1 X100.831 Y176.147 F152
G1 Y176.15 F152
G1 X100.859 Y176.265 F152
G1 X100.877 Y176.322 F152
G1 X100.888 Y176.351 F152
G1 X100.899 Y176.379 F152
G1 X100.968 Y176.551 F152
G1 X100.994 Y176.608 F152
G1 X101.002 Y176.623 F152
G1 X101.025 Y176.666 F152
G1 X101.055 Y176.723 F152
G1 X101.06 Y176.731 F152
G1 X101.086 Y176.78 F152
G1 X101.116 Y176.837 F152
G1 X101.117 Y176.838 F152
G1 X101.147 Y176.895 F152
G1 X101.174 Y176.943 F152
G1 X101.179 Y176.952 F152
G1 X101.208 Y177.009 F152
G1 X101.232 Y177.059 F152
G1 X101.235 Y177.067 F152
G1 X101.261 Y177.124 F152
G1 X101.279 Y177.181 F152
G1 X101.289 Y177.212 F152
G1 X101.297 Y177.238 F152
G1 X101.303 Y177.267 F152
G1 X101.308 Y177.296 F152
G1 X101.309 Y177.353 F152
G1 X101.307 Y177.41 F152
G1 X101.297 Y177.468 F152
G1 X101.289 Y177.51 F152
G1 X101.285 Y177.525 F152
G1 X101.274 Y177.582 F152
G1 X101.258 Y177.639 F152
G1 X101.239 Y177.697 F152
G1 X101.232 Y177.721 F152
G1 X101.221 Y177.754 F152
G1 X101.201 Y177.811 F152
G1 X101.179 Y177.868 F152
G1 X101.174 Y177.882 F152
G1 X101.157 Y177.926 F152
G1 X101.135 Y177.983 F152
G1 X101.117 Y178.03 F152
G1 X101.113 Y178.04 F152
G1 X101.091 Y178.098 F152
G1 X101.069 Y178.155 F152
G1 X101.06 Y178.178 F152
G1 X101.046 Y178.212 F152
G1 X101.024 Y178.269 F152
G1 X101.002 Y178.327 F152
G1 Y178.328 F152
G1 X100.985 Y178.384 F152
G1 X100.966 Y178.441 F152
G1 X100.948 Y178.499 F152
G1 X100.945 Y178.507 F152
G1 X100.929 Y178.556 F152
G1 X100.911 Y178.613 F152
G1 X100.896 Y178.67 F152
G1 X100.888 Y178.708 F152
G1 X100.883 Y178.728 F152
G1 X100.858 Y178.842 F152
G1 X100.85 Y178.899 F152
G1 X100.843 Y178.957 F152
G1 X100.835 Y179.014 F152
G1 X100.831 Y179.071 F152
G1 Y179.095 F152
G1 X100.829 Y179.129 F152
G1 X100.827 Y179.186 F152
G1 X100.826 Y179.243 F152
G1 X100.83 Y179.3 F152
G1 X100.831 Y179.311 F152
G1 X100.839 Y179.415 F152
G1 X100.845 Y179.472 F152
G1 X100.856 Y179.53 F152
G1 X100.868 Y179.587 F152
G1 X100.88 Y179.644 F152
G1 X100.888 Y179.677 F152
G1 X100.894 Y179.701 F152
G1 X100.913 Y179.759 F152
G1 X100.945 Y179.853 F152
G1 X100.952 Y179.873 F152
G1 X100.975 Y179.93 F152
G1 X101.002 Y179.988 F152
G1 Y179.989 F152
G1 X101.029 Y180.045 F152
G1 X101.057 Y180.102 F152
G1 X101.06 Y180.107 F152
G1 X101.09 Y180.16 F152
G1 X101.117 Y180.203 F152
G1 X101.125 Y180.217 F152
G1 X101.16 Y180.274 F152
G1 X101.174 Y180.297 F152
G1 X101.198 Y180.331 F152
G1 X101.232 Y180.376 F152
G1 X101.241 Y180.389 F152
G1 X101.283 Y180.446 F152
G1 X101.289 Y180.455 F152
G1 X101.328 Y180.503 F152
G1 X101.346 Y180.525 F152
G1 X101.377 Y180.561 F152
G1 X101.403 Y180.593 F152
G1 X101.425 Y180.618 F152
G1 X101.461 Y180.657 F152
G1 X101.479 Y180.675 F152
G1 X101.518 Y180.715 F152
G1 X101.535 Y180.732 F152
G1 X101.575 Y180.774 F152
G1 X101.633 Y180.831 F152
G1 X101.648 Y180.847 F152
G1 X101.705 Y180.904 F152
G1 X101.747 Y180.944 F152
G1 X101.768 Y180.961 F152
G1 X101.833 Y181.019 F152
G1 X101.862 Y181.045 F152
G1 X101.963 Y181.133 F152
G1 X101.976 Y181.145 F152
G1 X102.028 Y181.191 F152
G1 X102.034 Y181.195 F152
G1 X102.1 Y181.248 F152
G1 X102.148 Y181.287 F152
G1 X102.171 Y181.305 F152
G1 X102.205 Y181.333 F152
G1 X102.242 Y181.362 F152
G1 X102.263 Y181.379 F152
G1 X102.313 Y181.42 F152
G1 X102.32 Y181.425 F152
G1 X102.377 Y181.47 F152
G1 X102.387 Y181.477 F152
G1 X102.435 Y181.513 F152
G1 X102.492 Y181.556 F152
G1 X102.539 Y181.592 F152
G1 X102.549 Y181.6 F152
G1 X102.606 Y181.643 F152
G1 X102.615 Y181.649 F152
G1 X102.664 Y181.686 F152
G1 X102.693 Y181.706 F152
G1 X102.721 Y181.725 F152
G1 X102.776 Y181.763 F152
G1 X102.778 Y181.765 F152
G1 X102.836 Y181.805 F152
G1 X102.858 Y181.821 F152
G1 X102.893 Y181.845 F152
G1 X102.94 Y181.878 F152
G1 X102.95 Y181.885 F152
G1 X103.007 Y181.923 F152
G1 X103.294 Y182.097 F152
G1 X103.351 Y182.129 F152
G1 X103.408 Y182.157 F152
G1 X103.422 Y182.164 F152
G1 X103.466 Y182.187 F152
G1 X103.523 Y182.214 F152
G1 X103.541 Y182.222 F152
G1 X103.58 Y182.239 F152
G1 X103.638 Y182.264 F152
G1 X103.674 Y182.279 F152
G1 X103.695 Y182.288 F152
G1 X103.752 Y182.308 F152
G1 X103.809 Y182.326 F152
G1 X103.839 Y182.336 F152
G1 X103.867 Y182.346 F152
G1 X103.924 Y182.362 F152
G1 X104.039 Y182.389 F152
G1 X104.06 Y182.393 F152
G1 X104.096 Y182.401 F152
G1 X104.153 Y182.41 F152
G1 X104.268 Y182.425 F152
G1 X104.325 Y182.43 F152
G1 X104.382 Y182.433 F152
G1 X104.497 F152
G1 X104.554 Y182.432 F152
G1 X104.611 Y182.427 F152
G1 X104.669 Y182.421 F152
G1 X104.726 Y182.414 F152
G1 X104.783 Y182.406 F152
G1 X104.841 Y182.395 F152
G1 X104.845 Y182.393 F152
G1 X104.898 Y182.381 F152
G1 X104.955 Y182.367 F152
G1 X105.012 Y182.353 F152
G1 X105.063 Y182.336 F152
G1 X105.07 Y182.333 F152
G1 X105.127 Y182.314 F152
G1 X105.184 Y182.293 F152
G1 X105.242 Y182.271 F152
G1 X105.299 Y182.244 F152
G1 X105.345 Y182.222 F152
G1 X105.356 Y182.217 F152
G1 X105.413 Y182.189 F152
G1 X105.459 Y182.164 F152
G1 X105.471 Y182.158 F152
G1 X105.528 Y182.124 F152
G1 X105.558 Y182.107 F152
G1 X105.585 Y182.091 F152
G1 X105.648 Y182.05 F152
G1 X105.7 Y182.014 F152
G1 X105.757 Y181.975 F152
G1 X105.809 Y181.935 F152
G1 X105.872 Y181.882 F152
G1 X105.876 Y181.878 F152
G1 X105.929 Y181.833 F152
G1 X105.943 Y181.821 F152
G1 X106.01 Y181.763 F152
G1 X106.044 Y181.736 F152
G1 X106.077 Y181.706 F152
G1 X106.101 Y181.683 F152
G1 X106.133 Y181.649 F152
G1 X106.158 Y181.621 F152
G1 X106.186 Y181.592 F152
G1 X106.215 Y181.559 F152
G1 X106.273 Y181.498 F152
G1 X106.292 Y181.477 F152
G1 X106.33 Y181.436 F152
G1 X106.344 Y181.42 F152
G1 X106.387 Y181.365 F152
G1 X106.389 Y181.362 F152
G1 X106.433 Y181.305 F152
G1 X106.445 Y181.289 F152
G1 X106.476 Y181.248 F152
G1 X106.502 Y181.213 F152
G1 X106.519 Y181.191 F152
G1 X106.562 Y181.133 F152
G1 X106.599 Y181.076 F152
G1 X106.616 Y181.048 F152
G1 X106.635 Y181.019 F152
G1 X106.671 Y180.961 F152
G1 X106.674 Y180.957 F152
G1 X106.707 Y180.904 F152
G1 X106.731 Y180.865 F152
G1 X106.743 Y180.847 F152
G1 X106.774 Y180.79 F152
G1 X106.835 Y180.675 F152
G1 X106.846 Y180.654 F152
G1 X106.865 Y180.618 F152
G1 X106.895 Y180.561 F152
G1 X106.956 Y180.446 F152
G1 X106.96 Y180.437 F152
G1 X106.986 Y180.389 F152
G1 X107.017 Y180.331 F152
G1 Y180.329 F152
G1 X107.047 Y180.274 F152
G1 X107.075 Y180.223 F152
G1 X107.078 Y180.217 F152
G1 X107.11 Y180.16 F152
G1 X107.132 Y180.119 F152
G1 X107.143 Y180.102 F152
G1 X107.179 Y180.045 F152
G1 X107.189 Y180.028 F152
G1 X107.247 Y179.936 F152
G1 X107.25 Y179.93 F152
G1 X107.29 Y179.873 F152
G1 X107.304 Y179.854 F152
G1 X107.332 Y179.816 F152
G1 X107.361 Y179.778 F152
G1 X107.376 Y179.759 F152
G1 X107.418 Y179.707 F152
G1 X107.424 Y179.701 F152
G1 X107.476 Y179.639 F152
G1 X107.522 Y179.587 F152
G1 X107.575 Y179.53 F152
G1 X107.59 Y179.513 F152
G1 X107.631 Y179.472 F152
G1 X107.648 Y179.454 F152
G1 X107.686 Y179.415 F152
G1 X107.746 Y179.358 F152
G1 X107.762 Y179.342 F152
G1 X107.806 Y179.3 F152
G1 X107.819 Y179.288 F152
G1 X107.87 Y179.243 F152
G1 X107.877 Y179.237 F152
G1 X107.934 Y179.186 F152
G1 X107.991 Y179.138 F152
G1 X108.002 Y179.129 F152
G1 X108.049 Y179.089 F152
G1 X108.07 Y179.071 F152
G1 X108.106 Y179.043 F152
G1 X108.143 Y179.014 F152
G1 X108.163 Y178.999 F152
G1 X108.218 Y178.957 F152
G1 X108.22 Y178.954 F152
G1 X108.278 Y178.91 F152
G1 X108.292 Y178.899 F152
G1 X108.366 Y178.842 F152
G1 X108.392 Y178.822 F152
G1 X108.444 Y178.785 F152
G1 X108.45 Y178.781 F152
G1 X108.507 Y178.742 F152
G1 X108.527 Y178.728 F152
G1 X108.564 Y178.703 F152
G1 X108.611 Y178.67 F152
G1 X108.621 Y178.663 F152
G1 X108.679 Y178.624 F152
G1 X108.694 Y178.613 F152
G1 X108.736 Y178.584 F152
G1 X108.777 Y178.556 F152
G1 X108.851 Y178.511 F152
G1 X108.87 Y178.499 F152
G1 X108.908 Y178.475 F152
G1 X108.963 Y178.441 F152
G1 X108.965 Y178.44 F152
G1 X109.022 Y178.405 F152
G1 X109.056 Y178.384 F152
G1 X109.08 Y178.37 F152
G1 X109.137 Y178.335 F152
G1 X109.15 Y178.327 F152
G1 X109.194 Y178.302 F152
G1 X109.252 Y178.269 F152
G1 X109.423 Y178.175 F152
G1 X109.481 Y178.143 F152
G1 X109.538 Y178.112 F152
G1 X109.564 Y178.098 F152
G1 X109.653 Y178.055 F152
G1 X109.681 Y178.04 F152
G1 X109.71 Y178.027 F152
G1 X109.767 Y177.998 F152
G1 X109.882 Y177.943 F152
G1 X109.916 Y177.926 F152
G1 X109.939 Y177.915 F152
G1 X109.996 Y177.887 F152
G1 X110.04 Y177.868 F152
G1 X110.054 Y177.863 F152
G1 X110.168 Y177.815 F152
G1 X110.175 Y177.811 F152
G1 X110.225 Y177.79 F152
G1 X110.283 Y177.766 F152
G1 X110.31 Y177.754 F152
G1 X110.34 Y177.741 F152
G1 X110.397 Y177.717 F152
G1 X110.45 Y177.697 F152
G1 X110.455 Y177.696 F152
G1 X110.512 Y177.674 F152
G1 X110.569 Y177.654 F152
G1 X110.608 Y177.639 F152
G1 X110.626 Y177.633 F152
G1 X110.684 Y177.613 F152
G1 X110.741 Y177.591 F152
G1 X110.765 Y177.582 F152
G1 X110.798 Y177.57 F152
G1 X110.856 Y177.551 F152
G1 X110.913 Y177.534 F152
G1 X110.941 Y177.525 F152
G1 X110.97 Y177.517 F152
G1 X111.027 Y177.499 F152
G1 X111.085 Y177.482 F152
G1 X111.131 Y177.468 F152
G1 X111.142 Y177.465 F152
G1 X111.199 Y177.448 F152
G1 X111.257 Y177.43 F152
G1 X111.314 Y177.417 F152
G1 X111.338 Y177.41 F152
G1 X111.371 Y177.403 F152
G1 X111.428 Y177.389 F152
G1 X111.543 Y177.362 F152
G1 X111.577 Y177.353 F152
G1 X111.6 Y177.348 F152
G1 X111.658 Y177.334 F152
G1 X111.715 Y177.323 F152
G1 X111.772 Y177.313 F152
G1 X111.829 Y177.302 F152
G1 X111.864 Y177.296 F152
G1 X111.887 Y177.292 F152
G1 X111.944 Y177.282 F152
G1 X112.001 Y177.272 F152
G1 X112.059 Y177.262 F152
G1 X112.116 Y177.253 F152
G1 X112.173 Y177.246 F152
G1 X112.23 Y177.239 F152
G1 X112.235 Y177.238 F152
G1 X112.288 Y177.233 F152
G1 X112.345 Y177.226 F152
G1 X112.402 Y177.22 F152
G1 X112.46 Y177.212 F152
G1 X112.517 Y177.206 F152
G1 X112.574 Y177.203 F152
G1 X112.631 Y177.2 F152
G1 X112.689 Y177.196 F152
G1 X112.746 Y177.194 F152
G1 X112.803 Y177.19 F152
G1 X112.861 Y177.187 F152
G1 X112.918 Y177.184 F152
G1 X113.09 F152
G1 X113.147 Y177.185 F152
G1 X113.319 F152
G1 X113.376 Y177.187 F152
G1 X113.72 Y177.209 F152
G1 X113.777 Y177.214 F152
G1 X113.949 Y177.236 F152
G1 X113.977 Y177.238 F152
G1 X114.006 Y177.242 F152
G1 X114.121 Y177.256 F152
G1 X114.178 Y177.264 F152
G1 X114.235 Y177.274 F152
G1 X114.35 Y177.296 F152
G1 X114.352 F152
G1 X114.407 Y177.306 F152
G1 X114.465 Y177.316 F152
G1 X114.579 Y177.338 F152
G1 X114.636 Y177.351 F152
G1 X114.644 Y177.353 F152
G1 X114.694 Y177.365 F152
G1 X114.751 Y177.38 F152
G1 X114.808 Y177.393 F152
G1 X114.866 Y177.408 F152
G1 X114.878 Y177.41 F152
G1 X114.923 Y177.421 F152
G1 X114.98 Y177.435 F152
G1 X115.037 Y177.452 F152
G1 X115.089 Y177.468 F152
G1 X115.095 Y177.469 F152
G1 X115.152 Y177.487 F152
G1 X115.209 Y177.504 F152
G1 X115.267 Y177.522 F152
G1 X115.276 Y177.525 F152
G1 X115.324 Y177.54 F152
G1 X115.381 Y177.557 F152
G1 X115.438 Y177.577 F152
G1 X115.455 Y177.582 F152
G1 X115.496 Y177.597 F152
G1 X115.553 Y177.619 F152
G1 X115.608 Y177.639 F152
G1 X115.61 Y177.64 F152
G1 X115.668 Y177.662 F152
G1 X115.725 Y177.682 F152
G1 X115.763 Y177.697 F152
G1 X115.782 Y177.704 F152
G1 X115.839 Y177.725 F152
G1 X115.905 Y177.754 F152
G1 X115.954 Y177.775 F152
G1 X115.97 Y177.783 F152
G1 X115.983 Y177.788 F152
G1 X116.011 Y177.8 F152
G1 X116.036 Y177.811 F152
G1 X116.04 Y177.813 F152
G1 X116.097 Y177.838 F152
G1 X116.102 Y177.84 F152
G1 X116.112 Y177.844 F152
G1 X116.126 Y177.851 F152
G1 X116.168 Y177.868 F152
G1 X116.172 Y177.871 F152
G1 X116.183 Y177.876 F152
G1 X116.212 Y177.888 F152
G1 X116.233 Y177.897 F152
G1 X116.24 Y177.901 F152
G1 X116.262 Y177.911 F152
G1 X116.312 Y177.936 F152
G1 X116.326 Y177.944 F152
G1 X116.331 Y177.945 F152
G1 X116.335 Y177.948 F152
G1 X116.341 Y177.951 F152
G1 X116.349 Y177.954 F152
G1 X116.355 Y177.958 F152
G1 X116.362 Y177.962 F152
G1 X116.365 F152
G1 X116.367 Y177.963 F152
G1 X116.369 Y177.965 F152
G1 X116.381 Y177.97 F152
G1 X116.384 Y177.972 F152
G1 X116.39 Y177.975 F152
G1 X116.392 Y177.976 F152
G1 X116.394 Y177.978 F152
G1 X116.399 Y177.979 F152
G1 X116.402 Y177.981 F152
G1 X116.404 Y177.982 F152
G1 X116.406 Y177.983 F152
G1 X116.409 Y177.985 F152
G1 X116.41 F152
G1 X116.412 Y177.987 F152
G1 X116.415 F152
G1 X116.419 Y177.99 F152
G1 X116.422 Y177.991 F152
G1 X116.424 Y177.992 F152
G1 X116.425 Y177.993 F152
G1 X116.427 Y177.994 F152
G1 X116.428 Y177.995 F152
G1 X116.431 Y177.996 F152
G1 X116.434 Y177.997 F152
G1 X116.435 F152
; MOVEMENT_LINK_TRANSITION
G1 X116.434 Y177.998 F152
; MOVEMENT_CUTTING
G1 X116.43 Y177.997 F152
G1 X116.427 Y177.996 F152
G1 X116.425 Y177.995 F152
G1 X116.424 Y177.994 F152
G1 X116.422 F152
G1 X116.419 Y177.992 F152
G1 X116.417 Y177.991 F152
G1 X116.41 Y177.989 F152
G1 X116.409 Y177.987 F152
G1 X116.406 F152
G1 X116.404 Y177.986 F152
G1 X116.402 Y177.984 F152
G1 X116.398 Y177.983 F152
G1 X116.394 Y177.981 F152
G1 X116.391 Y177.98 F152
G1 X116.389 Y177.979 F152
G1 X116.384 Y177.976 F152
G1 X116.38 Y177.975 F152
G1 X116.369 Y177.97 F152
G1 X116.366 Y177.969 F152
G1 X116.355 Y177.963 F152
G1 X116.352 Y177.962 F152
G1 X116.348 Y177.961 F152
G1 X116.341 Y177.957 F152
G1 X116.334 Y177.954 F152
G1 X116.331 Y177.953 F152
G1 X116.326 Y177.951 F152
G1 X116.319 Y177.947 F152
G1 X116.312 Y177.945 F152
G1 X116.302 Y177.94 F152
G1 X116.298 Y177.938 F152
G1 X116.291 Y177.935 F152
G1 X116.276 Y177.928 F152
G1 X116.262 Y177.923 F152
G1 X116.24 Y177.914 F152
G1 X116.232 Y177.911 F152
G1 X116.226 Y177.909 F152
G1 X116.212 Y177.903 F152
G1 X116.196 Y177.897 F152
G1 X116.183 Y177.892 F152
G1 X116.172 Y177.887 F152
G1 X116.16 Y177.883 F152
G1 X116.154 Y177.88 F152
G1 X116.126 Y177.869 F152
G1 X116.123 Y177.868 F152
G1 X116.112 Y177.864 F152
G1 X116.097 Y177.858 F152
G1 X116.069 Y177.847 F152
G1 X116.051 Y177.84 F152
G1 X116.04 Y177.835 F152
G1 X116.011 Y177.825 F152
G1 X115.97 Y177.811 F152
G1 X115.968 Y177.81 F152
G1 X115.954 Y177.805 F152
G1 X115.839 Y177.766 F152
G1 X115.804 Y177.754 F152
G1 X115.782 Y177.746 F152
G1 X115.753 Y177.737 F152
G1 X115.725 Y177.729 F152
G1 X115.617 Y177.697 F152
G1 X115.61 Y177.695 F152
G1 X115.582 Y177.686 F152
G1 X115.496 Y177.662 F152
G1 X115.4 Y177.639 F152
G1 X115.381 Y177.635 F152
G1 X115.209 Y177.595 F152
G1 X115.155 Y177.582 F152
G1 X115.152 Y177.581 F152
G1 X115.037 Y177.554 F152
G1 X114.98 Y177.542 F152
G1 X114.923 Y177.533 F152
G1 X114.868 Y177.525 F152
G1 X114.866 Y177.524 F152
G1 X114.808 Y177.515 F152
G1 X114.751 Y177.507 F152
G1 X114.636 Y177.489 F152
G1 X114.579 Y177.481 F152
G1 X114.522 Y177.472 F152
G1 X114.49 Y177.468 F152
G1 X114.465 Y177.463 F152
G1 X114.407 Y177.457 F152
G1 X114.35 Y177.452 F152
G1 X114.293 Y177.449 F152
G1 X114.178 Y177.44 F152
G1 X114.121 Y177.436 F152
G1 X114.006 Y177.427 F152
G1 X113.949 Y177.424 F152
G1 X113.892 Y177.419 F152
G1 X113.834 Y177.417 F152
G1 X113.777 F152
G1 X113.72 F152
G1 X113.605 Y177.415 F152
G1 X113.548 Y177.416 F152
G1 X113.491 Y177.417 F152
G1 X113.433 Y177.418 F152
G1 X113.319 Y177.422 F152
G1 X113.262 Y177.425 F152
G1 X113.204 Y177.429 F152
G1 X113.147 Y177.433 F152
G1 X113.09 Y177.437 F152
G1 X113.032 Y177.441 F152
G1 X112.975 Y177.446 F152
G1 X112.918 Y177.453 F152
G1 X112.803 Y177.466 F152
G1 X112.793 Y177.468 F152
G1 X112.746 Y177.472 F152
G1 X112.689 Y177.48 F152
G1 X112.631 Y177.49 F152
G1 X112.46 Y177.517 F152
G1 X112.402 Y177.527 F152
G1 X112.173 Y177.574 F152
G1 X111.944 Y177.631 F152
G1 X111.914 Y177.639 F152
G1 X111.887 Y177.647 F152
G1 X111.772 Y177.681 F152
G1 X111.72 Y177.697 F152
G1 X111.715 Y177.698 F152
G1 X111.6 Y177.733 F152
G1 X111.543 Y177.753 F152
G1 X111.542 Y177.754 F152
G1 X111.486 Y177.774 F152
G1 X111.428 Y177.794 F152
G1 X111.382 Y177.811 F152
G1 X111.371 Y177.815 F152
G1 X111.314 Y177.836 F152
G1 X111.257 Y177.86 F152
G1 X111.237 Y177.868 F152
G1 X111.142 Y177.907 F152
G1 X111.097 Y177.926 F152
G1 X111.085 Y177.93 F152
G1 X110.97 Y177.984 F152
G1 X110.913 Y178.01 F152
G1 X110.856 Y178.037 F152
G1 X110.849 Y178.04 F152
G1 X110.798 Y178.065 F152
G1 X110.741 Y178.095 F152
G1 X110.737 Y178.098 F152
G1 X110.627 Y178.155 F152
G1 X110.626 F152
G1 X110.569 Y178.185 F152
G1 X110.523 Y178.212 F152
G1 X110.512 Y178.218 F152
G1 X110.455 Y178.252 F152
G1 X110.425 Y178.269 F152
G1 X110.34 Y178.319 F152
G1 X110.168 Y178.429 F152
G1 X110.148 Y178.441 F152
G1 X110.111 Y178.465 F152
G1 X110.063 Y178.499 F152
G1 X109.996 Y178.548 F152
G1 X109.986 Y178.556 F152
G1 X109.939 Y178.59 F152
G1 X109.907 Y178.613 F152
G1 X109.882 Y178.631 F152
G1 X109.71 Y178.757 F152
G1 X109.672 Y178.785 F152
G1 X109.653 Y178.801 F152
G1 X109.604 Y178.842 F152
G1 X109.595 Y178.849 F152
G1 X109.538 Y178.899 F152
G1 X109.537 F152
G1 X109.481 Y178.948 F152
G1 X109.47 Y178.957 F152
G1 X109.423 Y178.997 F152
G1 X109.403 Y179.014 F152
G1 X109.336 Y179.071 F152
G1 X109.269 Y179.129 F152
G1 X109.252 Y179.146 F152
G1 X109.21 Y179.186 F152
G1 X109.194 Y179.202 F152
G1 X109.152 Y179.243 F152
G1 X109.137 Y179.258 F152
G1 X109.094 Y179.3 F152
G1 X109.08 Y179.315 F152
G1 X109.036 Y179.358 F152
G1 X109.022 Y179.371 F152
G1 X108.978 Y179.415 F152
G1 X108.965 Y179.428 F152
G1 X108.919 Y179.472 F152
G1 X108.908 Y179.484 F152
G1 X108.866 Y179.53 F152
G1 X108.851 Y179.547 F152
G1 X108.816 Y179.587 F152
G1 X108.714 Y179.701 F152
G1 X108.679 Y179.742 F152
G1 X108.663 Y179.759 F152
G1 X108.621 Y179.806 F152
G1 X108.612 Y179.816 F152
G1 X108.564 Y179.871 F152
G1 X108.562 Y179.873 F152
G1 X108.518 Y179.93 F152
G1 X108.507 Y179.944 F152
G1 X108.474 Y179.988 F152
G1 X108.45 Y180.019 F152
G1 X108.43 Y180.045 F152
G1 X108.392 Y180.093 F152
G1 X108.386 Y180.102 F152
G1 X108.342 Y180.16 F152
G1 X108.335 Y180.169 F152
G1 X108.298 Y180.217 F152
G1 X108.254 Y180.274 F152
G1 X108.22 Y180.324 F152
G1 X108.216 Y180.331 F152
G1 X108.178 Y180.389 F152
G1 X108.163 Y180.413 F152
G1 X108.142 Y180.446 F152
G1 X108.104 Y180.503 F152
G1 X108.067 Y180.561 F152
G1 X108.03 Y180.618 F152
G1 X107.993 Y180.675 F152
G1 X107.991 Y180.678 F152
G1 X107.958 Y180.732 F152
G1 X107.894 Y180.847 F152
G1 X107.877 Y180.878 F152
G1 X107.862 Y180.904 F152
G1 X107.831 Y180.961 F152
G1 X107.819 Y180.986 F152
G1 X107.802 Y181.019 F152
G1 X107.774 Y181.076 F152
G1 X107.762 Y181.101 F152
G1 X107.746 Y181.133 F152
G1 X107.718 Y181.191 F152
G1 X107.705 Y181.222 F152
G1 X107.693 Y181.248 F152
G1 X107.668 Y181.305 F152
G1 X107.648 Y181.353 F152
G1 X107.643 Y181.362 F152
G1 X107.619 Y181.42 F152
G1 X107.597 Y181.477 F152
G1 X107.59 Y181.495 F152
G1 X107.575 Y181.534 F152
G1 X107.554 Y181.592 F152
G1 X107.533 Y181.648 F152
G1 X107.532 Y181.649 F152
G1 X107.513 Y181.706 F152
G1 X107.495 Y181.763 F152
G1 X107.477 Y181.821 F152
G1 X107.476 Y181.826 F152
G1 X107.459 Y181.878 F152
G1 X107.442 Y181.935 F152
G1 X107.426 Y181.992 F152
G1 X107.418 Y182.026 F152
G1 X107.412 Y182.05 F152
G1 X107.398 Y182.107 F152
G1 X107.383 Y182.164 F152
G1 X107.37 Y182.222 F152
G1 X107.361 Y182.267 F152
G1 X107.358 Y182.279 F152
G1 X107.347 Y182.336 F152
G1 X107.336 Y182.393 F152
G1 X107.324 Y182.451 F152
G1 X107.307 Y182.565 F152
G1 X107.304 Y182.589 F152
G1 X107.298 Y182.623 F152
G1 X107.282 Y182.737 F152
G1 X107.256 Y183.023 F152
G1 X107.253 Y183.081 F152
G1 X107.251 Y183.138 F152
G1 X107.248 Y183.195 F152
G1 X107.247 Y183.251 F152
G1 X107.246 Y183.253 F152
G1 X107.244 Y183.31 F152
G1 X107.243 Y183.367 F152
G1 X107.245 Y183.482 F152
G1 Y183.539 F152
G1 X107.246 Y183.596 F152
G1 X107.247 Y183.647 F152
G1 Y183.654 F152
G1 X107.249 Y183.711 F152
G1 X107.256 Y183.825 F152
G1 X107.259 Y183.883 F152
G1 X107.263 Y183.94 F152
G1 X107.267 Y183.997 F152
G1 X107.273 Y184.055 F152
G1 X107.279 Y184.112 F152
G1 X107.284 Y184.169 F152
G1 X107.297 Y184.284 F152
G1 X107.304 Y184.338 F152
G1 Y184.341 F152
G1 X107.32 Y184.455 F152
G1 X107.329 Y184.513 F152
G1 X107.345 Y184.627 F152
G1 X107.356 Y184.685 F152
G1 X107.361 Y184.712 F152
G1 X107.367 Y184.742 F152
G1 X107.376 Y184.799 F152
G1 X107.409 Y184.971 F152
G1 X107.418 Y185.012 F152
G1 X107.46 Y185.2 F152
G1 X107.486 Y185.315 F152
G1 X107.502 Y185.372 F152
G1 X107.516 Y185.429 F152
G1 X107.531 Y185.486 F152
G1 X107.533 Y185.493 F152
G1 X107.546 Y185.544 F152
G1 X107.561 Y185.601 F152
G1 X107.578 Y185.658 F152
G1 X107.59 Y185.701 F152
G1 X107.594 Y185.716 F152
G1 X107.645 Y185.887 F152
G1 X107.648 Y185.895 F152
G1 X107.663 Y185.945 F152
G1 X107.7 Y186.059 F152
G1 X107.705 Y186.073 F152
G1 X107.757 Y186.231 F152
G1 X107.762 Y186.245 F152
G1 X107.777 Y186.288 F152
G1 X107.799 Y186.346 F152
G1 X107.819 Y186.402 F152
G1 Y186.403 F152
G1 X107.84 Y186.46 F152
G1 X107.861 Y186.517 F152
G1 X107.877 Y186.558 F152
G1 X107.883 Y186.575 F152
G1 X107.93 Y186.689 F152
G1 X107.934 Y186.7 F152
G1 X107.952 Y186.747 F152
G1 X107.975 Y186.804 F152
G1 X107.991 Y186.842 F152
G1 X107.998 Y186.861 F152
G1 X108.023 Y186.918 F152
G1 X108.049 Y186.974 F152
G1 Y186.976 F152
G1 X108.125 Y187.148 F152
G1 X108.152 Y187.205 F152
G1 X108.163 Y187.227 F152
G1 X108.179 Y187.262 F152
G1 X108.262 Y187.434 F152
G1 X108.278 Y187.463 F152
G1 X108.292 Y187.491 F152
G1 X108.322 Y187.548 F152
G1 X108.335 Y187.574 F152
G1 X108.351 Y187.606 F152
G1 X108.381 Y187.663 F152
G1 X108.413 Y187.72 F152
G1 X108.444 Y187.778 F152
G1 X108.45 Y187.787 F152
G1 X108.476 Y187.835 F152
G1 X108.507 Y187.889 F152
G1 X108.509 Y187.892 F152
G1 X108.542 Y187.949 F152
G1 X108.576 Y188.007 F152
G1 X108.611 Y188.064 F152
G1 X108.621 Y188.082 F152
G1 X108.645 Y188.121 F152
G1 X108.679 Y188.176 F152
G1 X108.68 Y188.179 F152
G1 X108.717 Y188.236 F152
G1 X108.736 Y188.264 F152
G1 X108.754 Y188.293 F152
G1 X108.829 Y188.408 F152
G1 X108.851 Y188.438 F152
G1 X108.868 Y188.465 F152
G1 X108.908 Y188.521 F152
G1 Y188.522 F152
G1 X108.965 Y188.604 F152
G1 X108.989 Y188.637 F152
G1 X109.022 Y188.681 F152
G1 X109.033 Y188.694 F152
G1 X109.076 Y188.751 F152
G1 X109.08 Y188.757 F152
G1 X109.119 Y188.809 F152
G1 X109.137 Y188.833 F152
G1 X109.162 Y188.866 F152
G1 X109.205 Y188.923 F152
G1 X109.252 Y188.984 F152
G1 X109.295 Y189.038 F152
G1 X109.309 Y189.054 F152
G1 X109.343 Y189.095 F152
G1 X109.389 Y189.152 F152
G1 X109.423 Y189.193 F152
G1 X109.481 Y189.262 F152
G1 X109.484 Y189.267 F152
G1 X109.532 Y189.324 F152
G1 X109.538 Y189.332 F152
G1 X109.581 Y189.381 F152
G1 X109.595 Y189.397 F152
G1 X109.631 Y189.439 F152
G1 X109.68 Y189.496 F152
G1 X109.71 Y189.53 F152
G1 X109.73 Y189.553 F152
G1 X109.767 Y189.595 F152
G1 X109.781 Y189.61 F152
G1 X109.831 Y189.668 F152
G1 X109.933 Y189.782 F152
G1 X109.939 Y189.789 F152
G1 X109.984 Y189.84 F152
G1 X109.996 Y189.854 F152
G1 X110.035 Y189.897 F152
G1 X110.054 Y189.917 F152
G1 X110.086 Y189.954 F152
G1 X110.111 Y189.982 F152
G1 X110.138 Y190.011 F152
G1 X110.168 Y190.045 F152
G1 X110.19 Y190.069 F152
G1 X110.225 Y190.108 F152
G1 X110.283 Y190.172 F152
G1 X110.293 Y190.183 F152
G1 X110.34 Y190.234 F152
G1 X110.345 Y190.241 F152
G1 X110.397 Y190.298 F152
G1 X110.451 Y190.355 F152
G1 X110.455 Y190.359 F152
G1 X110.505 Y190.412 F152
G1 X110.512 Y190.42 F152
G1 X110.558 Y190.47 F152
G1 X110.611 Y190.527 F152
G1 X110.626 Y190.543 F152
G1 X110.665 Y190.584 F152
G1 X110.684 Y190.604 F152
G1 X110.719 Y190.641 F152
G1 X110.741 Y190.665 F152
G1 X110.774 Y190.699 F152
G1 X110.798 Y190.724 F152
G1 X110.83 Y190.756 F152
G1 X110.885 Y190.813 F152
G1 X110.913 Y190.841 F152
G1 X110.943 Y190.871 F152
G1 X111.058 Y190.985 F152
G1 X111.085 Y191.011 F152
G1 X111.118 Y191.042 F152
G1 X111.142 Y191.066 F152
G1 X111.179 Y191.1 F152
G1 X111.199 Y191.119 F152
G1 X111.24 Y191.157 F152
G1 X111.257 Y191.173 F152
G1 X111.314 Y191.227 F152
G1 X111.361 Y191.272 F152
G1 X111.371 Y191.28 F152
G1 X111.426 Y191.329 F152
G1 X111.428 Y191.332 F152
G1 X111.486 Y191.382 F152
G1 X111.491 Y191.386 F152
G1 X111.543 Y191.432 F152
G1 X111.556 Y191.443 F152
G1 X111.622 Y191.501 F152
G1 X111.658 Y191.533 F152
G1 X111.687 Y191.558 F152
G1 X111.715 Y191.58 F152
G1 X111.772 Y191.627 F152
G1 X111.829 Y191.672 F152
G1 Y191.673 F152
G1 X111.887 Y191.72 F152
G1 X111.899 Y191.73 F152
G1 X111.969 Y191.787 F152
G1 X112.001 Y191.813 F152
G1 X112.042 Y191.844 F152
G1 X112.059 Y191.857 F152
G1 X112.116 Y191.9 F152
G1 X112.119 Y191.902 F152
G1 X112.195 Y191.959 F152
G1 X112.23 Y191.986 F152
G1 X112.272 Y192.016 F152
G1 X112.288 Y192.029 F152
G1 X112.345 Y192.072 F152
G1 X112.348 Y192.073 F152
G1 X112.374 Y192.092 F152
G1 X112.387 Y192.102 F152
G1 X112.392 Y192.105 F152
G1 X112.402 Y192.113 F152
G1 X112.408 Y192.116 F152
G1 X112.413 Y192.12 F152
G1 X112.42 Y192.124 F152
; MOVEMENT_LEAD_OUT
G1 X112.425 Y192.128 Z-6.011 F152
G1 X112.426 Y192.129 Z-6.004 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X114.192 Y189.524 F152
G1 Z0.947 F152
; MOVEMENT_PLUNGE
G1 Z-5.966 F51
; MOVEMENT_LEAD_IN
G1 X114.189 Y189.522 Z-5.985 F152
G1 X114.18 Y189.516 Z-6.001 F152
G1 X114.166 Y189.507 Z-6.012 F152
G1 X114.15 Y189.496 Z-6.016 F152
; MOVEMENT_CUTTING
G1 X114.064 Y189.439 F152
G1 Y189.438 F152
G1 X113.949 Y189.352 F152
G1 X113.912 Y189.324 F152
G1 X113.892 Y189.309 F152
G1 X113.835 Y189.267 F152
G1 X113.834 Y189.266 F152
G1 X113.777 Y189.219 F152
G1 X113.765 Y189.21 F152
G1 X113.72 Y189.172 F152
G1 X113.605 Y189.075 F152
G1 X113.561 Y189.038 F152
G1 X113.499 Y188.98 F152
G1 X113.491 Y188.973 F152
G1 X113.437 Y188.923 F152
G1 X113.433 Y188.92 F152
G1 X113.319 Y188.812 F152
G1 X113.314 Y188.809 F152
G1 X113.262 Y188.754 F152
G1 X113.259 Y188.751 F152
G1 X113.092 Y188.579 F152
G1 X113.09 Y188.577 F152
G1 X113.04 Y188.522 F152
G1 X113.032 Y188.512 F152
G1 X112.99 Y188.465 F152
G1 X112.975 Y188.447 F152
G1 X112.94 Y188.408 F152
G1 X112.918 Y188.382 F152
G1 X112.89 Y188.35 F152
G1 X112.861 Y188.316 F152
G1 X112.84 Y188.293 F152
G1 X112.803 Y188.247 F152
G1 X112.794 Y188.236 F152
G1 X112.749 Y188.179 F152
G1 X112.746 Y188.175 F152
G1 X112.704 Y188.121 F152
G1 X112.689 Y188.102 F152
G1 X112.658 Y188.064 F152
G1 X112.631 Y188.031 F152
G1 X112.614 Y188.007 F152
G1 X112.574 Y187.952 F152
G1 X112.572 Y187.949 F152
G1 X112.53 Y187.892 F152
G1 X112.517 Y187.873 F152
G1 X112.489 Y187.835 F152
G1 X112.407 Y187.72 F152
G1 X112.402 Y187.713 F152
G1 X112.37 Y187.663 F152
G1 X112.345 Y187.625 F152
G1 X112.332 Y187.606 F152
G1 X112.295 Y187.548 F152
G1 X112.288 Y187.538 F152
G1 X112.257 Y187.491 F152
G1 X112.23 Y187.451 F152
G1 X112.22 Y187.434 F152
G1 X112.186 Y187.377 F152
G1 X112.173 Y187.356 F152
G1 X112.152 Y187.319 F152
G1 X112.118 Y187.262 F152
G1 X112.116 Y187.259 F152
G1 X112.084 Y187.205 F152
G1 X112.059 Y187.163 F152
G1 X112.05 Y187.148 F152
G1 X112.017 Y187.09 F152
G1 X112.001 Y187.061 F152
G1 X111.987 Y187.033 F152
G1 X111.957 Y186.976 F152
G1 X111.944 Y186.952 F152
G1 X111.926 Y186.918 F152
G1 X111.896 Y186.861 F152
G1 X111.887 Y186.845 F152
G1 X111.865 Y186.804 F152
G1 X111.837 Y186.747 F152
G1 X111.829 Y186.731 F152
G1 X111.783 Y186.632 F152
G1 X111.772 Y186.611 F152
G1 X111.755 Y186.575 F152
G1 X111.728 Y186.517 F152
G1 X111.715 Y186.49 F152
G1 X111.701 Y186.46 F152
G1 X111.677 Y186.403 F152
G1 X111.658 Y186.357 F152
G1 X111.653 Y186.346 F152
G1 X111.605 Y186.231 F152
G1 X111.6 Y186.221 F152
G1 X111.581 Y186.174 F152
G1 X111.556 Y186.117 F152
G1 X111.543 Y186.08 F152
G1 X111.536 Y186.059 F152
G1 X111.514 Y186.002 F152
G1 X111.494 Y185.945 F152
G1 X111.486 Y185.924 F152
G1 X111.472 Y185.887 F152
G1 X111.431 Y185.773 F152
G1 X111.428 Y185.766 F152
G1 X111.413 Y185.716 F152
G1 X111.394 Y185.658 F152
G1 X111.371 Y185.584 F152
G1 X111.323 Y185.429 F152
G1 X111.314 Y185.395 F152
G1 X111.308 Y185.372 F152
G1 X111.293 Y185.315 F152
G1 X111.263 Y185.2 F152
G1 X111.257 Y185.179 F152
G1 X111.233 Y185.086 F152
G1 X111.221 Y185.028 F152
G1 X111.209 Y184.971 F152
G1 X111.199 Y184.928 F152
G1 X111.197 Y184.914 F152
G1 X111.184 Y184.856 F152
G1 X111.161 Y184.742 F152
G1 X111.152 Y184.685 F152
G1 X111.142 Y184.627 F152
G1 X111.124 Y184.513 F152
G1 X111.114 Y184.455 F152
G1 X111.107 Y184.398 F152
G1 X111.088 Y184.226 F152
G1 X111.085 Y184.199 F152
G1 X111.082 Y184.169 F152
G1 X111.076 Y184.112 F152
G1 X111.065 Y183.94 F152
G1 X111.062 Y183.883 F152
G1 X111.059 Y183.825 F152
G1 X111.056 Y183.768 F152
G1 Y183.539 F152
G1 X111.057 Y183.482 F152
G1 X111.059 Y183.424 F152
G1 X111.066 Y183.31 F152
G1 X111.069 Y183.253 F152
G1 X111.072 Y183.195 F152
G1 X111.078 Y183.138 F152
G1 X111.084 Y183.081 F152
G1 X111.085 Y183.072 F152
G1 X111.091 Y183.023 F152
G1 X111.098 Y182.966 F152
G1 X111.104 Y182.909 F152
G1 X111.113 Y182.852 F152
G1 X111.135 Y182.737 F152
G1 X111.142 Y182.695 F152
G1 X111.146 Y182.68 F152
G1 X111.156 Y182.623 F152
G1 X111.169 Y182.565 F152
G1 X111.184 Y182.508 F152
G1 X111.198 Y182.451 F152
G1 X111.199 Y182.446 F152
G1 X111.214 Y182.393 F152
G1 X111.229 Y182.336 F152
G1 X111.248 Y182.279 F152
G1 X111.257 Y182.252 F152
G1 X111.267 Y182.222 F152
G1 X111.286 Y182.164 F152
G1 X111.306 Y182.107 F152
G1 X111.314 Y182.085 F152
G1 X111.329 Y182.05 F152
G1 X111.353 Y181.992 F152
G1 X111.371 Y181.95 F152
G1 X111.377 Y181.935 F152
G1 X111.402 Y181.878 F152
G1 X111.428 Y181.826 F152
G1 X111.431 Y181.821 F152
G1 X111.462 Y181.763 F152
G1 X111.486 Y181.716 F152
G1 X111.491 Y181.706 F152
G1 X111.523 Y181.649 F152
G1 X111.543 Y181.617 F152
G1 X111.559 Y181.592 F152
G1 X111.596 Y181.534 F152
G1 X111.6 Y181.527 F152
G1 X111.632 Y181.477 F152
G1 X111.658 Y181.445 F152
G1 X111.677 Y181.42 F152
G1 X111.715 Y181.37 F152
G1 X111.766 Y181.305 F152
G1 X111.772 Y181.299 F152
G1 X111.82 Y181.248 F152
G1 X111.872 Y181.191 F152
G1 X111.887 Y181.175 F152
G1 X111.931 Y181.133 F152
G1 X111.944 Y181.123 F152
G1 X111.996 Y181.076 F152
G1 X112.064 Y181.019 F152
G1 X112.116 Y180.981 F152
G1 X112.143 Y180.961 F152
G1 X112.173 Y180.94 F152
G1 X112.23 Y180.902 F152
G1 X112.288 Y180.869 F152
G1 X112.326 Y180.847 F152
G1 X112.345 Y180.836 F152
G1 X112.402 Y180.808 F152
G1 X112.442 Y180.79 F152
G1 X112.517 Y180.756 F152
G1 X112.574 Y180.734 F152
G1 X112.579 Y180.732 F152
G1 X112.631 Y180.714 F152
G1 X112.689 Y180.696 F152
G1 X112.746 Y180.68 F152
G1 X112.763 Y180.675 F152
G1 X112.803 Y180.666 F152
G1 X112.861 Y180.653 F152
G1 X112.918 Y180.641 F152
G1 X112.975 Y180.633 F152
G1 X113.032 Y180.626 F152
G1 X113.087 Y180.618 F152
G1 X113.09 F152
G1 X113.147 Y180.614 F152
G1 X113.204 Y180.612 F152
G1 X113.262 Y180.61 F152
G1 X113.319 Y180.607 F152
G1 X113.376 Y180.61 F152
G1 X113.433 Y180.613 F152
G1 X113.491 Y180.616 F152
G1 X113.538 Y180.618 F152
G1 X113.548 Y180.62 F152
G1 X113.605 Y180.627 F152
G1 X113.777 Y180.651 F152
G1 X113.834 Y180.663 F152
G1 X113.889 Y180.675 F152
G1 X113.892 Y180.676 F152
G1 X114.006 Y180.701 F152
G1 X114.121 Y180.735 F152
G1 X114.178 Y180.753 F152
G1 X114.235 Y180.77 F152
G1 X114.292 Y180.79 F152
G1 X114.293 Y180.791 F152
G1 X114.443 Y180.847 F152
G1 X114.465 Y180.856 F152
G1 X114.522 Y180.879 F152
G1 X114.577 Y180.904 F152
G1 X114.636 Y180.932 F152
G1 X114.694 Y180.958 F152
G1 X114.702 Y180.961 F152
G1 X114.751 Y180.984 F152
G1 X114.808 Y181.015 F152
G1 X114.815 Y181.019 F152
G1 X114.866 Y181.046 F152
G1 X114.922 Y181.076 F152
G1 X114.923 Y181.077 F152
G1 X115.026 Y181.133 F152
G1 X115.037 Y181.141 F152
G1 X115.095 Y181.176 F152
G1 X115.117 Y181.191 F152
G1 X115.152 Y181.212 F152
G1 X115.267 Y181.284 F152
G1 X115.297 Y181.305 F152
G1 X115.324 Y181.324 F152
G1 X115.378 Y181.362 F152
G1 X115.381 Y181.364 F152
G1 X115.438 Y181.405 F152
G1 X115.459 Y181.42 F152
G1 X115.496 Y181.446 F152
G1 X115.539 Y181.477 F152
G1 X115.553 Y181.489 F152
G1 X115.668 Y181.58 F152
G1 X115.683 Y181.592 F152
G1 X115.725 Y181.626 F152
G1 X115.754 Y181.649 F152
G1 X115.782 Y181.671 F152
G1 X115.822 Y181.706 F152
G1 X115.839 Y181.722 F152
G1 X115.886 Y181.763 F152
G1 X115.897 Y181.772 F152
G1 X115.95 Y181.821 F152
G1 X115.954 Y181.823 F152
G1 X116.011 Y181.874 F152
G1 X116.016 Y181.878 F152
G1 X116.069 Y181.929 F152
G1 X116.075 Y181.935 F152
G1 X116.126 Y181.985 F152
G1 X116.133 Y181.992 F152
G1 X116.183 Y182.042 F152
G1 X116.191 Y182.05 F152
G1 X116.24 Y182.098 F152
G1 X116.249 Y182.107 F152
G1 X116.298 Y182.157 F152
G1 X116.304 Y182.164 F152
G1 X116.355 Y182.22 F152
G1 X116.357 Y182.222 F152
G1 X116.41 Y182.279 F152
G1 X116.412 Y182.282 F152
G1 X116.462 Y182.336 F152
G1 X116.513 Y182.393 F152
G1 X116.527 Y182.409 F152
G1 X116.584 Y182.478 F152
G1 X116.609 Y182.508 F152
G1 X116.641 Y182.546 F152
G1 X116.658 Y182.565 F152
G1 X116.699 Y182.614 F152
G1 X116.705 Y182.623 F152
G1 X116.751 Y182.68 F152
G1 X116.756 Y182.686 F152
G1 X116.794 Y182.737 F152
G1 X116.837 Y182.794 F152
G1 X116.871 Y182.837 F152
G1 X116.924 Y182.909 F152
G1 X116.928 Y182.913 F152
G1 X116.985 Y182.994 F152
G1 X117.005 Y183.023 F152
G1 X117.042 Y183.077 F152
G1 X117.044 Y183.081 F152
G1 X117.084 Y183.138 F152
G1 X117.1 Y183.16 F152
G1 X117.123 Y183.195 F152
G1 X117.157 Y183.245 F152
G1 X117.197 Y183.31 F152
G1 X117.214 Y183.338 F152
G1 X117.232 Y183.367 F152
G1 X117.268 Y183.424 F152
G1 X117.272 Y183.43 F152
G1 X117.329 Y183.522 F152
G1 X117.34 Y183.539 F152
G1 X117.372 Y183.596 F152
G1 X117.386 Y183.621 F152
G1 X117.404 Y183.654 F152
G1 X117.436 Y183.711 F152
G1 X117.443 Y183.723 F152
G1 X117.468 Y183.768 F152
G1 X117.501 Y183.825 F152
G1 X117.531 Y183.883 F152
G1 X117.558 Y183.935 F152
G1 X117.56 Y183.94 F152
G1 X117.588 Y183.997 F152
G1 X117.615 Y184.05 F152
G1 X117.618 Y184.055 F152
G1 X117.675 Y184.169 F152
G1 X117.702 Y184.226 F152
G1 X117.727 Y184.284 F152
G1 X117.73 Y184.289 F152
G1 X117.753 Y184.341 F152
G1 X117.779 Y184.398 F152
G1 X117.787 Y184.417 F152
G1 X117.804 Y184.455 F152
G1 X117.83 Y184.513 F152
G1 X117.844 Y184.548 F152
G1 X117.852 Y184.57 F152
G1 X117.876 Y184.627 F152
G1 X117.898 Y184.685 F152
G1 X117.902 Y184.694 F152
G1 X117.943 Y184.799 F152
G1 X117.959 Y184.838 F152
G1 X117.965 Y184.856 F152
G1 X118.005 Y184.971 F152
G1 X118.016 Y185.004 F152
G1 X118.024 Y185.028 F152
G1 X118.074 Y185.171 F152
G1 X118.083 Y185.2 F152
G1 X118.117 Y185.315 F152
G1 X118.131 Y185.364 F152
G1 X118.133 Y185.372 F152
G1 X118.15 Y185.429 F152
G1 X118.166 Y185.486 F152
G1 X118.183 Y185.544 F152
G1 X118.188 Y185.566 F152
G1 X118.196 Y185.601 F152
G1 X118.223 Y185.716 F152
G1 X118.237 Y185.773 F152
G1 X118.245 Y185.806 F152
G1 X118.251 Y185.83 F152
G1 X118.264 Y185.887 F152
G1 X118.296 Y186.059 F152
G1 X118.303 Y186.091 F152
G1 X118.307 Y186.117 F152
G1 X118.318 Y186.174 F152
G1 X118.328 Y186.231 F152
G1 X118.336 Y186.288 F152
G1 X118.343 Y186.346 F152
G1 X118.36 Y186.466 F152
G1 X118.366 Y186.517 F152
G1 X118.373 Y186.575 F152
G1 X118.378 Y186.632 F152
G1 X118.387 Y186.747 F152
G1 X118.392 Y186.804 F152
G1 X118.397 Y186.861 F152
G1 X118.404 Y187.09 F152
G1 X118.406 Y187.205 F152
G1 X118.405 Y187.262 F152
G1 X118.398 Y187.491 F152
G1 X118.393 Y187.548 F152
G1 X118.388 Y187.606 F152
G1 X118.383 Y187.663 F152
G1 X118.373 Y187.778 F152
G1 X118.365 Y187.835 F152
G1 X118.36 Y187.87 F152
G1 X118.356 Y187.892 F152
G1 X118.33 Y188.064 F152
G1 X118.318 Y188.121 F152
G1 X118.305 Y188.179 F152
G1 X118.303 Y188.192 F152
G1 X118.293 Y188.236 F152
G1 X118.28 Y188.293 F152
G1 X118.267 Y188.35 F152
G1 X118.25 Y188.408 F152
G1 X118.245 Y188.424 F152
G1 X118.233 Y188.465 F152
G1 X118.199 Y188.579 F152
G1 X118.188 Y188.612 F152
G1 X118.178 Y188.637 F152
G1 X118.135 Y188.751 F152
G1 X118.131 Y188.763 F152
G1 X118.113 Y188.809 F152
G1 X118.088 Y188.866 F152
G1 X118.074 Y188.897 F152
G1 X118.061 Y188.923 F152
G1 X118.034 Y188.98 F152
G1 X118.016 Y189.019 F152
G1 X118.007 Y189.038 F152
G1 X117.974 Y189.095 F152
G1 X117.959 Y189.122 F152
G1 X117.941 Y189.152 F152
G1 X117.909 Y189.21 F152
G1 X117.902 Y189.221 F152
G1 X117.872 Y189.267 F152
G1 X117.792 Y189.381 F152
G1 X117.787 Y189.389 F152
G1 X117.749 Y189.439 F152
G1 X117.73 Y189.461 F152
G1 X117.7 Y189.496 F152
G1 X117.673 Y189.529 F152
G1 X117.652 Y189.553 F152
G1 X117.615 Y189.593 F152
G1 X117.597 Y189.61 F152
G1 X117.558 Y189.649 F152
G1 X117.539 Y189.668 F152
G1 X117.501 Y189.705 F152
G1 X117.478 Y189.725 F152
G1 X117.443 Y189.753 F152
G1 X117.407 Y189.782 F152
G1 X117.386 Y189.799 F152
G1 X117.334 Y189.84 F152
G1 X117.272 Y189.881 F152
G1 X117.246 Y189.897 F152
G1 X117.214 Y189.918 F152
G1 X117.157 Y189.952 F152
G1 X117.042 Y190.011 F152
G1 X116.985 Y190.037 F152
G1 X116.928 Y190.06 F152
G1 X116.906 Y190.069 F152
G1 X116.871 Y190.083 F152
G1 X116.813 Y190.103 F152
G1 X116.756 Y190.119 F152
G1 X116.732 Y190.126 F152
G1 X116.699 Y190.135 F152
G1 X116.641 Y190.15 F152
G1 X116.527 Y190.172 F152
G1 X116.47 Y190.181 F152
G1 X116.462 Y190.183 F152
G1 X116.412 Y190.188 F152
G1 X116.355 Y190.193 F152
G1 X116.24 Y190.202 F152
G1 X116.183 Y190.201 F152
G1 X116.069 F152
G1 X116.011 Y190.198 F152
G1 X115.897 Y190.188 F152
G1 X115.842 Y190.183 F152
G1 X115.839 Y190.182 F152
G1 X115.782 Y190.175 F152
G1 X115.725 Y190.165 F152
G1 X115.668 Y190.155 F152
G1 X115.61 Y190.145 F152
G1 X115.553 Y190.133 F152
G1 X115.525 Y190.126 F152
G1 X115.496 Y190.118 F152
G1 X115.438 Y190.104 F152
G1 X115.324 Y190.073 F152
G1 X115.31 Y190.069 F152
G1 X115.267 Y190.053 F152
G1 X115.152 Y190.014 F152
G1 X115.142 Y190.011 F152
G1 X115.095 Y189.995 F152
G1 X115.037 Y189.972 F152
G1 X114.994 Y189.954 F152
G1 X114.98 Y189.948 F152
G1 X114.866 Y189.9 F152
G1 X114.858 Y189.897 F152
G1 X114.808 Y189.874 F152
G1 X114.579 Y189.759 F152
G1 X114.522 Y189.726 F152
G1 X114.52 Y189.725 F152
G1 X114.465 Y189.693 F152
G1 X114.422 Y189.668 F152
G1 X114.407 Y189.659 F152
G1 X114.35 Y189.626 F152
G1 X114.323 Y189.61 F152
G1 X114.293 Y189.59 F152
G1 X114.237 Y189.553 F152
G1 X114.235 Y189.552 F152
G1 X114.178 Y189.514 F152
G1 X114.15 Y189.496 F152
; MOVEMENT_LEAD_OUT
G1 X114.134 Y189.486 Z-6.012 F152
G1 X114.121 Y189.477 Z-6.001 F152
G1 X114.112 Y189.471 Z-5.985 F152
G1 X114.108 Y189.469 Z-5.966 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X117.342 Y178.516 F152
G1 Z0.947 F152
; MOVEMENT_PLUNGE
G1 Z-5.978 F51
; MOVEMENT_LEAD_IN
G1 X117.34 Y178.515 Z-5.991 F152
G1 X117.335 Y178.512 Z-6.004 F152
G1 X117.327 Y178.508 Z-6.015 F152
; MOVEMENT_CUTTING
G1 X117.325 Y178.507 Z-6.012 F152
G1 X117.323 Y178.506 F152
G1 X117.322 Y178.505 Z-6.014 F152
G1 X117.315 Y178.5 Z-6.01 F152
G1 X117.226 Y178.441 Z-5.992 F152
G1 X117.214 Y178.433 F152
G1 X117.157 Y178.396 Z-5.989 F152
G1 X117.137 Y178.384 Z-5.991 F152
G1 X117.1 Y178.361 Z-5.989 F152
G1 X117.045 Y178.327 Z-5.988 F152
G1 X117.042 Y178.326 Z-5.982 F152
G1 X116.985 Y178.291 Z-5.975 F152
G1 X116.948 Y178.269 Z-5.972 F152
G1 X116.928 Y178.259 Z-5.97 F152
G1 X116.871 Y178.226 Z-5.977 F152
G1 X116.846 Y178.212 Z-5.976 F152
G1 X116.813 Y178.193 Z-5.978 F152
G1 X116.756 Y178.161 Z-5.979 F152
G1 X116.745 Y178.155 Z-5.983 F152
G1 X116.699 Y178.13 Z-5.996 F152
G1 X116.641 Y178.1 Z-6.002 F152
G1 X116.527 Y178.043 Z-6.001 F152
G1 X116.522 Y178.04 Z-6.005 F152
G1 X116.47 Y178.015 Z-6.014 F152
G1 X116.466 Y178.013 Z-6.015 F152
; MOVEMENT_LEAD_OUT
G1 X116.454 Y178.007 Z-6.018 F152
G1 X116.442 Y178.001 Z-6.015 F152
G1 X116.431 Y177.996 Z-6.008 F152
G1 X116.425 Y177.993 Z-5.996 F152
G1 X116.422 Y177.992 Z-5.983 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X119.162 Y162.806 F152
G1 Z0.98 F152
; MOVEMENT_PLUNGE
G1 Z-4.572 F51
; MOVEMENT_LEAD_IN
G1 Z-4.578 F152
; MOVEMENT_CUTTING
G1 X119.165 Y162.804 Z-4.604 F152
G1 X119.169 Y162.801 Z-4.648 F152
G1 X119.176 Y162.796 Z-4.717 F152
G1 X119.191 Y162.784 Z-4.859 F152
G1 X119.198 Y162.778 Z-4.929 F152
G1 X119.212 Y162.766 Z-5.07 F152
G1 X119.219 Y162.76 Z-5.134 F152
G1 X119.226 Y162.756 Z-5.197 F152
G1 X119.234 Y162.751 Z-5.26 F152
G1 X119.238 Y162.747 Z-5.299 F152
G1 X119.248 Y162.739 Z-5.385 F152
G1 X119.255 Y162.734 Z-5.448 F152
G1 X119.262 Y162.727 Z-5.51 F152
G1 X119.269 Y162.722 Z-5.573 F152
G1 X119.277 Y162.716 Z-5.635 F152
G1 X119.285 Y162.709 Z-5.711 F152
G1 X119.294 Y162.701 Z-5.786 F152
G1 X119.305 Y162.693 Z-5.874 F152
G1 X119.311 Y162.69 Z-5.916 F152
G1 X119.32 Y162.683 Z-5.986 F152
G1 X119.321 Y162.681 Z-5.999 F152
G1 X119.323 Y162.679 Z-6.013 F152
; MOVEMENT_LEAD_OUT
G1 X119.336 Y162.67 Z-6.011 F152
G1 X119.348 Y162.661 Z-6.004 F152
G1 X119.357 Y162.654 Z-5.993 F152
G1 X119.363 Y162.649 Z-5.979 F152
G1 X119.366 Y162.648 Z-5.963 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X114.895 Y160.057 F152
G1 Z0.943 F152
; MOVEMENT_PLUNGE
G1 Z-5.961 F51
; MOVEMENT_LEAD_IN
G1 X114.893 Y160.059 Z-5.977 F152
G1 X114.887 Y160.065 Z-5.992 F152
G1 X114.878 Y160.073 Z-6.003 F152
G1 X114.868 Y160.084 Z-6.009 F152
G1 X114.856 Y160.096 Z-6.01 F152
; MOVEMENT_CUTTING
G1 X114.854 Y160.098 Z-6.003 F152
G1 X114.851 Y160.102 Z-5.996 F152
G1 X114.84 Y160.112 Z-5.953 F152
G1 X114.824 Y160.13 Z-5.89 F152
G1 X114.808 Y160.146 Z-5.821 F152
G1 X114.8 Y160.155 Z-5.789 F152
G1 X114.786 Y160.17 Z-5.725 F152
G1 X114.759 Y160.198 Z-5.613 F152
G1 X114.751 Y160.207 Z-5.581 F152
G1 X114.732 Y160.227 Z-5.501 F152
G1 X114.722 Y160.237 Z-5.458 F152
G1 X114.704 Y160.255 Z-5.382 F152
G1 X114.694 Y160.267 Z-5.338 F152
G1 X114.678 Y160.284 Z-5.27 F152
G1 X114.664 Y160.298 Z-5.214 F152
G1 X114.651 Y160.313 Z-5.152 F152
G1 X114.636 Y160.329 Z-5.087 F152
G1 X114.625 Y160.341 Z-5.033 F152
G1 X114.611 Y160.356 Z-4.971 F152
G1 X114.599 Y160.37 Z-4.915 F152
G1 X114.579 Y160.391 Z-4.825 F152
G1 X114.572 Y160.399 Z-4.79 F152
G1 X114.559 Y160.413 Z-4.735 F152
G1 X114.545 Y160.427 Z-4.664 F152
G1 X114.532 Y160.442 Z-4.601 F152
G1 X114.517 Y160.456 Z-4.531 F152
G1 X114.504 Y160.47 Z-4.463 F152
G1 X114.491 Y160.485 Z-4.4 F152
G1 X114.465 Y160.513 Z-4.257 F152
G1 X114.452 Y160.528 Z-4.193 F152
G1 X114.438 Y160.542 Z-4.114 F152
G1 X114.411 Y160.57 Z-3.971 F152
G1 X114.397 Y160.585 Z-3.892 F152
G1 X114.383 Y160.599 Z-3.821 F152
G1 X114.37 Y160.613 Z-3.744 F152
G1 X114.356 Y160.628 Z-3.661 F152
G1 X114.344 Y160.642 Z-3.587 F152
G1 X114.303 Y160.685 Z-3.339 F152
G1 X114.284 Y160.705 Z-3.215 F152
G1 X114.276 Y160.714 Z-3.166 F152
G1 X114.261 Y160.728 Z-3.076 F152
G1 X114.249 Y160.742 Z-2.989 F152
G1 X114.242 Y160.75 Z-2.938 F152
G1 X114.235 Y160.758 Z-2.893 F152
G1 X114.223 Y160.771 Z-2.802 F152
G1 X114.215 Y160.779 Z-2.747 F152
G1 X114.207 Y160.787 Z-2.684 F152
G1 X114.195 Y160.8 Z-2.6 F152
G1 X114.178 Y160.817 Z-2.477 F152
G1 X114.167 Y160.828 Z-2.398 F152
G1 X114.161 Y160.835 Z-2.348 F152
G1 X114.142 Y160.857 Z-2.185 F152
G1 X114.121 Y160.878 Z-1.998 F152
G1 X114.115 Y160.885 Z-1.944 F152
G1 X114.095 Y160.905 Z-1.772 F152
G1 X114.092 Y160.909 Z-1.749 F152
G1 X114.088 Y160.914 Z-1.701 F152
G1 X114.085 Y160.918 Z-1.672 F152
G1 X114.074 Y160.928 Z-1.56 F152
G1 X114.071 Y160.932 Z-1.522 F152
G1 X114.064 Y160.939 Z-1.448 F152
G1 X114.056 Y160.947 Z-1.372 F152
G1 X114.048 Y160.955 Z-1.288 F152
G1 X114.045 Y160.959 Z-1.25 F152
G1 X114.043 Y160.961 Z-1.23 F152
G1 X114.041 Y160.963 Z-1.216 F152
G1 X114.04 Y160.965 Z-1.206 F152
G1 X114.038 Y160.967 Z-1.196 F152
G1 X114.034 Y160.971 Z-1.181 F152
; MOVEMENT_LEAD_OUT
G1 X114.032 Y160.974 Z-1.164 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X105.618 Y156.277 F152
G1 Z0.946 F152
; MOVEMENT_PLUNGE
G1 Z-5.965 F51
; MOVEMENT_LEAD_IN
G1 X105.615 Y156.28 Z-5.985 F152
G1 X105.609 Y156.289 Z-6.001 F152
G1 X105.599 Y156.303 Z-6.012 F152
G1 X105.587 Y156.318 Z-6.015 F152
G1 X105.575 Y156.334 Z-6.011 F152
; MOVEMENT_CUTTING
G1 Y156.335 Z-6.01 F152
G1 X105.571 Y156.337 Z-5.997 F152
G1 X105.557 Y156.35 Z-5.954 F152
G1 X105.528 Y156.374 Z-5.874 F152
G1 X105.51 Y156.389 Z-5.826 F152
G1 X105.499 Y156.398 Z-5.797 F152
G1 X105.471 Y156.423 Z-5.724 F152
G1 X105.445 Y156.446 Z-5.662 F152
G1 X105.413 Y156.477 Z-5.6 F152
G1 X105.387 Y156.504 Z-5.557 F152
G1 X105.356 Y156.535 Z-5.516 F152
G1 X105.329 Y156.561 Z-5.481 F152
G1 X105.272 Y156.618 Z-5.418 F152
G1 X105.242 Y156.651 Z-5.4 F152
G1 X105.22 Y156.676 Z-5.396 F152
G1 X105.184 Y156.715 Z-5.405 F152
G1 X105.167 Y156.733 Z-5.406 F152
G1 X105.127 Y156.777 Z-5.418 F152
G1 X105.114 Y156.79 Z-5.42 F152
G1 X105.07 Y156.843 Z-5.463 F152
G1 X105.066 Y156.847 Z-5.47 F152
G1 X105.041 Y156.876 Z-5.508 F152
G1 X105.015 Y156.905 Z-5.543 F152
G1 X105.012 Y156.907 Z-5.545 F152
G1 X104.989 Y156.933 Z-5.579 F152
G1 X104.963 Y156.962 Z-5.615 F152
G1 X104.955 Y156.972 Z-5.633 F152
G1 X104.938 Y156.991 Z-5.656 F152
G1 X104.914 Y157.019 Z-5.711 F152
G1 X104.898 Y157.037 Z-5.748 F152
G1 X104.888 Y157.048 Z-5.771 F152
G1 X104.862 Y157.076 Z-5.835 F152
G1 X104.841 Y157.1 Z-5.884 F152
G1 X104.81 Y157.134 Z-5.962 F152
G1 X104.797 Y157.148 Z-5.991 F152
G1 X104.79 Y157.156 Z-6.011 F152
G1 X104.789 Y157.157 Z-6.014 F152
; MOVEMENT_LEAD_OUT
G1 X104.779 Y157.169 Z-6.012 F152
G1 X104.769 Y157.18 Z-6.005 F152
G1 X104.761 Y157.188 Z-5.994 F152
G1 X104.756 Y157.194 Z-5.98 F152
G1 X104.755 Y157.196 Z-5.964 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X99.517 Y156.532 F152
G1 Z0.946 F152
; MOVEMENT_PLUNGE
G1 Z-5.96 F51
; MOVEMENT_LEAD_IN
G1 Y156.529 Z-5.977 F152
G1 X99.516 Y156.521 Z-5.992 F152
G1 X99.515 Y156.509 Z-6.003 F152
G1 X99.513 Y156.493 Z-6.009 F152
G1 X99.511 Y156.477 Z-6.01 F152
; MOVEMENT_CUTTING
G1 X99.51 Y156.475 Z-6.006 F152
G1 X99.504 Y156.446 Z-5.97 F152
G1 X99.492 Y156.389 Z-5.89 F152
G1 X99.481 Y156.332 Z-5.812 F152
G1 X99.47 Y156.275 Z-5.756 F152
G1 X99.46 Y156.217 Z-5.708 F152
G1 X99.456 Y156.196 Z-5.697 F152
G1 X99.449 Y156.16 Z-5.667 F152
G1 X99.44 Y156.103 Z-5.62 F152
G1 X99.431 Y156.045 Z-5.593 F152
G1 X99.415 Y155.931 Z-5.552 F152
G1 X99.406 Y155.874 Z-5.533 F152
G1 X99.398 Y155.816 Z-5.542 F152
G1 X99.391 Y155.759 Z-5.555 F152
G1 X99.385 Y155.702 Z-5.559 F152
G1 X99.378 Y155.645 Z-5.574 F152
G1 X99.372 Y155.587 Z-5.603 F152
G1 X99.367 Y155.53 Z-5.638 F152
G1 X99.361 Y155.473 Z-5.682 F152
G1 X99.355 Y155.415 Z-5.732 F152
G1 X99.35 Y155.358 Z-5.795 F152
G1 X99.346 Y155.301 Z-5.86 F152
G1 X99.341 Y155.253 Z-5.922 F152
G1 Y155.244 Z-5.926 F152
G1 X99.337 Y155.186 Z-6.004 F152
G1 Y155.179 Z-6.012 F152
; MOVEMENT_LEAD_OUT
G1 Y155.172 Z-6.015 F152
G1 X99.336 Y155.165 Z-6.013 F152
G1 Y155.162 Z-6.005 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X97.456 Y152.936 F152
G1 Z0.946 F152
; MOVEMENT_PLUNGE
G1 Z-5.966 F51
; MOVEMENT_LEAD_IN
G1 X97.453 Y152.935 Z-5.983 F152
G1 X97.445 Y152.932 Z-5.998 F152
G1 X97.433 Y152.927 Z-6.009 F152
G1 X97.418 Y152.922 Z-6.015 F152
G1 X97.402 Y152.916 Z-6.016 F152
; MOVEMENT_CUTTING
G1 X97.401 Y152.915 Z-6.015 F152
G1 X97.393 Y152.914 Z-5.999 F152
G1 X97.336 Y152.901 Z-5.927 F152
G1 X97.311 Y152.895 Z-5.901 F152
G1 X97.279 Y152.89 Z-5.866 F152
G1 X97.222 Y152.879 Z-5.822 F152
G1 X97.164 Y152.869 Z-5.77 F152
G1 X97.05 Y152.846 Z-5.698 F152
G1 X97.01 Y152.838 Z-5.674 F152
G1 X96.992 Y152.834 Z-5.662 F152
G1 X96.935 Y152.824 Z-5.624 F152
G1 X96.878 Y152.814 Z-5.611 F152
G1 X96.763 Y152.796 Z-5.585 F152
G1 X96.706 Y152.785 Z-5.588 F152
G1 X96.685 Y152.781 Z-5.594 F152
G1 X96.649 Y152.774 Z-5.591 F152
G1 X96.591 Y152.764 Z-5.594 F152
G1 X96.534 Y152.753 Z-5.604 F152
G1 X96.477 Y152.744 Z-5.625 F152
G1 X96.42 Y152.735 Z-5.649 F152
G1 X96.362 Y152.724 Z-5.689 F152
G1 X96.36 Y152.723 Z-5.694 F152
G1 X96.305 Y152.714 Z-5.729 F152
G1 X96.248 Y152.704 Z-5.761 F152
G1 X96.19 Y152.693 Z-5.801 F152
G1 X96.133 Y152.682 Z-5.848 F152
G1 X96.076 Y152.671 Z-5.917 F152
G1 X96.049 Y152.666 Z-5.952 F152
G1 X96.019 Y152.661 Z-5.985 F152
G1 X96.004 Y152.658 Z-6.002 F152
G1 X95.997 Y152.656 Z-6.015 F152
G1 X95.995 Z-6.014 F152
; MOVEMENT_LEAD_OUT
G1 X95.981 Z-6.003 F152
G1 X95.972 Z-5.987 F152
G1 X95.969 Z-5.97 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X88.169 Y155.423 F152
G1 Z0.946 F152
; MOVEMENT_PLUNGE
G1 Z-6.005 F51
; MOVEMENT_LEAD_IN
G1 X88.17 Y155.426 Z-6.013 F152
G1 X88.173 Y155.432 Z-6.016 F152
G1 X88.177 Y155.439 Z-6.013 F152
; MOVEMENT_CUTTING
G1 X88.178 Y155.44 Z-6.01 F152
G1 Y155.444 Z-5.999 F152
G1 X88.195 Y155.501 Z-5.836 F152
G1 X88.203 Y155.53 Z-5.747 F152
G1 X88.206 Y155.544 Z-5.695 F152
G1 X88.211 Y155.559 Z-5.65 F152
G1 X88.214 Y155.573 Z-5.598 F152
G1 X88.219 Y155.587 Z-5.553 F152
G1 X88.228 Y155.619 Z-5.442 F152
G1 X88.23 Y155.63 Z-5.403 F152
G1 X88.234 Y155.645 Z-5.344 F152
G1 X88.238 Y155.659 Z-5.29 F152
G1 X88.242 Y155.673 Z-5.229 F152
G1 X88.246 Y155.688 Z-5.175 F152
G1 X88.25 Y155.702 Z-5.114 F152
G1 X88.255 Y155.716 Z-5.06 F152
G1 X88.258 Y155.73 Z-5 F152
G1 X88.263 Y155.745 Z-4.942 F152
G1 X88.27 Y155.773 Z-4.802 F152
G1 X88.274 Y155.788 Z-4.738 F152
G1 X88.278 Y155.802 Z-4.668 F152
G1 X88.282 Y155.816 Z-4.603 F152
G1 X88.285 Y155.826 Z-4.557 F152
G1 X88.286 Y155.831 Z-4.534 F152
G1 X88.289 Y155.845 Z-4.458 F152
G1 X88.294 Y155.859 Z-4.383 F152
G1 X88.298 Y155.874 Z-4.303 F152
G1 X88.302 Y155.888 Z-4.227 F152
G1 X88.309 Y155.917 Z-4.066 F152
G1 X88.314 Y155.931 Z-3.986 F152
G1 X88.317 Y155.945 Z-3.894 F152
G1 X88.322 Y155.96 Z-3.806 F152
G1 X88.329 Y155.988 Z-3.621 F152
G1 X88.333 Y156.003 Z-3.53 F152
G1 X88.337 Y156.017 Z-3.425 F152
G1 X88.342 Y156.036 Z-3.29 F152
G1 X88.345 Y156.045 Z-3.219 F152
G1 X88.347 Y156.053 Z-3.166 F152
G1 X88.349 Y156.06 Z-3.113 F152
G1 X88.354 Y156.081 Z-2.936 F152
G1 X88.357 Y156.088 Z-2.88 F152
G1 X88.359 Y156.099 Z-2.791 F152
G1 X88.36 Y156.101 Z-2.776 F152
G1 Y156.103 Z-2.761 F152
; MOVEMENT_LEAD_OUT
G1 Z-2.755 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X85.65 Y157.164 F152
G1 Z1.014 F152
; MOVEMENT_PLUNGE
G1 Z-1.7 F51
; MOVEMENT_LEAD_IN
G1 Y157.163 Z-1.706 F152
; MOVEMENT_CUTTING
G1 X85.642 Y157.155 Z-1.8 F152
G1 X85.639 Y157.152 Z-1.84 F152
G1 X85.638 Y157.151 Z-1.855 F152
G1 X85.637 Y157.15 Z-1.865 F152
G1 X85.635 Y157.148 Z-1.887 F152
G1 X85.631 Y157.145 Z-1.923 F152
G1 X85.629 Y157.144 Z-1.941 F152
G1 Y157.143 Z-1.947 F152
G1 X85.627 Y157.142 Z-1.962 F152
G1 X85.619 Y157.134 Z-2.046 F152
G1 X85.602 Y157.116 Z-2.233 F152
G1 X85.6 Y157.115 Z-2.244 F152
G1 X85.593 Y157.109 Z-2.31 F152
G1 X85.584 Y157.102 Z-2.387 F152
G1 X85.575 Y157.094 Z-2.462 F152
G1 X85.564 Y157.083 Z-2.56 F152
G1 X85.558 Y157.076 Z-2.617 F152
G1 X85.55 Y157.069 Z-2.682 F152
G1 X85.535 Y157.057 Z-2.796 F152
G1 X85.528 Y157.051 Z-2.844 F152
G1 X85.521 Y157.045 Z-2.901 F152
G1 X85.514 Y157.039 Z-2.955 F152
G1 X85.507 Y157.032 Z-3.012 F152
G1 X85.492 Y157.019 Z-3.11 F152
G1 X85.435 Y156.973 Z-3.468 F152
G1 X85.422 Y156.962 Z-3.543 F152
G1 X85.421 Y156.961 Z-3.549 F152
G1 X85.406 Y156.949 Z-3.627 F152
G1 X85.392 Y156.939 Z-3.697 F152
G1 X85.378 Y156.927 Z-3.774 F152
G1 X85.363 Y156.916 Z-3.844 F152
G1 X85.348 Y156.905 Z-3.92 F152
G1 X85.335 Y156.895 Z-3.982 F152
G1 X85.32 Y156.884 Z-4.043 F152
G1 X85.306 Y156.872 Z-4.112 F152
G1 X85.271 Y156.847 Z-4.252 F152
G1 X85.249 Y156.831 Z-4.341 F152
G1 X85.235 Y156.821 Z-4.394 F152
G1 X85.22 Y156.811 Z-4.446 F152
G1 X85.192 Y156.791 Z-4.534 F152
G1 X85.191 Y156.79 Z-4.539 F152
G1 X85.163 Y156.771 Z-4.622 F152
G1 X85.134 Y156.752 Z-4.71 F152
G1 X85.107 Y156.733 Z-4.796 F152
G1 X85.093 Y156.723 Z-4.838 F152
G1 X85.063 Y156.702 Z-4.93 F152
G1 X85.048 Y156.692 Z-4.982 F152
G1 X85.024 Y156.676 Z-5.052 F152
G1 X85.02 Y156.672 Z-5.07 F152
G1 X84.991 Y156.653 Z-5.15 F152
G1 X84.962 Y156.633 Z-5.223 F152
G1 X84.941 Y156.618 Z-5.278 F152
G1 X84.905 Y156.593 Z-5.367 F152
G1 X84.876 Y156.574 Z-5.436 F152
G1 X84.859 Y156.561 Z-5.484 F152
G1 X84.848 Y156.553 Z-5.512 F152
G1 X84.791 Y156.514 Z-5.648 F152
G1 X84.777 Y156.504 Z-5.686 F152
G1 X84.762 Y156.493 Z-5.724 F152
G1 X84.733 Y156.473 Z-5.793 F152
G1 X84.697 Y156.446 Z-5.876 F152
G1 X84.676 Y156.43 Z-5.923 F152
G1 X84.647 Y156.408 Z-5.992 F152
G1 X84.642 Y156.403 Z-6.008 F152
G1 X84.64 F152
G1 X84.638 Y156.401 Z-6.016 F152
; MOVEMENT_LEAD_OUT
G1 X84.625 Y156.387 Z-6.012 F152
G1 X84.613 Y156.376 Z-6.001 F152
G1 X84.605 Y156.368 Z-5.985 F152
G1 X84.603 Y156.365 Z-5.966 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X81.461 Y158.466 F152
G1 Z0.945 F152
; MOVEMENT_PLUNGE
G1 Z-5.966 F51
; MOVEMENT_LEAD_IN
G1 X81.458 Y158.463 Z-5.985 F152
G1 X81.451 Y158.455 Z-6.001 F152
G1 X81.44 Y158.443 Z-6.012 F152
G1 X81.428 Y158.428 Z-6.016 F152
; MOVEMENT_CUTTING
G1 X81.425 Y158.424 Z-6.008 F152
G1 X81.423 Y158.423 Z-6.005 F152
G1 X81.411 Y158.408 Z-5.976 F152
G1 X81.397 Y158.394 Z-5.952 F152
G1 X81.371 Y158.365 Z-5.899 F152
G1 X81.353 Y158.346 Z-5.863 F152
G1 X81.345 Y158.337 Z-5.846 F152
G1 X81.319 Y158.308 Z-5.793 F152
G1 X81.296 Y158.282 Z-5.744 F152
G1 X81.293 Y158.279 Z-5.74 F152
G1 X81.267 Y158.251 Z-5.687 F152
G1 X81.242 Y158.222 Z-5.635 F152
G1 X81.239 Y158.218 Z-5.632 F152
G1 X81.217 Y158.193 Z-5.594 F152
G1 X81.193 Y158.165 Z-5.548 F152
G1 X81.182 Y158.151 Z-5.529 F152
G1 X81.144 Y158.107 Z-5.462 F152
G1 X81.124 Y158.085 Z-5.431 F152
G1 X81.094 Y158.05 Z-5.382 F152
G1 X81.067 Y158.019 Z-5.334 F152
G1 X81.046 Y157.993 Z-5.297 F152
G1 X81.01 Y157.95 Z-5.256 F152
G1 X80.998 Y157.936 Z-5.241 F152
G1 X80.952 Y157.879 Z-5.179 F152
G1 Y157.878 F152
G1 X80.905 Y157.821 Z-5.117 F152
G1 X80.895 Y157.809 Z-5.108 F152
G1 X80.858 Y157.764 Z-5.056 F152
G1 X80.838 Y157.738 Z-5.035 F152
G1 X80.814 Y157.707 Z-5.019 F152
G1 X80.781 Y157.663 Z-4.991 F152
G1 X80.771 Y157.649 Z-4.981 F152
G1 X80.727 Y157.592 Z-4.949 F152
G1 X80.723 Y157.588 Z-4.948 F152
G1 X80.683 Y157.535 Z-4.918 F152
G1 X80.666 Y157.512 Z-4.905 F152
G1 X80.641 Y157.477 Z-4.884 F152
G1 X80.609 Y157.432 Z-4.88 F152
G1 X80.601 Y157.42 Z-4.878 F152
G1 X80.561 Y157.363 Z-4.869 F152
G1 X80.551 Y157.349 Z-4.871 F152
G1 X80.521 Y157.306 Z-4.866 F152
G1 X80.494 Y157.266 Z-4.858 F152
G1 X80.482 Y157.248 Z-4.856 F152
G1 X80.443 Y157.191 Z-4.859 F152
G1 X80.437 Y157.181 Z-4.863 F152
G1 X80.408 Y157.134 Z-4.874 F152
G1 X80.38 Y157.088 Z-4.893 F152
G1 X80.372 Y157.076 Z-4.897 F152
G1 X80.337 Y157.019 Z-4.913 F152
G1 X80.322 Y156.994 Z-4.92 F152
G1 X80.303 Y156.962 Z-4.929 F152
G1 X80.269 Y156.905 Z-4.946 F152
G1 X80.265 Y156.897 Z-4.952 F152
G1 X80.239 Y156.847 Z-4.987 F152
G1 X80.209 Y156.79 Z-5.024 F152
G1 X80.208 Y156.787 Z-5.029 F152
G1 X80.179 Y156.733 Z-5.069 F152
G1 X80.15 Y156.679 Z-5.112 F152
G1 X80.149 Y156.676 Z-5.114 F152
G1 X80.119 Y156.618 Z-5.155 F152
G1 X80.093 Y156.565 Z-5.219 F152
G1 X80.091 Y156.561 Z-5.225 F152
G1 X80.066 Y156.504 Z-5.293 F152
G1 X80.04 Y156.446 Z-5.369 F152
G1 X80.036 Y156.437 Z-5.383 F152
G1 X80.015 Y156.389 Z-5.438 F152
G1 X79.99 Y156.332 Z-5.506 F152
G1 X79.979 Y156.307 Z-5.543 F152
G1 X79.965 Y156.275 Z-5.587 F152
G1 X79.954 Y156.246 Z-5.629 F152
G1 X79.944 Y156.217 Z-5.681 F152
G1 X79.922 Y156.16 Z-5.79 F152
G1 X79.921 Y156.157 Z-5.794 F152
G1 X79.912 Y156.131 Z-5.836 F152
G1 X79.88 Y156.045 Z-6 F152
G1 X79.878 Y156.041 Z-6.009 F152
G1 Y156.04 Z-6.008 F152
G1 X79.877 Y156.037 Z-6.014 F152
; MOVEMENT_LEAD_OUT
G1 X79.871 Y156.023 Z-6.012 F152
G1 X79.866 Y156.009 Z-6.005 F152
G1 X79.861 Y155.999 Z-5.994 F152
G1 X79.858 Y155.992 Z-5.98 F152
G1 X79.857 Y155.99 Z-5.964 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X69.482 Y160.021 F152
G1 Z0.945 F152
; MOVEMENT_PLUNGE
G1 Z-6 F51
; MOVEMENT_LEAD_IN
G1 X69.479 Y160.024 Z-6.007 F152
G1 X69.473 Y160.029 Z-6.008 F152
G1 X69.469 Y160.033 Z-6.003 F152
; MOVEMENT_CUTTING
G1 X69.467 Y160.036 Z-5.991 F152
G1 X69.452 Y160.048 Z-5.915 F152
G1 X69.444 Y160.055 Z-5.876 F152
G1 X69.438 Y160.06 Z-5.844 F152
G1 X69.424 Y160.073 Z-5.772 F152
G1 X69.409 Y160.085 Z-5.697 F152
G1 X69.395 Y160.097 Z-5.626 F152
G1 X69.381 Y160.109 Z-5.551 F152
G1 X69.377 Y160.112 Z-5.535 F152
G1 X69.366 Y160.121 Z-5.479 F152
G1 X69.352 Y160.133 Z-5.404 F152
G1 X69.338 Y160.145 Z-5.333 F152
G1 X69.323 Y160.157 Z-5.258 F152
G1 X69.295 Y160.182 Z-5.114 F152
G1 X69.28 Y160.194 Z-5.038 F152
G1 X69.252 Y160.219 Z-4.885 F152
G1 X69.243 Y160.227 Z-4.838 F152
G1 X69.226 Y160.241 Z-4.749 F152
G1 X69.209 Y160.256 Z-4.656 F152
G1 X69.193 Y160.271 Z-4.574 F152
G1 X69.178 Y160.284 Z-4.49 F152
G1 X69.166 Y160.294 Z-4.426 F152
G1 X69.123 Y160.332 Z-4.197 F152
G1 X69.111 Y160.341 Z-4.131 F152
G1 X69.103 Y160.349 Z-4.085 F152
G1 X69.094 Y160.357 Z-4.033 F152
G1 X69.066 Y160.382 Z-3.867 F152
G1 X69.056 Y160.391 Z-3.815 F152
G1 X69.047 Y160.399 Z-3.76 F152
G1 X69.037 Y160.408 Z-3.704 F152
G1 X68.994 Y160.445 Z-3.454 F152
G1 X68.981 Y160.456 Z-3.38 F152
G1 X68.98 Y160.457 Z-3.368 F152
G1 X68.965 Y160.469 Z-3.281 F152
G1 X68.951 Y160.483 Z-3.19 F152
G1 X68.937 Y160.495 Z-3.098 F152
G1 X68.922 Y160.509 Z-3.007 F152
G1 X68.917 Y160.513 Z-2.972 F152
G1 X68.908 Y160.521 Z-2.915 F152
G1 X68.894 Y160.535 Z-2.824 F152
G1 X68.879 Y160.546 Z-2.729 F152
G1 X68.865 Y160.559 Z-2.636 F152
G1 X68.852 Y160.57 Z-2.549 F152
G1 X68.845 Y160.577 Z-2.496 F152
G1 X68.836 Y160.585 Z-2.438 F152
G1 X68.829 Y160.591 Z-2.385 F152
G1 X68.822 Y160.598 Z-2.334 F152
G1 X68.815 Y160.604 Z-2.281 F152
G1 X68.808 Y160.612 Z-2.23 F152
G1 X68.789 Y160.628 Z-2.09 F152
G1 X68.779 Y160.637 Z-2.017 F152
G1 X68.772 Y160.642 Z-1.963 F152
G1 X68.758 Y160.655 Z-1.857 F152
G1 X68.751 Y160.661 Z-1.795 F152
G1 X68.722 Y160.689 Z-1.548 F152
G1 X68.71 Y160.698 Z-1.446 F152
G1 X68.689 Y160.716 Z-1.261 F152
G1 X68.688 Y160.717 Z-1.254 F152
G1 X68.687 Y160.719 Z-1.24 F152
G1 X68.685 Y160.721 Z-1.222 F152
G1 X68.678 Y160.728 Z-1.191 F152
G1 X68.67 Y160.735 Z-1.167 F152
G1 X68.669 Y160.737 Z-1.163 F152
G1 X68.668 Y160.738 Z-1.161 F152
G1 X68.667 Y160.739 Z-1.159 F152
G1 X68.663 Y160.742 Z-1.149 F152
; MOVEMENT_LEAD_OUT
G1 X68.659 Y160.746 Z-1.137 F152
G1 X68.658 Y160.747 Z-1.124 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X92.157 Y166.356 F152
G1 Z1.012 F152
; MOVEMENT_PLUNGE
G1 Z-2.041 F51
; MOVEMENT_LEAD_IN
G1 Z-2.048 F152
; MOVEMENT_CUTTING
G1 X92.159 Y166.355 Z-2.063 F152
G1 X92.195 Y166.328 Z-2.432 F152
G1 X92.202 Y166.323 Z-2.499 F152
G1 X92.209 Y166.318 Z-2.567 F152
G1 X92.231 Y166.302 Z-2.769 F152
G1 X92.235 Y166.298 Z-2.813 F152
G1 X92.238 Y166.296 Z-2.836 F152
G1 X92.266 Y166.275 Z-3.105 F152
G1 X92.274 Y166.271 Z-3.165 F152
G1 X92.295 Y166.254 Z-3.349 F152
G1 X92.303 Y166.247 Z-3.429 F152
G1 X92.312 Y166.241 Z-3.501 F152
G1 X92.316 Y166.237 Z-3.541 F152
G1 X92.352 Y166.211 Z-3.849 F152
G1 X92.361 Y166.204 Z-3.921 F152
G1 X92.37 Y166.197 Z-3.996 F152
G1 X92.381 Y166.188 Z-4.09 F152
G1 X92.387 Y166.184 Z-4.137 F152
G1 X92.395 Y166.177 Z-4.203 F152
G1 X92.41 Y166.167 Z-4.317 F152
G1 X92.417 Y166.16 Z-4.382 F152
G1 X92.438 Y166.144 Z-4.552 F152
G1 X92.445 Y166.138 Z-4.617 F152
G1 X92.453 Y166.133 Z-4.674 F152
G1 X92.461 Y166.126 Z-4.739 F152
G1 X92.467 Y166.122 Z-4.786 F152
G1 X92.481 Y166.109 Z-4.908 F152
G1 X92.488 Y166.104 Z-4.961 F152
G1 X92.495 Y166.098 Z-5.023 F152
G1 X92.503 Y166.092 Z-5.076 F152
G1 X92.517 Y166.08 Z-5.198 F152
G1 X92.524 Y166.075 Z-5.251 F152
G1 X92.53 Y166.069 Z-5.303 F152
G1 X92.538 Y166.063 Z-5.365 F152
G1 X92.546 Y166.057 Z-5.426 F152
G1 X92.553 Y166.051 Z-5.479 F152
G1 X92.56 Y166.045 Z-5.54 F152
G1 X92.567 Y166.04 Z-5.593 F152
G1 X92.574 Y166.033 Z-5.655 F152
G1 X92.581 Y166.028 Z-5.707 F152
G1 X92.6 Y166.012 Z-5.856 F152
G1 X92.61 Y166.003 Z-5.94 F152
G1 X92.616 Y165.998 Z-5.989 F152
G1 X92.617 F152
G1 X92.619 Y165.996 Z-6.005 F152
; MOVEMENT_LEAD_OUT
G1 X92.631 Y165.983 Z-6.006 F152
G1 X92.643 Y165.971 Z-6 F152
G1 X92.653 Y165.962 Z-5.989 F152
G1 X92.659 Y165.955 Z-5.974 F152
G1 X92.662 Y165.953 Z-5.956 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X103.962 Y200.328 F152
G1 Z0.947 F152
; MOVEMENT_PLUNGE
G1 Z-5.982 F51
; MOVEMENT_LEAD_IN
G1 X103.965 Y200.327 Z-5.996 F152
G1 X103.973 Y200.325 Z-6.008 F152
G1 X103.984 Y200.321 Z-6.016 F152
; MOVEMENT_CUTTING
G1 X104.039 Y200.304 F152
G1 X104.096 Y200.291 F152
G1 X104.153 Y200.281 F152
G1 X104.21 Y200.276 F152
G1 X104.268 Y200.271 F152
G1 X104.382 Y200.273 F152
G1 X104.44 Y200.278 F152
G1 X104.497 Y200.283 F152
G1 X104.554 Y200.289 F152
G1 X104.611 Y200.3 F152
G1 X104.669 Y200.31 F152
G1 X104.724 Y200.321 F152
G1 X104.726 Y200.322 F152
G1 X104.841 Y200.351 F152
G1 X104.898 Y200.368 F152
G1 X104.932 Y200.379 F152
G1 X104.955 Y200.387 F152
G1 X105.012 Y200.406 F152
G1 X105.07 Y200.426 F152
G1 X105.096 Y200.436 F152
G1 X105.127 Y200.449 F152
G1 X105.184 Y200.472 F152
G1 X105.236 Y200.493 F152
G1 X105.242 Y200.496 F152
G1 X105.358 Y200.551 F152
G1 X105.413 Y200.577 F152
G1 X105.47 Y200.608 F152
G1 X105.471 Y200.609 F152
G1 X105.528 Y200.64 F152
G1 X105.575 Y200.665 F152
G1 X105.585 Y200.671 F152
G1 X105.643 Y200.706 F152
G1 X105.669 Y200.722 F152
G1 X105.7 Y200.742 F152
G1 X105.762 Y200.78 F152
G1 X105.844 Y200.837 F152
G1 X105.872 Y200.857 F152
G1 X105.925 Y200.894 F152
G1 X105.986 Y200.941 F152
G1 X106.001 Y200.952 F152
G1 X106.044 Y200.986 F152
G1 X106.073 Y201.009 F152
G1 X106.101 Y201.03 F152
G1 X106.142 Y201.066 F152
G1 X106.158 Y201.08 F152
G1 X106.207 Y201.123 F152
G1 X106.272 Y201.181 F152
G1 X106.301 Y201.21 F152
G1 X106.33 Y201.238 F152
G1 X106.359 Y201.267 F152
G1 X106.388 Y201.295 F152
G1 X106.443 Y201.352 F152
G1 X106.445 Y201.355 F152
G1 X106.495 Y201.41 F152
G1 X106.546 Y201.467 F152
G1 X106.559 Y201.483 F152
G1 X106.592 Y201.524 F152
G1 X106.616 Y201.555 F152
G1 X106.638 Y201.582 F152
G1 X106.674 Y201.627 F152
G1 X106.682 Y201.639 F152
G1 X106.722 Y201.696 F152
G1 X106.731 Y201.709 F152
G1 X106.762 Y201.753 F152
G1 X106.788 Y201.794 F152
G1 X106.798 Y201.811 F152
G1 X106.833 Y201.868 F152
G1 X106.846 Y201.888 F152
G1 X106.867 Y201.925 F152
G1 X106.897 Y201.983 F152
G1 X106.903 Y201.994 F152
G1 X106.926 Y202.04 F152
G1 X106.952 Y202.097 F152
G1 X106.96 Y202.117 F152
G1 X106.975 Y202.154 F152
G1 X106.998 Y202.212 F152
G1 X107.017 Y202.272 F152
G1 X107.034 Y202.326 F152
G1 X107.046 Y202.383 F152
G1 X107.058 Y202.441 F152
G1 X107.065 Y202.498 F152
G1 X107.068 Y202.555 F152
G1 X107.067 Y202.613 F152
G1 X107.059 Y202.67 F152
G1 X107.042 Y202.727 F152
G1 X107.017 Y202.772 F152
G1 X107.007 Y202.784 F152
G1 X106.989 Y202.803 F152
G1 X106.96 Y202.826 F152
G1 X106.934 Y202.842 F152
G1 X106.903 Y202.857 F152
G1 X106.846 Y202.879 F152
G1 X106.788 Y202.895 F152
G1 X106.772 Y202.899 F152
G1 X106.731 Y202.906 F152
G1 X106.674 Y202.914 F152
G1 X106.616 Y202.919 F152
G1 X106.559 Y202.92 F152
G1 X106.502 F152
G1 X106.445 Y202.918 F152
G1 X106.387 Y202.912 F152
G1 X106.33 Y202.906 F152
G1 X106.28 Y202.899 F152
G1 X106.273 Y202.897 F152
G1 X106.215 Y202.887 F152
G1 X106.158 Y202.877 F152
G1 X106.019 Y202.842 F152
G1 X105.986 Y202.833 F152
G1 X105.929 Y202.815 F152
G1 X105.872 Y202.796 F152
G1 X105.837 Y202.784 F152
G1 X105.814 Y202.777 F152
G1 X105.757 Y202.754 F152
G1 X105.7 Y202.732 F152
G1 X105.689 Y202.727 F152
G1 X105.643 Y202.708 F152
G1 X105.585 Y202.682 F152
G1 X105.528 Y202.656 F152
G1 X105.471 Y202.628 F152
G1 X105.438 Y202.613 F152
G1 X105.413 Y202.598 F152
G1 X105.356 Y202.568 F152
G1 X105.334 Y202.555 F152
G1 X105.299 Y202.537 F152
G1 X105.242 Y202.503 F152
G1 X105.234 Y202.498 F152
G1 X105.184 Y202.468 F152
G1 X105.14 Y202.441 F152
G1 X105.127 Y202.432 F152
G1 X105.07 Y202.395 F152
G1 X105.054 Y202.383 F152
G1 X104.971 Y202.326 F152
G1 X104.898 Y202.273 F152
G1 X104.892 Y202.269 F152
G1 X104.841 Y202.229 F152
G1 X104.819 Y202.212 F152
G1 X104.783 Y202.183 F152
G1 X104.747 Y202.154 F152
G1 X104.726 Y202.136 F152
G1 X104.681 Y202.097 F152
G1 X104.669 Y202.085 F152
G1 X104.616 Y202.04 F152
G1 X104.611 Y202.035 F152
G1 X104.554 Y201.982 F152
G1 X104.525 Y201.953 F152
G1 X104.497 Y201.925 F152
G1 X104.44 Y201.868 F152
G1 X104.388 Y201.811 F152
G1 X104.382 Y201.804 F152
G1 X104.336 Y201.753 F152
G1 X104.325 Y201.742 F152
G1 X104.287 Y201.696 F152
G1 X104.241 Y201.639 F152
G1 X104.21 Y201.6 F152
G1 X104.195 Y201.582 F152
G1 X104.154 Y201.524 F152
G1 X104.153 Y201.523 F152
G1 X104.114 Y201.467 F152
G1 X104.096 Y201.441 F152
G1 X104.075 Y201.41 F152
G1 X104.04 Y201.352 F152
G1 X104.039 Y201.35 F152
G1 X104.005 Y201.295 F152
G1 X103.981 Y201.252 F152
G1 X103.945 Y201.181 F152
G1 X103.924 Y201.139 F152
G1 X103.917 Y201.123 F152
G1 X103.868 Y201.009 F152
G1 X103.867 Y201.004 F152
G1 X103.85 Y200.952 F152
G1 X103.831 Y200.894 F152
G1 X103.817 Y200.837 F152
G1 X103.809 Y200.807 F152
G1 X103.804 Y200.78 F152
G1 X103.795 Y200.722 F152
G1 X103.789 Y200.665 F152
G1 Y200.608 F152
G1 X103.793 Y200.551 F152
G1 X103.805 Y200.493 F152
G1 X103.809 Y200.477 F152
G1 X103.829 Y200.436 F152
G1 X103.85 Y200.407 F152
G1 X103.867 Y200.39 F152
G1 X103.88 Y200.379 F152
G1 X103.924 Y200.349 F152
G1 X103.981 Y200.322 F152
G1 X103.984 Y200.321 F152
; MOVEMENT_LEAD_OUT
G1 X104.002 Y200.315 Z-6.012 F152
G1 X104.018 Y200.31 Z-6.001 F152
G1 X104.028 Y200.307 Z-5.985 F152
G1 X104.031 Y200.306 Z-5.966 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X92.251 Y224.492 F152
G1 Z0.947 F152
; MOVEMENT_PLUNGE
G1 Z-5.966 F51
; MOVEMENT_LEAD_IN
G1 X92.254 Y224.494 Z-5.985 F152
G1 X92.264 Y224.499 Z-6.001 F152
G1 X92.278 Y224.507 Z-6.012 F152
G1 X92.295 Y224.516 Z-6.016 F152
; MOVEMENT_CUTTING
G1 X92.352 Y224.547 F152
G1 X92.359 Y224.55 F152
G1 X92.41 Y224.578 F152
G1 X92.467 Y224.608 F152
G1 X92.524 Y224.643 F152
G1 X92.559 Y224.665 F152
G1 X92.581 Y224.679 F152
G1 X92.639 Y224.714 F152
G1 X92.653 Y224.722 F152
G1 X92.696 Y224.749 F152
G1 X92.742 Y224.779 F152
G1 X92.753 Y224.787 F152
G1 X92.811 Y224.825 F152
G1 X92.828 Y224.837 F152
G1 X92.868 Y224.862 F152
G1 X92.925 Y224.901 F152
G1 X92.982 Y224.94 F152
G1 X93.154 Y225.061 F152
G1 X93.161 Y225.066 F152
G1 X93.212 Y225.101 F152
G1 X93.241 Y225.123 F152
G1 X93.269 Y225.143 F152
G1 X93.32 Y225.18 F152
G1 X93.326 Y225.185 F152
G1 X93.383 Y225.227 F152
G1 X93.399 Y225.237 F152
G1 X93.441 Y225.268 F152
G1 X93.477 Y225.295 F152
G1 X93.498 Y225.31 F152
G1 X93.553 Y225.352 F152
G1 X93.555 Y225.353 F152
G1 X93.613 Y225.397 F152
G1 X93.63 Y225.409 F152
G1 X93.67 Y225.44 F152
G1 X93.727 Y225.483 F152
G1 X93.784 Y225.527 F152
G1 X93.854 Y225.581 F152
G1 X93.899 Y225.617 F152
G1 X93.927 Y225.638 F152
G1 X93.956 Y225.662 F152
G1 X94 Y225.696 F152
G1 X94.071 Y225.752 F152
G1 X94.073 Y225.753 F152
G1 X94.145 Y225.81 F152
G1 X94.185 Y225.842 F152
G1 X94.219 Y225.868 F152
G1 X94.243 Y225.887 F152
G1 X94.291 Y225.925 F152
G1 X94.357 Y225.978 F152
G1 X94.415 Y226.026 F152
G1 X94.431 Y226.039 F152
G1 X94.472 Y226.074 F152
G1 X94.499 Y226.097 F152
G1 X94.529 Y226.122 F152
G1 X94.568 Y226.154 F152
G1 X94.586 Y226.17 F152
G1 X94.636 Y226.211 F152
G1 X94.644 Y226.218 F152
G1 X94.701 Y226.267 F152
G1 X94.704 Y226.268 F152
G1 X94.758 Y226.314 F152
G1 X94.772 Y226.326 F152
G1 X94.816 Y226.362 F152
G1 X94.84 Y226.383 F152
G1 X94.873 Y226.411 F152
G1 X94.909 Y226.44 F152
G1 X94.93 Y226.459 F152
G1 X94.972 Y226.498 F152
G1 X94.987 Y226.512 F152
G1 X95.045 Y226.564 F152
G1 X95.098 Y226.612 F152
G1 X95.102 Y226.616 F152
G1 X95.159 Y226.668 F152
G1 X95.161 Y226.669 F152
G1 X95.217 Y226.72 F152
G1 X95.225 Y226.727 F152
G1 X95.274 Y226.771 F152
G1 X95.287 Y226.784 F152
G1 X95.331 Y226.823 F152
G1 X95.388 Y226.875 F152
G1 X95.414 Y226.899 F152
G1 X95.446 Y226.927 F152
G1 X95.476 Y226.956 F152
G1 X95.503 Y226.983 F152
G1 X95.534 Y227.013 F152
G1 X95.592 Y227.07 F152
G1 X95.618 Y227.095 F152
G1 X95.675 Y227.153 F152
G1 X95.708 Y227.185 F152
G1 X95.732 Y227.209 F152
G1 X95.766 Y227.242 F152
G1 X95.823 Y227.299 F152
G1 X95.847 Y227.322 F152
G1 X95.904 Y227.379 F152
G1 X95.94 Y227.414 F152
G1 X95.961 Y227.436 F152
G1 X95.995 Y227.471 F152
G1 X96.019 Y227.496 F152
G1 X96.049 Y227.529 F152
G1 X96.076 Y227.558 F152
G1 X96.102 Y227.586 F152
G1 X96.155 Y227.643 F152
G1 X96.19 Y227.682 F152
G1 X96.208 Y227.7 F152
G1 X96.248 Y227.743 F152
G1 X96.261 Y227.758 F152
G1 X96.305 Y227.805 F152
G1 X96.314 Y227.815 F152
G1 X96.362 Y227.867 F152
G1 X96.368 Y227.872 F152
G1 X96.42 Y227.929 F152
G1 Y227.93 F152
G1 X96.471 Y227.987 F152
G1 X96.477 Y227.992 F152
G1 X96.521 Y228.044 F152
G1 X96.534 Y228.059 F152
G1 X96.57 Y228.101 F152
G1 X96.619 Y228.159 F152
G1 X96.649 Y228.193 F152
G1 X96.668 Y228.216 F152
G1 X96.706 Y228.26 F152
G1 X96.718 Y228.273 F152
G1 X96.763 Y228.327 F152
G1 X96.767 Y228.33 F152
G1 X96.815 Y228.388 F152
G1 X96.821 Y228.393 F152
G1 X96.864 Y228.445 F152
G1 X96.878 Y228.46 F152
G1 X96.913 Y228.502 F152
G1 X96.935 Y228.53 F152
G1 X96.958 Y228.56 F152
G1 X96.992 Y228.602 F152
G1 X97.005 Y228.617 F152
G1 X97.05 Y228.672 F152
G1 X97.051 Y228.674 F152
G1 X97.097 Y228.731 F152
G1 X97.107 Y228.744 F152
G1 X97.143 Y228.789 F152
G1 X97.164 Y228.815 F152
G1 X97.222 Y228.886 F152
G1 X97.235 Y228.903 F152
G1 X97.279 Y228.957 F152
G1 X97.282 Y228.961 F152
G1 X97.327 Y229.018 F152
G1 X97.371 Y229.075 F152
G1 X97.461 Y229.19 F152
G1 X97.504 Y229.247 F152
G1 X97.508 Y229.251 F152
G1 X97.594 Y229.361 F152
G1 X97.623 Y229.399 F152
G1 X97.638 Y229.419 F152
G1 X97.68 Y229.472 F152
G1 X97.726 Y229.533 F152
G1 X97.737 Y229.547 F152
G1 X97.77 Y229.591 F152
G1 X97.794 Y229.622 F152
G1 X97.814 Y229.648 F152
G1 X97.852 Y229.696 F152
G1 X97.858 Y229.705 F152
G1 X97.902 Y229.762 F152
G1 X97.909 Y229.771 F152
G1 X97.947 Y229.82 F152
G1 X97.966 Y229.846 F152
G1 X97.99 Y229.877 F152
G1 X98.024 Y229.921 F152
G1 X98.034 Y229.934 F152
G1 X98.122 Y230.049 F152
G1 X98.167 Y230.106 F152
G1 X98.195 Y230.144 F152
G1 X98.211 Y230.163 F152
G1 X98.253 Y230.217 F152
G1 X98.299 Y230.278 F152
G1 X98.31 Y230.291 F152
G1 X98.344 Y230.335 F152
G1 X98.388 Y230.393 F152
G1 X98.425 Y230.439 F152
G1 X98.433 Y230.45 F152
G1 X98.477 Y230.507 F152
G1 X98.482 Y230.513 F152
G1 X98.522 Y230.564 F152
G1 X98.539 Y230.587 F152
G1 X98.567 Y230.622 F152
G1 X98.596 Y230.659 F152
G1 X98.612 Y230.679 F152
G1 X98.654 Y230.733 F152
G1 X98.656 Y230.736 F152
G1 X98.768 Y230.879 F152
G1 X98.79 Y230.908 F152
G1 X98.826 Y230.954 F152
G1 X98.835 Y230.965 F152
G1 X98.879 Y231.023 F152
G1 X98.883 Y231.028 F152
G1 X98.923 Y231.08 F152
G1 X98.94 Y231.101 F152
G1 X98.968 Y231.137 F152
G1 X98.997 Y231.176 F152
G1 X99.012 Y231.194 F152
G1 X99.054 Y231.252 F152
G1 X99.055 Y231.253 F152
G1 X99.096 Y231.309 F152
G1 X99.112 Y231.33 F152
G1 X99.138 Y231.366 F152
G1 X99.169 Y231.408 F152
G1 X99.18 Y231.424 F152
G1 X99.222 Y231.481 F152
G1 X99.227 Y231.486 F152
G1 X99.263 Y231.538 F152
G1 X99.338 Y231.653 F152
G1 X99.341 Y231.656 F152
G1 X99.377 Y231.71 F152
G1 X99.398 Y231.743 F152
G1 X99.415 Y231.767 F152
G1 X99.452 Y231.824 F152
G1 X99.456 Y231.829 F152
G1 X99.488 Y231.882 F152
G1 X99.513 Y231.925 F152
G1 X99.521 Y231.939 F152
G1 X99.555 Y231.996 F152
G1 X99.57 Y232.023 F152
G1 X99.587 Y232.054 F152
G1 X99.618 Y232.111 F152
G1 X99.628 Y232.13 F152
G1 X99.647 Y232.168 F152
G1 X99.677 Y232.225 F152
G1 X99.685 Y232.24 F152
G1 X99.705 Y232.283 F152
G1 X99.731 Y232.34 F152
G1 X99.742 Y232.363 F152
G1 X99.757 Y232.397 F152
G1 X99.783 Y232.455 F152
G1 X99.799 Y232.489 F152
G1 X99.808 Y232.512 F152
G1 X99.831 Y232.569 F152
G1 X99.854 Y232.626 F152
G1 X99.857 Y232.634 F152
G1 X99.876 Y232.684 F152
G1 X99.898 Y232.741 F152
G1 X99.914 Y232.787 F152
G1 X99.918 Y232.798 F152
G1 X99.937 Y232.855 F152
G1 X99.956 Y232.913 F152
G1 X99.971 Y232.956 F152
G1 X99.976 Y232.97 F152
G1 X100.01 Y233.085 F152
G1 X100.026 Y233.142 F152
G1 X100.029 Y233.15 F152
G1 X100.042 Y233.199 F152
G1 X100.058 Y233.256 F152
G1 X100.072 Y233.314 F152
G1 X100.086 Y233.37 F152
G1 Y233.371 F152
G1 X100.099 Y233.428 F152
G1 X100.114 Y233.486 F152
G1 X100.126 Y233.543 F152
G1 X100.137 Y233.6 F152
G1 X100.143 Y233.631 F152
G1 X100.148 Y233.657 F152
G1 X100.159 Y233.715 F152
G1 X100.17 Y233.772 F152
G1 X100.18 Y233.829 F152
G1 X100.196 Y233.944 F152
G1 X100.2 Y233.969 F152
G1 X100.213 Y234.058 F152
G1 X100.219 Y234.116 F152
G1 X100.225 Y234.173 F152
G1 X100.231 Y234.23 F152
G1 X100.236 Y234.287 F152
G1 X100.241 Y234.345 F152
G1 X100.251 Y234.574 F152
G1 X100.248 Y234.803 F152
G1 X100.242 Y234.86 F152
G1 X100.238 Y234.917 F152
G1 X100.233 Y234.975 F152
G1 X100.225 Y235.032 F152
G1 X100.206 Y235.147 F152
G1 X100.2 Y235.181 F152
G1 X100.194 Y235.204 F152
G1 X100.164 Y235.318 F152
G1 X100.143 Y235.381 F152
G1 X100.123 Y235.433 F152
G1 X100.102 Y235.49 F152
G1 X100.086 Y235.525 F152
G1 X100.075 Y235.548 F152
G1 X100.048 Y235.605 F152
G1 X100.029 Y235.643 F152
G1 X100.018 Y235.662 F152
G1 X99.985 Y235.719 F152
G1 X99.971 Y235.742 F152
G1 X99.951 Y235.777 F152
G1 X99.914 Y235.832 F152
G1 X99.913 Y235.834 F152
G1 X99.874 Y235.891 F152
G1 X99.857 Y235.917 F152
G1 X99.834 Y235.948 F152
G1 X99.747 Y236.063 F152
G1 X99.742 Y236.068 F152
G1 X99.701 Y236.12 F152
G1 X99.685 Y236.14 F152
G1 X99.653 Y236.178 F152
G1 X99.628 Y236.207 F152
G1 X99.603 Y236.235 F152
G1 X99.57 Y236.274 F152
G1 X99.553 Y236.292 F152
G1 X99.5 Y236.349 F152
G1 X99.456 Y236.397 F152
G1 X99.446 Y236.407 F152
G1 X99.398 Y236.456 F152
G1 X99.39 Y236.464 F152
G1 X99.341 Y236.511 F152
G1 X99.331 Y236.521 F152
G1 X99.284 Y236.567 F152
G1 X99.271 Y236.579 F152
G1 X99.227 Y236.619 F152
G1 X99.207 Y236.636 F152
G1 X99.169 Y236.668 F152
G1 X99.141 Y236.693 F152
G1 X99.112 Y236.717 F152
G1 X99.071 Y236.75 F152
G1 X99.055 Y236.763 F152
G1 X98.994 Y236.808 F152
G1 X98.94 Y236.848 F152
G1 X98.913 Y236.865 F152
G1 X98.883 Y236.884 F152
G1 X98.826 Y236.92 F152
G1 X98.821 Y236.922 F152
G1 X98.768 Y236.952 F152
G1 X98.711 Y236.979 F152
G1 X98.654 Y237.006 F152
G1 X98.565 Y237.037 F152
G1 X98.539 Y237.044 F152
G1 X98.482 Y237.056 F152
G1 X98.425 Y237.065 F152
G1 X98.367 Y237.07 F152
G1 X98.31 Y237.073 F152
G1 X98.253 Y237.072 F152
G1 X98.195 Y237.07 F152
G1 X98.081 Y237.059 F152
G1 X98.024 Y237.053 F152
G1 X97.966 Y237.044 F152
G1 X97.915 Y237.037 F152
G1 X97.909 Y237.035 F152
G1 X97.852 Y237.027 F152
G1 X97.794 Y237.018 F152
G1 X97.737 Y237.01 F152
G1 X97.68 Y237.001 F152
G1 X97.623 Y236.993 F152
G1 X97.565 Y236.984 F152
G1 X97.534 Y236.979 F152
G1 X97.508 Y236.975 F152
G1 X97.451 Y236.966 F152
G1 X97.393 Y236.956 F152
G1 X97.336 Y236.947 F152
G1 X97.222 Y236.928 F152
G1 X97.189 Y236.922 F152
G1 X97.164 Y236.918 F152
G1 X97.107 Y236.907 F152
G1 X97.05 Y236.897 F152
G1 X96.992 Y236.885 F152
G1 X96.935 Y236.873 F152
G1 X96.895 Y236.865 F152
G1 X96.878 Y236.861 F152
G1 X96.821 Y236.849 F152
G1 X96.763 Y236.835 F152
G1 X96.706 Y236.819 F152
G1 X96.66 Y236.808 F152
G1 X96.649 Y236.804 F152
G1 X96.534 Y236.774 F152
G1 X96.477 Y236.754 F152
G1 X96.465 Y236.75 F152
G1 X96.42 Y236.734 F152
G1 X96.362 Y236.715 F152
G1 X96.305 Y236.696 F152
G1 X96.295 Y236.693 F152
G1 X96.248 Y236.675 F152
G1 X96.19 Y236.652 F152
G1 X96.149 Y236.636 F152
G1 X96.133 Y236.629 F152
G1 X96.019 Y236.582 F152
G1 X96.008 Y236.579 F152
G1 X95.961 Y236.559 F152
G1 X95.904 Y236.532 F152
G1 X95.882 Y236.521 F152
G1 X95.847 Y236.504 F152
G1 X95.789 Y236.477 F152
G1 X95.76 Y236.464 F152
G1 X95.732 Y236.451 F152
G1 X95.675 Y236.424 F152
G1 X95.639 Y236.407 F152
G1 X95.618 Y236.396 F152
G1 X95.56 Y236.369 F152
G1 X95.517 Y236.349 F152
G1 X95.503 Y236.342 F152
G1 X95.446 Y236.315 F152
G1 X95.396 Y236.292 F152
G1 X95.388 Y236.289 F152
G1 X95.331 Y236.261 F152
G1 X95.275 Y236.235 F152
G1 X95.274 Y236.234 F152
G1 X95.159 Y236.18 F152
G1 X95.152 Y236.178 F152
G1 X95.102 Y236.153 F152
G1 X95.045 Y236.127 F152
G1 X95.03 Y236.12 F152
G1 X94.987 Y236.1 F152
G1 X94.93 Y236.075 F152
G1 X94.901 Y236.063 F152
G1 X94.873 Y236.051 F152
G1 X94.816 Y236.026 F152
G1 X94.765 Y236.006 F152
G1 X94.758 Y236.003 F152
G1 X94.701 Y235.981 F152
G1 X94.644 Y235.959 F152
G1 X94.614 Y235.948 F152
G1 X94.586 Y235.939 F152
G1 X94.529 Y235.921 F152
G1 X94.472 Y235.904 F152
G1 X94.431 Y235.891 F152
G1 X94.415 Y235.886 F152
G1 X94.357 Y235.869 F152
G1 X94.3 Y235.856 F152
G1 X94.185 Y235.835 F152
G1 X94.128 Y235.823 F152
G1 X94.071 Y235.815 F152
G1 X94.014 Y235.811 F152
G1 X93.956 Y235.809 F152
G1 X93.899 Y235.806 F152
G1 X93.842 Y235.804 F152
G1 X93.784 Y235.805 F152
G1 X93.727 Y235.811 F152
G1 X93.613 Y235.827 F152
G1 X93.565 Y235.834 F152
G1 X93.555 Y235.835 F152
G1 X93.498 Y235.846 F152
G1 X93.441 Y235.863 F152
G1 X93.383 Y235.882 F152
G1 X93.359 Y235.891 F152
G1 X93.326 Y235.903 F152
G1 X93.269 Y235.923 F152
G1 X93.212 Y235.948 F152
G1 X93.154 Y235.978 F152
G1 X93.04 Y236.042 F152
G1 X93.007 Y236.063 F152
G1 X92.982 Y236.078 F152
G1 X92.926 Y236.12 F152
G1 X92.925 Y236.121 F152
G1 X92.868 Y236.165 F152
G1 X92.811 Y236.21 F152
G1 X92.782 Y236.235 F152
G1 X92.753 Y236.261 F152
G1 X92.696 Y236.314 F152
G1 X92.658 Y236.349 F152
G1 X92.639 Y236.368 F152
G1 X92.581 Y236.428 F152
G1 X92.547 Y236.464 F152
G1 X92.524 Y236.487 F152
G1 X92.491 Y236.521 F152
G1 X92.467 Y236.546 F152
G1 X92.436 Y236.579 F152
G1 X92.352 Y236.665 F152
G1 X92.325 Y236.693 F152
G1 X92.238 Y236.777 F152
G1 X92.205 Y236.808 F152
G1 X92.18 Y236.832 F152
G1 X92.146 Y236.865 F152
G1 X92.123 Y236.887 F152
G1 X92.087 Y236.922 F152
G1 X92.066 Y236.943 F152
G1 X92.024 Y236.979 F152
G1 X91.954 Y237.037 F152
G1 X91.951 Y237.039 F152
G1 X91.884 Y237.094 F152
G1 X91.815 Y237.151 F152
G1 X91.779 Y237.18 F152
G1 X91.743 Y237.209 F152
G1 X91.722 Y237.222 F152
G1 X91.665 Y237.262 F152
G1 X91.659 Y237.266 F152
G1 X91.608 Y237.302 F152
G1 X91.493 Y237.38 F152
G1 X91.436 Y237.419 F152
G1 X91.403 Y237.438 F152
G1 X91.378 Y237.452 F152
G1 X91.321 Y237.486 F152
G1 X91.307 Y237.495 F152
G1 X91.264 Y237.518 F152
G1 X91.207 Y237.548 F152
G1 X91.199 Y237.552 F152
G1 X91.149 Y237.578 F152
G1 X91.092 Y237.606 F152
G1 X91.084 Y237.61 F152
G1 X91.035 Y237.631 F152
G1 X90.977 Y237.657 F152
G1 X90.956 Y237.667 F152
G1 X90.92 Y237.681 F152
G1 X90.806 Y237.724 F152
G1 X90.748 Y237.745 F152
G1 X90.691 Y237.762 F152
G1 X90.634 Y237.778 F152
G1 X90.623 Y237.781 F152
G1 X90.576 Y237.794 F152
G1 X90.519 Y237.81 F152
G1 X90.462 Y237.821 F152
G1 X90.405 Y237.831 F152
G1 X90.364 Y237.839 F152
G1 X90.347 Y237.841 F152
G1 X90.29 Y237.851 F152
G1 X90.061 Y237.869 F152
G1 X89.946 F152
G1 X89.889 Y237.865 F152
G1 X89.832 Y237.861 F152
G1 X89.774 Y237.855 F152
G1 X89.717 Y237.848 F152
G1 X89.665 Y237.839 F152
G1 X89.66 Y237.837 F152
G1 X89.603 Y237.826 F152
G1 X89.545 Y237.814 F152
G1 X89.488 Y237.799 F152
G1 X89.431 Y237.783 F152
G1 X89.424 Y237.781 F152
G1 X89.373 Y237.765 F152
G1 X89.316 Y237.746 F152
G1 X89.259 Y237.724 F152
G1 X89.257 F152
G1 X89.202 Y237.703 F152
G1 X89.144 Y237.678 F152
G1 X89.121 Y237.667 F152
G1 X89.087 Y237.652 F152
G1 X89.03 Y237.624 F152
G1 X88.915 Y237.563 F152
G1 X88.896 Y237.552 F152
G1 X88.858 Y237.529 F152
G1 X88.801 Y237.495 F152
G1 X88.743 Y237.457 F152
G1 X88.714 Y237.438 F152
G1 X88.686 Y237.419 F152
G1 X88.63 Y237.38 F152
G1 X88.629 Y237.379 F152
G1 X88.571 Y237.336 F152
G1 X88.554 Y237.323 F152
G1 X88.514 Y237.293 F152
G1 X88.482 Y237.266 F152
G1 X88.457 Y237.245 F152
G1 X88.413 Y237.209 F152
G1 X88.4 Y237.198 F152
G1 X88.348 Y237.151 F152
G1 X88.342 Y237.147 F152
G1 X88.285 Y237.094 F152
G1 X88.256 Y237.066 F152
G1 X88.228 Y237.037 F152
G1 X88.174 Y236.979 F152
G1 X88.17 Y236.976 F152
G1 X88.119 Y236.922 F152
G1 X88.113 Y236.915 F152
G1 X88.066 Y236.865 F152
G1 X88.056 Y236.855 F152
G1 X88.012 Y236.808 F152
G1 X87.999 Y236.791 F152
G1 X87.967 Y236.75 F152
G1 X87.941 Y236.718 F152
G1 X87.922 Y236.693 F152
G1 X87.884 Y236.646 F152
G1 X87.877 Y236.636 F152
G1 X87.831 Y236.579 F152
G1 X87.827 Y236.572 F152
G1 X87.788 Y236.521 F152
G1 X87.751 Y236.464 F152
G1 X87.714 Y236.407 F152
G1 X87.712 Y236.405 F152
G1 X87.676 Y236.349 F152
G1 X87.655 Y236.316 F152
G1 X87.639 Y236.292 F152
G1 X87.602 Y236.235 F152
G1 X87.598 Y236.227 F152
G1 X87.572 Y236.178 F152
G1 X87.511 Y236.063 F152
G1 X87.483 Y236.011 F152
G1 X87.48 Y236.006 F152
G1 X87.45 Y235.948 F152
G1 X87.426 Y235.897 F152
G1 X87.424 Y235.891 F152
G1 X87.376 Y235.777 F152
G1 X87.368 Y235.761 F152
G1 X87.351 Y235.719 F152
G1 X87.327 Y235.662 F152
G1 X87.311 Y235.625 F152
G1 X87.303 Y235.605 F152
G1 X87.284 Y235.548 F152
G1 X87.266 Y235.49 F152
G1 X87.254 Y235.453 F152
G1 X87.248 Y235.433 F152
G1 X87.23 Y235.376 F152
G1 X87.211 Y235.318 F152
G1 X87.197 Y235.272 F152
G1 X87.195 Y235.261 F152
G1 X87.168 Y235.147 F152
G1 X87.155 Y235.089 F152
G1 X87.142 Y235.032 F152
G1 X87.139 Y235.021 F152
G1 X87.129 Y234.975 F152
G1 X87.119 Y234.917 F152
G1 X87.103 Y234.803 F152
G1 X87.094 Y234.746 F152
G1 X87.086 Y234.688 F152
G1 X87.082 Y234.664 F152
G1 X87.078 Y234.631 F152
G1 X87.073 Y234.574 F152
G1 X87.069 Y234.517 F152
G1 X87.065 Y234.459 F152
G1 X87.054 Y234.287 F152
G1 Y234.173 F152
G1 X87.055 Y234.116 F152
G1 Y234.058 F152
G1 X87.056 Y234.001 F152
G1 Y233.944 F152
G1 X87.06 Y233.886 F152
G1 X87.069 Y233.772 F152
G1 X87.074 Y233.715 F152
G1 X87.078 Y233.657 F152
G1 X87.082 Y233.602 F152
G1 X87.083 Y233.6 F152
G1 X87.087 Y233.543 F152
G1 X87.095 Y233.486 F152
G1 X87.103 Y233.428 F152
G1 X87.112 Y233.371 F152
G1 X87.12 Y233.314 F152
G1 X87.129 Y233.256 F152
G1 X87.137 Y233.199 F152
G1 X87.139 Y233.179 F152
G1 X87.155 Y233.085 F152
G1 X87.167 Y233.027 F152
G1 X87.18 Y232.97 F152
G1 X87.191 Y232.913 F152
G1 X87.197 Y232.887 F152
G1 X87.204 Y232.855 F152
G1 X87.227 Y232.741 F152
G1 X87.24 Y232.684 F152
G1 X87.254 Y232.629 F152
G1 X87.255 Y232.626 F152
G1 X87.3 Y232.455 F152
G1 X87.311 Y232.413 F152
G1 X87.316 Y232.397 F152
G1 X87.346 Y232.283 F152
G1 X87.362 Y232.225 F152
G1 X87.368 Y232.206 F152
G1 X87.38 Y232.168 F152
G1 X87.399 Y232.111 F152
G1 X87.417 Y232.054 F152
G1 X87.426 Y232.024 F152
G1 X87.435 Y231.996 F152
G1 X87.453 Y231.939 F152
G1 X87.471 Y231.882 F152
G1 X87.483 Y231.843 F152
G1 X87.489 Y231.824 F152
G1 X87.508 Y231.767 F152
G1 X87.529 Y231.71 F152
G1 X87.54 Y231.677 F152
G1 X87.549 Y231.653 F152
G1 X87.57 Y231.595 F152
G1 X87.591 Y231.538 F152
G1 X87.598 Y231.519 F152
G1 X87.612 Y231.481 F152
G1 X87.653 Y231.366 F152
G1 X87.655 Y231.361 F152
G1 X87.674 Y231.309 F152
G1 X87.712 Y231.211 F152
G1 X87.719 Y231.194 F152
G1 X87.742 Y231.137 F152
G1 X87.765 Y231.08 F152
G1 X87.769 Y231.068 F152
G1 X87.788 Y231.023 F152
G1 X87.811 Y230.965 F152
G1 X87.827 Y230.926 F152
G1 X87.835 Y230.908 F152
G1 X87.857 Y230.851 F152
G1 X87.88 Y230.793 F152
G1 X87.884 Y230.784 F152
G1 X87.905 Y230.736 F152
G1 X87.93 Y230.679 F152
G1 X87.941 Y230.652 F152
G1 X87.955 Y230.622 F152
G1 X88.055 Y230.393 F152
G1 X88.056 Y230.391 F152
G1 X88.08 Y230.335 F152
G1 X88.105 Y230.278 F152
G1 X88.113 Y230.26 F152
G1 X88.13 Y230.221 F152
G1 X88.184 Y230.106 F152
G1 X88.212 Y230.049 F152
G1 X88.228 Y230.013 F152
G1 X88.238 Y229.992 F152
G1 X88.265 Y229.934 F152
G1 X88.285 Y229.891 F152
G1 X88.292 Y229.877 F152
G1 X88.319 Y229.82 F152
G1 X88.342 Y229.77 F152
G1 X88.346 Y229.762 F152
G1 X88.4 Y229.648 F152
G1 Y229.647 F152
G1 X88.428 Y229.591 F152
G1 X88.457 Y229.533 F152
G1 Y229.532 F152
G1 X88.485 Y229.476 F152
G1 X88.514 Y229.417 F152
G1 X88.628 Y229.19 F152
G1 X88.629 Y229.187 F152
G1 X88.656 Y229.132 F152
G1 X88.685 Y229.075 F152
G1 X88.686 Y229.072 F152
G1 X88.715 Y229.018 F152
G1 X88.744 Y228.961 F152
G1 X88.775 Y228.903 F152
G1 X88.801 Y228.853 F152
G1 X88.804 Y228.846 F152
G1 X88.835 Y228.789 F152
G1 X88.858 Y228.743 F152
G1 X88.864 Y228.731 F152
G1 X88.895 Y228.674 F152
G1 X88.915 Y228.634 F152
G1 X88.924 Y228.617 F152
G1 X88.955 Y228.56 F152
G1 X88.972 Y228.525 F152
G1 X88.985 Y228.502 F152
G1 X89.014 Y228.445 F152
G1 X89.03 Y228.416 F152
G1 X89.046 Y228.388 F152
G1 X89.108 Y228.273 F152
G1 X89.141 Y228.216 F152
G1 X89.144 Y228.209 F152
G1 X89.172 Y228.159 F152
G1 X89.202 Y228.104 F152
G1 X89.203 Y228.101 F152
G1 X89.235 Y228.044 F152
G1 X89.259 Y228 F152
G1 X89.266 Y227.987 F152
G1 X89.298 Y227.93 F152
G1 X89.316 Y227.896 F152
G1 X89.33 Y227.872 F152
G1 X89.361 Y227.815 F152
G1 X89.373 Y227.793 F152
G1 X89.394 Y227.758 F152
G1 X89.427 Y227.7 F152
G1 X89.431 Y227.693 F152
G1 X89.46 Y227.643 F152
G1 X89.492 Y227.586 F152
G1 X89.592 Y227.414 F152
G1 X89.603 Y227.395 F152
G1 X89.625 Y227.357 F152
G1 X89.658 Y227.299 F152
G1 X89.66 Y227.296 F152
G1 X89.691 Y227.242 F152
G1 X89.717 Y227.197 F152
G1 X89.759 Y227.128 F152
G1 X89.829 Y227.013 F152
G1 X89.832 Y227.008 F152
G1 X89.889 Y226.913 F152
G1 X89.898 Y226.899 F152
G1 X89.933 Y226.841 F152
G1 X89.946 Y226.819 F152
G1 X89.968 Y226.784 F152
G1 X90.002 Y226.727 F152
G1 X90.004 Y226.724 F152
G1 X90.037 Y226.669 F152
G1 X90.061 Y226.63 F152
G1 X90.072 Y226.612 F152
G1 X90.108 Y226.555 F152
G1 X90.118 Y226.539 F152
G1 X90.144 Y226.498 F152
G1 X90.18 Y226.44 F152
G1 X90.217 Y226.383 F152
G1 X90.233 Y226.357 F152
G1 X90.253 Y226.326 F152
G1 X90.29 Y226.268 F152
G1 X90.328 Y226.211 F152
G1 X90.347 Y226.181 F152
G1 X90.365 Y226.154 F152
G1 X90.403 Y226.097 F152
G1 X90.405 Y226.093 F152
G1 X90.462 Y226.007 F152
G1 X90.479 Y225.982 F152
G1 X90.517 Y225.925 F152
G1 X90.519 Y225.923 F152
G1 X90.557 Y225.868 F152
G1 X90.576 Y225.838 F152
G1 X90.595 Y225.81 F152
G1 X90.634 Y225.756 F152
G1 X90.635 Y225.753 F152
G1 X90.676 Y225.696 F152
G1 X90.691 Y225.674 F152
G1 X90.716 Y225.638 F152
G1 X90.748 Y225.593 F152
G1 X90.756 Y225.581 F152
G1 X90.806 Y225.514 F152
G1 X90.883 Y225.409 F152
G1 X90.925 Y225.352 F152
G1 X90.97 Y225.295 F152
G1 X90.977 Y225.285 F152
G1 X91.014 Y225.237 F152
G1 X91.035 Y225.211 F152
G1 X91.059 Y225.18 F152
G1 X91.092 Y225.139 F152
G1 X91.105 Y225.123 F152
G1 X91.149 Y225.069 F152
G1 X91.153 Y225.066 F152
G1 X91.199 Y225.008 F152
G1 X91.207 Y225 F152
G1 X91.25 Y224.951 F152
G1 X91.301 Y224.894 F152
G1 X91.321 Y224.871 F152
G1 X91.352 Y224.837 F152
G1 X91.378 Y224.81 F152
G1 X91.407 Y224.779 F152
G1 X91.463 Y224.722 F152
G1 X91.523 Y224.665 F152
G1 X91.55 Y224.639 F152
G1 X91.586 Y224.607 F152
G1 X91.608 Y224.59 F152
G1 X91.654 Y224.55 F152
G1 X91.665 Y224.541 F152
G1 X91.722 Y224.5 F152
G1 X91.732 Y224.493 F152
G1 X91.779 Y224.462 F152
G1 X91.827 Y224.436 F152
G1 X91.837 Y224.431 F152
G1 X91.865 Y224.418 F152
G1 X91.894 Y224.408 F152
G1 X91.923 Y224.402 F152
G1 X91.951 Y224.4 F152
G1 X91.966 F152
G1 X91.98 Y224.401 F152
G1 X92.009 Y224.407 F152
G1 X92.066 Y224.423 F152
G1 X92.109 Y224.436 F152
G1 X92.123 Y224.44 F152
G1 X92.18 Y224.465 F152
G1 X92.238 Y224.489 F152
G1 X92.246 Y224.493 F152
G1 X92.295 Y224.516 F152
; MOVEMENT_LEAD_OUT
G1 X92.308 Y224.522 Z-6.013 F152
G1 X92.319 Y224.527 Z-6.005 F152
G1 X92.326 Y224.531 Z-5.993 F152
G1 X92.329 Y224.532 Z-5.979 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X135.776 Y151.734 F152
G1 Z0.937 F152
; MOVEMENT_PLUNGE
G1 Z-5.955 F51
; MOVEMENT_LEAD_IN
G1 X135.779 Y151.733 Z-5.973 F152
G1 X135.788 Y151.731 Z-5.988 F152
G1 X135.802 Y151.728 Z-5.999 F152
G1 X135.818 Y151.724 Z-6.005 F152
G1 X135.836 Y151.719 Z-6.004 F152
; MOVEMENT_CUTTING
G1 X135.846 Y151.717 Z-5.935 F152
G1 X135.861 Y151.712 Z-5.848 F152
G1 X135.918 Y151.698 Z-5.482 F152
G1 X135.926 Y151.695 Z-5.434 F152
G1 X135.933 Y151.692 Z-5.381 F152
G1 X135.94 Y151.691 Z-5.336 F152
G1 X135.954 Y151.687 Z-5.232 F152
G1 X135.961 Y151.684 Z-5.179 F152
G1 X135.968 Y151.683 Z-5.123 F152
G1 X135.983 Y151.677 Z-5.015 F152
G1 X135.99 Y151.675 Z-4.959 F152
G1 X136.004 Y151.67 Z-4.851 F152
G1 X136.011 Y151.668 Z-4.792 F152
G1 X136.018 Y151.666 Z-4.733 F152
G1 X136.025 Y151.664 Z-4.672 F152
G1 X136.033 Y151.661 Z-4.613 F152
G1 X136.04 Y151.659 Z-4.552 F152
G1 X136.047 Y151.657 Z-4.493 F152
G1 X136.054 Y151.654 Z-4.433 F152
G1 X136.068 Y151.648 Z-4.305 F152
G1 X136.076 Y151.647 Z-4.241 F152
G1 X136.083 Y151.644 Z-4.177 F152
G1 X136.09 Y151.642 Z-4.112 F152
G1 X136.099 Y151.639 Z-4.023 F152
G1 X136.101 Y151.638 Z-4.011 F152
G1 X136.102 Z-4 F152
G1 X136.104 Y151.637 Z-3.976 F152
G1 X136.109 Y151.635 Z-3.934 F152
; MOVEMENT_LEAD_OUT
G1 Z-3.928 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X142.164 Y152.856 F152
G1 Z0.937 F152
; MOVEMENT_PLUNGE
G1 Z-5.958 F51
; MOVEMENT_LEAD_IN
G1 X142.167 Y152.854 Z-5.975 F152
G1 X142.173 Y152.848 Z-5.99 F152
G1 X142.184 Y152.84 Z-6.001 F152
G1 X142.197 Y152.83 Z-6.007 F152
G1 X142.21 Y152.819 F152
; MOVEMENT_CUTTING
G1 X142.212 Y152.817 Z-5.991 F152
G1 X142.227 Y152.805 Z-5.875 F152
G1 X142.234 Y152.798 Z-5.808 F152
G1 X142.248 Y152.785 Z-5.683 F152
G1 X142.254 Y152.781 Z-5.638 F152
G1 X142.262 Y152.773 Z-5.558 F152
G1 X142.277 Y152.76 Z-5.434 F152
G1 X142.284 Y152.753 Z-5.363 F152
G1 X142.313 Y152.728 Z-5.114 F152
G1 X142.317 Y152.723 Z-5.07 F152
G1 X142.326 Y152.715 Z-4.984 F152
G1 X142.334 Y152.708 Z-4.905 F152
G1 X142.341 Y152.701 Z-4.829 F152
G1 X142.363 Y152.682 Z-4.624 F152
G1 X142.372 Y152.674 Z-4.537 F152
G1 X142.38 Y152.666 Z-4.451 F152
G1 X142.384 Y152.663 Z-4.412 F152
G1 X142.391 Y152.655 Z-4.331 F152
G1 X142.399 Y152.649 Z-4.256 F152
G1 X142.406 Y152.642 Z-4.173 F152
G1 X142.42 Y152.629 Z-4.023 F152
G1 X142.427 Y152.622 Z-3.94 F152
G1 X142.436 Y152.614 Z-3.843 F152
G1 X142.438 Y152.612 Z-3.82 F152
G1 X142.441 Y152.609 Z-3.778 F152
; MOVEMENT_LEAD_OUT
G1 X142.442 Z-3.772 F152
; MOVEMENT_CUTTING
G1 Z15.24 F152
; *** SECTION end ***
;
; *** STOP begin ***
M400
; COMMAND_COOLANT_OFF
; ---- Coolant: Off cur: Off A: Off B: Off
G0 X0 Y0 F4470
; COMMAND_STOP_SPINDLE
M300 S300 P3000
M0 Turn OFF spindle
M117 Job end
; *** STOP end ***
