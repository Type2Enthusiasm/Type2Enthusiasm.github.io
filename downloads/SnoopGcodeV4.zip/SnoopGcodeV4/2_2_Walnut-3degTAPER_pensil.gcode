; parseSafeZProperty: safeZMode = 'Retract'
; parseSafeZProperty: safeZHeightDefault = 15
; param: product-id = fusion360
;Fusion CAM 2602.1.25
; Posts processor: MPCNC v3.0 Beta 1.cps
; Gcode generated: Sun Aug 10 03:19:29 2025 GMT
; param: hostname = Harrisons-MacBook-Air.local
; param: username = harrisonesterly
; Document: snoop2 v16
; param: document-id = cdd3c627-a981-4b59-b2d6-a8cf2a6a6479
; param: model-version = 1b7ac768-0c1f-4280-92ec-74a9411570f3
; param: leads-supported = 1
; Setup: Setup4
; param: machine-id = 1
; param: machine-v2 = {
   "controller" : {
      "default" : {
         "head_info_part_id" : "head",
         "max_block_processing_speed" : 118,
         "max_normal_speed" : 4000.0000000000005,
         "non_tcp_rapid_interpolation_mode" : "Unsynchronized",
         "parts" : {
            "X" : {
               "coordinate" : 0,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Y" : {
               "coordinate" : 1,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Z" : {
               "coordinate" : 2,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            }
         },
         "table_part_id" : "table",
         "tcp_rapid_interpolation_mode" : "ToolTip"
      }
   },
   "general" : {
      "capabilities" : [ "milling" ],
      "description" : "Generic 3-axis",
      "minimumRevision" : 45805,
      "vendor" : "MP_CNC"
   },
   "interactions" : {
      "default" : {
         "pairs" : [
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            }
         ]
      }
   },
   "kinematics" : {
      "default" : {
         "conventions" : {
            "rotation" : "right-handed"
         },
         "parts" : [
            {
               "control" : "driven",
               "direction" : [ -1, 0, 0 ],
               "id" : "X",
               "max" : 289.99999999999994,
               "min" : 289.99999999999994,
               "name" : "X",
               "parts" : [
                  {
                     "control" : "driven",
                     "direction" : [ 0, -1, 0 ],
                     "id" : "Y",
                     "name" : "Y",
                     "parts" : [
                        {
                           "control" : "driven",
                           "direction" : [ 0, 0, -1 ],
                           "id" : "Z",
                           "max" : 0,
                           "min" : 0,
                           "name" : "Z",
                           "parts" : [
                              {
                                 "attach_frame" : {
                                    "point" : [ 0, 0, 0 ],
                                    "x_direction" : [ 1, 0, 0 ],
                                    "z_direction" : [ 0, 0, 1 ]
                                 },
                                 "display_name" : "table",
                                 "id" : "table",
                                 "type" : "table"
                              }
                           ],
                           "type" : "linear"
                        }
                     ],
                     "type" : "linear"
                  }
               ],
               "type" : "linear"
            },
            {
               "attach_frame" : {
                  "point" : [ 0, 0, 0 ],
                  "x_direction" : [ 1, 0, 0 ],
                  "z_direction" : [ 0, 0, 1 ]
               },
               "display_name" : "head",
               "id" : "head",
               "spindle" : {
                  "max_speed" : 0,
                  "min_speed" : 0
               },
               "tool_station" : {
                  "coolants" : null,
                  "max_tool_diameter" : 0,
                  "max_tool_length" : 0
               },
               "type" : "head"
            }
         ],
         "units" : {
            "angle" : "degrees",
            "length" : "mm"
         }
      }
   },
   "machining" : {
      "default" : {
         "feedrate_ratio" : 1,
         "tool_change_time" : 15
      }
   },
   "post" : {
      "default" : {
         "output_folder" : "/Users/harrisonesterly/Desktop/LIFE/Projects/MPCNC/fusion_GCode",
         "path" : "user://MPCNC.cps"
      }
   },
   "tooling" : {
      "default" : {
         "has_tool_changer" : false,
         "number_of_tools" : 100,
         "supports_tool_preload" : true
      }
   }
}


; param: stock-type = box
; param: stock = 0, 0, -26.496, 109.982, 150.241, 0
; param: stock-lower-x = 0
; param: stock-lower-y = 0
; param: stock-lower-z = -26.496
; param: stock-upper-x = 109.98200000000008
; param: stock-upper-y = 150.24076554149076
; param: stock-upper-z = 0
; param: part-lower-x = 1.0160000000000196
; param: part-lower-y = 1.016
; param: part-lower-z = -26.496
; param: part-upper-x = 108.96600000000007
; param: part-upper-y = 149.22476554149077
; param: part-upper-z = -1.016
; param: areBothSpindlesGrabbed = 0
; param: notes = 
; param: operation-strategy = pencil_new
; param: autodeskcam:operation-id = 37
; param: leads-supported = 1
; param: autodeskcam:path = Setups\Setup4\Pencil2 2
; param: operation:is2DStrategy = 0
; param: operation:is3DStrategy = 1
; param: operation:isRoughingStrategy = 0
; param: operation:isFinishingStrategy = 1
; param: operation:isMillingStrategy = 1
; param: operation:isTurningStrategy = 0
; param: operation:isJetStrategy = 0
; param: operation:isAdditiveStrategy = 0
; param: operation:isProbingStrategy = 0
; param: operation:isInspectionStrategy = 0
; param: operation:isDrillingStrategy = 0
; param: operation:isHoleMillingStrategy = 0
; param: operation:isThreadStrategy = 0
; param: operation:isSamplingStrategy = 0
; param: operation:isRotaryStrategy = 0
; param: operation:isSubspindleStrategy = 0
; param: operation:isSurfaceStrategy = 1
; param: operation:isCheckSurfaceStrategy = 1
; param: operation:isMultiAxisStrategy = 0
; param: operation:advancedMode = 0
; param: operation:betaMode = 0
; param: operation:alphaMode = 0
; param: operation:isXpress = 0
; param: operation:licenseMultiaxis = 1
; param: operation:license3D = 1
; param: operation:metric = 0
; param: operation:isAssemblyDocument = 1
; param: operation:context = operation
; param: operation:strategy = pencil_new
; param: operation:operation_description = 
; param: operation:tool_type = tapered mill
; param: operation:undercut = 0
; param: operation:tool_isTurning = 0
; param: operation:tool_isMill = 1
; param: operation:tool_isDrill = 0
; param: operation:tool_isJet = 0
; param: operation:tool_isDepositing = 0
; param: operation:tool_taperedType = tapered_bull_nose
; param: operation:tool_unit = millimeters
; param: operation:tool_number = 1
; param: operation:tool_diameterOffset = 1
; param: operation:tool_lengthOffset = 1
; param: operation:tool_compensationOffset = 1
; param: operation:tool_turret = 0
; param: operation:tool_manualToolChange = 0
; param: operation:tool_breakControl = 0
; param: operation:tool_live = 1
; param: operation:tool_material = carbide
; param: operation:tool_description = 46473 CNC 2D and 3D Carving 6.2 Deg Tapered Angle Ball Tip x 0.5mm Dia x 0.25mm Radius x 26.5mm x 6mm Shank x 75mm Long x 3 Flute Up-Cut Spiral Solid Carbide ZrN Coated
; param: operation:tool_comment = 
; param: operation:tool_vendor = Amana Tool
; param: operation:tool_productId = 46473
; param: operation:tool_productLink = https://www.amanatool.com/46473-cnc-2d-and-3d-carving-6-2-deg-tapered-angle-ball-tip-x-0-5mm-dia-x-0-25mm-radius-x-26-5mm-x-6mm-shank-x-75mm-long-x-3-flute-up-cut-spiral-solid-carbide-zrn-coated.html
; param: operation:tool_diameter = 0.5
; param: operation:tool_maximumCuttingDiameter = 0
; param: operation:tool_tipDiameter = 0
; param: operation:tool_tipOffset = 0
; param: operation:tool_cornerRadius = 0.25
; param: operation:tool_inclusiveAngle = 0
; param: operation:tool_taperAngle = 6.2
; param: operation:tool_tipAngle = 0
; param: operation:tool_threadTipType = point
; param: operation:tool_threadTipWidth = 0
; param: operation:tool_threadTipRadius = 0
; param: operation:tool_threadProfileAngle = 0
; param: operation:tool_tipLength = 0
; param: operation:tool_fluteLength = 26.5
; param: operation:tool_shoulderLength = 26.5
; param: operation:tool_bodyLength = 40
; param: operation:tool_overallLength = 75
; param: operation:tool_shaftDiameter = 6
; param: operation:tool_segmentHeight = 3
; param: operation:tool_segmentDiameterLower = 12
; param: operation:tool_segmentDiameterUpper = 12
; param: operation:tool_shaftSegmentHeight = 6.75
; param: operation:tool_shaftSegmentDiameterLower = 0.5
; param: operation:tool_shaftSegmentDiameterUpper = 6
; param: operation:tool_threadPitch = 0
; param: operation:tool_maximumThreadPitch = 0
; param: operation:tool_minimumThreadPitch = 0
; param: operation:tool_numberOfTeeth = 0
; param: operation:tool_numberOfFlutes = 3
; param: operation:tool_shoulderDiameter = 6.257643000000001
; param: operation:tool_upperRadius = 1.016
; param: operation:tool_profileRadius = 101.6
; param: operation:tool_lowerRadius = 1.016
; param: operation:tool_axialDistance = 1.016
; param: operation:tool_chamferWidth = 1.016
; param: operation:tool_chamferAngle = 45
; param: operation:holder_attached = 0
; param: operation:holder_description = 
; param: operation:holder_comment = 
; param: operation:holder_vendor = 
; param: operation:holder_productId = 
; param: operation:holder_productLink = 
; param: operation:holder_libraryName = 
; param: operation:tool_holderGaugeLength = 0
; param: operation:tool_assemblyGaugeLength = 40
; param: operation:tool_spindleSpeed = 18000
; param: operation:tool_stockDiameter = 0.5
; param: operation:tool_surfaceSpeed = 28274.33388230814
; param: operation:tool_rampSpindleSpeed = 18000
; param: operation:tool_feedCutting = 152.39999999999998
; param: operation:tool_feedPerTooth = 0.0028222222222222216
; param: operation:tool_feedEntry = 152.39999999999998
; param: operation:tool_feedExit = 152.39999999999998
; param: operation:tool_feedTransition = 152.39999999999998
; param: operation:tool_feedRamp = 50.79999999999999
; param: operation:tool_feedPlunge = 50.79999999999999
; param: operation:tool_feedPerRevolution = 0.0028222222222222216
; param: operation:tool_feedRetract = 50.79999999999999
; param: operation:tool_clockwise = 1
; param: operation:tool_coolant = disabled
; param: operation:featureOperationId = none
; param: operation:surfaceZHigh = -1.016
; param: operation:surfaceZLow = -26.496
; param: operation:surfaceXLow = 1.01600000000002
; param: operation:surfaceXHigh = 108.96600000000008
; param: operation:surfaceYLow = 1.016
; param: operation:surfaceYHigh = 149.22476554149074
; param: operation:stockZHigh = 0
; param: operation:stockZLow = -26.496
; param: operation:stockXLow = 0
; param: operation:stockXHigh = 109.98200000000008
; param: operation:stockYLow = 0
; param: operation:stockYHigh = 150.24076554149073
; param: operation:shaftAndHolderMode = dont care
; param: operation:useShaft = 0
; param: operation:shaftClearance = 1.016
; param: operation:useHolder = 0
; param: operation:holderClearance = 5.08
; param: operation:multiAxisMachiningType = three_axis
; param: operation:view_orientation_mode = useWCS
; param: operation:view_orientation_flipZ = 0
; param: operation:view_orientation_axesZX_unselected_default = wcs
; param: operation:view_orientation_axesZY_unselected_default = wcs
; param: operation:view_orientation_axesXY_unselected_default = wcs
; param: operation:view_select_angles = turn_and_tilt
; param: operation:view_turn_from_recipe = 0
; param: operation:view_tilt_from_recipe = 0
; param: operation:view_orientation_flipX = 0
; param: operation:view_orientation_flipY = 0
; param: operation:view_origin_mode = jobOrigin
; param: operation:view_origin_boxPoint = top center
; param: operation:show_machine = 0
; param: operation:multiAxisRotaryAxis_orientation_mode = axisZ
; param: operation:multiAxisRotaryAxis_origin_mode = jobOrigin
; param: operation:toolAxisMode = vertical
; param: operation:leadAngle = 0
; param: operation:leanAngle = 0
; param: operation:multiAxisTiltAngleFixed = 0
; param: operation:toolAxisLimitReferenceZ = setup
; param: operation:smoothingDistance = 1
; param: operation:smoothingAngle = 5
; param: operation:tiltAngle = 0
; param: operation:applyMicroTilt = 1
; param: operation:tiltToolMode = automatic
; param: operation:maximumTiltValidation = 180
; param: operation:minimumTilt5Axis = 0
; param: operation:maximumTilt5Axis = 90
; param: operation:tiltLimitMode = remove_toolpath
; param: operation:usePolarWhenNecessary = 0
; param: operation:polarMode = automatic
; param: operation:polarLineAngle = 0
; param: operation:boundaryMode = selection
; param: operation:useSilhouetteAsMachiningBoundary = 0
; param: operation:silhouetteAperture = 2.5
; param: operation:minimumSilhouetteArea = 0.009817477042468103
; param: operation:boundaryContainment = center
; param: operation:boundaryOffset = 0
; param: operation:machiningBoundaryOffset = 0
; param: operation:boundaryConfineTool = 0
; param: operation:contactOnly = 1
; param: operation:slopeAngleFrom = 0
; param: operation:slopeAngleTo = 90
; param: operation:restMaterialSource = previousOperations
; param: operation:restMaterialFromJob = 0
; param: operation:restMaterialOperation = 0
; param: operation:restMaterialUnion = 1
; param: operation:restMaterialPrevious = 1
; param: operation:restMaterialCutterDiameter = 1
; param: operation:restMaterialCornerRadius = 0.5
; param: operation:restMaterialTaperAngle = 0
; param: operation:restMaterialShoulderLength = 0
; param: operation:restMaterialResolution = 1.016
; param: operation:restMaterialOverlap = 0.05
; param: operation:restMaterialFile = 
; param: operation:restMaterialTool = 
; param: operation:restMaterialAdjustment = use as computed
; param: operation:restMaterialAdjustmentOffset = -0.02032
; param: operation:ignoreStockLessThan = 0.02032
; param: operation:includeSetupModel = 1
; param: operation:touchAvoidMode = avoid
; param: operation:viewAbsoluteClearances = 0
; param: operation:radialClearanceInfo = 0
; param: operation:axialClearanceInfo = 0
; param: operation:clearanceInfo = 0
; param: operation:checkSurfaceClearance = 0.01016
; param: operation:trimCheckSurfaces = 0
; param: operation:isClearanceAreaEnabled = 0
; param: operation:clearanceAreaType = plane
; param: operation:clearanceArea_orientation_mode = toolAxisZ
; param: operation:clearanceArea_orientation_flipAxis = 0
; param: operation:clearanceArea_origin_mode = jobOrigin
; param: operation:clearanceArea_origin_boxPoint = top center
; param: operation:clearanceHeight_mode = from retract height
; param: operation:clearanceHeightFromHighest_checkStock = top
; param: operation:clearanceHeightFromLowest_checkStock = bottom
; param: operation:clearanceHeightFromHighest_checkModel = top
; param: operation:clearanceHeightFromLowest_checkModel = bottom
; param: operation:clearanceHeightFromHighest_checkFixture = top
; param: operation:clearanceHeightFromLowest_checkFixture = bottom
; param: operation:clearanceHeight_offset = 10.16
; param: operation:clearanceHeight_value = 15.239999999999998
; param: operation:zClearance = 15.239999999999998
; param: operation:relativeZClearance = 15.239999999999998
; param: operation:clearanceHeight_absolute = 1
; param: operation:clearanceAreaHeight_mode = from retract height
; param: operation:clearanceAreaHeightFromHighest_checkStock = top
; param: operation:clearanceAreaHeightFromLowest_checkStock = bottom
; param: operation:clearanceAreaHeightFromHighest_checkModel = top
; param: operation:clearanceAreaHeightFromLowest_checkModel = bottom
; param: operation:clearanceAreaHeightFromHighest_checkFixture = top
; param: operation:clearanceAreaHeightFromLowest_checkFixture = bottom
; param: operation:clearanceAreaHeight_offset = 10.16
; param: operation:clearanceAreaHeight_value = 0
; param: operation:clearanceAreaHeight_absolute = 0
; param: operation:clearanceAreaCylinderRadius_mode = from retract radius
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkStock = outer diameter
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkModel = outer diameter
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkFixture = outer diameter
; param: operation:clearanceAreaCylinderRadius_offset = 10.16
; param: operation:clearanceAreaCylinderRadius_direct = 2.032
; param: operation:clearanceAreaCylinderRadius_value = 1.016
; param: operation:clearanceAreaCylinderRadius_absolute = 0
; param: operation:clearanceAreaSphereRadius_mode = from retract radius
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkStock = outer diameter
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkModel = outer diameter
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkFixture = outer diameter
; param: operation:clearanceAreaSphereRadius_offset = 10.16
; param: operation:clearanceAreaSphereRadius_direct = 2.032
; param: operation:clearanceAreaSphereRadius_value = 1.016
; param: operation:clearanceAreaSphereRadius_absolute = 0
; param: operation:retractHeight_mode = from stock top
; param: operation:retractHeightFromHighest_checkStock = top
; param: operation:retractHeightFromLowest_checkStock = bottom
; param: operation:retractHeightFromHighest_checkModel = top
; param: operation:retractHeightFromLowest_checkModel = bottom
; param: operation:retractHeightFromHighest_checkFixture = top
; param: operation:retractHeightFromLowest_checkFixture = bottom
; param: operation:retractHeight_offset = 5.08
; param: operation:retractHeight_value = 5.08
; param: operation:zRetract = 5.08
; param: operation:relativeZRetract = 5.08
; param: operation:retractHeight_absolute = 1
; param: operation:retractAreaType = plane
; param: operation:retractAreaHeight_mode = from stock top
; param: operation:retractAreaHeightFromHighest_checkStock = top
; param: operation:retractAreaHeightFromLowest_checkStock = bottom
; param: operation:retractAreaHeightFromHighest_checkModel = top
; param: operation:retractAreaHeightFromLowest_checkModel = bottom
; param: operation:retractAreaHeightFromHighest_checkFixture = top
; param: operation:retractAreaHeightFromLowest_checkFixture = bottom
; param: operation:retractAreaHeight_offset = 5.08
; param: operation:retractAreaHeight_value = 0
; param: operation:retractAreaHeight_absolute = 1
; param: operation:retractAreaCylinderRadius_mode = from stock od
; param: operation:retractAreaCylinderRadiusFromOutermost_checkStock = outer diameter
; param: operation:retractAreaCylinderRadiusFromOutermost_checkModel = outer diameter
; param: operation:retractAreaCylinderRadiusFromOutermost_checkFixture = outer diameter
; param: operation:retractAreaCylinderRadius_offset = 5.08
; param: operation:retractAreaCylinderRadius_direct = 2.032
; param: operation:retractAreaCylinderRadius_value = 1.016
; param: operation:retractAreaCylinderRadius_absolute = 0
; param: operation:retractAreaSphereRadius_mode = from stock od
; param: operation:retractAreaSphereRadiusFromOutermost_checkStock = outer diameter
; param: operation:retractAreaSphereRadiusFromOutermost_checkModel = outer diameter
; param: operation:retractAreaSphereRadiusFromOutermost_checkFixture = outer diameter
; param: operation:retractAreaSphereRadius_offset = 5.08
; param: operation:retractAreaSphereRadius_direct = 2.032
; param: operation:retractAreaSphereRadius_value = 1.016
; param: operation:retractAreaSphereRadius_absolute = 0
; param: operation:topHeight_mode = from stock top
; param: operation:topHeightFromHighest_checkStock = top
; param: operation:topHeightFromLowest_checkStock = bottom
; param: operation:topHeightFromHighest_checkModel = ignore
; param: operation:topHeightFromLowest_checkModel = ignore
; param: operation:topHeightFromHighest_checkFixture = ignore
; param: operation:topHeightFromLowest_checkFixture = ignore
; param: operation:topHeight_offset = 0
; param: operation:topHeight_value = 0
; param: operation:topHeight_absolute = 1
; param: operation:bottomHeight_mode = from surface bottom
; param: operation:bottomHeightFromHighest_checkStock = bottom
; param: operation:bottomHeightFromLowest_checkStock = ignore
; param: operation:bottomHeightFromHighest_checkModel = bottom
; param: operation:bottomHeightFromLowest_checkModel = bottom
; param: operation:bottomHeightFromHighest_checkFixture = ignore
; param: operation:bottomHeightFromLowest_checkFixture = ignore
; param: operation:bottomHeight_offset = 0
; param: operation:bottomHeight_value = -26.496
; param: operation:bottomHeight_absolute = 1
; param: operation:tolerance = 0.01016
; param: operation:contourTolerance = 0.00508
; param: operation:totalSurfaceTolerance = 0.00508
; param: operation:surfaceTriangulationTolerance = 0.00508
; param: operation:calculationTolerance = 0.00508
; param: operation:thinningTolerance = 0.0000508
; param: operation:chainingTolerance = 0.01016
; param: operation:gougingTolerance = 0.00508
; param: operation:overthickness = 0
; param: operation:bitangentAngle = 20
; param: operation:internalPasses = 1
; param: operation:linkInsideOut = 0
; param: operation:linkInsideOutside = outside-in
; param: operation:limitNumberOfStepovers = 1
; param: operation:numberOfStepovers = 0
; param: operation:stepover = 0.25
; param: operation:cuspHeightStepover = 0.07322000000000001
; param: operation:minimumFragmentLength = 0.050800000000000005
; param: operation:fragmentExtensionDistance = 0
; param: operation:direction = both ways
; param: operation:upDownMilling = dont care
; param: operation:upDownMillingShallowAngle = 1
; param: operation:manualProfileDiameter = 0
; param: operation:minimumProfileDiameter = 0
; param: operation:stockToLeave = 0
; param: operation:verticalStockToLeave = 0
; param: operation:simpleStockToLeave = 0
; param: operation:filletsCornerRadius = 0
; param: operation:legacyFillets = 1
; param: operation:useCombinedFilter = 1
; param: operation:useDMKSmoothing = 0
; param: operation:smoothingFilterMode = redistribute
; param: operation:smoothingFilterMaxSpacing = 0.508
; param: operation:smoothingFilterMaxAngle = 3
; param: operation:smoothingFilterToleranceForEvenlySpacedPoints = 0.00508
; param: operation:smoothingFilterToleranceFactor = 0.5
; param: operation:smoothingFilterTolerance = 0
; param: operation:reducedFeedChange = 25
; param: operation:reducedFeedRadius = 0
; param: operation:reducedFeedDistance = 0
; param: operation:reducedFeedrate = 38.099999999999994
; param: operation:reduceOnlyInnerCorners = 1
; param: operation:surfaceSpeedOnArcs = 0
; param: operation:maximumReducedFeedrateInternalArcFinishing = 100
; param: operation:maximumIncreasedFeedrateExternalArcFinishing = 100
; param: operation:maximumReducedFeedrateInternalArc = 100
; param: operation:maximumIncreasedFeedrateExternalArc = 100
; param: operation:retractionPolicy = full
; param: operation:highFeedrateMode = disabled
; param: operation:highFeedrate = 152.39999999999998
; param: operation:allowRapidRetract = 1
; param: operation:safeDistance = 2.032
; param: operation:stayDownDistance = 2.5
; param: operation:entry_verticalRadius = 0.05
; param: operation:leadInRadius = 0.05
; param: operation:leadInVerticalRadius = 0.05
; param: operation:exit_verticalRadius = 0.05
; param: operation:leadOutRadius = 0.05
; param: operation:leadOutVerticalRadius = 0.05
; param: operation:transitionType = curve
; param: operation:isOperationTemplate = 0
; param: operation:use_tool_stepdown = 0
; param: operation:tool_stepdown = 23.85
; param: operation:tool_finishingStepdown = 0.2032
; param: operation:use_tool_stepover = 0
; param: operation:tool_stepover = 0.15
; param: operation:tool_finishingStepover = 0.05
; param: operation:tool_rampType = helix
; param: operation:tool_rampAngle = 2
;When using Fusion for Personal Use, the feedrate of rapid
;moves is reduced to match the feedrate of cutting moves,
;which can increase machining time. Unrestricted rapid moves
;are available with a Fusion Subscription.
; param: movement:lead_in = 152.39999999999998
; param: movement:cutting = 152.39999999999998
; param: movement:lead_out = 152.39999999999998
; param: movement:transition = 152.39999999999998
; param: movement:direct = 152.39999999999998
; param: movement:helix_ramp = 50.79999999999999
; param: movement:profile_ramp = 50.79999999999999
; param: movement:zigzag_ramp = 50.79999999999999
; param: movement:ramp = 50.79999999999999
; param: movement:plunge = 50.79999999999999
; param: movement:predrill = 152.39999999999998
; param: movement:extended = 152.39999999999998
; param: movement:reduced = 152.39999999999998
; param: movement:finish_cutting = 152.39999999999998
; param: movement:high_feed = 152.39999999999998
; param: movement:depositing = 0
; param: movement:connection = 0
; param: movement:drill_breakthrough = 0
; param: movement:gun_drill_positioning = 0
; 
; Ranges Table:
;   X: Min=7.366 Max=108.995 Size=101.629
;   Y: Min=6.09 Max=139.583 Size=133.492
;   Z: Min=-8.097 Max=15.24 Size=23.337
; 
; Tools Table:
;  T1 D=0.5 CR=0.25 TAPER=6.2deg - ZMIN=-8.097 - tapered mill 
; 
; Feedrate and Scaling Properties:
;   Feed: Travel speed X/Y = 4470
;   Feed: Travel Speed Z = 2235
;   Feed: Enforce Feedrate = true
;   Feed: Scale Feedrate = false
;   Feed: Max XY Cut Speed = 1000
;   Feed: Max Z Cut Speed = 400
;   Feed: Max Toolpath Speed = 1000
; 
; G1->G0 Mapping Properties:
;   Map: First G1 -> G0 Rapid = false
;   Map: G1s -> G0 Rapids = false
;   Map: SafeZ Mode = Retract : default = 15
;   Map: Allow Rapid Z = false
; 
; *** START begin ***
;   Set Absolute Positioning
;   Units = mm
G90
G21
;   Disable stepper timeout
M84 S0
;   Set current position to 0,0,0
G92 X0 Y0 Z0
; *** START end ***
; 
; *** SECTION begin ***
;   X Min: 7.366 - X Max: 108.995
;   Y Min: 6.09 - Y Max: 139.583
;   Z Min: -8.097 - Z Max: 15.24
; Pencil2 2 - Milling - Tool: 1 -  tapered mill
; COMMAND_START_SPINDLE
; COMMAND_SPINDLE_CLOCKWISE
; >>> Spindle Speed: Manual
M0 Turn ON 18000RPM
; COMMAND_COOLANT_ON
;   tool.coolant = 0 strCoolant = Off
; ---- Coolant: Off cur: Off A: Off B: Off
M117  Pencil2 (2)
; MOVEMENT_CUTTING
G1 X55.355 Y52.647 Z15.24 F152
G1 Z1.016 F152
; MOVEMENT_PLUNGE
G1 Z-0.978 F51
; MOVEMENT_LEAD_IN
G1 X55.357 Y52.649 Z-0.995 F152
G1 X55.364 Y52.653 Z-1.009 F152
G1 X55.375 Y52.659 Z-1.021 F152
G1 X55.389 Y52.667 Z-1.027 F152
; MOVEMENT_CUTTING
G1 X55.417 Y52.683 Z-1.034 F152
G1 X55.446 Y52.698 Z-1.043 F152
G1 X55.503 Y52.728 Z-1.062 F152
G1 X55.557 Y52.756 Z-1.084 F152
G1 X55.561 Y52.758 Z-1.085 F152
G1 X55.618 Y52.788 Z-1.115 F152
G1 X55.664 Y52.813 Z-1.146 F152
G1 X55.675 Y52.82 Z-1.156 F152
G1 X55.704 Y52.835 Z-1.183 F152
G1 X55.718 Y52.842 Z-1.203 F152
G1 X55.732 Y52.85 Z-1.23 F152
G1 X55.747 Y52.857 Z-1.284 F152
G1 X55.761 Y52.865 Z-1.334 F152
G1 X55.772 Y52.871 Z-1.376 F152
G1 X55.79 Y52.88 Z-1.439 F152
G1 X55.804 Y52.889 Z-1.489 F152
G1 X55.818 Y52.896 Z-1.545 F152
G1 X55.833 Y52.904 Z-1.595 F152
G1 X55.847 Y52.911 Z-1.65 F152
G1 X55.864 Y52.92 Z-1.71 F152
G1 X55.879 Y52.928 Z-1.767 F152
G1 X55.904 Y52.941 Z-1.853 F152
G1 X55.919 Y52.949 Z-1.905 F152
G1 X55.933 Y52.957 Z-1.951 F152
G1 X55.947 Y52.964 Z-2.003 F152
G1 X55.962 Y52.972 Z-2.05 F152
G1 X55.988 Y52.985 Z-2.141 F152
G1 X56.003 Y52.994 Z-2.191 F152
G1 X56.019 Y53.002 Z-2.246 F152
G1 X56.033 Y53.009 Z-2.298 F152
G1 X56.047 Y53.017 Z-2.345 F152
G1 X56.062 Y53.025 Z-2.397 F152
G1 X56.076 Y53.033 Z-2.443 F152
G1 X56.096 Y53.043 Z-2.515 F152
G1 X56.115 Y53.052 Z-2.58 F152
G1 X56.133 Y53.063 Z-2.639 F152
G1 X56.162 Y53.077 Z-2.741 F152
G1 X56.176 Y53.086 Z-2.787 F152
G1 X56.191 Y53.093 Z-2.838 F152
G1 X56.204 Y53.1 Z-2.883 F152
G1 X56.219 Y53.108 Z-2.935 F152
G1 X56.234 Y53.116 Z-2.981 F152
G1 X56.248 Y53.123 Z-3.032 F152
G1 X56.262 Y53.131 Z-3.077 F152
G1 X56.291 Y53.145 Z-3.18 F152
G1 X56.305 Y53.154 Z-3.225 F152
G1 X56.312 Y53.157 Z-3.251 F152
G1 X56.334 Y53.169 Z-3.322 F152
G1 X56.348 Y53.176 Z-3.373 F152
G1 X56.363 Y53.184 Z-3.419 F152
G1 X56.391 Y53.198 Z-3.521 F152
G1 X56.405 Y53.206 Z-3.568 F152
G1 X56.422 Y53.214 Z-3.626 F152
G1 X56.448 Y53.229 Z-3.719 F152
G1 X56.463 Y53.236 Z-3.771 F152
G1 X56.477 Y53.244 Z-3.818 F152
G1 X56.491 Y53.251 Z-3.87 F152
G1 X56.506 Y53.259 Z-3.917 F152
G1 X56.531 Y53.272 Z-4.008 F152
G1 X56.534 Y53.274 Z-4.015 F152
G1 X56.563 Y53.289 Z-4.12 F152
G1 X56.577 Y53.297 Z-4.167 F152
G1 X56.592 Y53.304 Z-4.219 F152
G1 X56.606 Y53.312 Z-4.265 F152
G1 X56.62 Y53.319 Z-4.318 F152
G1 X56.639 Y53.329 Z-4.383 F152
G1 X56.649 Y53.334 Z-4.417 F152
G1 X56.663 Y53.342 Z-4.469 F152
G1 X56.678 Y53.35 Z-4.516 F152
G1 X56.706 Y53.364 Z-4.62 F152
G1 X56.721 Y53.371 Z-4.673 F152
G1 X56.735 Y53.379 Z-4.722 F152
G1 X56.75 Y53.386 Z-4.783 F152
G1 X56.763 Y53.393 Z-4.831 F152
G1 X56.778 Y53.402 Z-4.88 F152
G1 X56.806 Y53.416 Z-4.989 F152
G1 X56.821 Y53.424 Z-5.038 F152
G1 X56.86 Y53.444 Z-5.188 F152
G1 X56.878 Y53.453 Z-5.251 F152
G1 X56.907 Y53.468 Z-5.36 F152
G1 X56.921 Y53.476 Z-5.409 F152
G1 X56.953 Y53.492 Z-5.531 F152
G1 X56.97 Y53.501 Z-5.593 F152
G1 X56.993 Y53.513 Z-5.676 F152
G1 X57.007 Y53.521 Z-5.725 F152
G1 X57.036 Y53.535 Z-5.834 F152
G1 X57.05 Y53.543 Z-5.883 F152
G1 X57.065 Y53.55 Z-5.944 F152
G1 X57.079 Y53.558 Z-5.995 F152
G1 X57.093 Y53.565 Z-6.047 F152
G1 X57.107 Y53.573 Z-6.099 F152
G1 X57.121 Y53.581 Z-6.157 F152
G1 X57.136 Y53.589 Z-6.209 F152
G1 X57.236 Y53.639 Z-6.613 F152
G1 X57.25 Y53.647 Z-6.665 F152
G1 X57.302 Y53.673 Z-6.874 F152
G1 X57.319 Y53.682 Z-6.94 F152
G1 X57.336 Y53.69 Z-7.011 F152
G1 X57.351 Y53.697 Z-7.069 F152
G1 X57.365 Y53.705 Z-7.121 F152
G1 X57.433 Y53.739 Z-7.395 F152
G1 X57.451 Y53.748 Z-7.469 F152
G1 X57.465 Y53.756 Z-7.526 F152
G1 X57.479 Y53.763 Z-7.587 F152
G1 X57.494 Y53.771 Z-7.643 F152
G1 X57.508 Y53.778 Z-7.705 F152
G1 X57.525 Y53.787 Z-7.775 F152
G1 X57.537 Y53.794 Z-7.823 F152
G1 X57.551 Y53.801 Z-7.884 F152
G1 X57.565 Y53.809 Z-7.941 F152
G1 X57.58 Y53.816 Z-8.002 F152
G1 X57.594 Y53.824 Z-8.058 F152
G1 X57.601 Y53.827 Z-8.093 F152
; MOVEMENT_LINK_TRANSITION
G1 X57.603 Y53.828 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X57.605 Y53.83 F152
G1 X57.616 Y53.845 F152
G1 X57.623 Y53.853 F152
G1 X57.68 Y53.924 F152
G1 X57.709 Y53.959 F152
G1 X57.737 Y53.995 F152
G1 X57.754 Y54.017 F152
G1 X57.84 Y54.131 F152
G1 X57.884 Y54.188 F152
G1 X57.909 Y54.222 F152
G1 X57.927 Y54.246 F152
G1 X57.966 Y54.299 F152
G1 X57.97 Y54.303 F152
G1 X58.013 Y54.36 F152
G1 X58.024 Y54.376 F152
G1 X58.081 Y54.459 F152
G1 X58.093 Y54.475 F152
G1 X58.132 Y54.532 F152
G1 X58.212 Y54.647 F152
G1 X58.252 Y54.704 F152
G1 X58.253 Y54.705 F152
G1 X58.289 Y54.761 F152
G1 X58.31 Y54.795 F152
G1 X58.326 Y54.819 F152
G1 X58.363 Y54.876 F152
G1 X58.367 Y54.883 F152
G1 X58.4 Y54.933 F152
G1 X58.425 Y54.973 F152
G1 X58.436 Y54.991 F152
G1 X58.473 Y55.048 F152
G1 X58.482 Y55.062 F152
G1 X58.508 Y55.105 F152
G1 X58.539 Y55.159 F152
G1 X58.542 Y55.163 F152
G1 X58.575 Y55.22 F152
G1 X58.596 Y55.256 F152
G1 X58.609 Y55.277 F152
G1 X58.643 Y55.334 F152
G1 X58.654 Y55.353 F152
G1 X58.676 Y55.392 F152
G1 X58.709 Y55.449 F152
G1 X58.711 Y55.453 F152
G1 X58.74 Y55.506 F152
G1 X58.768 Y55.559 F152
G1 X58.771 Y55.564 F152
G1 X58.802 Y55.621 F152
G1 X58.826 Y55.666 F152
G1 X58.833 Y55.678 F152
G1 X58.863 Y55.735 F152
G1 X58.883 Y55.772 F152
G1 X58.894 Y55.793 F152
G1 X58.923 Y55.85 F152
G1 X58.94 Y55.886 F152
G1 X58.979 Y55.965 F152
G1 X58.997 Y56.002 F152
G1 X59.007 Y56.022 F152
G1 X59.035 Y56.079 F152
G1 X59.055 Y56.12 F152
G1 X59.064 Y56.137 F152
G1 X59.09 Y56.194 F152
G1 X59.142 Y56.308 F152
G1 X59.167 Y56.366 F152
G1 X59.169 Y56.369 F152
G1 X59.193 Y56.423 F152
G1 X59.219 Y56.48 F152
G1 X59.226 Y56.497 F152
G1 X59.244 Y56.538 F152
G1 X59.269 Y56.595 F152
G1 X59.284 Y56.633 F152
G1 X59.293 Y56.652 F152
G1 X59.341 Y56.771 F152
G1 X59.363 Y56.824 F152
G1 X59.387 Y56.881 F152
G1 X59.398 Y56.911 F152
G1 X59.409 Y56.939 F152
G1 X59.431 Y56.996 F152
G1 X59.451 Y57.053 F152
G1 X59.456 Y57.065 F152
G1 X59.473 Y57.111 F152
G1 X59.494 Y57.168 F152
G1 X59.513 Y57.22 F152
G1 X59.515 Y57.225 F152
G1 X59.558 Y57.34 F152
G1 X59.57 Y57.375 F152
G1 X59.579 Y57.397 F152
G1 X59.6 Y57.454 F152
G1 X59.621 Y57.512 F152
G1 X59.627 Y57.53 F152
G1 X59.643 Y57.569 F152
G1 X59.663 Y57.626 F152
G1 X59.682 Y57.684 F152
G1 X59.685 Y57.691 F152
G1 X59.702 Y57.741 F152
G1 X59.741 Y57.855 F152
G1 X59.742 Y57.86 F152
G1 X59.76 Y57.913 F152
G1 X59.799 Y58.027 F152
G1 Y58.028 F152
G1 X59.819 Y58.085 F152
G1 X59.838 Y58.142 F152
G1 X59.857 Y58.197 F152
G1 Y58.199 F152
G1 X59.897 Y58.314 F152
G1 X59.914 Y58.365 F152
G1 X59.917 Y58.371 F152
G1 X59.935 Y58.428 F152
G1 X59.955 Y58.486 F152
G1 X59.971 Y58.533 F152
G1 X59.975 Y58.543 F152
G1 X60.014 Y58.658 F152
G1 X60.028 Y58.701 F152
G1 X60.034 Y58.715 F152
G1 X60.073 Y58.83 F152
G1 X60.086 Y58.868 F152
G1 X60.093 Y58.887 F152
G1 X60.136 Y59.001 F152
G1 X60.143 Y59.02 F152
G1 X60.157 Y59.059 F152
G1 X60.18 Y59.116 F152
G1 X60.2 Y59.172 F152
G1 X60.201 Y59.173 F152
G1 X60.287 Y59.402 F152
G1 X60.31 Y59.46 F152
G1 X60.315 Y59.471 F152
G1 X60.334 Y59.517 F152
G1 X60.359 Y59.574 F152
G1 X60.372 Y59.607 F152
G1 X60.383 Y59.632 F152
G1 X60.408 Y59.689 F152
G1 X60.434 Y59.746 F152
G1 X60.461 Y59.804 F152
G1 X60.487 Y59.86 F152
G1 Y59.861 F152
G1 X60.513 Y59.918 F152
G1 X60.544 Y59.979 F152
G1 X60.572 Y60.033 F152
G1 X60.601 Y60.092 F152
G1 X60.63 Y60.147 F152
G1 X60.658 Y60.201 F152
G1 X60.661 Y60.205 F152
G1 X60.692 Y60.262 F152
G1 X60.716 Y60.303 F152
G1 X60.725 Y60.319 F152
G1 X60.757 Y60.377 F152
G1 X60.773 Y60.404 F152
G1 X60.791 Y60.434 F152
G1 X60.827 Y60.491 F152
G1 X60.83 Y60.497 F152
G1 X60.862 Y60.548 F152
G1 X60.888 Y60.591 F152
G1 X60.897 Y60.606 F152
G1 X60.935 Y60.663 F152
G1 X60.945 Y60.677 F152
G1 X61.002 Y60.763 F152
G1 X61.051 Y60.835 F152
G1 X61.059 Y60.846 F152
G1 X61.093 Y60.892 F152
G1 X61.117 Y60.924 F152
G1 X61.135 Y60.95 F152
G1 X61.174 Y61.002 F152
G1 X61.178 Y61.007 F152
G1 X61.222 Y61.064 F152
G1 X61.231 Y61.076 F152
G1 X61.267 Y61.121 F152
G1 X61.289 Y61.148 F152
G1 X61.313 Y61.179 F152
G1 X61.346 Y61.22 F152
G1 X61.359 Y61.236 F152
G1 X61.458 Y61.351 F152
G1 X61.46 Y61.353 F152
G1 X61.507 Y61.408 F152
G1 X61.56 Y61.465 F152
G1 X61.575 Y61.481 F152
G1 X61.632 Y61.544 F152
G1 X61.665 Y61.58 F152
G1 X61.689 Y61.604 F152
G1 X61.723 Y61.637 F152
G1 X61.747 Y61.66 F152
G1 X61.782 Y61.694 F152
G1 X61.804 Y61.716 F152
G1 X61.841 Y61.752 F152
G1 X61.861 Y61.772 F152
G1 X61.899 Y61.809 F152
G1 X61.919 Y61.828 F152
G1 X61.958 Y61.866 F152
G1 X61.976 Y61.884 F152
G1 X62.016 Y61.924 F152
G1 X62.033 Y61.94 F152
G1 X62.079 Y61.981 F152
G1 X62.09 Y61.991 F152
G1 X62.146 Y62.038 F152
G1 X62.148 Y62.04 F152
G1 X62.205 Y62.089 F152
G1 X62.212 Y62.095 F152
G1 X62.262 Y62.138 F152
G1 X62.279 Y62.153 F152
G1 X62.32 Y62.188 F152
G1 X62.345 Y62.21 F152
G1 X62.377 Y62.237 F152
G1 X62.413 Y62.267 F152
G1 X62.434 Y62.285 F152
G1 X62.484 Y62.325 F152
G1 X62.491 Y62.33 F152
G1 X62.549 Y62.375 F152
G1 X62.558 Y62.382 F152
G1 X62.606 Y62.42 F152
G1 X62.632 Y62.439 F152
G1 X62.663 Y62.463 F152
G1 X62.71 Y62.497 F152
G1 X62.72 Y62.505 F152
G1 X62.778 Y62.546 F152
G1 X62.789 Y62.554 F152
G1 X62.835 Y62.587 F152
G1 X62.87 Y62.611 F152
G1 X62.892 Y62.626 F152
G1 X62.95 Y62.666 F152
G1 X62.953 Y62.668 F152
G1 X63.007 Y62.704 F152
G1 X63.04 Y62.726 F152
G1 X63.064 Y62.741 F152
G1 X63.121 Y62.778 F152
G1 X63.129 Y62.783 F152
G1 X63.179 Y62.814 F152
G1 X63.221 Y62.84 F152
G1 X63.236 Y62.849 F152
G1 X63.351 Y62.917 F152
G1 X63.408 Y62.95 F152
G1 X63.417 Y62.955 F152
G1 X63.465 Y62.981 F152
G1 X63.521 Y63.012 F152
G1 X63.522 F152
G1 X63.58 Y63.043 F152
G1 X63.632 Y63.069 F152
G1 X63.637 Y63.071 F152
G1 X63.694 Y63.1 F152
G1 X63.752 Y63.128 F152
G1 X63.876 Y63.184 F152
G1 X63.923 Y63.204 F152
G1 X63.981 Y63.226 F152
G1 X64.016 Y63.241 F152
G1 X64.038 Y63.249 F152
G1 X64.152 Y63.291 F152
G1 X64.174 Y63.299 F152
G1 X64.21 Y63.31 F152
G1 X64.267 Y63.328 F152
G1 X64.324 Y63.345 F152
G1 X64.359 Y63.356 F152
G1 X64.382 Y63.361 F152
G1 X64.439 Y63.377 F152
G1 X64.496 Y63.39 F152
G1 X64.553 Y63.403 F152
G1 X64.604 Y63.413 F152
G1 X64.611 Y63.414 F152
G1 X64.668 Y63.425 F152
G1 X64.725 Y63.434 F152
G1 X64.783 Y63.442 F152
G1 X64.84 Y63.449 F152
G1 X64.897 Y63.455 F152
G1 X65.012 Y63.464 F152
G1 X65.069 Y63.466 F152
G1 X65.126 Y63.467 F152
G1 X65.183 Y63.469 F152
G1 X65.241 Y63.47 F152
G1 X65.298 Y63.466 F152
G1 X65.413 Y63.461 F152
G1 X65.47 Y63.455 F152
G1 X65.527 Y63.447 F152
G1 X65.584 Y63.44 F152
G1 X65.642 Y63.432 F152
G1 X65.699 Y63.42 F152
G1 X65.729 Y63.413 F152
G1 X65.756 Y63.407 F152
G1 X65.814 Y63.394 F152
G1 X65.871 Y63.38 F152
G1 X65.928 Y63.363 F152
G1 X65.95 Y63.356 F152
G1 X65.985 Y63.344 F152
G1 X66.043 Y63.324 F152
G1 X66.1 Y63.3 F152
G1 X66.106 Y63.299 F152
G1 X66.157 Y63.276 F152
G1 X66.215 Y63.25 F152
G1 X66.233 Y63.241 F152
G1 X66.272 Y63.222 F152
G1 X66.329 Y63.192 F152
G1 X66.386 Y63.16 F152
G1 X66.442 Y63.127 F152
G1 X66.444 Y63.126 F152
G1 X66.501 Y63.09 F152
G1 X66.533 Y63.069 F152
G1 X66.558 Y63.052 F152
G1 X66.615 Y63.013 F152
G1 X66.617 Y63.012 F152
G1 X66.673 Y62.971 F152
G1 X66.695 Y62.955 F152
G1 X66.73 Y62.928 F152
G1 X66.769 Y62.898 F152
G1 X66.839 Y62.84 F152
G1 X66.845 Y62.836 F152
G1 X66.902 Y62.787 F152
G1 X66.906 Y62.783 F152
G1 X66.959 Y62.736 F152
G1 X67.016 Y62.683 F152
G1 X67.032 Y62.668 F152
G1 X67.074 Y62.626 F152
G1 X67.09 Y62.611 F152
G1 X67.131 Y62.57 F152
G1 X67.188 Y62.509 F152
G1 X67.246 Y62.447 F152
G1 X67.303 Y62.383 F152
G1 Y62.382 F152
G1 X67.352 Y62.325 F152
G1 X67.36 Y62.315 F152
G1 X67.417 Y62.246 F152
G1 X67.446 Y62.21 F152
G1 X67.475 Y62.172 F152
G1 X67.532 Y62.098 F152
G1 X67.534 Y62.095 F152
G1 X67.575 Y62.038 F152
G1 X67.589 Y62.019 F152
G1 X67.617 Y61.981 F152
G1 X67.646 Y61.939 F152
G1 X67.656 Y61.924 F152
G1 X67.695 Y61.866 F152
G1 X67.704 Y61.854 F152
G1 X67.733 Y61.809 F152
G1 X67.761 Y61.766 F152
G1 X67.806 Y61.694 F152
G1 X67.818 Y61.675 F152
G1 X67.842 Y61.637 F152
G1 X67.876 Y61.58 F152
G1 X67.909 Y61.522 F152
G1 X67.933 Y61.481 F152
G1 X67.943 Y61.465 F152
G1 X67.99 Y61.378 F152
G1 X68.004 Y61.351 F152
G1 X68.036 Y61.293 F152
G1 X68.047 Y61.273 F152
G1 X68.065 Y61.236 F152
G1 X68.095 Y61.179 F152
G1 X68.105 Y61.16 F152
G1 X68.124 Y61.121 F152
G1 X68.152 Y61.064 F152
G1 X68.162 Y61.044 F152
G1 X68.18 Y61.007 F152
G1 X68.207 Y60.95 F152
G1 X68.219 Y60.924 F152
G1 X68.234 Y60.892 F152
G1 X68.26 Y60.835 F152
G1 X68.277 Y60.799 F152
G1 X68.285 Y60.778 F152
G1 X68.311 Y60.72 F152
G1 X68.334 Y60.67 F152
G1 X68.337 Y60.663 F152
G1 X68.385 Y60.548 F152
G1 X68.391 Y60.533 F152
G1 X68.408 Y60.491 F152
G1 X68.432 Y60.434 F152
G1 X68.499 Y60.262 F152
G1 X68.506 Y60.247 F152
G1 X68.522 Y60.205 F152
G1 X68.543 Y60.147 F152
G1 X68.563 Y60.095 F152
G1 X68.564 Y60.09 F152
G1 X68.607 Y59.975 F152
G1 X68.62 Y59.938 F152
G1 X68.626 Y59.918 F152
G1 X68.647 Y59.861 F152
G1 X68.667 Y59.804 F152
G1 X68.677 Y59.773 F152
G1 X68.686 Y59.746 F152
G1 X68.706 Y59.689 F152
G1 X68.725 Y59.632 F152
G1 X68.735 Y59.603 F152
G1 X68.744 Y59.574 F152
G1 X68.781 Y59.46 F152
G1 X68.792 Y59.428 F152
G1 X68.8 Y59.402 F152
G1 X68.817 Y59.345 F152
G1 X68.835 Y59.288 F152
G1 X68.849 Y59.243 F152
G1 X68.853 Y59.231 F152
G1 X68.871 Y59.173 F152
G1 X68.905 Y59.059 F152
G1 X68.907 Y59.053 F152
G1 X68.922 Y59.001 F152
G1 X68.938 Y58.944 F152
G1 X68.955 Y58.887 F152
G1 X68.964 Y58.858 F152
G1 X68.971 Y58.83 F152
G1 X69.019 Y58.658 F152
G1 X69.021 Y58.652 F152
G1 X69.035 Y58.6 F152
G1 X69.066 Y58.486 F152
G1 X69.078 Y58.44 F152
G1 X69.081 Y58.428 F152
G1 X69.127 Y58.257 F152
G1 X69.136 Y58.222 F152
G1 X69.141 Y58.199 F152
G1 X69.184 Y58.027 F152
G1 X69.193 Y57.994 F152
G1 X69.198 Y57.97 F152
G1 X69.213 Y57.913 F152
G1 X69.226 Y57.855 F152
G1 X69.24 Y57.798 F152
G1 X69.25 Y57.758 F152
G1 X69.254 Y57.741 F152
G1 X69.268 Y57.684 F152
G1 X69.308 Y57.515 F152
G1 Y57.512 F152
G1 X69.321 Y57.454 F152
G1 X69.348 Y57.34 F152
G1 X69.36 Y57.283 F152
G1 X69.365 Y57.264 F152
G1 X69.373 Y57.225 F152
G1 X69.386 Y57.168 F152
G1 X69.411 Y57.053 F152
G1 X69.422 Y57.005 F152
G1 X69.436 Y56.939 F152
G1 X69.473 Y56.767 F152
G1 X69.479 Y56.737 F152
G1 X69.485 Y56.71 F152
G1 X69.496 Y56.652 F152
G1 X69.509 Y56.595 F152
G1 X69.532 Y56.48 F152
G1 X69.537 Y56.46 F152
G1 X69.544 Y56.423 F152
G1 X69.567 Y56.308 F152
G1 X69.578 Y56.251 F152
G1 X69.589 Y56.194 F152
G1 X69.594 Y56.172 F152
G1 X69.6 Y56.137 F152
G1 X69.612 Y56.079 F152
G1 X69.644 Y55.907 F152
G1 X69.651 Y55.873 F152
G1 X69.655 Y55.85 F152
G1 X69.687 Y55.678 F152
G1 X69.697 Y55.621 F152
G1 X69.708 Y55.564 F152
G1 X69.709 Y55.56 F152
G1 X69.717 Y55.506 F152
G1 X69.728 Y55.449 F152
G1 X69.766 Y55.231 F152
G1 X69.777 Y55.163 F152
G1 X69.822 Y54.876 F152
G1 X69.823 Y54.874 F152
G1 X69.831 Y54.819 F152
G1 X69.876 Y54.532 F152
G1 X69.88 Y54.506 F152
G1 X69.885 Y54.475 F152
G1 X69.892 Y54.418 F152
G1 X69.908 Y54.303 F152
G1 X69.915 Y54.246 F152
G1 X69.931 Y54.131 F152
G1 X69.938 Y54.086 F152
G1 X69.939 Y54.074 F152
G1 X69.955 Y53.959 F152
G1 X69.969 Y53.845 F152
G1 X69.981 Y53.73 F152
G1 X69.989 Y53.673 F152
G1 X69.995 Y53.617 F152
G1 Y53.615 F152
G1 X70.02 Y53.386 F152
G1 X70.027 Y53.329 F152
G1 X70.033 Y53.272 F152
G1 X70.038 Y53.214 F152
G1 X70.043 Y53.157 F152
G1 X70.048 Y53.1 F152
G1 X70.052 Y53.054 F152
G1 X70.058 Y52.985 F152
G1 X70.063 Y52.928 F152
G1 X70.067 Y52.871 F152
G1 X70.073 Y52.813 F152
G1 X70.077 Y52.756 F152
G1 X70.083 Y52.699 F152
G1 X70.085 Y52.641 F152
G1 X70.092 Y52.527 F152
G1 X70.095 Y52.47 F152
G1 X70.099 Y52.412 F152
G1 X70.101 Y52.355 F152
G1 X70.109 Y52.227 F152
G1 X70.111 Y52.183 F152
G1 X70.114 Y52.126 F152
G1 X70.116 Y52.068 F152
G1 X70.117 Y52.011 F152
G1 X70.118 Y51.954 F152
G1 X70.12 Y51.839 F152
G1 X70.122 Y51.782 F152
G1 X70.123 Y51.725 F152
G1 X70.125 Y51.667 F152
G1 X70.126 Y51.61 F152
G1 Y51.496 F152
G1 X70.125 Y51.438 F152
G1 Y51.381 F152
G1 X70.123 Y51.324 F152
G1 X70.121 Y51.209 F152
G1 X70.118 Y51.152 F152
G1 X70.117 Y51.094 F152
G1 X70.111 Y50.98 F152
G1 X70.109 Y50.935 F152
G1 Y50.923 F152
G1 X70.101 Y50.808 F152
G1 X70.092 Y50.693 F152
G1 X70.089 Y50.636 F152
G1 X70.084 Y50.579 F152
G1 X70.077 Y50.521 F152
G1 X70.072 Y50.464 F152
G1 X70.066 Y50.407 F152
G1 X70.058 Y50.35 F152
G1 X70.052 Y50.292 F152
G1 Y50.29 F152
G1 X70.045 Y50.235 F152
G1 X70.036 Y50.178 F152
G1 X70.028 Y50.12 F152
G1 X70.019 Y50.063 F152
G1 X70.009 Y50.006 F152
G1 X70 Y49.948 F152
G1 X69.995 Y49.916 F152
G1 X69.99 Y49.891 F152
G1 X69.979 Y49.834 F152
G1 X69.967 Y49.777 F152
G1 X69.942 Y49.662 F152
G1 X69.938 Y49.642 F152
G1 X69.929 Y49.605 F152
G1 X69.914 Y49.547 F152
G1 X69.899 Y49.49 F152
G1 X69.882 Y49.433 F152
G1 X69.88 Y49.427 F152
G1 X69.864 Y49.376 F152
G1 X69.828 Y49.261 F152
G1 X69.823 Y49.243 F152
G1 X69.809 Y49.204 F152
G1 X69.784 Y49.142 F152
G1 X69.779 Y49.132 F152
G1 X69.777 Y49.128 F152
G1 Y49.127 F152
; MOVEMENT_LINK_TRANSITION
G1 Y49.126 F152
; MOVEMENT_CUTTING
G1 X69.766 Y49.138 F152
G1 X69.759 Y49.146 F152
G1 X69.712 Y49.204 F152
G1 X69.709 Y49.209 F152
G1 X69.67 Y49.261 F152
G1 X69.651 Y49.287 F152
G1 X69.628 Y49.318 F152
G1 X69.594 Y49.368 F152
G1 X69.589 Y49.376 F152
G1 X69.553 Y49.433 F152
G1 X69.537 Y49.457 F152
G1 X69.516 Y49.49 F152
G1 X69.48 Y49.547 F152
G1 X69.479 Y49.549 F152
G1 X69.449 Y49.605 F152
G1 X69.422 Y49.651 F152
G1 X69.417 Y49.662 F152
G1 X69.385 Y49.719 F152
G1 X69.365 Y49.757 F152
G1 X69.355 Y49.777 F152
G1 X69.327 Y49.834 F152
G1 X69.308 Y49.873 F152
G1 X69.3 Y49.891 F152
G1 X69.271 Y49.948 F152
G1 X69.25 Y49.997 F152
G1 X69.247 Y50.006 F152
G1 X69.198 Y50.12 F152
G1 X69.193 Y50.132 F152
G1 X69.174 Y50.178 F152
G1 X69.154 Y50.235 F152
G1 X69.136 Y50.284 F152
G1 X69.133 Y50.292 F152
G1 X69.112 Y50.35 F152
G1 X69.093 Y50.407 F152
G1 X69.078 Y50.453 F152
G1 X69.076 Y50.464 F152
G1 X69.059 Y50.521 F152
G1 X69.043 Y50.579 F152
G1 X69.026 Y50.636 F152
G1 X69.021 Y50.655 F152
G1 X69.013 Y50.693 F152
G1 X69 Y50.751 F152
G1 X68.975 Y50.865 F152
G1 X68.966 Y50.923 F152
G1 X68.964 Y50.931 F152
G1 X68.957 Y50.98 F152
G1 X68.948 Y51.037 F152
G1 X68.94 Y51.094 F152
G1 X68.924 Y51.266 F152
G1 X68.921 Y51.324 F152
G1 X68.92 Y51.381 F152
G1 X68.918 Y51.438 F152
G1 X68.917 Y51.496 F152
G1 X68.92 Y51.553 F152
G1 X68.922 Y51.61 F152
G1 X68.925 Y51.667 F152
G1 X68.929 Y51.725 F152
G1 X68.94 Y51.839 F152
G1 X68.954 Y51.954 F152
G1 X68.962 Y52.011 F152
G1 X68.964 Y52.026 F152
G1 X68.97 Y52.068 F152
G1 X68.997 Y52.24 F152
G1 X69.013 Y52.355 F152
G1 X69.02 Y52.412 F152
G1 X69.021 Y52.422 F152
G1 X69.027 Y52.47 F152
G1 X69.033 Y52.527 F152
G1 X69.036 Y52.584 F152
G1 X69.041 Y52.641 F152
G1 X69.042 Y52.699 F152
G1 X69.04 Y52.813 F152
G1 X69.037 Y52.871 F152
G1 X69.031 Y52.928 F152
G1 X69.021 Y52.991 F152
G1 X69.014 Y53.043 F152
G1 X69.002 Y53.1 F152
G1 X68.988 Y53.157 F152
G1 X68.969 Y53.214 F152
G1 X68.964 Y53.231 F152
G1 X68.95 Y53.272 F152
G1 X68.929 Y53.329 F152
G1 X68.907 Y53.379 F152
G1 X68.904 Y53.386 F152
G1 X68.874 Y53.444 F152
G1 X68.849 Y53.486 F152
G1 X68.84 Y53.501 F152
G1 X68.804 Y53.558 F152
G1 X68.792 Y53.577 F152
G1 X68.765 Y53.615 F152
G1 X68.735 Y53.656 F152
G1 X68.72 Y53.673 F152
G1 X68.677 Y53.721 F152
G1 X68.669 Y53.73 F152
G1 X68.62 Y53.778 F152
G1 X68.609 Y53.787 F152
G1 X68.563 Y53.832 F152
G1 X68.548 Y53.845 F152
G1 X68.506 Y53.88 F152
G1 X68.475 Y53.902 F152
G1 X68.448 Y53.921 F152
G1 X68.391 Y53.957 F152
G1 X68.387 Y53.959 F152
G1 X68.334 Y53.992 F152
G1 X68.29 Y54.017 F152
G1 X68.277 Y54.024 F152
G1 X68.219 Y54.051 F152
G1 X68.165 Y54.074 F152
G1 X68.162 Y54.075 F152
G1 X68.105 Y54.099 F152
G1 X68.047 Y54.12 F152
G1 X68.01 Y54.131 F152
G1 X67.99 Y54.137 F152
G1 X67.933 Y54.153 F152
G1 X67.876 Y54.168 F152
G1 X67.818 Y54.181 F152
G1 X67.776 Y54.188 F152
G1 X67.761 Y54.191 F152
G1 X67.704 Y54.202 F152
G1 X67.646 Y54.211 F152
G1 X67.589 Y54.217 F152
G1 X67.532 Y54.222 F152
G1 X67.475 Y54.229 F152
G1 X67.417 Y54.232 F152
G1 X67.36 Y54.235 F152
G1 X67.303 Y54.239 F152
G1 X67.188 Y54.24 F152
G1 X67.074 F152
G1 X67.016 Y54.239 F152
G1 X66.73 Y54.225 F152
G1 X66.444 Y54.194 F152
G1 X66.4 Y54.188 F152
G1 X66.386 F152
G1 X66.329 Y54.18 F152
G1 X66.157 Y54.15 F152
G1 X66.1 Y54.137 F152
G1 X66.072 Y54.131 F152
G1 X66.043 Y54.125 F152
G1 X65.985 Y54.112 F152
G1 X65.928 Y54.098 F152
G1 X65.871 Y54.082 F152
G1 X65.843 Y54.074 F152
G1 X65.814 Y54.066 F152
G1 X65.756 Y54.049 F152
G1 X65.667 Y54.017 F152
G1 X65.584 Y53.987 F152
G1 X65.527 Y53.962 F152
G1 X65.522 Y53.959 F152
G1 X65.47 Y53.936 F152
G1 X65.413 Y53.91 F152
G1 X65.396 Y53.902 F152
G1 X65.355 Y53.88 F152
G1 X65.298 Y53.847 F152
G1 X65.241 Y53.813 F152
G1 X65.198 Y53.787 F152
G1 X65.183 Y53.778 F152
G1 X65.126 Y53.737 F152
G1 X65.116 Y53.73 F152
G1 X65.069 Y53.694 F152
G1 X65.041 Y53.673 F152
G1 X65.012 Y53.65 F152
G1 X64.971 Y53.615 F152
G1 X64.954 Y53.599 F152
G1 X64.912 Y53.558 F152
G1 X64.84 Y53.486 F152
G1 X64.801 Y53.444 F152
G1 X64.783 Y53.42 F152
G1 X64.756 Y53.386 F152
G1 X64.725 Y53.346 F152
G1 X64.713 Y53.329 F152
G1 X64.67 Y53.272 F152
G1 X64.668 Y53.268 F152
G1 X64.633 Y53.214 F152
G1 X64.611 Y53.176 F152
G1 X64.6 Y53.157 F152
G1 X64.568 Y53.1 F152
G1 X64.537 Y53.043 F152
G1 X64.51 Y52.985 F152
G1 X64.496 Y52.949 F152
G1 X64.487 Y52.928 F152
G1 X64.442 Y52.813 F152
G1 X64.439 Y52.802 F152
G1 X64.425 Y52.756 F152
G1 X64.408 Y52.699 F152
G1 X64.393 Y52.641 F152
G1 X64.382 Y52.598 F152
G1 X64.378 Y52.584 F152
G1 X64.366 Y52.527 F152
G1 X64.356 Y52.47 F152
G1 X64.346 Y52.412 F152
G1 X64.338 Y52.355 F152
G1 X64.325 Y52.24 F152
G1 X64.324 Y52.225 F152
G1 X64.321 Y52.183 F152
G1 X64.315 Y52.068 F152
G1 X64.314 Y52.011 F152
G1 Y51.954 F152
G1 Y51.897 F152
G1 X64.315 Y51.839 F152
G1 X64.319 Y51.782 F152
G1 X64.323 Y51.725 F152
G1 X64.324 Y51.718 F152
G1 X64.328 Y51.667 F152
G1 X64.331 Y51.61 F152
G1 X64.336 Y51.553 F152
G1 X64.341 Y51.496 F152
G1 X64.365 Y51.324 F152
G1 X64.374 Y51.266 F152
G1 X64.382 Y51.217 F152
G1 Y51.209 F152
G1 X64.391 Y51.152 F152
G1 X64.439 Y50.918 F152
G1 X64.449 Y50.865 F152
G1 X64.462 Y50.808 F152
G1 X64.496 Y50.672 F152
G1 X64.504 Y50.636 F152
G1 X64.533 Y50.521 F152
G1 X64.55 Y50.464 F152
G1 X64.553 Y50.452 F152
G1 X64.582 Y50.35 F152
G1 X64.599 Y50.292 F152
G1 X64.611 Y50.252 F152
G1 X64.615 Y50.235 F152
G1 X64.633 Y50.178 F152
G1 X64.652 Y50.12 F152
G1 X64.668 Y50.072 F152
G1 X64.671 Y50.063 F152
G1 X64.689 Y50.006 F152
G1 X64.707 Y49.948 F152
G1 X64.725 Y49.898 F152
G1 X64.728 Y49.891 F152
G1 X64.749 Y49.834 F152
G1 X64.77 Y49.777 F152
G1 X64.783 Y49.743 F152
G1 X64.791 Y49.719 F152
G1 X64.812 Y49.662 F152
G1 X64.834 Y49.605 F152
G1 X64.84 Y49.589 F152
G1 X64.855 Y49.547 F152
G1 X64.877 Y49.49 F152
G1 X64.897 Y49.435 F152
G1 Y49.433 F152
G1 X64.919 Y49.376 F152
G1 X64.943 Y49.318 F152
G1 X64.954 Y49.292 F152
G1 X64.967 Y49.261 F152
G1 X64.991 Y49.204 F152
G1 X65.012 Y49.156 F152
G1 X65.015 Y49.146 F152
G1 X65.064 Y49.032 F152
G1 X65.069 Y49.02 F152
G1 X65.088 Y48.974 F152
G1 X65.112 Y48.917 F152
G1 X65.126 Y48.884 F152
G1 X65.137 Y48.86 F152
G1 X65.183 Y48.757 F152
G1 X65.189 Y48.745 F152
G1 X65.267 Y48.573 F152
G1 X65.294 Y48.516 F152
G1 X65.298 Y48.508 F152
G1 X65.321 Y48.459 F152
G1 X65.375 Y48.344 F152
G1 X65.403 Y48.287 F152
G1 X65.413 Y48.267 F152
G1 X65.43 Y48.23 F152
G1 X65.458 Y48.172 F152
G1 X65.47 Y48.149 F152
G1 X65.486 Y48.115 F152
G1 X65.514 Y48.058 F152
G1 X65.527 Y48.032 F152
G1 X65.542 Y48 F152
G1 X65.571 Y47.943 F152
G1 X65.584 Y47.917 F152
G1 X65.6 Y47.886 F152
G1 X65.628 Y47.829 F152
G1 X65.642 Y47.803 F152
G1 X65.657 Y47.771 F152
G1 X65.686 Y47.714 F152
G1 X65.699 Y47.691 F152
G1 X65.716 Y47.657 F152
G1 X65.746 Y47.599 F152
G1 X65.756 Y47.58 F152
G1 X65.775 Y47.542 F152
G1 X65.805 Y47.485 F152
G1 X65.814 Y47.469 F152
G1 X65.835 Y47.427 F152
G1 X65.865 Y47.37 F152
G1 X65.871 Y47.361 F152
G1 X65.897 Y47.313 F152
G1 X65.958 Y47.198 F152
G1 X65.985 Y47.147 F152
G1 X65.989 Y47.141 F152
G1 X66.02 Y47.084 F152
G1 X66.043 Y47.043 F152
G1 X66.052 Y47.026 F152
G1 X66.148 Y46.854 F152
G1 X66.157 Y46.839 F152
G1 X66.181 Y46.797 F152
G1 X66.248 Y46.683 F152
G1 X66.272 Y46.641 F152
G1 X66.282 Y46.625 F152
G1 X66.315 Y46.568 F152
G1 X66.329 Y46.545 F152
G1 X66.35 Y46.511 F152
G1 X66.385 Y46.453 F152
G1 X66.386 Y46.451 F152
G1 X66.419 Y46.396 F152
G1 X66.444 Y46.357 F152
G1 X66.455 Y46.339 F152
G1 X66.491 Y46.281 F152
G1 X66.501 Y46.266 F152
G1 X66.527 Y46.224 F152
G1 X66.558 Y46.177 F152
G1 X66.564 Y46.167 F152
G1 X66.602 Y46.11 F152
G1 X66.615 Y46.089 F152
G1 X66.639 Y46.052 F152
G1 X66.673 Y46.003 F152
G1 X66.717 Y45.938 F152
G1 X66.73 Y45.919 F152
G1 X66.757 Y45.88 F152
G1 X66.787 Y45.837 F152
G1 X66.797 Y45.823 F152
G1 X66.838 Y45.766 F152
G1 X66.845 Y45.757 F152
G1 X66.88 Y45.709 F152
G1 X66.923 Y45.651 F152
G1 X66.959 Y45.604 F152
G1 X66.966 Y45.594 F152
G1 X67.012 Y45.537 F152
G1 X67.016 Y45.531 F152
G1 X67.074 Y45.461 F152
G1 X67.105 Y45.422 F152
G1 X67.131 Y45.392 F152
G1 X67.155 Y45.365 F152
G1 X67.188 Y45.326 F152
G1 X67.205 Y45.307 F152
G1 X67.246 Y45.264 F152
G1 X67.258 Y45.25 F152
G1 X67.303 Y45.204 F152
G1 X67.314 Y45.193 F152
G1 X67.36 Y45.147 F152
G1 X67.373 Y45.136 F152
G1 X67.417 Y45.093 F152
G1 X67.434 Y45.078 F152
G1 X67.499 Y45.021 F152
G1 X67.532 Y44.994 F152
G1 X67.57 Y44.964 F152
G1 X67.589 Y44.948 F152
G1 X67.646 Y44.903 F152
G1 X67.704 Y44.862 F152
G1 X67.724 Y44.849 F152
G1 X67.761 Y44.823 F152
G1 X67.808 Y44.792 F152
G1 X67.818 Y44.786 F152
G1 X67.876 Y44.752 F152
G1 X67.907 Y44.734 F152
G1 X67.933 Y44.719 F152
G1 X67.99 Y44.688 F152
G1 X68.012 Y44.677 F152
G1 X68.047 Y44.66 F152
G1 X68.105 Y44.634 F152
G1 X68.138 Y44.62 F152
G1 X68.162 Y44.609 F152
G1 X68.219 Y44.588 F152
G1 X68.277 Y44.568 F152
G1 X68.293 Y44.563 F152
G1 X68.334 Y44.548 F152
G1 X68.391 Y44.531 F152
G1 X68.448 Y44.518 F152
G1 X68.505 Y44.505 F152
G1 X68.506 Y44.504 F152
G1 X68.563 Y44.493 F152
G1 X68.62 Y44.483 F152
G1 X68.677 Y44.477 F152
G1 X68.735 Y44.469 F152
G1 X68.792 Y44.465 F152
G1 X68.849 Y44.462 F152
G1 X68.907 Y44.461 F152
G1 X68.964 F152
G1 X69.021 Y44.463 F152
G1 X69.078 Y44.469 F152
G1 X69.136 Y44.475 F152
G1 X69.193 Y44.482 F152
G1 X69.25 Y44.488 F152
G1 X69.308 Y44.495 F152
G1 X69.36 Y44.505 F152
G1 X69.365 Y44.506 F152
G1 X69.422 Y44.52 F152
G1 X69.537 Y44.548 F152
G1 X69.59 Y44.563 F152
G1 X69.594 F152
G1 X69.651 Y44.579 F152
G1 X69.709 Y44.597 F152
G1 X69.766 Y44.617 F152
G1 X69.774 Y44.62 F152
G1 X69.88 Y44.657 F152
G1 X69.938 Y44.677 F152
G1 X70.084 Y44.734 F152
G1 X70.224 Y44.789 F152
G1 X70.231 Y44.792 F152
G1 X70.281 Y44.811 F152
G1 X70.339 Y44.833 F152
G1 X70.378 Y44.849 F152
G1 X70.396 Y44.855 F152
G1 X70.453 Y44.878 F152
G1 X70.51 Y44.898 F152
G1 X70.534 Y44.906 F152
G1 X70.682 Y44.957 F152
G1 X70.698 Y44.964 F152
G1 X70.797 Y44.991 F152
G1 X70.854 Y45.008 F152
G1 X70.898 Y45.021 F152
G1 X70.911 Y45.025 F152
G1 X70.969 Y45.039 F152
G1 X71.083 Y45.064 F152
G1 X71.14 Y45.076 F152
G1 X71.15 Y45.078 F152
G1 X71.198 Y45.088 F152
G1 X71.255 Y45.095 F152
G1 X71.427 Y45.119 F152
G1 X71.484 Y45.126 F152
G1 X71.541 Y45.129 F152
G1 X71.622 Y45.136 F152
G1 X71.656 Y45.137 F152
G1 X71.713 Y45.142 F152
G1 X71.828 Y45.144 F152
G1 X71.942 F152
G1 X72 Y45.145 F152
G1 X72.057 Y45.143 F152
G1 X72.172 Y45.137 F152
G1 X72.208 Y45.136 F152
G1 X72.229 Y45.134 F152
G1 X72.286 Y45.131 F152
G1 X72.343 Y45.127 F152
G1 X72.458 Y45.117 F152
G1 X72.515 Y45.11 F152
G1 X72.63 Y45.1 F152
G1 X72.687 Y45.093 F152
G1 X72.744 Y45.085 F152
G1 X72.79 Y45.078 F152
G1 X72.802 Y45.076 F152
G1 X72.973 Y45.052 F152
G1 X73.031 Y45.042 F152
G1 X73.088 Y45.032 F152
G1 X73.145 Y45.022 F152
G1 X73.152 Y45.021 F152
G1 X73.203 Y45.012 F152
G1 X73.26 Y45.001 F152
G1 X73.317 Y44.991 F152
G1 X73.374 Y44.98 F152
G1 X73.432 Y44.967 F152
G1 X73.452 Y44.964 F152
G1 X73.489 Y44.956 F152
G1 X73.546 Y44.944 F152
G1 X73.603 Y44.931 F152
G1 X73.661 Y44.92 F152
G1 X73.717 Y44.906 F152
G1 X73.718 Y44.905 F152
G1 X73.747 Y44.899 F152
G1 X73.775 Y44.892 F152
G1 X73.782 Y44.891 F152
G1 X73.784 Y44.89 F152
G1 X73.786 F152
; MOVEMENT_LINK_TRANSITION
G1 Y44.889 F152
; MOVEMENT_CUTTING
G1 X73.784 F152
G1 X73.781 Y44.888 F152
G1 X73.779 Y44.887 F152
G1 X73.775 F152
G1 X73.748 Y44.878 F152
G1 X73.718 Y44.869 F152
G1 X73.667 Y44.849 F152
G1 X73.603 Y44.821 F152
G1 X73.546 Y44.794 F152
G1 X73.542 Y44.792 F152
G1 X73.489 Y44.764 F152
G1 X73.44 Y44.734 F152
G1 X73.432 Y44.729 F152
G1 X73.374 Y44.69 F152
G1 X73.358 Y44.677 F152
G1 X73.317 Y44.647 F152
G1 X73.284 Y44.62 F152
G1 X73.26 Y44.599 F152
G1 X73.22 Y44.563 F152
G1 X73.203 Y44.544 F152
G1 X73.167 Y44.505 F152
G1 X73.145 Y44.481 F152
G1 X73.117 Y44.448 F152
G1 X73.088 Y44.412 F152
G1 X73.072 Y44.391 F152
G1 X73.032 Y44.333 F152
G1 X73.031 Y44.33 F152
G1 X72.998 Y44.276 F152
G1 X72.973 Y44.232 F152
G1 X72.966 Y44.219 F152
G1 X72.938 Y44.162 F152
G1 X72.913 Y44.104 F152
G1 X72.872 Y43.99 F152
G1 X72.859 Y43.943 F152
G1 X72.855 Y43.932 F152
G1 X72.843 Y43.875 F152
G1 X72.833 Y43.818 F152
G1 X72.819 Y43.703 F152
G1 X72.812 Y43.646 F152
G1 X72.807 Y43.589 F152
G1 X72.806 Y43.531 F152
G1 X72.808 Y43.474 F152
G1 X72.813 Y43.417 F152
G1 X72.819 Y43.359 F152
G1 X72.823 Y43.331 F152
G1 X72.824 Y43.32 F152
G1 X72.827 Y43.302 F152
G1 X72.828 Y43.295 F152
G1 Y43.291 F152
; MOVEMENT_LINK_TRANSITION
G1 X72.827 Y43.29 F152
; MOVEMENT_CUTTING
G1 X72.826 Y43.291 F152
G1 X72.815 Y43.302 F152
G1 X72.802 Y43.316 F152
G1 X72.76 Y43.359 F152
G1 X72.744 Y43.376 F152
G1 X72.687 Y43.436 F152
G1 X72.649 Y43.474 F152
G1 X72.63 Y43.493 F152
G1 X72.572 Y43.542 F152
G1 X72.517 Y43.589 F152
G1 X72.515 Y43.59 F152
G1 X72.458 Y43.634 F152
G1 X72.442 Y43.646 F152
G1 X72.401 Y43.674 F152
G1 X72.36 Y43.703 F152
G1 X72.343 Y43.715 F152
G1 X72.286 Y43.751 F152
G1 X72.268 Y43.76 F152
G1 X72.229 Y43.783 F152
G1 X72.172 Y43.815 F152
G1 X72.165 Y43.818 F152
G1 X72.114 Y43.843 F152
G1 X72.057 Y43.867 F152
G1 X72.037 Y43.875 F152
G1 X72 Y43.891 F152
G1 X71.942 Y43.913 F152
G1 X71.885 Y43.931 F152
G1 X71.877 Y43.932 F152
G1 X71.828 Y43.946 F152
G1 X71.771 Y43.961 F152
G1 X71.713 Y43.973 F152
G1 X71.656 Y43.982 F152
G1 X71.599 Y43.988 F152
G1 X71.577 Y43.99 F152
G1 X71.541 Y43.993 F152
G1 X71.484 Y43.997 F152
G1 X71.427 Y43.998 F152
G1 X71.37 Y43.995 F152
G1 X71.312 Y43.991 F152
G1 X71.309 Y43.99 F152
G1 X71.255 Y43.985 F152
G1 X71.198 Y43.977 F152
G1 X71.14 Y43.965 F152
G1 X71.026 Y43.935 F152
G1 X71.018 Y43.932 F152
G1 X70.969 Y43.917 F152
G1 X70.911 Y43.896 F152
G1 X70.865 Y43.875 F152
G1 X70.854 Y43.87 F152
G1 X70.797 Y43.842 F152
G1 X70.74 Y43.813 F152
G1 X70.682 Y43.779 F152
G1 X70.654 Y43.76 F152
G1 X70.568 Y43.699 F152
G1 X70.51 Y43.654 F152
G1 X70.501 Y43.646 F152
G1 X70.453 Y43.603 F152
G1 X70.439 Y43.589 F152
G1 X70.396 Y43.545 F152
G1 X70.382 Y43.531 F152
G1 X70.339 Y43.485 F152
G1 X70.329 Y43.474 F152
G1 X70.283 Y43.417 F152
G1 X70.281 Y43.414 F152
G1 X70.224 Y43.338 F152
G1 X70.199 Y43.302 F152
G1 X70.167 Y43.25 F152
G1 X70.164 Y43.245 F152
G1 X70.131 Y43.187 F152
G1 X70.109 Y43.15 F152
G1 X70.099 Y43.13 F152
G1 X70.07 Y43.073 F152
G1 X70.052 Y43.033 F152
G1 X70.044 Y43.016 F152
G1 X70.019 Y42.958 F152
G1 X69.995 Y42.896 F152
G1 X69.976 Y42.844 F152
G1 X69.956 Y42.786 F152
G1 X69.939 Y42.729 F152
G1 X69.938 Y42.724 F152
G1 X69.923 Y42.672 F152
G1 X69.895 Y42.557 F152
G1 X69.883 Y42.5 F152
G1 X69.88 Y42.483 F152
G1 X69.872 Y42.443 F152
G1 X69.862 Y42.385 F152
G1 X69.854 Y42.328 F152
G1 X69.839 Y42.213 F152
G1 X69.834 Y42.156 F152
G1 X69.829 Y42.099 F152
G1 X69.826 Y42.042 F152
G1 X69.823 Y41.984 F152
G1 Y41.98 F152
G1 X69.821 Y41.927 F152
G1 X69.82 Y41.812 F152
G1 X69.821 Y41.755 F152
G1 X69.822 Y41.698 F152
G1 X69.823 Y41.691 F152
G1 X69.824 Y41.64 F152
G1 X69.828 Y41.583 F152
G1 X69.841 Y41.411 F152
G1 X69.848 Y41.354 F152
G1 X69.854 Y41.297 F152
G1 X69.862 Y41.239 F152
G1 X69.889 Y41.067 F152
G1 X69.913 Y40.953 F152
G1 X69.938 Y40.838 F152
G1 X69.949 Y40.781 F152
G1 X69.963 Y40.724 F152
G1 X69.978 Y40.666 F152
G1 X69.981 Y40.658 F152
G1 Y40.657 F152
; MOVEMENT_LINK_TRANSITION
; MOVEMENT_CUTTING
G1 X69.977 F152
G1 X69.973 Y40.658 F152
G1 X69.966 F152
G1 X69.938 Y40.663 F152
G1 X69.908 Y40.666 F152
G1 X69.88 Y40.671 F152
G1 X69.709 Y40.695 F152
G1 X69.651 Y40.702 F152
G1 X69.537 Y40.718 F152
G1 X69.492 Y40.724 F152
G1 X69.365 Y40.742 F152
G1 X69.308 Y40.748 F152
G1 X69.078 Y40.777 F152
G1 X69.037 Y40.781 F152
G1 X69.021 Y40.784 F152
G1 X68.907 Y40.796 F152
G1 X68.849 Y40.802 F152
G1 X68.677 Y40.82 F152
G1 X68.506 Y40.836 F152
G1 X68.476 Y40.838 F152
G1 X68.448 Y40.841 F152
G1 X68.391 Y40.846 F152
G1 X68.334 Y40.851 F152
G1 X68.277 Y40.856 F152
G1 X68.162 Y40.865 F152
G1 X68.047 Y40.872 F152
G1 X67.99 Y40.877 F152
G1 X67.761 Y40.891 F152
G1 X67.704 Y40.894 F152
G1 X67.65 Y40.896 F152
G1 X67.646 F152
G1 X67.417 Y40.907 F152
G1 X67.246 Y40.913 F152
G1 X67.188 F152
G1 X67.016 Y40.919 F152
G1 X66.959 F152
G1 X66.787 Y40.922 F152
G1 X66.73 F152
G1 X66.673 F152
G1 X66.501 F152
G1 X66.444 F152
G1 X66.272 F152
G1 X66.215 Y40.921 F152
G1 X66.157 Y40.919 F152
G1 X65.928 Y40.915 F152
G1 X65.871 Y40.913 F152
G1 X65.814 F152
G1 X65.642 Y40.907 F152
G1 X65.584 Y40.906 F152
G1 X65.298 Y40.897 F152
G1 X65.253 Y40.896 F152
G1 X65.241 F152
G1 X65.126 Y40.892 F152
G1 X65.069 Y40.891 F152
G1 X64.897 Y40.886 F152
G1 X64.553 Y40.88 F152
G1 X64.496 F152
G1 X64.439 Y40.881 F152
G1 X64.382 F152
G1 X64.21 Y40.884 F152
G1 X64.152 Y40.886 F152
G1 X63.981 Y40.894 F152
G1 X63.937 Y40.896 F152
G1 X63.923 F152
G1 X63.866 Y40.901 F152
G1 X63.752 Y40.912 F152
G1 X63.694 Y40.916 F152
G1 X63.637 Y40.922 F152
G1 X63.465 Y40.948 F152
G1 X63.435 Y40.953 F152
G1 X63.408 Y40.957 F152
G1 X63.351 Y40.966 F152
G1 X63.293 Y40.98 F152
G1 X63.179 Y41.008 F152
G1 X63.171 Y41.01 F152
G1 X63.121 Y41.023 F152
G1 X63.064 Y41.039 F152
G1 X63.007 Y41.058 F152
G1 X62.979 Y41.067 F152
G1 X62.95 Y41.08 F152
G1 X62.892 Y41.103 F152
G1 X62.848 Y41.125 F152
G1 X62.835 Y41.131 F152
G1 X62.778 Y41.163 F152
G1 X62.745 Y41.182 F152
G1 X62.72 Y41.198 F152
G1 X62.664 Y41.239 F152
G1 X62.663 Y41.24 F152
G1 X62.606 Y41.289 F152
G1 X62.599 Y41.297 F152
G1 X62.549 Y41.349 F152
G1 X62.544 Y41.354 F152
G1 X62.499 Y41.411 F152
G1 X62.491 Y41.421 F152
G1 X62.459 Y41.469 F152
G1 X62.434 Y41.509 F152
G1 X62.424 Y41.526 F152
G1 X62.394 Y41.583 F152
G1 X62.377 Y41.619 F152
G1 X62.368 Y41.64 F152
G1 X62.345 Y41.698 F152
G1 X62.325 Y41.755 F152
G1 X62.32 Y41.768 F152
G1 X62.304 Y41.812 F152
G1 X62.285 Y41.87 F152
G1 X62.267 Y41.927 F152
G1 X62.262 Y41.946 F152
G1 X62.253 Y41.984 F152
G1 X62.239 Y42.042 F152
G1 X62.226 Y42.099 F152
G1 X62.211 Y42.156 F152
G1 X62.205 Y42.189 F152
G1 X62.201 Y42.213 F152
G1 X62.192 Y42.271 F152
G1 X62.183 Y42.328 F152
G1 X62.163 Y42.443 F152
G1 X62.15 Y42.557 F152
G1 X62.148 Y42.577 F152
G1 X62.144 Y42.614 F152
G1 X62.125 Y42.786 F152
G1 X62.104 Y43.13 F152
G1 X62.101 Y43.187 F152
G1 X62.092 Y43.474 F152
G1 X62.091 Y43.531 F152
G1 X62.09 Y43.548 F152
G1 Y43.646 F152
G1 X62.089 Y43.76 F152
G1 Y43.818 F152
G1 X62.088 Y43.875 F152
G1 X62.089 Y43.932 F152
G1 Y43.99 F152
G1 X62.09 Y44.047 F152
G1 Y44.104 F152
G1 Y44.162 F152
G1 Y44.233 F152
G1 X62.091 Y44.276 F152
G1 X62.093 Y44.391 F152
G1 X62.095 Y44.448 F152
G1 X62.098 Y44.62 F152
G1 X62.101 Y44.734 F152
G1 X62.102 Y44.792 F152
G1 X62.107 Y44.964 F152
G1 X62.108 Y45.021 F152
G1 X62.114 Y45.193 F152
G1 X62.116 Y45.25 F152
G1 X62.125 Y45.537 F152
G1 X62.128 Y45.594 F152
G1 X62.133 Y45.766 F152
G1 X62.136 Y45.823 F152
G1 X62.14 Y45.938 F152
G1 X62.142 Y45.995 F152
G1 X62.146 Y46.11 F152
G1 X62.148 Y46.161 F152
G1 X62.149 Y46.167 F152
G1 X62.152 Y46.281 F152
G1 X62.155 Y46.339 F152
G1 X62.157 Y46.396 F152
G1 X62.159 Y46.453 F152
G1 X62.163 Y46.568 F152
G1 X62.166 Y46.625 F152
G1 X62.173 Y46.854 F152
G1 X62.175 Y46.912 F152
G1 X62.186 Y47.256 F152
G1 X62.189 Y47.313 F152
G1 X62.2 Y47.657 F152
G1 X62.201 Y47.714 F152
G1 X62.204 Y47.829 F152
G1 X62.205 Y47.886 F152
G1 Y47.89 F152
G1 X62.207 Y47.943 F152
G1 X62.209 Y48 F152
G1 X62.211 Y48.172 F152
G1 X62.213 Y48.23 F152
G1 X62.218 Y48.516 F152
G1 Y48.573 F152
G1 X62.219 Y48.688 F152
G1 Y48.745 F152
G1 X62.22 Y48.803 F152
G1 Y49.146 F152
G1 X62.219 Y49.204 F152
G1 Y49.261 F152
G1 X62.218 Y49.318 F152
G1 X62.214 Y49.547 F152
G1 X62.209 Y49.719 F152
G1 X62.206 Y49.777 F152
G1 X62.205 Y49.786 F152
G1 X62.203 Y49.834 F152
G1 X62.201 Y49.891 F152
G1 X62.196 Y50.006 F152
G1 X62.185 Y50.178 F152
G1 X62.172 Y50.35 F152
G1 X62.161 Y50.464 F152
G1 X62.149 Y50.579 F152
G1 X62.148 Y50.582 F152
G1 X62.141 Y50.636 F152
G1 X62.134 Y50.693 F152
G1 X62.118 Y50.808 F152
G1 X62.1 Y50.923 F152
G1 X62.09 Y50.972 F152
G1 Y50.98 F152
G1 X62.079 Y51.037 F152
G1 X62.067 Y51.094 F152
G1 X62.055 Y51.152 F152
G1 X62.04 Y51.209 F152
G1 X62.033 Y51.236 F152
G1 X62.026 Y51.266 F152
G1 X62.011 Y51.324 F152
G1 X61.996 Y51.381 F152
G1 X61.981 Y51.438 F152
G1 X61.976 Y51.459 F152
G1 X61.965 Y51.496 F152
G1 X61.945 Y51.553 F152
G1 X61.925 Y51.61 F152
G1 X61.919 Y51.625 F152
G1 X61.903 Y51.667 F152
G1 X61.882 Y51.725 F152
G1 X61.861 Y51.779 F152
G1 X61.86 Y51.782 F152
G1 X61.839 Y51.839 F152
G1 X61.813 Y51.897 F152
G1 X61.804 Y51.914 F152
G1 X61.783 Y51.954 F152
G1 X61.754 Y52.011 F152
G1 X61.723 Y52.068 F152
G1 X61.694 Y52.126 F152
G1 X61.689 Y52.134 F152
G1 X61.664 Y52.183 F152
G1 X61.632 Y52.235 F152
G1 X61.63 Y52.24 F152
G1 X61.591 Y52.298 F152
G1 X61.575 Y52.322 F152
G1 X61.553 Y52.355 F152
G1 X61.518 Y52.405 F152
G1 X61.512 Y52.412 F152
G1 X61.468 Y52.47 F152
G1 X61.46 Y52.48 F152
G1 X61.425 Y52.527 F152
G1 X61.403 Y52.553 F152
G1 X61.376 Y52.584 F152
G1 X61.346 Y52.618 F152
G1 X61.325 Y52.641 F152
G1 X61.289 Y52.683 F152
G1 X61.273 Y52.699 F152
G1 X61.231 Y52.741 F152
G1 X61.215 Y52.756 F152
G1 X61.174 Y52.796 F152
G1 X61.117 Y52.851 F152
G1 X61.094 Y52.871 F152
G1 X61.059 Y52.9 F152
G1 X61.026 Y52.928 F152
G1 X61.002 Y52.949 F152
G1 X60.957 Y52.985 F152
G1 X60.945 Y52.995 F152
G1 X60.888 Y53.037 F152
G1 X60.88 Y53.043 F152
G1 X60.83 Y53.079 F152
G1 X60.802 Y53.1 F152
G1 X60.773 Y53.12 F152
G1 X60.716 Y53.155 F152
G1 X60.712 Y53.157 F152
G1 X60.658 Y53.189 F152
G1 X60.615 Y53.214 F152
G1 X60.601 Y53.223 F152
G1 X60.544 Y53.257 F152
G1 X60.519 Y53.272 F152
G1 X60.487 Y53.291 F152
G1 X60.429 Y53.324 F152
G1 X60.419 Y53.329 F152
G1 X60.372 Y53.352 F152
G1 X60.315 Y53.377 F152
G1 X60.257 Y53.403 F152
G1 X60.2 Y53.428 F152
G1 X60.166 Y53.444 F152
G1 X60.143 Y53.454 F152
G1 X60.086 Y53.479 F152
G1 X60.036 Y53.501 F152
G1 X60.028 Y53.504 F152
G1 X59.971 Y53.525 F152
G1 X59.914 Y53.544 F152
G1 X59.867 Y53.558 F152
G1 X59.799 Y53.581 F152
G1 X59.742 Y53.598 F152
G1 X59.688 Y53.615 F152
G1 X59.685 Y53.617 F152
G1 X59.627 Y53.635 F152
G1 X59.57 Y53.652 F152
G1 X59.513 Y53.666 F152
G1 X59.476 Y53.673 F152
G1 X59.226 Y53.727 F152
G1 X59.212 Y53.73 F152
G1 X59.169 Y53.74 F152
G1 X59.112 Y53.751 F152
G1 X58.997 Y53.767 F152
G1 X58.883 Y53.781 F152
G1 X58.829 Y53.787 F152
G1 X58.826 Y53.788 F152
G1 X58.654 Y53.81 F152
G1 X58.596 Y53.815 F152
G1 X58.482 Y53.822 F152
G1 X58.425 Y53.827 F152
G1 X58.367 Y53.83 F152
G1 X58.138 Y53.838 F152
G1 X57.966 F152
G1 X57.909 Y53.837 F152
G1 X57.852 F152
G1 X57.737 Y53.833 F152
G1 X57.68 Y53.83 F152
G1 X57.623 Y53.829 F152
G1 X57.606 Y53.828 F152
G1 X57.603 F152
G1 Z5.08 F152
G1 X57.508 Y62.26 F152
G1 Z0.966 F152
; MOVEMENT_PLUNGE
G1 Z-5.236 F51
; MOVEMENT_LEAD_IN
G1 Z-5.241 F152
; MOVEMENT_CUTTING
G1 X57.501 Y62.259 Z-5.307 F152
G1 X57.451 Z-5.758 F152
G1 X57.444 Y62.258 Z-5.824 F152
G1 X57.429 Z-5.952 F152
G1 X57.422 Y62.259 Z-6.015 F152
G1 X57.401 Z-6.208 F152
G1 X57.394 Y62.26 Z-6.271 F152
G1 X57.379 Z-6.399 F152
G1 X57.372 Y62.261 Z-6.462 F152
G1 X57.365 Z-6.526 F152
G1 X57.358 Y62.262 Z-6.589 F152
G1 X57.351 Y62.263 Z-6.65 F152
G1 X57.293 Z-7.14 F152
G1 X57.286 Y62.264 Z-7.198 F152
G1 X57.279 Z-7.259 F152
G1 X57.272 Y62.263 Z-7.322 F152
G1 X57.25 Z-7.499 F152
G1 X57.243 Y62.262 Z-7.561 F152
G1 X57.222 Z-7.738 F152
G1 X57.215 Y62.261 Z-7.801 F152
G1 X57.193 Z-7.977 F152
G1 X57.186 Y62.26 Z-8.04 F152
G1 X57.181 Z-8.084 F152
; MOVEMENT_LEAD_OUT
G1 X57.162 Z-8.086 F152
G1 X57.144 Z-8.081 F152
G1 X57.127 Z-8.072 F152
G1 X57.115 Z-8.058 F152
G1 X57.106 Z-8.042 F152
G1 X57.104 Z-8.023 F152
; MOVEMENT_LINK_TRANSITION
G1 X57.107 Z-8.007 F152
G1 X57.118 Z-7.994 F152
G1 X57.133 Z-7.986 F152
G1 X57.15 F152
G1 X57.165 Z-7.994 F152
G1 X57.176 Z-8.007 F152
G1 X57.179 Z-8.023 F152
G1 Z-8.076 F152
; MOVEMENT_LEAD_IN
G1 X57.178 Y62.259 Z-8.087 F152
G1 X57.176 Y62.253 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X57.17 Y62.239 F152
G1 X57.164 Y62.225 F152
G1 X57.156 Y62.21 F152
G1 X57.125 Y62.153 F152
G1 X57.107 Y62.121 F152
G1 X57.094 Y62.095 F152
G1 X57.059 Y62.038 F152
G1 X57.05 Y62.023 F152
G1 X57.023 Y61.981 F152
G1 X56.993 Y61.934 F152
G1 X56.985 Y61.924 F152
G1 X56.946 Y61.866 F152
G1 X56.935 Y61.85 F152
G1 X56.908 Y61.809 F152
G1 X56.746 Y61.58 F152
G1 X56.706 Y61.523 F152
G1 X56.705 Y61.522 F152
G1 X56.665 Y61.465 F152
G1 X56.624 Y61.408 F152
G1 X56.592 Y61.362 F152
G1 X56.583 Y61.351 F152
G1 X56.542 Y61.293 F152
G1 X56.534 Y61.283 F152
G1 X56.477 Y61.202 F152
G1 X56.461 Y61.179 F152
G1 X56.379 Y61.064 F152
G1 X56.363 Y61.041 F152
G1 X56.305 Y60.96 F152
G1 X56.297 Y60.95 F152
G1 X56.257 Y60.892 F152
G1 X56.133 Y60.72 F152
G1 X56.091 Y60.663 F152
G1 X56.076 Y60.642 F152
G1 X56.05 Y60.606 F152
G1 X56.019 Y60.562 F152
G1 X56.009 Y60.548 F152
G1 X55.968 Y60.491 F152
G1 X55.962 Y60.482 F152
G1 X55.927 Y60.434 F152
G1 X55.904 Y60.403 F152
G1 X55.884 Y60.377 F152
G1 X55.847 Y60.327 F152
G1 X55.841 Y60.319 F152
G1 X55.798 Y60.262 F152
G1 X55.79 Y60.25 F152
G1 X55.756 Y60.205 F152
G1 X55.732 Y60.174 F152
G1 X55.713 Y60.147 F152
G1 X55.627 Y60.033 F152
G1 X55.618 Y60.021 F152
G1 X55.561 Y59.944 F152
G1 X55.541 Y59.918 F152
G1 X55.455 Y59.804 F152
G1 X55.446 Y59.792 F152
G1 X55.412 Y59.746 F152
G1 X55.389 Y59.717 F152
G1 X55.367 Y59.689 F152
G1 X55.331 Y59.642 F152
G1 X55.323 Y59.632 F152
G1 X55.279 Y59.574 F152
G1 X55.274 Y59.568 F152
G1 X55.217 Y59.494 F152
G1 X55.19 Y59.46 F152
G1 X55.16 Y59.42 F152
G1 X55.146 Y59.402 F152
G1 X55.102 Y59.346 F152
G1 X55.101 Y59.345 F152
G1 X55.058 Y59.288 F152
G1 X55.013 Y59.231 F152
G1 X54.988 Y59.198 F152
G1 X54.968 Y59.173 F152
G1 X54.931 Y59.124 F152
G1 X54.835 Y59.001 F152
G1 X54.816 Y58.978 F152
G1 X54.789 Y58.944 F152
G1 X54.759 Y58.905 F152
G1 X54.744 Y58.887 F152
G1 X54.701 Y58.832 F152
G1 X54.7 Y58.83 F152
G1 X54.654 Y58.772 F152
G1 X54.587 Y58.686 F152
G1 X54.564 Y58.658 F152
G1 X54.53 Y58.614 F152
G1 X54.473 Y58.543 F152
G1 X54.472 Y58.541 F152
G1 X54.415 Y58.469 F152
G1 X54.358 Y58.397 F152
G1 X54.337 Y58.371 F152
G1 X54.3 Y58.325 F152
G1 X54.292 Y58.314 F152
G1 X54.201 Y58.199 F152
G1 X54.186 Y58.18 F152
G1 X54.156 Y58.142 F152
G1 X54.129 Y58.107 F152
G1 X54.111 Y58.085 F152
G1 X54.071 Y58.035 F152
G1 X54.066 Y58.027 F152
G1 X54.02 Y57.97 F152
G1 X54.014 Y57.962 F152
G1 X53.975 Y57.913 F152
G1 X53.957 Y57.889 F152
G1 X53.9 Y57.817 F152
G1 X53.884 Y57.798 F152
G1 X53.842 Y57.744 F152
G1 X53.839 Y57.741 F152
G1 X53.794 Y57.684 F152
G1 X53.785 Y57.672 F152
G1 X53.749 Y57.626 F152
G1 X53.728 Y57.599 F152
G1 X53.704 Y57.569 F152
G1 X53.67 Y57.525 F152
G1 X53.66 Y57.512 F152
G1 X53.613 Y57.451 F152
G1 X53.571 Y57.397 F152
G1 X53.556 Y57.377 F152
G1 X53.526 Y57.34 F152
G1 X53.499 Y57.304 F152
G1 X53.482 Y57.283 F152
G1 X53.441 Y57.23 F152
G1 X53.438 Y57.225 F152
G1 X53.393 Y57.168 F152
G1 X53.384 Y57.156 F152
G1 X53.348 Y57.111 F152
G1 X53.327 Y57.083 F152
G1 X53.303 Y57.053 F152
G1 X53.269 Y57.009 F152
G1 X53.215 Y56.939 F152
G1 X53.212 Y56.935 F152
G1 X53.17 Y56.881 F152
G1 X53.155 Y56.862 F152
G1 X53.126 Y56.824 F152
G1 X53.04 Y56.714 F152
G1 X53.037 Y56.71 F152
G1 X52.993 Y56.652 F152
G1 X52.983 Y56.64 F152
G1 X52.949 Y56.595 F152
G1 X52.905 Y56.538 F152
G1 X52.868 Y56.488 F152
G1 X52.862 Y56.48 F152
G1 X52.818 Y56.423 F152
G1 X52.811 Y56.413 F152
G1 X52.775 Y56.366 F152
G1 X52.754 Y56.336 F152
G1 X52.732 Y56.308 F152
G1 X52.697 Y56.26 F152
G1 X52.69 Y56.251 F152
G1 X52.647 Y56.194 F152
G1 X52.604 Y56.137 F152
G1 X52.582 Y56.107 F152
G1 X52.562 Y56.079 F152
G1 X52.525 Y56.029 F152
G1 X52.519 Y56.022 F152
G1 X52.477 Y55.965 F152
G1 X52.468 Y55.952 F152
G1 X52.434 Y55.907 F152
G1 X52.41 Y55.874 F152
G1 X52.392 Y55.85 F152
G1 X52.308 Y55.735 F152
G1 X52.296 Y55.718 F152
G1 X52.238 Y55.639 F152
G1 X52.225 Y55.621 F152
G1 X52.184 Y55.564 F152
G1 X52.181 Y55.559 F152
G1 X52.143 Y55.506 F152
G1 X52.124 Y55.48 F152
G1 X52.101 Y55.449 F152
G1 X52.067 Y55.401 F152
G1 X52.059 Y55.392 F152
G1 X52.019 Y55.334 F152
G1 X52.009 Y55.321 F152
G1 X51.978 Y55.277 F152
G1 X51.952 Y55.24 F152
G1 X51.938 Y55.22 F152
G1 X51.897 Y55.163 F152
G1 X51.895 Y55.159 F152
G1 X51.856 Y55.105 F152
G1 X51.837 Y55.077 F152
G1 X51.816 Y55.048 F152
G1 X51.78 Y54.997 F152
G1 X51.776 Y54.991 F152
G1 X51.735 Y54.933 F152
G1 X51.723 Y54.915 F152
G1 X51.696 Y54.876 F152
G1 X51.666 Y54.831 F152
G1 X51.657 Y54.819 F152
G1 X51.617 Y54.761 F152
G1 X51.608 Y54.749 F152
G1 X51.578 Y54.704 F152
G1 X51.551 Y54.666 F152
G1 X51.538 Y54.647 F152
G1 X51.498 Y54.59 F152
G1 X51.494 Y54.582 F152
G1 X51.46 Y54.532 F152
G1 X51.437 Y54.498 F152
G1 X51.421 Y54.475 F152
G1 X51.344 Y54.36 F152
G1 X51.322 Y54.327 F152
G1 X51.306 Y54.303 F152
G1 X51.267 Y54.246 F152
G1 X51.265 Y54.242 F152
G1 X51.229 Y54.188 F152
G1 X51.207 Y54.157 F152
G1 X51.153 Y54.074 F152
G1 X51.15 Y54.069 F152
G1 X51.115 Y54.017 F152
G1 X51.079 Y53.959 F152
G1 X51.041 Y53.902 F152
G1 X51.036 Y53.893 F152
G1 X51.003 Y53.845 F152
G1 X50.978 Y53.805 F152
G1 X50.967 Y53.787 F152
G1 X50.929 Y53.73 F152
G1 X50.892 Y53.673 F152
G1 X50.864 Y53.627 F152
G1 X50.856 Y53.615 F152
G1 X50.82 Y53.558 F152
G1 X50.806 Y53.536 F152
G1 X50.784 Y53.501 F152
G1 X50.749 Y53.445 F152
G1 X50.748 Y53.444 F152
G1 X50.712 Y53.386 F152
G1 X50.692 Y53.353 F152
G1 X50.677 Y53.329 F152
G1 X50.641 Y53.272 F152
G1 X50.635 Y53.262 F152
G1 X50.605 Y53.214 F152
G1 X50.577 Y53.169 F152
G1 X50.57 Y53.157 F152
G1 X50.536 Y53.1 F152
G1 X50.52 Y53.073 F152
G1 X50.501 Y53.043 F152
G1 X50.467 Y52.985 F152
G1 X50.463 Y52.977 F152
G1 X50.433 Y52.928 F152
G1 X50.406 Y52.882 F152
G1 X50.398 Y52.871 F152
G1 X50.364 Y52.813 F152
G1 X50.348 Y52.786 F152
G1 X50.329 Y52.756 F152
G1 X50.296 Y52.699 F152
G1 X50.291 Y52.689 F152
G1 X50.264 Y52.641 F152
G1 X50.234 Y52.589 F152
G1 X50.231 Y52.584 F152
G1 X50.199 Y52.527 F152
G1 X50.176 Y52.487 F152
G1 X50.166 Y52.47 F152
G1 X50.133 Y52.412 F152
G1 X50.119 Y52.387 F152
G1 X50.1 Y52.355 F152
G1 X50.068 Y52.298 F152
G1 X50.062 Y52.286 F152
G1 X50.036 Y52.24 F152
G1 X50.005 Y52.183 F152
G1 Y52.182 F152
G1 X49.974 Y52.126 F152
G1 X49.947 Y52.075 F152
G1 X49.944 Y52.068 F152
G1 X49.913 Y52.011 F152
G1 X49.89 Y51.968 F152
G1 X49.882 Y51.954 F152
G1 X49.852 Y51.897 F152
G1 X49.833 Y51.861 F152
G1 X49.821 Y51.839 F152
G1 X49.775 Y51.753 F152
G1 X49.732 Y51.667 F152
G1 X49.718 Y51.638 F152
G1 X49.704 Y51.61 F152
G1 X49.675 Y51.553 F152
G1 X49.661 Y51.522 F152
G1 X49.619 Y51.438 F152
G1 X49.604 Y51.407 F152
G1 X49.59 Y51.381 F152
G1 X49.562 Y51.324 F152
G1 X49.534 Y51.266 F152
G1 X49.508 Y51.209 F152
G1 X49.489 Y51.167 F152
G1 X49.482 Y51.152 F152
G1 X49.456 Y51.094 F152
G1 X49.432 Y51.041 F152
G1 X49.43 Y51.037 F152
G1 X49.378 Y50.923 F152
G1 X49.374 Y50.914 F152
G1 X49.326 Y50.808 F152
G1 X49.317 Y50.787 F152
G1 X49.302 Y50.751 F152
G1 X49.279 Y50.693 F152
G1 X49.26 Y50.646 F152
G1 X49.255 Y50.636 F152
G1 X49.232 Y50.579 F152
G1 X49.21 Y50.521 F152
G1 X49.203 Y50.504 F152
G1 X49.187 Y50.464 F152
G1 X49.163 Y50.407 F152
G1 X49.145 Y50.362 F152
G1 X49.14 Y50.35 F152
G1 X49.118 Y50.292 F152
G1 X49.097 Y50.235 F152
G1 X49.088 Y50.208 F152
G1 X49.077 Y50.178 F152
G1 X49.057 Y50.12 F152
G1 X49.037 Y50.063 F152
G1 X49.031 Y50.044 F152
G1 X49.017 Y50.006 F152
G1 X48.997 Y49.948 F152
G1 X48.977 Y49.891 F152
G1 X48.974 Y49.88 F152
G1 X48.957 Y49.834 F152
G1 X48.939 Y49.777 F152
G1 X48.922 Y49.719 F152
G1 X48.916 Y49.699 F152
G1 X48.906 Y49.662 F152
G1 X48.889 Y49.605 F152
G1 X48.872 Y49.547 F152
G1 X48.859 Y49.502 F152
G1 X48.855 Y49.49 F152
G1 X48.838 Y49.433 F152
G1 X48.822 Y49.376 F152
G1 X48.805 Y49.318 F152
G1 X48.802 Y49.301 F152
G1 X48.792 Y49.261 F152
G1 X48.779 Y49.204 F152
G1 X48.752 Y49.089 F152
G1 X48.744 Y49.051 F152
G1 X48.74 Y49.032 F152
G1 X48.727 Y48.974 F152
G1 X48.714 Y48.917 F152
G1 X48.701 Y48.86 F152
G1 X48.688 Y48.803 F152
G1 X48.687 Y48.793 F152
G1 X48.679 Y48.745 F152
G1 X48.67 Y48.688 F152
G1 X48.66 Y48.631 F152
G1 X48.651 Y48.573 F152
G1 X48.641 Y48.516 F152
G1 X48.633 Y48.459 F152
G1 X48.63 Y48.439 F152
G1 X48.624 Y48.401 F152
G1 X48.614 Y48.344 F152
G1 X48.607 Y48.287 F152
G1 X48.574 Y47.943 F152
G1 X48.573 Y47.919 F152
G1 X48.569 Y47.886 F152
G1 X48.564 Y47.829 F152
G1 X48.561 Y47.771 F152
G1 X48.559 Y47.714 F152
G1 X48.558 Y47.657 F152
G1 X48.556 Y47.599 F152
G1 Y47.542 F152
G1 X48.554 Y47.485 F152
G1 X48.553 Y47.427 F152
G1 X48.551 Y47.37 F152
G1 X48.55 Y47.313 F152
G1 X48.552 Y47.256 F152
G1 X48.565 Y46.969 F152
G1 X48.567 Y46.912 F152
G1 X48.57 Y46.854 F152
G1 X48.573 Y46.827 F152
G1 X48.575 Y46.797 F152
G1 X48.619 Y46.396 F152
G1 X48.627 Y46.339 F152
G1 X48.63 Y46.324 F152
G1 X48.637 Y46.281 F152
G1 X48.686 Y45.995 F152
G1 X48.687 Y45.991 F152
G1 X48.696 Y45.938 F152
G1 X48.708 Y45.88 F152
G1 X48.721 Y45.823 F152
G1 X48.734 Y45.766 F152
G1 X48.744 Y45.722 F152
G1 X48.747 Y45.709 F152
G1 X48.761 Y45.651 F152
G1 X48.773 Y45.594 F152
G1 X48.8 Y45.479 F152
G1 X48.802 Y45.473 F152
G1 X48.815 Y45.422 F152
G1 X48.847 Y45.307 F152
G1 X48.859 Y45.268 F152
G1 X48.863 Y45.25 F152
G1 X48.912 Y45.078 F152
G1 X48.916 Y45.064 F152
G1 X48.929 Y45.021 F152
G1 X48.966 Y44.906 F152
G1 X48.974 Y44.886 F152
G1 X48.985 Y44.849 F152
G1 X49.004 Y44.792 F152
G1 X49.022 Y44.734 F152
G1 X49.031 Y44.709 F152
G1 X49.041 Y44.677 F152
G1 X49.06 Y44.62 F152
G1 X49.081 Y44.563 F152
G1 X49.088 Y44.544 F152
G1 X49.102 Y44.505 F152
G1 X49.143 Y44.391 F152
G1 X49.145 Y44.384 F152
G1 X49.163 Y44.333 F152
G1 X49.184 Y44.276 F152
G1 X49.203 Y44.229 F152
G1 X49.206 Y44.219 F152
G1 X49.228 Y44.162 F152
G1 X49.26 Y44.079 F152
G1 X49.272 Y44.047 F152
G1 X49.294 Y43.99 F152
G1 X49.316 Y43.932 F152
G1 X49.317 Y43.931 F152
G1 X49.339 Y43.875 F152
G1 X49.361 Y43.818 F152
G1 X49.374 Y43.785 F152
G1 X49.429 Y43.646 F152
G1 X49.432 Y43.64 F152
G1 X49.452 Y43.589 F152
G1 X49.475 Y43.531 F152
G1 X49.489 Y43.495 F152
G1 X49.497 Y43.474 F152
G1 X49.542 Y43.359 F152
G1 X49.546 Y43.349 F152
G1 X49.565 Y43.302 F152
G1 X49.587 Y43.245 F152
G1 X49.604 Y43.2 F152
G1 X49.608 Y43.187 F152
G1 X49.651 Y43.073 F152
G1 X49.661 Y43.047 F152
G1 X49.673 Y43.016 F152
G1 X49.691 Y42.958 F152
G1 X49.711 Y42.901 F152
G1 X49.718 Y42.88 F152
G1 X49.731 Y42.844 F152
G1 X49.749 Y42.786 F152
G1 X49.766 Y42.729 F152
G1 X49.775 Y42.698 F152
G1 X49.783 Y42.672 F152
G1 X49.799 Y42.614 F152
G1 X49.814 Y42.557 F152
G1 X49.826 Y42.5 F152
G1 X49.833 Y42.466 F152
G1 X49.837 Y42.443 F152
G1 X49.848 Y42.385 F152
G1 X49.853 Y42.328 F152
G1 X49.86 Y42.271 F152
G1 Y42.213 F152
G1 Y42.156 F152
G1 X49.853 Y42.099 F152
G1 X49.843 Y42.042 F152
G1 X49.833 Y42.004 F152
G1 X49.826 Y41.984 F152
G1 X49.805 Y41.927 F152
G1 X49.776 Y41.87 F152
G1 X49.775 Y41.867 F152
G1 X49.746 Y41.812 F152
G1 X49.718 Y41.769 F152
G1 X49.664 Y41.698 F152
G1 X49.661 Y41.692 F152
G1 X49.618 Y41.64 F152
G1 X49.604 Y41.624 F152
G1 X49.546 Y41.562 F152
G1 X49.489 Y41.504 F152
G1 X49.452 Y41.469 F152
G1 X49.432 Y41.451 F152
G1 X49.388 Y41.411 F152
G1 X49.374 Y41.399 F152
G1 X49.32 Y41.354 F152
G1 X49.317 Y41.352 F152
G1 X49.26 Y41.307 F152
G1 X49.246 Y41.297 F152
G1 X49.203 Y41.263 F152
G1 X49.173 Y41.239 F152
G1 X49.145 Y41.218 F152
G1 X49.1 Y41.182 F152
G1 X49.088 Y41.173 F152
G1 X49.031 Y41.134 F152
G1 X49.017 Y41.125 F152
G1 X48.974 Y41.096 F152
G1 X48.931 Y41.067 F152
G1 X48.916 Y41.058 F152
G1 X48.846 Y41.01 F152
G1 X48.802 Y40.981 F152
G1 X48.756 Y40.953 F152
G1 X48.744 Y40.947 F152
G1 X48.687 Y40.913 F152
G1 X48.658 Y40.896 F152
G1 X48.573 Y40.846 F152
G1 X48.56 Y40.838 F152
G1 X48.515 Y40.812 F152
G1 X48.46 Y40.781 F152
G1 X48.401 Y40.75 F152
G1 X48.352 Y40.724 F152
G1 X48.343 Y40.719 F152
G1 X48.286 Y40.69 F152
G1 X48.172 Y40.632 F152
G1 X48.122 Y40.609 F152
G1 X48.114 Y40.606 F152
G1 X48 Y40.552 F152
G1 X47.885 Y40.502 F152
G1 X47.828 Y40.477 F152
G1 X47.729 Y40.437 F152
G1 X47.713 Y40.432 F152
G1 X47.599 Y40.387 F152
G1 X47.578 Y40.38 F152
G1 X47.484 Y40.348 F152
G1 X47.427 Y40.328 F152
G1 X47.412 Y40.323 F152
G1 X47.312 Y40.293 F152
G1 X47.255 Y40.277 F152
G1 X47.218 Y40.265 F152
G1 X47.198 Y40.26 F152
G1 X47.083 Y40.233 F152
G1 X47.026 Y40.219 F152
G1 X46.975 Y40.208 F152
G1 X46.969 Y40.207 F152
G1 X46.911 Y40.197 F152
G1 X46.854 Y40.187 F152
G1 X46.797 Y40.177 F152
G1 X46.682 Y40.164 F152
G1 X46.625 Y40.157 F152
G1 X46.524 Y40.151 F152
G1 X46.511 F152
G1 X46.453 Y40.148 F152
G1 X46.396 Y40.146 F152
G1 X46.339 Y40.148 F152
G1 X46.224 Y40.15 F152
G1 X46.21 Y40.151 F152
G1 X46.167 Y40.154 F152
G1 X46.11 Y40.159 F152
G1 X46.052 Y40.164 F152
G1 X45.995 Y40.17 F152
G1 X45.823 Y40.192 F152
G1 X45.766 Y40.202 F152
G1 X45.73 Y40.208 F152
G1 X45.709 Y40.212 F152
G1 X45.422 Y40.262 F152
G1 X45.397 Y40.265 F152
G1 X45.365 Y40.272 F152
G1 X45.136 Y40.315 F152
G1 X45.092 Y40.323 F152
G1 X45.079 Y40.325 F152
G1 X44.907 Y40.358 F152
G1 X44.849 Y40.367 F152
G1 X44.792 Y40.378 F152
G1 X44.777 Y40.38 F152
G1 X44.62 Y40.407 F152
G1 X44.563 Y40.417 F152
G1 X44.448 Y40.435 F152
G1 X44.425 Y40.437 F152
G1 X44.391 Y40.443 F152
G1 X44.334 Y40.451 F152
G1 X44.277 Y40.46 F152
G1 X44.219 Y40.468 F152
G1 X44.105 Y40.482 F152
G1 X44.048 Y40.488 F152
G1 X43.995 Y40.494 F152
G1 X43.99 Y40.495 F152
G1 X43.933 Y40.503 F152
G1 X43.818 Y40.515 F152
G1 X43.761 Y40.52 F152
G1 X43.647 Y40.53 F152
G1 X43.589 Y40.535 F152
G1 X43.532 Y40.54 F152
G1 X43.475 Y40.545 F152
G1 X43.36 Y40.552 F152
G1 X43.346 F152
G1 X43.303 Y40.554 F152
G1 X43.246 Y40.557 F152
G1 X43.188 Y40.561 F152
G1 X43.017 Y40.569 F152
G1 X42.959 Y40.57 F152
G1 X42.902 Y40.571 F152
G1 X42.787 Y40.573 F152
G1 X42.73 Y40.575 F152
G1 X42.616 Y40.577 F152
G1 X42.558 F152
G1 X42.501 Y40.576 F152
G1 X42.444 F152
G1 X42.386 Y40.575 F152
G1 X42.329 F152
G1 X42.272 Y40.574 F152
G1 X42.215 F152
G1 X41.814 Y40.562 F152
G1 X41.642 Y40.554 F152
G1 X41.623 Y40.552 F152
G1 X41.527 Y40.547 F152
G1 X41.52 F152
G1 X41.513 Y40.546 F152
G1 X41.51 F152
; MOVEMENT_LINK_TRANSITION
G1 X41.509 Y40.548 F152
; MOVEMENT_CUTTING
G1 X41.513 Y40.55 F152
G1 X41.516 Y40.552 F152
G1 X41.527 Y40.558 F152
G1 X41.585 Y40.59 F152
G1 X41.618 Y40.609 F152
G1 X41.642 Y40.623 F152
G1 X41.699 Y40.655 F152
G1 X41.721 Y40.666 F152
G1 X41.756 Y40.686 F152
G1 X41.814 Y40.718 F152
G1 X41.871 Y40.75 F152
G1 X41.927 Y40.781 F152
G1 X41.928 F152
G1 X41.985 Y40.812 F152
G1 X42.032 Y40.838 F152
G1 X42.043 Y40.844 F152
G1 X42.1 Y40.875 F152
G1 X42.137 Y40.896 F152
G1 X42.157 Y40.906 F152
G1 X42.215 Y40.938 F152
G1 X42.241 Y40.953 F152
G1 X42.272 Y40.97 F152
G1 X42.329 Y41.001 F152
G1 X42.345 Y41.01 F152
G1 X42.386 Y41.033 F152
G1 X42.444 Y41.064 F152
G1 X42.616 Y41.161 F152
G1 X42.654 Y41.182 F152
G1 X42.673 Y41.192 F152
G1 X42.73 Y41.226 F152
G1 X42.752 Y41.239 F152
G1 X42.787 Y41.26 F152
G1 X42.845 Y41.294 F152
G1 X42.848 Y41.297 F152
G1 X42.902 Y41.329 F152
G1 X42.945 Y41.354 F152
G1 X42.959 Y41.363 F152
G1 X43.074 Y41.431 F152
G1 X43.131 Y41.468 F152
G1 X43.132 Y41.469 F152
G1 X43.188 Y41.506 F152
G1 X43.217 Y41.526 F152
G1 X43.246 Y41.545 F152
G1 X43.302 Y41.583 F152
G1 X43.303 F152
G1 X43.36 Y41.623 F152
G1 X43.387 Y41.64 F152
G1 X43.417 Y41.661 F152
G1 X43.475 Y41.7 F152
G1 X43.532 Y41.741 F152
G1 X43.55 Y41.755 F152
G1 X43.589 Y41.785 F152
G1 X43.625 Y41.812 F152
G1 X43.647 Y41.828 F152
G1 X43.704 Y41.872 F152
G1 X43.771 Y41.927 F152
G1 X43.818 Y41.966 F152
G1 X43.839 Y41.984 F152
G1 X43.876 Y42.015 F152
G1 X43.908 Y42.042 F152
G1 X43.933 Y42.063 F152
G1 X43.972 Y42.099 F152
G1 X43.99 Y42.115 F152
G1 X44.035 Y42.156 F152
G1 X44.048 Y42.168 F152
G1 X44.099 Y42.213 F152
G1 X44.105 Y42.22 F152
G1 X44.158 Y42.271 F152
G1 X44.277 Y42.388 F152
G1 X44.334 Y42.446 F152
G1 X44.384 Y42.5 F152
G1 X44.391 Y42.507 F152
G1 X44.448 Y42.569 F152
G1 X44.491 Y42.614 F152
G1 X44.506 Y42.631 F152
G1 X44.543 Y42.672 F152
G1 X44.563 Y42.695 F152
G1 X44.593 Y42.729 F152
G1 X44.642 Y42.786 F152
G1 X44.678 Y42.828 F152
G1 X44.692 Y42.844 F152
G1 X44.735 Y42.894 F152
G1 X44.74 Y42.901 F152
G1 X44.787 Y42.958 F152
G1 X44.792 Y42.965 F152
G1 X44.833 Y43.016 F152
G1 X44.849 Y43.036 F152
G1 X44.88 Y43.073 F152
G1 X44.907 Y43.107 F152
G1 X44.926 Y43.13 F152
G1 X44.97 Y43.187 F152
G1 X45.014 Y43.245 F152
G1 X45.021 Y43.255 F152
G1 X45.058 Y43.302 F152
G1 X45.079 Y43.33 F152
G1 X45.101 Y43.359 F152
G1 X45.145 Y43.417 F152
G1 X45.187 Y43.474 F152
G1 X45.193 Y43.483 F152
G1 X45.228 Y43.531 F152
G1 X45.27 Y43.589 F152
G1 X45.308 Y43.641 F152
G1 X45.311 Y43.646 F152
G1 X45.352 Y43.703 F152
G1 X45.365 Y43.72 F152
G1 X45.432 Y43.818 F152
G1 X45.472 Y43.875 F152
G1 X45.48 Y43.886 F152
G1 X45.512 Y43.932 F152
G1 X45.537 Y43.969 F152
G1 X45.551 Y43.99 F152
G1 X45.59 Y44.047 F152
G1 X45.594 Y44.054 F152
G1 X45.627 Y44.104 F152
G1 X45.651 Y44.143 F152
G1 X45.664 Y44.162 F152
G1 X45.766 Y44.321 F152
G1 X45.775 Y44.333 F152
G1 X45.812 Y44.391 F152
G1 X45.823 Y44.409 F152
G1 X45.848 Y44.448 F152
G1 X45.88 Y44.498 F152
G1 X45.885 Y44.505 F152
G1 X45.923 Y44.563 F152
G1 X45.938 Y44.587 F152
G1 X45.959 Y44.62 F152
G1 X45.995 Y44.677 F152
G1 Y44.678 F152
G1 X46.029 Y44.734 F152
G1 X46.052 Y44.774 F152
G1 X46.063 Y44.792 F152
G1 X46.097 Y44.849 F152
G1 X46.132 Y44.906 F152
G1 X46.166 Y44.964 F152
G1 X46.167 Y44.966 F152
G1 X46.2 Y45.021 F152
G1 X46.224 Y45.063 F152
G1 X46.233 Y45.078 F152
G1 X46.265 Y45.136 F152
G1 X46.281 Y45.165 F152
G1 X46.298 Y45.193 F152
G1 X46.33 Y45.25 F152
G1 X46.339 Y45.267 F152
G1 X46.362 Y45.307 F152
G1 X46.392 Y45.365 F152
G1 X46.396 Y45.372 F152
G1 X46.423 Y45.422 F152
G1 X46.484 Y45.537 F152
G1 X46.511 Y45.588 F152
G1 X46.514 Y45.594 F152
G1 X46.543 Y45.651 F152
G1 X46.568 Y45.703 F152
G1 X46.599 Y45.766 F152
G1 X46.655 Y45.88 F152
G1 X46.681 Y45.938 F152
G1 X46.682 Y45.94 F152
G1 X46.707 Y45.995 F152
G1 X46.732 Y46.052 F152
G1 X46.74 Y46.071 F152
G1 X46.757 Y46.11 F152
G1 X46.782 Y46.167 F152
G1 X46.797 Y46.201 F152
G1 X46.807 Y46.224 F152
G1 X46.85 Y46.339 F152
G1 X46.854 Y46.351 F152
G1 X46.871 Y46.396 F152
G1 X46.892 Y46.453 F152
G1 X46.911 Y46.507 F152
G1 X46.913 Y46.511 F152
G1 X46.933 Y46.568 F152
G1 X46.951 Y46.625 F152
G1 X46.969 Y46.689 F152
G1 X46.984 Y46.74 F152
G1 X46.998 Y46.797 F152
G1 X47.011 Y46.854 F152
G1 X47.024 Y46.912 F152
G1 X47.026 Y46.922 F152
G1 X47.036 Y46.969 F152
G1 X47.06 Y47.141 F152
G1 X47.065 Y47.198 F152
G1 X47.067 Y47.256 F152
G1 Y47.313 F152
G1 X47.068 Y47.37 F152
G1 X47.067 Y47.427 F152
G1 X47.063 Y47.485 F152
G1 X47.055 Y47.542 F152
G1 X47.045 Y47.599 F152
G1 X47.033 Y47.657 F152
G1 X47.026 Y47.694 F152
G1 X47.022 Y47.714 F152
G1 X47.007 Y47.771 F152
G1 X46.989 Y47.829 F152
G1 X46.969 Y47.88 F152
G1 X46.967 Y47.886 F152
G1 X46.942 Y47.943 F152
G1 X46.915 Y48 F152
G1 X46.911 Y48.006 F152
G1 X46.883 Y48.058 F152
G1 X46.854 Y48.103 F152
G1 X46.847 Y48.115 F152
G1 X46.797 Y48.185 F152
G1 X46.763 Y48.23 F152
G1 X46.74 Y48.256 F152
G1 X46.712 Y48.287 F152
G1 X46.682 Y48.316 F152
G1 X46.653 Y48.344 F152
G1 X46.625 Y48.368 F152
G1 X46.587 Y48.401 F152
G1 X46.568 Y48.418 F152
G1 X46.511 Y48.459 F152
G1 Y48.46 F152
G1 X46.453 Y48.496 F152
G1 X46.396 Y48.529 F152
G1 X46.339 Y48.559 F152
G1 X46.307 Y48.573 F152
G1 X46.281 Y48.585 F152
G1 X46.224 Y48.607 F152
G1 X46.167 Y48.626 F152
G1 X46.148 Y48.631 F152
G1 X46.11 Y48.641 F152
G1 X45.995 Y48.667 F152
G1 X45.938 Y48.678 F152
G1 X45.88 Y48.685 F152
G1 X45.845 Y48.688 F152
G1 X45.823 Y48.69 F152
G1 X45.766 Y48.691 F152
G1 X45.709 Y48.69 F152
G1 X45.651 F152
G1 X45.612 Y48.688 F152
G1 X45.594 Y48.687 F152
G1 X45.537 Y48.682 F152
G1 X45.48 Y48.673 F152
G1 X45.422 Y48.665 F152
G1 X45.365 Y48.655 F152
G1 X45.308 Y48.642 F152
G1 X45.266 Y48.631 F152
G1 X45.25 Y48.627 F152
G1 X45.193 Y48.61 F152
G1 X45.079 Y48.578 F152
G1 X45.021 Y48.561 F152
G1 X44.964 Y48.54 F152
G1 X44.907 Y48.518 F152
G1 X44.903 Y48.516 F152
G1 X44.849 Y48.495 F152
G1 X44.792 Y48.472 F152
G1 X44.76 Y48.459 F152
G1 X44.735 Y48.449 F152
G1 X44.678 Y48.425 F152
G1 X44.63 Y48.401 F152
G1 X44.62 Y48.397 F152
G1 X44.563 Y48.37 F152
G1 X44.506 Y48.342 F152
G1 X44.448 Y48.316 F152
G1 X44.391 Y48.286 F152
G1 X44.334 Y48.256 F152
G1 X44.286 Y48.23 F152
G1 X44.277 Y48.225 F152
G1 X44.219 Y48.195 F152
G1 X44.178 Y48.172 F152
G1 X44.162 Y48.164 F152
G1 X44.105 Y48.131 F152
G1 X44.078 Y48.115 F152
G1 X44.048 Y48.098 F152
G1 X43.99 Y48.065 F152
G1 X43.979 Y48.058 F152
G1 X43.933 Y48.032 F152
G1 X43.876 Y47.998 F152
G1 X43.818 Y47.962 F152
G1 X43.788 Y47.943 F152
G1 X43.761 Y47.926 F152
G1 X43.704 Y47.891 F152
G1 X43.696 Y47.886 F152
G1 X43.647 Y47.855 F152
G1 X43.605 Y47.829 F152
G1 X43.589 Y47.819 F152
G1 X43.52 Y47.771 F152
G1 X43.475 Y47.741 F152
G1 X43.435 Y47.714 F152
G1 X43.417 Y47.701 F152
G1 X43.36 Y47.663 F152
G1 X43.351 Y47.657 F152
G1 X43.303 Y47.624 F152
G1 X43.266 Y47.599 F152
G1 X43.246 Y47.585 F152
G1 X43.188 Y47.547 F152
G1 X43.182 Y47.542 F152
G1 X43.131 Y47.507 F152
G1 X43.098 Y47.485 F152
G1 X43.074 Y47.468 F152
G1 X43.018 Y47.427 F152
G1 X43.017 Y47.426 F152
G1 X42.959 Y47.384 F152
G1 X42.94 Y47.37 F152
G1 X42.863 Y47.313 F152
G1 X42.845 Y47.299 F152
G1 X42.787 Y47.256 F152
G1 X42.786 F152
G1 X42.73 Y47.212 F152
G1 X42.713 Y47.198 F152
G1 X42.673 Y47.167 F152
G1 X42.64 Y47.141 F152
G1 X42.616 Y47.122 F152
G1 X42.558 Y47.077 F152
G1 X42.501 Y47.03 F152
G1 X42.444 Y46.983 F152
G1 X42.427 Y46.969 F152
G1 X42.386 Y46.936 F152
G1 X42.358 Y46.912 F152
G1 X42.329 Y46.888 F152
G1 X42.29 Y46.854 F152
G1 X42.272 Y46.838 F152
G1 X42.224 Y46.797 F152
G1 X42.215 Y46.788 F152
G1 X42.159 Y46.74 F152
G1 X42.157 Y46.738 F152
G1 X42.1 Y46.688 F152
G1 X42.094 Y46.683 F152
G1 X42.043 Y46.634 F152
G1 X42.033 Y46.625 F152
G1 X41.985 Y46.581 F152
G1 X41.972 Y46.568 F152
G1 X41.928 Y46.526 F152
G1 X41.912 Y46.511 F152
G1 X41.871 Y46.472 F152
G1 X41.814 Y46.418 F152
G1 X41.791 Y46.396 F152
G1 X41.756 Y46.364 F152
G1 X41.73 Y46.339 F152
G1 X41.699 Y46.309 F152
G1 X41.671 Y46.281 F152
G1 X41.616 Y46.224 F152
G1 X41.585 Y46.192 F152
G1 X41.56 Y46.167 F152
G1 X41.527 Y46.133 F152
G1 X41.505 Y46.11 F152
G1 X41.47 Y46.074 F152
G1 X41.449 Y46.052 F152
G1 X41.413 Y46.015 F152
G1 X41.393 Y45.995 F152
G1 X41.355 Y45.956 F152
G1 X41.338 Y45.938 F152
G1 X41.284 Y45.88 F152
G1 X41.231 Y45.823 F152
G1 X41.184 Y45.772 F152
G1 X41.177 Y45.766 F152
G1 X41.126 Y45.71 F152
G1 X41.125 Y45.709 F152
G1 X41.071 Y45.651 F152
G1 X41.069 Y45.649 F152
G1 X41.018 Y45.594 F152
G1 X41.012 Y45.587 F152
G1 X40.954 Y45.525 F152
G1 X40.912 Y45.479 F152
G1 X40.897 Y45.463 F152
G1 X40.84 Y45.401 F152
G1 X40.807 Y45.365 F152
G1 X40.783 Y45.339 F152
G1 X40.754 Y45.307 F152
G1 X40.725 Y45.277 F152
G1 X40.701 Y45.25 F152
G1 X40.668 Y45.215 F152
G1 X40.647 Y45.193 F152
G1 X40.611 Y45.153 F152
G1 X40.595 Y45.136 F152
G1 X40.541 Y45.078 F152
G1 X40.496 Y45.031 F152
G1 X40.486 Y45.021 F152
G1 X40.439 Y44.97 F152
G1 X40.433 Y44.964 F152
G1 X40.382 Y44.91 F152
G1 X40.378 Y44.906 F152
G1 X40.324 Y44.849 F152
G1 X40.268 Y44.792 F152
G1 X40.267 Y44.79 F152
G1 X40.213 Y44.734 F152
G1 X40.101 Y44.62 F152
G1 X40.095 Y44.615 F152
G1 X40.044 Y44.563 F152
G1 X40.038 Y44.556 F152
G1 X39.988 Y44.505 F152
G1 X39.981 Y44.498 F152
G1 X39.93 Y44.448 F152
G1 X39.923 Y44.442 F152
G1 X39.872 Y44.391 F152
G1 X39.866 Y44.385 F152
G1 X39.752 Y44.273 F152
G1 X39.694 Y44.217 F152
G1 X39.58 Y44.108 F152
G1 X39.576 Y44.104 F152
G1 X39.522 Y44.053 F152
G1 X39.515 Y44.047 F152
G1 X39.465 Y43.999 F152
G1 X39.408 Y43.947 F152
G1 X39.393 Y43.932 F152
G1 X39.33 Y43.875 F152
G1 X39.268 Y43.818 F152
G1 X39.236 Y43.788 F152
G1 X39.205 Y43.76 F152
G1 X39.179 Y43.738 F152
G1 X39.139 Y43.703 F152
G1 X39.122 Y43.687 F152
G1 X39.075 Y43.646 F152
G1 X39.064 Y43.636 F152
G1 X39.011 Y43.589 F152
G1 X39.007 Y43.586 F152
G1 X38.978 Y43.562 F152
G1 X38.977 Y43.56 F152
G1 X38.943 Y43.531 F152
G1 X38.935 Y43.525 F152
G1 X38.933 Y43.522 F152
G1 X38.93 Y43.52 F152
G1 X38.926 Y43.516 F152
; MOVEMENT_LINK_TRANSITION
G1 X38.925 Y43.517 F152
; MOVEMENT_CUTTING
G1 X38.928 Y43.522 F152
G1 X38.93 Y43.527 F152
G1 X38.933 Y43.531 F152
G1 X38.936 Y43.538 F152
G1 X38.941 Y43.546 F152
G1 X38.948 Y43.56 F152
G1 X38.95 Y43.563 F152
G1 X38.956 Y43.574 F152
G1 X38.964 Y43.589 F152
G1 X38.994 Y43.646 F152
G1 X39.007 Y43.668 F152
G1 X39.026 Y43.703 F152
G1 X39.057 Y43.76 F152
G1 X39.064 Y43.775 F152
G1 X39.092 Y43.818 F152
G1 X39.122 Y43.865 F152
G1 X39.128 Y43.875 F152
G1 X39.164 Y43.932 F152
G1 X39.179 Y43.956 F152
G1 X39.2 Y43.99 F152
G1 X39.272 Y44.104 F152
G1 X39.293 Y44.137 F152
G1 X39.311 Y44.162 F152
G1 X39.351 Y44.217 F152
G1 X39.352 Y44.219 F152
G1 X39.393 Y44.276 F152
G1 X39.408 Y44.298 F152
G1 X39.434 Y44.333 F152
G1 X39.465 Y44.378 F152
G1 X39.515 Y44.448 F152
G1 X39.522 Y44.458 F152
G1 X39.558 Y44.505 F152
G1 X39.58 Y44.532 F152
G1 X39.603 Y44.563 F152
G1 X39.637 Y44.606 F152
G1 X39.648 Y44.62 F152
G1 X39.693 Y44.677 F152
G1 X39.694 Y44.68 F152
G1 X39.737 Y44.734 F152
G1 X39.752 Y44.753 F152
G1 X39.809 Y44.826 F152
G1 X39.828 Y44.849 F152
G1 X39.875 Y44.906 F152
G1 X39.922 Y44.964 F152
G1 X39.923 Y44.965 F152
G1 X39.968 Y45.021 F152
G1 X39.981 Y45.036 F152
G1 X40.016 Y45.078 F152
G1 X40.038 Y45.106 F152
G1 X40.062 Y45.136 F152
G1 X40.095 Y45.176 F152
G1 X40.11 Y45.193 F152
G1 X40.153 Y45.246 F152
G1 X40.157 Y45.25 F152
G1 X40.204 Y45.307 F152
G1 X40.21 Y45.315 F152
G1 X40.267 Y45.384 F152
G1 X40.298 Y45.422 F152
G1 X40.346 Y45.479 F152
G1 X40.382 Y45.524 F152
G1 X40.392 Y45.537 F152
G1 X40.485 Y45.651 F152
G1 X40.496 Y45.665 F152
G1 X40.532 Y45.709 F152
G1 X40.554 Y45.735 F152
G1 X40.579 Y45.766 F152
G1 X40.623 Y45.823 F152
G1 X40.668 Y45.88 F152
G1 X40.669 F152
G1 X40.715 Y45.938 F152
G1 X40.725 Y45.952 F152
G1 X40.759 Y45.995 F152
G1 X40.783 Y46.025 F152
G1 X40.804 Y46.052 F152
G1 X40.84 Y46.1 F152
G1 X40.848 Y46.11 F152
G1 X40.891 Y46.167 F152
G1 X40.897 Y46.175 F152
G1 X40.935 Y46.224 F152
G1 X40.954 Y46.251 F152
G1 X40.978 Y46.281 F152
G1 X41.012 Y46.326 F152
G1 X41.022 Y46.339 F152
G1 X41.064 Y46.396 F152
G1 X41.069 Y46.404 F152
G1 X41.104 Y46.453 F152
G1 X41.126 Y46.485 F152
G1 X41.145 Y46.511 F152
G1 X41.184 Y46.565 F152
G1 X41.185 Y46.568 F152
G1 X41.227 Y46.625 F152
G1 X41.241 Y46.646 F152
G1 X41.267 Y46.683 F152
G1 X41.298 Y46.727 F152
G1 X41.307 Y46.74 F152
G1 X41.347 Y46.797 F152
G1 X41.355 Y46.811 F152
G1 X41.384 Y46.854 F152
G1 X41.457 Y46.969 F152
G1 X41.47 Y46.989 F152
G1 X41.494 Y47.026 F152
G1 X41.527 Y47.077 F152
G1 X41.532 Y47.084 F152
G1 X41.568 Y47.141 F152
G1 X41.585 Y47.167 F152
G1 X41.605 Y47.198 F152
G1 X41.64 Y47.256 F152
G1 X41.642 Y47.259 F152
G1 X41.673 Y47.313 F152
G1 X41.699 Y47.358 F152
G1 X41.706 Y47.37 F152
G1 X41.739 Y47.427 F152
G1 X41.756 Y47.456 F152
G1 X41.772 Y47.485 F152
G1 X41.803 Y47.542 F152
G1 X41.814 Y47.564 F152
G1 X41.833 Y47.599 F152
G1 X41.864 Y47.657 F152
G1 X41.871 Y47.671 F152
G1 X41.893 Y47.714 F152
G1 X41.921 Y47.771 F152
G1 X41.928 Y47.787 F152
G1 X41.948 Y47.829 F152
G1 X41.975 Y47.886 F152
G1 X41.985 Y47.909 F152
G1 X42.002 Y47.943 F152
G1 X42.028 Y48 F152
G1 X42.043 Y48.04 F152
G1 X42.05 Y48.058 F152
G1 X42.073 Y48.115 F152
G1 X42.096 Y48.172 F152
G1 X42.1 Y48.184 F152
G1 X42.119 Y48.23 F152
G1 X42.139 Y48.287 F152
G1 X42.175 Y48.401 F152
G1 X42.192 Y48.459 F152
G1 X42.21 Y48.516 F152
G1 X42.215 Y48.532 F152
G1 X42.227 Y48.573 F152
G1 X42.241 Y48.631 F152
G1 X42.262 Y48.745 F152
G1 X42.272 Y48.803 F152
G1 X42.283 Y48.86 F152
G1 X42.292 Y48.917 F152
G1 X42.3 Y48.974 F152
G1 X42.31 Y49.146 F152
G1 Y49.204 F152
G1 X42.309 Y49.261 F152
G1 X42.303 Y49.376 F152
G1 X42.297 Y49.433 F152
G1 X42.288 Y49.49 F152
G1 X42.277 Y49.547 F152
G1 X42.272 Y49.578 F152
G1 X42.267 Y49.605 F152
G1 X42.255 Y49.662 F152
G1 X42.238 Y49.719 F152
G1 X42.219 Y49.777 F152
G1 X42.215 Y49.788 F152
G1 X42.199 Y49.834 F152
G1 X42.178 Y49.891 F152
G1 X42.157 Y49.94 F152
G1 X42.154 Y49.948 F152
G1 X42.124 Y50.006 F152
G1 X42.06 Y50.12 F152
G1 X42.043 Y50.148 F152
G1 X42.024 Y50.178 F152
G1 X41.985 Y50.232 F152
G1 X41.984 Y50.235 F152
G1 X41.936 Y50.292 F152
G1 X41.928 Y50.301 F152
G1 X41.886 Y50.35 F152
G1 X41.871 Y50.367 F152
G1 X41.835 Y50.407 F152
G1 X41.814 Y50.428 F152
G1 X41.774 Y50.464 F152
G1 X41.756 Y50.48 F152
G1 X41.704 Y50.521 F152
G1 X41.699 Y50.526 F152
G1 X41.642 Y50.571 F152
G1 X41.631 Y50.579 F152
G1 X41.585 Y50.613 F152
G1 X41.548 Y50.636 F152
G1 X41.527 Y50.649 F152
G1 X41.47 Y50.68 F152
G1 X41.445 Y50.693 F152
G1 X41.413 Y50.711 F152
G1 X41.355 Y50.741 F152
G1 X41.333 Y50.751 F152
G1 X41.298 Y50.766 F152
G1 X41.241 Y50.787 F152
G1 X41.185 Y50.808 F152
G1 X41.184 Y50.809 F152
G1 X41.126 Y50.829 F152
G1 X41.069 Y50.846 F152
G1 X41.012 Y50.86 F152
G1 X40.988 Y50.865 F152
G1 X40.954 Y50.873 F152
G1 X40.897 Y50.887 F152
G1 X40.84 Y50.896 F152
G1 X40.725 Y50.908 F152
G1 X40.611 Y50.919 F152
G1 X40.575 Y50.923 F152
G1 X40.554 Y50.924 F152
G1 X40.496 Y50.927 F152
G1 X40.439 F152
G1 X40.382 Y50.924 F152
G1 X40.346 Y50.923 F152
G1 X40.324 F152
G1 X40.21 Y50.917 F152
G1 X40.153 Y50.914 F152
G1 X40.095 Y50.906 F152
G1 X39.981 Y50.889 F152
G1 X39.923 Y50.88 F152
G1 X39.866 Y50.872 F152
G1 X39.83 Y50.865 F152
G1 X39.809 Y50.862 F152
G1 X39.694 Y50.833 F152
G1 X39.637 Y50.82 F152
G1 X39.593 Y50.808 F152
G1 X39.58 Y50.805 F152
G1 X39.522 Y50.791 F152
G1 X39.465 Y50.774 F152
G1 X39.408 Y50.755 F152
G1 X39.397 Y50.751 F152
G1 X39.351 Y50.735 F152
G1 X39.236 Y50.696 F152
G1 X39.23 Y50.693 F152
G1 X39.179 Y50.676 F152
G1 X39.122 Y50.653 F152
G1 X39.064 Y50.629 F152
G1 X39.007 Y50.606 F152
G1 X38.95 Y50.58 F152
G1 X38.949 Y50.579 F152
G1 X38.892 Y50.553 F152
G1 X38.835 Y50.526 F152
G1 X38.778 Y50.497 F152
G1 X38.721 Y50.467 F152
G1 X38.716 Y50.464 F152
G1 X38.663 Y50.436 F152
G1 X38.61 Y50.407 F152
G1 X38.606 Y50.405 F152
G1 X38.549 Y50.371 F152
G1 X38.514 Y50.35 F152
G1 X38.491 Y50.336 F152
G1 X38.434 Y50.302 F152
G1 X38.419 Y50.292 F152
G1 X38.377 Y50.264 F152
G1 X38.334 Y50.235 F152
G1 X38.32 Y50.225 F152
G1 X38.249 Y50.178 F152
G1 X38.205 Y50.145 F152
G1 X38.172 Y50.12 F152
G1 X38.148 Y50.102 F152
G1 X38.097 Y50.063 F152
G1 X38.091 Y50.059 F152
G1 X38.033 Y50.014 F152
G1 X38.023 Y50.006 F152
G1 X37.976 Y49.966 F152
G1 X37.956 Y49.948 F152
G1 X37.919 Y49.916 F152
G1 X37.89 Y49.891 F152
G1 X37.861 Y49.867 F152
G1 X37.825 Y49.834 F152
G1 X37.804 Y49.814 F152
G1 X37.766 Y49.777 F152
G1 X37.747 Y49.759 F152
G1 X37.707 Y49.719 F152
G1 X37.69 Y49.702 F152
G1 X37.648 Y49.662 F152
G1 X37.632 Y49.645 F152
G1 X37.596 Y49.605 F152
G1 X37.543 Y49.547 F152
G1 X37.518 Y49.52 F152
G1 X37.491 Y49.49 F152
G1 X37.46 Y49.455 F152
G1 X37.443 Y49.433 F152
G1 X37.403 Y49.385 F152
G1 X37.349 Y49.318 F152
G1 X37.346 Y49.316 F152
G1 X37.303 Y49.261 F152
G1 X37.289 Y49.24 F152
G1 X37.262 Y49.204 F152
G1 X37.231 Y49.16 F152
G1 X37.221 Y49.146 F152
G1 X37.18 Y49.089 F152
G1 X37.14 Y49.032 F152
G1 X37.117 Y49 F152
G1 X37.099 Y48.974 F152
G1 X37.059 Y48.918 F152
G1 Y48.917 F152
G1 X37.022 Y48.86 F152
G1 X36.988 Y48.803 F152
G1 X36.953 Y48.745 F152
G1 X36.945 Y48.732 F152
G1 X36.918 Y48.688 F152
G1 X36.888 Y48.638 F152
G1 X36.883 Y48.631 F152
G1 X36.848 Y48.573 F152
G1 X36.83 Y48.544 F152
G1 X36.814 Y48.516 F152
G1 X36.783 Y48.459 F152
G1 X36.773 Y48.44 F152
G1 X36.752 Y48.401 F152
G1 X36.721 Y48.344 F152
G1 X36.659 Y48.23 F152
G1 Y48.229 F152
G1 X36.628 Y48.172 F152
G1 X36.601 Y48.122 F152
G1 X36.598 Y48.115 F152
G1 X36.568 Y48.058 F152
G1 X36.544 Y48.01 F152
G1 X36.539 Y48 F152
G1 X36.509 Y47.943 F152
G1 X36.487 Y47.897 F152
G1 X36.48 Y47.886 F152
G1 X36.452 Y47.829 F152
G1 X36.429 Y47.783 F152
G1 X36.423 Y47.771 F152
G1 X36.395 Y47.714 F152
G1 X36.372 Y47.668 F152
G1 X36.366 Y47.657 F152
G1 X36.338 Y47.599 F152
G1 X36.281 Y47.485 F152
G1 X36.258 Y47.437 F152
G1 X36.253 Y47.427 F152
G1 X36.224 Y47.37 F152
G1 X36.2 Y47.321 F152
G1 X36.196 Y47.313 F152
G1 X36.168 Y47.256 F152
G1 X36.111 Y47.141 F152
G1 X36.086 Y47.09 F152
G1 X36.082 Y47.084 F152
G1 X36.054 Y47.026 F152
G1 X36.028 Y46.974 F152
G1 X36.026 Y46.969 F152
G1 X35.996 Y46.912 F152
G1 X35.971 Y46.861 F152
G1 X35.968 Y46.854 F152
G1 X35.882 Y46.683 F152
G1 X35.857 Y46.633 F152
G1 X35.852 Y46.625 F152
G1 X35.823 Y46.568 F152
G1 X35.794 Y46.511 F152
G1 X35.764 Y46.453 F152
G1 X35.742 Y46.409 F152
G1 X35.735 Y46.396 F152
G1 X35.705 Y46.339 F152
G1 X35.685 Y46.299 F152
G1 X35.676 Y46.281 F152
G1 X35.646 Y46.224 F152
G1 X35.628 Y46.187 F152
G1 X35.617 Y46.167 F152
G1 X35.586 Y46.11 F152
G1 X35.57 Y46.077 F152
G1 X35.557 Y46.052 F152
G1 X35.526 Y45.995 F152
G1 X35.513 Y45.968 F152
G1 X35.466 Y45.88 F152
G1 X35.456 Y45.86 F152
G1 X35.436 Y45.823 F152
G1 X35.406 Y45.766 F152
G1 X35.398 Y45.751 F152
G1 X35.375 Y45.709 F152
G1 X35.345 Y45.651 F152
G1 X35.341 Y45.644 F152
G1 X35.314 Y45.594 F152
G1 X35.284 Y45.538 F152
G1 X35.283 Y45.537 F152
G1 X35.253 Y45.479 F152
G1 X35.227 Y45.431 F152
G1 X35.222 Y45.422 F152
G1 X35.191 Y45.365 F152
G1 X35.169 Y45.324 F152
G1 X35.16 Y45.307 F152
G1 X35.129 Y45.25 F152
G1 X35.112 Y45.219 F152
G1 X35.098 Y45.193 F152
G1 X35.066 Y45.136 F152
G1 X35.055 Y45.113 F152
G1 X35.036 Y45.078 F152
G1 X35.004 Y45.021 F152
G1 X34.997 Y45.008 F152
G1 X34.972 Y44.964 F152
G1 X34.941 Y44.906 F152
G1 X34.94 Y44.905 F152
G1 X34.91 Y44.849 F152
G1 X34.883 Y44.8 F152
G1 X34.846 Y44.734 F152
G1 X34.826 Y44.696 F152
G1 X34.815 Y44.677 F152
G1 X34.783 Y44.62 F152
G1 X34.768 Y44.593 F152
G1 X34.751 Y44.563 F152
G1 X34.719 Y44.505 F152
G1 X34.711 Y44.49 F152
G1 X34.687 Y44.448 F152
G1 X34.655 Y44.391 F152
G1 X34.654 Y44.389 F152
G1 X34.622 Y44.333 F152
G1 X34.596 Y44.287 F152
G1 X34.59 Y44.276 F152
G1 X34.558 Y44.219 F152
G1 X34.539 Y44.186 F152
G1 X34.525 Y44.162 F152
G1 X34.493 Y44.104 F152
G1 X34.482 Y44.085 F152
G1 X34.46 Y44.047 F152
G1 X34.426 Y43.99 F152
G1 X34.425 Y43.986 F152
G1 X34.393 Y43.932 F152
G1 X34.367 Y43.887 F152
G1 X34.36 Y43.875 F152
G1 X34.31 Y43.788 F152
G1 X34.294 Y43.76 F152
G1 X34.26 Y43.703 F152
G1 X34.253 Y43.691 F152
G1 X34.226 Y43.646 F152
G1 X34.196 Y43.594 F152
G1 X34.192 Y43.589 F152
G1 X34.138 Y43.498 F152
G1 X34.123 Y43.474 F152
G1 X34.088 Y43.417 F152
G1 X34.081 Y43.404 F152
G1 X34.053 Y43.359 F152
G1 X34.024 Y43.312 F152
G1 X33.909 Y43.133 F152
G1 X33.907 Y43.13 F152
G1 X33.871 Y43.073 F152
G1 X33.852 Y43.042 F152
G1 X33.833 Y43.016 F152
G1 X33.795 Y42.96 F152
G1 X33.793 Y42.958 F152
G1 X33.753 Y42.901 F152
G1 X33.737 Y42.878 F152
G1 X33.713 Y42.844 F152
G1 X33.68 Y42.795 F152
G1 X33.674 Y42.786 F152
G1 X33.632 Y42.729 F152
G1 X33.588 Y42.672 F152
G1 X33.565 Y42.643 F152
G1 X33.542 Y42.614 F152
G1 X33.508 Y42.573 F152
G1 X33.495 Y42.557 F152
G1 X33.444 Y42.5 F152
G1 X33.394 Y42.447 F152
G1 X33.389 Y42.443 F152
G1 X33.336 Y42.393 F152
G1 X33.327 Y42.385 F152
G1 X33.308 Y42.368 F152
G1 X33.302 Y42.364 F152
G1 X33.301 Y42.363 F152
G1 X33.298 Y42.36 F152
G1 X33.297 F152
; MOVEMENT_LINK_TRANSITION
G1 X33.293 Y42.358 F152
; MOVEMENT_CUTTING
G1 X33.279 Y42.366 F152
G1 X33.165 Y42.43 F152
G1 X33.141 Y42.443 F152
G1 X33.107 Y42.462 F152
G1 X33.05 Y42.499 F152
G1 X33.049 Y42.5 F152
G1 X32.963 Y42.557 F152
G1 X32.935 Y42.577 F152
G1 X32.88 Y42.614 F152
G1 X32.878 Y42.616 F152
G1 X32.821 Y42.656 F152
G1 X32.798 Y42.672 F152
G1 X32.792 Y42.675 F152
G1 X32.785 Y42.681 F152
G1 X32.78 Y42.684 F152
; MOVEMENT_LINK_TRANSITION
G1 X32.779 Y42.685 F152
; MOVEMENT_CUTTING
G1 Y42.686 F152
G1 Y42.7 F152
G1 X32.78 Y42.729 F152
G1 X32.785 Y42.844 F152
G1 X32.794 Y42.958 F152
G1 X32.799 Y43.016 F152
G1 X32.806 Y43.073 F152
G1 X32.813 Y43.13 F152
G1 X32.819 Y43.187 F152
G1 X32.821 Y43.209 F152
G1 X32.825 Y43.245 F152
G1 X32.832 Y43.302 F152
G1 X32.856 Y43.474 F152
G1 X32.865 Y43.531 F152
G1 X32.873 Y43.589 F152
G1 X32.878 Y43.631 F152
G1 X32.881 Y43.646 F152
G1 X32.899 Y43.76 F152
G1 X32.909 Y43.818 F152
G1 X32.918 Y43.875 F152
G1 X32.927 Y43.932 F152
G1 X32.935 Y43.986 F152
G1 X32.936 Y43.99 F152
G1 X32.946 Y44.047 F152
G1 X32.964 Y44.162 F152
G1 X32.974 Y44.219 F152
G1 X32.983 Y44.276 F152
G1 X32.993 Y44.333 F152
G1 Y44.339 F152
G1 X33.002 Y44.391 F152
G1 X33.011 Y44.448 F152
G1 X33.02 Y44.505 F152
G1 X33.038 Y44.62 F152
G1 X33.048 Y44.677 F152
G1 X33.05 Y44.692 F152
G1 X33.057 Y44.734 F152
G1 X33.084 Y44.906 F152
G1 X33.092 Y44.964 F152
G1 X33.101 Y45.021 F152
G1 X33.107 Y45.068 F152
G1 X33.109 Y45.078 F152
G1 X33.118 Y45.136 F152
G1 X33.126 Y45.193 F152
G1 X33.148 Y45.365 F152
G1 X33.154 Y45.422 F152
G1 X33.161 Y45.479 F152
G1 X33.165 Y45.512 F152
G1 X33.168 Y45.537 F152
G1 X33.174 Y45.594 F152
G1 X33.185 Y45.709 F152
G1 X33.194 Y45.823 F152
G1 X33.198 Y45.88 F152
G1 X33.2 Y45.938 F152
G1 X33.204 Y45.995 F152
G1 Y46.339 F152
G1 X33.2 Y46.396 F152
G1 X33.191 Y46.511 F152
G1 X33.185 Y46.568 F152
G1 X33.169 Y46.683 F152
G1 X33.16 Y46.74 F152
G1 X33.148 Y46.797 F152
G1 X33.136 Y46.854 F152
G1 X33.122 Y46.912 F152
G1 X33.107 Y46.966 F152
G1 Y46.969 F152
G1 X33.088 Y47.026 F152
G1 X33.071 Y47.084 F152
G1 X33.051 Y47.141 F152
G1 X33.05 Y47.142 F152
G1 X33.027 Y47.198 F152
G1 X33.003 Y47.256 F152
G1 X32.993 Y47.277 F152
G1 X32.977 Y47.313 F152
G1 X32.948 Y47.37 F152
G1 X32.935 Y47.392 F152
G1 X32.915 Y47.427 F152
G1 X32.878 Y47.491 F152
G1 X32.847 Y47.542 F152
G1 X32.821 Y47.579 F152
G1 X32.806 Y47.599 F152
G1 X32.764 Y47.654 F152
G1 X32.762 Y47.657 F152
G1 X32.717 Y47.714 F152
G1 X32.706 Y47.726 F152
G1 X32.666 Y47.771 F152
G1 X32.551 Y47.886 F152
G1 X32.534 Y47.901 F152
G1 X32.485 Y47.943 F152
G1 X32.477 Y47.949 F152
G1 X32.363 Y48.035 F152
G1 X32.332 Y48.058 F152
G1 X32.305 Y48.076 F152
G1 X32.248 Y48.112 F152
G1 X32.244 Y48.115 F152
G1 X32.138 Y48.172 F152
G1 X32.133 Y48.175 F152
G1 X32.076 Y48.205 F152
G1 X32.025 Y48.23 F152
G1 X32.019 Y48.232 F152
G1 X31.962 Y48.256 F152
G1 X31.904 Y48.278 F152
G1 X31.88 Y48.287 F152
G1 X31.847 Y48.3 F152
G1 X31.79 Y48.32 F152
G1 X31.733 Y48.337 F152
G1 X31.705 Y48.344 F152
G1 X31.675 Y48.352 F152
G1 X31.618 Y48.367 F152
G1 X31.561 Y48.382 F152
G1 X31.503 Y48.393 F152
G1 X31.452 Y48.401 F152
G1 X31.389 Y48.412 F152
G1 X31.332 Y48.421 F152
G1 X31.274 Y48.427 F152
G1 X31.102 Y48.441 F152
G1 X31.045 Y48.442 F152
G1 X30.931 F152
G1 X30.873 Y48.441 F152
G1 X30.702 Y48.427 F152
G1 X30.644 Y48.421 F152
G1 X30.587 Y48.411 F152
G1 X30.53 Y48.402 F152
G1 X30.529 Y48.401 F152
G1 X30.472 Y48.393 F152
G1 X30.415 Y48.38 F152
G1 X30.358 Y48.366 F152
G1 X30.301 Y48.35 F152
G1 X30.283 Y48.344 F152
G1 X30.243 Y48.333 F152
G1 X30.186 Y48.316 F152
G1 X30.129 Y48.295 F152
G1 X30.111 Y48.287 F152
G1 X30.071 Y48.271 F152
G1 X30.014 Y48.247 F152
G1 X29.975 Y48.23 F152
G1 X29.957 Y48.222 F152
G1 X29.9 Y48.194 F152
G1 X29.861 Y48.172 F152
G1 X29.842 Y48.162 F152
G1 X29.785 Y48.126 F152
G1 X29.768 Y48.115 F152
G1 X29.728 Y48.09 F152
G1 X29.678 Y48.058 F152
G1 X29.671 Y48.053 F152
G1 X29.613 Y48.01 F152
G1 X29.601 Y48 F152
G1 X29.556 Y47.962 F152
G1 X29.535 Y47.943 F152
G1 X29.47 Y47.886 F152
G1 X29.441 Y47.859 F152
G1 X29.411 Y47.829 F152
G1 X29.384 Y47.799 F152
G1 X29.361 Y47.771 F152
G1 X29.313 Y47.714 F152
G1 X29.265 Y47.657 F152
G1 X29.223 Y47.599 F152
G1 X29.212 Y47.583 F152
G1 X29.186 Y47.542 F152
G1 X29.155 Y47.493 F152
G1 X29.15 Y47.485 F152
G1 X29.114 Y47.427 F152
G1 X29.082 Y47.37 F152
G1 X29.055 Y47.313 F152
G1 X29.04 Y47.282 F152
G1 X29.027 Y47.256 F152
G1 X28.999 Y47.198 F152
G1 X28.983 Y47.16 F152
G1 X28.975 Y47.141 F152
G1 X28.955 Y47.084 F152
G1 X28.933 Y47.026 F152
G1 X28.926 Y47.007 F152
G1 X28.912 Y46.969 F152
G1 X28.891 Y46.912 F152
G1 X28.872 Y46.854 F152
G1 X28.869 Y46.841 F152
G1 X28.856 Y46.797 F152
G1 X28.839 Y46.74 F152
G1 X28.823 Y46.683 F152
G1 X28.811 Y46.64 F152
G1 X28.807 Y46.625 F152
G1 X28.792 Y46.568 F152
G1 X28.763 Y46.453 F152
G1 X28.754 Y46.414 F152
G1 X28.75 Y46.396 F152
G1 X28.736 Y46.339 F152
G1 X28.699 Y46.167 F152
G1 X28.697 Y46.156 F152
G1 X28.686 Y46.11 F152
G1 X28.593 Y45.651 F152
G1 X28.582 Y45.596 F152
G1 X28.581 Y45.594 F152
G1 X28.57 Y45.537 F152
G1 X28.559 Y45.479 F152
G1 X28.536 Y45.365 F152
G1 X28.525 Y45.31 F152
G1 X28.524 Y45.307 F152
G1 X28.477 Y45.078 F152
G1 X28.468 Y45.031 F152
G1 X28.465 Y45.021 F152
G1 X28.442 Y44.906 F152
G1 X28.429 Y44.849 F152
G1 X28.418 Y44.792 F152
G1 X28.41 Y44.759 F152
G1 X28.405 Y44.734 F152
G1 X28.367 Y44.563 F152
G1 X28.354 Y44.505 F152
G1 X28.353 Y44.499 F152
G1 X28.341 Y44.448 F152
G1 X28.315 Y44.333 F152
G1 X28.302 Y44.276 F152
G1 X28.296 Y44.248 F152
G1 X28.289 Y44.219 F152
G1 X28.276 Y44.162 F152
G1 X28.249 Y44.047 F152
G1 X28.239 Y44.003 F152
G1 X28.235 Y43.99 F152
G1 X28.192 Y43.818 F152
G1 X28.181 Y43.774 F152
G1 X28.177 Y43.76 F152
G1 X28.116 Y43.531 F152
G1 X28.092 Y43.445 F152
G1 X28.087 Y43.431 F152
G1 X28.086 Y43.427 F152
; MOVEMENT_LINK_TRANSITION
; MOVEMENT_CUTTING
G1 X28.085 F152
G1 X28.081 Y43.429 F152
G1 X28.075 Y43.431 F152
G1 X28.067 Y43.435 F152
G1 X28.009 Y43.457 F152
G1 X27.966 Y43.474 F152
G1 X27.952 Y43.479 F152
G1 X27.895 Y43.502 F152
G1 X27.838 Y43.52 F152
G1 X27.802 Y43.531 F152
G1 X27.78 Y43.538 F152
G1 X27.723 Y43.556 F152
G1 X27.666 Y43.575 F152
G1 X27.615 Y43.589 F152
G1 X27.608 Y43.59 F152
G1 X27.494 Y43.619 F152
G1 X27.379 Y43.646 F152
G1 X27.378 F152
G1 X27.322 Y43.657 F152
G1 X27.265 Y43.666 F152
G1 X27.208 Y43.677 F152
G1 X27.093 Y43.697 F152
G1 X27.036 Y43.703 F152
G1 X27.034 F152
G1 X26.978 Y43.71 F152
G1 X26.807 Y43.729 F152
G1 X26.692 Y43.736 F152
G1 X26.635 Y43.739 F152
G1 X26.577 Y43.743 F152
G1 X26.52 Y43.745 F152
G1 X26.463 Y43.746 F152
G1 X26.348 F152
G1 X26.291 Y43.747 F152
G1 X26.234 F152
G1 X26.176 Y43.746 F152
G1 X25.89 Y43.733 F152
G1 X25.833 Y43.728 F152
G1 X25.718 Y43.716 F152
G1 X25.661 Y43.71 F152
G1 X25.604 Y43.704 F152
G1 X25.601 Y43.703 F152
G1 X25.546 Y43.698 F152
G1 X25.432 Y43.685 F152
G1 X25.375 Y43.68 F152
G1 X25.317 Y43.674 F152
G1 X25.26 Y43.666 F152
G1 X25.203 Y43.657 F152
G1 X25.145 Y43.647 F152
G1 X25.141 Y43.646 F152
G1 X25.088 Y43.638 F152
G1 X25.031 Y43.628 F152
G1 X24.974 Y43.619 F152
G1 X24.916 Y43.609 F152
G1 X24.859 Y43.6 F152
G1 X24.573 Y43.542 F152
G1 X24.522 Y43.531 F152
G1 X24.515 Y43.53 F152
G1 X24.458 Y43.519 F152
G1 X24.401 Y43.506 F152
G1 X24.344 Y43.493 F152
G1 X24.286 Y43.478 F152
G1 X24.27 Y43.474 F152
G1 X24.229 Y43.464 F152
G1 X24.172 Y43.45 F152
G1 X24.114 Y43.436 F152
G1 X24.057 Y43.422 F152
G1 X24.037 Y43.417 F152
G1 X24 Y43.408 F152
G1 X23.885 Y43.379 F152
G1 X23.828 Y43.366 F152
G1 X23.806 Y43.359 F152
G1 X23.771 Y43.351 F152
G1 X23.599 Y43.308 F152
G1 X23.577 Y43.302 F152
G1 X23.542 Y43.293 F152
G1 X23.484 Y43.277 F152
G1 X23.37 Y43.247 F152
G1 X23.366 Y43.245 F152
G1 X23.255 Y43.215 F152
G1 X23.198 Y43.199 F152
G1 X23.156 Y43.187 F152
G1 X23.141 Y43.184 F152
G1 X23.083 Y43.168 F152
G1 X23.026 Y43.153 F152
G1 X22.969 Y43.136 F152
G1 X22.946 Y43.13 F152
G1 X22.912 Y43.121 F152
G1 X22.854 Y43.106 F152
G1 X22.797 Y43.09 F152
G1 X22.74 Y43.075 F152
G1 X22.733 Y43.073 F152
G1 X22.682 Y43.059 F152
G1 X22.568 Y43.029 F152
G1 X22.519 Y43.016 F152
G1 X22.511 Y43.014 F152
G1 X22.339 Y42.971 F152
G1 X22.29 Y42.958 F152
G1 X22.282 Y42.956 F152
G1 X22.167 Y42.928 F152
G1 X22.052 Y42.901 F152
G1 X21.995 Y42.889 F152
G1 X21.881 Y42.864 F152
G1 X21.823 Y42.853 F152
G1 X21.777 Y42.844 F152
G1 X21.766 Y42.842 F152
G1 X21.651 Y42.82 F152
G1 X21.48 Y42.794 F152
G1 X21.43 Y42.786 F152
G1 X21.422 Y42.785 F152
G1 X21.308 Y42.771 F152
G1 X21.136 Y42.755 F152
G1 X21.021 Y42.748 F152
G1 X20.964 Y42.745 F152
G1 X20.907 Y42.743 F152
G1 X20.85 F152
G1 X20.792 F152
G1 X20.678 Y42.744 F152
G1 X20.62 Y42.746 F152
G1 X20.563 Y42.751 F152
G1 X20.449 Y42.758 F152
G1 X20.391 Y42.764 F152
G1 X20.334 Y42.769 F152
G1 X20.277 Y42.776 F152
G1 X20.219 Y42.783 F152
G1 X20.192 Y42.786 F152
G1 X20.162 Y42.791 F152
G1 X20.048 Y42.805 F152
G1 X19.99 Y42.813 F152
G1 X19.933 Y42.82 F152
G1 X19.876 Y42.827 F152
G1 X19.819 Y42.833 F152
G1 X19.761 Y42.84 F152
G1 X19.724 Y42.844 F152
G1 X19.704 Y42.846 F152
G1 X19.647 Y42.853 F152
G1 X19.589 Y42.86 F152
G1 X19.532 Y42.864 F152
G1 X19.475 Y42.868 F152
G1 X19.418 Y42.871 F152
G1 X19.36 Y42.874 F152
G1 X19.303 Y42.876 F152
G1 X19.188 F152
G1 X19.131 Y42.877 F152
G1 X19.074 Y42.875 F152
G1 X18.902 Y42.864 F152
G1 X18.845 Y42.859 F152
G1 X18.787 Y42.851 F152
G1 X18.739 Y42.844 F152
G1 X18.73 Y42.843 F152
G1 X18.673 Y42.834 F152
G1 X18.616 Y42.826 F152
G1 X18.558 Y42.814 F152
G1 X18.501 Y42.801 F152
G1 X18.446 Y42.786 F152
G1 X18.444 F152
G1 X18.329 Y42.758 F152
G1 X18.272 Y42.74 F152
G1 X18.243 Y42.729 F152
G1 X18.215 Y42.719 F152
G1 X18.157 Y42.698 F152
G1 X18.1 Y42.677 F152
G1 X18.088 Y42.672 F152
G1 X18.043 Y42.656 F152
G1 X17.986 Y42.631 F152
G1 X17.953 Y42.614 F152
G1 X17.928 Y42.603 F152
G1 X17.871 Y42.575 F152
G1 X17.835 Y42.557 F152
G1 X17.814 Y42.547 F152
G1 X17.756 Y42.515 F152
G1 X17.731 Y42.5 F152
G1 X17.699 Y42.481 F152
G1 X17.642 Y42.446 F152
G1 X17.637 Y42.443 F152
G1 X17.585 Y42.411 F152
G1 X17.545 Y42.385 F152
G1 X17.527 Y42.374 F152
G1 X17.413 Y42.288 F152
G1 X17.39 Y42.271 F152
G1 X17.356 Y42.245 F152
G1 X17.315 Y42.213 F152
G1 X17.298 Y42.2 F152
G1 X17.248 Y42.156 F152
G1 X17.241 Y42.149 F152
G1 X17.186 Y42.099 F152
G1 X17.184 Y42.097 F152
G1 X17.126 Y42.044 F152
G1 X17.124 Y42.042 F152
G1 X17.069 Y41.991 F152
G1 X17.062 Y41.984 F152
G1 X17.012 Y41.932 F152
G1 X17.006 Y41.927 F152
G1 X16.955 Y41.87 F152
G1 X16.902 Y41.812 F152
G1 X16.897 Y41.808 F152
G1 X16.85 Y41.755 F152
G1 X16.84 Y41.743 F152
G1 X16.803 Y41.698 F152
G1 X16.783 Y41.672 F152
G1 X16.725 Y41.6 F152
G1 X16.712 Y41.583 F152
G1 X16.668 Y41.527 F152
G1 X16.667 Y41.526 F152
G1 X16.626 Y41.469 F152
G1 X16.611 Y41.446 F152
G1 X16.587 Y41.411 F152
G1 X16.554 Y41.363 F152
G1 X16.547 Y41.354 F152
G1 X16.496 Y41.28 F152
G1 X16.471 Y41.239 F152
G1 X16.401 Y41.125 F152
G1 X16.367 Y41.067 F152
G1 X16.334 Y41.01 F152
G1 X16.324 Y40.992 F152
G1 X16.304 Y40.953 F152
G1 X16.273 Y40.896 F152
G1 X16.267 Y40.883 F152
G1 X16.243 Y40.838 F152
G1 X16.213 Y40.781 F152
G1 X16.21 Y40.775 F152
G1 X16.186 Y40.724 F152
G1 X16.16 Y40.666 F152
G1 X16.153 Y40.65 F152
G1 X16.134 Y40.609 F152
G1 X16.095 Y40.524 F152
G1 X16.083 Y40.494 F152
G1 X16.038 Y40.38 F152
G1 Y40.379 F152
G1 X16.016 Y40.323 F152
G1 X15.994 Y40.265 F152
G1 X15.981 Y40.228 F152
G1 X15.975 Y40.208 F152
G1 X15.957 Y40.151 F152
G1 X15.938 Y40.093 F152
G1 X15.924 Y40.045 F152
G1 X15.92 Y40.036 F152
G1 X15.903 Y39.979 F152
G1 X15.888 Y39.922 F152
G1 X15.874 Y39.864 F152
G1 X15.866 Y39.829 F152
G1 X15.861 Y39.807 F152
G1 X15.847 Y39.75 F152
G1 X15.836 Y39.692 F152
G1 X15.826 Y39.635 F152
G1 X15.809 Y39.526 F152
G1 X15.808 Y39.52 F152
G1 X15.8 Y39.463 F152
G1 X15.795 Y39.406 F152
G1 X15.784 Y39.234 F152
G1 X15.782 Y39.177 F152
G1 X15.783 Y39.119 F152
G1 X15.788 Y39.062 F152
G1 X15.795 Y38.947 F152
G1 X15.799 Y38.89 F152
G1 X15.807 Y38.833 F152
G1 X15.809 Y38.826 F152
G1 X15.819 Y38.776 F152
G1 X15.831 Y38.718 F152
G1 X15.845 Y38.661 F152
G1 X15.859 Y38.604 F152
G1 X15.866 Y38.58 F152
G1 X15.877 Y38.546 F152
G1 X15.898 Y38.489 F152
G1 X15.923 Y38.432 F152
G1 X15.924 Y38.431 F152
G1 X15.947 Y38.375 F152
G1 X15.973 Y38.317 F152
G1 X16.003 Y38.26 F152
G1 X16.038 Y38.204 F152
G1 X16.039 Y38.203 F152
G1 X16.079 Y38.145 F152
G1 X16.12 Y38.088 F152
G1 X16.163 Y38.031 F152
G1 X16.21 Y37.976 F152
G1 X16.212 Y37.973 F152
G1 X16.269 Y37.916 F152
G1 X16.324 Y37.868 F152
G1 X16.335 Y37.859 F152
G1 X16.382 Y37.819 F152
G1 X16.403 Y37.802 F152
G1 X16.439 Y37.773 F152
G1 X16.479 Y37.744 F152
G1 X16.496 Y37.733 F152
G1 X16.554 Y37.698 F152
G1 X16.574 Y37.687 F152
G1 X16.611 Y37.667 F152
G1 X16.668 Y37.638 F152
G1 X16.683 Y37.63 F152
G1 X16.725 Y37.608 F152
G1 X16.783 Y37.583 F152
G1 X16.84 Y37.562 F152
G1 X16.955 Y37.526 F152
G1 X16.991 Y37.515 F152
G1 X17.012 Y37.509 F152
G1 X17.069 Y37.494 F152
G1 X17.126 Y37.484 F152
G1 X17.184 Y37.474 F152
G1 X17.241 Y37.465 F152
G1 X17.289 Y37.458 F152
G1 X17.298 Y37.456 F152
G1 X17.413 Y37.447 F152
G1 X17.527 Y37.44 F152
G1 X17.699 F152
G1 X17.756 Y37.442 F152
G1 X17.871 Y37.447 F152
G1 X17.928 Y37.451 F152
G1 X17.986 Y37.455 F152
G1 X18.012 Y37.458 F152
G1 X18.043 Y37.46 F152
G1 X18.1 Y37.465 F152
G1 X18.329 Y37.49 F152
G1 X18.444 Y37.504 F152
G1 X18.501 Y37.512 F152
G1 X18.558 Y37.52 F152
G1 X18.73 Y37.544 F152
G1 X18.787 Y37.553 F152
G1 X18.845 Y37.561 F152
G1 X18.902 Y37.57 F152
G1 X18.917 Y37.572 F152
G1 X18.959 Y37.579 F152
G1 X19.017 Y37.587 F152
G1 X19.246 Y37.622 F152
G1 X19.286 Y37.63 F152
G1 X19.36 Y37.641 F152
G1 X19.418 Y37.651 F152
G1 X19.475 Y37.66 F152
G1 X19.589 Y37.68 F152
G1 X19.629 Y37.687 F152
G1 X19.647 Y37.69 F152
G1 X19.761 Y37.709 F152
G1 X19.819 Y37.72 F152
G1 X19.876 Y37.73 F152
G1 X19.933 Y37.741 F152
G1 X19.953 Y37.744 F152
G1 X19.99 Y37.751 F152
G1 X20.105 Y37.772 F152
G1 X20.162 Y37.784 F152
G1 X20.219 Y37.794 F152
G1 X20.256 Y37.802 F152
G1 X20.277 Y37.805 F152
G1 X20.391 Y37.828 F152
G1 X20.449 Y37.839 F152
G1 X20.506 Y37.851 F152
G1 X20.543 Y37.859 F152
G1 X20.563 Y37.862 F152
G1 X20.62 Y37.875 F152
G1 X20.735 Y37.898 F152
G1 X20.792 Y37.911 F152
G1 X20.816 Y37.916 F152
G1 X20.85 Y37.923 F152
G1 X21.021 Y37.961 F152
G1 X21.075 Y37.973 F152
G1 X21.079 Y37.974 F152
G1 X21.136 Y37.987 F152
G1 X21.193 Y38 F152
G1 X21.25 Y38.013 F152
G1 X21.308 Y38.026 F152
G1 X21.325 Y38.031 F152
G1 X21.365 Y38.041 F152
G1 X21.48 Y38.067 F152
G1 X21.562 Y38.088 F152
G1 X21.594 Y38.095 F152
G1 X21.651 Y38.11 F152
G1 X21.766 Y38.139 F152
G1 X21.789 Y38.145 F152
G1 X21.823 Y38.153 F152
G1 X21.995 Y38.199 F152
G1 X22.008 Y38.203 F152
G1 X22.052 Y38.214 F152
G1 X22.11 Y38.229 F152
G1 X22.115 Y38.231 F152
G1 X22.117 F152
G1 X22.12 Y38.233 F152
; MOVEMENT_LINK_TRANSITION
G1 X22.122 Y38.231 F152
; MOVEMENT_CUTTING
G1 X22.121 Y38.224 F152
G1 Y38.217 F152
G1 X22.12 Y38.203 F152
G1 X22.116 Y38.145 F152
G1 X22.113 Y38.088 F152
G1 X22.114 Y38.031 F152
G1 X22.118 Y37.973 F152
G1 X22.122 Y37.916 F152
G1 X22.128 Y37.859 F152
G1 X22.136 Y37.802 F152
G1 X22.147 Y37.744 F152
G1 X22.162 Y37.687 F152
G1 X22.167 Y37.669 F152
G1 X22.177 Y37.63 F152
G1 X22.193 Y37.572 F152
G1 X22.213 Y37.515 F152
G1 X22.224 Y37.486 F152
G1 X22.236 Y37.458 F152
G1 X22.263 Y37.4 F152
G1 X22.282 Y37.361 F152
G1 X22.29 Y37.343 F152
G1 X22.319 Y37.286 F152
G1 X22.339 Y37.252 F152
G1 X22.353 Y37.229 F152
G1 X22.392 Y37.171 F152
G1 X22.396 Y37.166 F152
G1 X22.433 Y37.114 F152
G1 X22.453 Y37.086 F152
G1 X22.476 Y37.057 F152
G1 X22.511 Y37.015 F152
G1 X22.525 Y36.999 F152
G1 X22.568 Y36.955 F152
G1 X22.58 Y36.942 F152
G1 X22.625 Y36.896 F152
G1 X22.637 Y36.885 F152
G1 X22.682 Y36.843 F152
G1 X22.7 Y36.827 F152
G1 X22.74 Y36.797 F152
G1 X22.775 Y36.77 F152
G1 X22.797 Y36.753 F152
G1 X22.854 Y36.71 F152
G1 X22.912 Y36.671 F152
G1 X22.936 Y36.656 F152
G1 X22.969 Y36.637 F152
G1 X23.026 Y36.604 F152
G1 X23.035 Y36.598 F152
G1 X23.083 Y36.571 F152
G1 X23.141 Y36.541 F152
G1 X23.255 Y36.489 F152
G1 X23.267 Y36.484 F152
G1 X23.313 Y36.463 F152
G1 X23.37 Y36.442 F152
G1 X23.411 Y36.426 F152
G1 X23.427 Y36.42 F152
G1 X23.484 Y36.4 F152
G1 X23.542 Y36.38 F152
G1 X23.582 Y36.369 F152
G1 X23.599 Y36.364 F152
G1 X23.713 Y36.333 F152
G1 X23.771 Y36.317 F152
G1 X23.792 Y36.312 F152
G1 X23.828 Y36.302 F152
G1 X23.885 Y36.288 F152
G1 X24.057 Y36.255 F152
G1 X24.066 F152
G1 X24.114 Y36.246 F152
G1 X24.172 Y36.235 F152
G1 X24.229 Y36.226 F152
G1 X24.458 Y36.197 F152
G1 X24.464 F152
G1 X24.515 Y36.191 F152
G1 X24.63 Y36.182 F152
G1 X24.687 Y36.178 F152
G1 X24.745 Y36.174 F152
G1 X24.859 Y36.167 F152
G1 X24.916 Y36.165 F152
G1 X24.974 Y36.164 F152
G1 X25.088 Y36.161 F152
G1 X25.145 Y36.16 F152
G1 X25.203 F152
G1 X25.432 Y36.163 F152
G1 X25.489 Y36.165 F152
G1 X25.546 Y36.168 F152
G1 X25.661 Y36.175 F152
G1 X25.718 Y36.178 F152
G1 X25.833 Y36.185 F152
G1 X25.89 Y36.19 F152
G1 X25.947 Y36.196 F152
G1 X25.952 Y36.197 F152
G1 X26.005 Y36.203 F152
G1 X26.062 Y36.208 F152
G1 X26.176 Y36.221 F152
G1 X26.234 Y36.228 F152
G1 X26.291 Y36.237 F152
G1 X26.348 Y36.245 F152
G1 X26.406 Y36.254 F152
G1 X26.463 Y36.262 F152
G1 X26.52 Y36.271 F152
G1 X26.692 Y36.303 F152
G1 X26.738 Y36.312 F152
G1 X26.749 Y36.314 F152
G1 X26.807 Y36.324 F152
G1 X26.864 Y36.337 F152
G1 X26.921 Y36.35 F152
G1 X26.978 Y36.363 F152
G1 X27.003 Y36.369 F152
G1 X27.036 Y36.376 F152
G1 X27.093 Y36.39 F152
G1 X27.15 Y36.404 F152
G1 X27.208 Y36.419 F152
G1 X27.233 Y36.426 F152
G1 X27.265 Y36.434 F152
G1 X27.322 Y36.451 F152
G1 X27.379 Y36.466 F152
G1 X27.437 Y36.483 F152
G1 X27.439 Y36.484 F152
G1 X27.494 Y36.5 F152
G1 X27.608 Y36.536 F152
G1 X27.626 Y36.541 F152
G1 X27.666 Y36.553 F152
G1 X27.723 Y36.571 F152
G1 X27.78 Y36.591 F152
G1 X27.801 Y36.598 F152
G1 X27.838 Y36.611 F152
G1 X27.895 Y36.63 F152
G1 X27.952 Y36.649 F152
G1 X27.967 Y36.656 F152
G1 X28.009 Y36.671 F152
G1 X28.067 Y36.692 F152
G1 X28.123 Y36.713 F152
G1 X28.124 F152
G1 X28.181 Y36.734 F152
G1 X28.239 Y36.755 F152
G1 X28.279 Y36.77 F152
G1 X28.296 Y36.776 F152
G1 X28.353 Y36.797 F152
G1 X28.41 Y36.819 F152
G1 X28.434 Y36.827 F152
G1 X28.468 Y36.839 F152
G1 X28.582 Y36.882 F152
G1 X28.59 Y36.885 F152
G1 X28.639 Y36.903 F152
G1 X28.697 Y36.924 F152
G1 X28.746 Y36.942 F152
G1 X28.754 Y36.945 F152
G1 X28.811 Y36.965 F152
G1 X28.869 Y36.982 F152
G1 X28.922 Y36.999 F152
G1 X28.926 Y37 F152
G1 X28.983 Y37.018 F152
G1 X29.04 Y37.035 F152
G1 X29.098 Y37.053 F152
G1 X29.108 Y37.057 F152
G1 X29.155 Y37.07 F152
G1 X29.27 Y37.097 F152
G1 X29.327 Y37.108 F152
G1 X29.364 Y37.114 F152
G1 X29.384 Y37.117 F152
G1 X29.441 Y37.126 F152
G1 X29.499 Y37.131 F152
G1 X29.556 Y37.135 F152
G1 X29.613 Y37.138 F152
G1 X29.671 Y37.139 F152
G1 X29.728 F152
G1 X29.842 Y37.132 F152
G1 X29.9 Y37.127 F152
G1 X29.957 Y37.118 F152
G1 X29.99 Y37.114 F152
G1 X30.014 Y37.11 F152
G1 X30.071 Y37.101 F152
G1 X30.129 Y37.088 F152
G1 X30.186 Y37.076 F152
G1 X30.243 Y37.063 F152
G1 X30.267 Y37.057 F152
G1 X30.301 Y37.047 F152
G1 X30.358 Y37.032 F152
G1 X30.415 Y37.016 F152
G1 X30.465 Y36.999 F152
G1 X30.472 Y36.997 F152
G1 X30.587 Y36.959 F152
G1 X30.637 Y36.942 F152
G1 X30.759 Y36.896 F152
G1 X30.79 Y36.885 F152
G1 X30.816 Y36.875 F152
G1 X30.873 Y36.852 F152
G1 X31.045 Y36.779 F152
G1 X31.066 Y36.77 F152
G1 X31.102 Y36.755 F152
G1 X31.16 Y36.731 F152
G1 X31.202 Y36.713 F152
G1 X31.217 Y36.706 F152
G1 X31.332 Y36.657 F152
G1 X31.336 Y36.656 F152
G1 X31.389 Y36.631 F152
G1 X31.446 Y36.606 F152
G1 X31.464 Y36.598 F152
G1 X31.503 Y36.58 F152
G1 X31.561 Y36.555 F152
G1 X31.593 Y36.541 F152
G1 X31.618 Y36.529 F152
G1 X31.675 Y36.504 F152
G1 X31.721 Y36.484 F152
G1 X31.733 Y36.478 F152
G1 X31.79 Y36.453 F152
G1 X31.847 Y36.427 F152
G1 X31.85 Y36.426 F152
G1 X31.904 Y36.402 F152
G1 X31.962 Y36.376 F152
G1 X31.979 Y36.369 F152
G1 X32.019 Y36.35 F152
G1 X32.076 Y36.325 F152
G1 X32.107 Y36.312 F152
G1 X32.133 Y36.299 F152
G1 X32.191 Y36.274 F152
G1 X32.236 Y36.255 F152
G1 X32.248 Y36.248 F152
G1 X32.305 Y36.223 F152
G1 X32.363 Y36.197 F152
G1 X32.364 F152
G1 X32.42 Y36.174 F152
G1 X32.477 Y36.152 F152
G1 X32.511 Y36.14 F152
G1 X32.534 Y36.131 F152
G1 X32.592 Y36.109 F152
G1 X32.649 Y36.087 F152
G1 X32.662 Y36.083 F152
G1 X32.706 Y36.066 F152
G1 X32.821 Y36.023 F152
G1 X32.878 Y36 F152
G1 X32.935 Y35.979 F152
G1 X32.965 Y35.968 F152
G1 X32.993 Y35.958 F152
G1 X33.107 Y35.922 F152
G1 X33.145 Y35.911 F152
G1 X33.165 Y35.904 F152
G1 X33.279 Y35.869 F152
G1 X33.333 Y35.853 F152
G1 X33.336 Y35.852 F152
G1 X33.451 Y35.823 F152
G1 X33.508 Y35.808 F152
G1 X33.556 Y35.796 F152
G1 X33.565 Y35.793 F152
G1 X33.623 Y35.778 F152
G1 X33.68 Y35.766 F152
G1 X33.737 Y35.755 F152
G1 X33.795 Y35.743 F152
G1 X33.821 Y35.739 F152
G1 X33.852 Y35.733 F152
G1 X33.909 Y35.721 F152
G1 X33.966 Y35.71 F152
G1 X34.024 Y35.7 F152
G1 X34.138 Y35.686 F152
G1 X34.173 Y35.682 F152
G1 X34.196 Y35.678 F152
G1 X34.31 Y35.664 F152
G1 X34.367 Y35.657 F152
G1 X34.425 Y35.653 F152
G1 X34.711 Y35.635 F152
G1 X34.768 F152
G1 X34.826 Y35.634 F152
G1 X35.055 F152
G1 X35.513 Y35.663 F152
G1 X35.57 Y35.668 F152
G1 X35.628 Y35.675 F152
G1 X35.672 Y35.682 F152
G1 X35.685 F152
G1 X35.742 Y35.691 F152
G1 X35.971 Y35.719 F152
G1 X36.028 Y35.727 F152
G1 X36.086 Y35.736 F152
G1 X36.097 Y35.739 F152
G1 X36.143 Y35.746 F152
G1 X36.315 Y35.776 F152
G1 X36.372 Y35.785 F152
G1 X36.429 Y35.795 F152
G1 X36.434 Y35.796 F152
G1 X36.544 Y35.817 F152
G1 X36.601 Y35.828 F152
G1 X36.659 Y35.839 F152
G1 X36.716 Y35.851 F152
G1 X36.83 Y35.872 F152
G1 X36.888 Y35.884 F152
G1 X36.945 Y35.895 F152
G1 X37.002 Y35.906 F152
G1 X37.024 Y35.911 F152
G1 X37.059 Y35.918 F152
G1 X37.117 Y35.929 F152
G1 X37.231 Y35.952 F152
G1 X37.289 Y35.963 F152
G1 X37.313 Y35.968 F152
G1 X37.346 Y35.974 F152
G1 X37.403 Y35.986 F152
G1 X37.46 Y35.996 F152
G1 X37.575 Y36.017 F152
G1 X37.619 Y36.025 F152
G1 X37.632 Y36.027 F152
G1 X37.69 Y36.038 F152
G1 X37.747 Y36.048 F152
G1 X37.976 Y36.08 F152
G1 X37.989 Y36.083 F152
G1 X38.033 Y36.089 F152
G1 X38.262 Y36.121 F152
G1 X38.434 Y36.137 F152
G1 X38.454 Y36.14 F152
G1 X38.491 Y36.144 F152
G1 X38.778 Y36.161 F152
G1 X38.835 Y36.164 F152
G1 X38.892 Y36.166 F152
G1 X39.064 Y36.169 F152
G1 X39.122 F152
G1 X39.179 Y36.167 F152
G1 X39.236 Y36.166 F152
G1 X39.293 Y36.164 F152
G1 X39.351 Y36.163 F152
G1 X39.408 Y36.161 F152
G1 X39.465 Y36.157 F152
G1 X39.522 Y36.154 F152
G1 X39.637 Y36.147 F152
G1 X39.694 Y36.143 F152
G1 X39.731 Y36.14 F152
G1 X39.752 Y36.137 F152
G1 X40.095 Y36.1 F152
G1 X40.216 Y36.083 F152
G1 X40.267 Y36.075 F152
G1 X40.324 Y36.067 F152
G1 X40.554 Y36.027 F152
G1 X40.567 Y36.025 F152
G1 X40.84 Y35.97 F152
G1 X40.851 Y35.968 F152
G1 X40.897 Y35.958 F152
G1 X40.954 Y35.947 F152
G1 X41.069 Y35.92 F152
G1 X41.108 Y35.911 F152
G1 X41.126 Y35.906 F152
G1 X41.241 Y35.879 F152
G1 X41.298 Y35.865 F152
G1 X41.348 Y35.853 F152
G1 X41.355 Y35.852 F152
G1 X41.413 Y35.836 F152
G1 X41.47 Y35.822 F152
G1 X41.527 Y35.807 F152
G1 X41.57 Y35.796 F152
G1 X41.585 Y35.792 F152
G1 X41.642 Y35.776 F152
G1 X41.699 Y35.76 F152
G1 X41.756 Y35.745 F152
G1 X41.78 Y35.739 F152
G1 X41.814 Y35.729 F152
G1 X41.871 Y35.713 F152
G1 X41.928 Y35.698 F152
G1 X41.985 Y35.682 F152
G1 X41.986 F152
G1 X42.043 Y35.665 F152
G1 X42.1 Y35.649 F152
G1 X42.157 Y35.632 F152
G1 X42.188 Y35.624 F152
G1 X42.215 Y35.616 F152
G1 X42.272 Y35.599 F152
G1 X42.329 Y35.583 F152
G1 X42.386 Y35.567 F152
G1 Y35.566 F152
G1 X42.444 Y35.55 F152
G1 X42.501 Y35.533 F152
G1 X42.558 Y35.517 F152
G1 X42.616 Y35.5 F152
G1 X42.673 Y35.484 F152
G1 X42.73 Y35.467 F152
G1 X42.782 Y35.452 F152
G1 X42.787 Y35.451 F152
G1 X42.845 Y35.434 F152
G1 X42.982 Y35.395 F152
G1 X43.017 Y35.384 F152
G1 X43.074 Y35.368 F152
G1 X43.131 Y35.353 F152
G1 X43.187 Y35.338 F152
G1 X43.188 Y35.337 F152
G1 X43.246 Y35.322 F152
G1 X43.36 Y35.289 F152
G1 X43.395 Y35.28 F152
G1 X43.475 Y35.258 F152
G1 X43.532 Y35.244 F152
G1 X43.589 Y35.229 F152
G1 X43.613 Y35.223 F152
G1 X43.647 Y35.214 F152
G1 X43.704 Y35.2 F152
G1 X43.761 Y35.185 F152
G1 X43.836 Y35.166 F152
G1 X43.876 Y35.155 F152
G1 X43.99 Y35.128 F152
G1 X44.048 Y35.116 F152
G1 X44.081 Y35.109 F152
G1 X44.105 Y35.103 F152
G1 X44.162 Y35.09 F152
G1 X44.219 Y35.077 F152
G1 X44.277 Y35.064 F152
G1 X44.334 Y35.051 F152
G1 X44.336 F152
G1 X44.391 Y35.039 F152
G1 X44.448 Y35.025 F152
G1 X44.506 Y35.013 F152
G1 X44.563 Y35.001 F152
G1 X44.601 Y34.994 F152
G1 X44.62 Y34.99 F152
G1 X44.678 Y34.979 F152
G1 X44.735 Y34.967 F152
G1 X44.849 Y34.946 F152
G1 X44.907 Y34.937 F152
G1 X44.909 F152
G1 X44.964 Y34.927 F152
G1 X45.079 Y34.909 F152
G1 X45.136 Y34.899 F152
G1 X45.193 Y34.89 F152
G1 X45.25 Y34.88 F152
G1 X45.258 Y34.879 F152
G1 X45.308 Y34.871 F152
G1 X45.365 Y34.861 F152
G1 X45.422 Y34.853 F152
G1 X45.48 Y34.843 F152
G1 X45.594 Y34.827 F152
G1 X45.63 Y34.822 F152
G1 X45.651 Y34.819 F152
G1 X45.709 Y34.811 F152
G1 X45.766 Y34.803 F152
G1 X45.823 Y34.797 F152
G1 X45.88 Y34.792 F152
G1 X46.11 Y34.767 F152
G1 X46.135 Y34.765 F152
G1 X46.339 Y34.742 F152
G1 X46.396 Y34.737 F152
G1 X46.453 Y34.731 F152
G1 X46.74 Y34.708 F152
G1 X46.76 F152
G1 X46.797 Y34.705 F152
G1 X47.427 Y34.675 F152
G1 X47.484 Y34.673 F152
G1 X47.828 Y34.668 F152
G1 X47.885 F152
G1 X47.943 Y34.669 F152
G1 X48.057 F152
G1 X48.114 Y34.67 F152
G1 X48.172 F152
G1 X48.229 Y34.671 F152
G1 X48.343 Y34.674 F152
G1 X48.401 Y34.675 F152
G1 X48.573 Y34.681 F152
G1 X48.802 Y34.691 F152
G1 X48.859 Y34.695 F152
G1 X48.916 Y34.698 F152
G1 X48.974 Y34.701 F152
G1 X49.031 Y34.706 F152
G1 X49.046 Y34.708 F152
G1 X49.088 Y34.71 F152
G1 X49.26 Y34.724 F152
G1 X49.317 Y34.727 F152
G1 X49.374 Y34.732 F152
G1 X49.432 Y34.738 F152
G1 X49.489 Y34.743 F152
G1 X49.718 Y34.768 F152
G1 X49.775 Y34.774 F152
G1 X49.833 Y34.78 F152
G1 X49.89 Y34.788 F152
G1 X50.005 Y34.802 F152
G1 X50.062 Y34.81 F152
G1 X50.119 Y34.819 F152
G1 X50.137 Y34.822 F152
G1 X50.176 Y34.827 F152
G1 X50.234 Y34.836 F152
G1 X50.291 Y34.844 F152
G1 X50.406 Y34.864 F152
G1 X50.463 Y34.873 F152
G1 X50.498 Y34.879 F152
G1 X50.52 Y34.883 F152
G1 X50.635 Y34.906 F152
G1 X50.692 Y34.917 F152
G1 X50.749 Y34.929 F152
G1 X50.787 Y34.937 F152
G1 X50.806 Y34.94 F152
G1 X50.921 Y34.964 F152
G1 X50.978 Y34.974 F152
G1 X51.036 Y34.988 F152
G1 X51.062 Y34.994 F152
G1 X51.093 Y35.001 F152
G1 X51.265 Y35.041 F152
G1 X51.301 Y35.051 F152
G1 X51.322 Y35.057 F152
G1 X51.494 Y35.102 F152
G1 X51.516 Y35.109 F152
G1 X51.551 Y35.118 F152
G1 X51.608 Y35.133 F152
G1 X51.666 Y35.15 F152
G1 X51.719 Y35.166 F152
G1 X51.723 Y35.167 F152
G1 X51.895 Y35.218 F152
G1 X51.912 Y35.223 F152
G1 X51.952 Y35.235 F152
G1 X52.067 Y35.272 F152
G1 X52.089 Y35.28 F152
G1 X52.124 Y35.292 F152
G1 X52.238 Y35.33 F152
G1 X52.261 Y35.338 F152
G1 X52.296 Y35.349 F152
G1 X52.41 Y35.387 F152
G1 X52.433 Y35.395 F152
G1 X52.468 Y35.407 F152
G1 X52.582 Y35.448 F152
G1 X52.594 Y35.452 F152
G1 X52.639 Y35.468 F152
G1 X52.697 Y35.489 F152
G1 X52.751 Y35.51 F152
G1 X52.754 Y35.511 F152
G1 X52.868 Y35.552 F152
G1 X52.909 Y35.567 F152
G1 X52.926 Y35.573 F152
G1 X53.04 Y35.616 F152
G1 X53.061 Y35.624 F152
G1 X53.098 Y35.638 F152
G1 X53.212 Y35.681 F152
G1 X53.213 Y35.682 F152
G1 X53.269 Y35.702 F152
G1 X53.327 Y35.725 F152
G1 X53.364 Y35.739 F152
G1 X53.384 Y35.746 F152
G1 X53.441 Y35.768 F152
G1 X53.499 Y35.79 F152
G1 X53.515 Y35.796 F152
G1 X53.556 Y35.811 F152
G1 X53.613 Y35.834 F152
G1 X53.665 Y35.853 F152
G1 X53.67 Y35.855 F152
G1 X53.728 Y35.877 F152
G1 X53.785 Y35.899 F152
G1 X53.816 Y35.911 F152
G1 X53.842 Y35.921 F152
G1 X53.957 Y35.964 F152
G1 X53.968 Y35.968 F152
G1 X54.014 Y35.985 F152
G1 X54.071 Y36.007 F152
G1 X54.122 Y36.025 F152
G1 X54.129 Y36.027 F152
G1 X54.186 Y36.049 F152
G1 X54.243 Y36.069 F152
G1 X54.279 Y36.083 F152
G1 X54.3 Y36.09 F152
G1 X54.358 Y36.111 F152
G1 X54.415 Y36.132 F152
G1 X54.437 Y36.14 F152
G1 X54.472 Y36.152 F152
G1 X54.53 Y36.172 F152
G1 X54.587 Y36.193 F152
G1 X54.599 Y36.197 F152
G1 X54.644 Y36.213 F152
G1 X54.701 Y36.233 F152
G1 X54.759 Y36.254 F152
G1 X54.931 Y36.313 F152
G1 X54.988 Y36.332 F152
G1 X55.045 Y36.351 F152
G1 X55.099 Y36.369 F152
G1 X55.102 Y36.37 F152
G1 X55.16 Y36.389 F152
G1 X55.217 Y36.409 F152
G1 X55.273 Y36.426 F152
G1 X55.274 F152
G1 X55.331 Y36.444 F152
G1 X55.389 Y36.463 F152
G1 X55.446 Y36.481 F152
G1 X55.452 Y36.484 F152
G1 X55.503 Y36.5 F152
G1 X55.561 Y36.518 F152
G1 X55.618 Y36.537 F152
G1 X55.632 Y36.541 F152
G1 X55.675 Y36.554 F152
G1 X55.732 Y36.571 F152
G1 X55.79 Y36.588 F152
G1 X55.822 Y36.598 F152
G1 X55.847 Y36.605 F152
G1 X55.904 Y36.622 F152
G1 X55.962 Y36.64 F152
G1 X56.012 Y36.656 F152
G1 X56.019 Y36.657 F152
G1 X56.133 Y36.691 F152
G1 X56.191 Y36.708 F152
G1 X56.208 Y36.713 F152
G1 X56.248 Y36.724 F152
G1 X56.477 Y36.788 F152
G1 X56.534 Y36.803 F152
G1 X56.592 Y36.819 F152
G1 X56.621 Y36.827 F152
G1 X56.649 Y36.835 F152
G1 X56.706 Y36.85 F152
G1 X56.763 Y36.864 F152
G1 X56.821 Y36.879 F152
G1 X56.84 Y36.885 F152
G1 X56.878 Y36.895 F152
G1 X56.935 Y36.91 F152
G1 X57.064 Y36.942 F152
G1 X57.107 Y36.952 F152
G1 X57.297 Y36.999 F152
G1 X57.336 Y37.008 F152
G1 X57.451 Y37.035 F152
G1 X57.508 Y37.048 F152
G1 X57.544 Y37.057 F152
G1 X57.565 Y37.061 F152
G1 X57.623 Y37.075 F152
G1 X57.803 Y37.114 F152
G1 X57.852 Y37.124 F152
G1 X58.024 Y37.161 F152
G1 X58.081 Y37.173 F152
G1 X58.138 Y37.184 F152
G1 X58.195 Y37.195 F152
G1 X58.253 Y37.206 F152
G1 X58.31 Y37.218 F152
G1 X58.364 Y37.229 F152
G1 X58.367 F152
G1 X58.425 Y37.24 F152
G1 X58.482 Y37.25 F152
G1 X58.539 Y37.261 F152
G1 X58.596 Y37.271 F152
G1 X58.678 Y37.286 F152
G1 X58.711 Y37.291 F152
G1 X58.768 Y37.302 F152
G1 X58.826 Y37.311 F152
G1 X58.883 Y37.321 F152
G1 X58.997 Y37.339 F152
G1 X59.021 Y37.343 F152
G1 X59.169 Y37.366 F152
G1 X59.398 Y37.399 F152
G1 X59.407 Y37.4 F152
G1 X59.456 Y37.407 F152
G1 X59.57 Y37.423 F152
G1 X59.627 Y37.43 F152
G1 X59.685 Y37.436 F152
G1 X59.799 Y37.451 F152
G1 X59.855 Y37.458 F152
G1 X59.857 F152
G1 X59.914 Y37.465 F152
G1 X59.971 Y37.47 F152
G1 X60.028 Y37.477 F152
G1 X60.086 Y37.482 F152
G1 X60.143 Y37.488 F152
G1 X60.2 Y37.494 F152
G1 X60.257 Y37.5 F152
G1 X60.315 Y37.504 F152
G1 X60.372 Y37.51 F152
G1 X60.429 Y37.514 F152
G1 X60.436 Y37.515 F152
G1 X60.487 Y37.519 F152
G1 X60.544 Y37.523 F152
G1 X60.601 Y37.528 F152
G1 X60.83 Y37.543 F152
G1 X60.888 Y37.545 F152
G1 X60.945 Y37.549 F152
G1 X61.059 Y37.554 F152
G1 X61.117 Y37.556 F152
G1 X61.174 Y37.559 F152
G1 X61.231 Y37.561 F152
G1 X61.289 Y37.562 F152
G1 X61.346 Y37.563 F152
G1 X61.403 F152
G1 X61.46 F152
G1 X61.689 F152
G1 X61.747 Y37.562 F152
G1 X61.919 F152
G1 X61.976 Y37.559 F152
G1 X62.033 Y37.555 F152
G1 X62.148 Y37.55 F152
G1 X62.205 Y37.546 F152
G1 X62.32 Y37.537 F152
G1 X62.377 Y37.532 F152
G1 X62.434 Y37.528 F152
G1 X62.491 Y37.52 F152
G1 X62.537 Y37.515 F152
G1 X62.549 Y37.513 F152
G1 X62.663 Y37.499 F152
G1 X62.72 Y37.49 F152
G1 X62.778 Y37.479 F152
G1 X62.903 Y37.458 F152
G1 X62.95 Y37.447 F152
G1 X63.064 Y37.42 F152
G1 X63.121 Y37.406 F152
G1 X63.14 Y37.4 F152
G1 X63.179 Y37.389 F152
G1 X63.236 Y37.371 F152
G1 X63.293 Y37.352 F152
G1 X63.318 Y37.343 F152
G1 X63.408 Y37.308 F152
G1 X63.457 Y37.286 F152
G1 X63.465 Y37.281 F152
G1 X63.522 Y37.253 F152
G1 X63.564 Y37.229 F152
G1 X63.58 Y37.22 F152
G1 X63.637 Y37.181 F152
G1 X63.65 Y37.171 F152
G1 X63.694 Y37.135 F152
G1 X63.718 Y37.114 F152
G1 X63.752 Y37.078 F152
G1 X63.77 Y37.057 F152
G1 X63.809 Y37.006 F152
G1 X63.812 Y36.999 F152
G1 X63.847 Y36.942 F152
G1 X63.866 Y36.906 F152
G1 X63.877 Y36.885 F152
G1 X63.923 Y36.794 F152
G1 X63.936 Y36.77 F152
G1 X63.962 Y36.713 F152
G1 X63.981 Y36.672 F152
G1 X63.988 Y36.656 F152
G1 X64.014 Y36.598 F152
G1 X64.038 Y36.544 F152
G1 X64.039 Y36.541 F152
G1 X64.095 Y36.417 F152
G1 X64.116 Y36.369 F152
G1 X64.142 Y36.312 F152
G1 X64.152 Y36.289 F152
G1 X64.168 Y36.255 F152
G1 X64.195 Y36.197 F152
G1 X64.21 Y36.17 F152
G1 X64.228 Y36.14 F152
G1 X64.296 Y36.025 F152
G1 X64.324 Y35.978 F152
G1 X64.33 Y35.968 F152
G1 X64.364 Y35.911 F152
G1 X64.382 Y35.882 F152
G1 X64.401 Y35.853 F152
G1 X64.439 Y35.802 F152
G1 X64.443 Y35.796 F152
G1 X64.488 Y35.739 F152
G1 X64.496 Y35.729 F152
G1 X64.533 Y35.682 F152
G1 X64.553 Y35.657 F152
G1 X64.584 Y35.624 F152
G1 X64.611 Y35.596 F152
G1 X64.694 Y35.51 F152
G1 X64.725 Y35.479 F152
G1 X64.755 Y35.452 F152
G1 X64.783 Y35.428 F152
G1 X64.823 Y35.395 F152
G1 X64.84 Y35.381 F152
G1 X64.897 Y35.333 F152
G1 X64.954 Y35.291 F152
G1 X64.97 Y35.28 F152
G1 X65.056 Y35.223 F152
G1 X65.069 Y35.214 F152
G1 X65.126 Y35.178 F152
G1 X65.146 Y35.166 F152
G1 X65.183 Y35.144 F152
G1 X65.241 Y35.115 F152
G1 X65.252 Y35.109 F152
G1 X65.298 Y35.084 F152
G1 X65.355 Y35.055 F152
G1 X65.363 Y35.051 F152
G1 X65.413 Y35.029 F152
G1 X65.47 Y35.006 F152
G1 X65.5 Y34.994 F152
G1 X65.527 Y34.982 F152
G1 X65.584 Y34.96 F152
G1 X65.642 Y34.938 F152
G1 X65.699 Y34.92 F152
G1 X65.756 Y34.903 F152
G1 X65.814 Y34.885 F152
G1 X65.831 Y34.879 F152
G1 X65.871 Y34.868 F152
G1 X65.928 Y34.853 F152
G1 X66.043 Y34.827 F152
G1 X66.064 Y34.822 F152
G1 X66.1 Y34.813 F152
G1 X66.157 Y34.802 F152
G1 X66.215 Y34.792 F152
G1 X66.272 Y34.783 F152
G1 X66.329 Y34.773 F152
G1 X66.38 Y34.765 F152
G1 X66.386 Y34.763 F152
G1 X66.444 Y34.756 F152
G1 X66.673 Y34.731 F152
G1 X66.73 Y34.725 F152
G1 X66.959 Y34.711 F152
G1 X67.016 Y34.708 F152
G1 X67.075 F152
G1 X67.188 Y34.704 F152
G1 X67.303 Y34.702 F152
G1 X67.36 F152
G1 X67.417 Y34.703 F152
G1 X67.532 F152
G1 X67.589 Y34.704 F152
G1 X67.646 Y34.706 F152
G1 X67.684 Y34.708 F152
G1 X67.704 F152
G1 X67.761 Y34.709 F152
G1 X67.818 Y34.712 F152
G1 X67.876 Y34.714 F152
G1 X67.933 Y34.716 F152
G1 X67.99 Y34.72 F152
G1 X68.047 Y34.723 F152
G1 X68.162 Y34.73 F152
G1 X68.219 Y34.733 F152
G1 X68.563 Y34.759 F152
G1 X68.618 Y34.765 F152
G1 X68.62 F152
G1 X68.907 Y34.792 F152
G1 X69.078 Y34.81 F152
G1 X69.136 Y34.816 F152
G1 X69.186 Y34.822 F152
G1 X69.193 F152
G1 X69.25 Y34.828 F152
G1 X69.651 Y34.879 F152
G1 X69.658 F152
G1 X69.709 Y34.886 F152
G1 X69.766 Y34.892 F152
G1 X69.938 Y34.913 F152
G1 X70.109 Y34.938 F152
G1 X70.167 Y34.945 F152
G1 X70.453 Y34.985 F152
G1 X70.51 Y34.992 F152
G1 X70.518 Y34.994 F152
G1 X70.568 Y35 F152
G1 X70.74 Y35.024 F152
G1 X70.797 Y35.033 F152
G1 X70.911 Y35.049 F152
G1 X70.919 Y35.051 F152
G1 X70.969 Y35.058 F152
G1 X71.083 Y35.075 F152
G1 X71.14 Y35.084 F152
G1 X71.255 Y35.1 F152
G1 X71.311 Y35.109 F152
G1 X71.312 F152
G1 X71.427 Y35.125 F152
G1 X71.484 Y35.134 F152
G1 X71.599 Y35.15 F152
G1 X71.656 Y35.159 F152
G1 X71.704 Y35.166 F152
G1 X71.713 Y35.167 F152
G1 X71.771 Y35.175 F152
G1 X71.828 Y35.184 F152
G1 X71.942 Y35.2 F152
G1 X72 Y35.209 F152
G1 X72.057 Y35.217 F152
G1 X72.099 Y35.223 F152
G1 X72.114 Y35.225 F152
G1 X72.458 Y35.273 F152
G1 X72.507 Y35.28 F152
G1 X72.515 Y35.281 F152
G1 X72.687 Y35.306 F152
G1 X72.802 Y35.32 F152
G1 X72.859 Y35.328 F152
G1 X72.916 Y35.335 F152
G1 X72.935 Y35.338 F152
G1 X72.973 Y35.342 F152
G1 X73.088 Y35.357 F152
G1 X73.145 Y35.365 F152
G1 X73.374 Y35.393 F152
G1 X73.387 Y35.395 F152
G1 X73.432 Y35.4 F152
G1 X73.489 Y35.406 F152
G1 X73.546 Y35.413 F152
G1 X73.718 Y35.432 F152
G1 X73.775 Y35.437 F152
G1 X73.833 Y35.443 F152
G1 X73.89 Y35.449 F152
G1 X73.924 Y35.452 F152
G1 X73.947 Y35.454 F152
G1 X74.062 Y35.465 F152
G1 X74.234 Y35.478 F152
G1 X74.291 Y35.484 F152
G1 X74.348 Y35.488 F152
G1 X74.405 Y35.492 F152
G1 X74.463 Y35.494 F152
G1 X74.577 Y35.502 F152
G1 X74.692 Y35.507 F152
G1 X74.749 Y35.509 F152
G1 X74.761 Y35.51 F152
G1 X74.806 Y35.511 F152
G1 X74.921 Y35.514 F152
G1 X74.978 Y35.515 F152
G1 X75.093 F152
G1 X75.15 Y35.514 F152
G1 X75.207 F152
G1 X75.265 Y35.512 F152
G1 X75.322 Y35.51 F152
G1 X75.342 F152
G1 X75.436 Y35.505 F152
G1 X75.608 Y35.492 F152
G1 X75.666 Y35.485 F152
G1 X75.723 Y35.478 F152
G1 X75.78 Y35.471 F152
G1 X75.837 Y35.461 F152
G1 X75.895 Y35.452 F152
G1 X75.897 F152
G1 X75.952 Y35.442 F152
G1 X76.009 Y35.43 F152
G1 X76.066 Y35.417 F152
G1 X76.124 Y35.403 F152
G1 X76.16 Y35.395 F152
G1 X76.181 Y35.389 F152
G1 X76.238 Y35.374 F152
G1 X76.296 Y35.357 F152
G1 X76.353 Y35.342 F152
G1 X76.369 Y35.338 F152
G1 X76.467 Y35.31 F152
G1 X76.525 Y35.297 F152
G1 X76.582 Y35.282 F152
G1 X76.592 Y35.28 F152
G1 X76.639 Y35.269 F152
G1 X76.697 Y35.255 F152
G1 X76.754 Y35.241 F152
G1 X76.811 Y35.229 F152
G1 X76.841 Y35.223 F152
G1 X76.868 Y35.219 F152
G1 X76.926 Y35.21 F152
G1 X76.983 Y35.2 F152
G1 X77.04 Y35.192 F152
G1 X77.098 Y35.186 F152
G1 X77.155 Y35.182 F152
G1 X77.212 Y35.177 F152
G1 X77.269 Y35.173 F152
G1 X77.498 Y35.169 F152
G1 X77.728 Y35.18 F152
G1 X77.785 Y35.186 F152
G1 X77.842 Y35.192 F152
G1 X77.899 Y35.197 F152
G1 X77.957 Y35.203 F152
G1 X78.014 Y35.211 F152
G1 X78.071 Y35.219 F152
G1 X78.096 Y35.223 F152
G1 X78.186 Y35.236 F152
G1 X78.243 Y35.245 F152
G1 X78.3 Y35.255 F152
G1 X78.358 Y35.265 F152
G1 X78.415 Y35.276 F152
G1 X78.44 Y35.28 F152
G1 X78.472 Y35.286 F152
G1 X78.529 Y35.297 F152
G1 X78.587 Y35.308 F152
G1 X78.701 Y35.332 F152
G1 X78.73 Y35.338 F152
G1 X78.759 Y35.343 F152
G1 X78.873 Y35.368 F152
G1 X78.93 Y35.38 F152
G1 X78.988 Y35.392 F152
G1 X78.998 Y35.395 F152
G1 X79.045 Y35.405 F152
G1 X79.217 Y35.443 F152
G1 X79.258 Y35.452 F152
G1 X79.446 Y35.494 F152
G1 X79.503 Y35.506 F152
G1 X79.518 Y35.51 F152
G1 X79.561 Y35.519 F152
G1 X79.675 Y35.544 F152
G1 X79.732 Y35.555 F152
G1 X79.783 Y35.567 F152
G1 X79.79 Y35.568 F152
G1 X79.847 Y35.58 F152
G1 X80.019 Y35.615 F152
G1 X80.061 Y35.624 F152
G1 X80.076 Y35.627 F152
G1 X80.191 Y35.65 F152
G1 X80.305 Y35.672 F152
G1 X80.357 Y35.682 F152
G1 X80.42 Y35.692 F152
G1 X80.534 Y35.714 F152
G1 X80.592 Y35.724 F152
G1 X80.649 Y35.733 F152
G1 X80.686 Y35.739 F152
G1 X80.706 Y35.742 F152
G1 X80.763 Y35.751 F152
G1 X80.878 Y35.769 F152
G1 X81.05 Y35.793 F152
G1 X81.068 Y35.796 F152
G1 X81.107 Y35.802 F152
G1 X81.164 Y35.809 F152
G1 X81.222 Y35.817 F152
G1 X81.508 Y35.848 F152
G1 X81.551 Y35.853 F152
G1 X81.565 Y35.854 F152
G1 X81.68 Y35.863 F152
G1 X81.737 Y35.869 F152
G1 X81.909 Y35.882 F152
G1 X82.024 Y35.887 F152
G1 X82.081 Y35.891 F152
G1 X82.253 Y35.899 F152
G1 X82.31 Y35.901 F152
G1 X82.424 Y35.903 F152
G1 X82.482 Y35.904 F152
G1 X82.596 Y35.906 F152
G1 X82.711 F152
G1 X82.883 Y35.904 F152
G1 X82.94 F152
G1 X82.997 Y35.902 F152
G1 X83.055 Y35.899 F152
G1 X83.112 Y35.897 F152
G1 X83.226 Y35.892 F152
G1 X83.284 Y35.89 F152
G1 X83.398 Y35.883 F152
G1 X83.455 Y35.879 F152
G1 X83.513 Y35.875 F152
G1 X83.57 Y35.87 F152
G1 X83.627 Y35.867 F152
G1 X83.685 Y35.862 F152
G1 X83.742 Y35.856 F152
G1 X83.777 Y35.853 F152
G1 X83.799 Y35.851 F152
G1 X83.914 Y35.84 F152
G1 X83.971 Y35.834 F152
G1 X84.028 Y35.828 F152
G1 X84.257 Y35.8 F152
G1 X84.29 Y35.796 F152
G1 X84.315 Y35.793 F152
G1 X84.372 Y35.785 F152
G1 X84.429 Y35.777 F152
G1 X84.487 Y35.768 F152
G1 X84.601 Y35.752 F152
G1 X84.658 Y35.743 F152
G1 X84.693 Y35.739 F152
G1 X84.716 Y35.735 F152
G1 X84.945 Y35.696 F152
G1 X85.002 Y35.685 F152
G1 X85.027 Y35.682 F152
G1 X85.059 Y35.675 F152
G1 X85.346 Y35.626 F152
G1 X85.357 Y35.624 F152
G1 X85.403 Y35.616 F152
G1 X85.518 Y35.593 F152
G1 X85.575 Y35.582 F152
G1 X85.632 Y35.571 F152
G1 X85.654 Y35.567 F152
G1 X85.689 Y35.56 F152
G1 X85.747 Y35.548 F152
G1 X85.804 Y35.537 F152
G1 X85.861 Y35.526 F152
G1 X85.918 Y35.515 F152
G1 X85.945 Y35.51 F152
G1 X85.976 Y35.503 F152
G1 X86.033 Y35.492 F152
G1 X86.09 Y35.481 F152
G1 X86.205 Y35.458 F152
G1 X86.234 Y35.452 F152
G1 X86.262 Y35.446 F152
G1 X86.319 Y35.435 F152
G1 X86.491 Y35.4 F152
G1 X86.522 Y35.395 F152
G1 X86.549 Y35.39 F152
G1 X86.72 Y35.355 F152
G1 X86.778 Y35.345 F152
G1 X86.818 Y35.338 F152
G1 X86.835 Y35.334 F152
G1 X86.892 Y35.324 F152
G1 X87.007 Y35.303 F152
G1 X87.064 Y35.293 F152
G1 X87.121 Y35.282 F152
G1 X87.134 Y35.28 F152
G1 X87.179 Y35.272 F152
G1 X87.236 Y35.262 F152
G1 X87.293 Y35.251 F152
G1 X87.35 Y35.241 F152
G1 X87.465 Y35.223 F152
G1 X87.469 F152
G1 X87.522 Y35.215 F152
G1 X87.637 Y35.197 F152
G1 X87.694 Y35.189 F152
G1 X87.866 Y35.168 F152
G1 X87.881 Y35.166 F152
G1 X87.923 Y35.161 F152
G1 X87.981 Y35.153 F152
G1 X88.038 Y35.148 F152
G1 X88.095 Y35.142 F152
G1 X88.267 Y35.126 F152
G1 X88.496 Y35.111 F152
G1 X88.547 Y35.109 F152
G1 X88.553 Y35.108 F152
G1 X88.668 Y35.104 F152
G1 X88.725 Y35.103 F152
G1 X88.782 Y35.101 F152
G1 X88.84 F152
G1 X88.897 F152
G1 X89.126 Y35.104 F152
G1 X89.183 Y35.106 F152
G1 X89.218 Y35.109 F152
G1 X89.241 F152
G1 X89.355 Y35.117 F152
G1 X89.412 Y35.119 F152
G1 X89.47 Y35.124 F152
G1 X89.527 Y35.129 F152
G1 X89.584 Y35.135 F152
G1 X89.699 Y35.146 F152
G1 X89.756 Y35.153 F152
G1 X89.837 Y35.166 F152
G1 X89.871 Y35.171 F152
G1 X89.928 Y35.179 F152
G1 X90.157 Y35.215 F152
G1 X90.206 Y35.223 F152
G1 X90.214 Y35.224 F152
G1 X90.272 Y35.233 F152
G1 X90.329 Y35.245 F152
G1 X90.444 Y35.27 F152
G1 X90.494 Y35.28 F152
G1 X90.501 Y35.281 F152
G1 X90.673 Y35.319 F152
G1 X90.73 Y35.331 F152
G1 X90.759 Y35.338 F152
G1 X90.787 Y35.343 F152
G1 X90.959 Y35.386 F152
G1 X90.992 Y35.395 F152
G1 X91.016 Y35.401 F152
G1 X91.188 Y35.444 F152
G1 X91.219 Y35.452 F152
G1 X91.245 Y35.459 F152
G1 X91.303 Y35.473 F152
G1 X91.417 Y35.503 F152
G1 X91.439 Y35.51 F152
G1 X91.475 Y35.519 F152
G1 X91.646 Y35.564 F152
G1 X91.654 Y35.567 F152
G1 X91.704 Y35.579 F152
G1 X91.818 Y35.61 F152
G1 X91.871 Y35.624 F152
G1 X91.875 Y35.625 F152
G1 X91.99 Y35.656 F152
G1 X92.047 Y35.67 F152
G1 X92.105 Y35.685 F152
G1 X92.219 Y35.714 F152
G1 X92.276 Y35.729 F152
G1 X92.317 Y35.739 F152
G1 X92.334 Y35.742 F152
G1 X92.391 Y35.756 F152
G1 X92.448 Y35.77 F152
G1 X92.506 Y35.784 F152
G1 X92.557 Y35.796 F152
G1 X92.563 Y35.797 F152
G1 X92.62 Y35.81 F152
G1 X92.677 Y35.825 F152
G1 X92.792 Y35.852 F152
G1 X92.797 Y35.853 F152
G1 X92.849 Y35.865 F152
G1 X93.058 Y35.911 F152
G1 X93.078 Y35.914 F152
G1 X93.25 Y35.952 F152
G1 X93.307 Y35.964 F152
G1 X93.325 Y35.968 F152
G1 X93.422 Y35.988 F152
G1 X93.537 Y36.009 F152
G1 X93.594 Y36.021 F152
G1 X93.617 Y36.025 F152
G1 X93.651 Y36.032 F152
G1 X93.88 Y36.075 F152
G1 X93.919 Y36.083 F152
G1 X94.052 Y36.108 F152
G1 X94.109 Y36.117 F152
G1 X94.245 Y36.14 F152
G1 X94.281 Y36.145 F152
G1 X94.396 Y36.165 F152
G1 X94.453 Y36.174 F152
G1 X94.588 Y36.197 F152
G1 X94.625 Y36.203 F152
G1 X94.682 Y36.212 F152
G1 X94.739 Y36.221 F152
G1 X94.797 Y36.229 F152
G1 X94.911 Y36.246 F152
G1 X94.967 Y36.255 F152
G1 X94.969 F152
G1 X95.026 Y36.263 F152
G1 X95.083 Y36.272 F152
G1 X95.198 Y36.288 F152
G1 X95.255 Y36.297 F152
G1 X95.312 Y36.305 F152
G1 X95.357 Y36.312 F152
G1 X95.427 Y36.322 F152
G1 X95.484 Y36.329 F152
G1 X95.541 Y36.337 F152
G1 X95.599 Y36.344 F152
G1 X95.656 Y36.352 F152
G1 X95.713 Y36.359 F152
G1 X95.77 Y36.367 F152
G1 X95.782 Y36.369 F152
G1 X95.828 Y36.374 F152
G1 X95.885 Y36.383 F152
G1 X95.942 Y36.39 F152
G1 X96 Y36.398 F152
G1 X96.057 Y36.405 F152
G1 X96.114 Y36.413 F152
G1 X96.171 Y36.42 F152
G1 X96.216 Y36.426 F152
G1 X96.229 Y36.427 F152
G1 X96.286 Y36.434 F152
G1 X96.343 Y36.443 F152
G1 X96.63 Y36.478 F152
G1 X96.665 Y36.484 F152
G1 X96.973 Y36.522 F152
G1 X97.031 Y36.53 F152
G1 X97.088 Y36.537 F152
G1 X97.109 Y36.541 F152
G1 X97.202 Y36.553 F152
G1 X97.26 Y36.561 F152
G1 X97.317 Y36.568 F152
G1 X97.374 Y36.576 F152
G1 X97.432 Y36.583 F152
G1 X97.489 Y36.591 F152
G1 X97.541 Y36.598 F152
G1 X97.546 F152
G1 X97.603 Y36.606 F152
G1 X97.661 Y36.614 F152
G1 X97.718 Y36.622 F152
G1 X97.775 Y36.629 F152
G1 X97.89 Y36.645 F152
G1 X97.947 Y36.654 F152
G1 X97.957 Y36.656 F152
G1 X98.004 Y36.663 F152
G1 X98.062 Y36.671 F152
G1 X98.119 Y36.68 F152
G1 X98.176 Y36.688 F152
G1 X98.233 Y36.697 F152
G1 X98.291 Y36.705 F152
G1 X98.342 Y36.713 F152
G1 X98.405 Y36.722 F152
G1 X98.463 Y36.731 F152
G1 X98.52 Y36.739 F152
G1 X98.577 Y36.748 F152
G1 X98.634 Y36.756 F152
G1 X98.692 Y36.765 F152
G1 X98.725 Y36.77 F152
G1 X98.749 Y36.774 F152
G1 X98.806 Y36.784 F152
G1 X98.864 Y36.794 F152
G1 X99.035 Y36.824 F152
G1 X99.054 Y36.827 F152
G1 X99.093 Y36.834 F152
G1 X99.264 Y36.863 F152
G1 X99.322 Y36.874 F152
G1 X99.379 Y36.884 F152
G1 X99.384 Y36.885 F152
G1 X99.436 Y36.894 F152
G1 X99.608 Y36.923 F152
G1 X99.665 Y36.935 F152
G1 X99.699 Y36.942 F152
G1 X99.723 Y36.947 F152
G1 X99.78 Y36.959 F152
G1 X99.837 Y36.971 F152
G1 X99.895 Y36.983 F152
G1 X99.952 Y36.995 F152
G1 X99.972 Y36.999 F152
G1 X100.009 Y37.007 F152
G1 X100.066 Y37.019 F152
G1 X100.124 Y37.031 F152
G1 X100.181 Y37.043 F152
G1 X100.238 Y37.055 F152
G1 X100.244 Y37.057 F152
G1 X100.296 Y37.067 F152
G1 X100.353 Y37.079 F152
G1 X100.41 Y37.092 F152
G1 X100.467 Y37.103 F152
G1 X100.516 Y37.114 F152
G1 X100.525 Y37.116 F152
G1 X100.582 Y37.13 F152
G1 X100.639 Y37.144 F152
G1 X100.696 Y37.158 F152
G1 X100.749 Y37.171 F152
G1 X100.754 Y37.172 F152
G1 X100.811 Y37.186 F152
G1 X100.868 Y37.2 F152
G1 X100.926 Y37.214 F152
G1 X100.979 Y37.229 F152
G1 X100.983 F152
G1 X101.04 Y37.245 F152
G1 X101.155 Y37.277 F152
G1 X101.187 Y37.286 F152
G1 X101.212 Y37.293 F152
G1 X101.269 Y37.308 F152
G1 X101.384 Y37.34 F152
G1 X101.394 Y37.343 F152
G1 X101.441 Y37.357 F152
G1 X101.556 Y37.393 F152
G1 X101.578 Y37.4 F152
G1 X101.613 Y37.411 F152
G1 X101.727 Y37.447 F152
G1 X101.761 Y37.458 F152
G1 X101.785 Y37.465 F152
G1 X101.899 Y37.504 F152
G1 X101.929 Y37.515 F152
G1 X101.957 Y37.525 F152
G1 X102.014 Y37.545 F152
G1 X102.071 Y37.565 F152
G1 X102.091 Y37.572 F152
G1 X102.128 Y37.586 F152
G1 X102.186 Y37.605 F152
G1 X102.247 Y37.63 F152
G1 X102.3 Y37.651 F152
G1 X102.358 Y37.674 F152
G1 X102.39 Y37.687 F152
G1 X102.415 Y37.697 F152
G1 X102.529 Y37.743 F152
G1 X102.531 Y37.744 F152
G1 X102.587 Y37.767 F152
G1 X102.644 Y37.792 F152
G1 X102.664 Y37.802 F152
G1 X102.701 Y37.819 F152
G1 X102.816 Y37.872 F152
G1 X102.873 Y37.898 F152
G1 X102.91 Y37.916 F152
G1 X102.93 Y37.925 F152
G1 X102.988 Y37.952 F152
G1 X103.029 Y37.973 F152
G1 X103.045 Y37.982 F152
G1 X103.102 Y38.013 F152
G1 X103.134 Y38.031 F152
G1 X103.159 Y38.044 F152
G1 X103.217 Y38.075 F152
G1 X103.241 Y38.088 F152
G1 X103.274 Y38.106 F152
G1 X103.331 Y38.137 F152
G1 X103.346 Y38.145 F152
G1 X103.389 Y38.171 F152
G1 X103.437 Y38.203 F152
G1 X103.446 Y38.208 F152
G1 X103.503 Y38.244 F152
G1 X103.56 Y38.281 F152
G1 X103.618 Y38.316 F152
G1 X103.619 Y38.317 F152
G1 X103.675 Y38.353 F152
G1 X103.705 Y38.375 F152
G1 X103.732 Y38.394 F152
G1 X103.781 Y38.432 F152
G1 X103.79 Y38.437 F152
G1 X103.847 Y38.481 F152
G1 X103.904 Y38.524 F152
G1 X103.935 Y38.546 F152
G1 X103.961 Y38.567 F152
G1 X104.008 Y38.604 F152
G1 X104.019 Y38.613 F152
G1 X104.075 Y38.661 F152
G1 X104.076 Y38.662 F152
G1 X104.133 Y38.711 F152
G1 X104.141 Y38.718 F152
G1 X104.19 Y38.765 F152
G1 X104.202 Y38.776 F152
G1 X104.248 Y38.819 F152
G1 X104.262 Y38.833 F152
G1 X104.305 Y38.876 F152
G1 X104.318 Y38.89 F152
G1 X104.362 Y38.938 F152
G1 X104.372 Y38.947 F152
G1 X104.42 Y38.999 F152
G1 X104.425 Y39.005 F152
G1 X104.473 Y39.062 F152
G1 X104.477 Y39.067 F152
G1 X104.534 Y39.135 F152
G1 X104.566 Y39.177 F152
G1 X104.591 Y39.212 F152
G1 X104.608 Y39.234 F152
G1 X104.649 Y39.29 F152
G1 X104.65 Y39.291 F152
G1 X104.688 Y39.349 F152
G1 X104.706 Y39.377 F152
G1 X104.725 Y39.406 F152
G1 X104.761 Y39.463 F152
G1 X104.763 Y39.469 F152
G1 X104.793 Y39.52 F152
G1 X104.821 Y39.577 F152
G1 Y39.578 F152
G1 X104.85 Y39.635 F152
G1 X104.878 Y39.692 F152
G1 X104.906 Y39.75 F152
G1 X104.932 Y39.807 F152
G1 X104.935 Y39.815 F152
G1 X104.954 Y39.864 F152
G1 X104.991 Y39.979 F152
G1 X104.992 Y39.983 F152
G1 X105.01 Y40.036 F152
G1 X105.028 Y40.093 F152
G1 X105.044 Y40.151 F152
G1 X105.05 Y40.178 F152
G1 X105.056 Y40.208 F152
G1 X105.066 Y40.265 F152
G1 X105.075 Y40.323 F152
G1 X105.085 Y40.38 F152
G1 X105.094 Y40.437 F152
G1 X105.101 Y40.494 F152
G1 X105.104 Y40.552 F152
G1 X105.105 Y40.609 F152
G1 Y40.724 F152
G1 X105.103 Y40.838 F152
G1 X105.099 Y40.896 F152
G1 X105.091 Y40.953 F152
G1 X105.061 Y41.125 F152
G1 X105.051 Y41.182 F152
G1 X105.05 Y41.185 F152
G1 X105.037 Y41.239 F152
G1 X105.021 Y41.297 F152
G1 X104.98 Y41.411 F152
G1 X104.958 Y41.469 F152
G1 X104.938 Y41.526 F152
G1 X104.935 Y41.532 F152
G1 X104.915 Y41.583 F152
G1 X104.887 Y41.64 F152
G1 X104.878 Y41.657 F152
G1 X104.821 Y41.755 F152
G1 Y41.756 F152
G1 X104.788 Y41.812 F152
G1 X104.763 Y41.854 F152
G1 X104.754 Y41.87 F152
G1 X104.717 Y41.927 F152
G1 X104.706 Y41.942 F152
G1 X104.674 Y41.984 F152
G1 X104.649 Y42.015 F152
G1 X104.626 Y42.042 F152
G1 X104.591 Y42.083 F152
G1 X104.578 Y42.099 F152
G1 X104.534 Y42.15 F152
G1 X104.53 Y42.156 F152
G1 X104.476 Y42.213 F152
G1 X104.42 Y42.266 F152
G1 X104.414 Y42.271 F152
G1 X104.362 Y42.315 F152
G1 X104.347 Y42.328 F152
G1 X104.305 Y42.364 F152
G1 X104.28 Y42.385 F152
G1 X104.248 Y42.412 F152
G1 X104.208 Y42.443 F152
G1 X104.19 Y42.456 F152
G1 X104.133 Y42.494 F152
G1 X104.122 Y42.5 F152
G1 X104.076 Y42.529 F152
G1 X104.028 Y42.557 F152
G1 X104.019 Y42.563 F152
G1 X103.961 Y42.598 F152
G1 X103.934 Y42.614 F152
G1 X103.904 Y42.631 F152
G1 X103.847 Y42.658 F152
G1 X103.815 Y42.672 F152
G1 X103.79 Y42.683 F152
G1 X103.732 Y42.707 F152
G1 X103.678 Y42.729 F152
G1 X103.675 Y42.731 F152
G1 X103.618 Y42.754 F152
G1 X103.56 Y42.777 F152
G1 X103.529 Y42.786 F152
G1 X103.503 Y42.794 F152
G1 X103.446 Y42.81 F152
G1 X103.389 Y42.824 F152
G1 X103.331 Y42.839 F152
G1 X103.312 Y42.844 F152
G1 X103.274 Y42.854 F152
G1 X103.217 Y42.867 F152
G1 X103.159 Y42.878 F152
G1 X102.988 Y42.899 F152
G1 X102.972 Y42.901 F152
G1 X102.93 Y42.906 F152
G1 X102.873 Y42.914 F152
G1 X102.816 Y42.916 F152
G1 X102.759 Y42.918 F152
G1 X102.587 Y42.921 F152
G1 X102.529 Y42.92 F152
G1 X102.472 Y42.917 F152
G1 X102.415 Y42.913 F152
G1 X102.358 Y42.907 F152
G1 X102.3 Y42.903 F152
G1 X102.287 Y42.901 F152
G1 X102.243 Y42.897 F152
G1 X102.186 Y42.893 F152
G1 X102.128 Y42.885 F152
G1 X102.071 Y42.875 F152
G1 X102.014 Y42.864 F152
G1 X101.899 Y42.845 F152
G1 X101.897 Y42.844 F152
G1 X101.842 Y42.835 F152
G1 X101.785 Y42.821 F152
G1 X101.67 Y42.793 F152
G1 X101.648 Y42.786 F152
G1 X101.613 Y42.778 F152
G1 X101.556 Y42.763 F152
G1 X101.498 Y42.749 F152
G1 X101.441 Y42.731 F152
G1 X101.438 Y42.729 F152
G1 X101.384 Y42.712 F152
G1 X101.327 Y42.693 F152
G1 X101.269 Y42.675 F152
G1 X101.259 Y42.672 F152
G1 X101.212 Y42.657 F152
G1 X101.155 Y42.637 F152
G1 X101.098 Y42.614 F152
G1 X101.097 F152
G1 X101.04 Y42.593 F152
G1 X100.983 Y42.571 F152
G1 X100.948 Y42.557 F152
G1 X100.926 Y42.549 F152
G1 X100.868 Y42.527 F152
G1 X100.811 Y42.502 F152
G1 X100.807 Y42.5 F152
G1 X100.754 Y42.477 F152
G1 X100.696 Y42.452 F152
G1 X100.676 Y42.443 F152
G1 X100.639 Y42.427 F152
G1 X100.582 Y42.402 F152
G1 X100.546 Y42.385 F152
G1 X100.41 Y42.317 F152
G1 X100.353 Y42.29 F152
G1 X100.316 Y42.271 F152
G1 X100.296 Y42.261 F152
G1 X100.238 Y42.232 F152
G1 X100.202 Y42.213 F152
G1 X100.181 Y42.204 F152
G1 X100.009 Y42.118 F152
G1 X99.975 Y42.099 F152
G1 X99.952 Y42.086 F152
G1 X99.895 Y42.054 F152
G1 X99.871 Y42.042 F152
G1 X99.837 Y42.023 F152
G1 X99.78 Y41.991 F152
G1 X99.768 Y41.984 F152
G1 X99.665 Y41.928 F152
G1 Y41.927 F152
G1 X99.608 Y41.896 F152
G1 X99.561 Y41.87 F152
G1 X99.494 Y41.833 F152
G1 X99.458 Y41.812 F152
G1 X99.436 Y41.801 F152
G1 X99.379 Y41.768 F152
G1 X99.264 Y41.703 F152
G1 X99.256 Y41.698 F152
G1 X99.207 Y41.67 F152
G1 X99.155 Y41.64 F152
G1 X99.15 Y41.638 F152
G1 X99.093 Y41.606 F152
G1 X99.054 Y41.583 F152
G1 X99.035 Y41.572 F152
G1 X98.978 Y41.541 F152
G1 X98.921 Y41.511 F152
G1 X98.864 Y41.479 F152
G1 X98.845 Y41.469 F152
G1 X98.806 Y41.448 F152
G1 X98.739 Y41.411 F152
G1 X98.692 Y41.386 F152
G1 X98.634 Y41.355 F152
G1 Y41.354 F152
G1 X98.577 Y41.326 F152
G1 X98.52 Y41.299 F152
G1 X98.515 Y41.297 F152
G1 X98.463 Y41.272 F152
G1 X98.405 Y41.244 F152
G1 X98.396 Y41.239 F152
G1 X98.348 Y41.216 F152
G1 X98.291 Y41.188 F152
G1 X98.278 Y41.182 F152
G1 X98.233 Y41.161 F152
G1 X98.148 Y41.125 F152
G1 X98.119 Y41.113 F152
G1 X98.062 Y41.089 F152
G1 X98.005 Y41.067 F152
G1 X98.004 F152
G1 X97.89 Y41.024 F152
G1 X97.847 Y41.01 F152
G1 X97.833 Y41.006 F152
G1 X97.718 Y40.968 F152
G1 X97.669 Y40.953 F152
G1 X97.661 Y40.951 F152
G1 X97.489 Y40.903 F152
G1 X97.46 Y40.896 F152
G1 X97.432 Y40.889 F152
G1 X97.374 Y40.875 F152
G1 X97.317 Y40.862 F152
G1 X97.26 Y40.849 F152
G1 X97.206 Y40.838 F152
G1 X97.202 Y40.837 F152
G1 X97.145 Y40.827 F152
G1 X97.088 Y40.815 F152
G1 X97.031 Y40.805 F152
G1 X96.973 Y40.796 F152
G1 X96.916 Y40.786 F152
G1 X96.884 Y40.781 F152
G1 X96.859 Y40.777 F152
G1 X96.801 Y40.77 F152
G1 X96.744 Y40.762 F152
G1 X96.63 Y40.748 F152
G1 X96.515 Y40.735 F152
G1 X96.458 Y40.73 F152
G1 X96.401 Y40.724 F152
G1 X96.286 Y40.715 F152
G1 X96.229 Y40.711 F152
G1 X96.114 Y40.702 F152
G1 X95.942 Y40.697 F152
G1 X95.885 Y40.694 F152
G1 X95.77 Y40.691 F152
G1 X95.713 Y40.688 F152
G1 X95.599 Y40.684 F152
G1 X95.541 Y40.683 F152
G1 X95.312 F152
G1 X95.198 Y40.687 F152
G1 X95.14 Y40.688 F152
G1 X95.126 Y40.689 F152
G1 X95.119 F152
G1 X95.112 F152
; MOVEMENT_LINK_TRANSITION
G1 X95.11 Y40.69 F152
; MOVEMENT_CUTTING
G1 X95.112 Y40.691 F152
G1 X95.115 Y40.695 F152
G1 X95.139 Y40.724 F152
G1 X95.14 Y40.726 F152
G1 X95.184 Y40.781 F152
G1 X95.198 Y40.798 F152
G1 X95.255 Y40.87 F152
G1 X95.276 Y40.896 F152
G1 X95.312 Y40.942 F152
G1 X95.363 Y41.01 F152
G1 X95.37 Y41.018 F152
G1 X95.427 Y41.095 F152
G1 X95.449 Y41.125 F152
G1 X95.484 Y41.174 F152
G1 X95.49 Y41.182 F152
G1 X95.541 Y41.255 F152
G1 X95.57 Y41.297 F152
G1 X95.599 Y41.34 F152
G1 X95.608 Y41.354 F152
G1 X95.645 Y41.411 F152
G1 X95.656 Y41.429 F152
G1 X95.68 Y41.469 F152
G1 X95.713 Y41.522 F152
G1 X95.716 Y41.526 F152
G1 X95.751 Y41.583 F152
G1 X95.77 Y41.614 F152
G1 X95.786 Y41.64 F152
G1 X95.817 Y41.698 F152
G1 X95.828 Y41.719 F152
G1 X95.847 Y41.755 F152
G1 X95.877 Y41.812 F152
G1 X95.885 Y41.828 F152
G1 X95.907 Y41.87 F152
G1 X95.937 Y41.927 F152
G1 X95.942 Y41.939 F152
G1 X95.965 Y41.984 F152
G1 X95.989 Y42.042 F152
G1 X96 Y42.067 F152
G1 X96.013 Y42.099 F152
G1 X96.037 Y42.156 F152
G1 X96.057 Y42.204 F152
G1 X96.06 Y42.213 F152
G1 X96.083 Y42.271 F152
G1 X96.101 Y42.328 F152
G1 X96.114 Y42.372 F152
G1 X96.119 Y42.385 F152
G1 X96.137 Y42.443 F152
G1 X96.171 Y42.557 F152
G1 Y42.563 F152
G1 X96.183 Y42.614 F152
G1 X96.205 Y42.729 F152
G1 X96.214 Y42.786 F152
G1 X96.225 Y42.844 F152
G1 X96.229 Y42.874 F152
G1 X96.232 Y42.901 F152
G1 X96.236 Y42.958 F152
G1 X96.239 Y43.016 F152
G1 X96.242 Y43.13 F152
G1 X96.243 Y43.187 F152
G1 X96.24 Y43.245 F152
G1 X96.235 Y43.302 F152
G1 X96.229 Y43.344 F152
G1 X96.227 Y43.359 F152
G1 X96.22 Y43.417 F152
G1 X96.212 Y43.474 F152
G1 X96.201 Y43.531 F152
G1 X96.187 Y43.589 F152
G1 X96.171 Y43.638 F152
G1 X96.169 Y43.646 F152
G1 X96.129 Y43.76 F152
G1 X96.114 Y43.802 F152
G1 X96.109 Y43.818 F152
G1 X96.085 Y43.875 F152
G1 X96.056 Y43.932 F152
G1 X96.024 Y43.99 F152
G1 X96 Y44.026 F152
G1 X95.986 Y44.047 F152
G1 X95.949 Y44.104 F152
G1 X95.942 Y44.113 F152
G1 X95.91 Y44.162 F152
G1 X95.885 Y44.195 F152
G1 X95.866 Y44.219 F152
G1 X95.828 Y44.263 F152
G1 X95.815 Y44.276 F152
G1 X95.77 Y44.321 F152
G1 X95.713 Y44.371 F152
G1 X95.691 Y44.391 F152
G1 X95.656 Y44.422 F152
G1 X95.625 Y44.448 F152
G1 X95.599 Y44.47 F152
G1 X95.55 Y44.505 F152
G1 X95.541 Y44.512 F152
G1 X95.484 Y44.547 F152
G1 X95.457 Y44.563 F152
G1 X95.427 Y44.579 F152
G1 X95.344 Y44.62 F152
G1 X95.312 Y44.637 F152
G1 X95.255 Y44.665 F152
G1 X95.225 Y44.677 F152
G1 X95.198 Y44.689 F152
G1 X95.14 Y44.709 F152
G1 X95.083 Y44.726 F152
G1 X95.026 Y44.74 F152
G1 X94.969 Y44.755 F152
G1 X94.911 Y44.769 F152
G1 X94.854 Y44.781 F152
G1 X94.797 Y44.79 F152
G1 X94.775 Y44.792 F152
G1 X94.739 Y44.795 F152
G1 X94.625 Y44.806 F152
G1 X94.568 Y44.81 F152
G1 X94.51 Y44.811 F152
G1 X94.396 Y44.808 F152
G1 X94.281 Y44.803 F152
G1 X94.224 Y44.797 F152
G1 X94.187 Y44.792 F152
G1 X94.167 Y44.789 F152
G1 X93.995 Y44.765 F152
G1 X93.88 Y44.74 F152
G1 X93.861 Y44.734 F152
G1 X93.823 Y44.726 F152
G1 X93.766 Y44.713 F152
G1 X93.708 Y44.699 F152
G1 X93.651 Y44.681 F152
G1 X93.641 Y44.677 F152
G1 X93.594 Y44.663 F152
G1 X93.537 Y44.644 F152
G1 X93.479 Y44.626 F152
G1 X93.462 Y44.62 F152
G1 X93.422 Y44.606 F152
G1 X93.365 Y44.583 F152
G1 X93.316 Y44.563 F152
G1 X93.307 Y44.56 F152
G1 X93.193 Y44.513 F152
G1 X93.175 Y44.505 F152
G1 X93.136 Y44.487 F152
G1 X93.078 Y44.46 F152
G1 X93.055 Y44.448 F152
G1 X93.021 Y44.432 F152
G1 X92.964 Y44.404 F152
G1 X92.907 Y44.375 F152
G1 X92.849 Y44.341 F152
G1 X92.735 Y44.277 F152
G1 X92.734 Y44.276 F152
G1 X92.677 Y44.243 F152
G1 X92.64 Y44.219 F152
G1 X92.62 Y44.206 F152
G1 X92.563 Y44.169 F152
G1 X92.552 Y44.162 F152
G1 X92.506 Y44.131 F152
G1 X92.465 Y44.104 F152
G1 X92.448 Y44.093 F152
G1 X92.334 Y44.007 F152
G1 X92.31 Y43.99 F152
G1 X92.276 Y43.964 F152
G1 X92.236 Y43.932 F152
G1 X92.168 Y43.875 F152
G1 X92.162 Y43.87 F152
G1 X92.105 Y43.821 F152
G1 X92.1 Y43.818 F152
G1 X92.047 Y43.773 F152
G1 X91.99 Y43.719 F152
G1 X91.973 Y43.703 F152
G1 X91.933 Y43.666 F152
G1 X91.875 Y43.611 F152
G1 X91.852 Y43.589 F152
G1 X91.818 Y43.553 F152
G1 X91.799 Y43.531 F152
G1 X91.761 Y43.491 F152
G1 X91.746 Y43.474 F152
G1 X91.693 Y43.417 F152
G1 X91.646 Y43.366 F152
G1 X91.64 Y43.359 F152
G1 X91.589 Y43.304 F152
G1 X91.587 Y43.302 F152
G1 X91.535 Y43.245 F152
G1 X91.532 Y43.24 F152
G1 X91.487 Y43.187 F152
G1 X91.475 Y43.172 F152
G1 X91.417 Y43.103 F152
G1 X91.392 Y43.073 F152
G1 X91.36 Y43.033 F152
G1 X91.347 Y43.016 F152
G1 X91.303 Y42.961 F152
G1 X91.3 Y42.958 F152
G1 X91.245 Y42.888 F152
G1 X91.21 Y42.844 F152
G1 X91.188 Y42.816 F152
G1 X91.165 Y42.786 F152
G1 X91.131 Y42.743 F152
G1 X91.12 Y42.729 F152
G1 X91.074 Y42.668 F152
G1 X91.032 Y42.614 F152
G1 X91.016 Y42.595 F152
G1 X90.987 Y42.557 F152
G1 X90.959 Y42.521 F152
G1 X90.942 Y42.5 F152
G1 X90.902 Y42.448 F152
G1 X90.897 Y42.443 F152
G1 X90.853 Y42.385 F152
G1 X90.844 Y42.375 F152
G1 X90.808 Y42.328 F152
G1 X90.787 Y42.301 F152
G1 X90.763 Y42.271 F152
G1 X90.73 Y42.23 F152
G1 X90.716 Y42.213 F152
G1 X90.673 Y42.158 F152
G1 X90.671 Y42.156 F152
G1 X90.625 Y42.099 F152
G1 X90.615 Y42.086 F152
G1 X90.558 Y42.015 F152
G1 X90.533 Y41.984 F152
G1 X90.501 Y41.946 F152
G1 X90.485 Y41.927 F152
G1 X90.444 Y41.878 F152
G1 X90.436 Y41.87 F152
G1 X90.388 Y41.812 F152
G1 X90.386 Y41.81 F152
G1 X90.34 Y41.755 F152
G1 X90.329 Y41.742 F152
G1 X90.291 Y41.698 F152
G1 X90.272 Y41.674 F152
G1 X90.242 Y41.64 F152
G1 X90.214 Y41.61 F152
G1 X90.189 Y41.583 F152
G1 X90.157 Y41.547 F152
G1 X90.1 Y41.485 F152
G1 X90.086 Y41.469 F152
G1 X90.033 Y41.411 F152
G1 X89.985 Y41.359 F152
G1 X89.981 Y41.354 F152
G1 X89.928 Y41.301 F152
G1 X89.923 Y41.297 F152
G1 X89.851 Y41.225 F152
G1 X89.836 Y41.211 F152
G1 X89.835 Y41.209 F152
G1 X89.832 Y41.207 F152
G1 X89.83 Y41.205 F152
G1 Y41.204 F152
; MOVEMENT_LINK_TRANSITION
G1 Y41.208 F152
; MOVEMENT_CUTTING
G1 X89.831 Y41.211 F152
G1 X89.835 Y41.221 F152
G1 X89.837 Y41.229 F152
G1 X89.842 Y41.239 F152
G1 X89.851 Y41.264 F152
G1 X89.853 Y41.268 F152
G1 X89.864 Y41.297 F152
G1 X89.871 Y41.317 F152
G1 X89.874 Y41.325 F152
G1 X89.928 Y41.469 F152
G1 X89.949 Y41.526 F152
G1 X89.971 Y41.583 F152
G1 X89.985 Y41.622 F152
G1 X89.992 Y41.64 F152
G1 X90.015 Y41.698 F152
G1 X90.039 Y41.755 F152
G1 X90.043 Y41.763 F152
G1 X90.064 Y41.812 F152
G1 X90.088 Y41.87 F152
G1 X90.1 Y41.896 F152
G1 X90.113 Y41.927 F152
G1 X90.137 Y41.984 F152
G1 X90.157 Y42.03 F152
G1 X90.162 Y42.042 F152
G1 X90.188 Y42.099 F152
G1 X90.212 Y42.156 F152
G1 X90.214 Y42.163 F152
G1 X90.237 Y42.213 F152
G1 X90.261 Y42.271 F152
G1 X90.272 Y42.294 F152
G1 X90.288 Y42.328 F152
G1 X90.368 Y42.5 F152
G1 X90.386 Y42.537 F152
G1 X90.396 Y42.557 F152
G1 X90.423 Y42.614 F152
G1 X90.444 Y42.659 F152
G1 X90.45 Y42.672 F152
G1 X90.477 Y42.729 F152
G1 X90.501 Y42.781 F152
G1 X90.503 Y42.786 F152
G1 X90.558 Y42.903 F152
G1 X90.614 Y43.016 F152
G1 X90.615 Y43.018 F152
G1 X90.643 Y43.073 F152
G1 X90.672 Y43.13 F152
G1 X90.673 Y43.133 F152
G1 X90.7 Y43.187 F152
G1 X90.729 Y43.245 F152
G1 X90.73 Y43.247 F152
G1 X90.758 Y43.302 F152
G1 X90.786 Y43.359 F152
G1 X90.787 Y43.362 F152
G1 X90.815 Y43.417 F152
G1 X90.844 Y43.474 F152
G1 Y43.477 F152
G1 X90.872 Y43.531 F152
G1 X90.902 Y43.589 F152
G1 X90.931 Y43.646 F152
G1 X90.959 Y43.7 F152
G1 X90.961 Y43.703 F152
G1 X90.99 Y43.76 F152
G1 X91.016 Y43.811 F152
G1 X91.02 Y43.818 F152
G1 X91.049 Y43.875 F152
G1 X91.074 Y43.922 F152
G1 X91.079 Y43.932 F152
G1 X91.108 Y43.99 F152
G1 X91.131 Y44.033 F152
G1 X91.138 Y44.047 F152
G1 X91.168 Y44.104 F152
G1 X91.188 Y44.144 F152
G1 X91.198 Y44.162 F152
G1 X91.228 Y44.219 F152
G1 X91.245 Y44.254 F152
G1 X91.257 Y44.276 F152
G1 X91.287 Y44.333 F152
G1 X91.317 Y44.391 F152
G1 X91.347 Y44.448 F152
G1 X91.36 Y44.472 F152
G1 X91.377 Y44.505 F152
G1 X91.407 Y44.563 F152
G1 X91.417 Y44.582 F152
G1 X91.437 Y44.62 F152
G1 X91.467 Y44.677 F152
G1 X91.475 Y44.692 F152
G1 X91.497 Y44.734 F152
G1 X91.526 Y44.792 F152
G1 X91.532 Y44.802 F152
G1 X91.557 Y44.849 F152
G1 X91.586 Y44.906 F152
G1 X91.589 Y44.913 F152
G1 X91.616 Y44.964 F152
G1 X91.645 Y45.021 F152
G1 X91.646 Y45.024 F152
G1 X91.675 Y45.078 F152
G1 X91.704 Y45.136 F152
G1 X91.733 Y45.193 F152
G1 X91.762 Y45.25 F152
G1 X91.791 Y45.307 F152
G1 X91.818 Y45.362 F152
G1 X91.82 Y45.365 F152
G1 X91.848 Y45.422 F152
G1 X91.875 Y45.478 F152
G1 X91.876 Y45.479 F152
G1 X91.904 Y45.537 F152
G1 X91.933 Y45.594 F152
G1 Y45.595 F152
G1 X91.96 Y45.651 F152
G1 X91.986 Y45.709 F152
G1 X91.99 Y45.717 F152
G1 X92.013 Y45.766 F152
G1 X92.047 Y45.838 F152
G1 X92.066 Y45.88 F152
G1 X92.091 Y45.938 F152
G1 X92.105 Y45.969 F152
G1 X92.116 Y45.995 F152
G1 X92.141 Y46.052 F152
G1 X92.162 Y46.101 F152
G1 X92.165 Y46.11 F152
G1 X92.21 Y46.224 F152
G1 X92.219 Y46.247 F152
G1 X92.233 Y46.281 F152
G1 X92.255 Y46.339 F152
G1 X92.311 Y46.511 F152
G1 X92.329 Y46.568 F152
G1 X92.334 Y46.584 F152
G1 X92.344 Y46.625 F152
G1 X92.385 Y46.797 F152
G1 X92.391 Y46.831 F152
G1 X92.395 Y46.854 F152
G1 X92.403 Y46.912 F152
G1 X92.415 Y47.026 F152
G1 X92.419 Y47.084 F152
G1 Y47.141 F152
G1 X92.416 Y47.198 F152
G1 X92.414 Y47.256 F152
G1 X92.41 Y47.313 F152
G1 X92.403 Y47.37 F152
G1 X92.392 Y47.427 F152
G1 X92.391 Y47.431 F152
G1 X92.378 Y47.485 F152
G1 X92.343 Y47.599 F152
G1 X92.334 Y47.626 F152
G1 X92.323 Y47.657 F152
G1 X92.3 Y47.714 F152
G1 X92.276 Y47.763 F152
G1 X92.273 Y47.771 F152
G1 X92.241 Y47.829 F152
G1 X92.219 Y47.862 F152
G1 X92.203 Y47.886 F152
G1 X92.162 Y47.946 F152
G1 X92.118 Y48 F152
G1 X92.105 Y48.017 F152
G1 X92.066 Y48.058 F152
G1 X92.006 Y48.115 F152
G1 X91.99 Y48.129 F152
G1 X91.939 Y48.172 F152
G1 X91.933 Y48.178 F152
G1 X91.875 Y48.219 F152
G1 X91.858 Y48.23 F152
G1 X91.818 Y48.255 F152
G1 X91.761 Y48.285 F152
G1 X91.704 Y48.313 F152
G1 X91.646 Y48.34 F152
G1 X91.637 Y48.344 F152
G1 X91.589 Y48.364 F152
G1 X91.532 Y48.384 F152
G1 X91.475 Y48.401 F152
G1 X91.472 F152
G1 X91.417 Y48.414 F152
G1 X91.36 Y48.424 F152
G1 X91.245 Y48.442 F152
G1 X91.188 Y48.447 F152
G1 X91.131 Y48.449 F152
G1 X91.074 F152
G1 X90.959 Y48.447 F152
G1 X90.902 Y48.443 F152
G1 X90.787 Y48.43 F152
G1 X90.73 Y48.423 F152
G1 X90.615 Y48.401 F152
G1 X90.558 Y48.392 F152
G1 X90.501 Y48.38 F152
G1 X90.386 Y48.353 F152
G1 X90.35 Y48.344 F152
G1 X90.329 Y48.34 F152
G1 X90.272 Y48.324 F152
G1 X90.214 Y48.31 F152
G1 X90.157 Y48.295 F152
G1 X90.043 Y48.263 F152
G1 X89.985 Y48.247 F152
G1 X89.928 Y48.231 F152
G1 X89.924 Y48.23 F152
G1 X89.871 Y48.214 F152
G1 X89.756 Y48.182 F152
G1 X89.723 Y48.172 F152
G1 X89.699 Y48.166 F152
G1 X89.584 Y48.134 F152
G1 X89.527 Y48.119 F152
G1 X89.516 Y48.115 F152
G1 X89.47 Y48.102 F152
G1 X89.412 Y48.087 F152
G1 X89.298 Y48.059 F152
G1 X89.297 Y48.058 F152
G1 X89.241 Y48.044 F152
G1 X89.183 Y48.03 F152
G1 X89.069 Y48.005 F152
G1 X89.049 Y48 F152
G1 X89.012 Y47.992 F152
G1 X88.897 Y47.967 F152
G1 X88.84 Y47.956 F152
G1 X88.782 Y47.946 F152
G1 X88.766 Y47.943 F152
G1 X88.725 Y47.937 F152
G1 X88.496 Y47.897 F152
G1 X88.439 Y47.889 F152
G1 X88.417 Y47.886 F152
G1 X88.381 Y47.881 F152
G1 X88.324 Y47.873 F152
G1 X88.152 Y47.852 F152
G1 X88.095 Y47.844 F152
G1 X88.038 Y47.837 F152
G1 X87.981 Y47.829 F152
G1 X87.866 Y47.814 F152
G1 X87.809 Y47.806 F152
G1 X87.694 Y47.785 F152
G1 X87.637 Y47.775 F152
G1 X87.621 Y47.771 F152
G1 X87.58 Y47.764 F152
G1 X87.465 Y47.743 F152
G1 X87.408 Y47.73 F152
G1 X87.35 Y47.715 F152
G1 X87.347 Y47.714 F152
G1 X87.236 Y47.684 F152
G1 X87.179 Y47.667 F152
G1 X87.149 Y47.657 F152
G1 X87.121 Y47.648 F152
G1 X87.007 Y47.608 F152
G1 X86.984 Y47.599 F152
G1 X86.95 Y47.585 F152
G1 X86.892 Y47.56 F152
G1 X86.851 Y47.542 F152
G1 X86.835 Y47.536 F152
G1 X86.778 Y47.511 F152
G1 X86.727 Y47.485 F152
G1 X86.72 Y47.482 F152
G1 X86.663 Y47.451 F152
G1 X86.606 Y47.42 F152
G1 X86.549 Y47.389 F152
G1 X86.516 Y47.37 F152
G1 X86.434 Y47.317 F152
G1 X86.427 Y47.313 F152
G1 X86.377 Y47.281 F152
G1 X86.338 Y47.256 F152
G1 X86.319 Y47.243 F152
G1 X86.259 Y47.198 F152
G1 X86.205 Y47.158 F152
G1 X86.182 Y47.141 F152
G1 X86.106 Y47.084 F152
G1 X86.09 Y47.07 F152
G1 X86.039 Y47.026 F152
G1 X86.033 Y47.022 F152
G1 X85.976 Y46.973 F152
G1 X85.971 Y46.969 F152
G1 X85.905 Y46.912 F152
G1 X85.861 Y46.871 F152
G1 X85.844 Y46.854 F152
G1 X85.784 Y46.797 F152
G1 X85.747 Y46.762 F152
G1 X85.723 Y46.74 F152
G1 X85.689 Y46.705 F152
G1 X85.668 Y46.683 F152
G1 X85.632 Y46.646 F152
G1 X85.612 Y46.625 F152
G1 X85.575 Y46.587 F152
G1 X85.556 Y46.568 F152
G1 X85.518 Y46.527 F152
G1 X85.503 Y46.511 F152
G1 X85.45 Y46.453 F152
G1 X85.403 Y46.401 F152
G1 X85.398 Y46.396 F152
G1 X85.347 Y46.339 F152
G1 X85.346 Y46.337 F152
G1 X85.299 Y46.281 F152
G1 X85.25 Y46.224 F152
G1 X85.231 Y46.202 F152
G1 X85.202 Y46.167 F152
G1 X85.174 Y46.134 F152
G1 X85.153 Y46.11 F152
G1 X85.117 Y46.066 F152
G1 X85.105 Y46.052 F152
G1 X85.059 Y45.998 F152
G1 X85.057 Y45.995 F152
G1 X85.008 Y45.938 F152
G1 X85.002 Y45.93 F152
G1 X84.963 Y45.88 F152
G1 X84.945 Y45.859 F152
G1 X84.887 Y45.787 F152
G1 X84.87 Y45.766 F152
G1 X84.83 Y45.716 F152
G1 X84.824 Y45.709 F152
G1 X84.778 Y45.651 F152
G1 X84.773 Y45.645 F152
G1 X84.771 Y45.642 F152
G1 X84.768 Y45.64 F152
G1 Y45.638 F152
; MOVEMENT_LINK_TRANSITION
G1 X84.767 F152
; MOVEMENT_CUTTING
G1 Y45.64 F152
G1 X84.766 Y45.642 F152
G1 X84.763 Y45.651 F152
G1 X84.747 Y45.709 F152
G1 X84.73 Y45.766 F152
G1 X84.716 Y45.815 F152
G1 X84.714 Y45.823 F152
G1 X84.697 Y45.88 F152
G1 X84.681 Y45.938 F152
G1 X84.663 Y45.995 F152
G1 X84.642 Y46.052 F152
G1 X84.623 Y46.11 F152
G1 X84.602 Y46.167 F152
G1 X84.601 Y46.168 F152
G1 X84.581 Y46.224 F152
G1 X84.558 Y46.281 F152
G1 X84.534 Y46.339 F152
G1 X84.511 Y46.396 F152
G1 X84.487 Y46.452 F152
G1 Y46.453 F152
G1 X84.461 Y46.511 F152
G1 X84.433 Y46.568 F152
G1 X84.429 Y46.575 F152
G1 X84.405 Y46.625 F152
G1 X84.377 Y46.683 F152
G1 X84.349 Y46.74 F152
G1 X84.316 Y46.797 F152
G1 X84.315 Y46.8 F152
G1 X84.284 Y46.854 F152
G1 X84.218 Y46.969 F152
G1 X84.2 Y46.998 F152
G1 X84.144 Y47.084 F152
G1 X84.143 Y47.085 F152
G1 X84.106 Y47.141 F152
G1 X84.086 Y47.172 F152
G1 X84.068 Y47.198 F152
G1 X84.028 Y47.251 F152
G1 X84.025 Y47.256 F152
G1 X83.971 Y47.327 F152
G1 X83.938 Y47.37 F152
G1 X83.914 Y47.402 F152
G1 X83.894 Y47.427 F152
G1 X83.844 Y47.485 F152
G1 X83.799 Y47.537 F152
G1 X83.795 Y47.542 F152
G1 X83.745 Y47.599 F152
G1 X83.742 Y47.603 F152
G1 X83.692 Y47.657 F152
G1 X83.634 Y47.714 F152
G1 X83.627 Y47.722 F152
G1 X83.57 Y47.779 F152
G1 X83.52 Y47.829 F152
G1 X83.513 Y47.836 F152
G1 X83.456 Y47.886 F152
G1 X83.455 Y47.887 F152
G1 X83.398 Y47.939 F152
G1 X83.393 Y47.943 F152
G1 X83.341 Y47.99 F152
G1 X83.328 Y48 F152
G1 X83.284 Y48.037 F152
G1 X83.258 Y48.058 F152
G1 X83.186 Y48.115 F152
G1 X83.169 Y48.129 F152
G1 X83.114 Y48.172 F152
G1 X83.112 Y48.174 F152
G1 X83.055 Y48.215 F152
G1 X83.035 Y48.23 F152
G1 X82.997 Y48.257 F152
G1 X82.94 Y48.299 F152
G1 X82.883 Y48.339 F152
G1 X82.874 Y48.344 F152
G1 X82.788 Y48.401 F152
G1 X82.768 Y48.415 F152
G1 X82.711 Y48.453 F152
G1 X82.701 Y48.459 F152
G1 X82.654 Y48.488 F152
G1 X82.609 Y48.516 F152
G1 X82.596 Y48.523 F152
G1 X82.539 Y48.559 F152
G1 X82.515 Y48.573 F152
G1 X82.482 Y48.594 F152
G1 X82.367 Y48.66 F152
G1 X82.31 Y48.692 F152
G1 X82.253 Y48.726 F152
G1 X82.217 Y48.745 F152
G1 X82.195 Y48.757 F152
G1 X82.138 Y48.787 F152
G1 X82.109 Y48.803 F152
G1 X82.081 Y48.818 F152
G1 X82.024 Y48.847 F152
G1 X82 Y48.86 F152
G1 X81.966 Y48.878 F152
G1 X81.909 Y48.908 F152
G1 X81.892 Y48.917 F152
G1 X81.794 Y48.969 F152
G1 X81.783 Y48.974 F152
G1 X81.737 Y48.997 F152
G1 X81.68 Y49.025 F152
G1 X81.666 Y49.032 F152
G1 X81.623 Y49.053 F152
G1 X81.565 Y49.081 F152
G1 X81.547 Y49.089 F152
G1 X81.508 Y49.109 F152
G1 X81.451 Y49.136 F152
G1 X81.43 Y49.146 F152
G1 X81.393 Y49.164 F152
G1 X81.312 Y49.204 F152
G1 X81.279 Y49.219 F152
G1 X81.222 Y49.245 F152
G1 X81.185 Y49.261 F152
G1 X81.164 Y49.27 F152
G1 X81.107 Y49.296 F152
G1 X81.057 Y49.318 F152
G1 X81.05 Y49.322 F152
G1 X80.992 Y49.348 F152
G1 X80.935 Y49.373 F152
G1 X80.93 Y49.376 F152
G1 X80.878 Y49.399 F152
G1 X80.821 Y49.424 F152
G1 X80.799 Y49.433 F152
G1 X80.763 Y49.448 F152
G1 X80.706 Y49.471 F152
G1 X80.66 Y49.49 F152
G1 X80.649 Y49.495 F152
G1 X80.592 Y49.519 F152
G1 X80.534 Y49.543 F152
G1 X80.522 Y49.547 F152
G1 X80.42 Y49.59 F152
G1 X80.384 Y49.605 F152
G1 X80.362 Y49.614 F152
G1 X80.305 Y49.636 F152
G1 X80.248 Y49.658 F152
G1 X80.236 Y49.662 F152
G1 X80.191 Y49.68 F152
G1 X80.133 Y49.701 F152
G1 X80.085 Y49.719 F152
G1 X80.076 Y49.723 F152
G1 X79.961 Y49.764 F152
G1 X79.926 Y49.777 F152
G1 X79.904 Y49.785 F152
G1 X79.847 Y49.804 F152
G1 X79.79 Y49.822 F152
G1 X79.753 Y49.834 F152
G1 X79.732 Y49.84 F152
G1 X79.675 Y49.859 F152
G1 X79.618 Y49.877 F152
G1 X79.571 Y49.891 F152
G1 X79.561 Y49.895 F152
G1 X79.389 Y49.948 F152
G1 X79.388 F152
G1 X79.331 Y49.964 F152
G1 X79.274 Y49.977 F152
G1 X79.217 Y49.991 F152
G1 X79.16 Y50.005 F152
G1 X79.045 Y50.034 F152
G1 X78.988 Y50.047 F152
G1 X78.93 Y50.061 F152
G1 X78.873 Y50.073 F152
G1 X78.759 Y50.094 F152
G1 X78.644 Y50.114 F152
G1 X78.472 Y50.138 F152
G1 X78.415 Y50.145 F152
G1 X78.358 Y50.152 F152
G1 X78.3 Y50.157 F152
G1 X78.243 Y50.162 F152
G1 X78.186 Y50.167 F152
G1 X78.129 Y50.171 F152
G1 X78.071 Y50.174 F152
G1 X77.956 Y50.178 F152
G1 X77.899 Y50.18 F152
G1 X77.785 F152
G1 X77.728 Y50.179 F152
G1 X77.67 F152
G1 X77.635 Y50.178 F152
G1 X77.613 Y50.177 F152
G1 X77.441 Y50.169 F152
G1 X77.384 Y50.164 F152
G1 X77.327 Y50.158 F152
G1 X77.04 Y50.131 F152
G1 X76.926 Y50.117 F152
G1 X76.868 Y50.111 F152
G1 X76.697 Y50.089 F152
G1 X76.639 Y50.083 F152
G1 X76.467 Y50.067 F152
G1 X76.435 Y50.063 F152
G1 X76.41 Y50.061 F152
G1 X76.353 Y50.059 F152
G1 X76.296 Y50.057 F152
G1 X76.238 Y50.059 F152
G1 X76.184 Y50.063 F152
G1 X76.181 Y50.064 F152
G1 X76.124 Y50.074 F152
G1 X76.095 Y50.082 F152
G1 X76.066 Y50.092 F152
G1 X76.009 Y50.12 F152
G1 X75.952 Y50.161 F152
G1 X75.93 Y50.178 F152
G1 X75.895 Y50.21 F152
G1 X75.867 Y50.235 F152
G1 X75.837 Y50.267 F152
G1 X75.814 Y50.292 F152
G1 X75.78 Y50.33 F152
G1 X75.765 Y50.35 F152
G1 X75.723 Y50.403 F152
G1 X75.678 Y50.464 F152
G1 X75.666 Y50.482 F152
G1 X75.608 Y50.566 F152
G1 X75.6 Y50.579 F152
G1 X75.566 Y50.636 F152
G1 X75.551 Y50.66 F152
G1 X75.531 Y50.693 F152
G1 X75.498 Y50.751 F152
G1 X75.494 Y50.759 F152
G1 X75.468 Y50.808 F152
G1 X75.436 Y50.865 F152
G1 X75.407 Y50.923 F152
G1 X75.379 Y50.979 F152
G1 Y50.98 F152
G1 X75.324 Y51.094 F152
G1 X75.322 Y51.097 F152
G1 X75.298 Y51.152 F152
G1 X75.273 Y51.209 F152
G1 X75.265 Y51.226 F152
G1 X75.248 Y51.266 F152
G1 X75.223 Y51.324 F152
G1 X75.207 Y51.363 F152
G1 X75.2 Y51.381 F152
G1 X75.179 Y51.438 F152
G1 X75.156 Y51.496 F152
G1 X75.15 Y51.511 F152
G1 X75.134 Y51.553 F152
G1 X75.112 Y51.61 F152
G1 X75.093 Y51.658 F152
G1 X75.089 Y51.667 F152
G1 X75.067 Y51.725 F152
G1 X75.045 Y51.782 F152
G1 X75.035 Y51.812 F152
G1 X75.027 Y51.839 F152
G1 X74.989 Y51.954 F152
G1 X74.978 Y51.985 F152
G1 X74.97 Y52.011 F152
G1 X74.951 Y52.068 F152
G1 X74.932 Y52.126 F152
G1 X74.921 Y52.158 F152
G1 X74.913 Y52.183 F152
G1 X74.894 Y52.24 F152
G1 X74.876 Y52.298 F152
G1 X74.859 Y52.355 F152
G1 X74.827 Y52.47 F152
G1 X74.81 Y52.527 F152
G1 X74.806 Y52.539 F152
G1 X74.762 Y52.699 F152
G1 X74.749 Y52.74 F152
G1 X74.745 Y52.756 F152
G1 X74.714 Y52.871 F152
G1 X74.7 Y52.928 F152
G1 X74.692 Y52.957 F152
G1 X74.642 Y53.157 F152
G1 X74.635 Y53.187 F152
G1 X74.628 Y53.214 F152
G1 X74.615 Y53.272 F152
G1 X74.601 Y53.329 F152
G1 X74.587 Y53.386 F152
G1 X74.577 Y53.429 F152
G1 X74.575 Y53.444 F152
G1 X74.561 Y53.501 F152
G1 X74.524 Y53.673 F152
G1 X74.52 Y53.688 F152
G1 X74.511 Y53.73 F152
G1 X74.499 Y53.787 F152
G1 X74.487 Y53.845 F152
G1 X74.476 Y53.902 F152
G1 X74.463 Y53.968 F152
G1 X74.454 Y54.017 F152
G1 X74.442 Y54.074 F152
G1 X74.431 Y54.131 F152
G1 X74.42 Y54.188 F152
G1 X74.409 Y54.246 F152
G1 X74.405 Y54.26 F152
G1 X74.376 Y54.418 F152
G1 X74.366 Y54.475 F152
G1 X74.355 Y54.532 F152
G1 X74.348 Y54.573 F152
G1 X74.345 Y54.59 F152
G1 X74.336 Y54.647 F152
G1 X74.325 Y54.704 F152
G1 X74.305 Y54.819 F152
G1 X74.294 Y54.876 F152
G1 X74.291 Y54.896 F152
G1 X74.285 Y54.933 F152
G1 X74.276 Y54.991 F152
G1 X74.267 Y55.048 F152
G1 X74.257 Y55.105 F152
G1 X74.248 Y55.163 F152
G1 X74.238 Y55.22 F152
G1 X74.234 Y55.245 F152
G1 X74.229 Y55.277 F152
G1 X74.209 Y55.392 F152
G1 X74.2 Y55.449 F152
G1 X74.191 Y55.506 F152
G1 X74.182 Y55.564 F152
G1 X74.176 Y55.594 F152
G1 X74.172 Y55.621 F152
G1 X74.163 Y55.678 F152
G1 X74.153 Y55.735 F152
G1 X74.144 Y55.793 F152
G1 X74.134 Y55.85 F152
G1 X74.125 Y55.907 F152
G1 X74.119 Y55.942 F152
G1 X74.115 Y55.965 F152
G1 X74.106 Y56.022 F152
G1 X74.087 Y56.137 F152
G1 X74.078 Y56.194 F152
G1 X74.068 Y56.251 F152
G1 X74.062 Y56.287 F152
G1 X74.058 Y56.308 F152
G1 X74.049 Y56.366 F152
G1 X74.03 Y56.48 F152
G1 X74.019 Y56.538 F152
G1 X74.009 Y56.595 F152
G1 X74.004 Y56.618 F152
G1 X73.999 Y56.652 F152
G1 X73.989 Y56.71 F152
G1 X73.978 Y56.767 F152
G1 X73.959 Y56.881 F152
G1 X73.948 Y56.939 F152
G1 X73.947 Y56.941 F152
G1 X73.937 Y56.996 F152
G1 X73.916 Y57.111 F152
G1 X73.904 Y57.168 F152
G1 X73.893 Y57.225 F152
G1 X73.89 Y57.243 F152
G1 X73.883 Y57.283 F152
G1 X73.861 Y57.397 F152
G1 X73.85 Y57.454 F152
G1 X73.837 Y57.512 F152
G1 X73.833 Y57.533 F152
G1 X73.825 Y57.569 F152
G1 X73.802 Y57.684 F152
G1 X73.79 Y57.741 F152
G1 X73.778 Y57.798 F152
G1 X73.775 Y57.81 F152
G1 X73.766 Y57.855 F152
G1 X73.755 Y57.913 F152
G1 X73.741 Y57.97 F152
G1 X73.729 Y58.027 F152
G1 X73.715 Y58.085 F152
G1 X73.703 Y58.142 F152
G1 X73.689 Y58.199 F152
G1 X73.677 Y58.257 F152
G1 X73.661 Y58.325 F152
G1 X73.651 Y58.371 F152
G1 X73.624 Y58.486 F152
G1 X73.61 Y58.543 F152
G1 X73.603 Y58.569 F152
G1 X73.596 Y58.6 F152
G1 X73.582 Y58.658 F152
G1 X73.569 Y58.715 F152
G1 X73.553 Y58.772 F152
G1 X73.546 Y58.8 F152
G1 X73.539 Y58.83 F152
G1 X73.525 Y58.887 F152
G1 X73.51 Y58.944 F152
G1 X73.495 Y59.001 F152
G1 X73.489 Y59.024 F152
G1 X73.48 Y59.059 F152
G1 X73.465 Y59.116 F152
G1 X73.449 Y59.173 F152
G1 X73.433 Y59.231 F152
G1 X73.432 Y59.236 F152
G1 X73.418 Y59.288 F152
G1 X73.402 Y59.345 F152
G1 X73.387 Y59.402 F152
G1 X73.374 Y59.448 F152
G1 X73.372 Y59.46 F152
G1 X73.356 Y59.517 F152
G1 X73.324 Y59.632 F152
G1 X73.317 Y59.655 F152
G1 X73.308 Y59.689 F152
G1 X73.291 Y59.746 F152
G1 X73.275 Y59.804 F152
G1 X73.26 Y59.856 F152
G1 X73.259 Y59.861 F152
G1 X73.243 Y59.918 F152
G1 X73.226 Y59.975 F152
G1 X73.21 Y60.033 F152
G1 X73.203 Y60.057 F152
G1 X73.194 Y60.09 F152
G1 X73.16 Y60.205 F152
G1 X73.145 Y60.252 F152
G1 X73.143 Y60.262 F152
G1 X73.092 Y60.434 F152
G1 X73.088 Y60.444 F152
G1 X73.074 Y60.491 F152
G1 X73.04 Y60.606 F152
G1 X73.031 Y60.635 F152
G1 X73.023 Y60.663 F152
G1 X73.006 Y60.72 F152
G1 X72.988 Y60.778 F152
G1 X72.973 Y60.822 F152
G1 X72.97 Y60.835 F152
G1 X72.88 Y61.121 F152
G1 X72.863 Y61.179 F152
G1 X72.859 Y61.191 F152
G1 X72.845 Y61.236 F152
G1 X72.828 Y61.293 F152
G1 X72.809 Y61.351 F152
G1 X72.802 Y61.371 F152
G1 X72.79 Y61.408 F152
G1 X72.752 Y61.522 F152
G1 X72.744 Y61.546 F152
G1 X72.734 Y61.58 F152
G1 X72.696 Y61.694 F152
G1 X72.687 Y61.721 F152
G1 X72.677 Y61.752 F152
G1 X72.64 Y61.866 F152
G1 X72.63 Y61.897 F152
G1 X72.621 Y61.924 F152
G1 X72.603 Y61.981 F152
G1 X72.584 Y62.038 F152
G1 X72.572 Y62.071 F152
G1 X72.565 Y62.095 F152
G1 X72.528 Y62.21 F152
G1 X72.515 Y62.247 F152
G1 X72.509 Y62.267 F152
G1 X72.471 Y62.382 F152
G1 X72.458 Y62.422 F152
G1 X72.453 Y62.439 F152
G1 X72.413 Y62.554 F152
G1 X72.401 Y62.591 F152
G1 X72.393 Y62.611 F152
G1 X72.334 Y62.783 F152
G1 X72.316 Y62.84 F152
G1 X72.296 Y62.898 F152
G1 X72.286 Y62.924 F152
G1 X72.276 Y62.955 F152
G1 X72.257 Y63.012 F152
G1 X72.236 Y63.069 F152
G1 X72.229 Y63.089 F152
G1 X72.215 Y63.127 F152
G1 X72.196 Y63.184 F152
G1 X72.172 Y63.251 F152
G1 X72.155 Y63.299 F152
G1 X72.114 Y63.413 F152
G1 X72.095 Y63.471 F152
G1 X72.033 Y63.642 F152
G1 X72.011 Y63.7 F152
G1 X72 Y63.732 F152
G1 X71.97 Y63.814 F152
G1 X71.949 Y63.872 F152
G1 X71.942 Y63.889 F152
G1 X71.928 Y63.929 F152
G1 X71.908 Y63.986 F152
G1 X71.886 Y64.044 F152
G1 X71.885 Y64.045 F152
G1 X71.865 Y64.101 F152
G1 X71.844 Y64.158 F152
G1 X71.828 Y64.199 F152
G1 X71.822 Y64.215 F152
G1 X71.8 Y64.273 F152
G1 X71.779 Y64.33 F152
G1 X71.771 Y64.351 F152
G1 X71.757 Y64.387 F152
G1 X71.736 Y64.445 F152
G1 X71.713 Y64.502 F152
G1 X71.67 Y64.617 F152
G1 X71.603 Y64.788 F152
G1 X71.599 Y64.8 F152
G1 X71.558 Y64.903 F152
G1 X71.541 Y64.945 F152
G1 X71.536 Y64.96 F152
G1 X71.513 Y65.018 F152
G1 X71.49 Y65.075 F152
G1 X71.484 Y65.089 F152
G1 X71.467 Y65.132 F152
G1 X71.444 Y65.189 F152
G1 X71.427 Y65.231 F152
G1 X71.421 Y65.247 F152
G1 X71.397 Y65.304 F152
G1 X71.373 Y65.361 F152
G1 X71.37 Y65.37 F152
G1 X71.35 Y65.419 F152
G1 X71.326 Y65.476 F152
G1 X71.312 Y65.507 F152
G1 X71.302 Y65.533 F152
G1 X71.277 Y65.591 F152
G1 X71.255 Y65.642 F152
G1 X71.253 Y65.648 F152
G1 X71.203 Y65.762 F152
G1 X71.198 Y65.774 F152
G1 X71.178 Y65.82 F152
G1 X71.153 Y65.877 F152
G1 X71.14 Y65.904 F152
G1 X71.127 Y65.934 F152
G1 X71.101 Y65.992 F152
G1 X71.083 Y66.03 F152
G1 X71.075 Y66.049 F152
G1 X71.048 Y66.106 F152
G1 X71.026 Y66.154 F152
G1 X71.021 Y66.164 F152
G1 X70.969 Y66.273 F152
G1 X70.967 Y66.278 F152
G1 X70.938 Y66.335 F152
G1 X70.911 Y66.388 F152
G1 X70.91 Y66.393 F152
G1 X70.88 Y66.45 F152
G1 X70.854 Y66.501 F152
G1 X70.851 Y66.507 F152
G1 X70.82 Y66.565 F152
G1 X70.797 Y66.608 F152
G1 X70.79 Y66.622 F152
G1 X70.758 Y66.679 F152
G1 X70.74 Y66.714 F152
G1 X70.695 Y66.794 F152
G1 X70.682 Y66.815 F152
G1 X70.662 Y66.851 F152
G1 X70.629 Y66.908 F152
G1 X70.625 Y66.916 F152
G1 X70.595 Y66.966 F152
G1 X70.568 Y67.01 F152
G1 X70.561 Y67.023 F152
G1 X70.491 Y67.138 F152
G1 X70.453 Y67.195 F152
G1 X70.416 Y67.252 F152
G1 X70.396 Y67.284 F152
G1 X70.38 Y67.309 F152
G1 X70.34 Y67.367 F152
G1 X70.339 Y67.369 F152
G1 X70.301 Y67.424 F152
G1 X70.281 Y67.452 F152
G1 X70.262 Y67.481 F152
G1 X70.224 Y67.533 F152
G1 X70.22 Y67.539 F152
G1 X70.178 Y67.596 F152
G1 X70.167 Y67.611 F152
G1 X70.109 Y67.688 F152
G1 X70.092 Y67.711 F152
G1 X70.052 Y67.76 F152
G1 X70.046 Y67.768 F152
G1 X69.999 Y67.825 F152
G1 X69.995 Y67.831 F152
G1 X69.938 Y67.901 F152
G1 X69.906 Y67.94 F152
G1 X69.88 Y67.972 F152
G1 X69.86 Y67.997 F152
G1 X69.823 Y68.04 F152
G1 X69.81 Y68.054 F152
G1 X69.766 Y68.102 F152
G1 X69.709 Y68.164 F152
G1 X69.705 Y68.169 F152
G1 X69.651 Y68.227 F152
G1 X69.599 Y68.284 F152
G1 X69.594 Y68.29 F152
G1 X69.547 Y68.341 F152
G1 X69.537 Y68.351 F152
G1 X69.488 Y68.398 F152
G1 X69.422 Y68.464 F152
G1 X69.373 Y68.513 F152
G1 X69.365 Y68.521 F152
G1 X69.315 Y68.57 F152
G1 X69.308 Y68.577 F152
G1 X69.257 Y68.627 F152
G1 X69.25 Y68.633 F152
G1 X69.196 Y68.685 F152
G1 X69.193 Y68.687 F152
G1 X69.078 Y68.797 F152
G1 X69.076 Y68.799 F152
G1 X69.021 Y68.851 F152
G1 X69.015 Y68.856 F152
G1 X68.964 Y68.906 F152
G1 X68.955 Y68.914 F152
G1 X68.907 Y68.959 F152
G1 X68.895 Y68.971 F152
G1 X68.834 Y69.028 F152
G1 X68.792 Y69.069 F152
G1 X68.774 Y69.086 F152
G1 X68.735 Y69.127 F152
G1 X68.72 Y69.143 F152
G1 X68.677 Y69.186 F152
G1 X68.664 Y69.2 F152
G1 X68.62 Y69.245 F152
G1 X68.609 Y69.258 F152
G1 X68.563 Y69.309 F152
G1 X68.558 Y69.315 F152
G1 X68.509 Y69.372 F152
G1 X68.506 Y69.377 F152
G1 X68.462 Y69.429 F152
G1 X68.448 Y69.445 F152
G1 X68.418 Y69.487 F152
G1 X68.391 Y69.527 F152
G1 X68.379 Y69.544 F152
G1 X68.334 Y69.612 F152
G1 X68.308 Y69.659 F152
G1 X68.281 Y69.716 F152
G1 X68.277 Y69.725 F152
G1 X68.259 Y69.773 F152
G1 X68.242 Y69.831 F152
G1 X68.228 Y69.888 F152
G1 X68.219 Y69.942 F152
G1 Y69.945 F152
G1 X68.214 Y70.002 F152
G1 X68.21 Y70.06 F152
G1 Y70.117 F152
G1 X68.211 Y70.174 F152
G1 X68.216 Y70.232 F152
G1 X68.219 Y70.287 F152
G1 X68.22 Y70.289 F152
G1 X68.234 Y70.404 F152
G1 X68.243 Y70.461 F152
G1 X68.253 Y70.518 F152
G1 X68.264 Y70.575 F152
G1 X68.277 Y70.637 F152
G1 X68.301 Y70.747 F152
G1 X68.315 Y70.805 F152
G1 X68.33 Y70.862 F152
G1 X68.334 Y70.879 F152
G1 X68.36 Y70.976 F152
G1 X68.376 Y71.034 F152
G1 X68.391 Y71.087 F152
G1 X68.392 Y71.091 F152
G1 X68.443 Y71.263 F152
G1 X68.448 Y71.282 F152
G1 X68.461 Y71.32 F152
G1 X68.478 Y71.378 F152
G1 X68.496 Y71.435 F152
G1 X68.506 Y71.468 F152
G1 X68.514 Y71.492 F152
G1 X68.533 Y71.549 F152
G1 X68.55 Y71.607 F152
G1 X68.563 Y71.646 F152
G1 X68.569 Y71.664 F152
G1 X68.587 Y71.721 F152
G1 X68.606 Y71.779 F152
G1 X68.62 Y71.822 F152
G1 X68.626 Y71.836 F152
G1 X68.663 Y71.951 F152
G1 X68.677 Y71.993 F152
G1 X68.683 Y72.008 F152
G1 X68.702 Y72.065 F152
G1 X68.721 Y72.122 F152
G1 X68.735 Y72.161 F152
G1 X68.742 Y72.18 F152
G1 X68.781 Y72.294 F152
G1 X68.792 Y72.327 F152
G1 X68.801 Y72.352 F152
G1 X68.84 Y72.466 F152
G1 X68.849 Y72.493 F152
G1 X68.86 Y72.523 F152
G1 X68.899 Y72.638 F152
G1 X68.907 Y72.659 F152
G1 X68.92 Y72.695 F152
G1 X68.94 Y72.753 F152
G1 X68.96 Y72.81 F152
G1 X68.964 Y72.821 F152
G1 X68.981 Y72.867 F152
G1 X69.001 Y72.925 F152
G1 X69.062 Y73.096 F152
G1 X69.078 Y73.142 F152
G1 X69.083 Y73.154 F152
G1 X69.124 Y73.268 F152
G1 X69.136 Y73.301 F152
G1 X69.145 Y73.326 F152
G1 X69.165 Y73.383 F152
G1 X69.187 Y73.44 F152
G1 X69.193 Y73.459 F152
G1 X69.207 Y73.498 F152
G1 X69.249 Y73.612 F152
G1 X69.25 Y73.617 F152
G1 X69.27 Y73.669 F152
G1 X69.311 Y73.784 F152
G1 X69.333 Y73.841 F152
G1 X69.365 Y73.931 F152
G1 X69.375 Y73.956 F152
G1 X69.395 Y74.013 F152
G1 X69.417 Y74.071 F152
G1 X69.422 Y74.087 F152
G1 X69.437 Y74.128 F152
G1 X69.459 Y74.185 F152
G1 X69.479 Y74.242 F152
G1 X69.522 Y74.357 F152
G1 X69.537 Y74.395 F152
G1 X69.544 Y74.414 F152
G1 X69.587 Y74.529 F152
G1 X69.594 Y74.548 F152
G1 X69.608 Y74.586 F152
G1 X69.631 Y74.643 F152
G1 X69.651 Y74.7 F152
G1 X69.652 Y74.701 F152
G1 X69.674 Y74.758 F152
G1 X69.696 Y74.815 F152
G1 X69.709 Y74.848 F152
G1 X69.718 Y74.873 F152
G1 X69.74 Y74.93 F152
G1 X69.762 Y74.987 F152
G1 X69.766 Y74.997 F152
G1 X69.785 Y75.045 F152
G1 X69.806 Y75.102 F152
G1 X69.823 Y75.145 F152
G1 X69.829 Y75.159 F152
G1 X69.852 Y75.216 F152
G1 X69.875 Y75.274 F152
G1 X69.88 Y75.289 F152
G1 X69.897 Y75.331 F152
G1 X69.92 Y75.388 F152
G1 X69.938 Y75.433 F152
G1 X69.943 Y75.446 F152
G1 X69.99 Y75.56 F152
G1 X69.995 Y75.574 F152
G1 X70.013 Y75.618 F152
G1 X70.037 Y75.675 F152
G1 X70.052 Y75.713 F152
G1 X70.06 Y75.732 F152
G1 X70.084 Y75.789 F152
G1 X70.108 Y75.847 F152
G1 X70.109 Y75.852 F152
G1 X70.132 Y75.904 F152
G1 X70.156 Y75.961 F152
G1 X70.167 Y75.986 F152
G1 X70.181 Y76.019 F152
G1 X70.205 Y76.076 F152
G1 X70.224 Y76.122 F152
G1 X70.229 Y76.133 F152
G1 X70.254 Y76.19 F152
G1 X70.28 Y76.248 F152
G1 X70.281 Y76.25 F152
G1 X70.306 Y76.305 F152
G1 X70.332 Y76.362 F152
G1 X70.339 Y76.378 F152
G1 X70.358 Y76.42 F152
G1 X70.383 Y76.477 F152
G1 X70.453 Y76.631 F152
G1 X70.487 Y76.706 F152
G1 X70.51 Y76.758 F152
G1 X70.513 Y76.763 F152
G1 X70.539 Y76.821 F152
G1 X70.567 Y76.878 F152
G1 X70.568 Y76.881 F152
G1 X70.595 Y76.935 F152
G1 X70.623 Y76.993 F152
G1 X70.625 Y76.997 F152
G1 X70.651 Y77.05 F152
G1 X70.68 Y77.107 F152
G1 X70.682 Y77.114 F152
G1 X70.707 Y77.165 F152
G1 X70.735 Y77.222 F152
G1 X70.764 Y77.279 F152
G1 X70.791 Y77.336 F152
G1 X70.797 Y77.348 F152
G1 X70.819 Y77.394 F152
G1 X70.848 Y77.451 F152
G1 X70.854 Y77.464 F152
G1 X70.878 Y77.508 F152
G1 X70.908 Y77.566 F152
G1 X70.911 Y77.572 F152
G1 X70.938 Y77.623 F152
G1 X70.999 Y77.738 F152
G1 X71.026 Y77.788 F152
G1 X71.03 Y77.795 F152
G1 X71.121 Y77.967 F152
G1 X71.14 Y78.003 F152
G1 X71.151 Y78.024 F152
G1 X71.182 Y78.081 F152
G1 X71.246 Y78.196 F152
G1 X71.255 Y78.213 F152
G1 X71.278 Y78.253 F152
G1 X71.311 Y78.31 F152
G1 X71.312 Y78.315 F152
G1 X71.342 Y78.368 F152
G1 X71.37 Y78.416 F152
G1 X71.375 Y78.425 F152
G1 X71.408 Y78.482 F152
G1 X71.427 Y78.515 F152
G1 X71.441 Y78.54 F152
G1 X71.474 Y78.597 F152
G1 X71.484 Y78.615 F152
G1 X71.507 Y78.654 F152
G1 X71.541 Y78.712 F152
G1 Y78.713 F152
G1 X71.575 Y78.769 F152
G1 X71.599 Y78.81 F152
G1 X71.609 Y78.826 F152
G1 X71.643 Y78.883 F152
G1 X71.656 Y78.907 F152
G1 X71.677 Y78.941 F152
G1 X71.745 Y79.055 F152
G1 X71.771 Y79.098 F152
G1 X71.78 Y79.113 F152
G1 X71.814 Y79.17 F152
G1 X71.828 Y79.191 F152
G1 X71.849 Y79.227 F152
G1 X71.884 Y79.285 F152
G1 X71.885 F152
G1 X71.92 Y79.342 F152
G1 X71.942 Y79.379 F152
G1 X71.955 Y79.399 F152
G1 X72 Y79.473 F152
G1 X72.026 Y79.514 F152
G1 X72.097 Y79.628 F152
G1 X72.114 Y79.656 F152
G1 X72.133 Y79.686 F152
G1 X72.169 Y79.743 F152
G1 X72.172 Y79.747 F152
G1 X72.229 Y79.839 F152
G1 X72.241 Y79.857 F152
G1 X72.277 Y79.915 F152
G1 X72.286 Y79.928 F152
G1 X72.343 Y80.019 F152
G1 X72.351 Y80.029 F152
G1 X72.387 Y80.087 F152
G1 X72.401 Y80.109 F152
G1 X72.423 Y80.144 F152
G1 X72.458 Y80.198 F152
G1 X72.46 Y80.201 F152
G1 X72.497 Y80.259 F152
G1 X72.515 Y80.286 F152
G1 X72.535 Y80.316 F152
G1 X72.572 Y80.373 F152
G1 Y80.374 F152
G1 X72.609 Y80.43 F152
G1 X72.684 Y80.545 F152
G1 X72.687 Y80.55 F152
G1 X72.722 Y80.602 F152
G1 X72.759 Y80.66 F152
G1 X72.796 Y80.717 F152
G1 X72.802 Y80.725 F152
G1 X72.834 Y80.774 F152
G1 X72.859 Y80.814 F152
G1 X72.871 Y80.832 F152
G1 X72.916 Y80.901 F152
G1 X72.946 Y80.946 F152
G1 X72.973 Y80.989 F152
G1 X72.983 Y81.003 F152
G1 X73.02 Y81.061 F152
G1 X73.031 Y81.077 F152
G1 X73.088 Y81.165 F152
G1 X73.095 Y81.175 F152
G1 X73.133 Y81.233 F152
G1 X73.145 Y81.252 F152
G1 X73.169 Y81.29 F152
G1 X73.203 Y81.34 F152
G1 X73.207 Y81.347 F152
G1 X73.245 Y81.405 F152
G1 X73.26 Y81.429 F152
G1 X73.282 Y81.462 F152
G1 X73.317 Y81.516 F152
G1 X73.356 Y81.576 F152
G1 X73.374 Y81.604 F152
G1 X73.394 Y81.634 F152
G1 X73.431 Y81.691 F152
G1 X73.432 Y81.692 F152
G1 X73.468 Y81.748 F152
G1 X73.506 Y81.806 F152
G1 X73.543 Y81.863 F152
G1 X73.546 Y81.868 F152
G1 X73.579 Y81.92 F152
G1 X73.603 Y81.958 F152
G1 X73.617 Y81.977 F152
G1 X73.654 Y82.035 F152
G1 X73.661 Y82.046 F152
G1 X73.718 Y82.135 F152
G1 X73.727 Y82.149 F152
G1 X73.765 Y82.207 F152
G1 X73.775 Y82.224 F152
G1 X73.801 Y82.264 F152
G1 X73.833 Y82.313 F152
G1 X73.838 Y82.321 F152
G1 X73.876 Y82.379 F152
G1 X73.89 Y82.402 F152
G1 X73.912 Y82.436 F152
G1 X73.947 Y82.49 F152
G1 X73.949 Y82.493 F152
G1 X73.986 Y82.55 F152
G1 X74.023 Y82.608 F152
G1 X74.06 Y82.665 F152
G1 X74.062 Y82.669 F152
G1 X74.097 Y82.722 F152
G1 X74.133 Y82.78 F152
G1 X74.171 Y82.837 F152
G1 X74.176 Y82.846 F152
G1 X74.207 Y82.894 F152
G1 X74.234 Y82.938 F152
G1 X74.243 Y82.952 F152
G1 X74.277 Y83.009 F152
G1 X74.313 Y83.066 F152
G1 X74.348 Y83.123 F152
G1 X74.349 F152
G1 X74.385 Y83.181 F152
G1 X74.405 Y83.215 F152
G1 X74.421 Y83.238 F152
G1 X74.456 Y83.295 F152
G1 X74.463 Y83.306 F152
G1 X74.52 Y83.399 F152
G1 X74.527 Y83.41 F152
G1 X74.561 Y83.467 F152
G1 X74.577 Y83.495 F152
G1 X74.595 Y83.524 F152
G1 X74.63 Y83.582 F152
G1 X74.635 Y83.59 F152
G1 X74.664 Y83.639 F152
G1 X74.692 Y83.686 F152
G1 X74.698 Y83.696 F152
G1 X74.733 Y83.754 F152
G1 X74.749 Y83.781 F152
G1 X74.767 Y83.811 F152
G1 X74.835 Y83.926 F152
G1 X74.864 Y83.975 F152
G1 X74.921 Y84.077 F152
G1 X74.965 Y84.155 F152
G1 X74.978 Y84.179 F152
G1 X74.997 Y84.212 F152
G1 X75.029 Y84.269 F152
G1 X75.035 Y84.281 F152
G1 X75.061 Y84.327 F152
G1 X75.093 Y84.383 F152
G1 X75.094 Y84.384 F152
G1 X75.125 Y84.441 F152
G1 X75.15 Y84.485 F152
G1 X75.157 Y84.499 F152
G1 X75.189 Y84.556 F152
G1 X75.207 Y84.588 F152
G1 X75.222 Y84.613 F152
G1 X75.254 Y84.67 F152
G1 X75.265 Y84.69 F152
G1 X75.286 Y84.728 F152
G1 X75.318 Y84.785 F152
G1 X75.322 Y84.792 F152
G1 X75.349 Y84.842 F152
G1 X75.379 Y84.901 F152
G1 X75.409 Y84.957 F152
G1 X75.436 Y85.012 F152
G1 X75.438 Y85.014 F152
G1 X75.468 Y85.072 F152
G1 X75.494 Y85.122 F152
G1 X75.498 Y85.129 F152
G1 X75.528 Y85.186 F152
G1 X75.551 Y85.231 F152
G1 X75.586 Y85.301 F152
G1 X75.608 Y85.347 F152
G1 X75.642 Y85.415 F152
G1 X75.666 Y85.464 F152
G1 X75.67 Y85.473 F152
G1 X75.698 Y85.53 F152
G1 X75.723 Y85.581 F152
G1 X75.726 Y85.587 F152
G1 X75.782 Y85.702 F152
G1 X75.809 Y85.759 F152
G1 X75.835 Y85.816 F152
G1 X75.837 Y85.823 F152
G1 X75.861 Y85.874 F152
G1 X75.887 Y85.931 F152
G1 X75.895 Y85.947 F152
G1 X75.913 Y85.988 F152
G1 X75.94 Y86.046 F152
G1 X75.952 Y86.072 F152
G1 X75.966 Y86.103 F152
G1 X75.991 Y86.16 F152
G1 X76.009 Y86.202 F152
G1 X76.016 Y86.217 F152
G1 X76.065 Y86.332 F152
G1 X76.066 Y86.337 F152
G1 X76.09 Y86.389 F152
G1 X76.114 Y86.447 F152
G1 X76.124 Y86.471 F152
G1 X76.138 Y86.504 F152
G1 X76.163 Y86.561 F152
G1 X76.181 Y86.607 F152
G1 X76.186 Y86.619 F152
G1 X76.208 Y86.676 F152
G1 X76.231 Y86.733 F152
G1 X76.238 Y86.753 F152
G1 X76.254 Y86.79 F152
G1 X76.276 Y86.848 F152
G1 X76.296 Y86.899 F152
G1 X76.298 Y86.905 F152
G1 X76.343 Y87.02 F152
G1 X76.353 Y87.046 F152
G1 X76.365 Y87.077 F152
G1 X76.385 Y87.134 F152
G1 X76.405 Y87.192 F152
G1 X76.41 Y87.207 F152
G1 X76.425 Y87.249 F152
G1 X76.467 Y87.363 F152
G1 Y87.367 F152
G1 X76.487 Y87.421 F152
G1 X76.508 Y87.478 F152
G1 X76.564 Y87.65 F152
G1 X76.582 Y87.707 F152
G1 X76.62 Y87.822 F152
G1 X76.637 Y87.879 F152
G1 X76.639 Y87.885 F152
G1 X76.656 Y87.936 F152
G1 X76.672 Y87.994 F152
G1 X76.689 Y88.051 F152
G1 X76.697 Y88.077 F152
G1 X76.706 Y88.108 F152
G1 X76.723 Y88.166 F152
G1 X76.739 Y88.223 F152
G1 X76.754 Y88.276 F152
G1 X76.756 Y88.28 F152
G1 X76.772 Y88.337 F152
G1 X76.789 Y88.395 F152
G1 X76.803 Y88.452 F152
G1 X76.811 Y88.485 F152
G1 X76.817 Y88.509 F152
G1 X76.832 Y88.567 F152
G1 X76.847 Y88.624 F152
G1 X76.861 Y88.681 F152
G1 X76.868 Y88.711 F152
G1 X76.876 Y88.739 F152
G1 X76.891 Y88.796 F152
G1 X76.905 Y88.853 F152
G1 X76.918 Y88.91 F152
G1 X76.926 Y88.95 F152
G1 X76.93 Y88.968 F152
G1 X76.98 Y89.197 F152
G1 X76.983 Y89.21 F152
G1 X76.993 Y89.254 F152
G1 X77.005 Y89.311 F152
G1 X77.038 Y89.483 F152
G1 X77.04 Y89.499 F152
G1 X77.048 Y89.541 F152
G1 X77.081 Y89.713 F152
G1 X77.09 Y89.77 F152
G1 X77.098 Y89.819 F152
G1 X77.099 Y89.827 F152
G1 X77.153 Y90.171 F152
G1 X77.155 Y90.188 F152
G1 X77.16 Y90.228 F152
G1 X77.166 Y90.286 F152
G1 X77.174 Y90.343 F152
G1 X77.18 Y90.4 F152
G1 X77.187 Y90.457 F152
G1 X77.193 Y90.515 F152
G1 X77.2 Y90.572 F152
G1 X77.212 Y90.678 F152
G1 X77.214 Y90.687 F152
G1 X77.22 Y90.744 F152
G1 X77.227 Y90.801 F152
G1 X77.234 Y90.859 F152
G1 X77.241 Y90.916 F152
G1 X77.253 Y91.03 F152
G1 X77.267 Y91.202 F152
G1 X77.269 Y91.246 F152
G1 X77.271 Y91.26 F152
G1 X77.275 Y91.317 F152
G1 X77.288 Y91.489 F152
G1 X77.292 Y91.546 F152
G1 X77.301 Y91.661 F152
G1 X77.304 Y91.718 F152
G1 X77.309 Y91.775 F152
G1 X77.312 Y91.833 F152
G1 X77.315 Y91.89 F152
G1 X77.317 Y91.947 F152
G1 X77.319 Y92.004 F152
G1 X77.321 Y92.062 F152
G1 X77.327 Y92.176 F152
G1 Y92.192 F152
G1 X77.328 Y92.234 F152
G1 X77.334 Y92.348 F152
G1 X77.336 Y92.406 F152
G1 X77.341 Y92.52 F152
G1 X77.343 Y92.577 F152
G1 X77.347 Y92.864 F152
G1 X77.349 Y92.921 F152
G1 X77.353 Y93.208 F152
G1 Y93.609 F152
G1 X77.354 Y93.666 F152
G1 Y93.838 F152
G1 X77.353 Y93.953 F152
G1 Y94.01 F152
G1 X77.35 Y94.182 F152
G1 X77.348 Y94.239 F152
G1 X77.347 Y94.296 F152
G1 X77.342 Y94.468 F152
G1 X77.336 Y94.583 F152
G1 X77.333 Y94.64 F152
G1 X77.328 Y94.755 F152
G1 X77.327 Y94.758 F152
G1 X77.323 Y94.812 F152
G1 X77.319 Y94.869 F152
G1 X77.313 Y94.927 F152
G1 X77.309 Y94.984 F152
G1 X77.303 Y95.041 F152
G1 X77.289 Y95.156 F152
G1 X77.283 Y95.213 F152
G1 X77.276 Y95.27 F152
G1 X77.268 Y95.328 F152
G1 X77.238 Y95.5 F152
G1 X77.229 Y95.557 F152
G1 X77.217 Y95.614 F152
G1 X77.212 Y95.636 F152
G1 X77.205 Y95.671 F152
G1 X77.191 Y95.729 F152
G1 X77.179 Y95.786 F152
G1 X77.166 Y95.843 F152
G1 X77.155 Y95.885 F152
G1 X77.151 Y95.901 F152
G1 X77.103 Y96.073 F152
G1 X77.098 Y96.091 F152
G1 X77.087 Y96.13 F152
G1 X77.069 Y96.187 F152
G1 X77.05 Y96.244 F152
G1 X77.04 Y96.273 F152
G1 X77.031 Y96.302 F152
G1 X77.012 Y96.359 F152
G1 X76.993 Y96.416 F152
G1 X76.983 Y96.443 F152
G1 X76.972 Y96.474 F152
G1 X76.931 Y96.588 F152
G1 X76.926 Y96.602 F152
G1 X76.91 Y96.646 F152
G1 X76.888 Y96.703 F152
G1 X76.868 Y96.756 F152
G1 Y96.76 F152
G1 X76.825 Y96.875 F152
G1 X76.811 Y96.909 F152
G1 X76.803 Y96.932 F152
G1 X76.76 Y97.047 F152
G1 X76.754 Y97.063 F152
G1 X76.74 Y97.104 F152
G1 X76.721 Y97.161 F152
G1 X76.702 Y97.218 F152
G1 X76.697 Y97.235 F152
G1 X76.671 Y97.333 F152
G1 X76.657 Y97.39 F152
G1 X76.647 Y97.448 F152
G1 X76.642 Y97.505 F152
G1 X76.641 Y97.562 F152
G1 X76.648 Y97.62 F152
G1 X76.662 Y97.677 F152
G1 X76.68 Y97.734 F152
G1 X76.697 Y97.776 F152
G1 X76.703 Y97.791 F152
G1 X76.726 Y97.849 F152
G1 X76.752 Y97.906 F152
G1 X76.754 Y97.911 F152
G1 X76.778 Y97.963 F152
G1 X76.804 Y98.021 F152
G1 X76.811 Y98.037 F152
G1 X76.83 Y98.078 F152
G1 X76.857 Y98.135 F152
G1 X76.868 Y98.162 F152
G1 X76.883 Y98.193 F152
G1 X76.907 Y98.25 F152
G1 X76.926 Y98.296 F152
G1 X76.954 Y98.364 F152
G1 X76.978 Y98.422 F152
G1 X76.983 Y98.438 F152
G1 X76.997 Y98.479 F152
G1 X77.037 Y98.594 F152
G1 X77.04 Y98.606 F152
G1 X77.055 Y98.651 F152
G1 X77.073 Y98.708 F152
G1 X77.089 Y98.765 F152
G1 X77.098 Y98.803 F152
G1 X77.103 Y98.823 F152
G1 X77.118 Y98.88 F152
G1 X77.132 Y98.937 F152
G1 X77.153 Y99.052 F152
G1 X77.155 Y99.065 F152
G1 X77.164 Y99.109 F152
G1 X77.174 Y99.167 F152
G1 X77.188 Y99.281 F152
G1 X77.194 Y99.338 F152
G1 X77.201 Y99.396 F152
G1 X77.207 Y99.453 F152
G1 X77.209 Y99.51 F152
G1 X77.212 Y99.563 F152
G1 X77.213 Y99.568 F152
G1 X77.216 Y99.625 F152
G1 X77.219 Y99.682 F152
G1 X77.22 Y99.74 F152
G1 X77.219 Y99.797 F152
G1 Y99.854 F152
G1 X77.217 Y100.026 F152
G1 Y100.083 F152
G1 X77.216 Y100.141 F152
G1 X77.213 Y100.198 F152
G1 X77.212 Y100.204 F152
G1 X77.208 Y100.255 F152
G1 X77.203 Y100.313 F152
G1 X77.19 Y100.484 F152
G1 X77.184 Y100.542 F152
G1 X77.18 Y100.599 F152
G1 X77.174 Y100.656 F152
G1 X77.166 Y100.714 F152
G1 X77.158 Y100.771 F152
G1 X77.155 Y100.793 F152
G1 X77.15 Y100.828 F152
G1 X77.142 Y100.885 F152
G1 X77.123 Y101 F152
G1 X77.098 Y101.133 F152
G1 X77.089 Y101.172 F152
G1 X77.049 Y101.344 F152
G1 X77.035 Y101.401 F152
G1 X76.984 Y101.573 F152
G1 X76.983 Y101.575 F152
G1 X76.966 Y101.63 F152
G1 X76.945 Y101.688 F152
G1 X76.926 Y101.739 F152
G1 X76.924 Y101.745 F152
G1 X76.902 Y101.802 F152
G1 X76.88 Y101.86 F152
G1 X76.868 Y101.889 F152
G1 X76.857 Y101.917 F152
G1 X76.83 Y101.974 F152
G1 X76.811 Y102.012 F152
G1 X76.802 Y102.031 F152
G1 X76.774 Y102.089 F152
G1 X76.754 Y102.13 F152
G1 X76.747 Y102.146 F152
G1 X76.715 Y102.203 F152
G1 X76.697 Y102.235 F152
G1 X76.68 Y102.261 F152
G1 X76.646 Y102.318 F152
G1 X76.639 Y102.329 F152
G1 X76.612 Y102.375 F152
G1 X76.582 Y102.422 F152
G1 X76.575 Y102.432 F152
G1 X76.534 Y102.49 F152
G1 X76.525 Y102.501 F152
G1 X76.491 Y102.547 F152
G1 X76.467 Y102.578 F152
G1 X76.448 Y102.604 F152
G1 X76.41 Y102.654 F152
G1 X76.404 Y102.662 F152
G1 X76.356 Y102.719 F152
G1 X76.353 Y102.722 F152
G1 X76.304 Y102.776 F152
G1 X76.296 Y102.784 F152
G1 X76.251 Y102.834 F152
G1 X76.238 Y102.848 F152
G1 X76.197 Y102.891 F152
G1 X76.181 Y102.907 F152
G1 X76.136 Y102.948 F152
G1 X76.075 Y103.005 F152
G1 X76.066 Y103.013 F152
G1 X76.012 Y103.063 F152
G1 X76.009 Y103.065 F152
G1 X75.942 Y103.12 F152
G1 X75.895 Y103.158 F152
G1 X75.869 Y103.177 F152
G1 X75.837 Y103.202 F152
G1 X75.796 Y103.235 F152
G1 X75.78 Y103.246 F152
G1 X75.723 Y103.287 F152
G1 X75.714 Y103.292 F152
G1 X75.666 Y103.324 F152
G1 X75.629 Y103.349 F152
G1 X75.608 Y103.363 F152
G1 X75.551 Y103.401 F152
G1 X75.542 Y103.407 F152
G1 X75.494 Y103.436 F152
G1 X75.436 Y103.468 F152
G1 X75.379 Y103.501 F152
G1 X75.344 Y103.521 F152
G1 X75.322 Y103.535 F152
G1 X75.265 Y103.565 F152
G1 X75.15 Y103.622 F152
G1 X75.122 Y103.636 F152
G1 X75.093 Y103.651 F152
G1 X75.035 Y103.679 F152
G1 X75.002 Y103.693 F152
G1 X74.978 Y103.704 F152
G1 X74.868 Y103.75 F152
G1 X74.864 Y103.753 F152
G1 X74.806 Y103.777 F152
G1 X74.749 Y103.8 F152
G1 X74.728 Y103.808 F152
G1 X74.692 Y103.822 F152
G1 X74.635 Y103.843 F152
G1 X74.577 Y103.864 F152
G1 X74.575 Y103.865 F152
G1 X74.52 Y103.886 F152
G1 X74.463 Y103.904 F152
G1 X74.405 Y103.921 F152
G1 X74.402 Y103.922 F152
G1 X74.348 Y103.938 F152
G1 X74.291 Y103.956 F152
G1 X74.234 Y103.973 F152
G1 X74.211 Y103.98 F152
G1 X74.176 Y103.99 F152
G1 X74.119 Y104.007 F152
G1 X74.062 Y104.025 F152
G1 X74.021 Y104.037 F152
G1 X74.004 Y104.041 F152
G1 X73.947 Y104.055 F152
G1 X73.89 Y104.067 F152
G1 X73.833 Y104.079 F152
G1 X73.775 Y104.091 F152
G1 X73.761 Y104.094 F152
G1 X73.718 Y104.104 F152
G1 X73.661 Y104.116 F152
G1 X73.546 Y104.141 F152
G1 X73.491 Y104.151 F152
G1 X73.489 Y104.152 F152
G1 X73.374 Y104.168 F152
G1 X73.26 Y104.183 F152
G1 X73.203 Y104.191 F152
G1 X73.088 Y104.205 F152
G1 X73.058 Y104.209 F152
G1 X73.031 Y104.212 F152
G1 X72.973 Y104.216 F152
G1 X72.916 Y104.219 F152
G1 X72.859 Y104.222 F152
G1 X72.687 Y104.23 F152
G1 X72.63 Y104.234 F152
G1 X72.572 Y104.236 F152
G1 X72.515 F152
G1 X72.458 F152
G1 X72.401 F152
G1 X72.229 Y104.23 F152
G1 X72.114 Y104.225 F152
G1 X72 Y104.218 F152
G1 X71.942 Y104.213 F152
G1 X71.885 Y104.21 F152
G1 X71.884 Y104.209 F152
G1 X71.828 Y104.205 F152
G1 X71.656 Y104.189 F152
G1 X71.484 Y104.17 F152
G1 X71.37 Y104.156 F152
G1 X71.341 Y104.151 F152
G1 X71.312 Y104.148 F152
G1 X71.255 Y104.14 F152
G1 X71.198 Y104.131 F152
G1 X71.026 Y104.107 F152
G1 X70.969 Y104.097 F152
G1 X70.955 Y104.094 F152
G1 X70.911 Y104.086 F152
G1 X70.797 Y104.065 F152
G1 X70.74 Y104.053 F152
G1 X70.682 Y104.042 F152
G1 X70.655 Y104.037 F152
G1 X70.625 Y104.031 F152
G1 X70.568 Y104.021 F152
G1 X70.51 Y104.009 F152
G1 X70.396 Y103.98 F152
G1 X70.395 F152
G1 X70.339 Y103.966 F152
G1 X70.281 Y103.951 F152
G1 X70.224 Y103.937 F152
G1 X70.168 Y103.922 F152
G1 X70.167 F152
G1 X70.052 Y103.894 F152
G1 X69.995 Y103.877 F152
G1 X69.96 Y103.865 F152
G1 X69.938 Y103.859 F152
G1 X69.823 Y103.823 F152
G1 X69.777 Y103.808 F152
G1 X69.766 Y103.804 F152
G1 X69.709 Y103.784 F152
G1 X69.651 Y103.764 F152
G1 X69.615 Y103.75 F152
G1 X69.594 Y103.743 F152
G1 X69.537 Y103.722 F152
G1 X69.479 Y103.701 F152
G1 X69.461 Y103.693 F152
G1 X69.422 Y103.677 F152
G1 X69.365 Y103.654 F152
G1 X69.323 Y103.636 F152
G1 X69.308 Y103.629 F152
G1 X69.25 Y103.605 F152
G1 X69.193 Y103.58 F152
G1 X69.189 Y103.578 F152
G1 X69.136 Y103.553 F152
G1 X69.078 Y103.527 F152
G1 X69.067 Y103.521 F152
G1 X68.964 Y103.473 F152
G1 X68.948 Y103.464 F152
G1 X68.907 Y103.442 F152
G1 X68.849 Y103.413 F152
G1 X68.838 Y103.407 F152
G1 X68.792 Y103.383 F152
G1 X68.735 Y103.354 F152
G1 X68.728 Y103.349 F152
G1 X68.677 Y103.321 F152
G1 X68.626 Y103.292 F152
G1 X68.62 Y103.289 F152
G1 X68.563 Y103.256 F152
G1 X68.525 Y103.235 F152
G1 X68.506 Y103.224 F152
G1 X68.448 Y103.19 F152
G1 X68.429 Y103.177 F152
G1 X68.391 Y103.154 F152
G1 X68.337 Y103.12 F152
G1 X68.334 Y103.119 F152
G1 X68.277 Y103.083 F152
G1 X68.243 Y103.063 F152
G1 X68.219 Y103.048 F152
G1 X68.162 Y103.013 F152
G1 X68.151 Y103.005 F152
G1 X68.105 Y102.977 F152
G1 X68.059 Y102.948 F152
G1 X68.047 Y102.941 F152
G1 X67.99 Y102.905 F152
G1 X67.969 Y102.891 F152
G1 X67.933 Y102.868 F152
G1 X67.877 Y102.834 F152
G1 X67.876 Y102.833 F152
G1 X67.818 Y102.796 F152
G1 X67.787 Y102.776 F152
G1 X67.761 Y102.76 F152
G1 X67.704 Y102.723 F152
G1 X67.697 Y102.719 F152
G1 X67.646 Y102.689 F152
G1 X67.6 Y102.662 F152
G1 X67.589 Y102.655 F152
G1 X67.532 Y102.623 F152
G1 X67.498 Y102.604 F152
G1 X67.475 Y102.592 F152
G1 X67.417 Y102.562 F152
G1 X67.385 Y102.547 F152
G1 X67.36 Y102.535 F152
G1 X67.303 Y102.512 F152
G1 X67.246 Y102.492 F152
G1 X67.241 Y102.49 F152
G1 X67.188 Y102.475 F152
G1 X67.131 Y102.466 F152
G1 X67.074 Y102.459 F152
G1 X67.016 Y102.458 F152
G1 X66.959 F152
G1 X66.902 Y102.462 F152
G1 X66.787 Y102.471 F152
G1 X66.73 Y102.475 F152
G1 X66.615 Y102.485 F152
G1 X66.572 Y102.49 F152
G1 X66.558 Y102.492 F152
G1 X66.386 Y102.51 F152
G1 X66.157 Y102.532 F152
G1 X65.985 Y102.545 F152
G1 X65.951 Y102.547 F152
G1 X65.928 Y102.549 F152
G1 X65.814 Y102.556 F152
G1 X65.699 Y102.561 F152
G1 X65.642 Y102.563 F152
G1 X65.584 Y102.566 F152
G1 X65.527 Y102.567 F152
G1 X65.47 Y102.569 F152
G1 X65.413 F152
G1 X65.355 F152
G1 X65.183 F152
G1 X65.069 Y102.568 F152
G1 X65.012 F152
G1 X64.954 Y102.567 F152
G1 X64.897 Y102.565 F152
G1 X64.84 Y102.564 F152
G1 X64.783 Y102.562 F152
G1 X64.725 Y102.561 F152
G1 X64.439 Y102.552 F152
G1 X64.324 Y102.547 F152
G1 X64.267 Y102.545 F152
G1 X64.038 Y102.535 F152
G1 X63.981 Y102.531 F152
G1 X63.923 Y102.528 F152
G1 X63.866 Y102.525 F152
G1 X63.809 Y102.52 F152
G1 X63.465 Y102.499 F152
G1 X63.408 Y102.494 F152
G1 X63.362 Y102.49 F152
G1 X63.293 Y102.484 F152
G1 X63.236 Y102.479 F152
G1 X63.179 Y102.475 F152
G1 X63.064 Y102.464 F152
G1 X63.007 Y102.459 F152
G1 X62.95 Y102.454 F152
G1 X62.892 Y102.45 F152
G1 X62.835 Y102.443 F152
G1 X62.778 Y102.436 F152
G1 X62.746 Y102.432 F152
G1 X62.491 Y102.405 F152
G1 X62.434 Y102.398 F152
G1 X62.32 Y102.381 F152
G1 X62.276 Y102.375 F152
G1 X62.262 Y102.373 F152
G1 X62.205 Y102.366 F152
G1 X62.033 Y102.342 F152
G1 X61.919 Y102.322 F152
G1 X61.894 Y102.318 F152
G1 X61.861 Y102.313 F152
G1 X61.689 Y102.283 F152
G1 X61.632 Y102.272 F152
G1 X61.575 Y102.262 F152
G1 X61.569 Y102.261 F152
G1 X61.518 Y102.25 F152
G1 X61.403 Y102.225 F152
G1 X61.346 Y102.211 F152
G1 X61.174 Y102.174 F152
G1 X61.117 Y102.159 F152
G1 X61.072 Y102.146 F152
G1 X61.059 Y102.143 F152
G1 X61.002 Y102.127 F152
G1 X60.945 Y102.112 F152
G1 X60.871 Y102.089 F152
G1 X60.716 Y102.04 F152
G1 X60.692 Y102.031 F152
G1 X60.658 Y102.019 F152
G1 X60.544 Y101.978 F152
G1 X60.536 Y101.974 F152
G1 X60.487 Y101.956 F152
G1 X60.429 Y101.936 F152
G1 X60.372 Y101.914 F152
G1 X60.315 Y101.892 F152
G1 X60.257 Y101.867 F152
G1 X60.241 Y101.86 F152
G1 X60.2 Y101.842 F152
G1 X60.143 Y101.816 F152
G1 X60.112 Y101.802 F152
G1 X60.086 Y101.791 F152
G1 X60.028 Y101.766 F152
G1 X59.983 Y101.745 F152
G1 X59.971 Y101.74 F152
G1 X59.914 Y101.713 F152
G1 X59.865 Y101.688 F152
G1 X59.857 Y101.683 F152
G1 X59.799 Y101.654 F152
G1 X59.755 Y101.63 F152
G1 X59.742 Y101.624 F152
G1 X59.685 Y101.595 F152
G1 X59.643 Y101.573 F152
G1 X59.627 Y101.565 F152
G1 X59.57 Y101.535 F152
G1 X59.513 Y101.503 F152
G1 X59.456 Y101.47 F152
G1 X59.436 Y101.458 F152
G1 X59.398 Y101.437 F152
G1 X59.341 Y101.404 F152
G1 X59.337 Y101.401 F152
G1 X59.237 Y101.344 F152
G1 X59.226 Y101.338 F152
G1 X59.169 Y101.303 F152
G1 X59.143 Y101.287 F152
G1 X59.112 Y101.267 F152
G1 X59.055 Y101.231 F152
G1 X59.051 Y101.229 F152
G1 X58.997 Y101.196 F152
G1 X58.96 Y101.172 F152
G1 X58.94 Y101.16 F152
G1 X58.883 Y101.125 F152
G1 X58.868 Y101.115 F152
G1 X58.826 Y101.088 F152
G1 X58.779 Y101.057 F152
G1 X58.768 Y101.05 F152
G1 X58.711 Y101.013 F152
G1 X58.692 Y101 F152
G1 X58.654 Y100.975 F152
G1 X58.604 Y100.943 F152
G1 X58.596 Y100.937 F152
G1 X58.539 Y100.9 F152
G1 X58.518 Y100.885 F152
G1 X58.482 Y100.862 F152
G1 X58.432 Y100.828 F152
G1 X58.425 Y100.824 F152
G1 X58.367 Y100.784 F152
G1 X58.348 Y100.771 F152
G1 X58.31 Y100.746 F152
G1 X58.263 Y100.714 F152
G1 X58.195 Y100.668 F152
G1 X58.138 Y100.629 F152
G1 X58.094 Y100.599 F152
G1 X58.081 Y100.59 F152
G1 X58.024 Y100.55 F152
G1 X57.966 Y100.51 F152
G1 X57.929 Y100.484 F152
G1 X57.909 Y100.471 F152
G1 X57.852 Y100.431 F152
G1 X57.846 Y100.427 F152
G1 X57.794 Y100.391 F152
G1 X57.764 Y100.37 F152
G1 X57.737 Y100.351 F152
G1 X57.682 Y100.313 F152
G1 X57.68 Y100.312 F152
G1 X57.623 Y100.271 F152
G1 X57.565 Y100.23 F152
G1 X57.519 Y100.198 F152
G1 X57.508 Y100.19 F152
G1 X57.451 Y100.15 F152
G1 X57.438 Y100.141 F152
G1 X57.394 Y100.109 F152
G1 X57.357 Y100.083 F152
G1 X57.336 Y100.069 F152
G1 X57.279 Y100.029 F152
G1 X57.275 Y100.026 F152
G1 X57.222 Y99.988 F152
G1 X57.196 Y99.969 F152
G1 X57.164 Y99.946 F152
G1 X57.116 Y99.911 F152
G1 X57.107 Y99.905 F152
G1 X57.05 Y99.864 F152
G1 X57.036 Y99.854 F152
G1 X56.993 Y99.823 F152
G1 X56.956 Y99.797 F152
G1 X56.935 Y99.782 F152
G1 X56.878 Y99.741 F152
G1 X56.876 Y99.74 F152
G1 X56.821 Y99.7 F152
G1 X56.797 Y99.682 F152
G1 X56.763 Y99.659 F152
G1 X56.717 Y99.625 F152
G1 X56.706 Y99.618 F152
G1 X56.42 Y99.412 F152
G1 X56.398 Y99.396 F152
G1 X56.363 Y99.37 F152
G1 X56.319 Y99.338 F152
G1 X56.305 Y99.329 F152
G1 X56.248 Y99.287 F152
G1 X56.24 Y99.281 F152
G1 X56.161 Y99.224 F152
G1 X56.133 Y99.204 F152
G1 X56.082 Y99.167 F152
G1 X56.019 Y99.121 F152
G1 X56.004 Y99.109 F152
G1 X55.962 Y99.079 F152
G1 X55.925 Y99.052 F152
G1 X55.904 Y99.037 F152
G1 X55.847 Y98.996 F152
G1 X55.846 Y98.995 F152
G1 X55.79 Y98.953 F152
G1 X55.732 Y98.912 F152
G1 X55.618 Y98.828 F152
G1 X55.611 Y98.823 F152
G1 X55.561 Y98.786 F152
G1 X55.503 Y98.745 F152
G1 X55.454 Y98.708 F152
G1 X55.446 Y98.703 F152
G1 X55.331 Y98.619 F152
G1 X55.297 Y98.594 F152
G1 X55.274 Y98.577 F152
G1 X55.219 Y98.536 F152
G1 X55.217 Y98.535 F152
G1 X55.16 Y98.493 F152
G1 X55.141 Y98.479 F152
G1 X55.102 Y98.451 F152
G1 X54.931 Y98.325 F152
G1 X54.905 Y98.307 F152
G1 X54.873 Y98.284 F152
G1 X54.828 Y98.25 F152
G1 X54.816 Y98.242 F152
G1 X54.749 Y98.193 F152
G1 X54.644 Y98.116 F152
G1 X54.592 Y98.078 F152
G1 X54.587 Y98.074 F152
G1 X54.53 Y98.032 F152
G1 X54.514 Y98.021 F152
G1 X54.472 Y97.99 F152
G1 X54.436 Y97.963 F152
G1 X54.415 Y97.948 F152
G1 X54.358 Y97.907 F152
G1 X54.357 Y97.906 F152
G1 X54.3 Y97.865 F152
G1 X54.243 Y97.824 F152
G1 X54.186 Y97.782 F152
G1 X54.129 Y97.74 F152
G1 X54.121 Y97.734 F152
G1 X54.071 Y97.699 F152
G1 X54.014 Y97.657 F152
G1 X53.961 Y97.62 F152
G1 X53.957 Y97.616 F152
G1 X53.9 Y97.576 F152
G1 X53.882 Y97.562 F152
G1 X53.842 Y97.534 F152
G1 X53.785 Y97.493 F152
G1 X53.728 Y97.453 F152
G1 X53.721 Y97.448 F152
G1 X53.638 Y97.39 F152
G1 X53.613 Y97.372 F152
G1 X53.557 Y97.333 F152
G1 X53.556 F152
G1 X53.473 Y97.276 F152
G1 X53.441 Y97.255 F152
G1 X53.388 Y97.218 F152
G1 X53.384 Y97.216 F152
G1 X53.327 Y97.177 F152
G1 X53.303 Y97.161 F152
G1 X53.269 Y97.139 F152
G1 X53.218 Y97.104 F152
G1 X53.212 Y97.099 F152
G1 X53.155 Y97.062 F152
G1 X53.131 Y97.047 F152
G1 X53.098 Y97.025 F152
G1 X53.041 Y96.989 F152
G1 X53.04 Y96.988 F152
G1 X52.983 Y96.953 F152
G1 X52.952 Y96.932 F152
G1 X52.926 Y96.916 F152
G1 X52.868 Y96.879 F152
G1 X52.862 Y96.875 F152
G1 X52.811 Y96.842 F152
G1 X52.771 Y96.817 F152
G1 X52.754 Y96.808 F152
G1 X52.697 Y96.774 F152
G1 X52.674 Y96.76 F152
G1 X52.639 Y96.74 F152
G1 X52.525 Y96.671 F152
G1 X52.48 Y96.646 F152
G1 X52.468 Y96.638 F152
G1 X52.41 Y96.604 F152
G1 X52.383 Y96.588 F152
G1 X52.353 Y96.573 F152
G1 X52.276 Y96.531 F152
G1 X52.238 Y96.511 F152
G1 X52.181 Y96.48 F152
G1 X52.17 Y96.474 F152
G1 X52.067 Y96.419 F152
G1 X52.063 Y96.416 F152
G1 X52.009 Y96.388 F152
G1 X51.952 Y96.359 F152
G1 X51.837 Y96.304 F152
G1 X51.833 Y96.302 F152
G1 X51.78 Y96.277 F152
G1 X51.723 Y96.249 F152
G1 X51.715 Y96.244 F152
G1 X51.666 Y96.221 F152
G1 X51.608 Y96.193 F152
G1 X51.597 Y96.187 F152
G1 X51.551 Y96.167 F152
G1 X51.494 Y96.142 F152
G1 X51.466 Y96.13 F152
G1 X51.437 Y96.117 F152
G1 X51.379 Y96.092 F152
G1 X51.334 Y96.073 F152
G1 X51.322 Y96.068 F152
G1 X51.201 Y96.015 F152
G1 X51.15 Y95.994 F152
G1 X51.093 Y95.971 F152
G1 X51.059 Y95.958 F152
G1 X51.036 Y95.949 F152
G1 X50.978 Y95.927 F152
G1 X50.921 Y95.905 F152
G1 X50.91 Y95.901 F152
G1 X50.864 Y95.883 F152
G1 X50.806 Y95.86 F152
G1 X50.763 Y95.843 F152
G1 X50.749 Y95.839 F152
G1 X50.692 Y95.816 F152
G1 X50.635 Y95.796 F152
G1 X50.607 Y95.786 F152
G1 X50.577 Y95.776 F152
G1 X50.52 Y95.756 F152
G1 X50.463 Y95.736 F152
G1 X50.443 Y95.729 F152
G1 X50.406 Y95.716 F152
G1 X50.348 Y95.696 F152
G1 X50.291 Y95.676 F152
G1 X50.278 Y95.671 F152
G1 X50.234 Y95.656 F152
G1 X50.176 Y95.637 F152
G1 X50.119 Y95.619 F152
G1 X50.107 Y95.614 F152
G1 X50.062 Y95.6 F152
G1 X49.947 Y95.562 F152
G1 X49.93 Y95.557 F152
G1 X49.833 Y95.526 F152
G1 X49.775 Y95.509 F152
G1 X49.746 Y95.5 F152
G1 X49.718 Y95.492 F152
G1 X49.661 Y95.474 F152
G1 X49.604 Y95.457 F152
G1 X49.557 Y95.442 F152
G1 X49.546 Y95.44 F152
G1 X49.489 Y95.422 F152
G1 X49.432 Y95.406 F152
G1 X49.374 Y95.389 F152
G1 X49.364 Y95.385 F152
G1 X49.317 Y95.372 F152
G1 X49.26 Y95.355 F152
G1 X49.203 Y95.338 F152
G1 X49.165 Y95.328 F152
G1 X49.145 Y95.322 F152
G1 X48.974 Y95.274 F152
G1 X48.963 Y95.27 F152
G1 X48.916 Y95.258 F152
G1 X48.757 Y95.213 F152
G1 X48.744 Y95.209 F152
G1 X48.687 Y95.194 F152
G1 X48.63 Y95.178 F152
G1 X48.573 Y95.163 F152
G1 X48.548 Y95.156 F152
G1 X48.515 Y95.147 F152
G1 X48.458 Y95.132 F152
G1 X48.401 Y95.115 F152
G1 X48.343 Y95.1 F152
G1 X48.338 Y95.098 F152
G1 X48.286 Y95.085 F152
G1 X48.229 Y95.069 F152
G1 X48.172 Y95.054 F152
G1 X48.125 Y95.041 F152
G1 X48.114 Y95.038 F152
G1 X47.943 Y94.993 F152
G1 X47.909 Y94.984 F152
G1 X47.885 Y94.978 F152
G1 X47.713 Y94.932 F152
G1 X47.694 Y94.927 F152
G1 X47.656 Y94.917 F152
G1 X47.599 Y94.902 F152
G1 X47.484 Y94.872 F152
G1 X47.427 Y94.858 F152
G1 X47.37 Y94.842 F152
G1 X47.312 Y94.828 F152
G1 X47.255 Y94.813 F152
G1 X47.252 Y94.812 F152
G1 X47.198 Y94.799 F152
G1 X47.141 Y94.783 F152
G1 X47.083 Y94.769 F152
G1 X47.031 Y94.755 F152
G1 X47.026 Y94.754 F152
G1 X46.969 Y94.739 F152
G1 X46.911 Y94.724 F152
G1 X46.854 Y94.709 F152
G1 X46.809 Y94.697 F152
G1 X46.797 Y94.695 F152
G1 X46.74 Y94.679 F152
G1 X46.682 Y94.665 F152
G1 X46.625 Y94.65 F152
G1 X46.587 Y94.64 F152
G1 X46.568 Y94.636 F152
G1 X46.511 Y94.621 F152
G1 X46.453 Y94.606 F152
G1 X46.396 Y94.592 F152
G1 X46.361 Y94.583 F152
G1 X46.339 Y94.577 F152
G1 X46.167 Y94.534 F152
G1 X46.134 Y94.526 F152
G1 X46.11 Y94.52 F152
G1 X46.052 Y94.505 F152
G1 X45.995 Y94.491 F152
G1 X45.938 Y94.477 F152
G1 X45.905 Y94.468 F152
G1 X45.88 Y94.463 F152
G1 X45.709 Y94.42 F152
G1 X45.674 Y94.411 F152
G1 X45.651 Y94.406 F152
G1 X45.594 Y94.391 F152
G1 X45.537 Y94.378 F152
G1 X45.48 Y94.363 F152
G1 X45.441 Y94.354 F152
G1 X45.422 Y94.349 F152
G1 X45.365 Y94.336 F152
G1 X45.308 Y94.321 F152
G1 X45.25 Y94.308 F152
G1 X45.206 Y94.296 F152
G1 X45.193 Y94.294 F152
G1 X45.136 Y94.279 F152
G1 X45.079 Y94.266 F152
G1 X45.021 Y94.252 F152
G1 X44.969 Y94.239 F152
G1 X44.964 Y94.238 F152
G1 X44.907 Y94.224 F152
G1 X44.735 Y94.184 F152
G1 X44.73 Y94.182 F152
G1 X44.678 Y94.169 F152
G1 X44.506 Y94.129 F152
G1 X44.487 Y94.124 F152
G1 X44.391 Y94.102 F152
G1 X44.334 Y94.09 F152
G1 X44.277 Y94.076 F152
G1 X44.239 Y94.067 F152
G1 X44.219 Y94.063 F152
G1 X44.162 Y94.05 F152
G1 X44.105 Y94.037 F152
G1 X43.99 Y94.012 F152
G1 X43.983 Y94.01 F152
G1 X43.933 Y93.999 F152
G1 X43.761 Y93.961 F152
G1 X43.721 Y93.953 F152
G1 X43.704 Y93.949 F152
G1 X43.589 Y93.926 F152
G1 X43.532 Y93.913 F152
G1 X43.475 Y93.902 F152
G1 X43.444 Y93.895 F152
G1 X43.417 Y93.89 F152
G1 X43.36 Y93.879 F152
G1 X43.303 Y93.867 F152
G1 X43.246 Y93.857 F152
G1 X43.188 Y93.845 F152
G1 X43.152 Y93.838 F152
G1 X43.131 Y93.834 F152
G1 X43.074 Y93.823 F152
G1 X42.902 Y93.79 F152
G1 X42.848 Y93.781 F152
G1 X42.845 F152
G1 X42.616 Y93.738 F152
G1 X42.558 Y93.728 F152
G1 X42.537 Y93.723 F152
G1 X42.501 Y93.717 F152
G1 X42.444 Y93.707 F152
G1 X42.272 Y93.675 F152
G1 X42.224 Y93.666 F152
G1 X42.215 Y93.665 F152
G1 X41.985 Y93.622 F152
G1 X41.928 Y93.611 F152
G1 X41.922 Y93.609 F152
G1 X41.871 Y93.599 F152
G1 X41.814 Y93.587 F152
G1 X41.756 Y93.575 F152
G1 X41.699 Y93.563 F152
G1 X41.643 Y93.551 F152
G1 X41.642 F152
G1 X41.527 Y93.525 F152
G1 X41.47 Y93.51 F152
G1 X41.413 Y93.497 F152
G1 X41.404 Y93.494 F152
G1 X41.355 Y93.483 F152
G1 X41.298 Y93.469 F152
G1 X41.241 Y93.454 F152
G1 X41.185 Y93.437 F152
G1 X41.184 F152
G1 X41.012 Y93.386 F152
G1 X40.993 Y93.38 F152
G1 X40.954 Y93.369 F152
G1 X40.897 Y93.351 F152
G1 X40.84 Y93.33 F152
G1 X40.819 Y93.322 F152
G1 X40.783 Y93.309 F152
G1 X40.725 Y93.287 F152
G1 X40.668 Y93.267 F152
G1 X40.664 Y93.265 F152
G1 X40.611 Y93.245 F152
G1 X40.554 Y93.224 F152
G1 X40.511 Y93.208 F152
G1 X40.496 Y93.201 F152
G1 X40.439 Y93.175 F152
G1 X40.384 Y93.15 F152
G1 X40.382 Y93.149 F152
G1 X40.267 Y93.098 F152
G1 X40.258 Y93.093 F152
G1 X40.21 Y93.072 F152
G1 X40.153 Y93.045 F152
G1 X40.133 Y93.036 F152
G1 X40.095 Y93.018 F152
G1 X40.038 Y92.988 F152
G1 X40.02 Y92.978 F152
G1 X39.981 Y92.958 F152
G1 X39.923 Y92.928 F152
G1 X39.91 Y92.921 F152
G1 X39.866 Y92.897 F152
G1 X39.809 Y92.865 F152
G1 X39.807 Y92.864 F152
G1 X39.752 Y92.833 F152
G1 X39.706 Y92.807 F152
G1 X39.694 Y92.8 F152
G1 X39.58 Y92.732 F152
G1 X39.522 Y92.697 F152
G1 X39.514 Y92.692 F152
G1 X39.465 Y92.662 F152
G1 X39.421 Y92.635 F152
G1 X39.408 Y92.627 F152
G1 X39.351 Y92.591 F152
G1 X39.331 Y92.577 F152
G1 X39.293 Y92.553 F152
G1 X39.243 Y92.52 F152
G1 X39.236 Y92.516 F152
G1 X39.179 Y92.478 F152
G1 X39.156 Y92.463 F152
G1 X39.122 Y92.439 F152
G1 X39.073 Y92.406 F152
G1 X39.064 Y92.4 F152
G1 X39.007 Y92.361 F152
G1 X38.99 Y92.348 F152
G1 X38.95 Y92.32 F152
G1 X38.91 Y92.291 F152
G1 X38.892 Y92.278 F152
G1 X38.835 Y92.236 F152
G1 X38.778 Y92.194 F152
G1 X38.755 Y92.176 F152
G1 X38.721 Y92.15 F152
G1 X38.68 Y92.119 F152
G1 X38.663 Y92.107 F152
G1 X38.606 Y92.063 F152
G1 X38.605 Y92.062 F152
G1 X38.549 Y92.015 F152
G1 X38.536 Y92.004 F152
G1 X38.466 Y91.947 F152
G1 X38.434 Y91.92 F152
G1 X38.377 Y91.873 F152
G1 X38.329 Y91.833 F152
G1 X38.32 Y91.825 F152
G1 X38.262 Y91.777 F152
G1 X38.26 Y91.775 F152
G1 X38.205 Y91.725 F152
G1 X38.197 Y91.718 F152
G1 X38.135 Y91.661 F152
G1 X38.091 Y91.619 F152
G1 X38.073 Y91.603 F152
G1 X38.033 Y91.567 F152
G1 X37.976 Y91.514 F152
G1 X37.949 Y91.489 F152
G1 X37.919 Y91.461 F152
G1 X37.888 Y91.431 F152
G1 X37.747 Y91.286 F152
G1 X37.722 Y91.26 F152
G1 X37.69 Y91.226 F152
G1 X37.665 Y91.202 F152
G1 X37.632 Y91.168 F152
G1 X37.61 Y91.145 F152
G1 X37.575 Y91.107 F152
G1 X37.518 Y91.041 F152
G1 X37.508 Y91.03 F152
G1 X37.46 Y90.976 F152
G1 X37.459 Y90.973 F152
G1 X37.409 Y90.916 F152
G1 X37.403 Y90.91 F152
G1 X37.358 Y90.859 F152
G1 X37.346 Y90.843 F152
G1 X37.309 Y90.801 F152
G1 X37.289 Y90.778 F152
G1 X37.262 Y90.744 F152
G1 X37.231 Y90.705 F152
G1 X37.217 Y90.687 F152
G1 X37.174 Y90.631 F152
G1 X37.172 Y90.629 F152
G1 X37.117 Y90.557 F152
G1 X37.084 Y90.515 F152
G1 X37.059 Y90.483 F152
G1 X37.04 Y90.457 F152
G1 X37.002 Y90.408 F152
G1 X36.997 Y90.4 F152
G1 X36.956 Y90.343 F152
G1 X36.945 Y90.327 F152
G1 X36.915 Y90.286 F152
G1 X36.875 Y90.228 F152
G1 X36.837 Y90.171 F152
G1 X36.83 Y90.161 F152
G1 X36.799 Y90.114 F152
G1 X36.773 Y90.075 F152
G1 X36.761 Y90.056 F152
G1 X36.724 Y89.999 F152
G1 X36.716 Y89.986 F152
G1 X36.689 Y89.942 F152
G1 X36.659 Y89.893 F152
G1 X36.653 Y89.884 F152
G1 X36.618 Y89.827 F152
G1 X36.601 Y89.799 F152
G1 X36.583 Y89.77 F152
G1 X36.55 Y89.713 F152
G1 X36.544 Y89.701 F152
G1 X36.518 Y89.655 F152
G1 X36.487 Y89.599 F152
G1 X36.486 Y89.598 F152
G1 X36.454 Y89.541 F152
G1 X36.429 Y89.497 F152
G1 X36.421 Y89.483 F152
G1 X36.391 Y89.426 F152
G1 X36.362 Y89.369 F152
G1 X36.333 Y89.311 F152
G1 X36.315 Y89.277 F152
G1 X36.303 Y89.254 F152
G1 X36.274 Y89.197 F152
G1 X36.258 Y89.164 F152
G1 X36.245 Y89.14 F152
G1 X36.217 Y89.082 F152
G1 X36.2 Y89.046 F152
G1 X36.19 Y89.025 F152
G1 X36.163 Y88.968 F152
G1 X36.143 Y88.923 F152
G1 X36.137 Y88.91 F152
G1 X36.111 Y88.853 F152
G1 X36.086 Y88.797 F152
G1 X36.085 Y88.796 F152
G1 X36.06 Y88.739 F152
G1 X36.036 Y88.681 F152
G1 X36.028 Y88.662 F152
G1 X36.011 Y88.624 F152
G1 X35.988 Y88.567 F152
G1 X35.94 Y88.452 F152
G1 X35.917 Y88.395 F152
G1 X35.914 Y88.387 F152
G1 X35.894 Y88.337 F152
G1 X35.873 Y88.28 F152
G1 X35.857 Y88.238 F152
G1 X35.85 Y88.223 F152
G1 X35.829 Y88.166 F152
G1 X35.807 Y88.108 F152
G1 X35.799 Y88.089 F152
G1 X35.785 Y88.051 F152
G1 X35.764 Y87.994 F152
G1 X35.745 Y87.936 F152
G1 X35.742 Y87.928 F152
G1 X35.724 Y87.879 F152
G1 X35.685 Y87.764 F152
G1 X35.664 Y87.707 F152
G1 X35.645 Y87.65 F152
G1 X35.628 Y87.594 F152
G1 X35.627 Y87.593 F152
G1 X35.609 Y87.535 F152
G1 X35.59 Y87.478 F152
G1 X35.572 Y87.421 F152
G1 X35.57 Y87.414 F152
G1 X35.553 Y87.363 F152
G1 X35.513 Y87.234 F152
G1 X35.5 Y87.192 F152
G1 X35.466 Y87.077 F152
G1 X35.456 Y87.038 F152
G1 X35.433 Y86.962 F152
G1 X35.417 Y86.905 F152
G1 X35.4 Y86.848 F152
G1 X35.398 Y86.841 F152
G1 X35.384 Y86.79 F152
G1 X35.354 Y86.676 F152
G1 X35.341 Y86.627 F152
G1 X35.338 Y86.619 F152
G1 X35.308 Y86.504 F152
G1 X35.294 Y86.447 F152
G1 X35.284 Y86.41 F152
G1 X35.278 Y86.389 F152
G1 X35.265 Y86.332 F152
G1 X35.251 Y86.275 F152
G1 X35.237 Y86.217 F152
G1 X35.227 Y86.171 F152
G1 X35.21 Y86.103 F152
G1 X35.183 Y85.988 F152
G1 X35.17 Y85.931 F152
G1 X35.169 Y85.924 F152
G1 X35.159 Y85.874 F152
G1 X35.133 Y85.759 F152
G1 X35.122 Y85.702 F152
G1 X35.112 Y85.656 F152
G1 X35.109 Y85.644 F152
G1 X35.097 Y85.587 F152
G1 X35.065 Y85.415 F152
G1 X35.055 Y85.362 F152
G1 X35.054 Y85.358 F152
G1 X35.022 Y85.186 F152
G1 X35.013 Y85.129 F152
G1 X35.003 Y85.072 F152
G1 X34.997 Y85.037 F152
G1 X34.993 Y85.014 F152
G1 X34.984 Y84.957 F152
G1 X34.964 Y84.842 F152
G1 X34.94 Y84.67 F152
G1 X34.931 Y84.613 F152
G1 X34.915 Y84.499 F152
G1 X34.886 Y84.269 F152
G1 X34.883 Y84.234 F152
G1 X34.873 Y84.155 F152
G1 X34.867 Y84.097 F152
G1 X34.861 Y84.04 F152
G1 X34.855 Y83.983 F152
G1 X34.85 Y83.926 F152
G1 X34.844 Y83.868 F152
G1 X34.833 Y83.754 F152
G1 X34.828 Y83.696 F152
G1 X34.826 Y83.657 F152
G1 X34.824 Y83.639 F152
G1 X34.81 Y83.467 F152
G1 X34.792 Y83.181 F152
G1 X34.784 Y83.009 F152
G1 X34.783 Y82.952 F152
G1 X34.78 Y82.894 F152
G1 X34.775 Y82.722 F152
G1 X34.774 Y82.665 F152
G1 X34.772 Y82.608 F152
G1 X34.771 Y82.55 F152
G1 Y82.493 F152
G1 X34.769 Y82.379 F152
G1 Y82.207 F152
G1 X34.77 Y82.149 F152
G1 Y82.092 F152
G1 X34.773 Y81.92 F152
G1 X34.775 Y81.863 F152
G1 Y81.806 F152
G1 X34.783 Y81.576 F152
G1 X34.785 Y81.519 F152
G1 X34.787 Y81.462 F152
G1 X34.798 Y81.233 F152
G1 X34.801 Y81.175 F152
G1 X34.804 Y81.118 F152
G1 X34.808 Y81.061 F152
G1 X34.81 Y81.003 F152
G1 X34.814 Y80.946 F152
G1 X34.817 Y80.889 F152
G1 X34.824 Y80.774 F152
G1 X34.826 Y80.754 F152
G1 X34.827 Y80.717 F152
G1 X34.831 Y80.66 F152
G1 X34.835 Y80.602 F152
G1 X34.843 Y80.488 F152
G1 X34.852 Y80.373 F152
G1 X34.857 Y80.316 F152
G1 X34.866 Y80.201 F152
G1 X34.871 Y80.144 F152
G1 X34.88 Y80.029 F152
G1 X34.883 Y80.007 F152
G1 X34.895 Y79.857 F152
G1 X34.905 Y79.743 F152
G1 X34.937 Y79.456 F152
G1 X34.94 Y79.43 F152
G1 X34.943 Y79.399 F152
G1 X34.95 Y79.342 F152
G1 X34.988 Y78.998 F152
G1 X34.997 Y78.941 F152
G1 X35.005 Y78.883 F152
G1 X35.014 Y78.826 F152
G1 X35.022 Y78.769 F152
G1 X35.031 Y78.712 F152
G1 X35.039 Y78.654 F152
G1 X35.048 Y78.597 F152
G1 X35.055 Y78.55 F152
G1 X35.056 Y78.54 F152
G1 X35.065 Y78.482 F152
G1 X35.073 Y78.425 F152
G1 X35.091 Y78.31 F152
G1 X35.099 Y78.253 F152
G1 X35.108 Y78.196 F152
G1 X35.112 Y78.177 F152
G1 X35.162 Y77.909 F152
G1 X35.169 Y77.875 F152
G1 X35.173 Y77.852 F152
G1 X35.185 Y77.795 F152
G1 X35.206 Y77.68 F152
G1 X35.219 Y77.623 F152
G1 X35.227 Y77.594 F152
G1 X35.233 Y77.566 F152
G1 X35.273 Y77.394 F152
G1 X35.284 Y77.347 F152
G1 X35.287 Y77.336 F152
G1 X35.299 Y77.279 F152
G1 X35.312 Y77.222 F152
G1 X35.327 Y77.165 F152
G1 X35.341 Y77.115 F152
G1 X35.343 Y77.107 F152
G1 X35.359 Y77.05 F152
G1 X35.376 Y76.993 F152
G1 X35.392 Y76.935 F152
G1 X35.398 Y76.915 F152
G1 X35.408 Y76.878 F152
G1 X35.425 Y76.821 F152
G1 X35.441 Y76.763 F152
G1 X35.456 Y76.715 F152
G1 X35.457 Y76.706 F152
G1 X35.495 Y76.592 F152
G1 X35.513 Y76.541 F152
G1 X35.515 Y76.534 F152
G1 X35.534 Y76.477 F152
G1 X35.552 Y76.42 F152
G1 X35.571 Y76.362 F152
G1 X35.587 Y76.305 F152
G1 X35.599 Y76.248 F152
G1 X35.604 Y76.19 F152
G1 X35.606 Y76.133 F152
G1 X35.601 Y76.019 F152
G1 X35.585 Y75.847 F152
G1 X35.578 Y75.789 F152
G1 X35.571 Y75.732 F152
G1 X35.57 Y75.721 F152
G1 X35.564 Y75.675 F152
G1 X35.558 Y75.618 F152
G1 X35.551 Y75.56 F152
G1 X35.544 Y75.503 F152
G1 X35.53 Y75.388 F152
G1 X35.524 Y75.331 F152
G1 X35.517 Y75.274 F152
G1 X35.513 Y75.24 F152
G1 X35.509 Y75.216 F152
G1 X35.503 Y75.159 F152
G1 X35.496 Y75.102 F152
G1 X35.464 Y74.758 F152
G1 X35.457 Y74.643 F152
G1 X35.456 Y74.617 F152
G1 X35.453 Y74.586 F152
G1 X35.446 Y74.472 F152
G1 X35.443 Y74.414 F152
G1 X35.441 Y74.357 F152
G1 X35.44 Y74.3 F152
G1 X35.439 Y74.242 F152
G1 X35.435 Y74.013 F152
G1 X35.436 Y73.956 F152
G1 X35.441 Y73.784 F152
G1 X35.442 Y73.727 F152
G1 X35.446 Y73.612 F152
G1 X35.449 Y73.555 F152
G1 X35.453 Y73.498 F152
G1 X35.456 Y73.462 F152
G1 X35.457 Y73.44 F152
G1 X35.46 Y73.383 F152
G1 X35.487 Y73.096 F152
G1 X35.508 Y72.925 F152
G1 X35.513 Y72.888 F152
G1 X35.516 Y72.867 F152
G1 X35.532 Y72.753 F152
G1 X35.541 Y72.695 F152
G1 X35.549 Y72.638 F152
G1 X35.568 Y72.523 F152
G1 X35.57 Y72.515 F152
G1 X35.578 Y72.466 F152
G1 X35.588 Y72.409 F152
G1 X35.61 Y72.294 F152
G1 X35.621 Y72.237 F152
G1 X35.628 Y72.208 F152
G1 X35.633 Y72.18 F152
G1 X35.656 Y72.065 F152
G1 X35.67 Y72.008 F152
G1 X35.682 Y71.951 F152
G1 X35.685 Y71.94 F152
G1 X35.695 Y71.893 F152
G1 X35.721 Y71.779 F152
G1 X35.736 Y71.721 F152
G1 X35.742 Y71.698 F152
G1 X35.75 Y71.664 F152
G1 X35.779 Y71.549 F152
G1 X35.794 Y71.492 F152
G1 X35.799 Y71.473 F152
G1 X35.826 Y71.378 F152
G1 X35.843 Y71.32 F152
G1 X35.857 Y71.274 F152
G1 X35.859 Y71.263 F152
G1 X35.875 Y71.206 F152
G1 X35.892 Y71.148 F152
G1 X35.909 Y71.091 F152
G1 X35.914 Y71.073 F152
G1 X35.925 Y71.034 F152
G1 X35.942 Y70.976 F152
G1 X35.958 Y70.919 F152
G1 X35.976 Y70.862 F152
G1 X36.013 Y70.747 F152
G1 X36.028 Y70.703 F152
G1 X36.032 Y70.69 F152
G1 X36.07 Y70.575 F152
G1 X36.086 Y70.529 F152
G1 X36.088 Y70.518 F152
G1 X36.108 Y70.461 F152
G1 X36.165 Y70.289 F152
G1 X36.185 Y70.232 F152
G1 X36.2 Y70.193 F152
G1 X36.207 Y70.174 F152
G1 X36.229 Y70.117 F152
G1 X36.25 Y70.06 F152
G1 X36.258 Y70.041 F152
G1 X36.272 Y70.002 F152
G1 X36.293 Y69.945 F152
G1 X36.315 Y69.889 F152
G1 Y69.888 F152
G1 X36.358 Y69.773 F152
G1 X36.372 Y69.737 F152
G1 X36.379 Y69.716 F152
G1 X36.402 Y69.659 F152
G1 X36.426 Y69.601 F152
G1 X36.429 Y69.593 F152
G1 X36.45 Y69.544 F152
G1 X36.475 Y69.487 F152
G1 X36.487 Y69.46 F152
G1 X36.499 Y69.429 F152
G1 X36.524 Y69.372 F152
G1 X36.544 Y69.326 F152
G1 X36.573 Y69.258 F152
G1 X36.601 Y69.192 F152
G1 X36.622 Y69.143 F152
G1 X36.647 Y69.086 F152
G1 X36.659 Y69.059 F152
G1 X36.672 Y69.028 F152
G1 X36.7 Y68.971 F152
G1 X36.716 Y68.939 F152
G1 X36.727 Y68.914 F152
G1 X36.755 Y68.856 F152
G1 X36.773 Y68.822 F152
G1 X36.784 Y68.799 F152
G1 X36.812 Y68.742 F152
G1 X36.83 Y68.703 F152
G1 X36.839 Y68.685 F152
G1 X36.867 Y68.627 F152
G1 X36.896 Y68.57 F152
G1 X36.923 Y68.513 F152
G1 X36.945 Y68.469 F152
G1 X36.951 Y68.455 F152
G1 X36.98 Y68.398 F152
G1 X37.002 Y68.359 F152
G1 X37.043 Y68.284 F152
G1 X37.076 Y68.226 F152
G1 X37.107 Y68.169 F152
G1 X37.117 Y68.152 F152
G1 X37.138 Y68.112 F152
G1 X37.174 Y68.048 F152
G1 X37.202 Y67.997 F152
G1 X37.231 Y67.944 F152
G1 X37.234 Y67.94 F152
G1 X37.265 Y67.882 F152
G1 X37.289 Y67.84 F152
G1 X37.297 Y67.825 F152
G1 X37.331 Y67.768 F152
G1 X37.346 Y67.744 F152
G1 X37.366 Y67.711 F152
G1 X37.402 Y67.653 F152
G1 X37.403 Y67.652 F152
G1 X37.438 Y67.596 F152
G1 X37.475 Y67.539 F152
G1 X37.511 Y67.481 F152
G1 X37.518 Y67.47 F152
G1 X37.575 Y67.378 F152
G1 X37.582 Y67.367 F152
G1 X37.618 Y67.309 F152
G1 X37.632 Y67.287 F152
G1 X37.654 Y67.252 F152
G1 X37.69 Y67.196 F152
G1 Y67.195 F152
G1 X37.768 Y67.08 F152
G1 X37.804 Y67.027 F152
G1 X37.808 Y67.023 F152
G1 X37.846 Y66.966 F152
G1 X37.861 Y66.944 F152
G1 X37.886 Y66.908 F152
G1 X37.919 Y66.862 F152
G1 X37.927 Y66.851 F152
G1 X37.976 Y66.784 F152
G1 X38.01 Y66.736 F152
G1 X38.033 Y66.705 F152
G1 X38.052 Y66.679 F152
G1 X38.091 Y66.626 F152
G1 X38.094 Y66.622 F152
G1 X38.136 Y66.565 F152
G1 X38.148 Y66.55 F152
G1 X38.205 Y66.476 F152
G1 X38.225 Y66.45 F152
G1 X38.262 Y66.403 F152
G1 X38.27 Y66.393 F152
G1 X38.314 Y66.335 F152
G1 X38.32 Y66.328 F152
G1 X38.359 Y66.278 F152
G1 X38.377 Y66.256 F152
G1 X38.406 Y66.221 F152
G1 X38.434 Y66.187 F152
G1 X38.453 Y66.164 F152
G1 X38.5 Y66.106 F152
G1 X38.547 Y66.049 F152
G1 X38.549 Y66.047 F152
G1 X38.594 Y65.992 F152
G1 X38.606 Y65.978 F152
G1 X38.644 Y65.934 F152
G1 X38.663 Y65.912 F152
G1 X38.694 Y65.877 F152
G1 X38.721 Y65.847 F152
G1 X38.778 Y65.78 F152
G1 X38.793 Y65.762 F152
G1 X38.835 Y65.715 F152
G1 X38.843 Y65.705 F152
G1 X38.892 Y65.651 F152
G1 X38.896 Y65.648 F152
G1 X38.95 Y65.59 F152
G1 X39.002 Y65.533 F152
G1 X39.007 Y65.527 F152
G1 X39.054 Y65.476 F152
G1 X39.107 Y65.419 F152
G1 X39.122 Y65.403 F152
G1 X39.163 Y65.361 F152
G1 X39.179 Y65.344 F152
G1 X39.218 Y65.304 F152
G1 X39.236 Y65.285 F152
G1 X39.274 Y65.247 F152
G1 X39.293 Y65.227 F152
G1 X39.33 Y65.189 F152
G1 X39.351 Y65.168 F152
G1 X39.386 Y65.132 F152
G1 X39.408 Y65.111 F152
G1 X39.445 Y65.075 F152
G1 X39.465 Y65.055 F152
G1 X39.504 Y65.018 F152
G1 X39.522 Y65 F152
G1 X39.563 Y64.96 F152
G1 X39.58 Y64.944 F152
G1 X39.622 Y64.903 F152
G1 X39.637 Y64.888 F152
G1 X39.682 Y64.846 F152
G1 X39.694 Y64.834 F152
G1 X39.744 Y64.788 F152
G1 X39.752 Y64.782 F152
G1 X39.807 Y64.731 F152
G1 X39.809 Y64.729 F152
G1 X39.866 Y64.676 F152
G1 X39.87 Y64.674 F152
G1 X39.923 Y64.625 F152
G1 X39.931 Y64.617 F152
G1 X39.981 Y64.573 F152
G1 X39.997 Y64.559 F152
G1 X40.038 Y64.523 F152
G1 X40.095 Y64.474 F152
G1 X40.129 Y64.445 F152
G1 X40.153 Y64.425 F152
G1 X40.21 Y64.375 F152
G1 X40.263 Y64.33 F152
G1 X40.324 Y64.28 F152
G1 X40.333 Y64.273 F152
G1 X40.382 Y64.233 F152
G1 X40.403 Y64.215 F152
G1 X40.439 Y64.187 F152
G1 X40.474 Y64.158 F152
G1 X40.496 Y64.14 F152
G1 X40.545 Y64.101 F152
G1 X40.554 Y64.094 F152
G1 X40.611 Y64.049 F152
G1 X40.618 Y64.044 F152
G1 X40.668 Y64.005 F152
G1 X40.725 Y63.962 F152
G1 X40.768 Y63.929 F152
G1 X40.783 Y63.918 F152
G1 X40.843 Y63.872 F152
G1 X40.897 Y63.831 F152
G1 X40.921 Y63.814 F152
G1 X40.954 Y63.79 F152
G1 X41.001 Y63.757 F152
G1 X41.012 Y63.75 F152
G1 X41.126 Y63.668 F152
G1 X41.162 Y63.642 F152
G1 X41.184 Y63.627 F152
G1 X41.241 Y63.588 F152
G1 X41.244 Y63.585 F152
G1 X41.298 Y63.549 F152
G1 X41.331 Y63.528 F152
G1 X41.355 Y63.512 F152
G1 X41.413 Y63.473 F152
G1 X41.417 Y63.471 F152
G1 X41.47 Y63.436 F152
G1 X41.503 Y63.413 F152
G1 X41.527 Y63.397 F152
G1 X41.585 Y63.361 F152
G1 X41.593 Y63.356 F152
G1 X41.642 Y63.326 F152
G1 X41.686 Y63.299 F152
G1 X41.699 Y63.291 F152
G1 X41.756 Y63.255 F152
G1 X41.779 Y63.241 F152
G1 X41.814 Y63.22 F152
G1 X41.871 Y63.185 F152
G1 X41.872 Y63.184 F152
G1 X41.928 Y63.151 F152
G1 X42.043 Y63.087 F152
G1 X42.072 Y63.069 F152
G1 X42.1 Y63.053 F152
G1 X42.157 Y63.021 F152
G1 X42.173 Y63.012 F152
G1 X42.215 Y62.989 F152
G1 X42.272 Y62.958 F152
G1 X42.277 Y62.955 F152
G1 X42.386 Y62.898 F152
G1 X42.444 Y62.869 F152
G1 X42.498 Y62.84 F152
G1 X42.501 Y62.839 F152
G1 X42.558 Y62.809 F152
G1 X42.616 Y62.78 F152
G1 X42.732 Y62.726 F152
G1 X42.787 Y62.699 F152
G1 X42.845 Y62.672 F152
G1 X42.854 Y62.668 F152
G1 X42.902 Y62.645 F152
G1 X42.959 Y62.618 F152
G1 X43.074 Y62.57 F152
G1 X43.111 Y62.554 F152
G1 X43.131 Y62.546 F152
G1 X43.188 Y62.522 F152
G1 X43.246 Y62.497 F152
G1 X43.247 F152
G1 X43.303 Y62.472 F152
G1 X43.36 Y62.45 F152
G1 X43.532 Y62.386 F152
G1 X43.542 Y62.382 F152
G1 X43.589 Y62.364 F152
G1 X43.647 Y62.343 F152
G1 X43.694 Y62.325 F152
G1 X43.704 Y62.321 F152
G1 X43.761 Y62.301 F152
G1 X43.818 Y62.283 F152
G1 X43.867 Y62.267 F152
G1 X43.876 Y62.264 F152
G1 X43.99 Y62.226 F152
G1 X44.041 Y62.21 F152
G1 X44.048 Y62.207 F152
G1 X44.105 Y62.189 F152
G1 X44.219 Y62.157 F152
G1 X44.236 Y62.153 F152
G1 X44.277 Y62.141 F152
G1 X44.391 Y62.109 F152
G1 X44.44 Y62.095 F152
G1 X44.448 Y62.093 F152
G1 X44.506 Y62.078 F152
G1 X44.849 Y61.998 F152
G1 X44.907 Y61.985 F152
G1 X44.934 Y61.981 F152
G1 X44.964 Y61.975 F152
G1 X45.193 Y61.932 F152
G1 X45.241 Y61.924 F152
G1 X45.25 Y61.921 F152
G1 X45.308 Y61.912 F152
G1 X45.594 Y61.872 F152
G1 X45.637 Y61.866 F152
G1 X45.651 Y61.864 F152
G1 X45.709 Y61.857 F152
G1 X46.052 Y61.825 F152
G1 X46.11 Y61.821 F152
G1 X46.339 Y61.81 F152
G1 X46.368 Y61.809 F152
G1 X46.396 Y61.807 F152
G1 X46.511 Y61.802 F152
G1 X46.568 Y61.801 F152
G1 X46.625 F152
G1 X46.682 Y61.802 F152
G1 X46.74 F152
G1 X46.854 Y61.804 F152
G1 X46.911 F152
G1 X47.026 Y61.805 F152
G1 X47.083 Y61.808 F152
G1 X47.09 Y61.809 F152
G1 X47.141 Y61.812 F152
G1 X47.198 Y61.816 F152
G1 X47.312 Y61.823 F152
G1 X47.37 Y61.828 F152
G1 X47.484 Y61.835 F152
G1 X47.542 Y61.839 F152
G1 X47.713 Y61.858 F152
G1 X47.771 Y61.865 F152
G1 X47.828 Y61.872 F152
G1 X47.885 Y61.88 F152
G1 X47.943 Y61.889 F152
G1 X48.057 Y61.905 F152
G1 X48.114 Y61.914 F152
G1 X48.166 Y61.924 F152
G1 X48.286 Y61.944 F152
G1 X48.401 Y61.966 F152
G1 X48.458 Y61.978 F152
G1 X48.573 Y62.001 F152
G1 X48.687 Y62.027 F152
G1 X48.732 Y62.038 F152
G1 X48.744 Y62.041 F152
G1 X48.802 Y62.055 F152
G1 X48.859 Y62.069 F152
G1 X48.916 Y62.083 F152
G1 X48.965 Y62.095 F152
G1 X48.974 Y62.098 F152
G1 X49.031 Y62.113 F152
G1 X49.145 Y62.146 F152
G1 X49.17 Y62.153 F152
G1 X49.203 Y62.162 F152
G1 X49.26 Y62.178 F152
G1 X49.317 Y62.197 F152
G1 X49.357 Y62.21 F152
G1 X49.374 Y62.215 F152
G1 X49.432 Y62.235 F152
G1 X49.489 Y62.254 F152
G1 X49.529 Y62.267 F152
G1 X49.546 Y62.273 F152
G1 X49.661 Y62.31 F152
G1 X49.702 Y62.325 F152
G1 X49.718 Y62.329 F152
G1 X49.833 Y62.368 F152
G1 X49.868 Y62.382 F152
G1 X49.89 Y62.391 F152
G1 X49.947 Y62.413 F152
G1 X50.005 Y62.437 F152
G1 X50.012 Y62.439 F152
G1 X50.062 Y62.459 F152
G1 X50.119 Y62.482 F152
G1 X50.234 Y62.527 F152
G1 X50.291 Y62.55 F152
G1 X50.299 Y62.554 F152
G1 X50.348 Y62.573 F152
G1 X50.406 Y62.598 F152
G1 X50.433 Y62.611 F152
G1 X50.52 Y62.651 F152
G1 X50.558 Y62.668 F152
G1 X50.635 Y62.703 F152
G1 X50.682 Y62.726 F152
G1 X50.749 Y62.756 F152
G1 X50.864 Y62.81 F152
G1 X50.978 Y62.869 F152
G1 X51.033 Y62.898 F152
G1 X51.036 F152
G1 X51.093 Y62.929 F152
G1 X51.143 Y62.955 F152
G1 X51.15 Y62.958 F152
G1 X51.207 Y62.988 F152
G1 X51.252 Y63.012 F152
G1 X51.265 Y63.018 F152
G1 X51.322 Y63.048 F152
G1 X51.359 Y63.069 F152
G1 X51.379 Y63.081 F152
G1 X51.437 Y63.114 F152
G1 X51.458 Y63.127 F152
G1 X51.494 Y63.147 F152
G1 X51.551 Y63.181 F152
G1 X51.556 Y63.184 F152
G1 X51.608 Y63.215 F152
G1 X51.723 Y63.281 F152
G1 X51.753 Y63.299 F152
G1 X51.78 Y63.316 F152
G1 X51.837 Y63.352 F152
G1 X51.843 Y63.356 F152
G1 X51.895 Y63.389 F152
G1 X51.932 Y63.413 F152
G1 X51.952 Y63.426 F152
G1 X52.009 Y63.462 F152
G1 X52.023 Y63.471 F152
G1 X52.067 Y63.498 F152
G1 X52.112 Y63.528 F152
G1 X52.124 Y63.535 F152
G1 X52.181 Y63.574 F152
G1 X52.197 Y63.585 F152
G1 X52.238 Y63.613 F152
G1 X52.28 Y63.642 F152
G1 X52.296 Y63.652 F152
G1 X52.353 Y63.693 F152
G1 X52.362 Y63.7 F152
G1 X52.41 Y63.734 F152
G1 X52.442 Y63.757 F152
G1 X52.468 Y63.775 F152
G1 X52.52 Y63.814 F152
G1 X52.525 Y63.818 F152
G1 X52.582 Y63.861 F152
G1 X52.596 Y63.872 F152
G1 X52.639 Y63.905 F152
G1 X52.671 Y63.929 F152
G1 X52.697 Y63.949 F152
G1 X52.754 Y63.992 F152
G1 X52.811 Y64.038 F152
G1 X52.818 Y64.044 F152
G1 X52.868 Y64.085 F152
G1 X52.887 Y64.101 F152
G1 X52.926 Y64.132 F152
G1 X52.956 Y64.158 F152
G1 X52.983 Y64.18 F152
G1 X53.026 Y64.215 F152
G1 X53.04 Y64.228 F152
G1 X53.09 Y64.273 F152
G1 X53.098 Y64.279 F152
G1 X53.154 Y64.33 F152
G1 X53.155 Y64.331 F152
G1 X53.212 Y64.382 F152
G1 X53.218 Y64.387 F152
G1 X53.269 Y64.434 F152
G1 X53.281 Y64.445 F152
G1 X53.327 Y64.489 F152
G1 X53.34 Y64.502 F152
G1 X53.384 Y64.545 F152
G1 X53.398 Y64.559 F152
G1 X53.441 Y64.601 F152
G1 X53.457 Y64.617 F152
G1 X53.499 Y64.66 F152
G1 X53.511 Y64.674 F152
G1 X53.556 Y64.721 F152
G1 X53.566 Y64.731 F152
G1 X53.613 Y64.782 F152
G1 X53.619 Y64.788 F152
G1 X53.67 Y64.846 F152
G1 Y64.847 F152
G1 X53.72 Y64.903 F152
G1 X53.728 Y64.912 F152
G1 X53.769 Y64.96 F152
G1 X53.785 Y64.98 F152
G1 X53.816 Y65.018 F152
G1 X53.842 Y65.05 F152
G1 X53.863 Y65.075 F152
G1 X53.9 Y65.123 F152
G1 X53.907 Y65.132 F152
G1 X53.949 Y65.189 F152
G1 X53.992 Y65.247 F152
G1 X54.014 Y65.277 F152
G1 X54.033 Y65.304 F152
G1 X54.11 Y65.419 F152
G1 X54.129 Y65.446 F152
G1 X54.147 Y65.476 F152
G1 X54.182 Y65.533 F152
G1 X54.186 Y65.539 F152
G1 X54.218 Y65.591 F152
G1 X54.243 Y65.634 F152
G1 X54.251 Y65.648 F152
G1 X54.284 Y65.705 F152
G1 X54.345 Y65.82 F152
G1 X54.358 Y65.844 F152
G1 X54.376 Y65.877 F152
G1 X54.406 Y65.934 F152
G1 X54.415 Y65.952 F152
G1 X54.436 Y65.992 F152
G1 X54.466 Y66.049 F152
G1 X54.472 Y66.061 F152
G1 X54.527 Y66.164 F152
G1 X54.53 Y66.17 F152
G1 X54.557 Y66.221 F152
G1 X54.587 Y66.274 F152
G1 X54.59 Y66.278 F152
G1 X54.621 Y66.335 F152
G1 X54.644 Y66.377 F152
G1 X54.653 Y66.393 F152
G1 X54.69 Y66.45 F152
G1 X54.701 Y66.469 F152
G1 X54.726 Y66.507 F152
G1 X54.759 Y66.558 F152
G1 X54.764 Y66.565 F152
G1 X54.809 Y66.622 F152
G1 X54.816 Y66.632 F152
G1 X54.854 Y66.679 F152
G1 X54.873 Y66.705 F152
G1 X54.903 Y66.736 F152
G1 X55.014 Y66.851 F152
G1 X55.045 Y66.88 F152
G1 X55.078 Y66.908 F152
G1 X55.102 Y66.926 F152
G1 X55.157 Y66.966 F152
G1 X55.16 Y66.967 F152
G1 X55.217 Y67.002 F152
G1 X55.255 Y67.023 F152
G1 X55.274 Y67.031 F152
G1 X55.303 Y67.042 F152
G1 X55.331 Y67.049 F152
G1 X55.346 Y67.052 F152
G1 X55.36 F152
G1 X55.389 Y67.049 F152
G1 X55.417 Y67.042 F152
G1 X55.446 Y67.034 F152
G1 X55.474 Y67.023 F152
G1 X55.503 Y67.011 F152
G1 X55.561 Y66.984 F152
G1 X55.597 Y66.966 F152
G1 X55.618 Y66.954 F152
G1 X55.675 Y66.923 F152
G1 X55.699 Y66.908 F152
G1 X55.732 Y66.888 F152
G1 X55.79 Y66.852 F152
G1 X55.792 Y66.851 F152
G1 X55.847 Y66.814 F152
G1 X55.879 Y66.794 F152
G1 X55.904 Y66.777 F152
G1 X55.961 Y66.736 F152
G1 X55.962 F152
G1 X56.019 Y66.695 F152
G1 X56.042 Y66.679 F152
G1 X56.123 Y66.622 F152
G1 X56.133 Y66.614 F152
G1 X56.191 Y66.572 F152
G1 X56.2 Y66.565 F152
G1 X56.248 Y66.528 F152
G1 X56.305 Y66.484 F152
G1 X56.349 Y66.45 F152
G1 X56.363 Y66.439 F152
G1 X56.423 Y66.393 F152
G1 X56.495 Y66.335 F152
G1 X56.534 Y66.303 F152
G1 X56.566 Y66.278 F152
G1 X56.592 Y66.256 F152
G1 X56.633 Y66.221 F152
G1 X56.649 Y66.207 F152
G1 X56.706 Y66.159 F152
G1 X56.763 Y66.108 F152
G1 X56.765 Y66.106 F152
G1 X56.821 Y66.057 F152
G1 X56.829 Y66.049 F152
G1 X56.878 Y66.003 F152
G1 X56.89 Y65.992 F152
G1 X56.935 Y65.947 F152
G1 X56.947 Y65.934 F152
G1 X56.993 Y65.889 F152
G1 X57.002 Y65.877 F152
G1 X57.05 Y65.823 F152
G1 X57.053 Y65.82 F152
G1 X57.099 Y65.762 F152
G1 X57.107 Y65.752 F152
G1 X57.138 Y65.705 F152
G1 X57.155 Y65.677 F152
G1 X57.164 Y65.658 F152
G1 X57.168 Y65.648 F152
G1 X57.169 Y65.644 F152
G1 X57.17 Y65.642 F152
G1 Y65.626 F152
G1 X57.169 Y65.619 F152
G1 X57.164 Y65.597 F152
G1 X57.163 Y65.591 F152
G1 X57.15 Y65.533 F152
G1 X57.136 Y65.476 F152
G1 X57.096 Y65.361 F152
G1 X57.076 Y65.304 F152
G1 X57.054 Y65.247 F152
G1 X57.05 Y65.235 F152
G1 X57.031 Y65.189 F152
G1 X57.009 Y65.132 F152
G1 X56.993 Y65.09 F152
G1 X56.986 Y65.075 F152
G1 X56.964 Y65.018 F152
G1 X56.942 Y64.96 F152
G1 X56.935 Y64.94 F152
G1 X56.921 Y64.903 F152
G1 X56.9 Y64.846 F152
G1 X56.879 Y64.788 F152
G1 X56.859 Y64.731 F152
G1 X56.841 Y64.674 F152
G1 X56.824 Y64.617 F152
G1 X56.821 Y64.602 F152
G1 X56.807 Y64.559 F152
G1 X56.79 Y64.502 F152
G1 X56.774 Y64.445 F152
G1 X56.763 Y64.403 F152
G1 X56.76 Y64.387 F152
G1 X56.749 Y64.33 F152
G1 X56.739 Y64.273 F152
G1 X56.729 Y64.215 F152
G1 X56.709 Y64.101 F152
G1 X56.706 Y64.084 F152
G1 X56.701 Y64.044 F152
G1 X56.696 Y63.986 F152
G1 X56.693 Y63.929 F152
G1 X56.688 Y63.872 F152
G1 X56.687 Y63.814 F152
G1 X56.689 Y63.7 F152
G1 X56.691 Y63.642 F152
G1 X56.695 Y63.585 F152
G1 X56.703 Y63.528 F152
G1 X56.706 Y63.506 F152
G1 X56.718 Y63.413 F152
G1 X56.726 Y63.356 F152
G1 X56.738 Y63.299 F152
G1 X56.752 Y63.241 F152
G1 X56.763 Y63.198 F152
G1 X56.767 Y63.184 F152
G1 X56.782 Y63.127 F152
G1 X56.798 Y63.069 F152
G1 X56.816 Y63.012 F152
G1 X56.821 Y63.001 F152
G1 X56.839 Y62.955 F152
G1 X56.861 Y62.898 F152
G1 X56.878 Y62.855 F152
G1 X56.883 Y62.84 F152
G1 X56.907 Y62.783 F152
G1 X56.99 Y62.611 F152
G1 X56.993 Y62.607 F152
G1 X57.019 Y62.554 F152
G1 X57.05 Y62.499 F152
G1 X57.051 Y62.497 F152
G1 X57.082 Y62.439 F152
G1 X57.107 Y62.394 F152
G1 X57.113 Y62.382 F152
G1 X57.145 Y62.325 F152
G1 X57.164 Y62.289 F152
G1 X57.175 Y62.267 F152
; MOVEMENT_LEAD_OUT
G1 X57.177 Y62.264 Z-8.093 F152
G1 Y62.263 Z-8.089 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X50.258 Y68.043 F152
G1 Z0.875 F152
; MOVEMENT_PLUNGE
G1 Z-8.045 F51
; MOVEMENT_LEAD_IN
G1 X50.257 Y68.039 Z-8.064 F152
G1 X50.252 Y68.029 Z-8.081 F152
G1 X50.244 Y68.014 Z-8.091 F152
G1 X50.235 Y67.997 Z-8.095 F152
; MOVEMENT_CUTTING
G1 X50.234 Y67.993 Z-8.09 F152
G1 X50.209 Y67.94 Z-8.029 F152
G1 X50.181 Y67.882 Z-7.966 F152
G1 X50.176 Y67.873 Z-7.958 F152
G1 X50.15 Y67.825 Z-7.902 F152
G1 X50.119 Y67.771 Z-7.84 F152
G1 X50.117 Y67.768 Z-7.835 F152
G1 X50.086 Y67.711 Z-7.775 F152
G1 X50.054 Y67.653 Z-7.708 F152
G1 X50.021 Y67.596 Z-7.633 F152
G1 X50.005 Y67.568 Z-7.599 F152
G1 X49.986 Y67.539 Z-7.56 F152
G1 X49.948 Y67.481 Z-7.495 F152
G1 X49.947 Y67.48 Z-7.496 F152
G1 X49.911 Y67.424 Z-7.44 F152
G1 X49.89 Y67.391 Z-7.406 F152
G1 X49.874 Y67.367 Z-7.378 F152
G1 X49.834 Y67.309 Z-7.301 F152
G1 X49.833 Y67.307 Z-7.297 F152
G1 X49.815 Y67.281 Z-7.262 F152
G1 X49.794 Y67.252 Z-7.22 F152
G1 X49.775 Y67.226 Z-7.19 F152
G1 X49.752 Y67.195 Z-7.162 F152
G1 X49.718 Y67.15 Z-7.119 F152
G1 X49.709 Y67.138 Z-7.111 F152
G1 X49.664 Y67.08 Z-7.046 F152
G1 X49.661 Y67.076 Z-7.041 F152
G1 X49.618 Y67.023 Z-6.968 F152
G1 X49.604 Y67.004 Z-6.949 F152
G1 X49.572 Y66.966 Z-6.898 F152
G1 X49.546 Y66.934 Z-6.867 F152
G1 X49.523 Y66.908 Z-6.841 F152
G1 X49.489 Y66.869 Z-6.813 F152
G1 X49.473 Y66.851 Z-6.796 F152
G1 X49.432 Y66.807 Z-6.742 F152
G1 X49.419 Y66.794 Z-6.725 F152
G1 X49.374 Y66.745 Z-6.67 F152
G1 X49.366 Y66.736 Z-6.661 F152
G1 X49.317 Y66.684 Z-6.605 F152
G1 X49.313 Y66.679 Z-6.6 F152
G1 X49.26 Y66.626 Z-6.566 F152
G1 X49.255 Y66.622 Z-6.558 F152
G1 X49.203 Y66.574 Z-6.51 F152
G1 X49.193 Y66.565 Z-6.5 F152
G1 X49.145 Y66.521 Z-6.454 F152
G1 X49.088 Y66.467 Z-6.404 F152
G1 X49.069 Y66.45 Z-6.385 F152
G1 X49.031 Y66.416 Z-6.363 F152
G1 X49.002 Y66.393 Z-6.347 F152
G1 X48.974 Y66.37 Z-6.326 F152
G1 X48.93 Y66.335 Z-6.298 F152
G1 X48.916 Y66.325 Z-6.29 F152
G1 X48.859 Y66.279 Z-6.254 F152
G1 X48.857 Y66.278 Z-6.249 F152
G1 X48.802 Y66.234 Z-6.211 F152
G1 X48.785 Y66.221 Z-6.204 F152
G1 X48.744 Y66.192 Z-6.185 F152
G1 X48.701 Y66.164 Z-6.166 F152
G1 X48.687 Y66.154 Z-6.162 F152
G1 X48.63 Y66.116 Z-6.132 F152
G1 X48.616 Y66.106 Z-6.128 F152
G1 X48.53 Y66.049 Z-6.09 F152
G1 X48.515 Y66.039 Z-6.086 F152
G1 X48.458 Y66.004 Z-6.064 F152
G1 X48.436 Y65.992 Z-6.059 F152
G1 X48.401 Y65.972 Z-6.054 F152
G1 X48.343 Y65.941 Z-6.038 F152
G1 X48.333 Y65.934 F152
G1 X48.286 Y65.909 Z-6.021 F152
G1 X48.229 Y65.879 Z-5.998 F152
G1 X48.226 Y65.877 Z-6 F152
G1 X48.172 Y65.849 Z-5.979 F152
G1 X48.114 Y65.823 Z-5.972 F152
G1 X48.107 Y65.82 Z-5.975 F152
G1 X48.057 Y65.797 Z-5.971 F152
G1 X48 Y65.773 Z-5.956 F152
G1 X47.977 Y65.762 Z-5.957 F152
G1 X47.943 Y65.748 Z-5.947 F152
G1 X47.885 Y65.724 Z-5.932 F152
G1 X47.836 Y65.705 Z-5.924 F152
G1 X47.828 Y65.702 Z-5.923 F152
G1 X47.771 Y65.683 Z-5.925 F152
G1 X47.713 Y65.663 Z-5.927 F152
G1 X47.667 Y65.648 Z-5.923 F152
G1 X47.656 Y65.644 Z-5.922 F152
G1 X47.599 Y65.625 Z-5.917 F152
G1 X47.542 Y65.608 Z-5.899 F152
G1 X47.484 Y65.594 Z-5.891 F152
G1 X47.472 Y65.591 Z-5.897 F152
G1 X47.427 Y65.58 Z-5.901 F152
G1 X47.37 Y65.565 Z-5.91 F152
G1 X47.312 Y65.552 Z-5.912 F152
G1 X47.255 Y65.538 Z-5.921 F152
G1 X47.234 Y65.533 Z-5.916 F152
G1 X47.198 Y65.526 Z-5.91 F152
G1 X47.141 Y65.516 Z-5.916 F152
G1 X46.969 Y65.489 Z-5.954 F152
G1 X46.911 Y65.481 Z-5.958 F152
G1 X46.874 Y65.476 Z-5.961 F152
G1 X46.854 Y65.474 Z-5.956 F152
G1 X46.797 Y65.469 Z-5.969 F152
G1 X46.74 Y65.464 Z-5.99 F152
G1 X46.682 Y65.461 Z-6.002 F152
G1 X46.568 Y65.452 Z-6.043 F152
G1 X46.511 Y65.45 Z-6.04 F152
G1 X46.453 Y65.449 Z-6.052 F152
G1 X46.396 Z-6.078 F152
G1 X46.281 Z-6.131 F152
G1 X46.224 Y65.45 Z-6.149 F152
G1 X46.167 Y65.452 Z-6.159 F152
G1 X46.11 Y65.454 Z-6.174 F152
G1 X46.052 Y65.459 Z-6.201 F152
G1 X45.88 Y65.472 Z-6.291 F152
G1 X45.846 Y65.476 Z-6.3 F152
G1 X45.823 Y65.479 Z-6.305 F152
G1 X45.766 Y65.486 Z-6.314 F152
G1 X45.709 Y65.494 Z-6.346 F152
G1 X45.651 Y65.502 Z-6.386 F152
G1 X45.537 Y65.52 Z-6.45 F152
G1 X45.48 Y65.53 Z-6.474 F152
G1 X45.455 Y65.533 Z-6.489 F152
G1 X45.422 Y65.54 Z-6.498 F152
G1 X45.365 Y65.55 Z-6.533 F152
G1 X45.25 Y65.577 Z-6.599 F152
G1 X45.193 Y65.591 Z-6.632 F152
G1 X45.19 Z-6.639 F152
G1 X45.136 Y65.604 Z-6.665 F152
G1 X45.079 Y65.618 Z-6.69 F152
G1 X45.021 Y65.634 Z-6.714 F152
G1 X44.971 Y65.648 Z-6.75 F152
G1 X44.964 Y65.651 Z-6.751 F152
G1 X44.907 Y65.668 Z-6.792 F152
G1 X44.849 Y65.685 Z-6.825 F152
G1 X44.792 Y65.704 Z-6.85 F152
G1 X44.787 Y65.705 Z-6.86 F152
G1 X44.735 Y65.722 Z-6.884 F152
G1 X44.678 Y65.742 Z-6.902 F152
G1 X44.62 Y65.762 Z-6.936 F152
G1 X44.619 Z-6.943 F152
G1 X44.563 Y65.785 Z-6.97 F152
G1 X44.506 Y65.808 Z-6.996 F152
G1 X44.475 Y65.82 Z-7.015 F152
G1 X44.448 Y65.83 Z-7.029 F152
G1 X44.334 Y65.877 Z-7.08 F152
G1 X44.277 Y65.902 Z-7.103 F152
G1 X44.219 Y65.93 Z-7.128 F152
G1 X44.21 Y65.934 Z-7.135 F152
G1 X44.162 Y65.958 Z-7.154 F152
G1 X44.105 Y65.985 Z-7.181 F152
G1 X44.091 Y65.992 Z-7.189 F152
G1 X44.048 Y66.013 Z-7.207 F152
G1 X43.99 Y66.043 Z-7.218 F152
G1 X43.978 Y66.049 Z-7.223 F152
G1 X43.933 Y66.073 Z-7.228 F152
G1 X43.876 Y66.105 Z-7.252 F152
G1 X43.874 Y66.106 Z-7.254 F152
G1 X43.818 Y66.138 Z-7.272 F152
G1 X43.775 Y66.164 Z-7.289 F152
G1 X43.761 Y66.172 Z-7.292 F152
G1 X43.704 Y66.207 Z-7.291 F152
G1 X43.681 Y66.221 Z-7.295 F152
G1 X43.647 Y66.243 Z-7.29 F152
G1 X43.589 Y66.278 Z-7.299 F152
G1 X43.532 Y66.317 Z-7.31 F152
G1 X43.505 Y66.335 Z-7.311 F152
G1 X43.475 Y66.358 Z-7.305 F152
G1 X43.426 Y66.393 Z-7.304 F152
G1 X43.417 Y66.399 Z-7.3 F152
G1 X43.36 Y66.439 Z-7.302 F152
G1 X43.346 Y66.45 Z-7.297 F152
G1 X43.303 Y66.481 Z-7.29 F152
G1 X43.269 Y66.507 Z-7.276 F152
G1 X43.246 Y66.526 Z-7.265 F152
G1 X43.198 Y66.565 Z-7.258 F152
G1 X43.188 Y66.573 Z-7.256 F152
G1 X43.131 Y66.619 Z-7.248 F152
G1 X43.128 Y66.622 Z-7.244 F152
G1 X43.074 Y66.668 Z-7.228 F152
G1 X43.06 Y66.679 Z-7.221 F152
G1 X43.017 Y66.718 Z-7.194 F152
G1 X42.959 Y66.768 Z-7.161 F152
G1 X42.93 Y66.794 Z-7.148 F152
G1 X42.902 Y66.82 Z-7.138 F152
G1 X42.868 Y66.851 Z-7.129 F152
G1 X42.845 Y66.873 Z-7.117 F152
G1 X42.787 Y66.931 Z-7.072 F152
G1 X42.752 Y66.966 Z-7.049 F152
G1 X42.694 Y67.023 Z-7.004 F152
G1 X42.673 Y67.044 Z-6.993 F152
G1 X42.636 Y67.08 Z-6.967 F152
G1 X42.616 Y67.103 Z-6.949 F152
G1 X42.584 Y67.138 Z-6.922 F152
G1 X42.532 Y67.195 Z-6.88 F152
G1 X42.501 Y67.229 Z-6.859 F152
G1 X42.48 Y67.252 Z-6.839 F152
G1 X42.444 Y67.292 Z-6.811 F152
G1 X42.429 Y67.309 Z-6.797 F152
G1 X42.386 Y67.357 Z-6.757 F152
G1 X42.377 Y67.367 Z-6.75 F152
G1 X42.329 Y67.424 Z-6.7 F152
G1 X42.283 Y67.481 Z-6.658 F152
G1 X42.272 Y67.494 Z-6.652 F152
G1 X42.235 Y67.539 Z-6.622 F152
G1 X42.215 Y67.564 Z-6.604 F152
G1 X42.189 Y67.596 Z-6.579 F152
G1 X42.157 Y67.635 Z-6.545 F152
G1 X42.143 Y67.653 Z-6.531 F152
G1 X42.1 Y67.708 Z-6.481 F152
G1 X42.098 Y67.711 Z-6.476 F152
G1 X42.054 Y67.768 Z-6.435 F152
G1 X42.043 Y67.784 Z-6.422 F152
G1 X42.011 Y67.825 Z-6.4 F152
G1 X41.985 Y67.86 Z-6.378 F152
G1 X41.969 Y67.882 Z-6.359 F152
G1 X41.887 Y67.997 Z-6.264 F152
G1 X41.871 Y68.019 Z-6.246 F152
G1 X41.846 Y68.054 Z-6.217 F152
G1 X41.814 Y68.1 Z-6.185 F152
G1 X41.806 Y68.112 Z-6.18 F152
G1 X41.768 Y68.169 Z-6.136 F152
G1 X41.756 Y68.186 Z-6.127 F152
G1 X41.699 Y68.272 Z-6.069 F152
G1 X41.692 Y68.284 Z-6.057 F152
G1 X41.653 Y68.341 Z-6.02 F152
G1 X41.642 Y68.359 Z-6.006 F152
G1 X41.616 Y68.398 Z-5.977 F152
G1 X41.585 Y68.446 Z-5.942 F152
G1 X41.579 Y68.455 Z-5.935 F152
G1 X41.544 Y68.513 Z-5.901 F152
G1 X41.527 Y68.54 Z-5.885 F152
G1 X41.509 Y68.57 Z-5.866 F152
G1 X41.474 Y68.627 Z-5.832 F152
G1 X41.47 Y68.634 Z-5.829 F152
G1 X41.44 Y68.685 Z-5.798 F152
G1 X41.413 Y68.728 Z-5.773 F152
G1 X41.406 Y68.742 Z-5.757 F152
G1 X41.372 Y68.799 Z-5.716 F152
G1 X41.355 Y68.826 Z-5.705 F152
G1 X41.338 Y68.856 Z-5.689 F152
G1 X41.242 Y69.028 Z-5.609 F152
G1 X41.241 Y69.03 Z-5.607 F152
G1 X41.21 Y69.086 Z-5.575 F152
G1 X41.184 Y69.135 Z-5.545 F152
G1 X41.179 Y69.143 Z-5.541 F152
G1 X41.148 Y69.2 Z-5.511 F152
G1 X41.126 Y69.241 Z-5.497 F152
G1 X41.118 Y69.258 Z-5.49 F152
G1 X41.089 Y69.315 Z-5.469 F152
G1 X41.069 Y69.353 Z-5.453 F152
G1 X41.06 Y69.372 Z-5.44 F152
G1 X41.031 Y69.429 Z-5.412 F152
G1 X41.012 Y69.468 Z-5.397 F152
G1 X41.003 Y69.487 Z-5.384 F152
G1 X40.974 Y69.544 Z-5.356 F152
G1 X40.954 Y69.583 Z-5.342 F152
G1 X40.946 Y69.601 Z-5.337 F152
G1 X40.919 Y69.659 Z-5.321 F152
G1 X40.897 Y69.704 Z-5.308 F152
G1 X40.892 Y69.716 Z-5.304 F152
G1 X40.865 Y69.773 Z-5.288 F152
G1 X40.84 Y69.826 Z-5.276 F152
G1 X40.838 Y69.831 Z-5.272 F152
G1 X40.784 Y69.945 Z-5.24 F152
G1 X40.783 Y69.948 Z-5.243 F152
G1 X40.758 Y70.002 Z-5.229 F152
G1 X40.734 Y70.06 Z-5.216 F152
G1 X40.725 Y70.08 Z-5.214 F152
G1 X40.71 Y70.117 Z-5.204 F152
G1 X40.686 Y70.174 Z-5.192 F152
G1 X40.668 Y70.217 Z-5.18 F152
G1 X40.663 Y70.232 Z-5.172 F152
G1 X40.614 Y70.346 Z-5.147 F152
G1 X40.611 Y70.354 F152
G1 X40.591 Y70.404 Z-5.14 F152
G1 X40.569 Y70.461 Z-5.138 F152
G1 X40.554 Y70.498 Z-5.142 F152
G1 X40.546 Y70.518 Z-5.137 F152
G1 X40.502 Y70.633 Z-5.133 F152
G1 X40.496 Y70.645 Z-5.137 F152
G1 X40.479 Y70.69 Z-5.132 F152
G1 X40.458 Y70.747 Z-5.122 F152
G1 X40.439 Y70.797 Z-5.124 F152
G1 X40.437 Y70.805 Z-5.118 F152
G1 X40.417 Y70.862 Z-5.127 F152
G1 X40.397 Y70.919 Z-5.128 F152
G1 X40.382 Y70.961 Z-5.135 F152
G1 X40.377 Y70.976 Z-5.129 F152
G1 X40.357 Y71.034 Z-5.138 F152
G1 X40.338 Y71.091 Z-5.131 F152
G1 X40.324 Y71.129 Z-5.136 F152
G1 X40.318 Y71.148 Z-5.132 F152
G1 X40.299 Y71.206 Z-5.136 F152
G1 X40.281 Y71.263 Z-5.148 F152
G1 X40.267 Y71.308 Z-5.16 F152
G1 X40.264 Y71.32 Z-5.159 F152
G1 X40.246 Y71.378 Z-5.17 F152
G1 X40.229 Y71.435 Z-5.174 F152
G1 X40.211 Y71.492 Z-5.185 F152
G1 X40.21 Y71.496 Z-5.184 F152
G1 X40.194 Y71.549 Z-5.189 F152
G1 X40.177 Y71.607 Z-5.2 F152
G1 X40.162 Y71.664 Z-5.214 F152
G1 X40.153 Y71.694 Z-5.231 F152
G1 X40.145 Y71.721 Z-5.236 F152
G1 X40.1 Y71.893 Z-5.277 F152
G1 X40.095 Y71.908 Z-5.286 F152
G1 X40.085 Y71.951 Z-5.29 F152
G1 X40.069 Y72.008 Z-5.309 F152
G1 X40.055 Y72.065 Z-5.341 F152
G1 X40.042 Y72.122 Z-5.366 F152
G1 X40.038 Y72.138 Z-5.372 F152
G1 X40.029 Y72.18 Z-5.382 F152
G1 X39.989 Y72.352 Z-5.455 F152
G1 X39.981 Y72.386 Z-5.47 F152
G1 X39.976 Y72.409 Z-5.474 F152
G1 X39.965 Y72.466 Z-5.508 F152
G1 X39.941 Y72.581 Z-5.578 F152
G1 X39.931 Y72.638 Z-5.605 F152
G1 X39.923 Y72.672 Z-5.629 F152
G1 X39.919 Y72.695 Z-5.641 F152
G1 X39.908 Y72.753 Z-5.668 F152
G1 X39.897 Y72.81 Z-5.697 F152
G1 X39.888 Y72.867 Z-5.74 F152
G1 X39.87 Y72.982 Z-5.818 F152
G1 X39.866 Y73 Z-5.837 F152
G1 X39.86 Y73.039 Z-5.865 F152
G1 X39.842 Y73.154 Z-5.942 F152
G1 X39.833 Y73.211 Z-5.982 F152
G1 X39.825 Y73.268 Z-6.036 F152
G1 X39.819 Y73.326 Z-6.079 F152
G1 X39.812 Y73.383 Z-6.13 F152
G1 X39.809 Y73.4 Z-6.151 F152
G1 X39.804 Y73.44 Z-6.182 F152
G1 X39.79 Y73.555 Z-6.284 F152
G1 X39.784 Y73.612 Z-6.328 F152
G1 X39.778 Y73.669 Z-6.393 F152
G1 X39.773 Y73.727 Z-6.449 F152
G1 X39.768 Y73.784 Z-6.514 F152
G1 X39.759 Y73.899 Z-6.628 F152
G1 X39.753 Y73.956 Z-6.692 F152
G1 X39.752 Y73.977 Z-6.715 F152
G1 X39.749 Y74.013 Z-6.749 F152
G1 X39.745 Y74.071 Z-6.819 F152
G1 X39.732 Y74.357 Z-7.177 F152
G1 X39.729 Y74.414 Z-7.249 F152
G1 X39.728 Y74.443 Z-7.287 F152
G1 Y74.472 Z-7.324 F152
G1 X39.727 Y74.5 Z-7.372 F152
G1 Y74.558 Z-7.452 F152
G1 Y74.586 Z-7.5 F152
G1 Y74.672 Z-7.62 F152
G1 X39.726 Y74.701 Z-7.668 F152
G1 Y74.787 Z-7.788 F152
G1 Y74.815 Z-7.828 F152
G1 Y74.844 Z-7.874 F152
G1 X39.727 Y74.873 Z-7.92 F152
G1 X39.729 Y74.959 Z-8.067 F152
G1 Y74.973 Z-8.096 F152
; MOVEMENT_LEAD_OUT
G1 Y74.992 Z-8.093 F152
G1 Y75.01 Z-8.084 F152
G1 Y75.024 Z-8.07 F152
G1 Y75.033 Z-8.052 F152
G1 Y75.036 Z-8.033 F152
; MOVEMENT_LINK_TRANSITION
G1 Y75.032 Z-8.017 F152
G1 Y75.022 Z-8.004 F152
G1 Y75.007 Z-7.997 F152
G1 Y74.99 F152
G1 Y74.975 Z-8.004 F152
G1 Y74.965 Z-8.017 F152
G1 Y74.961 Z-8.033 F152
G1 Z-8.062 F152
; MOVEMENT_LEAD_IN
G1 Y74.964 Z-8.076 F152
G1 X39.73 Y74.972 Z-8.088 F152
G1 X39.731 Y74.984 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X39.732 Y74.987 F152
G1 X39.733 Y74.994 F152
G1 X39.738 Y75.016 F152
G1 X39.744 Y75.045 F152
G1 X39.75 Y75.066 F152
G1 X39.752 Y75.074 F152
G1 X39.757 Y75.102 F152
G1 X39.77 Y75.159 F152
G1 X39.783 Y75.216 F152
G1 X39.799 Y75.274 F152
G1 X39.85 Y75.446 F152
G1 X39.866 Y75.5 F152
G1 X39.867 Y75.503 F152
G1 X39.884 Y75.56 F152
G1 X39.902 Y75.618 F152
G1 X39.966 Y75.789 F152
G1 X39.989 Y75.847 F152
G1 X40.01 Y75.904 F152
G1 X40.033 Y75.961 F152
G1 X40.038 Y75.974 F152
G1 X40.058 Y76.019 F152
G1 X40.085 Y76.076 F152
G1 X40.095 Y76.097 F152
G1 X40.112 Y76.133 F152
G1 X40.139 Y76.19 F152
G1 X40.153 Y76.218 F152
G1 X40.166 Y76.248 F152
G1 X40.194 Y76.305 F152
G1 X40.21 Y76.336 F152
G1 X40.225 Y76.362 F152
G1 X40.258 Y76.42 F152
G1 X40.267 Y76.435 F152
G1 X40.291 Y76.477 F152
G1 X40.358 Y76.592 F152
G1 X40.382 Y76.633 F152
G1 X40.392 Y76.649 F152
G1 X40.439 Y76.718 F152
G1 X40.471 Y76.763 F152
G1 X40.496 Y76.799 F152
G1 X40.511 Y76.821 F152
G1 X40.551 Y76.878 F152
G1 X40.554 Y76.882 F152
G1 X40.591 Y76.935 F152
G1 X40.611 Y76.961 F152
G1 X40.637 Y76.993 F152
G1 X40.668 Y77.03 F152
G1 X40.685 Y77.05 F152
G1 X40.725 Y77.098 F152
G1 X40.733 Y77.107 F152
G1 X40.782 Y77.165 F152
G1 X40.783 F152
G1 X40.83 Y77.222 F152
G1 X40.84 Y77.233 F152
G1 X40.885 Y77.279 F152
G1 X40.897 Y77.291 F152
G1 X40.944 Y77.336 F152
G1 X40.954 Y77.347 F152
G1 X41.002 Y77.394 F152
G1 X41.012 Y77.404 F152
G1 X41.06 Y77.451 F152
G1 X41.069 Y77.46 F152
G1 X41.121 Y77.508 F152
G1 X41.126 Y77.513 F152
G1 X41.184 Y77.559 F152
G1 X41.191 Y77.566 F152
G1 X41.241 Y77.606 F152
G1 X41.262 Y77.623 F152
G1 X41.298 Y77.652 F152
G1 X41.333 Y77.68 F152
G1 X41.355 Y77.698 F152
G1 X41.407 Y77.738 F152
G1 X41.413 Y77.742 F152
G1 X41.47 Y77.78 F152
G1 X41.527 Y77.817 F152
G1 X41.581 Y77.852 F152
G1 X41.585 Y77.855 F152
G1 X41.642 Y77.892 F152
G1 X41.669 Y77.909 F152
G1 X41.699 Y77.929 F152
G1 X41.756 Y77.961 F152
G1 X41.767 Y77.967 F152
G1 X41.814 Y77.991 F152
G1 X41.871 Y78.02 F152
G1 X41.878 Y78.024 F152
G1 X41.928 Y78.05 F152
G1 X41.985 Y78.079 F152
G1 X41.988 Y78.081 F152
G1 X42.043 Y78.108 F152
G1 X42.1 Y78.132 F152
G1 X42.116 Y78.139 F152
G1 X42.157 Y78.156 F152
G1 X42.215 Y78.178 F152
G1 X42.261 Y78.196 F152
G1 X42.272 Y78.2 F152
G1 X42.386 Y78.245 F152
G1 X42.413 Y78.253 F152
G1 X42.444 Y78.263 F152
G1 X42.558 Y78.295 F152
G1 X42.613 Y78.31 F152
G1 X42.616 Y78.311 F152
G1 X42.73 Y78.344 F152
G1 X42.787 Y78.356 F152
G1 X42.845 Y78.367 F152
G1 X42.852 Y78.368 F152
G1 X42.902 Y78.378 F152
G1 X42.959 Y78.387 F152
G1 X43.017 Y78.398 F152
G1 X43.074 Y78.408 F152
G1 X43.131 Y78.417 F152
G1 X43.188 Y78.422 F152
G1 X43.225 Y78.425 F152
G1 X43.246 Y78.427 F152
G1 X43.303 Y78.432 F152
G1 X43.36 Y78.437 F152
G1 X43.417 Y78.442 F152
G1 X43.475 Y78.447 F152
G1 X43.532 F152
G1 X43.647 F152
G1 X43.704 F152
G1 X43.818 F152
G1 X43.876 Y78.445 F152
G1 X43.933 Y78.439 F152
G1 X43.99 Y78.435 F152
G1 X44.076 Y78.427 F152
G1 X44.087 Y78.425 F152
G1 X44.105 Y78.424 F152
G1 X44.112 Y78.423 F152
G1 X44.115 F152
G1 X44.117 Y78.422 F152
; MOVEMENT_LINK_TRANSITION
G1 X44.118 Y78.423 F152
; MOVEMENT_CUTTING
G1 X44.116 Y78.425 F152
G1 X44.105 Y78.432 F152
G1 X44.093 Y78.439 F152
G1 X44.076 Y78.451 F152
G1 X44.072 Y78.454 F152
G1 X44.048 Y78.471 F152
G1 X44.031 Y78.482 F152
G1 X43.99 Y78.511 F152
G1 X43.951 Y78.54 F152
G1 X43.933 Y78.553 F152
G1 X43.879 Y78.597 F152
G1 X43.876 Y78.6 F152
G1 X43.818 Y78.648 F152
G1 X43.811 Y78.654 F152
G1 X43.761 Y78.703 F152
G1 X43.752 Y78.712 F152
G1 X43.704 Y78.763 F152
G1 X43.698 Y78.769 F152
G1 X43.648 Y78.826 F152
G1 X43.647 Y78.828 F152
G1 X43.605 Y78.883 F152
G1 X43.589 Y78.908 F152
G1 X43.569 Y78.941 F152
G1 X43.532 Y79.003 F152
G1 X43.503 Y79.055 F152
G1 X43.477 Y79.113 F152
G1 X43.475 Y79.118 F152
G1 X43.454 Y79.17 F152
G1 X43.435 Y79.227 F152
G1 X43.421 Y79.285 F152
G1 X43.417 Y79.302 F152
G1 X43.409 Y79.342 F152
G1 X43.401 Y79.399 F152
G1 X43.395 Y79.456 F152
G1 X43.391 Y79.514 F152
G1 Y79.571 F152
G1 X43.393 Y79.628 F152
G1 X43.4 Y79.686 F152
G1 X43.409 Y79.743 F152
G1 X43.417 Y79.784 F152
G1 X43.421 Y79.8 F152
G1 X43.437 Y79.857 F152
G1 X43.457 Y79.915 F152
G1 X43.475 Y79.957 F152
G1 X43.481 Y79.972 F152
G1 X43.509 Y80.029 F152
G1 X43.539 Y80.087 F152
G1 X43.574 Y80.144 F152
G1 X43.589 Y80.166 F152
G1 X43.614 Y80.201 F152
G1 X43.647 Y80.242 F152
G1 X43.661 Y80.259 F152
G1 X43.704 Y80.304 F152
G1 X43.715 Y80.316 F152
G1 X43.761 Y80.358 F152
G1 X43.779 Y80.373 F152
G1 X43.818 Y80.405 F152
G1 X43.855 Y80.43 F152
G1 X43.876 Y80.445 F152
G1 X43.933 Y80.483 F152
G1 X43.94 Y80.488 F152
G1 X43.99 Y80.516 F152
G1 X44.048 Y80.545 F152
G1 X44.105 Y80.569 F152
G1 X44.162 Y80.591 F152
G1 X44.195 Y80.602 F152
G1 X44.219 Y80.61 F152
G1 X44.277 Y80.627 F152
G1 X44.334 Y80.64 F152
G1 X44.391 Y80.653 F152
G1 X44.425 Y80.66 F152
G1 X44.448 Y80.664 F152
G1 X44.506 Y80.672 F152
G1 X44.62 Y80.687 F152
G1 X44.678 Y80.69 F152
G1 X44.907 Y80.701 F152
G1 X44.964 Y80.703 F152
G1 X45.079 F152
G1 X45.136 Y80.702 F152
G1 X45.193 Y80.7 F152
G1 X45.25 Y80.699 F152
G1 X45.308 Y80.697 F152
G1 X45.422 Y80.69 F152
G1 X45.48 Y80.687 F152
G1 X45.709 Y80.673 F152
G1 X45.823 Y80.662 F152
G1 X45.845 Y80.66 F152
G1 X45.88 Y80.657 F152
G1 X45.995 Y80.646 F152
G1 X46.052 Y80.64 F152
G1 X46.11 Y80.635 F152
G1 X46.339 Y80.606 F152
G1 X46.366 Y80.602 F152
G1 X46.396 Y80.599 F152
G1 X46.511 Y80.584 F152
G1 X46.568 Y80.576 F152
G1 X46.625 Y80.567 F152
G1 X46.74 Y80.549 F152
G1 X46.759 Y80.545 F152
G1 X46.797 Y80.54 F152
G1 X46.854 Y80.53 F152
G1 X46.911 Y80.521 F152
G1 X46.969 Y80.511 F152
G1 X47.026 Y80.5 F152
G1 X47.083 Y80.489 F152
G1 X47.086 Y80.488 F152
G1 X47.141 Y80.477 F152
G1 X47.198 Y80.466 F152
G1 X47.37 Y80.431 F152
G1 X47.372 Y80.43 F152
G1 X47.427 Y80.418 F152
G1 X47.599 Y80.378 F152
G1 X47.615 Y80.373 F152
G1 X47.656 Y80.364 F152
G1 X47.771 Y80.334 F152
G1 X47.828 Y80.318 F152
G1 X47.833 Y80.316 F152
G1 X47.885 Y80.302 F152
G1 X48 Y80.27 F152
G1 X48.037 Y80.259 F152
G1 X48.057 Y80.253 F152
G1 X48.114 Y80.234 F152
G1 X48.172 Y80.216 F152
G1 X48.22 Y80.201 F152
G1 X48.229 Y80.199 F152
G1 X48.286 Y80.181 F152
G1 X48.343 Y80.162 F152
G1 X48.392 Y80.144 F152
G1 X48.401 Y80.141 F152
G1 X48.515 Y80.1 F152
G1 X48.553 Y80.087 F152
G1 X48.573 Y80.08 F152
G1 X48.63 Y80.059 F152
G1 X48.687 Y80.036 F152
G1 X48.802 Y79.991 F152
G1 X48.847 Y79.972 F152
G1 X48.859 Y79.968 F152
G1 X48.916 Y79.944 F152
G1 X48.974 Y79.919 F152
G1 X48.983 Y79.915 F152
G1 X49.031 Y79.894 F152
G1 X49.088 Y79.869 F152
G1 X49.114 Y79.857 F152
G1 X49.145 Y79.844 F152
G1 X49.203 Y79.818 F152
G1 X49.238 Y79.8 F152
G1 X49.26 Y79.789 F152
G1 X49.353 Y79.743 F152
G1 X49.374 Y79.733 F152
G1 X49.546 Y79.647 F152
G1 X49.585 Y79.628 F152
G1 X49.604 Y79.619 F152
G1 X49.718 Y79.562 F152
G1 X49.775 Y79.531 F152
G1 X49.805 Y79.514 F152
G1 X49.833 Y79.498 F152
G1 X49.89 Y79.466 F152
G1 X49.908 Y79.456 F152
G1 X49.947 Y79.434 F152
G1 X50.005 Y79.403 F152
G1 X50.01 Y79.399 F152
G1 X50.062 Y79.37 F152
G1 X50.112 Y79.342 F152
G1 X50.119 Y79.338 F152
G1 X50.176 Y79.306 F152
G1 X50.214 Y79.285 F152
G1 X50.234 Y79.274 F152
G1 X50.291 Y79.241 F152
G1 X50.313 Y79.227 F152
G1 X50.348 Y79.207 F152
G1 X50.463 Y79.139 F152
G1 X50.507 Y79.113 F152
G1 X50.52 Y79.105 F152
G1 X50.577 Y79.071 F152
G1 X50.602 Y79.055 F152
G1 X50.635 Y79.036 F152
G1 X50.692 Y79.001 F152
G1 X50.695 Y78.998 F152
G1 X50.749 Y78.966 F152
G1 X50.789 Y78.941 F152
G1 X50.806 Y78.931 F152
G1 X50.864 Y78.894 F152
G1 X50.881 Y78.883 F152
G1 X50.921 Y78.858 F152
G1 X50.972 Y78.826 F152
G1 X50.978 Y78.823 F152
G1 X51.036 Y78.786 F152
G1 X51.062 Y78.769 F152
G1 X51.093 Y78.75 F152
G1 X51.15 Y78.714 F152
G1 X51.154 Y78.712 F152
G1 X51.244 Y78.654 F152
G1 X51.265 Y78.642 F152
G1 X51.322 Y78.605 F152
G1 X51.335 Y78.597 F152
G1 X51.379 Y78.567 F152
G1 X51.421 Y78.54 F152
G1 X51.437 Y78.53 F152
G1 X51.507 Y78.482 F152
G1 X51.551 Y78.453 F152
G1 X51.593 Y78.425 F152
G1 X51.608 Y78.415 F152
G1 X51.679 Y78.368 F152
G1 X51.723 Y78.338 F152
G1 X51.765 Y78.31 F152
G1 X51.78 Y78.301 F152
G1 X51.851 Y78.253 F152
G1 X51.895 Y78.223 F152
G1 X51.933 Y78.196 F152
G1 X51.952 Y78.183 F152
G1 X52.009 Y78.143 F152
G1 X52.016 Y78.139 F152
G1 X52.067 Y78.103 F152
G1 X52.098 Y78.081 F152
G1 X52.124 Y78.062 F152
G1 X52.178 Y78.024 F152
G1 X52.181 Y78.021 F152
G1 X52.238 Y77.98 F152
G1 X52.257 Y77.967 F152
G1 X52.296 Y77.939 F152
G1 X52.336 Y77.909 F152
G1 X52.353 Y77.898 F152
G1 X52.468 Y77.812 F152
G1 X52.49 Y77.795 F152
G1 X52.567 Y77.738 F152
G1 X52.639 Y77.682 F152
G1 X52.641 Y77.68 F152
G1 X52.697 Y77.637 F152
G1 X52.715 Y77.623 F152
G1 X52.754 Y77.592 F152
G1 X52.789 Y77.566 F152
G1 X52.86 Y77.508 F152
G1 X52.868 Y77.501 F152
G1 X52.983 Y77.408 F152
G1 X53.001 Y77.394 F152
G1 X53.04 Y77.361 F152
G1 X53.07 Y77.336 F152
G1 X53.098 Y77.312 F152
G1 X53.137 Y77.279 F152
G1 X53.204 Y77.222 F152
G1 X53.212 Y77.216 F152
G1 X53.269 Y77.165 F152
G1 X53.327 Y77.111 F152
G1 X53.33 Y77.107 F152
G1 X53.384 Y77.058 F152
G1 X53.393 Y77.05 F152
G1 X53.441 Y77.005 F152
G1 X53.455 Y76.993 F152
G1 X53.499 Y76.952 F152
G1 X53.517 Y76.935 F152
G1 X53.556 Y76.9 F152
G1 X53.579 Y76.878 F152
G1 X53.613 Y76.845 F152
G1 X53.636 Y76.821 F152
G1 X53.694 Y76.763 F152
G1 X53.728 Y76.729 F152
G1 X53.75 Y76.706 F152
G1 X53.805 Y76.649 F152
G1 X53.842 Y76.609 F152
G1 X53.857 Y76.592 F152
G1 X53.9 Y76.547 F152
G1 X53.911 Y76.534 F152
G1 X53.957 Y76.484 F152
G1 X53.963 Y76.477 F152
G1 X54.014 Y76.42 F152
G1 X54.066 Y76.362 F152
G1 X54.071 Y76.356 F152
G1 X54.116 Y76.305 F152
G1 X54.129 Y76.29 F152
G1 X54.165 Y76.248 F152
G1 X54.186 Y76.224 F152
G1 X54.215 Y76.19 F152
G1 X54.263 Y76.133 F152
G1 X54.3 Y76.087 F152
G1 X54.309 Y76.076 F152
G1 X54.356 Y76.019 F152
G1 X54.358 Y76.016 F152
G1 X54.403 Y75.961 F152
G1 X54.415 Y75.945 F152
G1 X54.449 Y75.904 F152
G1 X54.472 Y75.874 F152
G1 X54.496 Y75.847 F152
G1 X54.53 Y75.804 F152
G1 X54.541 Y75.789 F152
G1 X54.587 Y75.732 F152
G1 X54.63 Y75.675 F152
G1 X54.644 Y75.655 F152
G1 X54.672 Y75.618 F152
G1 X54.758 Y75.503 F152
G1 X54.759 Y75.501 F152
G1 X54.8 Y75.446 F152
G1 X54.843 Y75.388 F152
G1 X54.873 Y75.347 F152
G1 X54.885 Y75.331 F152
G1 X54.925 Y75.274 F152
G1 X54.931 Y75.265 F152
G1 X54.964 Y75.216 F152
G1 X54.988 Y75.181 F152
G1 X55.002 Y75.159 F152
G1 X55.041 Y75.102 F152
G1 X55.045 Y75.096 F152
G1 X55.08 Y75.045 F152
G1 X55.102 Y75.011 F152
G1 X55.118 Y74.987 F152
G1 X55.156 Y74.93 F152
G1 X55.16 Y74.924 F152
G1 X55.192 Y74.873 F152
G1 X55.227 Y74.815 F152
G1 X55.263 Y74.758 F152
G1 X55.274 Y74.738 F152
G1 X55.296 Y74.701 F152
G1 X55.329 Y74.643 F152
G1 X55.331 Y74.639 F152
G1 X55.362 Y74.586 F152
G1 X55.389 Y74.538 F152
G1 X55.394 Y74.529 F152
G1 X55.424 Y74.472 F152
G1 X55.454 Y74.414 F152
G1 X55.484 Y74.357 F152
G1 X55.503 Y74.318 F152
G1 X55.512 Y74.3 F152
G1 X55.54 Y74.242 F152
G1 X55.561 Y74.198 F152
G1 X55.567 Y74.185 F152
G1 X55.594 Y74.128 F152
G1 X55.642 Y74.013 F152
G1 X55.689 Y73.899 F152
G1 X55.71 Y73.841 F152
G1 X55.731 Y73.784 F152
G1 X55.732 Y73.777 F152
G1 X55.75 Y73.727 F152
G1 X55.771 Y73.669 F152
G1 X55.788 Y73.612 F152
G1 X55.79 Y73.605 F152
G1 X55.805 Y73.555 F152
G1 X55.822 Y73.498 F152
G1 X55.838 Y73.44 F152
G1 X55.881 Y73.268 F152
G1 X55.894 Y73.211 F152
G1 X55.903 Y73.154 F152
G1 X55.904 Y73.147 F152
G1 X55.914 Y73.096 F152
G1 X55.924 Y73.039 F152
G1 X55.935 Y72.982 F152
G1 X55.954 Y72.867 F152
G1 X55.962 Y72.82 F152
G1 X55.963 Y72.81 F152
G1 X55.996 Y72.581 F152
G1 X56.005 Y72.523 F152
G1 X56.013 Y72.466 F152
G1 X56.019 Y72.417 F152
G1 X56.021 Y72.409 F152
G1 X56.037 Y72.294 F152
G1 X56.047 Y72.237 F152
G1 X56.074 Y72.122 F152
G1 X56.089 Y72.065 F152
G1 X56.107 Y72.008 F152
G1 X56.132 Y71.951 F152
G1 X56.133 Y71.945 F152
G1 X56.159 Y71.893 F152
G1 X56.193 Y71.836 F152
G1 X56.233 Y71.779 F152
G1 X56.248 Y71.759 F152
G1 X56.28 Y71.721 F152
G1 X56.305 Y71.694 F152
G1 X56.334 Y71.664 F152
G1 X56.363 Y71.637 F152
G1 X56.395 Y71.607 F152
G1 X56.42 Y71.587 F152
G1 X56.466 Y71.549 F152
G1 X56.477 Y71.541 F152
G1 X56.534 Y71.501 F152
G1 X56.548 Y71.492 F152
G1 X56.592 Y71.463 F152
G1 X56.639 Y71.435 F152
G1 X56.649 Y71.429 F152
G1 X56.706 Y71.397 F152
G1 X56.743 Y71.378 F152
G1 X56.763 Y71.367 F152
G1 X56.821 Y71.339 F152
G1 X56.861 Y71.32 F152
G1 X56.935 Y71.289 F152
G1 X56.993 Y71.267 F152
G1 X57.003 Y71.263 F152
G1 X57.05 Y71.245 F152
G1 X57.107 Y71.224 F152
G1 X57.155 Y71.206 F152
G1 X57.222 Y71.181 F152
G1 X57.279 Y71.164 F152
G1 X57.333 Y71.148 F152
G1 X57.336 Y71.147 F152
G1 X57.508 Y71.096 F152
G1 X57.525 Y71.091 F152
G1 X57.565 Y71.079 F152
G1 X57.623 Y71.062 F152
G1 X57.725 Y71.034 F152
G1 X57.737 Y71.031 F152
G1 X57.794 Y71.015 F152
G1 X57.909 Y70.985 F152
G1 X57.939 Y70.976 F152
G1 X57.966 Y70.969 F152
G1 X58.138 Y70.924 F152
G1 X58.152 Y70.919 F152
G1 X58.195 Y70.907 F152
G1 X58.253 Y70.891 F152
G1 X58.31 Y70.874 F152
G1 X58.35 Y70.862 F152
G1 X58.367 Y70.857 F152
G1 X58.425 Y70.84 F152
G1 X58.482 Y70.822 F152
G1 X58.531 Y70.805 F152
G1 X58.539 Y70.803 F152
G1 X58.596 Y70.784 F152
G1 X58.654 Y70.764 F152
G1 X58.7 Y70.747 F152
G1 X58.711 Y70.743 F152
G1 X58.883 Y70.676 F152
G1 X58.94 Y70.652 F152
G1 X58.983 Y70.633 F152
G1 X58.997 Y70.626 F152
G1 X59.055 Y70.599 F152
G1 X59.102 Y70.575 F152
G1 X59.112 Y70.571 F152
G1 X59.169 Y70.543 F152
G1 X59.218 Y70.518 F152
G1 X59.284 Y70.479 F152
G1 X59.313 Y70.461 F152
G1 X59.341 Y70.445 F152
G1 X59.398 Y70.41 F152
G1 X59.409 Y70.404 F152
G1 X59.456 Y70.375 F152
G1 X59.496 Y70.346 F152
G1 X59.513 Y70.334 F152
G1 X59.57 Y70.29 F152
G1 X59.572 Y70.289 F152
G1 X59.627 Y70.247 F152
G1 X59.647 Y70.232 F152
G1 X59.685 Y70.202 F152
G1 X59.718 Y70.174 F152
G1 X59.742 Y70.153 F152
G1 X59.779 Y70.117 F152
G1 X59.799 Y70.097 F152
G1 X59.838 Y70.06 F152
G1 X59.857 Y70.041 F152
G1 X59.896 Y70.002 F152
G1 X59.914 Y69.985 F152
G1 X59.951 Y69.945 F152
G1 X59.971 Y69.92 F152
G1 X59.997 Y69.888 F152
G1 X60.043 Y69.831 F152
G1 X60.086 Y69.776 F152
G1 X60.088 Y69.773 F152
G1 X60.131 Y69.716 F152
G1 X60.143 Y69.699 F152
G1 X60.169 Y69.659 F152
G1 X60.2 Y69.608 F152
G1 X60.205 Y69.601 F152
G1 X60.24 Y69.544 F152
G1 X60.257 Y69.515 F152
G1 X60.274 Y69.487 F152
G1 X60.306 Y69.429 F152
G1 X60.334 Y69.372 F152
G1 X60.362 Y69.315 F152
G1 X60.372 Y69.293 F152
G1 X60.39 Y69.258 F152
G1 X60.417 Y69.2 F152
G1 X60.429 Y69.168 F152
G1 X60.439 Y69.143 F152
G1 X60.462 Y69.086 F152
G1 X60.507 Y68.971 F152
G1 X60.544 Y68.865 F152
G1 X60.547 Y68.856 F152
G1 X60.567 Y68.799 F152
G1 X60.601 Y68.695 F152
G1 X60.605 Y68.685 F152
G1 X60.624 Y68.627 F152
G1 X60.643 Y68.57 F152
G1 X60.658 Y68.522 F152
G1 X60.662 Y68.513 F152
G1 X60.7 Y68.398 F152
G1 X60.716 Y68.352 F152
G1 X60.72 Y68.341 F152
G1 X60.742 Y68.284 F152
G1 X60.764 Y68.226 F152
G1 X60.773 Y68.206 F152
G1 X60.79 Y68.169 F152
G1 X60.816 Y68.112 F152
G1 X60.83 Y68.085 F152
G1 X60.847 Y68.054 F152
G1 X60.882 Y67.997 F152
G1 X60.888 Y67.989 F152
G1 X60.922 Y67.94 F152
G1 X60.945 Y67.916 F152
G1 X60.978 Y67.882 F152
G1 X61.002 Y67.862 F152
G1 X61.031 Y67.844 F152
G1 X61.059 Y67.83 F152
G1 X61.07 Y67.825 F152
G1 X61.117 Y67.812 F152
G1 X61.174 Y67.802 F152
G1 X61.231 Y67.796 F152
G1 X61.346 Y67.798 F152
G1 X61.46 Y67.811 F152
G1 X61.518 Y67.819 F152
G1 X61.553 Y67.825 F152
G1 X61.575 Y67.83 F152
G1 X61.632 Y67.84 F152
G1 X61.689 Y67.852 F152
G1 X61.819 Y67.882 F152
G1 X61.861 Y67.893 F152
G1 X61.919 Y67.908 F152
G1 X62.033 Y67.94 F152
G1 X62.034 F152
G1 X62.09 Y67.956 F152
G1 X62.148 Y67.972 F152
G1 X62.205 Y67.989 F152
G1 X62.233 Y67.997 F152
G1 X62.262 Y68.006 F152
G1 X62.32 Y68.023 F152
G1 X62.377 Y68.041 F152
G1 X62.422 Y68.054 F152
G1 X62.606 Y68.112 F152
G1 X62.607 F152
G1 X62.663 Y68.13 F152
G1 X62.778 Y68.167 F152
G1 X62.785 Y68.169 F152
G1 X62.835 Y68.186 F152
G1 X62.892 Y68.205 F152
G1 X62.95 Y68.224 F152
G1 X62.957 Y68.226 F152
G1 X63.007 Y68.243 F152
G1 X63.064 Y68.263 F152
G1 X63.121 Y68.284 F152
G1 X63.122 F152
G1 X63.179 Y68.304 F152
G1 X63.293 Y68.345 F152
G1 X63.408 Y68.39 F152
G1 X63.429 Y68.398 F152
G1 X63.465 Y68.413 F152
G1 X63.522 Y68.438 F152
G1 X63.557 Y68.455 F152
G1 X63.58 Y68.467 F152
G1 X63.637 Y68.496 F152
G1 X63.672 Y68.513 F152
G1 X63.694 Y68.524 F152
G1 X63.752 Y68.562 F152
G1 X63.809 Y68.599 F152
G1 X63.846 Y68.627 F152
G1 X63.866 Y68.645 F152
G1 X63.904 Y68.685 F152
G1 X63.923 Y68.709 F152
G1 X63.947 Y68.742 F152
G1 X63.979 Y68.799 F152
G1 X63.981 Y68.802 F152
G1 X64.001 Y68.856 F152
G1 X64.023 Y68.914 F152
G1 X64.038 Y68.962 F152
G1 X64.04 Y68.971 F152
G1 X64.067 Y69.086 F152
G1 X64.075 Y69.143 F152
G1 X64.087 Y69.258 F152
G1 X64.092 Y69.315 F152
G1 X64.093 Y69.372 F152
G1 X64.094 Y69.429 F152
G1 X64.095 Y69.445 F152
G1 X64.096 Y69.487 F152
G1 X64.095 Y69.544 F152
G1 Y69.55 F152
G1 X64.092 Y69.601 F152
G1 X64.089 Y69.659 F152
G1 X64.084 Y69.773 F152
G1 X64.078 Y69.831 F152
G1 X64.072 Y69.888 F152
G1 X64.067 Y69.945 F152
G1 X64.06 Y70.002 F152
G1 X64.046 Y70.117 F152
G1 X64.038 Y70.174 F152
G1 Y70.178 F152
G1 X64.031 Y70.232 F152
G1 X64.015 Y70.346 F152
G1 X64.006 Y70.404 F152
G1 X63.998 Y70.461 F152
G1 X63.989 Y70.518 F152
G1 X63.981 Y70.575 F152
G1 Y70.576 F152
G1 X63.972 Y70.633 F152
G1 X63.964 Y70.69 F152
G1 X63.955 Y70.747 F152
G1 X63.947 Y70.805 F152
G1 X63.938 Y70.862 F152
G1 X63.93 Y70.919 F152
G1 X63.923 Y70.971 F152
G1 X63.922 Y70.976 F152
G1 X63.914 Y71.034 F152
G1 X63.9 Y71.148 F152
G1 X63.892 Y71.206 F152
G1 X63.886 Y71.263 F152
G1 X63.88 Y71.32 F152
G1 X63.874 Y71.378 F152
G1 X63.869 Y71.435 F152
G1 X63.866 Y71.465 F152
G1 X63.863 Y71.492 F152
G1 X63.857 Y71.549 F152
G1 X63.853 Y71.607 F152
G1 X63.842 Y71.779 F152
G1 X63.839 Y71.836 F152
G1 X63.832 Y71.951 F152
G1 X63.828 Y72.18 F152
G1 Y72.237 F152
G1 Y72.294 F152
G1 Y72.352 F152
G1 X63.831 Y72.466 F152
G1 X63.834 Y72.523 F152
G1 X63.837 Y72.638 F152
G1 X63.84 Y72.695 F152
G1 X63.844 Y72.753 F152
G1 X63.853 Y72.867 F152
G1 X63.858 Y72.925 F152
G1 X63.862 Y72.982 F152
G1 X63.866 Y73.015 F152
G1 X63.868 Y73.039 F152
G1 X63.872 Y73.096 F152
G1 X63.887 Y73.211 F152
G1 X63.895 Y73.268 F152
G1 X63.902 Y73.326 F152
G1 X63.91 Y73.383 F152
G1 X63.917 Y73.44 F152
G1 X63.923 Y73.482 F152
G1 X63.925 Y73.498 F152
G1 X63.955 Y73.669 F152
G1 X63.965 Y73.727 F152
G1 X63.975 Y73.784 F152
G1 X63.981 Y73.811 F152
G1 X63.986 Y73.841 F152
G1 X63.996 Y73.899 F152
G1 X64.033 Y74.071 F152
G1 X64.038 Y74.088 F152
G1 X64.046 Y74.128 F152
G1 X64.071 Y74.242 F152
G1 X64.084 Y74.3 F152
G1 X64.1 Y74.357 F152
G1 X64.114 Y74.414 F152
G1 X64.129 Y74.472 F152
G1 X64.144 Y74.529 F152
G1 X64.152 Y74.562 F152
G1 X64.159 Y74.586 F152
G1 X64.173 Y74.643 F152
G1 X64.189 Y74.701 F152
G1 X64.206 Y74.758 F152
G1 X64.21 Y74.77 F152
G1 X64.223 Y74.815 F152
G1 X64.239 Y74.873 F152
G1 X64.256 Y74.93 F152
G1 X64.267 Y74.965 F152
G1 X64.273 Y74.987 F152
G1 X64.29 Y75.045 F152
G1 X64.309 Y75.102 F152
G1 X64.324 Y75.148 F152
G1 X64.328 Y75.159 F152
G1 X64.403 Y75.388 F152
G1 X64.424 Y75.446 F152
G1 X64.439 Y75.488 F152
G1 X64.444 Y75.503 F152
G1 X64.485 Y75.618 F152
G1 X64.496 Y75.646 F152
G1 X64.506 Y75.675 F152
G1 X64.527 Y75.732 F152
G1 X64.549 Y75.789 F152
G1 X64.553 Y75.799 F152
G1 X64.572 Y75.847 F152
G1 X64.595 Y75.904 F152
G1 X64.611 Y75.944 F152
G1 X64.617 Y75.961 F152
G1 X64.639 Y76.019 F152
G1 X64.663 Y76.076 F152
G1 X64.668 Y76.088 F152
G1 X64.687 Y76.133 F152
G1 X64.713 Y76.19 F152
G1 X64.763 Y76.305 F152
G1 X64.783 Y76.348 F152
G1 X64.839 Y76.477 F152
G1 X64.84 Y76.478 F152
G1 X64.865 Y76.534 F152
G1 X64.89 Y76.592 F152
G1 X64.897 Y76.607 F152
G1 X64.915 Y76.649 F152
G1 X64.941 Y76.706 F152
G1 X64.954 Y76.735 F152
G1 X64.997 Y76.821 F152
G1 X65.012 Y76.849 F152
G1 X65.026 Y76.878 F152
G1 X65.055 Y76.935 F152
G1 X65.069 Y76.963 F152
G1 X65.083 Y76.993 F152
G1 X65.113 Y77.05 F152
G1 X65.227 Y77.279 F152
G1 X65.257 Y77.336 F152
G1 X65.32 Y77.451 F152
G1 X65.384 Y77.566 F152
G1 X65.413 Y77.618 F152
G1 X65.415 Y77.623 F152
G1 X65.448 Y77.68 F152
G1 X65.47 Y77.72 F152
G1 X65.479 Y77.738 F152
G1 X65.543 Y77.852 F152
G1 X65.575 Y77.909 F152
G1 X65.608 Y77.967 F152
G1 X65.676 Y78.081 F152
G1 X65.699 Y78.121 F152
G1 X65.71 Y78.139 F152
G1 X65.744 Y78.196 F152
G1 X65.756 Y78.217 F152
G1 X65.778 Y78.253 F152
G1 X65.813 Y78.31 F152
G1 X65.814 Y78.311 F152
G1 X65.848 Y78.368 F152
G1 X65.883 Y78.425 F152
G1 X65.919 Y78.482 F152
G1 X65.928 Y78.498 F152
G1 X65.954 Y78.54 F152
G1 X65.985 Y78.589 F152
G1 X65.99 Y78.597 F152
G1 X66.173 Y78.883 F152
G1 X66.249 Y78.998 F152
G1 X66.272 Y79.034 F152
G1 X66.286 Y79.055 F152
G1 X66.324 Y79.113 F152
G1 X66.329 Y79.121 F152
G1 X66.361 Y79.17 F152
G1 X66.386 Y79.208 F152
G1 X66.399 Y79.227 F152
G1 X66.438 Y79.285 F152
G1 X66.477 Y79.342 F152
G1 X66.501 Y79.378 F152
G1 X66.515 Y79.399 F152
G1 X66.554 Y79.456 F152
G1 X66.558 Y79.463 F152
G1 X66.592 Y79.514 F152
G1 X66.615 Y79.547 F152
G1 X66.632 Y79.571 F152
G1 X66.671 Y79.628 F152
G1 X66.673 Y79.63 F152
G1 X66.711 Y79.686 F152
G1 X66.73 Y79.713 F152
G1 X66.751 Y79.743 F152
G1 X66.787 Y79.797 F152
G1 X66.79 Y79.8 F152
G1 X66.829 Y79.857 F152
G1 X66.845 Y79.879 F152
G1 X66.87 Y79.915 F152
G1 X66.902 Y79.96 F152
G1 X66.91 Y79.972 F152
G1 X66.95 Y80.029 F152
G1 X66.959 Y80.042 F152
G1 X66.99 Y80.087 F152
G1 X67.016 Y80.123 F152
G1 X67.031 Y80.144 F152
G1 X67.071 Y80.201 F152
G1 X67.074 Y80.205 F152
G1 X67.111 Y80.259 F152
G1 X67.131 Y80.285 F152
G1 X67.152 Y80.316 F152
G1 X67.188 Y80.366 F152
G1 X67.194 Y80.373 F152
G1 X67.235 Y80.43 F152
G1 X67.275 Y80.488 F152
G1 X67.303 Y80.526 F152
G1 X67.316 Y80.545 F152
G1 X67.357 Y80.602 F152
G1 X67.36 Y80.606 F152
G1 X67.399 Y80.66 F152
G1 X67.417 Y80.685 F152
G1 X67.441 Y80.717 F152
G1 X67.475 Y80.764 F152
G1 X67.482 Y80.774 F152
G1 X67.523 Y80.832 F152
G1 X67.532 Y80.843 F152
G1 X67.564 Y80.889 F152
G1 X67.589 Y80.923 F152
G1 X67.606 Y80.946 F152
G1 X67.646 Y81.002 F152
G1 X67.647 Y81.003 F152
G1 X67.689 Y81.061 F152
G1 X67.704 Y81.08 F152
G1 X67.732 Y81.118 F152
G1 X67.773 Y81.175 F152
G1 X67.815 Y81.233 F152
G1 X67.818 Y81.237 F152
G1 X67.857 Y81.29 F152
G1 X67.876 Y81.316 F152
G1 X67.898 Y81.347 F152
G1 X67.933 Y81.395 F152
G1 X67.982 Y81.462 F152
G1 X67.99 Y81.473 F152
G1 X68.024 Y81.519 F152
G1 X68.047 Y81.551 F152
G1 X68.066 Y81.576 F152
G1 X68.105 Y81.629 F152
G1 X68.108 Y81.634 F152
G1 X68.15 Y81.691 F152
G1 X68.192 Y81.748 F152
G1 X68.219 Y81.786 F152
G1 X68.234 Y81.806 F152
G1 X68.276 Y81.863 F152
G1 X68.277 Y81.864 F152
G1 X68.318 Y81.92 F152
G1 X68.334 Y81.942 F152
G1 X68.36 Y81.977 F152
G1 X68.391 Y82.02 F152
G1 X68.402 Y82.035 F152
G1 X68.444 Y82.092 F152
G1 X68.448 Y82.097 F152
G1 X68.486 Y82.149 F152
G1 X68.563 Y82.254 F152
G1 X68.612 Y82.321 F152
G1 X68.62 Y82.332 F152
G1 X68.654 Y82.379 F152
G1 X68.677 Y82.411 F152
G1 X68.696 Y82.436 F152
G1 X68.735 Y82.489 F152
G1 X68.738 Y82.493 F152
G1 X68.78 Y82.55 F152
G1 X68.822 Y82.608 F152
G1 X68.849 Y82.645 F152
G1 X68.864 Y82.665 F152
G1 X68.906 Y82.722 F152
G1 X68.907 Y82.724 F152
G1 X68.947 Y82.78 F152
G1 X68.964 Y82.802 F152
G1 X68.989 Y82.837 F152
G1 X69.073 Y82.952 F152
G1 X69.078 Y82.96 F152
G1 X69.136 Y83.038 F152
G1 X69.155 Y83.066 F152
G1 X69.193 Y83.118 F152
G1 X69.197 Y83.123 F152
G1 X69.239 Y83.181 F152
G1 X69.28 Y83.238 F152
G1 X69.308 Y83.276 F152
G1 X69.321 Y83.295 F152
G1 X69.363 Y83.353 F152
G1 X69.365 Y83.355 F152
G1 X69.404 Y83.41 F152
G1 X69.422 Y83.434 F152
G1 X69.445 Y83.467 F152
G1 X69.479 Y83.514 F152
G1 X69.487 Y83.524 F152
G1 X69.529 Y83.582 F152
G1 X69.537 Y83.593 F152
G1 X69.57 Y83.639 F152
G1 X69.594 Y83.672 F152
G1 X69.612 Y83.696 F152
G1 X69.651 Y83.752 F152
G1 X69.652 Y83.754 F152
G1 X69.693 Y83.811 F152
G1 X69.709 Y83.832 F152
G1 X69.734 Y83.868 F152
G1 X69.766 Y83.912 F152
G1 X69.776 Y83.926 F152
G1 X69.816 Y83.983 F152
G1 X69.823 Y83.993 F152
G1 X69.857 Y84.04 F152
G1 X69.88 Y84.072 F152
G1 X69.897 Y84.097 F152
G1 X69.938 Y84.154 F152
G1 Y84.155 F152
G1 X69.979 Y84.212 F152
G1 X69.995 Y84.235 F152
G1 X70.019 Y84.269 F152
G1 X70.052 Y84.317 F152
G1 X70.059 Y84.327 F152
G1 X70.1 Y84.384 F152
G1 X70.109 Y84.398 F152
G1 X70.14 Y84.441 F152
G1 X70.167 Y84.48 F152
G1 X70.179 Y84.499 F152
G1 X70.22 Y84.556 F152
G1 X70.224 Y84.563 F152
G1 X70.281 Y84.645 F152
G1 X70.298 Y84.67 F152
G1 X70.339 Y84.728 F152
G1 X70.378 Y84.785 F152
G1 X70.396 Y84.812 F152
G1 X70.416 Y84.842 F152
G1 X70.453 Y84.896 F152
G1 X70.456 Y84.9 F152
G1 X70.494 Y84.957 F152
G1 X70.51 Y84.98 F152
G1 X70.533 Y85.014 F152
G1 X70.568 Y85.065 F152
G1 X70.572 Y85.072 F152
G1 X70.611 Y85.129 F152
G1 X70.625 Y85.15 F152
G1 X70.648 Y85.186 F152
G1 X70.682 Y85.237 F152
G1 X70.687 Y85.243 F152
G1 X70.762 Y85.358 F152
G1 X70.8 Y85.415 F152
G1 X70.837 Y85.473 F152
G1 X70.854 Y85.499 F152
G1 X70.874 Y85.53 F152
G1 X70.91 Y85.587 F152
G1 X70.911 Y85.588 F152
G1 X70.947 Y85.644 F152
G1 X70.969 Y85.678 F152
G1 X70.984 Y85.702 F152
G1 X71.021 Y85.759 F152
G1 X71.026 Y85.767 F152
G1 X71.056 Y85.816 F152
G1 X71.092 Y85.874 F152
G1 X71.127 Y85.931 F152
G1 X71.163 Y85.988 F152
G1 X71.198 Y86.045 F152
G1 Y86.046 F152
G1 X71.234 Y86.103 F152
G1 X71.255 Y86.14 F152
G1 X71.267 Y86.16 F152
G1 X71.301 Y86.217 F152
G1 X71.312 Y86.236 F152
G1 X71.335 Y86.275 F152
G1 X71.369 Y86.332 F152
G1 X71.37 Y86.334 F152
G1 X71.402 Y86.389 F152
G1 X71.427 Y86.431 F152
G1 X71.435 Y86.447 F152
G1 X71.466 Y86.504 F152
G1 X71.484 Y86.536 F152
G1 X71.498 Y86.561 F152
G1 X71.529 Y86.619 F152
G1 X71.541 Y86.64 F152
G1 X71.561 Y86.676 F152
G1 X71.592 Y86.733 F152
G1 X71.599 Y86.745 F152
G1 X71.655 Y86.848 F152
G1 X71.656 Y86.849 F152
G1 X71.686 Y86.905 F152
G1 X71.713 Y86.955 F152
G1 X71.717 Y86.962 F152
G1 X71.745 Y87.02 F152
G1 X71.773 Y87.077 F152
G1 X71.801 Y87.134 F152
G1 X71.83 Y87.192 F152
G1 X71.857 Y87.249 F152
G1 X71.886 Y87.306 F152
G1 X71.914 Y87.363 F152
G1 X71.942 Y87.42 F152
G1 Y87.421 F152
G1 X71.968 Y87.478 F152
G1 X71.993 Y87.535 F152
G1 X72 Y87.551 F152
G1 X72.018 Y87.593 F152
G1 X72.042 Y87.65 F152
G1 X72.057 Y87.684 F152
G1 X72.067 Y87.707 F152
G1 X72.092 Y87.764 F152
G1 X72.114 Y87.817 F152
G1 X72.116 Y87.822 F152
G1 X72.141 Y87.879 F152
G1 X72.165 Y87.936 F152
G1 X72.172 Y87.95 F152
G1 X72.187 Y87.994 F152
G1 X72.208 Y88.051 F152
G1 X72.27 Y88.223 F152
G1 X72.286 Y88.266 F152
G1 X72.291 Y88.28 F152
G1 X72.312 Y88.337 F152
G1 X72.333 Y88.395 F152
G1 X72.343 Y88.424 F152
G1 X72.353 Y88.452 F152
G1 X72.373 Y88.509 F152
G1 X72.391 Y88.567 F152
G1 X72.401 Y88.599 F152
G1 X72.408 Y88.624 F152
G1 X72.444 Y88.739 F152
G1 X72.458 Y88.788 F152
G1 X72.46 Y88.796 F152
G1 X72.476 Y88.853 F152
G1 X72.491 Y88.91 F152
G1 X72.507 Y88.968 F152
G1 X72.515 Y88.997 F152
G1 X72.522 Y89.025 F152
G1 X72.536 Y89.082 F152
G1 X72.55 Y89.14 F152
G1 X72.564 Y89.197 F152
G1 X72.572 Y89.234 F152
G1 X72.577 Y89.254 F152
G1 X72.59 Y89.311 F152
G1 X72.625 Y89.483 F152
G1 X72.63 Y89.503 F152
G1 X72.637 Y89.541 F152
G1 X72.649 Y89.598 F152
G1 X72.658 Y89.655 F152
G1 X72.667 Y89.713 F152
G1 X72.687 Y89.827 F152
G1 X72.696 Y89.884 F152
G1 X72.704 Y89.942 F152
G1 X72.733 Y90.171 F152
G1 X72.739 Y90.228 F152
G1 X72.743 Y90.286 F152
G1 X72.744 F152
G1 X72.749 Y90.343 F152
G1 X72.76 Y90.457 F152
G1 X72.763 Y90.515 F152
G1 X72.766 Y90.572 F152
G1 X72.769 Y90.629 F152
G1 X72.775 Y90.744 F152
G1 X72.777 Y90.801 F152
G1 Y90.859 F152
G1 Y90.916 F152
G1 X72.778 Y90.973 F152
G1 Y91.03 F152
G1 X72.779 Y91.088 F152
G1 X72.776 Y91.202 F152
G1 X72.773 Y91.26 F152
G1 X72.771 Y91.317 F152
G1 X72.768 Y91.374 F152
G1 X72.767 Y91.431 F152
G1 X72.762 Y91.489 F152
G1 X72.751 Y91.603 F152
G1 X72.747 Y91.661 F152
G1 X72.744 Y91.693 F152
G1 X72.742 Y91.718 F152
G1 X72.736 Y91.775 F152
G1 X72.729 Y91.833 F152
G1 X72.689 Y92.119 F152
G1 X72.687 Y92.129 F152
G1 X72.677 Y92.176 F152
G1 X72.656 Y92.291 F152
G1 X72.644 Y92.348 F152
G1 X72.633 Y92.406 F152
G1 X72.63 Y92.425 F152
G1 X72.621 Y92.463 F152
G1 X72.607 Y92.52 F152
G1 X72.579 Y92.635 F152
G1 X72.572 Y92.662 F152
G1 X72.564 Y92.692 F152
G1 X72.55 Y92.749 F152
G1 X72.534 Y92.807 F152
G1 X72.517 Y92.864 F152
G1 X72.515 Y92.87 F152
G1 X72.499 Y92.921 F152
G1 X72.465 Y93.036 F152
G1 X72.458 Y93.059 F152
G1 X72.447 Y93.093 F152
G1 X72.406 Y93.208 F152
G1 X72.401 Y93.223 F152
G1 X72.385 Y93.265 F152
G1 X72.344 Y93.38 F152
G1 X72.343 Y93.382 F152
G1 X72.322 Y93.437 F152
G1 X72.286 Y93.522 F152
G1 X72.249 Y93.609 F152
G1 X72.229 Y93.659 F152
G1 X72.225 Y93.666 F152
G1 X72.201 Y93.723 F152
G1 X72.174 Y93.781 F152
G1 X72.172 Y93.786 F152
G1 X72.119 Y93.895 F152
G1 X72.114 Y93.906 F152
G1 X72.092 Y93.953 F152
G1 X72.064 Y94.01 F152
G1 X72.057 Y94.025 F152
G1 X72.035 Y94.067 F152
G1 X72.003 Y94.124 F152
G1 X72 Y94.132 F152
G1 X71.972 Y94.182 F152
G1 X71.942 Y94.239 F152
G1 X71.885 Y94.342 F152
G1 X71.843 Y94.411 F152
G1 X71.828 Y94.437 F152
G1 X71.809 Y94.468 F152
G1 X71.774 Y94.526 F152
G1 X71.771 Y94.532 F152
G1 X71.74 Y94.583 F152
G1 X71.713 Y94.627 F152
G1 X71.666 Y94.697 F152
G1 X71.656 Y94.713 F152
G1 X71.627 Y94.755 F152
G1 X71.599 Y94.799 F152
G1 X71.551 Y94.869 F152
G1 X71.541 Y94.885 F152
G1 X71.512 Y94.927 F152
G1 X71.484 Y94.965 F152
G1 X71.47 Y94.984 F152
G1 X71.429 Y95.041 F152
G1 X71.427 Y95.043 F152
G1 X71.387 Y95.098 F152
G1 X71.37 Y95.122 F152
G1 X71.345 Y95.156 F152
G1 X71.312 Y95.199 F152
G1 X71.301 Y95.213 F152
G1 X71.209 Y95.328 F152
G1 X71.198 Y95.342 F152
G1 X71.164 Y95.385 F152
G1 X71.14 Y95.415 F152
G1 X71.118 Y95.442 F152
G1 X71.083 Y95.483 F152
G1 X71.069 Y95.5 F152
G1 X71.026 Y95.55 F152
G1 X70.97 Y95.614 F152
G1 X70.969 Y95.616 F152
G1 X70.92 Y95.671 F152
G1 X70.911 Y95.682 F152
G1 X70.869 Y95.729 F152
G1 X70.854 Y95.745 F152
G1 X70.816 Y95.786 F152
G1 X70.797 Y95.806 F152
G1 X70.74 Y95.868 F152
G1 X70.708 Y95.901 F152
G1 X70.682 Y95.928 F152
G1 X70.654 Y95.958 F152
G1 X70.568 Y96.044 F152
G1 X70.538 Y96.073 F152
G1 X70.481 Y96.13 F152
G1 X70.422 Y96.187 F152
G1 X70.396 Y96.211 F152
G1 X70.36 Y96.244 F152
G1 X70.297 Y96.302 F152
G1 X70.281 Y96.316 F152
G1 X70.224 Y96.369 F152
G1 X70.171 Y96.416 F152
G1 X70.167 Y96.42 F152
G1 X70.109 Y96.469 F152
G1 X70.052 Y96.517 F152
G1 X70.036 Y96.531 F152
G1 X69.995 Y96.566 F152
G1 X69.969 Y96.588 F152
G1 X69.938 Y96.614 F152
G1 X69.898 Y96.646 F152
G1 X69.88 Y96.659 F152
G1 X69.825 Y96.703 F152
G1 X69.823 Y96.705 F152
G1 X69.766 Y96.749 F152
G1 X69.752 Y96.76 F152
G1 X69.709 Y96.794 F152
G1 X69.677 Y96.817 F152
G1 X69.651 Y96.836 F152
G1 X69.598 Y96.875 F152
G1 X69.594 Y96.877 F152
G1 X69.537 Y96.919 F152
G1 X69.519 Y96.932 F152
G1 X69.479 Y96.961 F152
G1 X69.437 Y96.989 F152
G1 X69.422 Y96.999 F152
G1 X69.365 Y97.037 F152
G1 X69.351 Y97.047 F152
G1 X69.265 Y97.104 F152
G1 X69.25 Y97.113 F152
G1 X69.193 Y97.15 F152
G1 X69.136 Y97.184 F152
G1 X69.021 Y97.253 F152
G1 X68.984 Y97.276 F152
G1 X68.774 Y97.39 F152
G1 X68.735 Y97.411 F152
G1 X68.677 Y97.439 F152
G1 X68.66 Y97.448 F152
G1 X68.62 Y97.467 F152
G1 X68.563 Y97.495 F152
G1 X68.543 Y97.505 F152
G1 X68.506 Y97.523 F152
G1 X68.419 Y97.562 F152
G1 X68.334 Y97.598 F152
G1 X68.284 Y97.62 F152
G1 X68.277 Y97.622 F152
G1 X68.137 Y97.677 F152
G1 X68.047 Y97.709 F152
G1 X67.99 Y97.728 F152
G1 X67.971 Y97.734 F152
G1 X67.933 Y97.747 F152
G1 X67.876 Y97.765 F152
G1 X67.818 Y97.783 F152
G1 X67.794 Y97.791 F152
G1 X67.761 Y97.8 F152
G1 X67.704 Y97.817 F152
G1 X67.646 Y97.832 F152
G1 X67.589 Y97.848 F152
G1 X67.586 Y97.849 F152
G1 X67.532 Y97.863 F152
G1 X67.417 Y97.89 F152
G1 X67.36 Y97.902 F152
G1 X67.347 Y97.906 F152
G1 X67.303 Y97.916 F152
G1 X67.246 Y97.928 F152
G1 X67.188 Y97.938 F152
G1 X67.131 Y97.948 F152
G1 X67.074 Y97.959 F152
G1 X67.05 Y97.963 F152
G1 X67.016 Y97.969 F152
G1 X66.959 Y97.979 F152
G1 X66.902 Y97.988 F152
G1 X66.845 Y97.996 F152
G1 X66.787 Y98.005 F152
G1 X66.73 Y98.013 F152
G1 X66.675 Y98.021 F152
G1 X66.673 F152
G1 X66.501 Y98.039 F152
G1 X66.386 Y98.05 F152
G1 X66.272 Y98.059 F152
G1 X66.215 Y98.063 F152
G1 X66.157 Y98.067 F152
G1 X66.1 Y98.071 F152
G1 X66.043 Y98.073 F152
G1 X65.985 Y98.075 F152
G1 X65.932 Y98.078 F152
G1 X65.928 F152
G1 X65.871 Y98.08 F152
G1 X65.814 Y98.082 F152
G1 X65.756 Y98.083 F152
G1 X65.642 F152
G1 X65.584 Y98.084 F152
G1 X65.47 F152
G1 X65.413 Y98.082 F152
G1 X65.355 F152
G1 X65.241 Y98.078 F152
G1 X65.209 F152
G1 X65.183 Y98.077 F152
G1 X65.126 Y98.074 F152
G1 X65.069 Y98.071 F152
G1 X65.012 Y98.068 F152
G1 X64.954 Y98.064 F152
G1 X64.897 Y98.062 F152
G1 X64.84 Y98.058 F152
G1 X64.725 Y98.047 F152
G1 X64.668 Y98.043 F152
G1 X64.553 Y98.032 F152
G1 X64.447 Y98.021 F152
G1 X64.439 Y98.019 F152
G1 X64.21 Y97.99 F152
G1 X64.038 Y97.963 F152
G1 X64.036 F152
G1 X63.981 Y97.954 F152
G1 X63.866 Y97.935 F152
G1 X63.809 Y97.924 F152
G1 X63.752 Y97.912 F152
G1 X63.717 Y97.906 F152
G1 X63.637 Y97.89 F152
G1 X63.58 Y97.879 F152
G1 X63.522 Y97.867 F152
G1 X63.465 Y97.853 F152
G1 X63.445 Y97.849 F152
G1 X63.408 Y97.84 F152
G1 X63.351 Y97.826 F152
G1 X63.293 Y97.814 F152
G1 X63.236 Y97.8 F152
G1 X63.202 Y97.791 F152
G1 X63.179 Y97.785 F152
G1 X63.007 Y97.74 F152
G1 X62.984 Y97.734 F152
G1 X62.95 Y97.725 F152
G1 X62.892 Y97.709 F152
G1 X62.835 Y97.692 F152
G1 X62.783 Y97.677 F152
G1 X62.778 Y97.675 F152
G1 X62.606 Y97.624 F152
G1 X62.59 Y97.62 F152
G1 X62.491 Y97.587 F152
G1 X62.434 Y97.569 F152
G1 X62.413 Y97.562 F152
G1 X62.377 Y97.551 F152
G1 X62.262 Y97.513 F152
G1 X62.148 Y97.472 F152
G1 X62.09 Y97.452 F152
G1 X62.077 Y97.448 F152
G1 X62.033 Y97.432 F152
G1 X61.976 Y97.412 F152
G1 X61.919 Y97.39 F152
G1 X61.917 F152
G1 X61.861 Y97.369 F152
G1 X61.804 Y97.346 F152
G1 X61.767 Y97.333 F152
G1 X61.747 Y97.325 F152
G1 X61.689 Y97.304 F152
G1 X61.632 Y97.281 F152
G1 X61.617 Y97.276 F152
G1 X61.575 Y97.26 F152
G1 X61.518 Y97.237 F152
G1 X61.472 Y97.218 F152
G1 X61.46 Y97.213 F152
G1 X61.403 Y97.19 F152
G1 X61.346 Y97.166 F152
G1 X61.333 Y97.161 F152
G1 X61.289 Y97.142 F152
G1 X61.231 Y97.119 F152
G1 X61.195 Y97.104 F152
G1 X61.174 Y97.095 F152
G1 X61.117 Y97.072 F152
G1 X61.059 Y97.047 F152
G1 X61.002 Y97.021 F152
G1 X60.945 Y96.996 F152
G1 X60.93 Y96.989 F152
G1 X60.888 Y96.97 F152
G1 X60.83 Y96.945 F152
G1 X60.799 Y96.932 F152
G1 X60.773 Y96.92 F152
G1 X60.716 Y96.895 F152
G1 X60.671 Y96.875 F152
G1 X60.658 Y96.868 F152
G1 X60.601 Y96.842 F152
G1 X60.549 Y96.817 F152
G1 X60.544 Y96.815 F152
G1 X60.315 Y96.707 F152
G1 X60.306 Y96.703 F152
G1 X60.257 Y96.68 F152
G1 X60.189 Y96.646 F152
G1 X60.143 Y96.621 F152
G1 X60.086 Y96.593 F152
G1 X60.076 Y96.588 F152
G1 X60.028 Y96.564 F152
G1 X59.962 Y96.531 F152
G1 X59.914 Y96.506 F152
G1 X59.857 Y96.477 F152
G1 X59.848 Y96.474 F152
G1 X59.799 Y96.447 F152
G1 X59.742 Y96.416 F152
G1 X59.741 F152
G1 X59.685 Y96.386 F152
G1 X59.634 Y96.359 F152
G1 X59.57 Y96.323 F152
G1 X59.53 Y96.302 F152
G1 X59.513 Y96.292 F152
G1 X59.456 Y96.261 F152
G1 X59.427 Y96.244 F152
G1 X59.398 Y96.227 F152
G1 X59.341 Y96.195 F152
G1 X59.328 Y96.187 F152
G1 X59.284 Y96.162 F152
G1 X59.228 Y96.13 F152
G1 X59.226 Y96.129 F152
G1 X59.169 Y96.094 F152
G1 X59.132 Y96.073 F152
G1 X59.112 Y96.06 F152
G1 X59.055 Y96.026 F152
G1 X59.037 Y96.015 F152
G1 X58.997 Y95.99 F152
G1 X58.945 Y95.958 F152
G1 X58.94 Y95.954 F152
G1 X58.883 Y95.919 F152
G1 X58.853 Y95.901 F152
G1 X58.826 Y95.883 F152
G1 X58.768 Y95.845 F152
G1 X58.765 Y95.843 F152
G1 X58.711 Y95.808 F152
G1 X58.676 Y95.786 F152
G1 X58.654 Y95.771 F152
G1 X58.596 Y95.731 F152
G1 X58.592 Y95.729 F152
G1 X58.539 Y95.693 F152
G1 X58.482 Y95.654 F152
G1 X58.426 Y95.614 F152
G1 X58.425 Y95.613 F152
G1 X58.367 Y95.572 F152
G1 X58.345 Y95.557 F152
G1 X58.31 Y95.531 F152
G1 X58.267 Y95.5 F152
G1 X58.195 Y95.446 F152
G1 X58.19 Y95.442 F152
G1 X58.138 Y95.403 F152
G1 X58.115 Y95.385 F152
G1 X58.081 Y95.358 F152
G1 X58.042 Y95.328 F152
G1 X57.97 Y95.27 F152
G1 X57.966 Y95.268 F152
G1 X57.909 Y95.22 F152
G1 X57.9 Y95.213 F152
G1 X57.852 Y95.174 F152
G1 X57.831 Y95.156 F152
G1 X57.794 Y95.124 F152
G1 X57.765 Y95.098 F152
G1 X57.737 Y95.074 F152
G1 X57.7 Y95.041 F152
G1 X57.68 Y95.024 F152
G1 X57.635 Y94.984 F152
G1 X57.623 Y94.972 F152
G1 X57.574 Y94.927 F152
G1 X57.565 Y94.919 F152
G1 X57.513 Y94.869 F152
G1 X57.508 Y94.864 F152
G1 X57.451 Y94.808 F152
G1 X57.399 Y94.755 F152
G1 X57.394 Y94.749 F152
G1 X57.343 Y94.697 F152
G1 X57.336 Y94.69 F152
G1 X57.287 Y94.64 F152
G1 X57.279 Y94.632 F152
G1 X57.232 Y94.583 F152
G1 X57.222 Y94.573 F152
G1 X57.176 Y94.526 F152
G1 X57.164 Y94.513 F152
G1 X57.107 Y94.452 F152
G1 X57.069 Y94.411 F152
G1 X57.05 Y94.39 F152
G1 X57.015 Y94.354 F152
G1 X56.993 Y94.329 F152
G1 X56.962 Y94.296 F152
G1 X56.908 Y94.239 F152
G1 X56.878 Y94.207 F152
G1 X56.821 Y94.145 F152
G1 X56.801 Y94.124 F152
G1 X56.763 Y94.084 F152
G1 X56.747 Y94.067 F152
G1 X56.694 Y94.01 F152
G1 X56.649 Y93.962 F152
G1 X56.64 Y93.953 F152
G1 X56.583 Y93.895 F152
G1 X56.534 Y93.846 F152
G1 X56.526 Y93.838 F152
G1 X56.477 Y93.788 F152
G1 X56.47 Y93.781 F152
G1 X56.42 Y93.73 F152
G1 X56.356 Y93.666 F152
G1 X56.305 Y93.618 F152
G1 X56.295 Y93.609 F152
G1 X56.248 Y93.565 F152
G1 X56.234 Y93.551 F152
G1 X56.191 Y93.512 F152
G1 X56.172 Y93.494 F152
G1 X56.133 Y93.458 F152
G1 X56.11 Y93.437 F152
G1 X56.042 Y93.38 F152
G1 X56.019 Y93.36 F152
G1 X55.974 Y93.322 F152
G1 X55.907 Y93.265 F152
G1 X55.904 Y93.263 F152
G1 X55.847 Y93.215 F152
G1 X55.838 Y93.208 F152
G1 X55.79 Y93.171 F152
G1 X55.762 Y93.15 F152
G1 X55.732 Y93.128 F152
G1 X55.675 Y93.084 F152
G1 X55.561 Y92.998 F152
G1 X55.531 Y92.978 F152
G1 X55.503 Y92.96 F152
G1 X55.389 Y92.883 F152
G1 X55.36 Y92.864 F152
G1 X55.331 Y92.844 F152
G1 X55.275 Y92.807 F152
G1 X55.274 Y92.806 F152
G1 X55.217 Y92.771 F152
G1 X55.18 Y92.749 F152
G1 X55.16 Y92.737 F152
G1 X55.102 Y92.703 F152
G1 X55.084 Y92.692 F152
G1 X55.045 Y92.669 F152
G1 X54.988 Y92.635 F152
G1 X54.987 F152
G1 X54.931 Y92.602 F152
G1 X54.885 Y92.577 F152
G1 X54.873 Y92.571 F152
G1 X54.816 Y92.542 F152
G1 X54.775 Y92.52 F152
G1 X54.759 Y92.511 F152
G1 X54.701 Y92.482 F152
G1 X54.665 Y92.463 F152
G1 X54.644 Y92.452 F152
G1 X54.587 Y92.423 F152
G1 X54.551 Y92.406 F152
G1 X54.53 Y92.396 F152
G1 X54.472 Y92.369 F152
G1 X54.427 Y92.348 F152
G1 X54.415 Y92.343 F152
G1 X54.358 Y92.316 F152
G1 X54.302 Y92.291 F152
G1 X54.243 Y92.263 F152
G1 X54.186 Y92.239 F152
G1 X54.172 Y92.234 F152
G1 X54.129 Y92.216 F152
G1 X54.071 Y92.192 F152
G1 X54.032 Y92.176 F152
G1 X54.014 Y92.169 F152
G1 X53.957 Y92.145 F152
G1 X53.9 Y92.122 F152
G1 X53.892 Y92.119 F152
G1 X53.842 Y92.098 F152
G1 X53.728 Y92.057 F152
G1 X53.67 Y92.036 F152
G1 X53.613 Y92.015 F152
G1 X53.556 Y91.994 F152
G1 X53.441 Y91.953 F152
G1 X53.423 Y91.947 F152
G1 X53.384 Y91.934 F152
G1 X53.269 Y91.896 F152
G1 X53.25 Y91.89 F152
G1 X53.212 Y91.877 F152
G1 X53.155 Y91.858 F152
G1 X53.098 Y91.839 F152
G1 X53.077 Y91.833 F152
G1 X53.04 Y91.821 F152
G1 X52.926 Y91.787 F152
G1 X52.887 Y91.775 F152
G1 X52.868 Y91.769 F152
G1 X52.697 Y91.718 F152
G1 X52.525 Y91.67 F152
G1 X52.491 Y91.661 F152
G1 X52.468 Y91.654 F152
G1 X52.41 Y91.638 F152
G1 X52.296 Y91.606 F152
G1 X52.283 Y91.603 F152
G1 X52.238 Y91.592 F152
G1 X52.067 Y91.549 F152
G1 X52.054 Y91.546 F152
G1 X52.009 Y91.534 F152
G1 X51.952 Y91.52 F152
G1 X51.895 Y91.507 F152
G1 X51.608 Y91.435 F152
G1 X51.592 Y91.431 F152
G1 X51.551 Y91.421 F152
G1 X51.494 Y91.406 F152
G1 X51.437 Y91.394 F152
G1 X51.379 Y91.38 F152
G1 X51.349 Y91.374 F152
G1 X51.265 Y91.354 F152
G1 X51.207 Y91.342 F152
G1 X51.15 Y91.329 F152
G1 X51.096 Y91.317 F152
G1 X51.093 Y91.316 F152
G1 X51.036 Y91.303 F152
G1 X50.921 Y91.277 F152
G1 X50.864 Y91.264 F152
G1 X50.841 Y91.26 F152
G1 X50.806 Y91.252 F152
G1 X50.749 Y91.238 F152
G1 X50.635 Y91.213 F152
G1 X50.584 Y91.202 F152
G1 X50.577 Y91.201 F152
G1 X50.348 Y91.15 F152
G1 X50.32 Y91.145 F152
G1 X50.291 Y91.138 F152
G1 X50.234 Y91.126 F152
G1 X50.062 Y91.089 F152
G1 X50.056 Y91.088 F152
G1 X50.005 Y91.076 F152
G1 X49.947 Y91.064 F152
G1 X49.89 Y91.052 F152
G1 X49.792 Y91.03 F152
G1 X49.604 Y90.989 F152
G1 X49.546 Y90.977 F152
G1 X49.528 Y90.973 F152
G1 X49.489 Y90.964 F152
G1 X49.374 Y90.939 F152
G1 X49.317 Y90.926 F152
G1 X49.27 Y90.916 F152
G1 X49.26 Y90.913 F152
G1 X49.088 Y90.876 F152
G1 X49.031 Y90.862 F152
G1 X49.014 Y90.859 F152
G1 X48.974 Y90.85 F152
G1 X48.859 Y90.823 F152
G1 X48.761 Y90.801 F152
G1 X48.744 Y90.797 F152
G1 X48.687 Y90.784 F152
G1 X48.515 Y90.744 F152
G1 X48.514 F152
G1 X48.458 Y90.73 F152
G1 X48.286 Y90.69 F152
G1 X48.229 Y90.676 F152
G1 X48.172 Y90.662 F152
G1 X48.114 Y90.648 F152
G1 X48.057 Y90.635 F152
G1 X48.034 Y90.629 F152
G1 X48 Y90.62 F152
G1 X47.943 Y90.607 F152
G1 X47.574 Y90.515 F152
G1 X47.542 Y90.506 F152
G1 X47.484 Y90.491 F152
G1 X47.427 Y90.476 F152
G1 X47.37 Y90.462 F152
G1 X47.141 Y90.401 F152
G1 X47.135 Y90.4 F152
G1 X47.083 Y90.386 F152
G1 X46.969 Y90.355 F152
G1 X46.922 Y90.343 F152
G1 X46.911 Y90.339 F152
G1 X46.854 Y90.324 F152
G1 X46.797 Y90.308 F152
G1 X46.74 Y90.293 F152
G1 X46.715 Y90.286 F152
G1 X46.682 Y90.277 F152
G1 X46.511 Y90.228 F152
G1 X46.51 F152
G1 X46.453 Y90.212 F152
G1 X46.396 Y90.196 F152
G1 X46.339 Y90.179 F152
G1 X46.31 Y90.171 F152
G1 X46.281 Y90.162 F152
G1 X46.224 Y90.146 F152
G1 X46.167 Y90.129 F152
G1 X46.114 Y90.114 F152
G1 X46.11 Y90.112 F152
G1 X46.052 Y90.096 F152
G1 X45.995 Y90.079 F152
G1 X45.938 Y90.061 F152
G1 X45.922 Y90.056 F152
G1 X45.88 Y90.044 F152
G1 X45.823 Y90.026 F152
G1 X45.733 Y89.999 F152
G1 X45.709 Y89.991 F152
G1 X45.651 Y89.974 F152
G1 X45.594 Y89.956 F152
G1 X45.547 Y89.942 F152
G1 X45.537 Y89.938 F152
G1 X45.422 Y89.902 F152
G1 X45.366 Y89.884 F152
G1 X45.365 F152
G1 X45.193 Y89.83 F152
G1 X45.184 Y89.827 F152
G1 X45.136 Y89.811 F152
G1 X45.011 Y89.77 F152
G1 X44.964 Y89.754 F152
G1 X44.849 Y89.716 F152
G1 X44.838 Y89.713 F152
G1 X44.792 Y89.697 F152
G1 X44.735 Y89.679 F152
G1 X44.678 Y89.659 F152
G1 X44.62 Y89.638 F152
G1 X44.506 Y89.599 F152
G1 X44.502 Y89.598 F152
G1 X44.448 Y89.579 F152
G1 X44.391 Y89.559 F152
G1 X44.338 Y89.541 F152
G1 X44.334 Y89.539 F152
G1 X44.219 Y89.498 F152
G1 X44.179 Y89.483 F152
G1 X44.162 Y89.477 F152
G1 X44.105 Y89.456 F152
G1 X44.048 Y89.435 F152
G1 X44.022 Y89.426 F152
G1 X43.99 Y89.414 F152
G1 X43.869 Y89.369 F152
G1 X43.818 Y89.349 F152
G1 X43.761 Y89.328 F152
G1 X43.719 Y89.311 F152
G1 X43.704 Y89.305 F152
G1 X43.647 Y89.284 F152
G1 X43.589 Y89.261 F152
G1 X43.57 Y89.254 F152
G1 X43.475 Y89.216 F152
G1 X43.428 Y89.197 F152
G1 X43.417 Y89.192 F152
G1 X43.303 Y89.146 F152
G1 X43.287 Y89.14 F152
G1 X43.246 Y89.123 F152
G1 X43.188 Y89.098 F152
G1 X43.15 Y89.082 F152
G1 X43.131 Y89.074 F152
G1 X43.074 Y89.049 F152
G1 X43.017 Y89.025 F152
G1 X42.959 Y89 F152
G1 X42.902 Y88.976 F152
G1 X42.883 Y88.968 F152
G1 X42.845 Y88.951 F152
G1 X42.787 Y88.924 F152
G1 X42.757 Y88.91 F152
G1 X42.673 Y88.871 F152
G1 X42.633 Y88.853 F152
G1 X42.616 Y88.845 F152
G1 X42.558 Y88.818 F152
G1 X42.509 Y88.796 F152
G1 X42.501 Y88.791 F152
G1 X42.444 Y88.764 F152
G1 X42.329 Y88.706 F152
G1 X42.277 Y88.681 F152
G1 X42.215 Y88.65 F152
G1 X42.164 Y88.624 F152
G1 X42.157 Y88.619 F152
G1 X42.1 Y88.589 F152
G1 X42.057 Y88.567 F152
G1 X42.043 Y88.559 F152
G1 X41.985 Y88.528 F152
G1 X41.951 Y88.509 F152
G1 X41.928 Y88.498 F152
G1 X41.871 Y88.465 F152
G1 X41.849 Y88.452 F152
G1 X41.814 Y88.431 F152
G1 X41.699 Y88.365 F152
G1 X41.652 Y88.337 F152
G1 X41.642 Y88.332 F152
G1 X41.585 Y88.296 F152
G1 X41.47 Y88.223 F152
G1 X41.469 F152
G1 X41.413 Y88.186 F152
G1 X41.38 Y88.166 F152
G1 X41.298 Y88.108 F152
G1 X41.297 F152
G1 X41.241 Y88.068 F152
G1 X41.216 Y88.051 F152
G1 X41.184 Y88.029 F152
G1 X41.135 Y87.994 F152
G1 X41.126 Y87.986 F152
G1 X41.069 Y87.942 F152
G1 X41.062 Y87.936 F152
G1 X41.012 Y87.898 F152
G1 X40.988 Y87.879 F152
G1 X40.954 Y87.853 F152
G1 X40.916 Y87.822 F152
G1 X40.897 Y87.806 F152
G1 X40.85 Y87.764 F152
G1 X40.84 Y87.756 F152
G1 X40.784 Y87.707 F152
G1 X40.783 Y87.706 F152
G1 X40.725 Y87.654 F152
G1 X40.72 Y87.65 F152
G1 X40.668 Y87.6 F152
G1 X40.661 Y87.593 F152
G1 X40.611 Y87.544 F152
G1 X40.601 Y87.535 F152
G1 X40.554 Y87.487 F152
G1 X40.545 Y87.478 F152
G1 X40.496 Y87.425 F152
G1 X40.492 Y87.421 F152
G1 X40.439 Y87.363 F152
G1 X40.39 Y87.306 F152
G1 X40.382 Y87.297 F152
G1 X40.341 Y87.249 F152
G1 X40.294 Y87.192 F152
G1 X40.267 Y87.157 F152
G1 X40.25 Y87.134 F152
G1 X40.164 Y87.02 F152
G1 X40.153 Y87.004 F152
G1 X40.125 Y86.962 F152
G1 X40.085 Y86.905 F152
G1 X40.047 Y86.848 F152
G1 X40.011 Y86.79 F152
G1 X39.981 Y86.74 F152
G1 X39.976 Y86.733 F152
G1 X39.941 Y86.676 F152
G1 X39.923 Y86.645 F152
G1 X39.909 Y86.619 F152
G1 X39.877 Y86.561 F152
G1 X39.866 Y86.542 F152
G1 X39.845 Y86.504 F152
G1 X39.815 Y86.447 F152
G1 X39.758 Y86.332 F152
G1 X39.752 Y86.321 F152
G1 X39.73 Y86.275 F152
G1 X39.704 Y86.217 F152
G1 X39.694 Y86.197 F152
G1 X39.653 Y86.103 F152
G1 X39.637 Y86.064 F152
G1 X39.63 Y86.046 F152
G1 X39.606 Y85.988 F152
G1 X39.583 Y85.931 F152
G1 X39.58 Y85.922 F152
G1 X39.562 Y85.874 F152
G1 X39.54 Y85.816 F152
G1 X39.522 Y85.766 F152
G1 X39.52 Y85.759 F152
G1 X39.482 Y85.644 F152
G1 X39.465 Y85.592 F152
G1 X39.464 Y85.587 F152
G1 X39.43 Y85.473 F152
G1 X39.416 Y85.415 F152
G1 X39.408 Y85.384 F152
G1 X39.402 Y85.358 F152
G1 X39.389 Y85.301 F152
G1 X39.357 Y85.129 F152
G1 X39.351 Y85.097 F152
G1 X39.336 Y85.014 F152
G1 X39.329 Y84.957 F152
G1 X39.317 Y84.842 F152
G1 X39.309 Y84.785 F152
G1 X39.303 Y84.728 F152
G1 X39.294 Y84.613 F152
G1 X39.293 Y84.608 F152
G1 X39.29 Y84.556 F152
G1 X39.284 Y84.441 F152
G1 X39.281 Y84.384 F152
G1 X39.272 Y84.097 F152
G1 X39.271 Y84.04 F152
G1 X39.269 Y83.983 F152
G1 X39.264 Y83.639 F152
G1 Y83.582 F152
G1 X39.261 Y83.41 F152
G1 Y83.353 F152
G1 X39.257 Y83.066 F152
G1 Y83.009 F152
G1 X39.252 Y82.722 F152
G1 Y82.665 F152
G1 X39.248 Y82.379 F152
G1 Y82.321 F152
G1 X39.244 Y82.092 F152
G1 Y82.035 F152
G1 X39.241 Y81.863 F152
G1 Y81.806 F152
G1 X39.239 Y81.634 F152
G1 Y81.576 F152
G1 X39.237 Y81.462 F152
G1 Y81.405 F152
G1 X39.236 Y81.377 F152
G1 Y81.175 F152
G1 X39.235 Y81.118 F152
G1 Y81.003 F152
G1 X39.236 Y80.946 F152
G1 Y80.881 F152
G1 X39.237 Y80.832 F152
G1 Y80.774 F152
G1 X39.241 Y80.488 F152
G1 X39.243 Y80.43 F152
G1 X39.244 Y80.373 F152
G1 X39.246 Y80.316 F152
G1 X39.247 Y80.259 F152
G1 X39.258 Y79.915 F152
G1 X39.26 Y79.857 F152
G1 X39.264 Y79.743 F152
G1 X39.283 Y79.342 F152
G1 X39.286 Y79.285 F152
G1 X39.289 Y79.227 F152
G1 X39.292 Y79.17 F152
G1 X39.293 Y79.143 F152
G1 X39.295 Y79.113 F152
G1 X39.302 Y78.998 F152
G1 X39.305 Y78.941 F152
G1 X39.309 Y78.883 F152
G1 X39.324 Y78.654 F152
G1 X39.328 Y78.597 F152
G1 X39.332 Y78.54 F152
G1 X39.345 Y78.368 F152
G1 X39.349 Y78.31 F152
G1 X39.351 Y78.285 F152
G1 X39.353 Y78.253 F152
G1 X39.367 Y78.081 F152
G1 X39.372 Y78.024 F152
G1 X39.377 Y77.967 F152
G1 X39.382 Y77.909 F152
G1 X39.386 Y77.852 F152
G1 X39.392 Y77.795 F152
G1 X39.396 Y77.738 F152
G1 X39.407 Y77.623 F152
G1 X39.408 Y77.608 F152
G1 X39.412 Y77.566 F152
G1 X39.439 Y77.279 F152
G1 X39.452 Y77.165 F152
G1 X39.457 Y77.107 F152
G1 X39.463 Y77.05 F152
G1 X39.465 Y77.03 F152
G1 X39.47 Y76.993 F152
G1 X39.476 Y76.935 F152
G1 X39.481 Y76.878 F152
G1 X39.5 Y76.706 F152
G1 X39.507 Y76.649 F152
G1 X39.514 Y76.592 F152
G1 X39.521 Y76.534 F152
G1 X39.522 Y76.512 F152
G1 X39.527 Y76.477 F152
G1 X39.533 Y76.42 F152
G1 X39.54 Y76.362 F152
G1 X39.547 Y76.305 F152
G1 X39.575 Y76.076 F152
G1 X39.58 Y76.037 F152
G1 X39.582 Y76.019 F152
G1 X39.59 Y75.961 F152
G1 X39.598 Y75.904 F152
G1 X39.612 Y75.789 F152
G1 X39.628 Y75.675 F152
G1 X39.637 Y75.603 F152
G1 X39.643 Y75.56 F152
G1 X39.684 Y75.274 F152
G1 X39.693 Y75.216 F152
G1 X39.694 Y75.2 F152
G1 X39.701 Y75.159 F152
G1 X39.71 Y75.102 F152
G1 X39.715 Y75.066 F152
G1 X39.718 Y75.045 F152
G1 X39.723 Y75.016 F152
G1 X39.725 Y75 F152
G1 X39.726 Y74.994 F152
G1 X39.727 Y74.987 F152
; MOVEMENT_LEAD_OUT
G1 X39.729 Y74.981 Z-8.091 F152
G1 X39.73 Y74.978 Z-8.082 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X44.071 Y78.441 F152
G1 Z0.873 F152
; MOVEMENT_PLUNGE
G1 Z-8.043 F51
; MOVEMENT_LEAD_IN
G1 X44.074 Y78.44 Z-8.059 F152
G1 X44.081 Y78.437 Z-8.073 F152
G1 X44.092 Y78.433 Z-8.084 F152
G1 X44.106 Y78.428 Z-8.091 F152
G1 X44.121 Y78.422 Z-8.093 F152
; MOVEMENT_CUTTING
G1 X44.128 Y78.42 Z-8.078 F152
G1 X44.133 Y78.418 Z-8.065 F152
G1 X44.219 Y78.388 Z-7.866 F152
G1 X44.248 Y78.379 Z-7.805 F152
G1 X44.276 Y78.368 Z-7.757 F152
G1 X44.277 Z-7.753 F152
G1 X44.363 Y78.336 Z-7.599 F152
G1 X44.391 Y78.325 Z-7.548 F152
G1 X44.43 Y78.31 Z-7.485 F152
G1 X44.448 Y78.304 Z-7.448 F152
G1 X44.506 Y78.283 Z-7.356 F152
G1 X44.534 Y78.273 Z-7.302 F152
G1 X44.563 Y78.262 Z-7.257 F152
G1 X44.587 Y78.253 Z-7.219 F152
G1 X44.62 Y78.241 Z-7.17 F152
G1 X44.678 Y78.217 Z-7.097 F152
G1 X44.731 Y78.196 Z-7.027 F152
G1 X44.735 Y78.195 Z-7.018 F152
G1 X44.849 Y78.148 Z-6.878 F152
G1 X44.874 Y78.139 Z-6.848 F152
G1 X44.907 Y78.126 Z-6.8 F152
G1 X44.964 Y78.102 Z-6.737 F152
G1 X45.011 Y78.081 Z-6.69 F152
G1 X45.021 Y78.077 Z-6.682 F152
G1 X45.079 Y78.052 Z-6.625 F152
G1 X45.136 Y78.026 Z-6.572 F152
G1 X45.139 Y78.024 Z-6.57 F152
G1 X45.193 Y78 Z-6.519 F152
G1 X45.25 Y77.974 Z-6.467 F152
G1 X45.267 Y77.967 Z-6.451 F152
G1 X45.308 Y77.948 Z-6.414 F152
G1 X45.365 Y77.92 Z-6.375 F152
G1 X45.386 Y77.909 Z-6.363 F152
G1 X45.422 Y77.892 Z-6.337 F152
G1 X45.48 Y77.864 Z-6.298 F152
G1 X45.502 Y77.852 Z-6.286 F152
G1 X45.537 Y77.834 Z-6.265 F152
G1 X45.651 Y77.777 Z-6.184 F152
G1 X45.709 Y77.746 Z-6.165 F152
G1 X45.724 Y77.738 Z-6.157 F152
G1 X45.766 Y77.714 Z-6.144 F152
G1 X45.823 Y77.683 Z-6.111 F152
G1 X45.827 Y77.68 Z-6.115 F152
G1 X45.88 Y77.651 Z-6.086 F152
G1 X45.93 Y77.623 Z-6.064 F152
G1 X45.938 Y77.618 Z-6.06 F152
G1 X45.995 Y77.586 Z-6.034 F152
G1 X46.029 Y77.566 Z-6.03 F152
G1 X46.052 Y77.552 Z-6.023 F152
G1 X46.11 Y77.517 Z-6.007 F152
G1 X46.123 Y77.508 Z-6.008 F152
G1 X46.167 Y77.481 Z-5.991 F152
G1 X46.215 Y77.451 Z-5.979 F152
G1 X46.224 Y77.446 Z-5.975 F152
G1 X46.281 Y77.41 Z-5.958 F152
G1 X46.307 Y77.394 Z-5.95 F152
G1 X46.339 Y77.374 Z-5.942 F152
G1 X46.394 Y77.336 F152
G1 X46.396 Z-5.939 F152
G1 X46.453 Y77.296 Z-5.927 F152
G1 X46.477 Y77.279 Z-5.925 F152
G1 X46.511 Y77.257 Z-5.915 F152
G1 X46.561 Y77.222 Z-5.908 F152
G1 X46.568 Y77.217 Z-5.903 F152
G1 X46.625 Y77.177 Z-5.898 F152
G1 X46.644 Y77.165 Z-5.891 F152
G1 X46.682 Y77.136 F152
G1 X46.72 Y77.107 Z-5.887 F152
G1 X46.74 Y77.093 Z-5.88 F152
G1 X46.795 Y77.05 F152
G1 X46.797 Y77.049 Z-5.876 F152
G1 X46.854 Y77.005 Z-5.872 F152
G1 X46.87 Y76.993 F152
G1 X46.911 Y76.961 Z-5.867 F152
G1 X46.945 Y76.935 Z-5.863 F152
G1 X46.969 Y76.917 Z-5.853 F152
G1 X47.014 Y76.878 Z-5.854 F152
G1 X47.026 Y76.869 Z-5.848 F152
G1 X47.141 Y76.772 Z-5.852 F152
G1 X47.151 Y76.763 Z-5.851 F152
G1 X47.198 Y76.724 Z-5.847 F152
G1 X47.218 Y76.706 Z-5.842 F152
G1 X47.255 Y76.674 Z-5.837 F152
G1 X47.284 Y76.649 Z-5.832 F152
G1 X47.312 Y76.623 Z-5.833 F152
G1 X47.347 Y76.592 F152
G1 X47.37 Y76.571 Z-5.836 F152
G1 X47.41 Y76.534 Z-5.839 F152
G1 X47.427 Y76.518 Z-5.841 F152
G1 X47.471 Y76.477 Z-5.836 F152
G1 X47.484 Y76.464 Z-5.84 F152
G1 X47.531 Y76.42 Z-5.836 F152
G1 X47.542 Y76.41 Z-5.834 F152
G1 X47.592 Y76.362 Z-5.831 F152
G1 X47.599 Y76.355 Z-5.833 F152
G1 X47.65 Y76.305 Z-5.838 F152
G1 X47.656 Y76.298 Z-5.844 F152
G1 X47.705 Y76.248 Z-5.849 F152
G1 X47.713 Y76.24 F152
G1 X47.762 Y76.19 Z-5.855 F152
G1 X47.771 Y76.182 F152
G1 X47.818 Y76.133 Z-5.86 F152
G1 X47.828 Y76.123 F152
G1 X47.874 Y76.076 Z-5.856 F152
G1 X47.885 Y76.064 Z-5.859 F152
G1 X47.927 Y76.019 Z-5.871 F152
G1 X47.943 Y76.002 Z-5.873 F152
G1 X47.98 Y75.961 Z-5.886 F152
G1 X48 Y75.94 Z-5.892 F152
G1 X48.033 Y75.904 Z-5.9 F152
G1 X48.057 Y75.877 Z-5.907 F152
G1 X48.085 Y75.847 Z-5.913 F152
G1 X48.114 Y75.814 Z-5.923 F152
G1 X48.137 Y75.789 Z-5.925 F152
G1 X48.172 Y75.751 Z-5.933 F152
G1 X48.188 Y75.732 Z-5.943 F152
G1 X48.229 Y75.685 Z-5.964 F152
G1 X48.238 Y75.675 Z-5.965 F152
G1 X48.286 Y75.618 Z-5.995 F152
G1 X48.335 Y75.56 Z-6.02 F152
G1 X48.343 Y75.551 Z-6.021 F152
G1 X48.385 Y75.503 Z-6.044 F152
G1 X48.401 Y75.484 Z-6.051 F152
G1 X48.434 Y75.446 Z-6.063 F152
G1 X48.458 Y75.416 Z-6.081 F152
G1 X48.481 Y75.388 Z-6.094 F152
G1 X48.515 Y75.346 Z-6.122 F152
G1 X48.528 Y75.331 Z-6.131 F152
G1 X48.573 Y75.275 Z-6.17 F152
G1 Y75.274 F152
G1 X48.62 Y75.216 Z-6.2 F152
G1 X48.63 Y75.204 Z-6.209 F152
G1 X48.687 Y75.132 Z-6.252 F152
G1 X48.711 Y75.102 Z-6.27 F152
G1 X48.744 Y75.059 Z-6.297 F152
G1 X48.798 Y74.987 Z-6.351 F152
G1 X48.802 Y74.983 Z-6.353 F152
G1 X48.841 Y74.93 Z-6.395 F152
G1 X48.859 Y74.907 Z-6.409 F152
G1 X48.884 Y74.873 Z-6.438 F152
G1 X48.916 Y74.831 Z-6.465 F152
G1 X48.928 Y74.815 Z-6.475 F152
G1 X48.971 Y74.758 Z-6.519 F152
G1 X48.974 Y74.754 Z-6.527 F152
G1 X49.012 Y74.701 Z-6.569 F152
G1 X49.031 Y74.674 Z-6.592 F152
G1 X49.052 Y74.643 Z-6.616 F152
G1 X49.088 Y74.592 Z-6.658 F152
G1 X49.093 Y74.586 Z-6.662 F152
G1 X49.132 Y74.529 Z-6.715 F152
G1 X49.145 Y74.51 Z-6.729 F152
G1 X49.172 Y74.472 Z-6.762 F152
G1 X49.203 Y74.428 Z-6.8 F152
G1 X49.212 Y74.414 Z-6.806 F152
G1 X49.251 Y74.357 Z-6.847 F152
G1 X49.26 Y74.343 Z-6.862 F152
G1 X49.288 Y74.3 Z-6.901 F152
G1 X49.317 Y74.253 Z-6.947 F152
G1 X49.324 Y74.242 Z-6.955 F152
G1 X49.361 Y74.185 Z-7.009 F152
G1 X49.374 Y74.165 Z-7.027 F152
G1 X49.399 Y74.128 Z-7.057 F152
G1 X49.432 Y74.074 Z-7.1 F152
G1 X49.434 Y74.071 Z-7.099 F152
G1 X49.469 Y74.013 Z-7.14 F152
G1 X49.489 Y73.98 Z-7.168 F152
G1 X49.503 Y73.956 Z-7.188 F152
G1 X49.537 Y73.899 Z-7.236 F152
G1 X49.546 Y73.882 Z-7.254 F152
G1 X49.57 Y73.841 Z-7.291 F152
G1 X49.604 Y73.784 Z-7.346 F152
G1 X49.635 Y73.727 Z-7.375 F152
G1 X49.661 Y73.678 Z-7.404 F152
G1 X49.666 Y73.669 Z-7.405 F152
G1 X49.697 Y73.612 Z-7.442 F152
G1 X49.718 Y73.571 Z-7.471 F152
G1 X49.727 Y73.555 Z-7.479 F152
G1 X49.756 Y73.498 Z-7.53 F152
G1 X49.775 Y73.459 Z-7.56 F152
G1 X49.785 Y73.44 Z-7.573 F152
G1 X49.813 Y73.383 Z-7.602 F152
G1 X49.833 Y73.341 Z-7.624 F152
G1 X49.841 Y73.326 Z-7.625 F152
G1 X49.868 Y73.268 Z-7.654 F152
G1 X49.89 Y73.221 Z-7.677 F152
G1 X49.894 Y73.211 Z-7.684 F152
G1 X49.946 Y73.096 Z-7.757 F152
G1 X49.947 Y73.094 Z-7.762 F152
G1 X49.971 Y73.039 Z-7.801 F152
G1 X49.996 Y72.982 Z-7.822 F152
G1 X50.005 Y72.959 Z-7.833 F152
G1 X50.02 Y72.925 Z-7.84 F152
G1 X50.043 Y72.867 Z-7.865 F152
G1 X50.062 Y72.821 Z-7.887 F152
G1 X50.066 Y72.81 Z-7.891 F152
G1 X50.111 Y72.695 Z-7.957 F152
G1 X50.119 Y72.674 Z-7.972 F152
G1 X50.133 Y72.638 Z-7.989 F152
G1 X50.155 Y72.581 Z-8.018 F152
G1 X50.175 Y72.523 Z-8.04 F152
G1 X50.176 Y72.518 Z-8.043 F152
G1 X50.195 Y72.466 Z-8.055 F152
G1 X50.215 Y72.409 Z-8.078 F152
G1 X50.226 Y72.38 Z-8.082 F152
G1 X50.23 Y72.366 Z-8.091 F152
G1 X50.231 Y72.362 Z-8.096 F152
; MOVEMENT_LINK_TRANSITION
G1 X50.234 Y72.355 F152
; MOVEMENT_CUTTING
G1 X50.235 Y72.352 F152
G1 X50.236 Y72.35 F152
G1 Y72.348 F152
G1 X50.237 Y72.344 F152
G1 X50.24 Y72.337 F152
G1 X50.242 Y72.335 F152
G1 X50.243 Y72.33 F152
G1 X50.246 Y72.323 F152
G1 X50.248 Y72.318 F152
G1 X50.252 Y72.309 F152
G1 X50.255 Y72.301 F152
G1 X50.257 Y72.294 F152
G1 X50.262 Y72.282 F152
G1 X50.269 Y72.266 F152
G1 X50.274 Y72.251 F152
G1 X50.277 Y72.245 F152
G1 X50.279 Y72.237 F152
G1 X50.285 Y72.223 F152
G1 X50.291 Y72.208 F152
G1 X50.318 Y72.137 F152
G1 X50.32 Y72.133 F152
G1 X50.322 Y72.122 F152
G1 X50.332 Y72.094 F152
G1 X50.341 Y72.065 F152
G1 X50.348 Y72.045 F152
G1 X50.36 Y72.008 F152
G1 X50.378 Y71.951 F152
G1 X50.388 Y71.922 F152
G1 X50.397 Y71.893 F152
G1 X50.406 Y71.867 F152
G1 X50.415 Y71.836 F152
G1 X50.434 Y71.779 F152
G1 X50.452 Y71.721 F152
G1 X50.463 Y71.689 F152
G1 X50.471 Y71.664 F152
G1 X50.487 Y71.607 F152
G1 X50.502 Y71.549 F152
G1 X50.52 Y71.486 F152
G1 X50.533 Y71.435 F152
G1 X50.562 Y71.32 F152
G1 X50.576 Y71.263 F152
G1 X50.577 Y71.258 F152
G1 X50.59 Y71.206 F152
G1 X50.602 Y71.148 F152
G1 X50.626 Y71.034 F152
G1 X50.635 Y70.993 F152
G1 X50.638 Y70.976 F152
G1 X50.649 Y70.919 F152
G1 X50.688 Y70.69 F152
G1 X50.692 Y70.668 F152
G1 X50.696 Y70.633 F152
G1 X50.704 Y70.575 F152
G1 X50.712 Y70.518 F152
G1 X50.719 Y70.461 F152
G1 X50.725 Y70.404 F152
G1 X50.741 Y70.232 F152
G1 X50.745 Y70.174 F152
G1 X50.747 Y70.117 F152
G1 X50.749 Y70.091 F152
G1 X50.75 Y70.06 F152
G1 X50.754 Y70.002 F152
G1 Y69.945 F152
G1 X50.755 Y69.888 F152
G1 Y69.773 F152
G1 X50.752 Y69.716 F152
G1 X50.75 Y69.659 F152
G1 X50.749 Y69.634 F152
G1 X50.747 Y69.601 F152
G1 X50.744 Y69.544 F152
G1 X50.733 Y69.429 F152
G1 X50.727 Y69.372 F152
G1 X50.72 Y69.315 F152
G1 X50.702 Y69.2 F152
G1 X50.692 Y69.149 F152
G1 X50.69 Y69.143 F152
G1 X50.667 Y69.028 F152
G1 X50.635 Y68.899 F152
G1 X50.623 Y68.856 F152
G1 X50.587 Y68.742 F152
G1 X50.577 Y68.71 F152
G1 X50.568 Y68.685 F152
G1 X50.525 Y68.57 F152
G1 X50.52 Y68.555 F152
G1 X50.503 Y68.513 F152
G1 X50.463 Y68.42 F152
G1 X50.453 Y68.398 F152
G1 X50.425 Y68.341 F152
G1 X50.406 Y68.303 F152
G1 X50.396 Y68.284 F152
G1 X50.366 Y68.226 F152
G1 X50.348 Y68.192 F152
G1 X50.337 Y68.169 F152
G1 X50.321 Y68.14 F152
G1 X50.305 Y68.112 F152
G1 X50.291 Y68.088 F152
G1 X50.287 Y68.083 F152
G1 X50.278 Y68.069 F152
G1 X50.27 Y68.054 F152
G1 X50.262 Y68.042 F152
G1 X50.261 Y68.04 F152
G1 X50.248 Y68.019 F152
G1 X50.245 Y68.013 F152
G1 X50.244 Y68.011 F152
G1 X50.243 Y68.01 F152
; MOVEMENT_LINK_TRANSITION
G1 X50.241 Y68.011 F152
; MOVEMENT_CUTTING
G1 X50.242 Y68.015 F152
G1 X50.243 Y68.016 F152
G1 X50.244 Y68.02 F152
G1 X50.248 Y68.034 F152
G1 X50.251 Y68.04 F152
G1 X50.253 Y68.047 F152
G1 X50.255 Y68.054 F152
G1 X50.262 Y68.076 F152
G1 X50.265 Y68.083 F152
G1 X50.269 Y68.097 F152
G1 X50.275 Y68.112 F152
G1 X50.294 Y68.169 F152
G1 X50.313 Y68.226 F152
G1 X50.33 Y68.284 F152
G1 X50.346 Y68.341 F152
G1 X50.348 Y68.354 F152
G1 X50.375 Y68.455 F152
G1 X50.389 Y68.513 F152
G1 X50.405 Y68.57 F152
G1 X50.406 Y68.575 F152
G1 X50.419 Y68.627 F152
G1 X50.431 Y68.685 F152
G1 X50.463 Y68.856 F152
G1 Y68.859 F152
G1 X50.474 Y68.914 F152
G1 X50.484 Y68.971 F152
G1 X50.494 Y69.028 F152
G1 X50.502 Y69.086 F152
G1 X50.508 Y69.143 F152
G1 X50.516 Y69.2 F152
G1 X50.52 Y69.241 F152
G1 X50.523 Y69.258 F152
G1 X50.53 Y69.315 F152
G1 X50.536 Y69.372 F152
G1 X50.543 Y69.429 F152
G1 X50.55 Y69.544 F152
G1 X50.553 Y69.601 F152
G1 X50.564 Y69.773 F152
G1 X50.567 Y69.831 F152
G1 Y69.888 F152
G1 Y70.117 F152
G1 X50.568 Y70.174 F152
G1 Y70.232 F152
G1 X50.567 Y70.289 F152
G1 X50.563 Y70.346 F152
G1 X50.56 Y70.404 F152
G1 X50.557 Y70.461 F152
G1 X50.554 Y70.518 F152
G1 X50.543 Y70.69 F152
G1 X50.525 Y70.862 F152
G1 X50.52 Y70.901 F152
G1 X50.518 Y70.919 F152
G1 X50.499 Y71.091 F152
G1 X50.491 Y71.148 F152
G1 X50.482 Y71.206 F152
G1 X50.464 Y71.32 F152
G1 X50.463 Y71.321 F152
G1 X50.454 Y71.378 F152
G1 X50.436 Y71.492 F152
G1 X50.425 Y71.549 F152
G1 X50.413 Y71.607 F152
G1 X50.406 Y71.64 F152
G1 X50.401 Y71.664 F152
G1 X50.376 Y71.779 F152
G1 X50.364 Y71.836 F152
G1 X50.348 Y71.909 F152
G1 X50.339 Y71.951 F152
G1 X50.325 Y72.008 F152
G1 X50.317 Y72.036 F152
G1 X50.31 Y72.065 F152
G1 X50.302 Y72.094 F152
G1 X50.295 Y72.122 F152
G1 X50.291 Y72.135 F152
G1 X50.279 Y72.18 F152
G1 X50.274 Y72.201 F152
G1 X50.268 Y72.223 F152
G1 X50.264 Y72.237 F152
G1 X50.262 Y72.243 F152
G1 X50.257 Y72.266 F152
G1 X50.252 Y72.28 F152
G1 X50.249 Y72.294 F152
G1 X50.247 Y72.301 F152
G1 X50.245 Y72.309 F152
G1 X50.24 Y72.33 F152
G1 X50.239 Y72.333 F152
G1 X50.238 Y72.335 F152
G1 X50.237 Y72.337 F152
G1 X50.235 Y72.344 F152
G1 Y72.347 F152
G1 X50.234 Y72.35 F152
G1 Y72.352 F152
G1 X50.233 Y72.354 F152
; MOVEMENT_LEAD_OUT
G1 X50.229 Y72.367 Z-8.093 F152
G1 X50.225 Y72.378 Z-8.086 F152
G1 X50.223 Y72.385 Z-8.075 F152
G1 X50.222 Y72.387 Z-8.061 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X54.405 Y85.059 F152
G1 Z0.877 F152
; MOVEMENT_PLUNGE
G1 Z-8.046 F51
; MOVEMENT_LEAD_IN
G1 X54.402 Y85.06 Z-8.065 F152
G1 X54.391 Y85.063 Z-8.081 F152
G1 X54.376 Y85.068 Z-8.092 F152
G1 X54.358 Y85.074 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X54.243 Y85.112 F152
G1 X54.193 Y85.129 F152
G1 X54.186 Y85.131 F152
G1 X54.129 Y85.151 F152
G1 X54.071 Y85.174 F152
G1 X54.042 Y85.186 F152
G1 X54.014 Y85.197 F152
G1 X53.957 Y85.22 F152
G1 X53.9 Y85.243 F152
G1 X53.898 F152
G1 X53.842 Y85.267 F152
G1 X53.785 Y85.294 F152
G1 X53.771 Y85.301 F152
G1 X53.728 Y85.321 F152
G1 X53.67 Y85.348 F152
G1 X53.65 Y85.358 F152
G1 X53.613 Y85.375 F152
G1 X53.556 Y85.404 F152
G1 X53.535 Y85.415 F152
G1 X53.499 Y85.435 F152
G1 X53.441 Y85.466 F152
G1 X53.431 Y85.473 F152
G1 X53.384 Y85.498 F152
G1 X53.327 Y85.529 F152
G1 X53.325 Y85.53 F152
G1 X53.269 Y85.563 F152
G1 X53.231 Y85.587 F152
G1 X53.212 Y85.599 F152
G1 X53.155 Y85.634 F152
G1 X53.139 Y85.644 F152
G1 X53.098 Y85.67 F152
G1 X53.047 Y85.702 F152
G1 X53.04 Y85.706 F152
G1 X52.983 Y85.746 F152
G1 X52.964 Y85.759 F152
G1 X52.926 Y85.786 F152
G1 X52.882 Y85.816 F152
G1 X52.868 Y85.825 F152
G1 X52.811 Y85.866 F152
G1 X52.754 Y85.909 F152
G1 X52.726 Y85.931 F152
G1 X52.697 Y85.954 F152
G1 X52.653 Y85.988 F152
G1 X52.639 Y85.999 F152
G1 X52.582 Y86.044 F152
G1 X52.58 Y86.046 F152
G1 X52.525 Y86.09 F152
G1 X52.511 Y86.103 F152
G1 X52.381 Y86.217 F152
G1 X52.353 Y86.242 F152
G1 X52.316 Y86.275 F152
G1 X52.296 Y86.294 F152
G1 X52.256 Y86.332 F152
G1 X52.238 Y86.35 F152
G1 X52.198 Y86.389 F152
G1 X52.181 Y86.406 F152
G1 X52.14 Y86.447 F152
G1 X52.083 Y86.504 F152
G1 X52.067 Y86.522 F152
G1 X52.031 Y86.561 F152
G1 X52.009 Y86.585 F152
G1 X51.979 Y86.619 F152
G1 X51.952 Y86.649 F152
G1 X51.927 Y86.676 F152
G1 X51.895 Y86.712 F152
G1 X51.877 Y86.733 F152
G1 X51.837 Y86.781 F152
G1 X51.785 Y86.848 F152
G1 X51.78 Y86.853 F152
G1 X51.739 Y86.905 F152
G1 X51.723 Y86.925 F152
G1 X51.693 Y86.962 F152
G1 X51.666 Y87.001 F152
G1 X51.652 Y87.02 F152
G1 X51.612 Y87.077 F152
G1 X51.608 Y87.082 F152
G1 X51.572 Y87.134 F152
G1 X51.551 Y87.165 F152
G1 X51.532 Y87.192 F152
G1 X51.496 Y87.249 F152
G1 X51.494 Y87.251 F152
G1 X51.461 Y87.306 F152
G1 X51.437 Y87.346 F152
G1 X51.426 Y87.363 F152
G1 X51.391 Y87.421 F152
G1 X51.379 Y87.44 F152
G1 X51.358 Y87.478 F152
G1 X51.328 Y87.535 F152
G1 X51.322 Y87.548 F152
G1 X51.299 Y87.593 F152
G1 X51.269 Y87.65 F152
G1 X51.265 Y87.66 F152
G1 X51.241 Y87.707 F152
G1 X51.214 Y87.764 F152
G1 X51.207 Y87.781 F152
G1 X51.166 Y87.879 F152
G1 X51.15 Y87.918 F152
G1 X51.142 Y87.936 F152
G1 X51.119 Y87.994 F152
G1 X51.099 Y88.051 F152
G1 X51.093 Y88.072 F152
G1 X51.081 Y88.108 F152
G1 X51.062 Y88.166 F152
G1 X51.036 Y88.251 F152
G1 X51.028 Y88.28 F152
G1 X51.013 Y88.337 F152
G1 X50.988 Y88.452 F152
G1 X50.978 Y88.499 F152
G1 X50.976 Y88.509 F152
G1 X50.965 Y88.567 F152
G1 X50.957 Y88.624 F152
G1 X50.951 Y88.681 F152
G1 X50.943 Y88.739 F152
G1 X50.937 Y88.796 F152
G1 X50.932 Y88.853 F152
G1 X50.93 Y88.91 F152
G1 Y89.082 F152
G1 X50.932 Y89.14 F152
G1 X50.936 Y89.197 F152
G1 X50.958 Y89.369 F152
G1 X50.966 Y89.426 F152
G1 X50.977 Y89.483 F152
G1 X50.978 Y89.485 F152
G1 X50.993 Y89.541 F152
G1 X51.023 Y89.655 F152
G1 X51.036 Y89.699 F152
G1 X51.039 Y89.713 F152
G1 X51.059 Y89.77 F152
G1 X51.083 Y89.827 F152
G1 X51.093 Y89.85 F152
G1 X51.107 Y89.884 F152
G1 X51.132 Y89.942 F152
G1 X51.15 Y89.981 F152
G1 X51.158 Y89.999 F152
G1 X51.189 Y90.056 F152
G1 X51.207 Y90.088 F152
G1 X51.224 Y90.114 F152
G1 X51.259 Y90.171 F152
G1 X51.265 Y90.179 F152
G1 X51.296 Y90.228 F152
G1 X51.322 Y90.267 F152
G1 X51.335 Y90.286 F152
G1 X51.379 Y90.341 F152
G1 X51.381 Y90.343 F152
G1 X51.43 Y90.4 F152
G1 X51.48 Y90.457 F152
G1 X51.494 Y90.473 F152
G1 X51.533 Y90.515 F152
G1 X51.551 Y90.533 F152
G1 X51.595 Y90.572 F152
G1 X51.608 Y90.584 F152
G1 X51.663 Y90.629 F152
G1 X51.666 Y90.632 F152
G1 X51.723 Y90.68 F152
G1 X51.731 Y90.687 F152
G1 X51.78 Y90.724 F152
G1 X51.808 Y90.744 F152
G1 X51.837 Y90.763 F152
G1 X51.895 Y90.799 F152
G1 X51.899 Y90.801 F152
G1 X51.952 Y90.834 F152
G1 X51.991 Y90.859 F152
G1 X52.009 Y90.869 F152
G1 X52.067 Y90.899 F152
G1 X52.181 Y90.951 F152
G1 X52.232 Y90.973 F152
G1 X52.296 Y91 F152
G1 X52.353 Y91.021 F152
G1 X52.387 Y91.03 F152
G1 X52.41 Y91.038 F152
G1 X52.468 Y91.055 F152
G1 X52.525 Y91.072 F152
G1 X52.579 Y91.088 F152
G1 X52.582 Y91.089 F152
G1 X52.639 Y91.101 F152
G1 X52.754 Y91.123 F152
G1 X52.868 Y91.142 F152
G1 X52.926 Y91.149 F152
G1 X53.098 Y91.162 F152
G1 X53.155 Y91.166 F152
G1 X53.212 F152
G1 X53.269 F152
G1 X53.327 F152
G1 X53.384 Y91.165 F152
G1 X53.441 Y91.163 F152
G1 X53.499 Y91.159 F152
G1 X53.556 Y91.153 F152
G1 X53.613 Y91.148 F152
G1 X53.636 Y91.145 F152
G1 X53.67 Y91.142 F152
G1 X53.728 Y91.136 F152
G1 X53.785 Y91.128 F152
G1 X53.842 Y91.117 F152
G1 X53.9 Y91.107 F152
G1 X53.957 Y91.097 F152
G1 X54.006 Y91.088 F152
G1 X54.014 Y91.087 F152
G1 X54.071 Y91.074 F152
G1 X54.129 Y91.06 F152
G1 X54.186 Y91.045 F152
G1 X54.241 Y91.03 F152
G1 X54.243 F152
G1 X54.3 Y91.016 F152
G1 X54.358 Y90.999 F152
G1 X54.415 Y90.98 F152
G1 X54.437 Y90.973 F152
G1 X54.472 Y90.961 F152
G1 X54.587 Y90.924 F152
G1 X54.61 Y90.916 F152
G1 X54.644 Y90.903 F152
G1 X54.701 Y90.881 F152
G1 X54.756 Y90.859 F152
G1 X54.759 Y90.858 F152
G1 X54.816 Y90.835 F152
G1 X54.873 Y90.812 F152
G1 X54.898 Y90.801 F152
G1 X54.931 Y90.787 F152
G1 X54.988 Y90.76 F152
G1 X55.022 Y90.744 F152
G1 X55.045 Y90.733 F152
G1 X55.102 Y90.706 F152
G1 X55.144 Y90.687 F152
G1 X55.16 Y90.679 F152
G1 X55.217 Y90.65 F152
G1 X55.254 Y90.629 F152
G1 X55.274 Y90.619 F152
G1 X55.446 Y90.525 F152
G1 X55.463 Y90.515 F152
G1 X55.555 Y90.457 F152
G1 X55.561 Y90.455 F152
G1 X55.618 Y90.419 F152
G1 X55.648 Y90.4 F152
G1 X55.675 Y90.383 F152
G1 X55.732 Y90.346 F152
G1 X55.738 Y90.343 F152
G1 X55.79 Y90.307 F152
G1 X55.82 Y90.286 F152
G1 X55.847 Y90.267 F152
G1 X55.902 Y90.228 F152
G1 X55.904 Y90.226 F152
G1 X55.962 Y90.186 F152
G1 X55.982 Y90.171 F152
G1 X56.019 Y90.143 F152
G1 X56.056 Y90.114 F152
G1 X56.129 Y90.056 F152
G1 X56.133 Y90.053 F152
G1 X56.191 Y90.008 F152
G1 X56.248 Y89.961 F152
G1 X56.305 Y89.91 F152
G1 X56.334 Y89.884 F152
G1 X56.399 Y89.827 F152
G1 X56.42 Y89.809 F152
G1 X56.464 Y89.77 F152
G1 X56.477 Y89.756 F152
G1 X56.522 Y89.713 F152
G1 X56.534 Y89.7 F152
G1 X56.58 Y89.655 F152
G1 X56.592 Y89.644 F152
G1 X56.638 Y89.598 F152
G1 X56.649 Y89.587 F152
G1 X56.695 Y89.541 F152
G1 X56.706 Y89.527 F152
G1 X56.746 Y89.483 F152
G1 X56.798 Y89.426 F152
G1 X56.821 Y89.401 F152
G1 X56.85 Y89.369 F152
G1 X56.878 Y89.337 F152
G1 X56.9 Y89.311 F152
G1 X56.935 Y89.267 F152
G1 X56.945 Y89.254 F152
G1 X56.992 Y89.197 F152
G1 X56.993 Y89.195 F152
G1 X57.037 Y89.14 F152
G1 X57.082 Y89.082 F152
G1 X57.107 Y89.046 F152
G1 X57.122 Y89.025 F152
G1 X57.163 Y88.968 F152
G1 X57.164 Y88.965 F152
G1 X57.203 Y88.91 F152
G1 X57.222 Y88.883 F152
G1 X57.242 Y88.853 F152
G1 X57.278 Y88.796 F152
G1 X57.279 Y88.794 F152
G1 X57.313 Y88.739 F152
G1 X57.336 Y88.7 F152
G1 X57.348 Y88.681 F152
G1 X57.383 Y88.624 F152
G1 X57.394 Y88.605 F152
G1 X57.415 Y88.567 F152
G1 X57.445 Y88.509 F152
G1 X57.451 Y88.496 F152
G1 X57.473 Y88.452 F152
G1 X57.503 Y88.395 F152
G1 X57.531 Y88.337 F152
G1 X57.557 Y88.28 F152
G1 X57.565 Y88.26 F152
G1 X57.581 Y88.223 F152
G1 X57.605 Y88.166 F152
G1 X57.623 Y88.122 F152
G1 X57.629 Y88.108 F152
G1 X57.651 Y88.051 F152
G1 X57.67 Y87.994 F152
G1 X57.68 Y87.963 F152
G1 X57.689 Y87.936 F152
G1 X57.707 Y87.879 F152
G1 X57.726 Y87.822 F152
G1 X57.737 Y87.781 F152
G1 X57.742 Y87.764 F152
G1 X57.755 Y87.707 F152
G1 X57.793 Y87.535 F152
G1 X57.794 Y87.525 F152
G1 X57.803 Y87.478 F152
G1 X57.811 Y87.421 F152
G1 X57.817 Y87.363 F152
G1 X57.824 Y87.306 F152
G1 X57.83 Y87.249 F152
G1 X57.835 Y87.192 F152
G1 X57.836 Y87.134 F152
G1 Y86.962 F152
G1 X57.834 Y86.905 F152
G1 X57.829 Y86.848 F152
G1 X57.814 Y86.733 F152
G1 X57.806 Y86.676 F152
G1 X57.797 Y86.619 F152
G1 X57.794 Y86.604 F152
G1 X57.786 Y86.561 F152
G1 X57.755 Y86.447 F152
G1 X57.739 Y86.389 F152
G1 X57.737 Y86.382 F152
G1 X57.722 Y86.332 F152
G1 X57.701 Y86.275 F152
G1 X57.653 Y86.16 F152
G1 X57.628 Y86.103 F152
G1 X57.623 Y86.091 F152
G1 X57.601 Y86.046 F152
G1 X57.57 Y85.988 F152
G1 X57.534 Y85.931 F152
G1 X57.508 Y85.89 F152
G1 X57.498 Y85.874 F152
G1 X57.462 Y85.816 F152
G1 X57.451 Y85.8 F152
G1 X57.421 Y85.759 F152
G1 X57.394 Y85.724 F152
G1 X57.374 Y85.702 F152
G1 X57.336 Y85.658 F152
G1 X57.325 Y85.644 F152
G1 X57.279 Y85.593 F152
G1 X57.275 Y85.587 F152
G1 X57.222 Y85.532 F152
G1 X57.22 Y85.53 F152
G1 X57.164 Y85.48 F152
G1 X57.155 Y85.473 F152
G1 X57.107 Y85.431 F152
G1 X57.088 Y85.415 F152
G1 X57.05 Y85.383 F152
G1 X57.019 Y85.358 F152
G1 X56.993 Y85.337 F152
G1 X56.935 Y85.299 F152
G1 X56.878 Y85.263 F152
G1 X56.846 Y85.243 F152
G1 X56.821 Y85.227 F152
G1 X56.763 Y85.192 F152
G1 X56.752 Y85.186 F152
G1 X56.706 Y85.162 F152
G1 X56.649 Y85.135 F152
G1 X56.634 Y85.129 F152
G1 X56.592 Y85.11 F152
G1 X56.534 Y85.084 F152
G1 X56.505 Y85.072 F152
G1 X56.477 Y85.06 F152
G1 X56.42 Y85.039 F152
G1 X56.363 Y85.021 F152
G1 X56.337 Y85.014 F152
G1 X56.305 Y85.004 F152
G1 X56.248 Y84.986 F152
G1 X56.191 Y84.97 F152
G1 X56.133 Y84.958 F152
G1 X56.129 Y84.957 F152
G1 X55.962 Y84.926 F152
G1 X55.904 Y84.916 F152
G1 X55.847 Y84.909 F152
G1 X55.732 Y84.901 F152
G1 X55.719 Y84.9 F152
G1 X55.675 Y84.896 F152
G1 X55.618 Y84.892 F152
G1 X55.561 Y84.891 F152
G1 X55.446 Y84.892 F152
G1 X55.389 F152
G1 X55.331 Y84.894 F152
G1 X55.274 Y84.898 F152
G1 X55.256 Y84.9 F152
G1 X55.217 Y84.903 F152
G1 X55.16 Y84.909 F152
G1 X55.102 Y84.915 F152
G1 X55.045 Y84.92 F152
G1 X54.988 Y84.928 F152
G1 X54.931 Y84.938 F152
G1 X54.83 Y84.957 F152
G1 X54.816 Y84.959 F152
G1 X54.759 Y84.969 F152
G1 X54.701 Y84.981 F152
G1 X54.644 Y84.996 F152
G1 X54.587 Y85.011 F152
G1 X54.574 Y85.014 F152
G1 X54.53 Y85.025 F152
G1 X54.472 Y85.04 F152
G1 X54.415 Y85.056 F152
G1 X54.368 Y85.072 F152
G1 X54.358 Y85.074 F152
; MOVEMENT_LEAD_OUT
G1 X54.339 Y85.079 Z-8.092 F152
G1 X54.324 Y85.084 Z-8.081 F152
G1 X54.313 Y85.086 Z-8.065 F152
G1 X54.31 Y85.087 Z-8.046 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X69.767 Y49.183 F152
G1 Z0.865 F152
; MOVEMENT_PLUNGE
G1 Z-8.036 F51
; MOVEMENT_LEAD_IN
G1 X69.768 Y49.18 Z-8.053 F152
G1 X69.769 Y49.171 Z-8.069 F152
G1 X69.772 Y49.157 Z-8.08 F152
G1 X69.775 Y49.141 Z-8.085 F152
G1 X69.777 Y49.123 F152
; MOVEMENT_CUTTING
G1 X69.778 Y49.118 Z-8.058 F152
G1 X69.781 Y49.103 Z-7.986 F152
G1 X69.783 Y49.089 Z-7.92 F152
G1 X69.785 Y49.075 Z-7.848 F152
G1 X69.787 Y49.06 Z-7.782 F152
G1 X69.793 Y49.032 Z-7.637 F152
G1 X69.794 Y49.017 Z-7.572 F152
G1 X69.797 Y49.003 Z-7.499 F152
G1 X69.8 Y48.989 Z-7.42 F152
G1 X69.802 Y48.974 Z-7.335 F152
G1 X69.806 Y48.946 Z-7.18 F152
G1 X69.809 Y48.931 Z-7.095 F152
G1 X69.811 Y48.917 Z-7.017 F152
G1 X69.813 Y48.903 Z-6.932 F152
G1 X69.817 Y48.874 Z-6.777 F152
G1 X69.82 Y48.86 Z-6.692 F152
G1 X69.821 Y48.846 Z-6.615 F152
G1 X69.823 Y48.832 Z-6.541 F152
G1 X69.827 Y48.817 Z-6.447 F152
G1 X69.829 Y48.803 Z-6.36 F152
G1 X69.835 Y48.774 Z-6.19 F152
G1 X69.837 Y48.76 Z-6.1 F152
G1 X69.839 Y48.745 Z-6.011 F152
G1 X69.845 Y48.717 Z-5.82 F152
G1 X69.847 Y48.702 Z-5.724 F152
G1 X69.852 Y48.666 Z-5.482 F152
G1 X69.854 Y48.659 Z-5.427 F152
G1 Y48.652 Z-5.379 F152
G1 X69.856 Y48.645 Z-5.324 F152
G1 X69.857 Y48.638 Z-5.275 F152
G1 X69.859 Y48.631 Z-5.221 F152
G1 X69.86 Y48.624 Z-5.172 F152
G1 X69.862 Y48.602 Z-5.013 F152
G1 X69.864 Y48.595 Z-4.954 F152
G1 X69.865 Y48.588 Z-4.902 F152
G1 X69.867 Y48.581 Z-4.843 F152
G1 X69.868 Y48.573 Z-4.79 F152
G1 X69.87 Y48.566 Z-4.73 F152
G1 X69.873 Y48.538 Z-4.501 F152
G1 X69.875 Y48.53 Z-4.438 F152
G1 X69.876 Y48.523 Z-4.381 F152
G1 X69.878 Y48.516 Z-4.319 F152
G1 X69.879 Y48.502 Z-4.196 F152
G1 X69.88 Y48.495 Z-4.142 F152
; MOVEMENT_LEAD_OUT
G1 Z-4.136 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X73.745 Y44.88 F152
G1 Z0.876 F152
; MOVEMENT_PLUNGE
G1 Z-8.067 F51
; MOVEMENT_LEAD_IN
G1 X73.747 Z-8.079 F152
G1 X73.754 Y44.882 Z-8.089 F152
G1 X73.765 Y44.884 Z-8.096 F152
G1 X73.777 Y44.887 Z-8.097 F152
G1 X73.788 Y44.889 Z-8.093 F152
; MOVEMENT_CUTTING
G1 X73.79 F152
G1 X73.804 Z-8.056 F152
G1 X73.833 Y44.89 Z-7.993 F152
G1 X73.861 Z-7.924 F152
G1 X73.89 Z-7.86 F152
G1 X73.919 Z-7.804 F152
G1 X73.947 Y44.889 Z-7.747 F152
G1 X73.976 Y44.888 Z-7.697 F152
G1 X74.004 Z-7.653 F152
G1 X74.062 Y44.884 Z-7.551 F152
G1 X74.09 Y44.881 Z-7.494 F152
G1 X74.119 Y44.88 Z-7.453 F152
G1 X74.148 Y44.877 Z-7.412 F152
G1 X74.176 Y44.873 Z-7.37 F152
G1 X74.234 Y44.866 Z-7.294 F152
G1 X74.291 Y44.86 Z-7.231 F152
G1 X74.348 Y44.851 Z-7.173 F152
G1 X74.358 Y44.849 Z-7.163 F152
G1 X74.405 Y44.84 Z-7.111 F152
G1 X74.463 Y44.83 Z-7.063 F152
G1 X74.52 Y44.818 Z-7.018 F152
G1 X74.577 Y44.806 Z-6.986 F152
G1 X74.635 Y44.794 Z-6.955 F152
G1 X74.642 Y44.792 Z-6.952 F152
G1 X74.692 Y44.778 Z-6.93 F152
G1 X74.806 Y44.748 Z-6.889 F152
G1 X74.859 Y44.734 Z-6.875 F152
G1 X74.864 Y44.733 Z-6.868 F152
G1 X74.921 Y44.717 Z-6.851 F152
G1 X74.978 Y44.699 Z-6.846 F152
G1 X75.035 Y44.681 Z-6.841 F152
G1 X75.048 Y44.677 Z-6.843 F152
G1 X75.093 Y44.663 Z-6.837 F152
G1 X75.15 Y44.644 Z-6.825 F152
G1 X75.207 Y44.625 Z-6.822 F152
G1 X75.224 Y44.62 Z-6.829 F152
G1 X75.265 Y44.606 Z-6.832 F152
G1 X75.379 Y44.564 Z-6.836 F152
G1 X75.385 Y44.563 Z-6.837 F152
G1 X75.436 Y44.544 Z-6.838 F152
G1 X75.494 Y44.522 Z-6.842 F152
G1 X75.538 Y44.505 Z-6.856 F152
G1 X75.551 Y44.5 Z-6.854 F152
G1 X75.608 Y44.477 Z-6.859 F152
G1 X75.666 Y44.454 Z-6.872 F152
G1 X75.681 Y44.448 F152
G1 X75.723 Y44.431 Z-6.877 F152
G1 X75.78 Y44.407 Z-6.884 F152
G1 X75.819 Y44.391 Z-6.902 F152
G1 X75.837 Y44.382 F152
G1 X75.895 Y44.356 Z-6.912 F152
G1 X75.946 Y44.333 Z-6.928 F152
G1 X75.952 Y44.331 Z-6.93 F152
G1 X76.009 Y44.305 Z-6.941 F152
G1 X76.066 Y44.278 Z-6.952 F152
G1 X76.071 Y44.276 Z-6.957 F152
G1 X76.124 Y44.249 Z-6.975 F152
G1 X76.181 Y44.221 Z-6.999 F152
G1 X76.184 Y44.219 Z-6.996 F152
G1 X76.238 Y44.191 Z-7.015 F152
G1 X76.296 Y44.162 Z-7.032 F152
G1 X76.297 Z-7.036 F152
G1 X76.353 Y44.132 Z-7.054 F152
G1 X76.402 Y44.104 Z-7.077 F152
G1 X76.41 Y44.099 Z-7.074 F152
G1 X76.467 Y44.067 Z-7.102 F152
G1 X76.502 Y44.047 Z-7.12 F152
G1 X76.525 Y44.033 Z-7.131 F152
G1 X76.582 Y43.999 Z-7.165 F152
G1 X76.597 Y43.99 Z-7.176 F152
G1 X76.639 Y43.963 Z-7.191 F152
G1 X76.687 Y43.932 Z-7.223 F152
G1 X76.697 Y43.925 Z-7.225 F152
G1 X76.754 Y43.888 Z-7.267 F152
G1 X76.773 Y43.875 Z-7.279 F152
G1 X76.811 Y43.849 Z-7.306 F152
G1 X76.855 Y43.818 Z-7.341 F152
G1 X76.868 Y43.808 Z-7.351 F152
G1 X76.926 Y43.766 Z-7.392 F152
G1 X76.933 Y43.76 Z-7.397 F152
G1 X76.983 Y43.722 Z-7.439 F152
G1 X77.007 Y43.703 Z-7.47 F152
G1 X77.04 Y43.676 Z-7.507 F152
G1 X77.077 Y43.646 Z-7.543 F152
G1 X77.098 Y43.628 Z-7.558 F152
G1 X77.145 Y43.589 Z-7.605 F152
G1 X77.155 Y43.58 Z-7.609 F152
G1 X77.212 Y43.531 Z-7.661 F152
G1 X77.241 Y43.506 Z-7.691 F152
G1 X77.269 Y43.48 Z-7.729 F152
G1 X77.276 Y43.474 Z-7.736 F152
G1 X77.327 Y43.423 Z-7.801 F152
G1 X77.333 Y43.417 Z-7.809 F152
G1 X77.384 Y43.365 Z-7.869 F152
G1 X77.447 Y43.302 Z-7.95 F152
G1 X77.498 Y43.247 Z-8.005 F152
G1 X77.5 Y43.245 Z-8.003 F152
G1 X77.549 Y43.187 Z-8.066 F152
G1 X77.556 Y43.18 Z-8.078 F152
G1 X77.561 Y43.173 Z-8.083 F152
G1 X77.567 Y43.166 Z-8.095 F152
; MOVEMENT_LINK_TRANSITION
G1 X77.573 Y43.159 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X77.574 Y43.157 F152
G1 X77.576 Y43.154 F152
G1 X77.577 Y43.152 F152
G1 X77.579 Y43.149 F152
G1 X77.58 Y43.147 F152
G1 X77.582 Y43.144 F152
G1 X77.587 Y43.137 F152
G1 X77.599 Y43.119 F152
G1 X77.61 Y43.102 F152
G1 X77.613 Y43.097 F152
G1 X77.619 Y43.087 F152
G1 X77.629 Y43.073 F152
G1 X77.642 Y43.053 F152
G1 X77.648 Y43.044 F152
G1 X77.667 Y43.016 F152
G1 X77.67 Y43.009 F152
G1 X77.686 Y42.987 F152
G1 X77.704 Y42.958 F152
G1 X77.728 Y42.922 F152
G1 X77.74 Y42.901 F152
G1 X77.785 Y42.817 F152
G1 X77.802 Y42.786 F152
G1 X77.832 Y42.729 F152
G1 X77.842 Y42.709 F152
G1 X77.863 Y42.672 F152
G1 X77.893 Y42.614 F152
G1 X77.922 Y42.557 F152
G1 X77.947 Y42.5 F152
G1 X77.957 Y42.478 F152
G1 X77.973 Y42.443 F152
G1 X77.999 Y42.385 F152
G1 X78.014 Y42.351 F152
G1 X78.025 Y42.328 F152
G1 X78.051 Y42.271 F152
G1 X78.071 Y42.219 F152
G1 X78.074 Y42.213 F152
G1 X78.12 Y42.099 F152
G1 X78.129 Y42.077 F152
G1 X78.132 Y42.07 F152
G1 X78.137 Y42.056 F152
G1 X78.139 Y42.05 F152
G1 X78.144 Y42.042 F152
G1 X78.146 Y42.034 F152
G1 X78.147 Y42.032 F152
; MOVEMENT_LINK_TRANSITION
G1 Y42.033 F152
; MOVEMENT_CUTTING
G1 X78.148 Y42.034 F152
G1 Y42.042 F152
G1 X78.149 Y42.056 F152
G1 X78.148 Y42.07 F152
G1 Y42.084 F152
G1 X78.147 Y42.099 F152
G1 X78.146 Y42.156 F152
G1 X78.139 Y42.213 F152
G1 X78.129 Y42.271 F152
G1 Y42.281 F152
G1 X78.119 Y42.328 F152
G1 X78.103 Y42.385 F152
G1 X78.082 Y42.443 F152
G1 X78.071 Y42.473 F152
G1 X78.06 Y42.5 F152
G1 X78.034 Y42.557 F152
G1 X78.014 Y42.597 F152
G1 X77.973 Y42.672 F152
G1 X77.936 Y42.729 F152
G1 X77.899 Y42.785 F152
G1 Y42.786 F152
G1 X77.857 Y42.844 F152
G1 X77.842 Y42.864 F152
G1 X77.785 Y42.931 F152
G1 X77.728 Y42.998 F152
G1 X77.67 Y43.065 F152
G1 X77.663 Y43.073 F152
G1 X77.642 Y43.094 F152
G1 X77.634 Y43.102 F152
G1 X77.61 Y43.125 F152
G1 X77.604 Y43.13 F152
G1 X77.579 Y43.155 F152
G1 X77.577 Y43.157 F152
G1 X77.575 Y43.159 F152
; MOVEMENT_LEAD_OUT
G1 X77.572 Z-8.089 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X78.143 Y42.084 F152
G1 Z0.875 F152
; MOVEMENT_PLUNGE
G1 Z-8.042 F51
; MOVEMENT_LEAD_IN
G1 Y42.081 Z-8.058 F152
G1 Y42.073 Z-8.073 F152
G1 X78.144 Y42.061 Z-8.084 F152
G1 X78.146 Y42.046 Z-8.09 F152
G1 X78.147 Y42.03 Z-8.092 F152
; MOVEMENT_CUTTING
G1 Y42.027 Z-8.084 F152
G1 X78.149 Y42.013 Z-8.05 F152
G1 X78.154 Y41.984 Z-7.99 F152
G1 X78.157 Y41.956 Z-7.922 F152
G1 X78.161 Y41.927 Z-7.855 F152
G1 X78.163 Y41.898 Z-7.781 F152
G1 X78.171 Y41.784 Z-7.454 F152
G1 Y41.669 Z-7.066 F152
G1 Y41.64 Z-6.962 F152
G1 X78.168 Y41.597 Z-6.782 F152
G1 Y41.583 Z-6.73 F152
G1 X78.163 Y41.512 Z-6.431 F152
G1 Y41.497 Z-6.378 F152
G1 X78.162 Y41.483 Z-6.311 F152
G1 X78.161 Y41.469 Z-6.251 F152
G1 X78.154 Y41.411 Z-5.982 F152
G1 X78.153 Y41.397 Z-5.914 F152
G1 X78.151 Y41.383 Z-5.839 F152
G1 X78.149 Y41.354 Z-5.702 F152
G1 X78.146 Y41.325 Z-5.551 F152
G1 X78.143 Y41.311 Z-5.469 F152
G1 X78.141 Y41.297 Z-5.393 F152
G1 X78.138 Y41.282 Z-5.31 F152
G1 X78.137 Y41.268 Z-5.235 F152
G1 X78.134 Y41.254 Z-5.152 F152
G1 X78.132 Y41.239 Z-5.077 F152
G1 X78.129 Y41.223 Z-4.984 F152
G1 Y41.208 Z-4.898 F152
G1 X78.127 Y41.196 Z-4.824 F152
G1 X78.119 Y41.153 Z-4.54 F152
G1 X78.117 Y41.139 Z-4.453 F152
G1 X78.109 Y41.096 Z-4.169 F152
G1 X78.107 Y41.089 Z-4.118 F152
G1 Y41.085 Z-4.099 F152
G1 X78.106 Y41.082 Z-4.07 F152
G1 X78.105 Y41.075 Z-4.018 F152
G1 Y41.067 Z-3.971 F152
G1 X78.101 Y41.032 Z-3.709 F152
G1 X78.095 Y41.01 Z-3.534 F152
G1 Y41.003 Z-3.482 F152
G1 X78.087 Y40.974 Z-3.249 F152
G1 X78.085 Y40.967 Z-3.185 F152
G1 X78.083 Y40.96 Z-3.127 F152
G1 X78.08 Y40.953 Z-3.063 F152
; MOVEMENT_LEAD_OUT
G1 Z-3.057 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X74.749 Y39.911 F152
G1 Z0.953 F152
; MOVEMENT_PLUNGE
G1 Z-5.772 F51
; MOVEMENT_LEAD_IN
G1 Y39.912 Z-5.777 F152
; MOVEMENT_CUTTING
G1 X74.747 Y39.914 Z-5.806 F152
G1 X74.735 Y39.929 Z-5.969 F152
G1 X74.728 Y39.936 Z-6.047 F152
G1 X74.723 Y39.943 Z-6.122 F152
G1 X74.711 Y39.957 Z-6.277 F152
G1 X74.704 Y39.965 Z-6.35 F152
G1 X74.699 Y39.972 Z-6.419 F152
G1 X74.694 Y39.979 Z-6.484 F152
G1 X74.692 Y39.982 Z-6.509 F152
G1 X74.688 Y39.986 Z-6.55 F152
G1 X74.672 Y40.007 Z-6.745 F152
G1 X74.666 Y40.015 Z-6.811 F152
G1 X74.66 Y40.022 Z-6.876 F152
G1 X74.648 Y40.036 Z-7.006 F152
G1 X74.641 Y40.045 Z-7.084 F152
G1 X74.63 Y40.058 Z-7.202 F152
G1 X74.611 Y40.079 Z-7.397 F152
G1 X74.605 Y40.086 Z-7.456 F152
G1 X74.6 Y40.093 Z-7.512 F152
G1 X74.593 Y40.101 Z-7.567 F152
G1 X74.583 Y40.115 Z-7.681 F152
G1 X74.558 Y40.143 Z-7.901 F152
G1 X74.552 Y40.151 Z-7.959 F152
G1 X74.549 Y40.155 Z-7.994 F152
G1 X74.54 Y40.165 Z-8.069 F152
G1 X74.538 Y40.168 Z-8.091 F152
; MOVEMENT_LINK_TRANSITION
G1 X74.536 Y40.169 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X74.52 Y40.173 F152
G1 X74.463 Y40.191 F152
G1 X74.414 Y40.208 F152
G1 X74.405 Y40.212 F152
G1 X74.348 Y40.238 F152
G1 X74.296 Y40.265 F152
G1 X74.291 Y40.269 F152
G1 X74.234 Y40.303 F152
G1 X74.207 Y40.323 F152
G1 X74.176 Y40.346 F152
G1 X74.137 Y40.38 F152
G1 X74.119 Y40.398 F152
G1 X74.084 Y40.437 F152
G1 X74.062 Y40.467 F152
G1 X74.044 Y40.494 F152
G1 X74.012 Y40.552 F152
G1 X73.987 Y40.609 F152
G1 X73.966 Y40.666 F152
G1 X73.948 Y40.724 F152
G1 X73.947 Y40.725 F152
G1 X73.93 Y40.781 F152
G1 X73.9 Y40.896 F152
G1 X73.89 Y40.932 F152
G1 X73.885 Y40.953 F152
G1 X73.871 Y41.01 F152
G1 X73.842 Y41.125 F152
G1 X73.833 Y41.165 F152
G1 X73.829 Y41.182 F152
G1 X73.814 Y41.239 F152
G1 X73.799 Y41.297 F152
G1 X73.784 Y41.354 F152
G1 X73.77 Y41.411 F152
G1 X73.754 Y41.469 F152
G1 X73.737 Y41.526 F152
G1 X73.721 Y41.583 F152
G1 X73.718 Y41.59 F152
G1 X73.704 Y41.64 F152
G1 X73.687 Y41.698 F152
G1 X73.678 Y41.726 F152
G1 X73.668 Y41.755 F152
G1 X73.663 Y41.769 F152
G1 X73.661 Y41.774 F152
G1 X73.658 Y41.784 F152
G1 X73.653 Y41.798 F152
G1 X73.65 Y41.807 F152
G1 X73.648 Y41.812 F152
G1 X73.646 Y41.815 F152
G1 Y41.818 F152
G1 X73.645 Y41.82 F152
G1 X73.644 Y41.821 F152
; MOVEMENT_LINK_TRANSITION
G1 X73.645 F152
; MOVEMENT_CUTTING
G1 X73.646 Y41.819 F152
G1 X73.648 Y41.818 F152
G1 X73.652 Y41.814 F152
G1 X73.653 Y41.812 F152
G1 X73.655 Y41.81 F152
G1 X73.658 Y41.807 F152
G1 X73.661 Y41.804 F152
G1 X73.689 Y41.773 F152
G1 X73.706 Y41.755 F152
G1 X73.718 Y41.742 F152
G1 X73.758 Y41.698 F152
G1 X73.775 Y41.678 F152
G1 X73.809 Y41.64 F152
G1 X73.833 Y41.614 F152
G1 X73.859 Y41.583 F152
G1 X73.89 Y41.549 F152
G1 X73.91 Y41.526 F152
G1 X73.947 Y41.482 F152
G1 X73.959 Y41.469 F152
G1 X74.004 Y41.411 F152
G1 X74.049 Y41.354 F152
G1 X74.091 Y41.297 F152
G1 X74.119 Y41.258 F152
G1 X74.132 Y41.239 F152
G1 X74.169 Y41.182 F152
G1 X74.176 Y41.17 F152
G1 X74.204 Y41.125 F152
G1 X74.234 Y41.077 F152
G1 X74.239 Y41.067 F152
G1 X74.272 Y41.01 F152
G1 X74.291 Y40.974 F152
G1 X74.302 Y40.953 F152
G1 X74.348 Y40.862 F152
G1 X74.359 Y40.838 F152
G1 X74.382 Y40.781 F152
G1 X74.405 Y40.726 F152
G1 X74.406 Y40.724 F152
G1 X74.43 Y40.666 F152
G1 X74.447 Y40.609 F152
G1 X74.463 Y40.563 F152
G1 X74.466 Y40.552 F152
G1 X74.484 Y40.494 F152
G1 X74.52 Y40.331 F152
G1 X74.527 Y40.265 F152
G1 X74.532 Y40.208 F152
G1 X74.536 Y40.179 F152
G1 Y40.172 F152
G1 X74.537 Y40.17 F152
; MOVEMENT_LEAD_OUT
G1 Z-8.032 F152
G1 X74.536 Y40.173 Z-8.013 F152
G1 X74.531 Y40.181 Z-7.995 F152
G1 X74.525 Y40.193 Z-7.982 F152
G1 X74.517 Y40.208 Z-7.973 F152
G1 X74.507 Y40.225 Z-7.97 F152
; MOVEMENT_LINK_TRANSITION
G1 X73.707 Y41.713 F152
; MOVEMENT_LEAD_IN
G1 X73.698 Y41.73 Z-7.973 F152
G1 X73.689 Y41.746 Z-7.982 F152
G1 X73.683 Y41.758 Z-7.995 F152
G1 X73.679 Y41.766 Z-8.013 F152
G1 X73.677 Y41.768 Z-8.032 F152
G1 X73.676 Y41.771 Z-8.052 F152
G1 X73.671 Y41.779 Z-8.069 F152
G1 X73.663 Y41.791 Z-8.083 F152
G1 X73.654 Y41.806 Z-8.092 F152
G1 X73.644 Y41.823 Z-8.095 F152
; MOVEMENT_CUTTING
G1 X73.633 Y41.841 Z-8.057 F152
G1 X73.616 Y41.87 Z-7.995 F152
G1 X73.603 Y41.891 Z-7.947 F152
G1 X73.583 Y41.927 Z-7.871 F152
G1 X73.549 Y41.984 Z-7.757 F152
G1 X73.546 Y41.989 Z-7.748 F152
G1 X73.532 Y42.013 Z-7.7 F152
G1 X73.514 Y42.042 Z-7.649 F152
G1 X73.489 Y42.081 Z-7.582 F152
G1 X73.478 Y42.099 Z-7.548 F152
G1 X73.461 Y42.127 Z-7.502 F152
G1 X73.444 Y42.156 Z-7.462 F152
G1 X73.432 Y42.177 Z-7.435 F152
G1 X73.41 Y42.213 Z-7.381 F152
G1 X73.376 Y42.271 Z-7.301 F152
G1 X73.374 Y42.273 Z-7.299 F152
G1 X73.34 Y42.328 Z-7.236 F152
G1 X73.317 Y42.367 Z-7.2 F152
G1 X73.306 Y42.385 Z-7.188 F152
G1 X73.272 Y42.443 Z-7.147 F152
G1 X73.26 Y42.464 Z-7.134 F152
G1 X73.24 Y42.5 Z-7.114 F152
G1 X73.208 Y42.557 Z-7.093 F152
G1 X73.203 Y42.566 Z-7.092 F152
G1 X73.175 Y42.614 Z-7.09 F152
G1 X73.145 Y42.669 Z-7.107 F152
G1 X73.144 Y42.672 Z-7.104 F152
G1 X73.113 Y42.729 Z-7.134 F152
G1 X73.088 Y42.775 Z-7.158 F152
G1 X73.082 Y42.786 Z-7.163 F152
G1 X73.049 Y42.844 Z-7.207 F152
G1 X73.031 Y42.879 Z-7.242 F152
G1 X73.02 Y42.901 Z-7.266 F152
G1 X73.005 Y42.93 Z-7.314 F152
G1 X72.991 Y42.958 Z-7.354 F152
G1 X72.973 Y42.993 Z-7.417 F152
G1 X72.963 Y43.016 Z-7.45 F152
G1 X72.948 Y43.044 Z-7.498 F152
G1 X72.933 Y43.073 Z-7.554 F152
G1 X72.916 Y43.105 Z-7.617 F152
G1 X72.904 Y43.13 Z-7.666 F152
G1 X72.889 Y43.159 Z-7.731 F152
G1 X72.876 Y43.187 Z-7.797 F152
G1 X72.868 Y43.205 Z-7.839 F152
G1 X72.859 Y43.223 Z-7.894 F152
G1 X72.849 Y43.245 Z-7.955 F152
G1 X72.836 Y43.273 Z-8.046 F152
G1 X72.828 Y43.288 Z-8.096 F152
; MOVEMENT_LEAD_OUT
G1 X72.82 Y43.305 Z-8.092 F152
G1 X72.813 Y43.319 Z-8.081 F152
G1 X72.808 Y43.329 Z-8.065 F152
G1 X72.806 Y43.333 Z-8.046 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X69.935 Y40.691 F152
G1 Z0.866 F152
; MOVEMENT_PLUNGE
G1 Z-8.037 F51
; MOVEMENT_LEAD_IN
G1 X69.937 Y40.689 Z-8.054 F152
G1 X69.944 Y40.683 Z-8.069 F152
G1 X69.955 Y40.675 Z-8.08 F152
G1 X69.968 Y40.665 Z-8.086 F152
G1 X69.982 Y40.655 F152
; MOVEMENT_CUTTING
G1 X69.984 Y40.653 Z-8.076 F152
G1 X69.985 Y40.652 Z-8.065 F152
G1 X69.995 Y40.644 Z-8.004 F152
G1 X70.024 Y40.619 Z-7.812 F152
G1 X70.034 Y40.609 Z-7.735 F152
G1 X70.043 Y40.601 Z-7.673 F152
G1 X70.052 Y40.594 Z-7.619 F152
G1 X70.095 Y40.556 Z-7.33 F152
G1 X70.1 Y40.552 Z-7.295 F152
G1 X70.109 Y40.544 Z-7.234 F152
G1 X70.152 Y40.506 Z-6.945 F152
G1 X70.166 Y40.494 Z-6.856 F152
G1 X70.167 Z-6.849 F152
G1 X70.21 Y40.456 Z-6.56 F152
G1 X70.224 Y40.444 Z-6.472 F152
G1 X70.232 Y40.437 Z-6.417 F152
G1 X70.238 Y40.432 Z-6.376 F152
G1 X70.267 Y40.409 Z-6.2 F152
G1 X70.281 Y40.397 Z-6.111 F152
G1 X70.296 Y40.384 Z-6.013 F152
G1 X70.302 Y40.38 Z-5.979 F152
G1 X70.31 Y40.373 Z-5.923 F152
G1 X70.32 Y40.365 Z-5.862 F152
G1 X70.329 Y40.357 Z-5.799 F152
G1 X70.339 Y40.349 Z-5.744 F152
G1 X70.356 Y40.335 Z-5.633 F152
G1 X70.367 Y40.326 Z-5.564 F152
G1 X70.372 Y40.323 Z-5.537 F152
G1 X70.382 Y40.314 Z-5.466 F152
G1 X70.425 Y40.279 Z-5.197 F152
G1 X70.433 Y40.272 Z-5.142 F152
G1 X70.441 Y40.265 Z-5.093 F152
G1 X70.453 Y40.255 Z-5.018 F152
G1 X70.496 Y40.221 Z-4.749 F152
G1 X70.51 Y40.209 Z-4.659 F152
G1 X70.512 Y40.208 Z-4.652 F152
G1 X70.525 Y40.198 Z-4.573 F152
G1 X70.539 Y40.187 Z-4.48 F152
G1 X70.568 Y40.165 Z-4.31 F152
G1 X70.577 Y40.157 Z-4.245 F152
G1 X70.586 Y40.151 Z-4.196 F152
G1 X70.596 Y40.143 Z-4.132 F152
G1 X70.611 Y40.131 Z-4.039 F152
G1 X70.625 Y40.12 Z-3.953 F152
G1 X70.634 Y40.113 Z-3.896 F152
G1 X70.642 Y40.107 Z-3.847 F152
G1 X70.654 Y40.098 Z-3.775 F152
G1 X70.659 Y40.093 Z-3.739 F152
G1 X70.668 Y40.086 Z-3.682 F152
G1 X70.682 Y40.076 Z-3.597 F152
G1 X70.697 Y40.064 Z-3.504 F152
G1 X70.711 Y40.053 Z-3.419 F152
G1 X70.725 Y40.042 Z-3.328 F152
G1 X70.734 Y40.036 Z-3.275 F152
G1 X70.74 Y40.032 Z-3.237 F152
G1 X70.768 Y40.01 Z-3.054 F152
G1 X70.783 Y40 Z-2.971 F152
G1 X70.854 Y39.947 Z-2.513 F152
G1 X70.871 Y39.934 Z-2.406 F152
G1 X70.883 Y39.925 Z-2.33 F152
G1 X70.887 Y39.922 Z-2.298 F152
G1 X70.897 Y39.914 Z-2.229 F152
G1 X70.911 Y39.905 Z-2.135 F152
G1 X70.926 Y39.894 Z-2.032 F152
G1 X70.954 Y39.874 Z-1.842 F152
G1 X70.968 Y39.864 Z-1.748 F152
G1 X70.969 Y39.863 Z-1.74 F152
G1 X70.997 Y39.844 Z-1.55 F152
G1 X71.004 Y39.838 Z-1.499 F152
G1 X71.012 Y39.832 Z-1.439 F152
G1 X71.019 Y39.827 Z-1.387 F152
G1 X71.026 Y39.822 Z-1.334 F152
G1 X71.033 Y39.817 Z-1.273 F152
G1 X71.04 Y39.812 Z-1.224 F152
G1 X71.048 Y39.807 Z-1.195 F152
G1 X71.066 Y39.794 Z-1.155 F152
G1 X71.083 Y39.783 Z-1.129 F152
G1 X71.112 Y39.763 Z-1.097 F152
G1 X71.121 Y39.756 Z-1.088 F152
G1 X71.131 Y39.75 Z-1.079 F152
G1 X71.14 Y39.742 Z-1.07 F152
; MOVEMENT_LEAD_OUT
G1 X71.149 Y39.736 Z-1.059 F152
G1 X71.155 Y39.732 Z-1.045 F152
G1 X71.157 Y39.731 Z-1.03 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X78.216 Y46.997 F152
G1 Z1.016 F152
; MOVEMENT_PLUNGE
G1 Z-0.989 F51
; MOVEMENT_LEAD_IN
G1 X78.218 Y46.995 Z-1.005 F152
G1 X78.224 Y46.989 Z-1.02 F152
G1 X78.232 Y46.981 Z-1.031 F152
G1 X78.243 Y46.97 Z-1.037 F152
; MOVEMENT_CUTTING
G1 X78.244 Y46.969 Z-1.038 F152
G1 X78.296 Y46.912 Z-1.055 F152
G1 X78.3 Y46.907 Z-1.056 F152
G1 X78.349 Y46.854 Z-1.076 F152
G1 X78.358 Y46.846 Z-1.08 F152
G1 X78.402 Y46.797 Z-1.101 F152
G1 X78.415 Y46.784 Z-1.108 F152
G1 X78.455 Y46.74 Z-1.132 F152
G1 X78.472 Y46.722 Z-1.144 F152
G1 X78.509 Y46.683 Z-1.175 F152
G1 X78.529 Y46.66 Z-1.2 F152
G1 X78.546 Y46.643 Z-1.231 F152
G1 X78.563 Y46.625 Z-1.287 F152
G1 X78.587 Y46.6 Z-1.371 F152
G1 X78.601 Y46.585 Z-1.416 F152
G1 X78.617 Y46.568 Z-1.473 F152
G1 X78.671 Y46.511 Z-1.651 F152
G1 X78.701 Y46.478 Z-1.75 F152
G1 X78.725 Y46.453 Z-1.826 F152
G1 X78.759 Y46.418 Z-1.929 F152
G1 X78.779 Y46.396 Z-1.993 F152
G1 X78.806 Y46.367 Z-2.072 F152
G1 X78.816 Y46.358 Z-2.105 F152
G1 X78.834 Y46.339 Z-2.159 F152
G1 X78.861 Y46.31 Z-2.239 F152
G1 X78.873 Y46.298 Z-2.28 F152
G1 X78.888 Y46.281 Z-2.326 F152
G1 X78.915 Y46.253 Z-2.403 F152
G1 X78.93 Y46.237 Z-2.445 F152
G1 X78.943 Y46.224 Z-2.483 F152
G1 X78.971 Y46.196 Z-2.563 F152
G1 X78.988 Y46.178 Z-2.611 F152
G1 X78.998 Y46.167 Z-2.636 F152
G1 X79.025 Y46.138 Z-2.717 F152
G1 X79.045 Y46.118 Z-2.772 F152
G1 X79.053 Y46.11 Z-2.797 F152
G1 X79.081 Y46.081 Z-2.877 F152
G1 X79.102 Y46.059 Z-2.938 F152
G1 X79.108 Y46.052 Z-2.95 F152
G1 X79.135 Y46.024 Z-3.026 F152
G1 X79.16 Y45.999 Z-3.095 F152
G1 X79.163 Y45.995 Z-3.101 F152
G1 X79.191 Y45.966 Z-3.176 F152
G1 X79.217 Y45.939 Z-3.246 F152
G1 X79.219 Y45.938 Z-3.251 F152
G1 X79.302 Y45.852 Z-3.476 F152
G1 X79.33 Y45.823 Z-3.55 F152
G1 X79.331 Y45.821 Z-3.554 F152
G1 X79.357 Y45.794 Z-3.62 F152
G1 X79.385 Y45.766 Z-3.691 F152
G1 X79.389 Y45.762 Z-3.701 F152
G1 X79.413 Y45.737 Z-3.762 F152
G1 X79.441 Y45.709 Z-3.832 F152
G1 X79.446 Y45.703 Z-3.847 F152
G1 X79.468 Y45.68 Z-3.903 F152
G1 X79.496 Y45.651 Z-3.974 F152
G1 X79.503 Y45.644 Z-3.993 F152
G1 X79.524 Y45.623 Z-4.044 F152
G1 X79.552 Y45.594 Z-4.114 F152
G1 X79.561 Y45.585 Z-4.137 F152
G1 X79.579 Y45.565 Z-4.181 F152
G1 X79.607 Y45.537 Z-4.248 F152
G1 X79.618 Y45.526 Z-4.276 F152
G1 X79.635 Y45.508 Z-4.315 F152
G1 X79.663 Y45.479 Z-4.383 F152
G1 X79.675 Y45.467 Z-4.415 F152
G1 X79.69 Y45.451 Z-4.45 F152
G1 X79.718 Y45.422 Z-4.517 F152
G1 X79.732 Y45.407 Z-4.55 F152
G1 X79.746 Y45.393 Z-4.585 F152
G1 X79.774 Y45.365 Z-4.649 F152
G1 X79.79 Y45.348 Z-4.685 F152
G1 X79.801 Y45.336 Z-4.714 F152
G1 X79.829 Y45.307 Z-4.778 F152
G1 X79.847 Y45.289 Z-4.818 F152
G1 X79.857 Y45.279 Z-4.843 F152
G1 X79.884 Y45.25 Z-4.901 F152
G1 X79.904 Y45.229 Z-4.948 F152
G1 X79.939 Y45.193 Z-5.03 F152
G1 X79.961 Y45.17 Z-5.081 F152
G1 X79.994 Y45.136 Z-5.15 F152
G1 X80.019 Y45.11 Z-5.207 F152
G1 X80.048 Y45.078 Z-5.269 F152
G1 X80.076 Y45.05 Z-5.332 F152
G1 X80.103 Y45.021 Z-5.388 F152
G1 X80.133 Y44.989 Z-5.452 F152
G1 X80.157 Y44.964 Z-5.506 F152
G1 X80.191 Y44.929 Z-5.576 F152
G1 X80.212 Y44.906 Z-5.623 F152
G1 X80.248 Y44.868 Z-5.696 F152
G1 X80.265 Y44.849 Z-5.728 F152
G1 X80.319 Y44.792 Z-5.841 F152
G1 X80.345 Y44.763 Z-5.9 F152
G1 X80.362 Y44.744 Z-5.934 F152
G1 X80.371 Y44.734 Z-5.952 F152
G1 X80.397 Y44.706 Z-6.004 F152
G1 X80.42 Y44.682 Z-6.052 F152
G1 X80.423 Y44.677 Z-6.056 F152
G1 X80.475 Y44.62 Z-6.161 F152
G1 X80.477 Y44.618 Z-6.165 F152
G1 X80.501 Y44.591 Z-6.215 F152
G1 X80.526 Y44.563 Z-6.264 F152
G1 X80.534 Y44.554 Z-6.281 F152
G1 X80.551 Y44.534 Z-6.313 F152
G1 X80.576 Y44.505 Z-6.363 F152
G1 X80.592 Y44.487 Z-6.39 F152
G1 X80.625 Y44.448 Z-6.447 F152
G1 X80.673 Y44.391 Z-6.532 F152
G1 X80.706 Y44.35 Z-6.589 F152
G1 X80.72 Y44.333 Z-6.616 F152
G1 X80.763 Y44.28 Z-6.683 F152
G1 X80.766 Y44.276 Z-6.686 F152
G1 X80.811 Y44.219 Z-6.75 F152
G1 X80.821 Y44.207 Z-6.769 F152
G1 X80.856 Y44.162 Z-6.822 F152
G1 X80.878 Y44.134 Z-6.855 F152
G1 X80.901 Y44.104 Z-6.893 F152
G1 X80.935 Y44.058 Z-6.932 F152
G1 X80.942 Y44.047 Z-6.936 F152
G1 X80.984 Y43.99 Z-6.986 F152
G1 X80.992 Y43.979 Z-6.997 F152
G1 X81.026 Y43.932 Z-7.029 F152
G1 X81.05 Y43.897 Z-7.044 F152
G1 X81.065 Y43.875 Z-7.058 F152
G1 X81.103 Y43.818 Z-7.08 F152
G1 X81.107 Y43.813 Z-7.086 F152
G1 X81.14 Y43.76 Z-7.088 F152
G1 X81.164 Y43.723 Z-7.097 F152
G1 X81.177 Y43.703 Z-7.101 F152
G1 X81.211 Y43.646 Z-7.093 F152
G1 X81.222 Y43.628 Z-7.091 F152
G1 X81.245 Y43.589 Z-7.085 F152
G1 X81.277 Y43.531 Z-7.063 F152
G1 X81.279 Y43.528 Z-7.06 F152
G1 X81.308 Y43.474 Z-7.027 F152
G1 X81.336 Y43.419 Z-6.99 F152
G1 X81.337 Y43.417 Z-6.984 F152
G1 X81.364 Y43.359 Z-6.92 F152
G1 X81.392 Y43.302 Z-6.863 F152
G1 X81.393 Y43.298 Z-6.86 F152
G1 X81.404 Y43.273 Z-6.821 F152
G1 X81.417 Y43.245 Z-6.779 F152
G1 X81.428 Y43.216 Z-6.73 F152
G1 X81.441 Y43.187 Z-6.688 F152
G1 X81.451 Y43.163 Z-6.647 F152
G1 X81.463 Y43.13 Z-6.582 F152
G1 X81.485 Y43.073 Z-6.47 F152
G1 X81.495 Y43.044 Z-6.406 F152
G1 X81.505 Y43.016 Z-6.332 F152
G1 X81.508 Y43.009 Z-6.32 F152
G1 X81.515 Y42.987 Z-6.258 F152
G1 X81.525 Y42.958 Z-6.184 F152
G1 X81.552 Y42.872 Z-5.941 F152
G1 X81.56 Y42.844 Z-5.854 F152
G1 X81.565 Y42.826 Z-5.796 F152
G1 X81.568 Y42.815 Z-5.755 F152
G1 X81.577 Y42.786 Z-5.659 F152
G1 X81.58 Y42.772 Z-5.605 F152
G1 X81.585 Y42.758 Z-5.557 F152
G1 X81.606 Y42.672 Z-5.229 F152
G1 X81.61 Y42.657 Z-5.166 F152
G1 X81.621 Y42.614 Z-4.973 F152
G1 X81.623 Y42.609 Z-4.952 F152
G1 X81.624 Y42.6 Z-4.909 F152
G1 X81.628 Y42.586 Z-4.844 F152
G1 X81.631 Y42.572 Z-4.773 F152
G1 X81.634 Y42.557 Z-4.709 F152
G1 X81.64 Y42.529 Z-4.568 F152
G1 X81.643 Y42.514 Z-4.499 F152
G1 X81.647 Y42.5 Z-4.421 F152
G1 X81.649 Y42.486 Z-4.338 F152
G1 X81.653 Y42.471 Z-4.26 F152
G1 X81.656 Y42.457 Z-4.177 F152
G1 X81.659 Y42.443 Z-4.099 F152
G1 X81.662 Y42.428 Z-4.016 F152
G1 X81.664 Y42.414 Z-3.927 F152
G1 X81.666 Y42.4 Z-3.844 F152
G1 X81.669 Y42.385 Z-3.752 F152
G1 X81.676 Y42.357 Z-3.562 F152
G1 X81.678 Y42.342 Z-3.459 F152
G1 X81.68 Y42.337 Z-3.426 F152
G1 X81.681 Y42.328 Z-3.36 F152
G1 X81.683 Y42.321 Z-3.313 F152
G1 Y42.314 Z-3.261 F152
G1 X81.685 Y42.307 Z-3.214 F152
G1 X81.686 Y42.299 Z-3.162 F152
G1 Y42.292 Z-3.106 F152
G1 X81.687 Y42.285 Z-3.054 F152
G1 X81.688 Y42.281 Z-3.03 F152
G1 Y42.28 Z-3.016 F152
G1 Y42.278 Z-3.002 F152
G1 X81.69 Y42.271 Z-2.947 F152
G1 X81.692 Y42.249 Z-2.772 F152
G1 X81.694 Y42.242 Z-2.71 F152
G1 X81.695 Y42.235 Z-2.648 F152
G1 X81.696 Y42.233 Z-2.633 F152
G1 Y42.231 Z-2.617 F152
G1 X81.697 Y42.228 Z-2.586 F152
G1 Y42.222 Z-2.538 F152
G1 X81.698 Y42.221 Z-2.522 F152
G1 X81.699 Y42.213 Z-2.456 F152
; MOVEMENT_LEAD_OUT
G1 Z-2.451 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X84.372 Y44.025 F152
G1 Z1.016 F152
; MOVEMENT_PLUNGE
G1 Z-1.065 F51
; MOVEMENT_LEAD_IN
G1 Y44.028 Z-1.08 F152
G1 Y44.035 Z-1.094 F152
G1 Y44.045 Z-1.105 F152
; MOVEMENT_CUTTING
G1 Y44.047 Z-1.106 F152
G1 X84.377 Y44.061 Z-1.123 F152
G1 X84.378 Y44.065 Z-1.128 F152
G1 Y44.067 Z-1.13 F152
G1 X84.379 Y44.068 Z-1.132 F152
G1 X84.381 Y44.076 Z-1.142 F152
G1 X84.382 Y44.083 Z-1.152 F152
G1 X84.383 Y44.085 Z-1.156 F152
G1 Y44.086 Z-1.158 F152
G1 X84.384 Y44.09 Z-1.163 F152
G1 X84.388 Y44.104 Z-1.191 F152
G1 X84.391 Y44.111 Z-1.212 F152
G1 X84.393 Y44.119 Z-1.244 F152
G1 X84.401 Y44.147 Z-1.441 F152
G1 X84.409 Y44.176 Z-1.623 F152
G1 X84.412 Y44.19 Z-1.701 F152
G1 X84.421 Y44.219 Z-1.871 F152
G1 X84.425 Y44.233 Z-1.948 F152
G1 X84.429 Y44.247 Z-2.033 F152
G1 X84.433 Y44.261 Z-2.109 F152
G1 X84.437 Y44.276 Z-2.195 F152
G1 X84.44 Y44.29 Z-2.265 F152
G1 X84.444 Y44.305 Z-2.343 F152
G1 X84.448 Y44.319 Z-2.411 F152
G1 X84.452 Y44.333 Z-2.488 F152
G1 X84.456 Y44.348 Z-2.556 F152
G1 X84.461 Y44.362 Z-2.633 F152
G1 X84.468 Y44.391 Z-2.77 F152
G1 X84.472 Y44.405 Z-2.846 F152
G1 X84.479 Y44.434 Z-2.983 F152
G1 X84.483 Y44.448 Z-3.047 F152
G1 X84.487 Y44.46 Z-3.105 F152
G1 X84.491 Y44.477 Z-3.182 F152
G1 X84.498 Y44.505 Z-3.309 F152
G1 X84.503 Y44.52 Z-3.38 F152
G1 X84.51 Y44.548 Z-3.507 F152
G1 X84.514 Y44.563 Z-3.579 F152
G1 X84.521 Y44.591 Z-3.705 F152
G1 X84.525 Y44.606 Z-3.768 F152
G1 X84.539 Y44.663 Z-4.011 F152
G1 X84.544 Y44.677 Z-4.079 F152
G1 X84.565 Y44.763 Z-4.444 F152
G1 X84.57 Y44.777 Z-4.512 F152
G1 X84.572 Y44.792 Z-4.565 F152
G1 X84.597 Y44.892 Z-4.984 F152
G1 X84.601 Y44.904 Z-5.039 F152
G1 Y44.906 Z-5.044 F152
G1 X84.626 Y45.007 Z-5.464 F152
G1 X84.63 Y45.021 Z-5.525 F152
G1 X84.632 Y45.035 Z-5.579 F152
G1 X84.64 Y45.064 Z-5.703 F152
G1 X84.642 Y45.078 Z-5.756 F152
G1 X84.653 Y45.121 Z-5.942 F152
G1 X84.656 Y45.136 Z-5.995 F152
G1 X84.658 Y45.145 Z-6.038 F152
G1 X84.663 Y45.164 Z-6.119 F152
G1 X84.666 Y45.179 Z-6.173 F152
G1 X84.676 Y45.221 Z-6.358 F152
G1 X84.679 Y45.236 Z-6.412 F152
G1 X84.686 Y45.264 Z-6.535 F152
G1 X84.689 Y45.279 Z-6.589 F152
G1 X84.692 Y45.293 Z-6.651 F152
G1 X84.695 Y45.307 Z-6.704 F152
G1 X84.702 Y45.336 Z-6.828 F152
G1 X84.705 Y45.35 Z-6.882 F152
G1 X84.708 Y45.365 Z-6.944 F152
G1 X84.716 Y45.394 Z-7.069 F152
G1 X84.718 Y45.408 Z-7.121 F152
G1 X84.722 Y45.422 Z-7.183 F152
G1 X84.725 Y45.436 Z-7.236 F152
G1 X84.728 Y45.451 Z-7.298 F152
G1 X84.731 Y45.465 Z-7.352 F152
G1 X84.734 Y45.479 Z-7.414 F152
G1 X84.738 Y45.494 Z-7.478 F152
G1 X84.741 Y45.508 Z-7.536 F152
G1 X84.743 Y45.522 Z-7.595 F152
G1 X84.746 Y45.537 Z-7.655 F152
G1 X84.75 Y45.551 Z-7.723 F152
G1 X84.758 Y45.594 Z-7.904 F152
G1 X84.761 Y45.608 Z-7.973 F152
G1 X84.767 Y45.637 Z-8.093 F152
; MOVEMENT_LEAD_OUT
G1 X84.77 Y45.653 Z-8.091 F152
G1 X84.772 Y45.667 Z-8.085 F152
G1 X84.774 Y45.679 Z-8.074 F152
G1 X84.776 Y45.686 Z-8.059 F152
G1 Y45.689 Z-8.043 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X89.859 Y41.244 F152
G1 Z0.874 F152
; MOVEMENT_PLUNGE
G1 Z-8.041 F51
; MOVEMENT_LEAD_IN
G1 X89.857 Y41.241 Z-8.058 F152
G1 X89.852 Y41.235 Z-8.072 F152
G1 X89.845 Y41.225 Z-8.084 F152
G1 X89.836 Y41.213 Z-8.09 F152
G1 X89.826 Y41.2 Z-8.091 F152
; MOVEMENT_CUTTING
G1 X89.823 Y41.196 Z-8.08 F152
G1 X89.814 Y41.182 Z-8.049 F152
G1 X89.813 Y41.181 Z-8.044 F152
G1 X89.796 Y41.153 Z-7.98 F152
G1 X89.777 Y41.125 Z-7.91 F152
G1 X89.756 Y41.091 Z-7.828 F152
G1 X89.742 Y41.067 Z-7.769 F152
G1 X89.724 Y41.039 Z-7.695 F152
G1 X89.705 Y41.01 Z-7.613 F152
G1 X89.699 Y41.001 Z-7.584 F152
G1 X89.686 Y40.982 Z-7.531 F152
G1 X89.667 Y40.953 Z-7.44 F152
G1 X89.648 Y40.924 Z-7.355 F152
G1 X89.642 Y40.913 Z-7.327 F152
G1 X89.63 Y40.896 Z-7.271 F152
G1 X89.611 Y40.867 Z-7.178 F152
G1 X89.593 Y40.838 Z-7.094 F152
G1 X89.584 Y40.825 Z-7.05 F152
G1 X89.574 Y40.81 Z-7.002 F152
G1 X89.557 Y40.781 Z-6.918 F152
G1 X89.538 Y40.752 Z-6.825 F152
G1 X89.527 Y40.735 Z-6.774 F152
G1 X89.52 Y40.724 Z-6.738 F152
G1 X89.484 Y40.666 Z-6.544 F152
G1 X89.47 Y40.644 Z-6.465 F152
G1 X89.447 Y40.609 Z-6.334 F152
G1 X89.429 Y40.58 Z-6.237 F152
G1 X89.412 Y40.556 Z-6.146 F152
G1 X89.409 Y40.552 Z-6.124 F152
G1 X89.4 Y40.537 Z-6.075 F152
G1 X89.39 Y40.523 Z-6.014 F152
G1 X89.372 Y40.494 Z-5.9 F152
G1 X89.362 Y40.48 Z-5.835 F152
G1 X89.355 Y40.468 Z-5.792 F152
G1 X89.336 Y40.437 Z-5.665 F152
G1 X89.327 Y40.423 Z-5.609 F152
G1 X89.307 Y40.394 Z-5.479 F152
G1 X89.298 Y40.381 Z-5.421 F152
G1 X89.297 Y40.38 Z-5.414 F152
G1 X89.277 Y40.351 Z-5.285 F152
G1 X89.268 Y40.337 Z-5.226 F152
G1 X89.259 Y40.323 Z-5.161 F152
G1 X89.25 Y40.307 Z-5.088 F152
G1 X89.241 Y40.293 Z-5.022 F152
G1 X89.232 Y40.28 Z-4.956 F152
G1 X89.223 Y40.265 Z-4.89 F152
G1 X89.203 Y40.237 Z-4.743 F152
G1 X89.193 Y40.222 Z-4.668 F152
G1 X89.183 Y40.208 Z-4.585 F152
G1 Y40.207 F152
G1 X89.174 Y40.194 Z-4.509 F152
G1 X89.148 Y40.151 Z-4.284 F152
G1 X89.137 Y40.134 Z-4.193 F152
G1 X89.126 Y40.118 Z-4.103 F152
G1 X89.119 Y40.108 Z-4.042 F152
G1 X89.11 Y40.093 Z-3.955 F152
G1 X89.1 Y40.079 Z-3.858 F152
G1 X89.073 Y40.036 Z-3.593 F152
G1 X89.069 Y40.03 Z-3.549 F152
G1 X89.063 Y40.022 Z-3.496 F152
G1 X89.053 Y40.007 Z-3.391 F152
G1 X89.048 Y40 Z-3.347 F152
G1 X89.044 Y39.993 Z-3.298 F152
G1 X89.035 Y39.979 Z-3.191 F152
G1 X89.024 Y39.96 Z-3.059 F152
G1 X89.017 Y39.95 Z-2.977 F152
G1 X89.012 Y39.942 Z-2.913 F152
G1 X89.007 Y39.936 Z-2.862 F152
G1 X89.003 Y39.929 Z-2.808 F152
G1 X88.997 Y39.922 Z-2.746 F152
G1 X88.993 Y39.914 Z-2.693 F152
G1 X88.987 Y39.907 Z-2.631 F152
G1 X88.983 Y39.9 Z-2.578 F152
G1 X88.978 Y39.893 Z-2.516 F152
G1 X88.976 Y39.891 Z-2.497 F152
G1 X88.975 Y39.889 Z-2.483 F152
G1 X88.967 Y39.879 Z-2.376 F152
G1 X88.962 Y39.871 Z-2.313 F152
G1 X88.957 Y39.864 Z-2.242 F152
G1 X88.954 Y39.86 Z-2.203 F152
; MOVEMENT_LEAD_OUT
G1 Y39.859 Z-2.196 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X93.755 Y40.165 F152
G1 Z1.016 F152
; MOVEMENT_PLUNGE
G1 Z-1.078 F51
; MOVEMENT_LEAD_IN
G1 X93.758 Y40.166 Z-1.095 F152
G1 X93.766 Y40.169 Z-1.109 F152
; MOVEMENT_CUTTING
G1 X93.78 Y40.173 Z-1.128 F152
G1 X93.794 Y40.178 Z-1.153 F152
G1 X93.809 Y40.183 Z-1.186 F152
G1 X93.816 Y40.186 Z-1.211 F152
G1 X93.823 Y40.187 Z-1.257 F152
G1 X93.844 Y40.195 Z-1.455 F152
G1 X93.852 Y40.197 Z-1.515 F152
G1 X93.853 Y40.198 Z-1.534 F152
G1 X93.855 Y40.199 Z-1.551 F152
G1 X93.859 Z-1.576 F152
G1 X93.861 Y40.2 Z-1.595 F152
G1 X93.862 Z-1.604 F152
G1 X93.866 Y40.202 Z-1.636 F152
G1 X93.873 Y40.204 Z-1.686 F152
G1 X93.88 Y40.206 Z-1.743 F152
G1 X93.885 Y40.208 Z-1.78 F152
G1 X93.895 Y40.211 Z-1.851 F152
G1 X93.909 Y40.216 Z-1.966 F152
G1 X93.916 Y40.218 Z-2.016 F152
G1 X93.923 Y40.221 Z-2.073 F152
G1 X93.93 Y40.223 Z-2.125 F152
G1 X93.938 Y40.226 Z-2.175 F152
G1 X93.945 Y40.23 Z-2.232 F152
G1 X93.952 Y40.232 Z-2.282 F152
G1 X93.995 Y40.246 Z-2.557 F152
G1 X94.009 Y40.251 Z-2.656 F152
G1 X94.023 Y40.255 Z-2.748 F152
G1 X94.038 Y40.26 Z-2.837 F152
G1 X94.05 Y40.265 Z-2.922 F152
G1 X94.052 Y40.266 Z-2.935 F152
G1 X94.066 Y40.272 Z-3.024 F152
G1 X94.081 Y40.276 Z-3.106 F152
G1 X94.095 Y40.281 Z-3.186 F152
G1 X94.124 Y40.291 Z-3.353 F152
G1 X94.138 Y40.296 Z-3.429 F152
G1 X94.167 Y40.306 Z-3.596 F152
G1 X94.195 Y40.317 Z-3.753 F152
G1 X94.209 Y40.323 Z-3.829 F152
G1 X94.224 Y40.328 Z-3.91 F152
G1 X94.253 Y40.339 Z-4.066 F152
G1 X94.267 Y40.343 Z-4.133 F152
G1 X94.338 Y40.37 Z-4.502 F152
G1 X94.353 Y40.375 Z-4.575 F152
G1 X94.363 Y40.38 Z-4.628 F152
G1 X94.379 Y40.386 Z-4.707 F152
G1 X94.396 Y40.393 Z-4.794 F152
G1 X94.453 Y40.415 Z-5.066 F152
G1 X94.467 Y40.421 Z-5.142 F152
G1 X94.496 Y40.432 Z-5.277 F152
G1 X94.509 Y40.437 Z-5.344 F152
G1 X94.51 Z-5.345 F152
G1 X94.553 Y40.453 Z-5.549 F152
G1 X94.568 Y40.46 Z-5.625 F152
G1 X94.582 Y40.465 Z-5.692 F152
G1 X94.596 Y40.47 Z-5.756 F152
G1 X94.611 Y40.477 Z-5.826 F152
G1 X94.625 Y40.482 Z-5.888 F152
G1 X94.654 Y40.494 Z-6.029 F152
G1 X94.668 Y40.5 Z-6.09 F152
G1 X94.682 Y40.506 Z-6.16 F152
G1 X94.696 Y40.512 Z-6.221 F152
G1 X94.711 Y40.518 Z-6.291 F152
G1 X94.725 Y40.523 Z-6.353 F152
G1 X94.739 Y40.529 Z-6.423 F152
G1 X94.754 Y40.535 Z-6.485 F152
G1 X94.768 Y40.541 Z-6.554 F152
G1 X94.782 Y40.546 Z-6.616 F152
G1 X94.795 Y40.552 Z-6.676 F152
G1 X94.797 Y40.553 Z-6.686 F152
G1 X94.811 Y40.558 Z-6.748 F152
G1 X94.825 Y40.564 Z-6.815 F152
G1 X94.868 Y40.583 Z-7.01 F152
G1 X94.883 Y40.589 Z-7.068 F152
G1 X94.911 Y40.601 Z-7.198 F152
G1 X94.928 Y40.609 Z-7.281 F152
G1 X94.94 Y40.614 Z-7.329 F152
G1 X95.026 Y40.651 Z-7.721 F152
G1 X95.043 Y40.658 Z-7.796 F152
G1 X95.061 Y40.666 Z-7.879 F152
G1 X95.069 Y40.67 Z-7.914 F152
G1 X95.083 Y40.676 Z-7.975 F152
G1 X95.092 Y40.681 Z-8.019 F152
G1 X95.097 Y40.683 Z-8.037 F152
G1 X95.105 Y40.686 Z-8.072 F152
G1 X95.106 Y40.687 Z-8.082 F152
G1 X95.109 Y40.688 Z-8.093 F152
; MOVEMENT_LEAD_OUT
G1 X95.124 Y40.695 Z-8.092 F152
G1 X95.137 Y40.7 Z-8.085 F152
G1 X95.148 Y40.705 Z-8.074 F152
G1 X95.155 Y40.708 Z-8.059 F152
G1 X95.158 Y40.709 Z-8.043 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X108.995 Y6.986 F152
G1 Z0.8 F152
; MOVEMENT_PLUNGE
G1 Z-8.046 F51
; MOVEMENT_LEAD_IN
G1 X108.991 Z-8.065 F152
G1 X108.98 Z-8.081 F152
G1 X108.964 Z-8.092 F152
G1 X108.945 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X8.262 F152
; MOVEMENT_LINK_TRANSITION
G1 Y6.987 F152
; MOVEMENT_CUTTING
G1 Y138.687 F152
; MOVEMENT_LINK_TRANSITION
G1 Y138.689 F152
; MOVEMENT_CUTTING
G1 X108.945 F152
; MOVEMENT_LEAD_OUT
G1 X108.964 Z-8.092 F152
G1 X108.98 Z-8.081 F152
G1 X108.991 Z-8.065 F152
G1 X108.995 Z-8.046 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X8.277 Y138.673 F152
G1 Z0.794 F152
; MOVEMENT_PLUNGE
G1 Z-8.075 F51
; MOVEMENT_LEAD_IN
G1 X8.274 Y138.675 Z-8.083 F152
G1 X8.269 Y138.681 Z-8.087 F152
G1 X8.262 Y138.687 Z-8.085 F152
G1 X8.259 Y138.691 Z-8.077 F152
; MOVEMENT_CUTTING
G1 X8.22 Y138.73 Z-7.714 F152
G1 X8.213 Y138.738 Z-7.65 F152
G1 X8.205 Y138.744 Z-7.582 F152
G1 X8.162 Y138.787 Z-7.187 F152
G1 X8.155 Y138.795 Z-7.123 F152
G1 X8.148 Y138.802 Z-7.055 F152
G1 X8.105 Y138.845 Z-6.659 F152
G1 X8.098 Y138.852 Z-6.596 F152
G1 X8.091 Y138.859 Z-6.528 F152
G1 X7.525 Y139.425 Z-1.317 F152
G1 X7.518 Y139.432 Z-1.282 F152
G1 X7.504 Y139.446 Z-1.242 F152
G1 X7.489 Y139.461 Z-1.215 F152
G1 X7.475 Y139.475 Z-1.194 F152
G1 X7.446 Y139.504 Z-1.163 F152
G1 X7.418 Y139.532 Z-1.14 F152
G1 X7.389 Y139.561 Z-1.123 F152
; MOVEMENT_LEAD_OUT
G1 X7.378 Y139.572 Z-1.112 F152
G1 X7.37 Y139.58 Z-1.096 F152
G1 X7.367 Y139.583 Z-1.077 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X28.059 Y43.476 F152
G1 Z0.863 F152
; MOVEMENT_PLUNGE
G1 Z-8.039 F51
; MOVEMENT_LEAD_IN
G1 X28.061 Y43.474 Z-8.056 F152
G1 X28.065 Y43.466 Z-8.071 F152
G1 X28.071 Y43.455 Z-8.082 F152
G1 X28.078 Y43.441 Z-8.088 F152
G1 X28.086 Y43.425 F152
; MOVEMENT_CUTTING
G1 X28.087 Y43.424 Z-8.077 F152
G1 X28.098 Y43.402 Z-7.929 F152
G1 X28.101 Y43.395 Z-7.877 F152
G1 X28.108 Y43.381 Z-7.781 F152
G1 X28.111 Y43.374 Z-7.733 F152
G1 X28.118 Y43.359 Z-7.635 F152
G1 X28.124 Y43.346 Z-7.546 F152
G1 X28.127 Y43.339 Z-7.496 F152
G1 X28.13 Y43.331 Z-7.443 F152
G1 X28.137 Y43.316 Z-7.351 F152
G1 X28.175 Y43.23 Z-6.78 F152
G1 X28.181 Y43.218 Z-6.7 F152
G1 X28.184 Y43.211 Z-6.653 F152
G1 X28.195 Y43.187 Z-6.499 F152
G1 X28.22 Y43.13 Z-6.118 F152
G1 X28.226 Y43.116 Z-6.025 F152
G1 X28.232 Y43.102 Z-5.933 F152
G1 X28.239 Y43.087 Z-5.843 F152
G1 X28.244 Y43.073 Z-5.75 F152
G1 X28.25 Y43.059 Z-5.66 F152
G1 X28.266 Y43.016 Z-5.38 F152
G1 X28.273 Y43.001 Z-5.291 F152
G1 X28.289 Y42.958 Z-5.011 F152
G1 X28.296 Y42.941 Z-4.903 F152
G1 X28.3 Y42.93 Z-4.828 F152
G1 X28.311 Y42.901 Z-4.641 F152
G1 X28.316 Y42.887 Z-4.55 F152
G1 X28.333 Y42.844 Z-4.281 F152
G1 X28.337 Y42.829 Z-4.188 F152
G1 X28.342 Y42.815 Z-4.098 F152
G1 X28.347 Y42.801 Z-4.004 F152
G1 X28.352 Y42.786 Z-3.915 F152
G1 X28.353 Y42.784 Z-3.898 F152
G1 X28.357 Y42.772 Z-3.821 F152
G1 X28.362 Y42.758 Z-3.732 F152
G1 X28.367 Y42.743 Z-3.638 F152
G1 X28.372 Y42.729 Z-3.548 F152
G1 X28.381 Y42.7 Z-3.361 F152
G1 X28.386 Y42.686 Z-3.273 F152
G1 X28.409 Y42.614 Z-2.809 F152
G1 X28.41 Y42.608 Z-2.767 F152
G1 X28.412 Y42.6 Z-2.712 F152
G1 X28.421 Y42.572 Z-2.526 F152
G1 X28.425 Y42.557 Z-2.429 F152
G1 X28.429 Y42.543 Z-2.335 F152
G1 X28.447 Y42.486 Z-1.95 F152
G1 X28.458 Y42.443 Z-1.649 F152
G1 X28.46 Y42.434 Z-1.592 F152
G1 X28.463 Y42.426 Z-1.531 F152
G1 X28.466 Y42.414 Z-1.437 F152
G1 X28.468 Y42.409 Z-1.406 F152
G1 X28.47 Y42.4 Z-1.331 F152
G1 X28.471 Y42.392 Z-1.273 F152
G1 X28.473 Y42.385 Z-1.223 F152
G1 X28.474 Y42.378 Z-1.196 F152
G1 X28.476 Y42.371 Z-1.178 F152
G1 X28.478 Y42.357 Z-1.151 F152
G1 X28.479 Y42.353 Z-1.145 F152
G1 X28.48 Y42.351 Z-1.142 F152
G1 Y42.349 Z-1.139 F152
G1 X28.482 Y42.342 Z-1.129 F152
G1 X28.486 Y42.328 Z-1.11 F152
; MOVEMENT_LEAD_OUT
G1 X28.489 Y42.32 Z-1.096 F152
G1 X28.49 Y42.317 Z-1.079 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X32.42 Y42.495 F152
G1 Z0.978 F152
; MOVEMENT_PLUNGE
G1 Z-4.689 F51
; MOVEMENT_LEAD_IN
G1 Z-4.695 F152
; MOVEMENT_CUTTING
G1 X32.428 Y42.5 Z-4.774 F152
G1 X32.434 Y42.503 Z-4.837 F152
G1 X32.441 Y42.507 Z-4.905 F152
G1 X32.449 Y42.512 Z-4.979 F152
G1 X32.456 Y42.515 Z-5.047 F152
G1 X32.463 Y42.52 Z-5.121 F152
G1 X32.47 Y42.523 Z-5.189 F152
G1 X32.477 Y42.528 Z-5.264 F152
G1 X32.527 Y42.553 Z-5.739 F152
G1 X32.534 Y42.557 Z-5.812 F152
G1 X32.542 Y42.561 Z-5.878 F152
G1 X32.549 Y42.565 Z-5.95 F152
G1 X32.556 Y42.569 Z-6.016 F152
G1 X32.563 Y42.573 Z-6.089 F152
G1 X32.577 Y42.58 Z-6.22 F152
G1 X32.585 Y42.585 Z-6.293 F152
G1 X32.606 Y42.596 Z-6.491 F152
G1 X32.613 Y42.6 Z-6.563 F152
G1 X32.635 Y42.611 Z-6.761 F152
G1 X32.641 Y42.614 Z-6.822 F152
G1 X32.649 Y42.618 Z-6.893 F152
G1 X32.656 Y42.623 Z-6.965 F152
G1 X32.699 Y42.644 Z-7.361 F152
G1 X32.706 Y42.649 Z-7.433 F152
G1 X32.753 Y42.672 Z-7.862 F152
G1 X32.756 Y42.673 Z-7.888 F152
G1 X32.774 Y42.682 Z-8.053 F152
G1 X32.777 Y42.683 Z-8.079 F152
; MOVEMENT_LEAD_OUT
G1 X32.792 Y42.695 Z-8.082 F152
G1 X32.808 Y42.706 Z-8.079 F152
G1 X32.822 Y42.717 Z-8.07 F152
G1 X32.834 Y42.725 Z-8.057 F152
G1 X32.841 Y42.73 Z-8.039 F152
G1 X32.843 Y42.732 Z-8.02 F152
G1 X32.846 Y42.73 Z-8 F152
G1 X32.853 Y42.725 Z-7.983 F152
G1 X32.865 Y42.718 Z-7.969 F152
G1 X32.879 Y42.708 Z-7.96 F152
G1 X32.895 Y42.697 Z-7.957 F152
; MOVEMENT_LINK_TRANSITION
G1 X33.242 Y42.464 F152
; MOVEMENT_LEAD_IN
G1 X33.258 Y42.453 Z-7.96 F152
G1 X33.273 Y42.443 Z-7.969 F152
G1 X33.284 Y42.435 Z-7.983 F152
G1 X33.292 Y42.43 Z-8 F152
G1 X33.294 Y42.429 Z-8.02 F152
G1 Z-8.026 F152
G1 Y42.425 Z-8.047 F152
G1 Y42.414 Z-8.066 F152
G1 Y42.398 Z-8.08 F152
G1 Y42.378 Z-8.088 F152
G1 Y42.357 F152
; MOVEMENT_CUTTING
G1 Y42.349 Z-8.028 F152
G1 X33.301 Y42.299 Z-7.627 F152
G1 Y42.292 Z-7.569 F152
G1 X33.303 Y42.278 Z-7.449 F152
G1 Y42.271 Z-7.386 F152
G1 X33.308 Y42.235 Z-7.085 F152
G1 Y42.228 Z-7.023 F152
G1 X33.309 Y42.221 Z-6.963 F152
G1 X33.31 Y42.213 Z-6.901 F152
; MOVEMENT_LEAD_OUT
G1 Z-6.896 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X37.747 Y41.972 F152
G1 Z1.015 F152
; MOVEMENT_PLUNGE
G1 Z-1.535 F51
; MOVEMENT_LEAD_IN
G1 Y41.973 Z-1.54 F152
; MOVEMENT_CUTTING
G1 X37.748 Z-1.552 F152
G1 X37.749 Y41.975 Z-1.568 F152
G1 X37.75 Y41.977 Z-1.591 F152
G1 X37.751 Y41.979 Z-1.607 F152
G1 X37.752 Y41.981 Z-1.621 F152
G1 X37.76 Y41.991 Z-1.724 F152
G1 X37.767 Y41.999 Z-1.801 F152
G1 X37.777 Y42.013 Z-1.94 F152
G1 X37.779 Y42.016 Z-1.967 F152
G1 X37.798 Y42.042 Z-2.179 F152
G1 X37.804 Y42.05 Z-2.249 F152
G1 X37.809 Y42.056 Z-2.3 F152
G1 X37.815 Y42.063 Z-2.362 F152
G1 X37.821 Y42.07 Z-2.421 F152
G1 X37.843 Y42.099 Z-2.625 F152
G1 X37.849 Y42.106 Z-2.684 F152
G1 X37.854 Y42.113 Z-2.735 F152
G1 X37.861 Y42.124 Z-2.803 F152
G1 X37.864 Y42.127 Z-2.829 F152
G1 X37.872 Y42.14 Z-2.905 F152
G1 X37.878 Y42.148 Z-2.957 F152
G1 X37.884 Y42.156 Z-3.016 F152
G1 X37.894 Y42.17 Z-3.11 F152
G1 X37.903 Y42.185 Z-3.195 F152
G1 X37.914 Y42.199 Z-3.291 F152
G1 X37.919 Y42.205 Z-3.325 F152
G1 X37.925 Y42.213 Z-3.374 F152
G1 X37.937 Y42.228 Z-3.466 F152
G1 X37.947 Y42.242 Z-3.55 F152
G1 X37.959 Y42.256 Z-3.642 F152
G1 X37.97 Y42.271 Z-3.726 F152
G1 X37.976 Y42.279 Z-3.776 F152
G1 X37.98 Y42.285 Z-3.802 F152
G1 X37.99 Y42.299 Z-3.886 F152
G1 X38 Y42.314 Z-3.962 F152
G1 X38.011 Y42.328 Z-4.038 F152
G1 X38.022 Y42.343 Z-4.109 F152
G1 X38.033 Y42.358 Z-4.188 F152
G1 X38.043 Y42.371 Z-4.253 F152
G1 X38.054 Y42.385 Z-4.324 F152
G1 X38.065 Y42.4 Z-4.404 F152
G1 X38.076 Y42.414 Z-4.476 F152
G1 X38.091 Y42.433 Z-4.572 F152
G1 X38.098 Y42.443 Z-4.619 F152
G1 X38.108 Y42.457 Z-4.681 F152
G1 X38.183 Y42.557 Z-5.121 F152
G1 X38.194 Y42.572 Z-5.191 F152
G1 X38.205 Y42.587 Z-5.253 F152
G1 X38.216 Y42.6 Z-5.313 F152
G1 X38.248 Y42.643 Z-5.48 F152
G1 X38.262 Y42.662 Z-5.555 F152
G1 X38.27 Y42.672 Z-5.591 F152
G1 X38.312 Y42.729 Z-5.814 F152
G1 X38.32 Y42.739 Z-5.85 F152
G1 X38.335 Y42.758 Z-5.924 F152
G1 X38.367 Y42.801 Z-6.072 F152
G1 X38.377 Y42.813 Z-6.119 F152
G1 X38.388 Y42.828 Z-6.167 F152
G1 X38.399 Y42.844 Z-6.22 F152
G1 X38.421 Y42.872 Z-6.319 F152
G1 X38.434 Y42.889 Z-6.383 F152
G1 X38.443 Y42.901 Z-6.423 F152
G1 X38.454 Y42.915 Z-6.466 F152
G1 X38.466 Y42.93 Z-6.518 F152
G1 X38.476 Y42.944 Z-6.561 F152
G1 X38.488 Y42.958 Z-6.612 F152
G1 X38.491 Y42.964 Z-6.625 F152
G1 X38.509 Y42.987 Z-6.699 F152
G1 X38.531 Y43.016 Z-6.786 F152
G1 X38.549 Y43.039 Z-6.86 F152
G1 X38.561 Y43.055 Z-6.911 F152
G1 X38.575 Y43.073 Z-6.962 F152
G1 X38.597 Y43.102 Z-7.046 F152
G1 X38.606 Y43.113 Z-7.078 F152
G1 X38.619 Y43.13 Z-7.129 F152
G1 X38.642 Y43.159 Z-7.212 F152
G1 X38.663 Y43.187 Z-7.291 F152
G1 X38.664 Z-7.295 F152
G1 X38.686 Y43.216 Z-7.371 F152
G1 X38.708 Y43.245 Z-7.449 F152
G1 X38.721 Y43.261 Z-7.489 F152
G1 X38.73 Y43.273 Z-7.521 F152
G1 X38.753 Y43.302 Z-7.593 F152
G1 X38.778 Y43.333 Z-7.677 F152
G1 X38.798 Y43.359 Z-7.745 F152
G1 X38.821 Y43.388 Z-7.817 F152
G1 X38.835 Y43.406 Z-7.86 F152
G1 X38.844 Y43.417 Z-7.885 F152
G1 X38.866 Y43.445 Z-7.94 F152
G1 X38.89 Y43.474 Z-8.003 F152
G1 X38.892 Y43.477 Z-8.013 F152
G1 X38.913 Y43.503 Z-8.066 F152
G1 X38.921 Y43.512 Z-8.092 F152
G1 X38.922 Y43.513 Z-8.091 F152
; MOVEMENT_LEAD_OUT
G1 X38.928 Y43.526 Z-8.084 F152
G1 X38.933 Y43.536 Z-8.073 F152
G1 X38.937 Y43.543 Z-8.059 F152
G1 X38.938 Y43.545 Z-8.043 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X41.55 Y40.568 F152
G1 Z0.876 F152
; MOVEMENT_PLUNGE
G1 Z-8.045 F51
; MOVEMENT_LEAD_IN
G1 X41.546 Y40.567 Z-8.064 F152
G1 X41.536 Y40.562 Z-8.081 F152
G1 X41.521 Y40.554 Z-8.091 F152
G1 X41.504 Y40.546 Z-8.095 F152
; MOVEMENT_CUTTING
G1 X41.502 Y40.545 Z-8.087 F152
G1 X41.499 Y40.544 Z-8.081 F152
G1 X41.47 Y40.535 Z-8.012 F152
G1 X41.441 Y40.527 Z-7.951 F152
G1 X41.413 Y40.519 Z-7.892 F152
G1 X41.355 Y40.501 Z-7.763 F152
G1 X41.333 Y40.494 Z-7.719 F152
G1 X41.298 Y40.484 Z-7.641 F152
G1 X41.27 Y40.475 Z-7.577 F152
G1 X41.241 Y40.467 Z-7.52 F152
G1 X41.184 Y40.449 Z-7.391 F152
G1 X41.144 Y40.437 Z-7.308 F152
G1 X41.126 Y40.432 Z-7.27 F152
G1 X41.069 Y40.414 Z-7.14 F152
G1 X41.04 Y40.405 Z-7.078 F152
G1 X40.983 Y40.387 Z-6.954 F152
G1 X40.96 Y40.38 Z-6.905 F152
G1 X40.954 Y40.378 Z-6.893 F152
G1 X40.926 Y40.369 Z-6.831 F152
G1 X40.897 Y40.359 Z-6.761 F152
G1 X40.811 Y40.332 Z-6.576 F152
G1 X40.783 Y40.323 Z-6.507 F152
G1 X40.781 Z-6.508 F152
G1 X40.754 Y40.314 Z-6.445 F152
G1 X40.725 Y40.305 Z-6.383 F152
G1 X40.697 Y40.295 Z-6.315 F152
G1 X40.668 Y40.286 Z-6.255 F152
G1 X40.639 Y40.276 Z-6.187 F152
G1 X40.611 Y40.267 Z-6.127 F152
G1 X40.605 Y40.265 Z-6.115 F152
G1 X40.582 Y40.257 Z-6.059 F152
G1 X40.554 Y40.247 Z-5.991 F152
G1 X40.525 Y40.238 Z-5.931 F152
G1 X40.468 Y40.219 Z-5.796 F152
G1 X40.439 Y40.21 Z-5.736 F152
G1 X40.434 Y40.208 Z-5.724 F152
G1 X40.41 Y40.2 Z-5.668 F152
G1 X40.382 Y40.19 Z-5.6 F152
G1 X40.296 Y40.161 Z-5.397 F152
G1 X40.267 Y40.152 Z-5.338 F152
G1 X40.264 Y40.151 Z-5.332 F152
G1 X40.238 Y40.142 Z-5.271 F152
G1 X40.21 Y40.132 Z-5.203 F152
G1 X40.181 Y40.121 Z-5.127 F152
G1 X40.153 Y40.111 Z-5.06 F152
G1 X40.124 Y40.101 Z-4.984 F152
G1 X40.102 Y40.093 Z-4.936 F152
G1 X40.095 Y40.091 Z-4.917 F152
G1 X40.067 Y40.08 Z-4.84 F152
G1 X40.038 Y40.07 Z-4.771 F152
G1 X40.009 Y40.059 Z-4.694 F152
G1 X39.952 Y40.04 Z-4.557 F152
G1 X39.942 Y40.036 Z-4.532 F152
G1 X39.923 Y40.029 Z-4.48 F152
G1 X39.866 Y40.009 Z-4.343 F152
G1 X39.838 Y39.999 Z-4.266 F152
G1 X39.809 Y39.989 Z-4.197 F152
G1 X39.78 Y39.979 Z-4.125 F152
G1 X39.752 Y39.968 Z-4.045 F152
G1 X39.666 Y39.939 Z-3.829 F152
G1 X39.637 Y39.928 Z-3.749 F152
G1 X39.619 Y39.922 Z-3.704 F152
G1 X39.608 Y39.917 Z-3.669 F152
G1 X39.58 Y39.906 Z-3.589 F152
G1 X39.551 Y39.896 Z-3.506 F152
G1 X39.522 Y39.886 Z-3.428 F152
G1 X39.465 Y39.864 Z-3.257 F152
G1 X39.463 Z-3.258 F152
G1 X39.437 Y39.854 Z-3.179 F152
G1 X39.379 Y39.833 Z-3.008 F152
G1 X39.351 Y39.821 Z-2.913 F152
G1 X39.336 Y39.816 Z-2.867 F152
G1 X39.322 Y39.811 Z-2.82 F152
G1 X39.311 Y39.807 Z-2.788 F152
G1 X39.293 Y39.8 Z-2.724 F152
G1 X39.179 Y39.757 Z-2.343 F152
G1 X39.159 Y39.75 Z-2.28 F152
G1 X39.14 Y39.742 Z-2.209 F152
G1 X39.122 Y39.736 Z-2.144 F152
G1 X39.107 Y39.73 Z-2.08 F152
G1 X39.021 Y39.698 Z-1.75 F152
G1 X39.008 Y39.692 Z-1.695 F152
G1 X39.007 Y39.691 Z-1.686 F152
G1 X38.993 Y39.686 Z-1.631 F152
G1 X38.921 Y39.659 Z-1.297 F152
G1 X38.907 Y39.654 Z-1.232 F152
G1 X38.892 Y39.648 Z-1.197 F152
G1 X38.876 Y39.641 Z-1.17 F152
G1 X38.86 Y39.635 Z-1.151 F152
G1 X38.835 Y39.626 Z-1.124 F152
G1 X38.821 Y39.622 Z-1.113 F152
G1 X38.814 Y39.619 Z-1.107 F152
G1 X38.807 Y39.615 Z-1.1 F152
G1 X38.778 Y39.602 Z-1.079 F152
G1 X38.764 Y39.596 Z-1.07 F152
G1 X38.749 Y39.59 Z-1.063 F152
G1 X38.735 Y39.586 Z-1.055 F152
G1 X38.728 Y39.584 Z-1.051 F152
G1 X38.721 Y39.581 Z-1.047 F152
; MOVEMENT_LEAD_OUT
G1 X38.707 Y39.576 Z-1.036 F152
G1 X38.699 Y39.573 Z-1.021 F152
G1 X38.696 Y39.572 Z-1.003 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X25.072 Y40.069 F152
G1 Z1.016 F152
; MOVEMENT_PLUNGE
G1 Z-0.979 F51
; MOVEMENT_LEAD_IN
G1 X25.069 Y40.067 Z-0.997 F152
G1 X25.06 Y40.063 Z-1.013 F152
G1 X25.047 Y40.057 Z-1.024 F152
G1 X25.031 Y40.05 Z-1.029 F152
; MOVEMENT_CUTTING
G1 X25.002 Y40.036 Z-1.032 F152
G1 X24.974 Y40.023 Z-1.035 F152
G1 X24.916 Y39.994 Z-1.043 F152
G1 X24.885 Y39.979 Z-1.047 F152
G1 X24.802 Y39.939 Z-1.058 F152
G1 X24.767 Y39.922 Z-1.063 F152
G1 X24.745 Y39.912 Z-1.066 F152
G1 X24.687 Y39.884 Z-1.076 F152
G1 X24.647 Y39.864 Z-1.083 F152
G1 X24.63 Y39.856 Z-1.086 F152
G1 X24.573 Y39.828 Z-1.097 F152
G1 X24.527 Y39.807 Z-1.106 F152
G1 X24.515 Y39.802 Z-1.109 F152
G1 X24.458 Y39.775 Z-1.121 F152
G1 X24.407 Y39.75 Z-1.134 F152
G1 X24.401 Y39.747 Z-1.136 F152
G1 X24.344 Y39.72 Z-1.152 F152
G1 X24.286 Y39.693 Z-1.171 F152
G1 X24.284 Y39.692 Z-1.172 F152
G1 X24.229 Y39.666 Z-1.196 F152
G1 X24.2 Y39.653 Z-1.212 F152
G1 X24.172 Y39.64 Z-1.239 F152
G1 X24.163 Y39.635 Z-1.253 F152
G1 X24.114 Y39.613 Z-1.318 F152
G1 X24.057 Y39.586 Z-1.395 F152
G1 X24.04 Y39.578 Z-1.419 F152
G1 X24 Y39.559 Z-1.472 F152
G1 X23.943 Y39.532 Z-1.548 F152
G1 X23.918 Y39.52 Z-1.583 F152
G1 X23.885 Y39.505 Z-1.625 F152
G1 X23.857 Y39.492 Z-1.663 F152
G1 X23.828 Y39.477 Z-1.708 F152
G1 X23.798 Y39.463 Z-1.749 F152
G1 X23.771 Y39.451 Z-1.784 F152
G1 X23.742 Y39.437 Z-1.822 F152
G1 X23.713 Y39.423 Z-1.868 F152
G1 X23.679 Y39.406 Z-1.923 F152
G1 X23.484 Y39.308 Z-2.237 F152
G1 X23.453 Y39.291 Z-2.299 F152
G1 X23.427 Y39.277 Z-2.353 F152
G1 X23.398 Y39.262 Z-2.407 F152
G1 X23.37 Y39.246 Z-2.469 F152
G1 X23.348 Y39.234 Z-2.512 F152
G1 X23.313 Y39.215 Z-2.577 F152
G1 X23.284 Y39.199 Z-2.639 F152
G1 X23.255 Y39.183 Z-2.702 F152
G1 X23.245 Y39.177 Z-2.728 F152
G1 X23.227 Y39.166 Z-2.773 F152
G1 X23.198 Y39.148 Z-2.853 F152
G1 X23.169 Y39.131 Z-2.925 F152
G1 X23.151 Y39.119 Z-2.979 F152
G1 X23.141 Y39.113 Z-3.005 F152
G1 X23.112 Y39.095 Z-3.084 F152
G1 X23.083 Y39.078 Z-3.156 F152
G1 X23.057 Y39.062 Z-3.228 F152
G1 X23.026 Y39.042 Z-3.316 F152
G1 X22.997 Y39.023 Z-3.411 F152
G1 X22.972 Y39.005 Z-3.501 F152
G1 X22.969 Y39.002 Z-3.515 F152
G1 X22.94 Y38.982 Z-3.61 F152
G1 X22.926 Y38.972 Z-3.666 F152
G1 X22.912 Y38.962 Z-3.713 F152
G1 X22.892 Y38.947 Z-3.786 F152
G1 X22.883 Y38.941 Z-3.817 F152
G1 X22.869 Y38.93 Z-3.872 F152
G1 X22.84 Y38.911 Z-3.968 F152
G1 X22.826 Y38.9 Z-4.024 F152
G1 X22.812 Y38.89 Z-4.074 F152
G1 X22.797 Y38.879 Z-4.128 F152
G1 X22.754 Y38.847 Z-4.297 F152
G1 X22.74 Y38.836 Z-4.362 F152
G1 X22.737 Y38.833 Z-4.378 F152
G1 X22.725 Y38.823 Z-4.434 F152
G1 X22.711 Y38.811 Z-4.498 F152
G1 X22.697 Y38.799 Z-4.57 F152
G1 X22.682 Y38.787 Z-4.634 F152
G1 X22.669 Y38.776 Z-4.701 F152
G1 X22.654 Y38.763 Z-4.771 F152
G1 X22.64 Y38.751 Z-4.843 F152
G1 X22.625 Y38.739 Z-4.907 F152
G1 X22.611 Y38.726 Z-4.98 F152
G1 X22.601 Y38.718 Z-5.025 F152
G1 X22.585 Y38.705 Z-5.1 F152
G1 X22.551 Y38.676 Z-5.263 F152
G1 X22.534 Y38.661 Z-5.352 F152
G1 X22.525 Y38.654 Z-5.392 F152
G1 X22.482 Y38.614 Z-5.636 F152
G1 X22.471 Y38.604 Z-5.695 F152
G1 X22.461 Y38.594 Z-5.752 F152
G1 X22.453 Y38.586 Z-5.806 F152
G1 X22.439 Y38.572 Z-5.887 F152
G1 X22.425 Y38.559 Z-5.969 F152
G1 X22.412 Y38.546 Z-6.048 F152
G1 X22.396 Y38.531 Z-6.141 F152
G1 X22.375 Y38.511 Z-6.271 F152
G1 X22.367 Y38.503 Z-6.313 F152
G1 X22.354 Y38.489 Z-6.406 F152
G1 X22.339 Y38.474 Z-6.501 F152
G1 X22.299 Y38.432 Z-6.775 F152
G1 X22.286 Y38.417 Z-6.868 F152
G1 X22.282 Y38.413 Z-6.897 F152
G1 X22.273 Y38.403 Z-6.962 F152
G1 X22.232 Y38.36 Z-7.241 F152
G1 X22.224 Y38.351 Z-7.3 F152
G1 X22.219 Y38.346 Z-7.335 F152
G1 X22.208 Y38.334 Z-7.412 F152
G1 X22.201 Y38.326 Z-7.47 F152
G1 X22.193 Y38.317 Z-7.526 F152
G1 X22.187 Y38.309 Z-7.58 F152
G1 X22.172 Y38.294 Z-7.684 F152
G1 X22.167 Y38.287 Z-7.732 F152
G1 X22.156 Y38.274 Z-7.817 F152
G1 X22.144 Y38.26 Z-7.914 F152
G1 X22.138 Y38.253 Z-7.964 F152
G1 X22.132 Y38.246 Z-8.012 F152
G1 X22.124 Y38.236 Z-8.08 F152
G1 X22.122 Y38.234 Z-8.092 F152
; MOVEMENT_LEAD_OUT
G1 X22.111 Y38.222 Z-8.09 F152
G1 X22.1 Y38.212 Z-8.084 F152
G1 X22.091 Y38.203 Z-8.073 F152
G1 X22.086 Y38.197 Z-8.058 F152
G1 X22.084 Y38.196 Z-8.042 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X53.766 Y43.76 F152
G1 Z1.015 F152
; MOVEMENT_PLUNGE
G1 Z-1.527 F51
; MOVEMENT_LEAD_IN
G1 Z-1.533 F152
; MOVEMENT_CUTTING
G1 Y43.764 Z-1.562 F152
G1 X53.765 Y43.766 Z-1.581 F152
G1 Y43.8 Z-1.861 F152
G1 Y43.802 Z-1.875 F152
G1 X53.764 Y43.803 Z-1.893 F152
G1 X53.763 Y43.811 Z-1.949 F152
G1 Y43.816 Z-1.987 F152
G1 Y43.818 Z-2.005 F152
G1 Y43.854 Z-2.261 F152
G1 X53.762 Y43.861 Z-2.317 F152
G1 Y43.875 Z-2.42 F152
G1 X53.761 Y43.882 Z-2.471 F152
G1 Y43.889 Z-2.515 F152
G1 X53.759 Y43.918 Z-2.705 F152
G1 Y43.947 Z-2.882 F152
G1 X53.758 Y43.961 Z-2.976 F152
G1 Y43.975 Z-3.065 F152
G1 X53.757 Y43.99 Z-3.15 F152
G1 X53.755 Y44.018 Z-3.318 F152
G1 Y44.033 Z-3.395 F152
G1 Y44.047 Z-3.479 F152
G1 Y44.076 Z-3.634 F152
G1 X53.754 Y44.09 Z-3.718 F152
G1 Y44.162 Z-4.104 F152
G1 Y44.176 Z-4.176 F152
G1 Y44.19 Z-4.246 F152
G1 X53.753 Y44.204 Z-4.322 F152
G1 Y44.348 Z-5.02 F152
G1 X53.754 Y44.362 Z-5.082 F152
G1 Y44.376 Z-5.152 F152
G1 X53.755 Y44.391 Z-5.215 F152
G1 Y44.434 Z-5.415 F152
G1 Y44.448 Z-5.475 F152
G1 Y44.491 Z-5.676 F152
G1 X53.756 Y44.505 Z-5.735 F152
G1 Y44.52 Z-5.802 F152
G1 X53.757 Y44.534 Z-5.862 F152
G1 Y44.548 Z-5.929 F152
G1 X53.759 Y44.577 Z-6.048 F152
G1 Y44.591 Z-6.115 F152
G1 X53.76 Y44.606 Z-6.175 F152
G1 Y44.62 Z-6.242 F152
G1 X53.762 Y44.649 Z-6.361 F152
G1 Y44.663 Z-6.429 F152
G1 X53.772 Y44.82 Z-7.097 F152
G1 X53.773 Y44.835 Z-7.15 F152
G1 X53.775 Y44.863 Z-7.272 F152
G1 X53.777 Y44.878 Z-7.325 F152
G1 X53.779 Y44.906 Z-7.447 F152
G1 X53.78 Y44.921 Z-7.5 F152
G1 X53.781 Y44.935 Z-7.561 F152
G1 X53.782 Y44.949 Z-7.622 F152
G1 X53.784 Y44.964 Z-7.678 F152
G1 X53.785 Y44.98 Z-7.751 F152
G1 X53.787 Y44.992 Z-7.801 F152
G1 X53.789 Y45.007 Z-7.86 F152
G1 Y45.021 Z-7.925 F152
G1 X53.793 Y45.05 Z-8.043 F152
G1 Y45.057 Z-8.079 F152
G1 X53.794 Y45.06 Z-8.091 F152
; MOVEMENT_LINK_TRANSITION
G1 Y45.062 Z-8.096 F152
; MOVEMENT_CUTTING
G1 X53.795 Y45.064 F152
G1 X53.799 Y45.07 F152
G1 X53.814 Y45.092 F152
G1 X53.823 Y45.107 F152
G1 X53.88 Y45.193 F152
G1 X53.9 Y45.222 F152
G1 X53.917 Y45.25 F152
G1 X53.957 Y45.307 F152
G1 X54.002 Y45.365 F152
G1 X54.014 Y45.38 F152
G1 X54.047 Y45.422 F152
G1 X54.071 Y45.452 F152
G1 X54.093 Y45.479 F152
G1 X54.129 Y45.525 F152
G1 X54.138 Y45.537 F152
G1 X54.183 Y45.594 F152
G1 X54.186 Y45.597 F152
G1 X54.234 Y45.651 F152
G1 X54.243 Y45.66 F152
G1 X54.289 Y45.709 F152
G1 X54.3 Y45.72 F152
G1 X54.344 Y45.766 F152
G1 X54.358 Y45.779 F152
G1 X54.404 Y45.823 F152
G1 X54.415 Y45.833 F152
G1 X54.468 Y45.88 F152
G1 X54.472 Y45.884 F152
G1 X54.53 Y45.935 F152
G1 X54.533 Y45.938 F152
G1 X54.587 Y45.98 F152
G1 X54.607 Y45.995 F152
G1 X54.682 Y46.052 F152
G1 X54.701 Y46.068 F152
G1 X54.759 Y46.106 F152
G1 X54.765 Y46.11 F152
G1 X54.816 Y46.143 F152
G1 X54.854 Y46.167 F152
G1 X54.873 Y46.179 F152
G1 X54.931 Y46.213 F152
G1 X54.952 Y46.224 F152
G1 X54.988 Y46.243 F152
G1 X55.045 Y46.273 F152
G1 X55.062 Y46.281 F152
G1 X55.102 Y46.302 F152
G1 X55.16 Y46.328 F152
G1 X55.187 Y46.339 F152
G1 X55.217 Y46.352 F152
G1 X55.274 Y46.376 F152
G1 X55.325 Y46.396 F152
G1 X55.331 Y46.399 F152
G1 X55.389 Y46.418 F152
G1 X55.446 Y46.437 F152
G1 X55.497 Y46.453 F152
G1 X55.503 Y46.456 F152
G1 X55.561 Y46.472 F152
G1 X55.732 Y46.515 F152
G1 X55.79 Y46.526 F152
G1 X55.847 Y46.535 F152
G1 X55.904 Y46.545 F152
G1 X56.019 Y46.563 F152
G1 X56.057 Y46.568 F152
G1 X56.076 Y46.572 F152
G1 X56.133 Y46.58 F152
G1 X56.191 Y46.585 F152
G1 X56.248 Y46.589 F152
G1 X56.305 Y46.593 F152
G1 X56.363 Y46.597 F152
G1 X56.42 Y46.601 F152
G1 X56.534 Y46.608 F152
G1 X56.706 Y46.611 F152
G1 X56.763 Y46.613 F152
G1 X56.878 Y46.615 F152
G1 X56.935 Y46.616 F152
G1 X57.107 Y46.619 F152
G1 X57.164 Y46.621 F152
G1 X57.222 Y46.622 F152
G1 X57.279 Y46.623 F152
G1 X57.321 Y46.625 F152
G1 X57.336 Y46.627 F152
G1 X57.565 Y46.641 F152
G1 X57.623 Y46.647 F152
G1 X57.68 Y46.654 F152
G1 X57.737 Y46.663 F152
G1 X57.794 Y46.674 F152
G1 X57.838 Y46.683 F152
G1 X57.909 Y46.701 F152
G1 X57.966 Y46.719 F152
G1 X58.026 Y46.74 F152
G1 X58.081 Y46.766 F152
G1 X58.136 Y46.797 F152
G1 X58.138 Y46.798 F152
G1 X58.195 Y46.84 F152
G1 X58.212 Y46.854 F152
G1 X58.253 Y46.898 F152
G1 X58.263 Y46.912 F152
G1 X58.299 Y46.969 F152
G1 X58.31 Y46.988 F152
G1 X58.327 Y47.026 F152
G1 X58.348 Y47.084 F152
G1 X58.365 Y47.141 F152
G1 X58.367 Y47.153 F152
G1 X58.376 Y47.198 F152
G1 X58.385 Y47.256 F152
G1 X58.392 Y47.313 F152
G1 X58.396 Y47.37 F152
G1 X58.398 Y47.427 F152
G1 X58.397 Y47.485 F152
G1 X58.395 Y47.542 F152
G1 X58.392 Y47.599 F152
G1 X58.385 Y47.657 F152
G1 X58.379 Y47.714 F152
G1 X58.371 Y47.771 F152
G1 X58.367 Y47.793 F152
G1 X58.36 Y47.829 F152
G1 X58.35 Y47.886 F152
G1 X58.338 Y47.943 F152
G1 X58.323 Y48 F152
G1 X58.31 Y48.058 F152
G1 X58.293 Y48.115 F152
G1 X58.275 Y48.172 F152
G1 X58.258 Y48.23 F152
G1 X58.253 Y48.245 F152
G1 X58.238 Y48.287 F152
G1 X58.217 Y48.344 F152
G1 X58.195 Y48.401 F152
G1 X58.147 Y48.516 F152
G1 X58.138 Y48.538 F152
G1 X58.121 Y48.573 F152
G1 X58.093 Y48.631 F152
G1 X58.081 Y48.658 F152
G1 X58.066 Y48.688 F152
G1 X58.036 Y48.745 F152
G1 X58.004 Y48.803 F152
G1 X57.973 Y48.86 F152
G1 X57.966 Y48.87 F152
G1 X57.937 Y48.917 F152
G1 X57.909 Y48.962 F152
G1 X57.901 Y48.974 F152
G1 X57.863 Y49.032 F152
G1 X57.822 Y49.089 F152
G1 X57.794 Y49.128 F152
G1 X57.779 Y49.146 F152
G1 X57.734 Y49.204 F152
G1 X57.685 Y49.261 F152
G1 X57.68 Y49.266 F152
G1 X57.633 Y49.318 F152
G1 X57.623 Y49.33 F152
G1 X57.575 Y49.376 F152
G1 X57.565 Y49.385 F152
G1 X57.513 Y49.433 F152
G1 X57.508 Y49.436 F152
G1 X57.451 Y49.485 F152
G1 X57.443 Y49.49 F152
G1 X57.394 Y49.525 F152
G1 X57.36 Y49.547 F152
G1 X57.336 Y49.562 F152
G1 X57.279 Y49.594 F152
G1 X57.257 Y49.605 F152
G1 X57.222 Y49.621 F152
G1 X57.164 Y49.642 F152
G1 X57.107 Y49.658 F152
G1 X57.094 Y49.662 F152
G1 X57.05 Y49.671 F152
G1 X56.993 Y49.68 F152
G1 X56.935 Y49.684 F152
G1 X56.878 Y49.687 F152
G1 X56.763 Y49.682 F152
G1 X56.706 Y49.675 F152
G1 X56.649 Y49.668 F152
G1 X56.611 Y49.662 F152
G1 X56.592 Y49.658 F152
G1 X56.534 Y49.648 F152
G1 X56.477 Y49.635 F152
G1 X56.363 Y49.607 F152
G1 X56.354 Y49.605 F152
G1 X56.305 Y49.589 F152
G1 X56.191 Y49.555 F152
G1 X56.133 Y49.535 F152
G1 X56.076 Y49.515 F152
G1 X56.019 Y49.495 F152
G1 X56.005 Y49.49 F152
G1 X55.962 Y49.474 F152
G1 X55.904 Y49.451 F152
G1 X55.859 Y49.433 F152
G1 X55.847 Y49.428 F152
G1 X55.79 Y49.405 F152
G1 X55.732 Y49.38 F152
G1 X55.722 Y49.376 F152
G1 X55.675 Y49.355 F152
G1 X55.618 Y49.329 F152
G1 X55.593 Y49.318 F152
G1 X55.561 Y49.304 F152
G1 X55.503 Y49.275 F152
G1 X55.474 Y49.261 F152
G1 X55.446 Y49.247 F152
G1 X55.357 Y49.204 F152
G1 X55.331 Y49.189 F152
G1 X55.274 Y49.158 F152
G1 X55.252 Y49.146 F152
G1 X55.217 Y49.128 F152
G1 X55.16 Y49.096 F152
G1 X55.146 Y49.089 F152
G1 X55.102 Y49.062 F152
G1 X55.051 Y49.032 F152
G1 X55.045 Y49.028 F152
G1 X54.988 Y48.993 F152
G1 X54.956 Y48.974 F152
G1 X54.931 Y48.957 F152
G1 X54.873 Y48.92 F152
G1 X54.87 Y48.917 F152
G1 X54.784 Y48.86 F152
G1 X54.759 Y48.842 F152
G1 X54.706 Y48.803 F152
G1 X54.701 Y48.799 F152
G1 X54.644 Y48.756 F152
G1 X54.629 Y48.745 F152
G1 X54.587 Y48.712 F152
G1 X54.49 Y48.631 F152
G1 X54.472 Y48.615 F152
G1 X54.415 Y48.563 F152
G1 X54.367 Y48.516 F152
G1 X54.309 Y48.459 F152
G1 X54.3 Y48.449 F152
G1 X54.257 Y48.401 F152
G1 X54.243 Y48.386 F152
G1 X54.205 Y48.344 F152
G1 X54.186 Y48.321 F152
G1 X54.159 Y48.287 F152
G1 X54.129 Y48.249 F152
G1 X54.113 Y48.23 F152
G1 X54.071 Y48.173 F152
G1 Y48.172 F152
G1 X54.014 Y48.091 F152
G1 X53.992 Y48.058 F152
G1 X53.9 Y47.906 F152
G1 X53.889 Y47.886 F152
G1 X53.858 Y47.829 F152
G1 X53.842 Y47.8 F152
G1 X53.827 Y47.771 F152
G1 X53.799 Y47.714 F152
G1 X53.746 Y47.599 F152
G1 X53.728 Y47.557 F152
G1 X53.721 Y47.542 F152
G1 X53.698 Y47.485 F152
G1 X53.676 Y47.427 F152
G1 X53.67 Y47.414 F152
G1 X53.655 Y47.37 F152
G1 X53.635 Y47.313 F152
G1 X53.617 Y47.256 F152
G1 X53.613 Y47.246 F152
G1 X53.6 Y47.198 F152
G1 X53.583 Y47.141 F152
G1 X53.568 Y47.084 F152
G1 X53.556 Y47.028 F152
G1 Y47.026 F152
G1 X53.543 Y46.969 F152
G1 X53.533 Y46.912 F152
G1 X53.525 Y46.854 F152
G1 X53.516 Y46.797 F152
G1 X53.503 Y46.625 F152
G1 X53.501 Y46.568 F152
G1 Y46.453 F152
G1 X53.502 Y46.396 F152
G1 X53.507 Y46.339 F152
G1 X53.51 Y46.281 F152
G1 X53.515 Y46.224 F152
G1 X53.52 Y46.167 F152
G1 X53.552 Y45.938 F152
G1 X53.556 Y45.918 F152
G1 X53.564 Y45.88 F152
G1 X53.599 Y45.709 F152
G1 X53.612 Y45.651 F152
G1 X53.613 Y45.646 F152
G1 X53.627 Y45.594 F152
G1 X53.658 Y45.479 F152
G1 X53.67 Y45.431 F152
G1 X53.69 Y45.365 F152
G1 X53.765 Y45.136 F152
G1 X53.785 Y45.082 F152
G1 X53.787 Y45.078 F152
G1 X53.792 Y45.064 F152
; MOVEMENT_LEAD_OUT
G1 X53.793 Y45.061 Z-8.089 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X55.444 Y41.256 F152
G1 Z0.877 F152
; MOVEMENT_PLUNGE
G1 Z-8.096 F51
; MOVEMENT_CUTTING
G1 X55.445 Y41.257 F152
G1 X55.446 Y41.261 F152
G1 X55.464 Y41.297 F152
G1 X55.493 Y41.354 F152
G1 X55.503 Y41.374 F152
G1 X55.525 Y41.411 F152
G1 X55.558 Y41.469 F152
G1 X55.561 Y41.474 F152
G1 X55.59 Y41.526 F152
G1 X55.618 Y41.572 F152
G1 X55.626 Y41.583 F152
G1 X55.663 Y41.64 F152
G1 X55.675 Y41.659 F152
G1 X55.7 Y41.698 F152
G1 X55.732 Y41.743 F152
G1 X55.742 Y41.755 F152
G1 X55.784 Y41.812 F152
G1 X55.79 Y41.819 F152
G1 X55.83 Y41.87 F152
G1 X55.847 Y41.89 F152
G1 X55.878 Y41.927 F152
G1 X55.904 Y41.956 F152
G1 X55.931 Y41.984 F152
G1 X55.962 Y42.014 F152
G1 X55.989 Y42.042 F152
G1 X56.019 Y42.067 F152
G1 X56.076 Y42.114 F152
G1 X56.139 Y42.156 F152
G1 X56.191 Y42.187 F152
G1 X56.24 Y42.213 F152
G1 X56.248 Y42.217 F152
G1 X56.305 Y42.244 F152
G1 X56.363 Y42.268 F152
G1 X56.368 Y42.271 F152
G1 X56.42 Y42.29 F152
G1 X56.477 Y42.31 F152
G1 X56.526 Y42.328 F152
G1 X56.534 Y42.331 F152
G1 X56.706 Y42.382 F152
G1 X56.716 Y42.385 F152
G1 X56.763 Y42.398 F152
G1 X56.821 Y42.412 F152
G1 X56.878 Y42.427 F152
G1 X56.935 Y42.441 F152
G1 X56.942 Y42.443 F152
G1 X56.993 Y42.454 F152
G1 X57.05 Y42.467 F152
G1 X57.164 Y42.49 F152
G1 X57.214 Y42.5 F152
G1 X57.222 Y42.501 F152
G1 X57.279 Y42.512 F152
G1 X57.336 Y42.52 F152
G1 X57.394 Y42.53 F152
G1 X57.451 Y42.539 F152
G1 X57.508 Y42.546 F152
G1 X57.565 Y42.553 F152
G1 X57.596 Y42.557 F152
G1 X57.623 Y42.559 F152
G1 X57.68 Y42.564 F152
G1 X57.737 Y42.569 F152
G1 X57.852 Y42.574 F152
G1 X57.909 Y42.575 F152
G1 X58.024 Y42.573 F152
G1 X58.081 Y42.569 F152
G1 X58.138 Y42.563 F152
G1 X58.188 Y42.557 F152
G1 X58.195 Y42.555 F152
G1 X58.253 Y42.546 F152
G1 X58.31 Y42.531 F152
G1 X58.367 Y42.512 F152
G1 X58.4 Y42.5 F152
G1 X58.425 Y42.487 F152
G1 X58.453 Y42.471 F152
G1 X58.482 Y42.451 F152
G1 X58.491 Y42.443 F152
G1 X58.519 Y42.414 F152
G1 X58.539 Y42.391 F152
G1 X58.543 Y42.385 F152
G1 X58.578 Y42.328 F152
G1 X58.596 Y42.29 F152
G1 X58.604 Y42.271 F152
G1 X58.625 Y42.213 F152
G1 X58.641 Y42.156 F152
G1 X58.654 Y42.102 F152
G1 Y42.099 F152
G1 X58.663 Y42.042 F152
G1 X58.67 Y41.984 F152
G1 X58.672 Y41.927 F152
G1 X58.673 Y41.87 F152
G1 X58.672 Y41.812 F152
G1 X58.666 Y41.755 F152
G1 X58.658 Y41.698 F152
G1 X58.654 Y41.669 F152
G1 X58.647 Y41.64 F152
G1 X58.63 Y41.583 F152
G1 X58.607 Y41.526 F152
G1 X58.596 Y41.505 F152
G1 X58.573 Y41.469 F152
G1 X58.55 Y41.44 F152
G1 X58.521 Y41.411 F152
G1 X58.482 Y41.381 F152
G1 X58.443 Y41.354 F152
G1 X58.425 Y41.343 F152
G1 X58.367 Y41.314 F152
G1 X58.333 Y41.297 F152
G1 X58.31 Y41.286 F152
G1 X58.253 Y41.264 F152
G1 X58.188 Y41.239 F152
G1 X58.138 Y41.224 F152
G1 X58.081 Y41.207 F152
G1 X58.024 Y41.193 F152
G1 X57.966 Y41.179 F152
G1 X57.909 Y41.168 F152
G1 X57.852 Y41.158 F152
G1 X57.794 Y41.147 F152
G1 X57.623 Y41.126 F152
G1 X57.621 Y41.125 F152
G1 X57.565 Y41.12 F152
G1 X57.451 Y41.111 F152
G1 X57.394 Y41.109 F152
G1 X57.222 Y41.103 F152
G1 X57.164 F152
G1 X57.107 Y41.104 F152
G1 X57.05 F152
G1 X56.878 Y41.11 F152
G1 X56.763 Y41.115 F152
G1 X56.606 Y41.125 F152
G1 X56.592 Y41.127 F152
G1 X56.534 Y41.13 F152
G1 X56.363 Y41.144 F152
G1 X56.076 Y41.17 F152
G1 X56.019 Y41.177 F152
G1 X55.965 Y41.182 F152
G1 X55.962 Y41.183 F152
G1 X55.618 Y41.226 F152
G1 X55.561 Y41.235 F152
G1 X55.53 Y41.239 F152
G1 X55.503 Y41.244 F152
G1 X55.475 Y41.249 F152
G1 X55.446 Y41.254 F152
; MOVEMENT_LINK_TRANSITION
G1 X55.442 Y41.255 Z-8.091 F152
; MOVEMENT_CUTTING
G1 X55.439 Y41.253 Z-8.069 F152
G1 X55.432 Y41.249 Z-8.024 F152
G1 X55.417 Y41.241 Z-7.936 F152
G1 X55.403 Y41.234 Z-7.845 F152
G1 X55.389 Y41.226 Z-7.756 F152
G1 X55.374 Y41.219 Z-7.659 F152
G1 X55.317 Y41.187 Z-7.284 F152
G1 X55.309 Y41.182 Z-7.231 F152
G1 X55.303 Y41.178 Z-7.19 F152
G1 X55.292 Y41.173 Z-7.117 F152
G1 X55.274 Y41.162 Z-7.002 F152
G1 X55.26 Y41.155 Z-6.905 F152
G1 X55.246 Y41.147 Z-6.811 F152
G1 X55.231 Y41.14 Z-6.714 F152
G1 X55.224 Y41.136 Z-6.669 F152
G1 X55.217 Y41.132 Z-6.621 F152
G1 X55.204 Y41.125 Z-6.531 F152
G1 X55.196 Y41.121 Z-6.483 F152
G1 X55.188 Y41.117 Z-6.429 F152
G1 X55.181 Y41.113 Z-6.376 F152
G1 X55.167 Y41.104 Z-6.274 F152
G1 X55.16 Y41.101 Z-6.221 F152
G1 X55.145 Y41.092 Z-6.119 F152
G1 X55.138 Y41.088 Z-6.066 F152
G1 X55.131 Y41.084 Z-6.015 F152
G1 X55.124 Y41.08 Z-5.962 F152
G1 X55.117 Y41.076 Z-5.911 F152
G1 X55.103 Y41.067 Z-5.815 F152
G1 X55.102 Z-5.807 F152
G1 X55.095 Y41.063 Z-5.756 F152
G1 X55.081 Y41.056 Z-5.65 F152
G1 X55.074 Y41.051 Z-5.599 F152
G1 X55.067 Y41.048 Z-5.546 F152
G1 X55.059 Y41.043 Z-5.495 F152
G1 X55.045 Y41.036 Z-5.389 F152
G1 X55.038 Y41.032 Z-5.338 F152
G1 X55.031 Y41.028 Z-5.285 F152
G1 X55.024 Y41.024 Z-5.234 F152
G1 X55.016 Y41.02 Z-5.178 F152
G1 X55.009 Y41.015 Z-5.118 F152
G1 X55.001 Y41.01 Z-5.056 F152
G1 X54.995 Y41.007 Z-5.005 F152
G1 X54.988 Y41.001 Z-4.949 F152
G1 X54.973 Y40.992 Z-4.834 F152
G1 X54.966 Y40.989 Z-4.775 F152
G1 X54.952 Y40.98 Z-4.66 F152
G1 X54.945 Y40.976 Z-4.601 F152
G1 X54.923 Y40.963 Z-4.429 F152
G1 X54.916 Y40.959 Z-4.37 F152
G1 X54.906 Y40.953 Z-4.291 F152
G1 X54.902 Y40.95 Z-4.255 F152
G1 X54.89 Y40.944 Z-4.16 F152
G1 X54.873 Y40.935 Z-4.02 F152
G1 X54.866 Y40.93 Z-3.963 F152
G1 X54.859 Y40.927 Z-3.9 F152
G1 X54.83 Y40.909 Z-3.646 F152
G1 X54.823 Y40.905 Z-3.58 F152
G1 X54.816 Y40.9 Z-3.512 F152
G1 X54.808 Y40.896 Z-3.436 F152
G1 X54.802 Y40.892 Z-3.377 F152
G1 X54.795 Y40.888 Z-3.309 F152
G1 X54.787 Y40.882 Z-3.238 F152
G1 X54.759 Y40.864 Z-2.948 F152
; MOVEMENT_LEAD_OUT
G1 X54.758 Z-2.943 F152
; MOVEMENT_CUTTING
G1 Z5.08 F152
G1 X8.303 Y7.028 F152
G1 Z0.784 F152
; MOVEMENT_PLUNGE
G1 Z-8.036 F51
; MOVEMENT_LEAD_IN
G1 X8.301 Y7.026 Z-8.053 F152
G1 X8.294 Y7.019 Z-8.069 F152
G1 X8.284 Y7.009 Z-8.08 F152
G1 X8.272 Y6.997 Z-8.085 F152
G1 X8.26 Y6.985 F152
; MOVEMENT_CUTTING
G1 X8.222 Y6.947 Z-7.739 F152
G1 X8.214 Y6.938 Z-7.663 F152
G1 X8.205 Y6.93 Z-7.582 F152
G1 X8.165 Y6.89 Z-7.211 F152
G1 X8.157 Y6.881 Z-7.135 F152
G1 X8.148 Y6.873 Z-7.055 F152
G1 X8.108 Y6.833 Z-6.684 F152
G1 X8.099 Y6.824 Z-6.608 F152
G1 X8.091 Y6.816 Z-6.528 F152
G1 X8.05 Y6.775 Z-6.157 F152
G1 X8.042 Y6.766 Z-6.081 F152
G1 X8.033 Y6.758 Z-6 F152
G1 X7.526 Y6.251 Z-1.329 F152
G1 X7.518 Y6.243 Z-1.282 F152
G1 X7.506 Y6.231 Z-1.248 F152
G1 X7.504 Y6.228 Z-1.242 F152
G1 X7.492 Y6.217 Z-1.22 F152
G1 X7.478 Y6.202 Z-1.198 F152
G1 X7.449 Y6.174 Z-1.165 F152
G1 X7.446 Y6.171 Z-1.163 F152
G1 X7.42 Y6.145 Z-1.142 F152
G1 X7.392 Y6.116 Z-1.124 F152
G1 X7.389 Y6.114 Z-1.123 F152
; MOVEMENT_LEAD_OUT
G1 X7.38 Y6.104 Z-1.116 F152
G1 X7.372 Y6.097 Z-1.105 F152
G1 X7.367 Y6.092 Z-1.091 F152
G1 X7.366 Y6.09 Z-1.076 F152
; MOVEMENT_CUTTING
G1 Z15.24 F152
; *** SECTION end ***
;
; *** STOP begin ***
M400
; COMMAND_COOLANT_OFF
; ---- Coolant: Off cur: Off A: Off B: Off
G0 X0 Y0 F4470
; COMMAND_STOP_SPINDLE
M300 S300 P3000
M0 Turn OFF spindle
M117 Job end
; *** STOP end ***
