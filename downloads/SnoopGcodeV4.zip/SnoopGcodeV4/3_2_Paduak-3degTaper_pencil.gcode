; parseSafeZProperty: safeZMode = 'Retract'
; parseSafeZProperty: safeZHeightDefault = 15
; param: product-id = fusion360
;Fusion CAM 2602.1.25
; Posts processor: MPCNC v3.0 Beta 1.cps
; Gcode generated: Wed Aug 13 00:34:43 2025 GMT
; param: hostname = Harrisons-MacBook-Air.local
; param: username = harrisonesterly
; Document: snoop2 v18
; param: document-id = cdd3c627-a981-4b59-b2d6-a8cf2a6a6479
; param: model-version = bdc37a29-57e1-40f4-926d-96910b3fbf17
; param: leads-supported = 1
; Setup: Setup5
; param: machine-id = 1
; param: machine-v2 = {
   "controller" : {
      "default" : {
         "head_info_part_id" : "head",
         "max_block_processing_speed" : 118,
         "max_normal_speed" : 4000.0000000000005,
         "non_tcp_rapid_interpolation_mode" : "Unsynchronized",
         "parts" : {
            "X" : {
               "coordinate" : 0,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Y" : {
               "coordinate" : 1,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            },
            "Z" : {
               "coordinate" : 2,
               "max_normal_speed" : 0,
               "max_rapid_speed" : 0,
               "preference" : "negative",
               "reset" : "never",
               "reversed" : false,
               "tcp" : false,
               "zero_position_offset" : 0
            }
         },
         "table_part_id" : "table",
         "tcp_rapid_interpolation_mode" : "ToolTip"
      }
   },
   "general" : {
      "capabilities" : [ "milling" ],
      "description" : "Generic 3-axis",
      "minimumRevision" : 45805,
      "vendor" : "MP_CNC"
   },
   "interactions" : {
      "default" : {
         "pairs" : [
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "head",
                     "type" : "tool"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "X",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : [ "check_collisions" ],
               "solids" : [
                  {
                     "id" : "Y",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "machine_part"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "stock"
                  }
               ]
            },
            {
               "setting" : null,
               "solids" : [
                  {
                     "id" : "Z",
                     "type" : "machine_part"
                  },
                  {
                     "id" : "table",
                     "type" : "fixture"
                  }
               ]
            }
         ]
      }
   },
   "kinematics" : {
      "default" : {
         "conventions" : {
            "rotation" : "right-handed"
         },
         "parts" : [
            {
               "control" : "driven",
               "direction" : [ -1, 0, 0 ],
               "id" : "X",
               "max" : 289.99999999999994,
               "min" : 289.99999999999994,
               "name" : "X",
               "parts" : [
                  {
                     "control" : "driven",
                     "direction" : [ 0, -1, 0 ],
                     "id" : "Y",
                     "name" : "Y",
                     "parts" : [
                        {
                           "control" : "driven",
                           "direction" : [ 0, 0, -1 ],
                           "id" : "Z",
                           "max" : 0,
                           "min" : 0,
                           "name" : "Z",
                           "parts" : [
                              {
                                 "attach_frame" : {
                                    "point" : [ 0, 0, 0 ],
                                    "x_direction" : [ 1, 0, 0 ],
                                    "z_direction" : [ 0, 0, 1 ]
                                 },
                                 "display_name" : "table",
                                 "id" : "table",
                                 "type" : "table"
                              }
                           ],
                           "type" : "linear"
                        }
                     ],
                     "type" : "linear"
                  }
               ],
               "type" : "linear"
            },
            {
               "attach_frame" : {
                  "point" : [ 0, 0, 0 ],
                  "x_direction" : [ 1, 0, 0 ],
                  "z_direction" : [ 0, 0, 1 ]
               },
               "display_name" : "head",
               "id" : "head",
               "spindle" : {
                  "max_speed" : 0,
                  "min_speed" : 0
               },
               "tool_station" : {
                  "coolants" : null,
                  "max_tool_diameter" : 0,
                  "max_tool_length" : 0
               },
               "type" : "head"
            }
         ],
         "units" : {
            "angle" : "degrees",
            "length" : "mm"
         }
      }
   },
   "machining" : {
      "default" : {
         "feedrate_ratio" : 1,
         "tool_change_time" : 15
      }
   },
   "post" : {
      "default" : {
         "output_folder" : "/Users/harrisonesterly/Desktop/LIFE/Projects/MPCNC/fusion_GCode",
         "path" : "user://MPCNC.cps"
      }
   },
   "tooling" : {
      "default" : {
         "has_tool_changer" : false,
         "number_of_tools" : 100,
         "supports_tool_preload" : true
      }
   }
}


; param: stock-type = box
; param: stock = 0, 0, -26.496, 141.732, 106.172, 0
; param: stock-lower-x = 0
; param: stock-lower-y = 0
; param: stock-lower-z = -26.495999999999995
; param: stock-upper-x = 141.732
; param: stock-upper-y = 106.17199999999997
; param: stock-upper-z = 0
; param: part-lower-x = 1.0159999999999911
; param: part-lower-y = 1.0159999999999982
; param: part-lower-z = -26.495999999999995
; param: part-upper-x = 140.71599999999998
; param: part-upper-y = 105.15599999999998
; param: part-upper-z = -1.016
; param: areBothSpindlesGrabbed = 0
; param: notes = 
; param: operation-strategy = pencil_new
; param: autodeskcam:operation-id = 43
; param: leads-supported = 1
; param: autodeskcam:path = Setups\Setup5\Pencil2 3
; param: operation:is2DStrategy = 0
; param: operation:is3DStrategy = 1
; param: operation:isRoughingStrategy = 0
; param: operation:isFinishingStrategy = 1
; param: operation:isMillingStrategy = 1
; param: operation:isTurningStrategy = 0
; param: operation:isJetStrategy = 0
; param: operation:isAdditiveStrategy = 0
; param: operation:isProbingStrategy = 0
; param: operation:isInspectionStrategy = 0
; param: operation:isDrillingStrategy = 0
; param: operation:isHoleMillingStrategy = 0
; param: operation:isThreadStrategy = 0
; param: operation:isSamplingStrategy = 0
; param: operation:isRotaryStrategy = 0
; param: operation:isSubspindleStrategy = 0
; param: operation:isSurfaceStrategy = 1
; param: operation:isCheckSurfaceStrategy = 1
; param: operation:isMultiAxisStrategy = 0
; param: operation:advancedMode = 0
; param: operation:betaMode = 0
; param: operation:alphaMode = 0
; param: operation:isXpress = 0
; param: operation:licenseMultiaxis = 1
; param: operation:license3D = 1
; param: operation:metric = 0
; param: operation:isAssemblyDocument = 1
; param: operation:context = operation
; param: operation:strategy = pencil_new
; param: operation:operation_description = 
; param: operation:tool_type = tapered mill
; param: operation:undercut = 0
; param: operation:tool_isTurning = 0
; param: operation:tool_isMill = 1
; param: operation:tool_isDrill = 0
; param: operation:tool_isJet = 0
; param: operation:tool_isDepositing = 0
; param: operation:tool_taperedType = tapered_bull_nose
; param: operation:tool_unit = millimeters
; param: operation:tool_number = 1
; param: operation:tool_diameterOffset = 1
; param: operation:tool_lengthOffset = 1
; param: operation:tool_compensationOffset = 1
; param: operation:tool_turret = 0
; param: operation:tool_manualToolChange = 0
; param: operation:tool_breakControl = 0
; param: operation:tool_live = 1
; param: operation:tool_material = carbide
; param: operation:tool_description = 46473 CNC 2D and 3D Carving 6.2 Deg Tapered Angle Ball Tip x 0.5mm Dia x 0.25mm Radius x 26.5mm x 6mm Shank x 75mm Long x 3 Flute Up-Cut Spiral Solid Carbide ZrN Coated
; param: operation:tool_comment = 
; param: operation:tool_vendor = Amana Tool
; param: operation:tool_productId = 46473
; param: operation:tool_productLink = https://www.amanatool.com/46473-cnc-2d-and-3d-carving-6-2-deg-tapered-angle-ball-tip-x-0-5mm-dia-x-0-25mm-radius-x-26-5mm-x-6mm-shank-x-75mm-long-x-3-flute-up-cut-spiral-solid-carbide-zrn-coated.html
; param: operation:tool_diameter = 0.5
; param: operation:tool_maximumCuttingDiameter = 0
; param: operation:tool_tipDiameter = 0
; param: operation:tool_tipOffset = 0
; param: operation:tool_cornerRadius = 0.25
; param: operation:tool_inclusiveAngle = 0
; param: operation:tool_taperAngle = 6.2
; param: operation:tool_tipAngle = 0
; param: operation:tool_threadTipType = point
; param: operation:tool_threadTipWidth = 0
; param: operation:tool_threadTipRadius = 0
; param: operation:tool_threadProfileAngle = 0
; param: operation:tool_tipLength = 0
; param: operation:tool_fluteLength = 26.5
; param: operation:tool_shoulderLength = 26.5
; param: operation:tool_bodyLength = 40
; param: operation:tool_overallLength = 75
; param: operation:tool_shaftDiameter = 6
; param: operation:tool_segmentHeight = 3
; param: operation:tool_segmentDiameterLower = 12
; param: operation:tool_segmentDiameterUpper = 12
; param: operation:tool_shaftSegmentHeight = 6.75
; param: operation:tool_shaftSegmentDiameterLower = 0.5
; param: operation:tool_shaftSegmentDiameterUpper = 6
; param: operation:tool_threadPitch = 0
; param: operation:tool_maximumThreadPitch = 0
; param: operation:tool_minimumThreadPitch = 0
; param: operation:tool_numberOfTeeth = 0
; param: operation:tool_numberOfFlutes = 3
; param: operation:tool_shoulderDiameter = 6.257643000000001
; param: operation:tool_upperRadius = 1.016
; param: operation:tool_profileRadius = 101.6
; param: operation:tool_lowerRadius = 1.016
; param: operation:tool_axialDistance = 1.016
; param: operation:tool_chamferWidth = 1.016
; param: operation:tool_chamferAngle = 45
; param: operation:holder_attached = 0
; param: operation:holder_description = 
; param: operation:holder_comment = 
; param: operation:holder_vendor = 
; param: operation:holder_productId = 
; param: operation:holder_productLink = 
; param: operation:holder_libraryName = 
; param: operation:tool_holderGaugeLength = 0
; param: operation:tool_assemblyGaugeLength = 40
; param: operation:tool_spindleSpeed = 18000
; param: operation:tool_stockDiameter = 0.5
; param: operation:tool_surfaceSpeed = 28274.33388230814
; param: operation:tool_rampSpindleSpeed = 18000
; param: operation:tool_feedCutting = 152.39999999999998
; param: operation:tool_feedPerTooth = 0.0028222222222222216
; param: operation:tool_feedEntry = 152.39999999999998
; param: operation:tool_feedExit = 152.39999999999998
; param: operation:tool_feedTransition = 152.39999999999998
; param: operation:tool_feedRamp = 50.79999999999999
; param: operation:tool_feedPlunge = 50.79999999999999
; param: operation:tool_feedPerRevolution = 0.0028222222222222216
; param: operation:tool_feedRetract = 50.79999999999999
; param: operation:tool_clockwise = 1
; param: operation:tool_coolant = disabled
; param: operation:featureOperationId = none
; param: operation:surfaceZHigh = -1.016
; param: operation:surfaceZLow = -26.496
; param: operation:surfaceXLow = 1.0159999999999896
; param: operation:surfaceXHigh = 140.71599999999998
; param: operation:surfaceYLow = 1.016
; param: operation:surfaceYHigh = 105.15599999999998
; param: operation:stockZHigh = 0
; param: operation:stockZLow = -26.496
; param: operation:stockXLow = 0
; param: operation:stockXHigh = 141.732
; param: operation:stockYLow = 0
; param: operation:stockYHigh = 106.17199999999997
; param: operation:shaftAndHolderMode = dont care
; param: operation:useShaft = 0
; param: operation:shaftClearance = 1.016
; param: operation:useHolder = 0
; param: operation:holderClearance = 5.08
; param: operation:multiAxisMachiningType = three_axis
; param: operation:view_orientation_mode = useWCS
; param: operation:view_orientation_flipZ = 0
; param: operation:view_orientation_axesZX_unselected_default = wcs
; param: operation:view_orientation_axesZY_unselected_default = wcs
; param: operation:view_orientation_axesXY_unselected_default = wcs
; param: operation:view_select_angles = turn_and_tilt
; param: operation:view_turn_from_recipe = 0
; param: operation:view_tilt_from_recipe = 0
; param: operation:view_orientation_flipX = 0
; param: operation:view_orientation_flipY = 0
; param: operation:view_origin_mode = jobOrigin
; param: operation:view_origin_boxPoint = top center
; param: operation:show_machine = 0
; param: operation:multiAxisRotaryAxis_orientation_mode = axisZ
; param: operation:multiAxisRotaryAxis_origin_mode = jobOrigin
; param: operation:toolAxisMode = vertical
; param: operation:leadAngle = 0
; param: operation:leanAngle = 0
; param: operation:multiAxisTiltAngleFixed = 0
; param: operation:toolAxisLimitReferenceZ = setup
; param: operation:smoothingDistance = 1
; param: operation:smoothingAngle = 5
; param: operation:tiltAngle = 0
; param: operation:applyMicroTilt = 1
; param: operation:tiltToolMode = automatic
; param: operation:maximumTiltValidation = 180
; param: operation:minimumTilt5Axis = 0
; param: operation:maximumTilt5Axis = 90
; param: operation:tiltLimitMode = remove_toolpath
; param: operation:usePolarWhenNecessary = 0
; param: operation:polarMode = automatic
; param: operation:polarLineAngle = 0
; param: operation:boundaryMode = selection
; param: operation:useSilhouetteAsMachiningBoundary = 0
; param: operation:silhouetteAperture = 2.5
; param: operation:minimumSilhouetteArea = 0.009817477042468103
; param: operation:boundaryContainment = center
; param: operation:boundaryOffset = -0.22859999999999997
; param: operation:machiningBoundaryOffset = -0.22859999999999997
; param: operation:boundaryConfineTool = 0
; param: operation:contactOnly = 1
; param: operation:slopeAngleFrom = 0
; param: operation:slopeAngleTo = 90
; param: operation:restMaterialSource = none
; param: operation:restMaterialFromJob = 0
; param: operation:restMaterialOperation = 0
; param: operation:restMaterialUnion = 1
; param: operation:restMaterialPrevious = 1
; param: operation:restMaterialCutterDiameter = 1
; param: operation:restMaterialCornerRadius = 0.5
; param: operation:restMaterialTaperAngle = 0
; param: operation:restMaterialShoulderLength = 0
; param: operation:restMaterialResolution = 1.016
; param: operation:restMaterialOverlap = 0.05
; param: operation:restMaterialFile = 
; param: operation:restMaterialTool = 
; param: operation:restMaterialAdjustment = use as computed
; param: operation:restMaterialAdjustmentOffset = 0
; param: operation:ignoreStockLessThan = 0.02032
; param: operation:includeSetupModel = 1
; param: operation:touchAvoidMode = avoid
; param: operation:viewAbsoluteClearances = 0
; param: operation:radialClearanceInfo = -0.22859999999999997
; param: operation:axialClearanceInfo = -0.22859999999999997
; param: operation:clearanceInfo = 0
; param: operation:checkSurfaceClearance = 0.01016
; param: operation:trimCheckSurfaces = 0
; param: operation:isClearanceAreaEnabled = 0
; param: operation:clearanceAreaType = plane
; param: operation:clearanceArea_orientation_mode = toolAxisZ
; param: operation:clearanceArea_orientation_flipAxis = 0
; param: operation:clearanceArea_origin_mode = jobOrigin
; param: operation:clearanceArea_origin_boxPoint = top center
; param: operation:clearanceHeight_mode = from retract height
; param: operation:clearanceHeightFromHighest_checkStock = top
; param: operation:clearanceHeightFromLowest_checkStock = bottom
; param: operation:clearanceHeightFromHighest_checkModel = top
; param: operation:clearanceHeightFromLowest_checkModel = bottom
; param: operation:clearanceHeightFromHighest_checkFixture = top
; param: operation:clearanceHeightFromLowest_checkFixture = bottom
; param: operation:clearanceHeight_offset = 10.16
; param: operation:clearanceHeight_value = 15.239999999999998
; param: operation:zClearance = 15.239999999999998
; param: operation:relativeZClearance = 15.239999999999998
; param: operation:clearanceHeight_absolute = 1
; param: operation:clearanceAreaHeight_mode = from retract height
; param: operation:clearanceAreaHeightFromHighest_checkStock = top
; param: operation:clearanceAreaHeightFromLowest_checkStock = bottom
; param: operation:clearanceAreaHeightFromHighest_checkModel = top
; param: operation:clearanceAreaHeightFromLowest_checkModel = bottom
; param: operation:clearanceAreaHeightFromHighest_checkFixture = top
; param: operation:clearanceAreaHeightFromLowest_checkFixture = bottom
; param: operation:clearanceAreaHeight_offset = 10.16
; param: operation:clearanceAreaHeight_value = 0
; param: operation:clearanceAreaHeight_absolute = 0
; param: operation:clearanceAreaCylinderRadius_mode = from retract radius
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkStock = outer diameter
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkModel = outer diameter
; param: operation:clearanceAreaCylinderRadiusFromOutermost_checkFixture = outer diameter
; param: operation:clearanceAreaCylinderRadius_offset = 10.16
; param: operation:clearanceAreaCylinderRadius_direct = 2.032
; param: operation:clearanceAreaCylinderRadius_value = 1.016
; param: operation:clearanceAreaCylinderRadius_absolute = 0
; param: operation:clearanceAreaSphereRadius_mode = from retract radius
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkStock = outer diameter
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkModel = outer diameter
; param: operation:clearanceAreaSphereRadiusFromOutermost_checkFixture = outer diameter
; param: operation:clearanceAreaSphereRadius_offset = 10.16
; param: operation:clearanceAreaSphereRadius_direct = 2.032
; param: operation:clearanceAreaSphereRadius_value = 1.016
; param: operation:clearanceAreaSphereRadius_absolute = 0
; param: operation:retractHeight_mode = from stock top
; param: operation:retractHeightFromHighest_checkStock = top
; param: operation:retractHeightFromLowest_checkStock = bottom
; param: operation:retractHeightFromHighest_checkModel = top
; param: operation:retractHeightFromLowest_checkModel = bottom
; param: operation:retractHeightFromHighest_checkFixture = top
; param: operation:retractHeightFromLowest_checkFixture = bottom
; param: operation:retractHeight_offset = 5.08
; param: operation:retractHeight_value = 5.08
; param: operation:zRetract = 5.08
; param: operation:relativeZRetract = 5.08
; param: operation:retractHeight_absolute = 1
; param: operation:retractAreaType = plane
; param: operation:retractAreaHeight_mode = from stock top
; param: operation:retractAreaHeightFromHighest_checkStock = top
; param: operation:retractAreaHeightFromLowest_checkStock = bottom
; param: operation:retractAreaHeightFromHighest_checkModel = top
; param: operation:retractAreaHeightFromLowest_checkModel = bottom
; param: operation:retractAreaHeightFromHighest_checkFixture = top
; param: operation:retractAreaHeightFromLowest_checkFixture = bottom
; param: operation:retractAreaHeight_offset = 5.08
; param: operation:retractAreaHeight_value = 0
; param: operation:retractAreaHeight_absolute = 1
; param: operation:retractAreaCylinderRadius_mode = from stock od
; param: operation:retractAreaCylinderRadiusFromOutermost_checkStock = outer diameter
; param: operation:retractAreaCylinderRadiusFromOutermost_checkModel = outer diameter
; param: operation:retractAreaCylinderRadiusFromOutermost_checkFixture = outer diameter
; param: operation:retractAreaCylinderRadius_offset = 5.08
; param: operation:retractAreaCylinderRadius_direct = 2.032
; param: operation:retractAreaCylinderRadius_value = 1.016
; param: operation:retractAreaCylinderRadius_absolute = 0
; param: operation:retractAreaSphereRadius_mode = from stock od
; param: operation:retractAreaSphereRadiusFromOutermost_checkStock = outer diameter
; param: operation:retractAreaSphereRadiusFromOutermost_checkModel = outer diameter
; param: operation:retractAreaSphereRadiusFromOutermost_checkFixture = outer diameter
; param: operation:retractAreaSphereRadius_offset = 5.08
; param: operation:retractAreaSphereRadius_direct = 2.032
; param: operation:retractAreaSphereRadius_value = 1.016
; param: operation:retractAreaSphereRadius_absolute = 0
; param: operation:topHeight_mode = from stock top
; param: operation:topHeightFromHighest_checkStock = top
; param: operation:topHeightFromLowest_checkStock = bottom
; param: operation:topHeightFromHighest_checkModel = ignore
; param: operation:topHeightFromLowest_checkModel = ignore
; param: operation:topHeightFromHighest_checkFixture = ignore
; param: operation:topHeightFromLowest_checkFixture = ignore
; param: operation:topHeight_offset = 0
; param: operation:topHeight_value = 0
; param: operation:topHeight_absolute = 1
; param: operation:bottomHeight_mode = from surface bottom
; param: operation:bottomHeightFromHighest_checkStock = bottom
; param: operation:bottomHeightFromLowest_checkStock = ignore
; param: operation:bottomHeightFromHighest_checkModel = bottom
; param: operation:bottomHeightFromLowest_checkModel = bottom
; param: operation:bottomHeightFromHighest_checkFixture = ignore
; param: operation:bottomHeightFromLowest_checkFixture = ignore
; param: operation:bottomHeight_offset = 0
; param: operation:bottomHeight_value = -26.496
; param: operation:bottomHeight_absolute = 1
; param: operation:tolerance = 0.01016
; param: operation:contourTolerance = 0.00508
; param: operation:totalSurfaceTolerance = 0.00508
; param: operation:surfaceTriangulationTolerance = 0.00508
; param: operation:calculationTolerance = 0.00508
; param: operation:thinningTolerance = 0.0000508
; param: operation:chainingTolerance = 0.01016
; param: operation:gougingTolerance = 0.00508
; param: operation:overthickness = 0
; param: operation:bitangentAngle = 20
; param: operation:internalPasses = 1
; param: operation:linkInsideOut = 0
; param: operation:linkInsideOutside = outside-in
; param: operation:limitNumberOfStepovers = 1
; param: operation:numberOfStepovers = 0
; param: operation:stepover = 0.25
; param: operation:cuspHeightStepover = 0.07322000000000001
; param: operation:minimumFragmentLength = 0.050800000000000005
; param: operation:fragmentExtensionDistance = 0
; param: operation:direction = both ways
; param: operation:upDownMilling = dont care
; param: operation:upDownMillingShallowAngle = 1
; param: operation:manualProfileDiameter = 0
; param: operation:minimumProfileDiameter = 0
; param: operation:stockToLeave = -0.22859999999999997
; param: operation:verticalStockToLeave = -0.22859999999999997
; param: operation:simpleStockToLeave = 0
; param: operation:filletsCornerRadius = 0
; param: operation:legacyFillets = 1
; param: operation:useCombinedFilter = 1
; param: operation:useDMKSmoothing = 0
; param: operation:smoothingFilterMode = redistribute
; param: operation:smoothingFilterMaxSpacing = 0.508
; param: operation:smoothingFilterMaxAngle = 3
; param: operation:smoothingFilterToleranceForEvenlySpacedPoints = 0.00508
; param: operation:smoothingFilterToleranceFactor = 0.5
; param: operation:smoothingFilterTolerance = 0
; param: operation:reducedFeedChange = 25
; param: operation:reducedFeedRadius = 0
; param: operation:reducedFeedDistance = 0
; param: operation:reducedFeedrate = 38.099999999999994
; param: operation:reduceOnlyInnerCorners = 1
; param: operation:surfaceSpeedOnArcs = 0
; param: operation:maximumReducedFeedrateInternalArcFinishing = 100
; param: operation:maximumIncreasedFeedrateExternalArcFinishing = 100
; param: operation:maximumReducedFeedrateInternalArc = 100
; param: operation:maximumIncreasedFeedrateExternalArc = 100
; param: operation:retractionPolicy = full
; param: operation:highFeedrateMode = disabled
; param: operation:highFeedrate = 152.39999999999998
; param: operation:allowRapidRetract = 1
; param: operation:safeDistance = 2.032
; param: operation:stayDownDistance = 2.5
; param: operation:entry_verticalRadius = 0.05
; param: operation:leadInRadius = 0.05
; param: operation:leadInVerticalRadius = 0.05
; param: operation:exit_verticalRadius = 0.05
; param: operation:leadOutRadius = 0.05
; param: operation:leadOutVerticalRadius = 0.05
; param: operation:transitionType = curve
; param: operation:isOperationTemplate = 0
; param: operation:use_tool_stepdown = 0
; param: operation:tool_stepdown = 23.85
; param: operation:tool_finishingStepdown = 0.2032
; param: operation:use_tool_stepover = 0
; param: operation:tool_stepover = 0.15
; param: operation:tool_finishingStepover = 0.05
; param: operation:tool_rampType = helix
; param: operation:tool_rampAngle = 2
;When using Fusion for Personal Use, the feedrate of rapid
;moves is reduced to match the feedrate of cutting moves,
;which can increase machining time. Unrestricted rapid moves
;are available with a Fusion Subscription.
; param: movement:lead_in = 152.39999999999998
; param: movement:cutting = 152.39999999999998
; param: movement:lead_out = 152.39999999999998
; param: movement:transition = 152.39999999999998
; param: movement:direct = 152.39999999999998
; param: movement:helix_ramp = 50.79999999999999
; param: movement:profile_ramp = 50.79999999999999
; param: movement:zigzag_ramp = 50.79999999999999
; param: movement:ramp = 50.79999999999999
; param: movement:plunge = 50.79999999999999
; param: movement:predrill = 152.39999999999998
; param: movement:extended = 152.39999999999998
; param: movement:reduced = 152.39999999999998
; param: movement:finish_cutting = 152.39999999999998
; param: movement:high_feed = 152.39999999999998
; param: movement:depositing = 0
; param: movement:connection = 0
; param: movement:drill_breakthrough = 0
; param: movement:gun_drill_positioning = 0
; 
; Ranges Table:
;   X: Min=69.086 Max=85.454 Size=16.368
;   Y: Min=47.552 Max=64.19 Size=16.638
;   Z: Min=-8.325 Max=15.24 Size=23.565
; 
; Tools Table:
;  T1 D=0.5 CR=0.25 TAPER=6.2deg - ZMIN=-8.325 - tapered mill 
; 
; Feedrate and Scaling Properties:
;   Feed: Travel speed X/Y = 4470
;   Feed: Travel Speed Z = 2235
;   Feed: Enforce Feedrate = true
;   Feed: Scale Feedrate = false
;   Feed: Max XY Cut Speed = 1000
;   Feed: Max Z Cut Speed = 400
;   Feed: Max Toolpath Speed = 1000
; 
; G1->G0 Mapping Properties:
;   Map: First G1 -> G0 Rapid = false
;   Map: G1s -> G0 Rapids = false
;   Map: SafeZ Mode = Retract : default = 15
;   Map: Allow Rapid Z = false
; 
; *** START begin ***
;   Set Absolute Positioning
;   Units = mm
G90
G21
;   Disable stepper timeout
M84 S0
;   Set current position to 0,0,0
G92 X0 Y0 Z0
; *** START end ***
; 
; *** SECTION begin ***
;   X Min: 69.086 - X Max: 85.454
;   Y Min: 47.552 - Y Max: 64.19
;   Z Min: -8.325 - Z Max: 15.24
; Pencil2 3 - Milling - Tool: 1 -  tapered mill
; COMMAND_START_SPINDLE
; COMMAND_SPINDLE_CLOCKWISE
; >>> Spindle Speed: Manual
M0 Turn ON 18000RPM
; COMMAND_COOLANT_ON
;   tool.coolant = 0 strCoolant = Off
; ---- Coolant: Off cur: Off A: Off B: Off
M117  Pencil2 (3)
; MOVEMENT_CUTTING
G1 X77.059 Y62.086 Z15.24 F152
G1 Z0.716 F152
; MOVEMENT_PLUNGE
G1 Z-7.942 F51
; MOVEMENT_LEAD_IN
G1 Z-7.948 F152
; MOVEMENT_CUTTING
G1 Y62.088 Z-7.962 F152
G1 X77.058 Y62.091 Z-7.999 F152
G1 X77.052 Y62.113 Z-8.196 F152
G1 Y62.116 Z-8.224 F152
G1 X77.05 Y62.124 Z-8.29 F152
G1 X77.049 Y62.125 Z-8.304 F152
; MOVEMENT_LINK_TRANSITION
G1 Y62.127 Z-8.325 F152
; MOVEMENT_CUTTING
G1 X77.045 F152
G1 X77.031 Y62.128 F152
G1 X77.002 Y62.133 F152
G1 X76.945 Y62.146 F152
G1 X76.887 Y62.163 F152
G1 X76.864 Y62.17 F152
G1 X76.83 Y62.182 F152
G1 X76.716 Y62.226 F152
G1 X76.713 Y62.227 F152
G1 X76.658 Y62.25 F152
G1 X76.601 Y62.275 F152
G1 X76.579 Y62.285 F152
G1 X76.544 Y62.301 F152
G1 X76.486 Y62.327 F152
G1 X76.452 Y62.342 F152
G1 X76.429 Y62.354 F152
G1 X76.372 Y62.381 F152
G1 X76.333 Y62.399 F152
G1 X76.314 Y62.408 F152
G1 X76.257 Y62.436 F152
G1 X76.214 Y62.457 F152
G1 X76.2 Y62.464 F152
G1 X76.143 Y62.491 F152
G1 X76.096 Y62.514 F152
G1 X76.085 Y62.519 F152
G1 X76.028 Y62.547 F152
G1 X75.977 Y62.571 F152
G1 X75.971 Y62.575 F152
G1 X75.913 Y62.602 F152
G1 X75.857 Y62.628 F152
G1 X75.856 Y62.629 F152
G1 X75.799 Y62.656 F152
G1 X75.741 Y62.682 F152
G1 X75.733 Y62.686 F152
G1 X75.684 Y62.709 F152
G1 X75.627 Y62.735 F152
G1 X75.607 Y62.743 F152
G1 X75.57 Y62.76 F152
G1 X75.512 Y62.785 F152
G1 X75.476 Y62.8 F152
G1 X75.455 Y62.81 F152
G1 X75.398 Y62.834 F152
G1 X75.34 Y62.857 F152
G1 X75.338 F152
G1 X75.283 Y62.879 F152
G1 X75.226 Y62.902 F152
G1 X75.193 Y62.915 F152
G1 X75.168 Y62.925 F152
G1 X75.111 Y62.946 F152
G1 X75.054 Y62.965 F152
G1 X75.032 Y62.972 F152
G1 X74.997 Y62.985 F152
G1 X74.882 Y63.022 F152
G1 X74.86 Y63.029 F152
G1 X74.825 Y63.04 F152
G1 X74.767 Y63.055 F152
G1 X74.71 Y63.071 F152
G1 X74.653 Y63.087 F152
G1 X74.651 F152
G1 X74.595 Y63.102 F152
G1 X74.538 Y63.115 F152
G1 X74.424 Y63.14 F152
G1 X74.407 Y63.144 F152
G1 X74.366 Y63.153 F152
G1 X74.309 Y63.165 F152
G1 X74.194 Y63.187 F152
G1 X74.137 Y63.197 F152
G1 X74.113 Y63.201 F152
G1 X74.08 Y63.207 F152
G1 X73.965 Y63.227 F152
G1 X73.908 Y63.236 F152
G1 X73.851 Y63.246 F152
G1 X73.77 Y63.258 F152
G1 X73.736 Y63.265 F152
G1 X73.564 Y63.292 F152
G1 X73.507 Y63.301 F152
G1 X73.449 Y63.31 F152
G1 X73.409 Y63.316 F152
G1 X73.278 Y63.336 F152
G1 X73.22 Y63.344 F152
G1 X73.163 Y63.352 F152
G1 X73.106 Y63.36 F152
G1 X73.048 Y63.367 F152
G1 X72.991 Y63.372 F152
G1 X72.976 Y63.373 F152
G1 X72.934 Y63.378 F152
G1 X72.819 Y63.388 F152
G1 X72.762 Y63.39 F152
G1 X72.647 Y63.392 F152
G1 X72.59 Y63.394 F152
G1 X72.533 F152
G1 X72.475 Y63.39 F152
G1 X72.303 Y63.374 F152
G1 X72.3 Y63.373 F152
G1 X72.246 Y63.369 F152
G1 X72.189 Y63.36 F152
G1 X72.132 Y63.347 F152
G1 X72.017 Y63.32 F152
G1 X71.998 Y63.316 F152
G1 X71.96 Y63.308 F152
G1 X71.902 Y63.293 F152
G1 X71.845 Y63.274 F152
G1 X71.805 Y63.258 F152
G1 X71.788 Y63.252 F152
G1 X71.616 Y63.188 F152
G1 X71.559 Y63.163 F152
G1 X71.522 Y63.144 F152
G1 X71.501 Y63.133 F152
G1 X71.444 Y63.104 F152
G1 X71.413 Y63.087 F152
G1 X71.329 Y63.044 F152
G1 X71.303 Y63.029 F152
G1 X71.272 Y63.011 F152
G1 X71.158 Y62.936 F152
G1 X71.125 Y62.915 F152
G1 X71.1 Y62.899 F152
G1 X71.043 Y62.86 F152
G1 X71.038 Y62.857 F152
G1 X70.986 Y62.82 F152
G1 X70.961 Y62.8 F152
G1 X70.928 Y62.775 F152
G1 X70.888 Y62.743 F152
G1 X70.816 Y62.686 F152
G1 X70.814 Y62.685 F152
G1 X70.743 Y62.628 F152
G1 X70.699 Y62.589 F152
G1 X70.642 Y62.537 F152
G1 X70.616 Y62.514 F152
G1 X70.553 Y62.457 F152
G1 X70.527 Y62.433 F152
G1 X70.491 Y62.399 F152
G1 X70.47 Y62.379 F152
G1 X70.432 Y62.342 F152
G1 X70.355 Y62.265 F152
G1 X70.32 Y62.227 F152
G1 X70.298 Y62.205 F152
G1 X70.264 Y62.17 F152
G1 X70.241 Y62.144 F152
G1 X70.213 Y62.113 F152
G1 X70.162 Y62.056 F152
G1 X70.126 Y62.016 F152
G1 X70.11 Y61.998 F152
G1 X70.069 Y61.952 F152
G1 X70.059 Y61.941 F152
G1 X70.013 Y61.884 F152
G1 X70.012 Y61.882 F152
G1 X69.967 Y61.826 F152
G1 X69.954 Y61.81 F152
G1 X69.921 Y61.769 F152
G1 X69.897 Y61.739 F152
G1 X69.875 Y61.712 F152
G1 X69.84 Y61.663 F152
G1 X69.725 Y61.501 F152
G1 X69.712 Y61.483 F152
G1 X69.673 Y61.425 F152
G1 X69.668 Y61.416 F152
G1 X69.638 Y61.368 F152
G1 X69.61 Y61.322 F152
G1 X69.603 Y61.311 F152
G1 X69.568 Y61.254 F152
G1 X69.553 Y61.228 F152
G1 X69.534 Y61.196 F152
G1 X69.503 Y61.139 F152
G1 X69.496 Y61.124 F152
G1 X69.474 Y61.082 F152
G1 X69.446 Y61.024 F152
G1 X69.439 Y61.009 F152
G1 X69.417 Y60.967 F152
G1 X69.389 Y60.91 F152
G1 X69.381 Y60.893 F152
G1 X69.365 Y60.853 F152
G1 X69.343 Y60.795 F152
G1 X69.324 Y60.746 F152
G1 X69.32 Y60.738 F152
G1 X69.298 Y60.681 F152
G1 X69.276 Y60.623 F152
G1 X69.267 Y60.596 F152
G1 X69.258 Y60.566 F152
G1 X69.193 Y60.337 F152
G1 X69.18 Y60.28 F152
G1 X69.152 Y60.132 F152
G1 X69.147 Y60.108 F152
G1 X69.136 Y60.051 F152
G1 X69.128 Y59.993 F152
G1 X69.103 Y59.764 F152
G1 X69.097 Y59.707 F152
G1 X69.095 Y59.65 F152
G1 Y59.632 F152
G1 X69.09 Y59.535 F152
G1 X69.088 Y59.478 F152
G1 X69.086 Y59.42 F152
G1 X69.088 Y59.306 F152
G1 X69.089 Y59.249 F152
G1 X69.09 Y59.191 F152
G1 X69.094 Y59.077 F152
G1 X69.095 Y59.071 F152
G1 X69.098 Y59.019 F152
G1 X69.103 Y58.962 F152
G1 X69.106 Y58.905 F152
G1 X69.115 Y58.79 F152
G1 X69.122 Y58.733 F152
G1 X69.143 Y58.561 F152
G1 X69.149 Y58.504 F152
G1 X69.152 Y58.488 F152
G1 X69.157 Y58.447 F152
G1 X69.186 Y58.275 F152
G1 X69.195 Y58.217 F152
G1 X69.205 Y58.16 F152
G1 X69.209 Y58.136 F152
G1 X69.216 Y58.103 F152
G1 X69.227 Y58.046 F152
G1 X69.24 Y57.988 F152
G1 X69.251 Y57.931 F152
G1 X69.264 Y57.874 F152
G1 X69.267 Y57.862 F152
G1 X69.276 Y57.817 F152
G1 X69.319 Y57.645 F152
G1 X69.324 Y57.626 F152
G1 X69.334 Y57.587 F152
G1 X69.348 Y57.53 F152
G1 X69.363 Y57.473 F152
G1 X69.38 Y57.416 F152
G1 X69.381 Y57.413 F152
G1 X69.397 Y57.358 F152
G1 X69.415 Y57.301 F152
G1 X69.432 Y57.244 F152
G1 X69.439 Y57.224 F152
G1 X69.449 Y57.186 F152
G1 X69.468 Y57.129 F152
G1 X69.489 Y57.072 F152
G1 X69.496 Y57.052 F152
G1 X69.509 Y57.015 F152
G1 X69.529 Y56.957 F152
G1 X69.57 Y56.843 F152
G1 X69.593 Y56.785 F152
G1 X69.61 Y56.744 F152
G1 X69.617 Y56.728 F152
G1 X69.663 Y56.614 F152
G1 X69.668 Y56.604 F152
G1 X69.687 Y56.556 F152
G1 X69.713 Y56.499 F152
G1 X69.725 Y56.475 F152
G1 X69.74 Y56.442 F152
G1 X69.766 Y56.384 F152
G1 X69.782 Y56.351 F152
G1 X69.793 Y56.327 F152
G1 X69.82 Y56.27 F152
G1 X69.84 Y56.233 F152
G1 X69.85 Y56.213 F152
G1 X69.88 Y56.155 F152
G1 X69.897 Y56.123 F152
G1 X69.91 Y56.098 F152
G1 X69.94 Y56.041 F152
G1 X69.954 Y56.014 F152
G1 X69.971 Y55.983 F152
G1 X70.004 Y55.926 F152
G1 X70.012 Y55.914 F152
G1 X70.038 Y55.869 F152
G1 X70.069 Y55.816 F152
G1 X70.072 Y55.812 F152
G1 X70.105 Y55.754 F152
G1 X70.126 Y55.722 F152
G1 X70.179 Y55.64 F152
G1 X70.183 Y55.633 F152
G1 X70.217 Y55.582 F152
G1 X70.241 Y55.545 F152
G1 X70.253 Y55.525 F152
G1 X70.29 Y55.468 F152
G1 X70.329 Y55.411 F152
G1 X70.355 Y55.374 F152
G1 X70.37 Y55.353 F152
G1 X70.41 Y55.296 F152
G1 X70.413 Y55.292 F152
G1 X70.451 Y55.239 F152
G1 X70.47 Y55.213 F152
G1 X70.527 Y55.136 F152
G1 X70.535 Y55.124 F152
G1 X70.578 Y55.067 F152
G1 X70.585 Y55.059 F152
G1 X70.622 Y55.01 F152
G1 X70.642 Y54.984 F152
G1 X70.665 Y54.952 F152
G1 X70.699 Y54.908 F152
G1 X70.709 Y54.895 F152
G1 X70.752 Y54.838 F152
G1 X70.756 Y54.832 F152
G1 X70.796 Y54.78 F152
G1 X70.814 Y54.757 F152
G1 X70.871 Y54.682 F152
G1 X70.884 Y54.666 F152
G1 X70.927 Y54.609 F152
G1 X70.928 Y54.607 F152
G1 X70.97 Y54.551 F152
G1 X70.986 Y54.533 F152
G1 X71.015 Y54.494 F152
G1 X71.043 Y54.457 F152
G1 X71.059 Y54.437 F152
G1 X71.147 Y54.322 F152
G1 X71.158 Y54.309 F152
G1 X71.191 Y54.265 F152
G1 X71.215 Y54.234 F152
G1 X71.235 Y54.208 F152
G1 X71.272 Y54.159 F152
G1 X71.279 Y54.15 F152
G1 X71.323 Y54.093 F152
G1 X71.329 Y54.086 F152
G1 X71.368 Y54.036 F152
G1 X71.387 Y54.012 F152
G1 X71.412 Y53.978 F152
G1 X71.501 Y53.864 F152
G1 X71.545 Y53.807 F152
G1 X71.559 Y53.79 F152
G1 X71.59 Y53.749 F152
G1 X71.616 Y53.716 F152
G1 X71.635 Y53.692 F152
G1 X71.769 Y53.52 F152
G1 X71.788 Y53.496 F152
G1 X71.814 Y53.463 F152
G1 X71.845 Y53.424 F152
G1 X71.859 Y53.406 F152
G1 X71.902 Y53.35 F152
G1 X71.903 Y53.348 F152
G1 X71.948 Y53.291 F152
G1 X71.96 Y53.277 F152
G1 X71.994 Y53.234 F152
G1 X72.017 Y53.203 F152
G1 X72.038 Y53.176 F152
G1 X72.074 Y53.131 F152
G1 X72.083 Y53.119 F152
G1 X72.129 Y53.062 F152
G1 X72.132 Y53.058 F152
G1 X72.189 Y52.987 F152
G1 X72.22 Y52.947 F152
G1 X72.246 Y52.914 F152
G1 X72.265 Y52.89 F152
G1 X72.356 Y52.776 F152
G1 X72.361 Y52.77 F152
G1 X72.402 Y52.718 F152
G1 X72.418 Y52.698 F152
G1 X72.448 Y52.661 F152
G1 X72.475 Y52.626 F152
G1 X72.533 Y52.554 F152
G1 X72.539 Y52.546 F152
G1 X72.586 Y52.489 F152
G1 X72.59 Y52.483 F152
G1 X72.631 Y52.432 F152
G1 X72.647 Y52.412 F152
G1 X72.705 Y52.341 F152
G1 X72.724 Y52.317 F152
G1 X72.762 Y52.272 F152
G1 X72.771 Y52.26 F152
G1 X72.817 Y52.203 F152
G1 X72.819 Y52.201 F152
G1 X72.865 Y52.145 F152
G1 X72.876 Y52.131 F152
G1 X72.912 Y52.088 F152
G1 X72.96 Y52.031 F152
G1 X72.991 Y51.993 F152
G1 X73.007 Y51.974 F152
G1 X73.048 Y51.924 F152
G1 X73.055 Y51.916 F152
G1 X73.103 Y51.859 F152
G1 X73.106 Y51.856 F152
G1 X73.163 Y51.789 F152
G1 X73.201 Y51.744 F152
G1 X73.252 Y51.687 F152
G1 X73.278 Y51.658 F152
G1 X73.302 Y51.63 F152
G1 X73.335 Y51.593 F152
G1 X73.353 Y51.573 F152
G1 X73.392 Y51.53 F152
G1 X73.405 Y51.515 F152
G1 X73.449 Y51.467 F152
G1 X73.458 Y51.458 F152
G1 X73.507 Y51.404 F152
G1 X73.51 Y51.401 F152
G1 X73.564 Y51.343 F152
G1 X73.617 Y51.286 F152
G1 X73.621 Y51.281 F152
G1 X73.672 Y51.229 F152
G1 X73.679 Y51.221 F152
G1 X73.726 Y51.172 F152
G1 X73.736 Y51.161 F152
G1 X73.781 Y51.114 F152
G1 X73.793 Y51.101 F152
G1 X73.836 Y51.057 F152
G1 X73.851 Y51.043 F152
G1 X73.893 Y51 F152
G1 X73.908 Y50.984 F152
G1 X73.949 Y50.942 F152
G1 X73.965 Y50.926 F152
G1 X74.005 Y50.885 F152
G1 X74.022 Y50.868 F152
G1 X74.064 Y50.828 F152
G1 X74.08 Y50.812 F152
G1 X74.122 Y50.771 F152
G1 X74.137 Y50.756 F152
G1 X74.181 Y50.713 F152
G1 X74.194 Y50.7 F152
G1 X74.239 Y50.656 F152
G1 X74.252 Y50.643 F152
G1 X74.299 Y50.599 F152
G1 X74.309 Y50.59 F152
G1 X74.36 Y50.541 F152
G1 X74.366 Y50.535 F152
G1 X74.421 Y50.484 F152
G1 X74.424 Y50.481 F152
G1 X74.481 Y50.427 F152
G1 X74.538 Y50.374 F152
G1 X74.544 Y50.37 F152
G1 X74.606 Y50.312 F152
G1 X74.653 Y50.269 F152
G1 X74.669 Y50.255 F152
G1 X74.732 Y50.198 F152
G1 X74.767 Y50.166 F152
G1 X74.796 Y50.14 F152
G1 X74.861 Y50.083 F152
G1 X74.882 Y50.064 F152
G1 X74.926 Y50.026 F152
G1 X74.939 Y50.013 F152
G1 X74.991 Y49.969 F152
G1 X74.997 Y49.964 F152
G1 X75.054 Y49.914 F152
G1 X75.057 Y49.911 F152
G1 X75.111 Y49.865 F152
G1 X75.168 Y49.816 F152
G1 X75.191 Y49.797 F152
G1 X75.226 Y49.767 F152
G1 X75.259 Y49.739 F152
G1 X75.283 Y49.719 F152
G1 X75.327 Y49.682 F152
G1 X75.34 Y49.671 F152
G1 X75.396 Y49.625 F152
G1 X75.398 Y49.623 F152
G1 X75.455 Y49.576 F152
G1 X75.512 Y49.529 F152
G1 X75.536 Y49.51 F152
G1 X75.57 Y49.483 F152
G1 X75.605 Y49.453 F152
G1 X75.627 Y49.436 F152
G1 X75.676 Y49.396 F152
G1 X75.684 Y49.389 F152
G1 X75.741 Y49.343 F152
G1 X75.748 Y49.338 F152
G1 X75.82 Y49.281 F152
G1 X75.856 Y49.253 F152
G1 X75.893 Y49.224 F152
G1 X75.913 Y49.207 F152
G1 X75.965 Y49.167 F152
G1 X75.971 Y49.162 F152
G1 X76.085 Y49.074 F152
G1 X76.115 Y49.052 F152
G1 X76.143 Y49.031 F152
G1 X76.19 Y48.995 F152
G1 X76.2 Y48.987 F152
G1 X76.257 Y48.944 F152
G1 X76.265 Y48.937 F152
G1 X76.314 Y48.9 F152
G1 X76.34 Y48.88 F152
G1 X76.372 Y48.856 F152
G1 X76.415 Y48.823 F152
G1 X76.486 Y48.769 F152
G1 X76.492 Y48.766 F152
G1 X76.544 Y48.727 F152
G1 X76.57 Y48.708 F152
G1 X76.647 Y48.651 F152
G1 X76.658 Y48.642 F152
G1 X76.716 Y48.601 F152
G1 X76.725 Y48.594 F152
G1 X76.773 Y48.56 F152
G1 X76.806 Y48.536 F152
G1 X76.83 Y48.519 F152
G1 X76.886 Y48.479 F152
G1 X76.887 Y48.477 F152
G1 X76.945 Y48.437 F152
G1 X76.967 Y48.422 F152
G1 X77.002 Y48.398 F152
G1 X77.05 Y48.365 F152
G1 X77.059 Y48.358 F152
G1 X77.134 Y48.307 F152
G1 X77.174 Y48.281 F152
G1 X77.22 Y48.25 F152
G1 X77.231 Y48.243 F152
G1 X77.289 Y48.205 F152
G1 X77.307 Y48.193 F152
G1 X77.346 Y48.168 F152
G1 X77.395 Y48.136 F152
G1 X77.403 Y48.131 F152
G1 X77.46 Y48.095 F152
G1 X77.488 Y48.078 F152
G1 X77.518 Y48.06 F152
G1 X77.575 Y48.025 F152
G1 X77.581 Y48.021 F152
G1 X77.632 Y47.991 F152
G1 X77.681 Y47.964 F152
G1 X77.69 Y47.958 F152
G1 X77.747 Y47.926 F152
G1 X77.783 Y47.906 F152
G1 X77.804 Y47.894 F152
G1 X77.862 Y47.863 F152
G1 X77.892 Y47.849 F152
G1 X77.919 Y47.836 F152
G1 X77.976 Y47.808 F152
G1 X78.033 Y47.779 F152
G1 X78.091 Y47.753 F152
G1 X78.138 Y47.735 F152
G1 X78.148 Y47.73 F152
G1 X78.283 Y47.677 F152
G1 X78.32 Y47.664 F152
G1 X78.377 Y47.647 F152
G1 X78.435 Y47.631 F152
G1 X78.475 Y47.62 F152
G1 X78.492 Y47.615 F152
G1 X78.549 Y47.599 F152
G1 X78.606 Y47.587 F152
G1 X78.664 Y47.578 F152
G1 X78.721 Y47.571 F152
G1 X78.778 Y47.563 F152
G1 X78.784 F152
G1 X78.836 Y47.556 F152
G1 X78.893 Y47.552 F152
G1 X78.95 F152
G1 X79.122 Y47.557 F152
G1 X79.179 Y47.562 F152
G1 X79.183 Y47.563 F152
G1 X79.237 Y47.571 F152
G1 X79.294 Y47.582 F152
G1 X79.351 Y47.595 F152
G1 X79.409 Y47.607 F152
G1 X79.464 Y47.62 F152
G1 X79.466 F152
G1 X79.523 Y47.638 F152
G1 X79.581 Y47.66 F152
G1 X79.624 Y47.677 F152
G1 X79.638 Y47.683 F152
G1 X79.695 Y47.705 F152
G1 X79.752 Y47.728 F152
G1 X79.766 Y47.735 F152
G1 X79.81 Y47.756 F152
G1 X79.867 Y47.789 F152
G1 X79.871 Y47.792 F152
G1 X79.924 Y47.821 F152
G1 X79.972 Y47.849 F152
G1 X79.982 Y47.854 F152
G1 X80.039 Y47.888 F152
G1 X80.065 Y47.906 F152
G1 X80.096 Y47.929 F152
G1 X80.145 Y47.964 F152
G1 X80.154 Y47.97 F152
G1 X80.211 Y48.011 F152
G1 X80.223 Y48.021 F152
G1 X80.268 Y48.057 F152
G1 X80.293 Y48.078 F152
G1 X80.325 Y48.105 F152
G1 X80.361 Y48.136 F152
G1 X80.383 Y48.153 F152
G1 X80.427 Y48.193 F152
G1 X80.44 Y48.204 F152
G1 X80.488 Y48.25 F152
G1 X80.497 Y48.258 F152
G1 X80.549 Y48.307 F152
G1 X80.555 Y48.313 F152
G1 X80.612 Y48.369 F152
G1 X80.662 Y48.422 F152
G1 X80.669 Y48.429 F152
G1 X80.717 Y48.479 F152
G1 X80.727 Y48.489 F152
G1 X80.77 Y48.536 F152
G1 X80.784 Y48.552 F152
G1 X80.821 Y48.594 F152
G1 X80.841 Y48.617 F152
G1 X80.872 Y48.651 F152
G1 X80.898 Y48.681 F152
G1 X80.922 Y48.708 F152
G1 X80.956 Y48.75 F152
G1 X81.013 Y48.818 F152
G1 X81.063 Y48.88 F152
G1 X81.07 Y48.888 F152
G1 X81.128 Y48.96 F152
G1 X81.154 Y48.995 F152
G1 X81.185 Y49.034 F152
G1 X81.199 Y49.052 F152
G1 X81.242 Y49.108 F152
G1 X81.243 Y49.109 F152
G1 X81.287 Y49.167 F152
G1 X81.329 Y49.224 F152
G1 X81.357 Y49.261 F152
G1 X81.371 Y49.281 F152
G1 X81.414 Y49.338 F152
G1 Y49.339 F152
G1 X81.455 Y49.396 F152
G1 X81.471 Y49.419 F152
G1 X81.496 Y49.453 F152
G1 X81.529 Y49.5 F152
G1 X81.536 Y49.51 F152
G1 X81.576 Y49.568 F152
G1 X81.586 Y49.582 F152
G1 X81.616 Y49.625 F152
G1 X81.643 Y49.663 F152
G1 X81.657 Y49.682 F152
G1 X81.734 Y49.797 F152
G1 X81.758 Y49.833 F152
G1 X81.772 Y49.854 F152
G1 X81.811 Y49.911 F152
G1 X81.815 Y49.918 F152
G1 X81.848 Y49.969 F152
G1 X81.872 Y50.004 F152
G1 X81.887 Y50.026 F152
G1 X81.924 Y50.083 F152
G1 X81.93 Y50.091 F152
G1 X81.961 Y50.14 F152
G1 X81.987 Y50.181 F152
G1 X81.998 Y50.198 F152
G1 X82.035 Y50.255 F152
G1 X82.044 Y50.27 F152
G1 X82.071 Y50.312 F152
G1 X82.145 Y50.427 F152
G1 X82.159 Y50.451 F152
G1 X82.18 Y50.484 F152
G1 X82.215 Y50.541 F152
G1 X82.216 Y50.543 F152
G1 X82.25 Y50.599 F152
G1 X82.274 Y50.636 F152
G1 X82.286 Y50.656 F152
G1 X82.426 Y50.885 F152
G1 X82.46 Y50.942 F152
G1 X82.495 Y51 F152
G1 X82.503 Y51.014 F152
G1 X82.529 Y51.057 F152
G1 X82.56 Y51.111 F152
G1 X82.562 Y51.114 F152
G1 X82.596 Y51.172 F152
G1 X82.617 Y51.208 F152
G1 X82.63 Y51.229 F152
G1 X82.663 Y51.286 F152
G1 X82.675 Y51.307 F152
G1 X82.696 Y51.343 F152
G1 X82.729 Y51.401 F152
G1 X82.732 Y51.405 F152
G1 X82.789 Y51.505 F152
G1 X82.829 Y51.573 F152
G1 X82.847 Y51.605 F152
G1 X82.861 Y51.63 F152
G1 X82.893 Y51.687 F152
G1 X82.904 Y51.707 F152
G1 X82.925 Y51.744 F152
G1 X82.99 Y51.859 F152
G1 X83.018 Y51.909 F152
G1 X83.023 Y51.916 F152
G1 X83.055 Y51.974 F152
G1 X83.076 Y52.012 F152
G1 X83.087 Y52.031 F152
G1 X83.149 Y52.145 F152
G1 X83.181 Y52.203 F152
G1 X83.19 Y52.22 F152
G1 X83.213 Y52.26 F152
G1 X83.244 Y52.317 F152
G1 X83.276 Y52.375 F152
G1 X83.306 Y52.432 F152
G1 X83.336 Y52.489 F152
G1 X83.362 Y52.538 F152
G1 X83.367 Y52.546 F152
G1 X83.397 Y52.604 F152
G1 X83.42 Y52.647 F152
G1 X83.428 Y52.661 F152
G1 X83.457 Y52.718 F152
G1 X83.477 Y52.755 F152
G1 X83.488 Y52.776 F152
G1 X83.579 Y52.947 F152
G1 X83.591 Y52.972 F152
G1 X83.608 Y53.005 F152
G1 X83.639 Y53.062 F152
G1 X83.649 Y53.081 F152
G1 X83.669 Y53.119 F152
G1 X83.699 Y53.176 F152
G1 X83.728 Y53.234 F152
G1 X83.757 Y53.291 F152
G1 X83.763 Y53.304 F152
G1 X83.786 Y53.348 F152
G1 X83.814 Y53.406 F152
G1 X83.821 Y53.419 F152
G1 X83.843 Y53.463 F152
G1 X83.9 Y53.577 F152
G1 X83.928 Y53.635 F152
G1 X83.935 Y53.651 F152
G1 X83.956 Y53.692 F152
G1 X83.984 Y53.749 F152
G1 X83.993 Y53.769 F152
G1 X84.01 Y53.807 F152
G1 X84.05 Y53.888 F152
G1 X84.066 Y53.921 F152
G1 X84.093 Y53.978 F152
G1 X84.107 Y54.01 F152
G1 X84.12 Y54.036 F152
G1 X84.146 Y54.093 F152
G1 X84.164 Y54.133 F152
G1 X84.173 Y54.15 F152
G1 X84.199 Y54.208 F152
G1 X84.222 Y54.257 F152
G1 X84.225 Y54.265 F152
G1 X84.252 Y54.322 F152
G1 X84.277 Y54.379 F152
G1 X84.279 Y54.384 F152
G1 X84.302 Y54.437 F152
G1 X84.328 Y54.494 F152
G1 X84.336 Y54.514 F152
G1 X84.353 Y54.551 F152
G1 X84.394 Y54.644 F152
G1 X84.404 Y54.666 F152
G1 X84.428 Y54.723 F152
G1 X84.451 Y54.779 F152
G1 X84.452 Y54.78 F152
G1 X84.5 Y54.895 F152
G1 X84.508 Y54.915 F152
G1 X84.524 Y54.952 F152
G1 X84.549 Y55.01 F152
G1 X84.566 Y55.053 F152
G1 X84.572 Y55.067 F152
G1 X84.617 Y55.181 F152
G1 X84.623 Y55.197 F152
G1 X84.64 Y55.239 F152
G1 X84.68 Y55.342 F152
G1 X84.686 Y55.353 F152
G1 X84.707 Y55.411 F152
G1 X84.728 Y55.468 F152
G1 X84.737 Y55.495 F152
G1 X84.749 Y55.525 F152
G1 X84.771 Y55.582 F152
G1 X84.795 Y55.65 F152
G1 X84.813 Y55.697 F152
G1 X84.833 Y55.754 F152
G1 X84.852 Y55.806 F152
G1 X84.855 Y55.812 F152
G1 X84.874 Y55.869 F152
G1 X84.893 Y55.926 F152
G1 X84.909 Y55.976 F152
G1 X84.912 Y55.983 F152
G1 X84.932 Y56.041 F152
G1 X84.951 Y56.098 F152
G1 X84.967 Y56.146 F152
G1 X84.97 Y56.155 F152
G1 X84.989 Y56.213 F152
G1 X85.006 Y56.27 F152
G1 X85.024 Y56.327 F152
G1 Y56.33 F152
G1 X85.041 Y56.384 F152
G1 X85.075 Y56.499 F152
G1 X85.081 Y56.52 F152
G1 X85.093 Y56.556 F152
G1 X85.11 Y56.614 F152
G1 X85.125 Y56.671 F152
G1 X85.139 Y56.724 F152
G1 X85.14 Y56.728 F152
G1 X85.155 Y56.785 F152
G1 X85.185 Y56.9 F152
G1 X85.196 Y56.942 F152
G1 X85.2 Y56.957 F152
G1 X85.216 Y57.015 F152
G1 X85.253 Y57.186 F152
G1 Y57.187 F152
G1 X85.266 Y57.244 F152
G1 X85.279 Y57.301 F152
G1 X85.304 Y57.416 F152
G1 X85.31 Y57.454 F152
G1 X85.314 Y57.473 F152
G1 X85.334 Y57.587 F152
G1 X85.344 Y57.645 F152
G1 X85.364 Y57.759 F152
G1 X85.368 Y57.782 F152
G1 X85.374 Y57.817 F152
G1 X85.417 Y58.16 F152
G1 X85.423 Y58.217 F152
G1 X85.425 Y58.25 F152
G1 X85.427 Y58.275 F152
G1 X85.431 Y58.332 F152
G1 X85.435 Y58.389 F152
G1 X85.444 Y58.504 F152
G1 X85.447 Y58.561 F152
G1 X85.45 Y58.618 F152
G1 X85.451 Y58.676 F152
G1 Y58.733 F152
G1 X85.452 Y58.79 F152
G1 Y58.848 F152
G1 X85.453 Y58.905 F152
G1 Y58.962 F152
G1 X85.454 Y59.019 F152
G1 X85.453 Y59.077 F152
G1 X85.442 Y59.249 F152
G1 X85.438 Y59.306 F152
G1 X85.427 Y59.478 F152
G1 X85.425 Y59.498 F152
G1 X85.421 Y59.535 F152
G1 X85.389 Y59.764 F152
G1 X85.38 Y59.821 F152
G1 X85.372 Y59.879 F152
G1 X85.368 Y59.909 F152
G1 X85.364 Y59.936 F152
G1 X85.354 Y59.993 F152
G1 X85.342 Y60.051 F152
G1 X85.315 Y60.165 F152
G1 X85.31 Y60.185 F152
G1 X85.302 Y60.222 F152
G1 X85.289 Y60.28 F152
G1 X85.276 Y60.337 F152
G1 X85.263 Y60.394 F152
G1 X85.253 Y60.433 F152
G1 X85.249 Y60.452 F152
G1 X85.23 Y60.509 F152
G1 X85.212 Y60.566 F152
G1 X85.196 Y60.614 F152
G1 X85.193 Y60.623 F152
G1 X85.175 Y60.681 F152
G1 X85.138 Y60.795 F152
G1 X85.12 Y60.853 F152
G1 X85.099 Y60.91 F152
G1 X85.081 Y60.953 F152
G1 X85.076 Y60.967 F152
G1 X85.028 Y61.082 F152
G1 X85.024 Y61.089 F152
G1 X85.003 Y61.139 F152
G1 X84.979 Y61.196 F152
G1 X84.967 Y61.225 F152
G1 X84.955 Y61.254 F152
G1 X84.931 Y61.311 F152
G1 X84.909 Y61.356 F152
G1 X84.904 Y61.368 F152
G1 X84.874 Y61.425 F152
G1 X84.852 Y61.465 F152
G1 X84.843 Y61.483 F152
G1 X84.813 Y61.54 F152
G1 X84.795 Y61.573 F152
G1 X84.782 Y61.597 F152
G1 X84.691 Y61.769 F152
G1 X84.68 Y61.786 F152
G1 X84.655 Y61.826 F152
G1 X84.623 Y61.875 F152
G1 X84.617 Y61.884 F152
G1 X84.58 Y61.941 F152
G1 X84.543 Y61.998 F152
G1 X84.508 Y62.051 F152
G1 X84.506 Y62.056 F152
G1 X84.451 Y62.139 F152
G1 X84.431 Y62.17 F152
G1 X84.394 Y62.221 F152
G1 X84.389 Y62.227 F152
G1 X84.344 Y62.285 F152
G1 X84.336 Y62.295 F152
G1 X84.299 Y62.342 F152
G1 X84.279 Y62.367 F152
G1 X84.254 Y62.399 F152
G1 X84.222 Y62.439 F152
G1 X84.209 Y62.457 F152
G1 X84.164 Y62.513 F152
G1 Y62.514 F152
G1 X84.119 Y62.571 F152
G1 X84.107 Y62.584 F152
G1 X84.067 Y62.628 F152
G1 X84.012 Y62.686 F152
G1 X83.993 Y62.707 F152
G1 X83.959 Y62.743 F152
G1 X83.935 Y62.767 F152
G1 X83.904 Y62.8 F152
G1 X83.878 Y62.828 F152
G1 X83.849 Y62.857 F152
G1 X83.821 Y62.888 F152
G1 X83.796 Y62.915 F152
G1 X83.763 Y62.947 F152
G1 X83.737 Y62.972 F152
G1 X83.706 Y63 F152
G1 X83.674 Y63.029 F152
G1 X83.612 Y63.087 F152
G1 X83.591 Y63.105 F152
G1 X83.534 Y63.154 F152
G1 X83.42 Y63.249 F152
G1 X83.408 Y63.258 F152
G1 X83.362 Y63.294 F152
G1 X83.305 Y63.337 F152
G1 X83.258 Y63.373 F152
G1 X83.248 Y63.38 F152
G1 X83.19 Y63.423 F152
G1 X83.133 Y63.462 F152
G1 X83.095 Y63.488 F152
G1 X83.076 Y63.5 F152
G1 X83.018 Y63.539 F152
G1 X83.01 Y63.545 F152
G1 X82.961 Y63.575 F152
G1 X82.916 Y63.602 F152
G1 X82.904 Y63.609 F152
G1 X82.847 Y63.643 F152
G1 X82.82 Y63.659 F152
G1 X82.789 Y63.678 F152
G1 X82.675 Y63.739 F152
G1 X82.617 Y63.769 F152
G1 X82.608 Y63.774 F152
G1 X82.56 Y63.798 F152
G1 X82.503 Y63.825 F152
G1 X82.488 Y63.831 F152
G1 X82.445 Y63.851 F152
G1 X82.388 Y63.877 F152
G1 X82.361 Y63.889 F152
G1 X82.331 Y63.902 F152
G1 X82.274 Y63.924 F152
G1 X82.216 Y63.946 F152
G1 X82.215 F152
G1 X82.159 Y63.968 F152
G1 X82.102 Y63.988 F152
G1 X82.054 Y64.003 F152
G1 X82.044 Y64.007 F152
G1 X81.987 Y64.025 F152
G1 X81.93 Y64.043 F152
G1 X81.872 Y64.059 F152
G1 X81.866 Y64.06 F152
G1 X81.815 Y64.074 F152
G1 X81.701 Y64.103 F152
G1 X81.643 Y64.114 F152
G1 X81.624 Y64.118 F152
G1 X81.586 Y64.125 F152
G1 X81.471 Y64.146 F152
G1 X81.414 Y64.154 F152
G1 X81.299 Y64.169 F152
G1 X81.242 Y64.175 F152
G1 X81.185 Y64.18 F152
G1 X81.07 Y64.187 F152
G1 X81.013 Y64.189 F152
G1 X80.956 F152
G1 X80.898 Y64.19 F152
G1 X80.841 F152
G1 X80.784 Y64.188 F152
G1 X80.669 Y64.18 F152
G1 X80.616 Y64.175 F152
G1 X80.612 F152
G1 X80.44 Y64.162 F152
G1 X80.383 Y64.154 F152
G1 X80.268 Y64.132 F152
G1 X80.211 Y64.122 F152
G1 X80.19 Y64.118 F152
G1 X80.154 Y64.111 F152
G1 X80.096 Y64.101 F152
G1 X80.039 Y64.089 F152
G1 X79.982 Y64.074 F152
G1 X79.935 Y64.06 F152
G1 X79.924 Y64.058 F152
G1 X79.752 Y64.009 F152
G1 X79.731 Y64.003 F152
G1 X79.695 Y63.992 F152
G1 X79.581 Y63.951 F152
G1 X79.568 Y63.946 F152
G1 X79.466 Y63.909 F152
G1 X79.412 Y63.889 F152
G1 X79.409 Y63.888 F152
G1 X79.351 Y63.864 F152
G1 X79.294 Y63.838 F152
G1 X79.281 Y63.831 F152
G1 X79.237 Y63.813 F152
G1 X79.122 Y63.761 F152
G1 X79.065 Y63.732 F152
G1 X79.037 Y63.717 F152
G1 X78.95 Y63.672 F152
G1 X78.927 Y63.659 F152
G1 X78.893 Y63.642 F152
G1 X78.836 Y63.61 F152
G1 X78.822 Y63.602 F152
G1 X78.778 Y63.577 F152
G1 X78.725 Y63.545 F152
G1 X78.721 Y63.543 F152
G1 X78.664 Y63.509 F152
G1 X78.628 Y63.488 F152
G1 X78.606 Y63.473 F152
G1 X78.549 Y63.436 F152
G1 X78.541 Y63.43 F152
G1 X78.492 Y63.398 F152
G1 X78.453 Y63.373 F152
G1 X78.435 Y63.361 F152
G1 X78.377 Y63.321 F152
G1 X78.37 Y63.316 F152
G1 X78.32 Y63.279 F152
G1 X78.205 Y63.197 F152
G1 X78.091 Y63.105 F152
G1 X78.067 Y63.087 F152
G1 X78.033 Y63.061 F152
G1 X77.976 Y63.014 F152
G1 X77.928 Y62.972 F152
G1 X77.919 Y62.965 F152
G1 X77.862 Y62.916 F152
G1 X77.861 Y62.915 F152
G1 X77.804 Y62.866 F152
G1 X77.796 Y62.857 F152
G1 X77.734 Y62.8 F152
G1 X77.674 Y62.743 F152
G1 X77.632 Y62.704 F152
G1 X77.613 Y62.686 F152
G1 X77.46 Y62.533 F152
G1 X77.403 Y62.474 F152
G1 X77.387 Y62.457 F152
G1 X77.346 Y62.414 F152
G1 X77.332 Y62.399 F152
G1 X77.289 Y62.354 F152
G1 X77.278 Y62.342 F152
G1 X77.231 Y62.295 F152
G1 X77.221 Y62.285 F152
G1 X77.174 Y62.235 F152
G1 X77.166 Y62.227 F152
G1 X77.104 Y62.17 F152
G1 X77.059 Y62.134 F152
G1 X77.054 Y62.131 F152
G1 X77.05 Y62.128 F152
G1 Z15.24 F152
; *** SECTION end ***
;
; *** STOP begin ***
M400
; COMMAND_COOLANT_OFF
; ---- Coolant: Off cur: Off A: Off B: Off
G0 X0 Y0 F4470
; COMMAND_STOP_SPINDLE
M300 S300 P3000
M0 Turn OFF spindle
M117 Job end
; *** STOP end ***
