# Snoopy Wall Decoration V4

**Check all dimensions and simulate G-code before running.**

---

## File Naming Convention
Files are named as: #ID of wood _ #ID of order_Bit to use_cut/notes.gcode


**Example:**  
The third operation for walnut would be: “2_3_Walnut-3degTAPER_adaptive_inner.gcode”



---

## Required Bits (1/4” Shank)
- 1/8” Up Cut End Mill *(YOKISHUN | B0D22KJMD2)*
- 1/4” Up Cut End Mill *(YOKISHUN | B0D22KJMD2)*
- 1/4” Up Cut Ball Nose *(YOKISHUN | B0D22KJMD2)*
- 6.2˚ Tapered Angle Ball Tip *(Amana Tool | 46473)*

---

## Wood Stock
- 1 = **Poplar:** 11.75” × 7.75” × 1”
- 2 = **Paduak:** 4.1” × 5.5” × 1”
- 3 = **Walnut:** 5.84” × 4.25” × 1”

---

## G-code Files

### Poplar
- `1_1_Poplar-1o8ENDmill.gcode`
- `1_2_Poplar-3degTaper_pensil.gcode`
- `1_3_Poplar-3degTaper_adaptive.gcode`
- `1_4_LAST_Poplar-1o4BALL_adaptive_DOLAST.gcode`  
  *→ Use this file after all inlays have been completed and glued.*

### Walnut
- `2_1_Walnut-1o8END_adaptive.gcode`
- `2_2_Walnut-3degTAPER_pensil.gcode`
- `2_3_Walnut-3degTAPER_adaptive_inner.gcode`
- `2_4_Walnut-3degTAPER_adaptive_outter.gcode`

### Paduak
- `3_1_Paduak-1o4END_adaptive.gcode`
- `3_2_Paduak-3degTaper_pencil.gcode`
- `3_3_Paduak-3degTaper_adaptive.gcode`

---

## Useful Files
- `3x3-10mm_startsbottomleft_1_4ENDMILL.gcode`
- `2mmClearingoffSnoop_fixerrors.gcode`
- `5x5boxclearing_10mm_1_4ENDMILL.gcode`
